// Escanor focus helper (GNOME Shell 45 and later, Wayland or X11).
//
// GNOME does not let a program that is not itself in front bring a window to the front or make it full screen, and F11 pressed through
// the remote-desktop service goes to whichever window happens to have the keyboard. The shell itself can do both, so this tiny extension
// offers four calls on the session bus, on the shell's own name (org.gnome.Shell), path /in/escanor/Focus:
//   Windows() -> JSON text: the open normal windows, the one used most recently first
//   Active()  -> JSON text: the window in front (or null)
//   Focus(id) -> bool       brings that window to the front
//   Fullscreen(id) -> bool  makes that window full screen
// Every window is described by its id, the application class, its title, its process id and whether it is full screen or in front.
// It reads nothing inside any window, takes no pictures and sends no keys.
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

const IFACE = `<node><interface name="in.escanor.Focus">
  <method name="Windows"><arg type="s" direction="out" name="json"/></method>
  <method name="Active"><arg type="s" direction="out" name="json"/></method>
  <method name="Focus"><arg type="t" direction="in" name="id"/><arg type="b" direction="out" name="ok"/></method>
  <method name="Fullscreen"><arg type="t" direction="in" name="id"/><arg type="b" direction="out" name="ok"/></method>
  <property name="Version" type="u" access="read"/>
</interface></node>`;

const VERSION = 1;

function describe(w, focus) {
  return {
    id: Number(w.get_id()),
    wmClass: w.get_wm_class() ?? '',
    title: (w.get_title() ?? '').slice(0, 200),
    pid: w.get_pid(),
    fullscreen: w.is_fullscreen(),
    focused: w === focus,
  };
}

function normalWindows() {
  const list = global.display.get_tab_list(Meta.TabList.NORMAL, null);
  return list.filter((w) => w.get_window_type() === Meta.WindowType.NORMAL && !w.is_skip_taskbar());
}

/** Brings a window to the front. The shell's own activation first (it also changes workspace and un-minimizes); GNOME's focus-stealing
 * check can turn that into a mere "needs attention" when another window was used more recently, so the shell then gives the window
 * the keyboard itself, which the check does not apply to. */
function bringToFront(w) {
  Main.activateWindow(w);
  if (global.display.focus_window !== w) {
    w.raise();
    w.focus(global.get_current_time());
  }
}

function byId(id) {
  return normalWindows().find((w) => Number(w.get_id()) === Number(id)) ?? null;
}

export default class EscanorFocus extends Extension {
  enable() {
    this._impl = {
      Windows: () => JSON.stringify(normalWindows().map((w) => describe(w, global.display.focus_window))),
      Active: () => {
        const w = global.display.focus_window;
        return JSON.stringify(w && w.get_window_type() === Meta.WindowType.NORMAL ? describe(w, w) : null);
      },
      Focus: (id) => {
        const w = byId(id);
        if (!w) return false;
        bringToFront(w);
        return true;
      },
      Fullscreen: (id) => {
        const w = byId(id);
        if (!w) return false;
        if (!w.is_fullscreen()) w.make_fullscreen();
        bringToFront(w);
        return true;
      },
      get Version() {
        return VERSION;
      },
    };
    this._dbus = Gio.DBusExportedObject.wrapJSObject(IFACE, this._impl);
    this._dbus.export(Gio.DBus.session, '/in/escanor/Focus');
  }

  disable() {
    this._dbus?.unexport();
    this._dbus = null;
    this._impl = null;
  }
}
