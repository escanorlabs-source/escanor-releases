import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { AgentToHubMessage, HubUserInput } from '@remote-harness/shared';

/**
 * AGIN: the hub may send a message from the apps again when the socket died before it got this machine's confirmation
 * (input_ack). The same `inputId` must not be typed into the chat twice: the repeat gets the confirmation it already got
 * (or nothing yet, while the first copy is still on its way, since that confirmation will follow on its own).
 *
 * Keyed on the inputId alone (the hub makes it a random UUID per message), so a repeat that names the real chat instead of a new
 * chat's temp id is still recognised. Kept on disk (data/seen-inputs.json), the newest `maxEntries` for `ttlMs`. Only an id that
 * reached a final answer (delivered or refused) is loaded back after a restart: a message the last process held in memory
 * (queued, or not yet handed to Claude) went with it, so a copy sent again runs. The exception (0.9.7): what waited in the saved
 * queue (data/queue.json) did not go, and keepQueued() marks it seen again at start.
 */

type AckStatus = 'delivered' | 'queued' | 'refused';
type InputAck = Extract<AgentToHubMessage, { type: 'input_ack' }>;
type StoredAck = { sessionId: string; tempId?: string; status: AckStatus; reason?: string };
type Entry = { inputId: string; at: number; ack?: StoredAck };

export const SEEN_INPUTS_MAX = 1000;
export const SEEN_INPUTS_TTL_MS = 24 * 3_600_000;

const STATUSES = new Set<string>(['delivered', 'queued', 'refused']);
const isFinal = (s: AckStatus | undefined) => s === 'delivered' || s === 'refused';
/** The hub's ids for app messages; `agent:` ones are the agent's own (a fix continued after a restart) and never repeat. */
const tracked = (id: unknown): id is string => typeof id === 'string' && id.length > 0 && id.length <= 200 && !id.startsWith('agent:');

function readAck(a: unknown): StoredAck | undefined | null {
  if (a === undefined) return undefined;
  if (typeof a !== 'object' || a === null) return null;
  const o = a as Record<string, unknown>;
  if (typeof o.sessionId !== 'string' || typeof o.status !== 'string' || !STATUSES.has(o.status)) return null;
  if (o.tempId !== undefined && typeof o.tempId !== 'string') return null;
  if (o.reason !== undefined && typeof o.reason !== 'string') return null;
  return {
    sessionId: o.sessionId,
    ...(o.tempId ? { tempId: o.tempId as string } : {}),
    status: o.status as AckStatus,
    ...(o.reason ? { reason: o.reason as string } : {}),
  };
}

/** A message that waits in this machine's saved queue (data/queue.json, QUEUEUI): it survived the restart. */
export type QueuedInput = { inputId: string; sessionId: string; tempId?: string };

export class SeenInputs {
  private entries = new Map<string, Entry>(); // oldest first
  private file: string | null;
  private max: number;
  private ttl: number;
  private now: () => number;

  constructor(opts: { file: string | null; maxEntries?: number; ttlMs?: number; now?: () => number }) {
    this.file = opts.file;
    this.max = opts.maxEntries ?? SEEN_INPUTS_MAX;
    this.ttl = opts.ttlMs ?? SEEN_INPUTS_TTL_MS;
    this.now = opts.now ?? Date.now;
    this.load();
  }

  /**
   * A user_input from the hub. `run` = it is new (it is on disk before it runs, so a crash right after cannot run it twice);
   * otherwise `ack` is the confirmation to send again, if it has one yet.
   */
  take(input: HubUserInput): { run: true } | { run: false; ack?: InputAck } {
    if (!tracked(input.inputId)) return { run: true };
    this.prune();
    const seen = this.entries.get(input.inputId);
    if (seen) {
      if (!seen.ack) return { run: false };
      return { run: false, ack: { type: 'input_ack', ...seen.ack, inputId: input.inputId } };
    }
    this.entries.set(input.inputId, { inputId: input.inputId, at: this.now() });
    this.trim();
    this.save();
    return { run: true };
  }

  /**
   * QUEUEUI: the messages that waited in the saved queue when the agent stopped did not die with it (data/queue.json), so they are
   * seen again at once, as queued: a copy the hub sends again is only confirmed, whether it comes before the saved queue starts or
   * after, and the `delivered` that follows when it starts replaces the queued.
   */
  keepQueued(items: QueuedInput[]): void {
    let changed = false;
    for (const q of items) {
      if (!tracked(q.inputId)) continue;
      const e = this.entries.get(q.inputId);
      if (e && isFinal(e.ack?.status)) continue;
      this.entries.set(q.inputId, {
        inputId: q.inputId,
        at: e?.at ?? this.now(),
        ack: { sessionId: q.sessionId, ...(q.tempId ? { tempId: q.tempId } : {}), status: 'queued' },
      });
      changed = true;
    }
    if (!changed) return;
    this.trim();
    this.save();
  }

  /** Every message the agent sends goes past here: the latest answer for each id is kept (a final one is never replaced). */
  observe(msg: AgentToHubMessage): void {
    if (msg.type !== 'input_ack' || !tracked(msg.inputId)) return;
    const e = this.entries.get(msg.inputId);
    if (!e || !STATUSES.has(msg.status)) return;
    if (isFinal(e.ack?.status)) return;
    const reason = typeof msg.reason === 'string' && msg.reason ? msg.reason.slice(0, 300) : undefined;
    e.ack = {
      sessionId: msg.sessionId,
      ...(msg.tempId ? { tempId: msg.tempId } : {}),
      status: msg.status as AckStatus,
      ...(reason ? { reason } : {}),
    };
    this.save();
  }

  private prune(): void {
    const oldest = this.now() - this.ttl;
    for (const [id, e] of this.entries) {
      if (e.at >= oldest) break; // in order of arrival
      this.entries.delete(id);
    }
  }

  private trim(): void {
    while (this.entries.size > this.max) this.entries.delete(this.entries.keys().next().value!);
  }

  private load(): void {
    if (!this.file) return;
    let raw: unknown;
    try {
      raw = JSON.parse(readFileSync(this.file, 'utf8'));
    } catch {
      return; // none yet, or unreadable: start empty (at worst one message runs twice, as before this file existed)
    }
    if (!Array.isArray(raw)) return;
    const oldest = this.now() - this.ttl;
    const rows: Entry[] = [];
    for (const r of raw) {
      if (typeof r !== 'object' || r === null) continue;
      const o = r as Record<string, unknown>;
      if (!tracked(o.inputId) || typeof o.at !== 'number' || o.at < oldest) continue;
      const ack = readAck(o.ack);
      if (!ack || !isFinal(ack.status)) continue; // see the class comment: only finished messages are remembered across a restart
      rows.push({ inputId: o.inputId, at: o.at, ack });
    }
    rows.sort((a, b) => a.at - b.at);
    for (const e of rows) this.entries.set(e.inputId, e);
    this.trim();
  }

  private save(): void {
    if (!this.file) return;
    try {
      mkdirSync(dirname(this.file), { recursive: true });
      const tmp = `${this.file}.tmp`;
      writeFileSync(tmp, JSON.stringify([...this.entries.values()]), { mode: 0o600 });
      renameSync(tmp, this.file);
    } catch (err) {
      console.error(`Could not write the list of handled messages (${err instanceof Error ? err.message : err}).`);
    }
  }
}

/** What the agent does with a user_input from the hub: run it once; answer a repeat with the confirmation it already got. */
export function routeHubInput(
  seen: SeenInputs,
  input: HubUserInput,
  run: (input: HubUserInput) => void,
  send: (msg: AgentToHubMessage) => void,
): void {
  const r = seen.take(input);
  if (r.run) {
    run(input);
    return;
  }
  console.log(`Message ${input.inputId} came again: not run a second time${r.ack ? `, confirmed again (${r.ack.status})` : ''}`);
  if (r.ack) send(r.ack);
}
