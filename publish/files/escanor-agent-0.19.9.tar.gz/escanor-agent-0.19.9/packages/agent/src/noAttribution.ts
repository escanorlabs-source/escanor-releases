/**
 * Claude Code adds "Co-Authored-By: Claude ..." to commits and "Generated with Claude Code" to pull requests. Escanor's chats never
 * do: nothing that Escanor makes (an app built for someone, a fix, a change) carries the AI's name. Passed to every chat the agent
 * starts as settings, so it holds whatever the machine's own settings files say.
 */
export const NO_ATTRIBUTION = {
  includeCoAuthoredBy: false,
  attribution: { commit: '', pr: '' },
} as const;
