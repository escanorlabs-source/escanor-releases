import { closeSync, existsSync, openSync, readSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';

/**
 * A chat the app asks to continue that this agent has no registry row for. Two agents can serve one computer (the background service
 * and the Desktop app's own), each with its own list of chats, while Claude keeps every transcript in the same place on disk. So
 * before refusing, the agent looks for the transcript itself: found, the chat is taken into this agent's list and goes on as before.
 */
export type FoundTranscript = { sessionId: string; cwd: string; title: string; createdAt: string; configDir: string };

const ID_RE = /^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$/;
const HEAD_BYTES = 256 * 1024;

function head(file: string): string {
  let fd: number | null = null;
  try {
    fd = openSync(file, 'r');
    const buf = Buffer.alloc(HEAD_BYTES);
    const n = readSync(fd, buf, 0, HEAD_BYTES, 0);
    return buf.subarray(0, n).toString('utf8');
  } catch {
    return '';
  } finally {
    if (fd !== null) closeSync(fd);
  }
}

function textOf(content: unknown): string {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    for (const part of content) {
      if (part && typeof part === 'object' && (part as { type?: unknown }).type === 'text' && typeof (part as { text?: unknown }).text === 'string') return (part as { text: string }).text;
    }
  }
  return '';
}

/** Looks for <dir>/projects/<project>/<sessionId>.jsonl in each Claude config folder; returns where the chat was held, or null. */
export function findTranscript(sessionId: string, configDirs: string[]): FoundTranscript | null {
  if (!ID_RE.test(sessionId)) return null; // also keeps a hostile id from ever becoming a path
  for (const dir of new Set(configDirs.filter(Boolean))) {
    const projects = join(dir, 'projects');
    let subs: string[];
    try {
      subs = readdirSync(projects);
    } catch {
      continue;
    }
    for (const sub of subs) {
      const file = join(projects, sub, `${sessionId}.jsonl`);
      if (!existsSync(file)) continue;
      let cwd = '';
      let title = '';
      for (const line of head(file).split('\n')) {
        if (!line.trim()) continue;
        let j: { cwd?: unknown; type?: unknown; message?: { content?: unknown }; isSidechain?: unknown; isMeta?: unknown };
        try {
          j = JSON.parse(line);
        } catch {
          continue; // a line cut at the end of what was read
        }
        if (!cwd && typeof j.cwd === 'string' && j.cwd) cwd = j.cwd;
        if (!title && j.type === 'user' && !j.isMeta && !j.isSidechain) title = textOf(j.message?.content).trim();
        if (cwd && title) break;
      }
      if (!cwd) continue;
      let createdAt = new Date().toISOString();
      try {
        createdAt = statSync(file).birthtime.toISOString();
      } catch {
        // keep now
      }
      return { sessionId, cwd, title, createdAt, configDir: dir };
    }
  }
  return null;
}
