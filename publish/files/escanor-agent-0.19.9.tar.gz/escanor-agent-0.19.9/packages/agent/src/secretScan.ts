/**
 * Find keys and passwords in text before Escanor sends it anywhere (F2 key protections).
 *
 * Mirrors mongo-backend secret_scan.py and escanor-mcp secret_scan.py: the same rules, the same exclusions, the same placeholder
 * (`[hidden: <kind>]`), the same mask and the same fingerprint (SHA-256 hex of the value, a private key without its line breaks),
 * so a key found here is matched by the backend against the workspace's own stored keys without the key ever leaving this machine.
 * The same file lives in the harness agent (packages/agent/src/secretScan.ts) and in escanor-hub (src/secretScan.ts): keep them in step.
 *
 * What is a key: the well-known formats (AWS, Google Cloud service-account JSON, GitHub, GitLab, Stripe, Razorpay, OpenAI,
 * Anthropic, Groq, Slack, SendGrid, npm, private keys, passwords inside database URLs, Escanor's own tokens), and a high-entropy
 * value right next to a key-like name (`API_KEY = "..."`, `client_secret: ...`). Documentation examples (AWS's own documentation key, ending in EXAMPLE),
 * placeholders (`your-key-here`, `xxxx`, `${TOKEN}`, `<token>`), values read from the environment (`process.env.X`,
 * `os.environ[...]`), a line marked `escanor-allow-secret` (or gitleaks' / detect-secrets' markers) and files named *.example or
 * *.sample are not keys.
 *
 * `blocksPush: false` rules (a Google browser API key, which Firebase web config ships in public on purpose) are hidden from
 * models and apps but never stop a push. Self-contained (no imports) so it runs in Node and in a Cloudflare Worker alike.
 */

export const MAX_SCAN_CHARS = 2_000_000;
export const MAX_FINDINGS = 50;
export const ALLOW_MARKERS = ['escanor-allow-secret', 'gitleaks:allow', 'pragma: allowlist secret', 'nosec: secret'];
/** Files that hold examples on purpose (.env.example, config.sample): never scanned. */
export const EXAMPLE_FILE = /\.(?:example|sample)$/i;

interface Rule {
  id: string;
  label: string;
  pattern: RegExp;
  group: number;
  blocksPush: boolean;
  generic: boolean;
}

function r(id: string, label: string, source: string, flags = '', o: { group?: number; blocksPush?: boolean; generic?: boolean } = {}): Rule {
  return { id, label, pattern: new RegExp(source, `${flags}gd`), group: o.group ?? 1, blocksPush: o.blocksPush ?? true, generic: o.generic ?? false };
}

const NAME =
  '(?:[A-Za-z0-9_.-]{0,40}?(?:api[_-]?key|apikey|secret|token|passw(?:or)?d|passwd|pwd|private[_-]?key|access[_-]?key|' +
  'client[_-]?secret|auth[_-]?key|credential|signing[_-]?key|webhook[_-]?secret)s?)';

export const RULES: readonly Rule[] = [
  r('private_key', 'private key', '(-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----(?:.{0,8000}?-----END (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----)?)', 's'),
  r('gcp_service_account', 'Google Cloud service account key', '"private_key_id"\\s*:\\s*"([0-9a-f]{40})"'),
  r('aws_access_key', 'AWS access key', '(?<![A-Za-z0-9])((?:AKIA|ASIA)[0-9A-Z]{16})(?![A-Za-z0-9])'),
  r('aws_secret_key', 'AWS secret key', 'aws[A-Za-z0-9_.-]{0,20}?(?:secret|sk)[A-Za-z0-9_.-]{0,20}?["\']?\\s*(?:[:=]|=>)\\s*["\']?([A-Za-z0-9/+]{40})(?![A-Za-z0-9/+])', 'i'),
  r('github_token', 'GitHub token', '(?<![A-Za-z0-9_])((?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,255})(?![A-Za-z0-9_])'),
  r('github_pat', 'GitHub token', '(?<![A-Za-z0-9_])(github_pat_[A-Za-z0-9_]{22,255})(?![A-Za-z0-9_])'),
  r('gitlab_token', 'GitLab token', '(?<![A-Za-z0-9_])(glpat-[A-Za-z0-9_-]{20,})'),
  r('stripe_key', 'Stripe secret key', '(?<![A-Za-z0-9_])((?:sk|rk)_(?:live|test)_[A-Za-z0-9]{16,})(?![A-Za-z0-9_])'),
  r('stripe_webhook', 'Stripe webhook secret', '(?<![A-Za-z0-9_])(whsec_[A-Za-z0-9+/=]{24,})'),
  r('razorpay_secret', 'Razorpay key secret', 'razorpay[A-Za-z0-9_.-]{0,20}?secret["\']?\\s*(?:[:=]|=>)\\s*["\']?([A-Za-z0-9]{20,})(?![A-Za-z0-9])', 'i'),
  r('anthropic_key', 'Anthropic API key', '(?<![A-Za-z0-9_-])(sk-ant-[A-Za-z0-9_-]{20,})'),
  r('openai_key', 'OpenAI API key', '(?<![A-Za-z0-9_-])(sk-(?:proj|svcacct|admin|None)-[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9]{20}T3BlbkFJ[A-Za-z0-9]{20}|sk-[A-Za-z0-9]{48})(?![A-Za-z0-9_-])'),
  r('groq_key', 'Groq API key', '(?<![A-Za-z0-9_])(gsk_[A-Za-z0-9]{40,})(?![A-Za-z0-9_])'),
  r('slack_token', 'Slack token', '(?<![A-Za-z0-9_-])(xox[abposr]-[A-Za-z0-9-]{10,})'),
  r('slack_webhook', 'Slack webhook address', '(https://hooks\\.slack\\.com/(?:services|workflows)/[A-Za-z0-9_/]{20,})'),
  r('sendgrid_key', 'SendGrid API key', '(?<![A-Za-z0-9_])(SG\\.[A-Za-z0-9_-]{22}\\.[A-Za-z0-9_-]{43})(?![A-Za-z0-9_-])'),
  r('npm_token', 'npm token', '(?<![A-Za-z0-9_])(npm_[A-Za-z0-9]{36})(?![A-Za-z0-9_])'),
  r('escanor_token', 'Escanor token', '(?<![A-Za-z0-9_])((?:escanor|esc_llm|escl|upt_src)_[A-Za-z0-9_-]{40,})'),
  r('db_password', 'database password', '\\b(?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\\+srv)?|redis|rediss|amqps?)://([^:/\\s"\'@]+):([^@\\s"\'/]{6,})@(\\[[0-9A-Fa-f:]*\\]|[^:/\\s"\'?#,]*)', 'i', { group: 2 }),
  r('google_api_key', 'Google API key', '(?<![A-Za-z0-9_-])(AIza[0-9A-Za-z_-]{35})(?![A-Za-z0-9_-])', '', { blocksPush: false }),
  r('google_ai_studio_key', 'Google AI Studio key', '(?<![A-Za-z0-9_.-])(AQ\\.[0-9A-Za-z_-][0-9A-Za-z_.-]{30,})(?![A-Za-z0-9_.-])', '', { blocksPush: false }),
  // Django SECRET_KEY / Rails secret_key_base (also DJANGO_SECRET_KEY=..., config.secret_key_base = "..."): the value may hold quotes-free
  // symbols the generic rule stops at, so these two read a whole quoted value, or an unquoted one up to the next space.
  r('framework_secret', 'secret key', '(?<![A-Za-z0-9])secret_key(?:_base)?["\']?\\s*(?:=|:=|:)\\s*(["\'`])((?:(?!\\1)[^\\s]){20,256}?)\\1', 'i', { group: 2 }),
  r('framework_secret', 'secret key', '(?<![A-Za-z0-9])secret_key(?:_base)?["\']?[ \\t]*(?:=|:=|:)[ \\t]*([^\\s"\'`,;]{20,512})', 'i'),
  r('named_secret', 'key or password',
    '(?<![A-Za-z0-9])(' + NAME + ')["\'`]?\\s*(?:[:=]|=>|:=)\\s*["\'`]?([A-Za-z0-9_\\-+/=.~!@#$%^&*]{16,})(?=["\'`,;\\s)}\\]]|$)',
    'im', { generic: true }),
];

/** A generic match whose name says it is about a key, not the key (token_type: "Bearer", max_tokens = 4096, secret_name = ...). */
const ABOUT = /(?:^|[_.-])(?:id|ids|name|names|type|types|count|max|min|limit|url|uri|hint|prefix|suffix|last4|length|label|version|arn|path|ref|kind|format|status|header|field|env|var|file|endpoint|expires|expiry|scope|scopes|usage|page|cursor|next|input|output|total|ttl|policy|description)$/i;
const PLACEHOLDER = /example|sample|dummy|fake|placeholder|changeme|change_me|redacted|your[_-]?|xxxx|\*\*\*|<[^>]*>|\$\{|\{\{|%[sd(]|replace[_-]?me|insert[_-]?|not[_-]?a[_-]?real|test[_-]?key|todo|0000000000|1234567890|abcdefghij/i;
const FROM_CODE = /^(?:process\.env|os\.environ|os\.getenv|env\.|getenv|import\.meta\.env|config\.|settings\.|self\.|this\.|request\.|req\.|args\.|params\.|props\.|ctx\.|context\.)/i;
const KNOWN_EXAMPLES = new Set(['AKIA' + 'IOSFODNN7EXAMPLE', 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY']);
/** A value that is code, not a key: a dotted reference (random_password.rds2.result) or a type name (AccessTokenProvider). */
const CODE_REF = /^[A-Za-z_$][\w$]{0,40}(?:\.[A-Za-z_$][\w$]{0,40})+$/;
const TYPE_NAME = /^(?:[A-Z][a-z]{2,}){2,}[0-9]{0,3}$/;
/** Lowercase words joined by _ . - (a name such as random_secret_generator_v2, my-dev-secret-123): not a random token. */
const NAME_LIKE = /^(?:[a-z]+\d{0,2}|\d{1,4})(?:[_.-](?:[a-z]+\d{0,2}|\d{1,4}))+$/;
/** A database address on this computer, or a well-known development password: not a key in use. */
const LOCAL_HOST = /^(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[?::1\]?|host\.docker\.internal)$/i;
const DEV_PASSWORDS = new Set(['postgres', 'password', 'passwd', 'secret', 'root', 'example', 'test', 'testing', 'dev', 'admin', 'mysql',
  'mongo', 'redis', 'guest', 'changeme', 'pass123', 'password123', 'secret123', 'postgrespw']);
/** Kinds whose start says nothing about the kind (a password, a generic value): shown with no characters at all. */
const NO_START = new Set(['named_secret', 'db_password', 'framework_secret']);

export interface Finding {
  rule: string;
  label: string;
  path: string;
  line: number;
  /** Never logged or shown: `mask(value)` is what anyone sees. */
  value: string;
  blocksPush: boolean;
  /** The commit that adds the key (a push scan only): its first 7 characters are named in the refusal. */
  commit?: string;
}

/** The form a value is compared in: a private key without its line breaks (a JSON file writes them as `\n`). */
export function normalise(value: string): string {
  if (value.includes('PRIVATE KEY')) return value.replace(/\\n|\s/g, '');
  return value.trim();
}

/** SHA-256 hex of the normalised value (WebCrypto: Node 18+ and Workers). */
export async function fingerprint(value: string): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(normalise(value)));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

/** A found key as it is shown: its kind of start and its length, never enough to use it. */
export function mask(value: string, rule = ''): string {
  const text = String(value);
  if (text.includes('PRIVATE KEY')) return '-----BEGIN PRIVATE KEY----- (hidden)';
  const shown = text.length >= 16 && !NO_START.has(rule) ? text.slice(0, 4) : '';
  return shown ? `${shown}… (${text.length} characters)` : `(hidden, ${text.length} characters)`;
}

export function where(f: Pick<Finding, 'path' | 'line' | 'commit'>): string {
  const place = f.path ? `${f.path} line ${f.line}` : `line ${f.line}`;
  return f.commit ? `${place} (commit ${f.commit.slice(0, 7)})` : place;
}

export function entropy(value: string): number {
  if (!value) return 0;
  const counts = new Map<string, number>();
  for (const ch of value) counts.set(ch, (counts.get(ch) ?? 0) + 1);
  let e = 0;
  for (const c of counts.values()) e -= (c / value.length) * Math.log2(c / value.length);
  return e;
}

/** A generic value that looks like a key: long, varied, mixed letters and digits (or cases), not a word or a path. */
/** A dotted reference in code, not a dotted token: no part of it is long, mixed-case and with digits (as a key's parts are). */
function codeRef(value: string): boolean {
  if (!CODE_REF.test(value) || value.startsWith('eyJ')) return false;
  return !value.split('.').some((p) => p.length >= 16 && /\d/.test(p) && /[a-z]/.test(p) && /[A-Z]/.test(p));
}

function looksRandom(value: string): boolean {
  if (value.length < 16 || PLACEHOLDER.test(value) || FROM_CODE.test(value)) return false;
  if (/^[a-z]+(?:[_.-][a-z]+)*$/.test(value) || /^[A-Z]+(?:_[A-Z]+)*$/.test(value)) return false;
  if ((value.match(/\./g)?.length ?? 0) >= 2 && /^[A-Za-z_][\w.]*$/.test(value) && !/\d/.test(value)) return false;
  if (codeRef(value) || TYPE_NAME.test(value)) return false;
  const letters = /[A-Za-z]/.test(value);
  const digits = /\d/.test(value);
  const mixedCase = /[a-z]/.test(value) && /[A-Z]/.test(value);
  if (!((letters && digits) || mixedCase)) return false;
  const hexish = /^[0-9a-fA-F]+$/.test(value);
  return entropy(value) >= (hexish ? 3.0 : 3.5);
}

/**
 * The sample token jwt.io shows (and the copies of it every JWT library's tests use, whatever the signature or algorithm): its payload
 * is exactly `sub: 1234567890, name: John Doe` (with jwt.io's own iat / admin when present). A token like that is documentation, not
 * a key in use. (The signature is not checked: tests sign the sample with their own throwaway secrets.)
 */
export function isJwtSample(value: string): boolean {
  const m = /^eyJ[\w-]+\.(eyJ[\w-]+)(?:\.[\w-]*)?$/.exec(value);
  if (!m) return false;
  try {
    const b64 = m[1].replace(/-/g, '+').replace(/_/g, '/');
    const payload = globalThis.atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4));
    // Exactly the claims jwt.io's samples carry, with their values: a token with anything more (a role, an expiry) is someone's own.
    const claims = JSON.parse(payload) as Record<string, unknown>;
    const allowed = new Set(['sub', 'name', 'admin', 'iat']);
    return (
      Object.keys(claims).every((k) => allowed.has(k)) &&
      claims.sub === '1234567890' &&
      claims.name === 'John Doe' &&
      (claims.iat === undefined || claims.iat === 1516239022) &&
      (claims.admin === undefined || claims.admin === true)
    );
  } catch {
    return false;
  }
}

function allowedLine(text: string, start: number): boolean {
  const begin = text.lastIndexOf('\n', start - 1) + 1;
  const endAt = text.indexOf('\n', start);
  const line = text.slice(begin, endAt === -1 ? text.length : endAt);
  return ALLOW_MARKERS.some((m) => line.includes(m));
}

const rstripS = (s: string) => s.replace(/s+$/, '');

function keep(rule: Rule, m: RegExpMatchArray, value: string): boolean {
  if (KNOWN_EXAMPLES.has(value) || value.includes('EXAMPLE') || isJwtSample(value)) return false;
  if (rule.id === 'framework_secret') {
    // A setting's value, not code that reads one: not a placeholder, an environment read, a reference or one repeated character.
    // (A generated Django key can hold "%(" or "%s" by chance, so those are not read as a format string here.)
    if (PLACEHOLDER.test(value.replace(/%[sd(]/g, '')) || FROM_CODE.test(value) || codeRef(value) || TYPE_NAME.test(value) || /^(.)\1+$/.test(value)) return false;
    // A file path is where a key is kept, not the key.
    if (/^(?:\/|~\/|\.{1,2}\/|[A-Za-z]:\\)/.test(value)) return false;
    // A function call (get_random_secret_key(), base64.b64decode(x)): a call has none of the symbols a generated Django key is full of.
    if (/^[A-Za-z_][\w.]{4,}\(/.test(value) && !/[!@#$%^&*+/~]/.test(value)) return false;
    // Only letters, digits, _ . - (a Rails hex key, a token): it must look random, not like a name (random_secret_generator_v2).
    if (/^[\w.-]+$/.test(value)) return !NAME_LIKE.test(value) && looksRandom(value);
    return /[^A-Za-z]/.test(value) && entropy(value) >= 3.0;
  }
  if (rule.generic) {
    const name = m[1] ?? '';
    if (ABOUT.test(rstripS(name)) || ABOUT.test(name)) return false;
    return looksRandom(value);
  }
  if (rule.id === 'db_password') {
    const user = m[1] ?? '';
    const host = m[3] ?? '';
    if (LOCAL_HOST.test(host) || value === user || DEV_PASSWORDS.has(value.toLowerCase())) return false;
    return !PLACEHOLDER.test(value) && !value.startsWith('$') && !value.startsWith('%');
  }
  if (rule.id === 'escanor_token') {
    const tail = value.replace(/^(?:escanor|esc_llm|escl|upt_src)_/, '');
    return /\d/.test(tail) || (/[a-z]/.test(tail) && /[A-Z]/.test(tail));
  }
  if (rule.id === 'razorpay_secret' || rule.id === 'aws_secret_key') return !PLACEHOLDER.test(value);
  return !/x{6,}|\*{3,}|<|>|\$\{/i.test(value);
}

function lineOf(text: string, offset: number): number {
  let n = 1;
  for (let i = text.indexOf('\n'); i !== -1 && i < offset; i = text.indexOf('\n', i + 1)) n++;
  return n;
}

/**
 * Every key in `text`, first to last, each value once per place. `includeSoft`: also the rules that never stop a push (a Google
 * browser key): what scrubbing hides. A file named *.example / *.sample is never scanned.
 */
export function scanText(text: string, path = '', o: { includeSoft?: boolean } = {}): Finding[] {
  if (!text || typeof text !== 'string') return [];
  if (path && EXAMPLE_FILE.test(path)) return [];
  const body = text.slice(0, MAX_SCAN_CHARS);
  const found: Finding[] = [];
  const taken: Array<[number, number]> = [];
  const sorted = () => found.sort((a, b) => a.line - b.line);
  for (const rule of RULES) {
    if (!rule.blocksPush && !o.includeSoft) continue;
    if (rule.id === 'gcp_service_account' && !body.includes('service_account')) continue;
    rule.pattern.lastIndex = 0;
    for (const m of body.matchAll(rule.pattern)) {
      const g = rule.generic ? 2 : rule.group;
      const value = m[g];
      const span = m.indices?.[g];
      if (value === undefined || !span) continue;
      const [start, end] = span;
      if (taken.some(([s, e]) => (s <= start && start < e) || (s < end && end <= e))) continue;
      if (!keep(rule, m, value) || allowedLine(body, start)) continue;
      taken.push([start, end]);
      found.push({ rule: rule.id, label: rule.label, path, line: lineOf(body, start), value, blocksPush: rule.blocksPush });
      if (found.length >= MAX_FINDINGS) return sorted();
    }
  }
  return sorted();
}

export function scanFiles(files: Iterable<[string, string]>): Finding[] {
  const out: Finding[] = [];
  for (const [path, content] of files) {
    out.push(...scanText(content, path));
    if (out.length >= MAX_FINDINGS) break;
  }
  return out.slice(0, MAX_FINDINGS);
}

function replaceFound(text: string, findings: Finding[]): string {
  let out = text;
  for (const f of [...findings].sort((a, b) => b.value.length - a.value.length)) out = out.split(f.value).join(`[hidden: ${f.label}]`);
  return out;
}

/** `text` with every key (soft ones too) replaced by `[hidden: <kind>]`. Code and prose around them stay as they are. */
export function scrub(text: string): string {
  if (!text || typeof text !== 'string') return text;
  const findings = scanText(text, '', { includeSoft: true });
  return findings.length ? replaceFound(text, findings) : text;
}

/** Keys that are a message's own bookkeeping, never words: left as they are by scrubDeep. */
export const FIXED_KEYS: ReadonlySet<string> = new Set([
  'id', 'type', 'role', 'name', 'media_type', 'tool_use_id', 'parent_tool_use_id', 'uuid', 'session_id', 'sessionId', 'tempId', 'mid',
  'requestId', 'inputId', 'vmId', 'toolName', 'model', 'cwd', 'accountId', 'source',
]);

/**
 * Every string inside a JSON-like value scrubbed (dict keys kept as they are, values under FIXED_KEYS left alone, a base64 photo or
 * document block left alone). Returns the scrubbed copy (the original when nothing was hidden) and what was found. Never changes
 * the value it is given.
 */
export function scrubDeep<T>(value: T, o: { fixed?: ReadonlySet<string> } = {}): { value: T; found: Finding[] } {
  const fixed = o.fixed ?? FIXED_KEYS;
  const found: Finding[] = [];
  const walk = (v: unknown, depth: number): unknown => {
    if (depth > 40) return v;
    if (typeof v === 'string') {
      const f = scanText(v, '', { includeSoft: true });
      if (!f.length) return v;
      found.push(...f);
      return replaceFound(v, f);
    }
    if (Array.isArray(v)) {
      let changed = false;
      const next = v.map((x) => {
        const y = walk(x, depth + 1);
        if (y !== x) changed = true;
        return y;
      });
      return changed ? next : v;
    }
    if (v && typeof v === 'object') {
      const obj = v as Record<string, unknown>;
      const src = obj.source as Record<string, unknown> | undefined;
      if ((obj.type === 'image' || obj.type === 'document') && src && typeof src === 'object' && src.type === 'base64') return v;
      let changed = false;
      const next: Record<string, unknown> = {};
      for (const [k, x] of Object.entries(obj)) {
        const y = fixed.has(k) ? x : walk(x, depth + 1);
        if (y !== x) changed = true;
        next[k] = y;
      }
      return changed ? next : v;
    }
    return v;
  };
  return { value: walk(value, 0) as T, found };
}

/** Why a push (or a pull request description, or a comment) was refused: where each key is, never the key itself. */
export function pushWords(findings: Finding[], what = 'push'): string {
  const shown = findings.slice(0, 10);
  const lines = shown.map((f) => `- ${where(f)}: ${f.label} (${mask(f.value, f.rule)})`).join('\n');
  const more = findings.length > shown.length ? `\n- and ${findings.length - shown.length} more` : '';
  return (
    `Escanor stopped this ${what} because it contains a key or password:\n${lines}${more}\n` +
    'Take the key out (read it from an environment setting or Escanor\'s vault instead), then try again. ' +
    `If it is not a real key (a sample in a test, say), put the comment ${ALLOW_MARKERS[0]} on that line and try again. ` +
    'If this key was ever pushed or shared before, make a new key at the provider and remove the old one.'
  );
}
