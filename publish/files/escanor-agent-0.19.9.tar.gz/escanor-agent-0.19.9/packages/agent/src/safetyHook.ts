// The machine-wide safety hook: a PreToolUse hook that Escanor puts in every Claude Code settings file on this computer
// (machineGuard.ts), so ANY Claude here (a terminal chat, `claude -p` from a timer, a script) goes through the same safety layer as
// Escanor's own chats: disasters are refused, deletes get a copy kept first, what no copy can undo waits for the person.
// Run by Claude Code with the call on stdin; prints its decision as JSON. Never run by the agent itself.
//
// It must never break a Claude: anything that goes wrong in here lets the call through (and is logged), except the checks that
// already decided to refuse.
import { readFileSync } from 'node:fs';
import { gate } from './safetyGate.ts';
import { whoRuns } from './safetyWho.ts';
import { logSafety } from './safetyLog.ts';
import { UndoStore } from './undo.ts';

const out = (decision: 'deny' | 'ask', reason: string): never => {
  process.stdout.write(JSON.stringify({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: decision, permissionDecisionReason: reason } }));
  return process.exit(0);
};

async function main() {
  const rootArg = process.argv.find((a) => a.startsWith('--root='))?.slice(7);
  // The daily safety snapshot (safetyRuntime.ts runs it in its own low-priority process).
  const snap = process.argv.indexOf('--snapshot');
  if (snap >= 0) {
    const store = new UndoStore(rootArg ? { root: rootArg } : {});
    store.prune();
    const e = store.snapshot(process.argv.slice(snap + 1).filter((a) => !a.startsWith('--')));
    if (e) logSafety(store.root, { at: e.at, action: 'backup', source: 'agent', command: 'Daily safety copy', undoId: e.id, paths: e.items.map((i) => i.path) });
    process.exit(0);
  }
  let input: { tool_name?: string; tool_input?: unknown; cwd?: string; session_id?: string; hook_event_name?: string };
  try {
    input = JSON.parse(readFileSync(0, 'utf8'));
  } catch {
    process.exit(0);
  }
  if (input.hook_event_name && input.hook_event_name !== 'PreToolUse') process.exit(0);
  const store = new UndoStore(rootArg ? { root: rootArg } : {});
  // The agent's own chats: the agent runs this as a child (so a long copy never stalls it) and decides holds itself.
  if (process.argv.includes('--agent-json')) {
    let res;
    try {
      res = gate(String(input.tool_name ?? ''), input.tool_input, { cwd: String(input.cwd ?? process.cwd()), store, source: 'agent', session: input.session_id });
    } catch (err) {
      res = { kind: 'hold', why: `Escanor could not check this command (${err instanceof Error ? err.message : String(err)}).` };
    }
    process.stdout.write(JSON.stringify(res));
    process.exit(0);
  }
  // There is no switch in the environment here (a Claude could start another with it set): the agent takes the hook out instead.
  const who = whoRuns(store.root);
  if (who.agentChat) process.exit(0); // the agent's own chats are checked inside the agent, not twice
  let r;
  try {
    r = gate(String(input.tool_name ?? ''), input.tool_input, { cwd: String(input.cwd ?? process.cwd()), store, source: 'machine', session: input.session_id });
  } catch (err) {
    logSafety(store.root, { at: Date.now(), action: 'guard', source: 'machine', why: `hook error: ${err instanceof Error ? err.message : String(err)}` });
    process.exit(0);
  }
  if (r.kind === 'run') process.exit(0);
  if (r.kind === 'deny') return out('deny', r.message);
  const command = r.verdict.command;
  if (who.headless) {
    logSafety(store.root, { at: Date.now(), action: 'hold', source: 'machine', command, why: `refused (no one to ask): ${r.why}`, cwd: input.cwd, session: input.session_id });
    out('deny', `Escanor stopped this command. ${r.why} This Claude runs with nobody watching (claude -p), so it cannot ask anyone; it never runs from here. Find a safer way, or leave it for the person.`);
  }
  logSafety(store.root, { at: Date.now(), action: 'hold', source: 'machine', command, why: `asked the person: ${r.why}`, cwd: input.cwd, session: input.session_id });
  out('ask', `Escanor: ${r.why}`);
}

void main();
