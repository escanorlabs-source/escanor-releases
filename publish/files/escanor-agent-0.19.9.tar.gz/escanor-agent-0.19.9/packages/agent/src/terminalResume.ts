import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { uptime } from 'node:os';
import type { AgentToHubMessage, HubUserInput } from '@remote-harness/shared';
import type { ClaudeProc } from './claudeProcs.js';
import { lastTurnEnded } from './turnState.js';
import {
  AUTO_RESUME_INPUT,
  continueText,
  errorBackoffMs,
  MAX_LIMIT_AGE_MS,
  MAX_OFFLINE_AGE_MS,
  maxTries,
  resumeNotice,
  tailState,
  waitNotice,
  type TailState,
} from './autoResume.js';

/**
 * AUTORESUME for chats open in a terminal on this computer (not run by the agent):
 *
 * - Claude's usage limit stopped one (its transcript ends with Claude Code's limit error): when the limit resets, "continue" is
 *   handed to that same terminal Claude through the phone inbox (terminalInbox.ts), so it goes on where it is, in the terminal.
 * - the AI service failed (server error, overloaded): tried again the same way 1, 5 and 15 minutes later, when online.
 * - the computer went off while one was busy (its process is gone after a reboot and its last turn never ended): the agent
 *   carries it on as one of its own chats (SessionManager.markOffline), visible in the apps, once connected.
 *
 * What was done is kept in a small file, so a restart of the agent never sends a second "continue" for the same stop. Never a
 * chat the person wrote to since; a terminal that cannot take messages from the agent (opened before the phone link) is left.
 */
type ChatState = {
  /** The transcript line (uuid) a "continue" was already sent for. */
  handled?: string;
  /** The stop the person was told about (once per incident). */
  told?: string;
  /** Continues sent since the chat last replied fine. */
  tries: number;
  /** When this run of stops began (ms). */
  since: number;
};

type Saved = {
  chats: Record<string, ChatState>;
  /** Last heartbeat: when, and the terminal chats busy then (for a computer that went off mid-turn). */
  alive?: { at: number; busy: { sessionId: string; cwd?: string }[] };
};

/** Held work goes out this long after Claude's limit resets (the reset is Claude's clock, not ours). */
const RESET_MARGIN_MS = 60_000;
/** A stop first seen more than this after it was due is not picked up. */
const STALE_MS = 6 * 3_600_000;

export class TerminalResume {
  private saved: Saved = { chats: {} };
  private lastSaved = '';
  private cache = new Map<string, { mtimeMs: number; state: TailState }>();
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private o: {
      /** Claude processes open on this machine, by session id. */
      procs: () => Map<string, ClaudeProc>;
      /** Chats this agent runs itself (SessionManager handles those). */
      isLive: (sessionId: string) => boolean;
      /** The chat's open terminal runs the inbox waiter (terminalInbox.canReach). */
      canReach: (sessionId: string) => boolean;
      /** Hands a message to that terminal (terminalInbox.deliver); false = it could not. */
      deliver: (input: HubUserInput) => boolean;
      /** The transcript's last lines and mtime (TurnState.tail). */
      tail: (sessionId: string, cwd: string | undefined) => { lines: string[]; mtimeMs: number } | null;
      isOnline: () => boolean;
      send: (msg: AgentToHubMessage) => void;
      /** A terminal chat cut off by the computer going away: the agent carries it on (SessionManager.markOffline). */
      markOffline: (sessionId: string) => boolean;
      file: string;
      now?: () => number;
      /** When this computer started (ms); injectable for tests. */
      bootTime?: number;
      pollMs?: number;
    },
  ) {
    this.load();
  }

  private now(): number {
    return this.o.now?.() ?? Date.now();
  }

  private get bootTime(): number {
    return this.o.bootTime ?? Date.now() - uptime() * 1000;
  }

  private load(): void {
    try {
      const raw = JSON.parse(readFileSync(this.o.file, 'utf8')) as Saved;
      if (raw && typeof raw === 'object' && raw.chats && typeof raw.chats === 'object') this.saved = { chats: raw.chats, ...(raw.alive ? { alive: raw.alive } : {}) };
    } catch {
      // first start, or unreadable: nothing was done yet
    }
    this.lastSaved = JSON.stringify(this.saved);
  }

  private save(): void {
    const json = JSON.stringify(this.saved);
    if (json === this.lastSaved) return;
    try {
      mkdirSync(dirname(this.o.file), { recursive: true });
      const tmp = `${this.o.file}.tmp`;
      writeFileSync(tmp, json, { mode: 0o600 });
      renameSync(tmp, this.o.file);
      this.lastSaved = json;
    } catch (err) {
      console.error(`Auto-resume: could not write ${this.o.file} (${err instanceof Error ? err.message : err})`);
    }
  }

  /**
   * Once, at agent start (before the first resume): terminal chats that were busy at the last heartbeat, when this computer has
   * started since (it was turned off or restarted), whose Claude is gone and whose last turn never ended, were cut off by it.
   */
  atStart(): string[] {
    const alive = this.saved.alive;
    const out: string[] = [];
    if (!alive || alive.at >= this.bootTime || this.now() - alive.at > MAX_OFFLINE_AGE_MS) return out;
    const procs = this.o.procs();
    for (const { sessionId, cwd } of alive.busy) {
      if (procs.has(sessionId)) continue; // opened again already
      const t = this.o.tail(sessionId, cwd);
      if (!t || lastTurnEnded(t.lines) !== false) continue;
      if (this.o.markOffline(sessionId)) out.push(sessionId);
    }
    return out;
  }

  start(): void {
    this.check();
    this.timer = setInterval(() => this.check(), this.o.pollMs ?? 30_000);
    this.timer.unref?.();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /** One look at every terminal chat open here. */
  check(): void {
    let procs: Map<string, ClaudeProc>;
    try {
      procs = this.o.procs();
    } catch {
      return;
    }
    const now = this.now();
    const busy: { sessionId: string; cwd?: string }[] = [];
    for (const [sessionId, p] of procs) {
      if (this.o.isLive(sessionId)) continue;
      const state = this.stateOf(sessionId, p.cwd, busy);
      if (state) this.consider(sessionId, state, now);
    }
    this.saved.alive = { at: now, busy };
    // Chats closed long ago are forgotten.
    for (const [id, c] of Object.entries(this.saved.chats)) if (!procs.has(id) && now - c.since > MAX_LIMIT_AGE_MS) delete this.saved.chats[id];
    this.save();
  }

  private stateOf(sessionId: string, cwd: string | undefined, busy: { sessionId: string; cwd?: string }[]): TailState | null {
    const t = this.o.tail(sessionId, cwd);
    if (!t) return null;
    if (lastTurnEnded(t.lines) === false) busy.push({ sessionId, ...(cwd ? { cwd } : {}) });
    const hit = this.cache.get(sessionId);
    if (hit && hit.mtimeMs === t.mtimeMs) return hit.state;
    const state = tailState(t.lines, this.now());
    this.cache.set(sessionId, { mtimeMs: t.mtimeMs, state });
    return state;
  }

  private dueOf(s: Extract<TailState, { state: 'cut' }>, tries: number): number {
    return s.reason === 'limit' ? (s.resetsAt ?? s.at) + RESET_MARGIN_MS : s.at + errorBackoffMs(tries);
  }

  private consider(sessionId: string, s: TailState, now: number): void {
    if (s.state === 'ok') {
      delete this.saved.chats[sessionId]; // it replied fine: a later stop is a new incident
      return;
    }
    if (s.state !== 'cut') return;
    // A stop seen for the first time long after it should have been picked up (it predates this agent, or the agent was off for
    // long): left as it is, so turning this on never wakes old chats.
    if (!this.saved.chats[sessionId] && now - this.dueOf(s, 0) > STALE_MS) return;
    const c = (this.saved.chats[sessionId] ??= { tries: 0, since: s.at });
    if (c.handled === s.uuid) return; // its "continue" is on its way
    const maxAge = s.reason === 'limit' ? MAX_LIMIT_AGE_MS : 24 * 3_600_000;
    if (c.tries >= maxTries(s.reason) || now - c.since > maxAge) return; // left for the person
    if (!this.o.canReach(sessionId)) return; // opened before the phone link: it cannot be handed a message
    const due = this.dueOf(s, c.tries);
    if (c.told === undefined) {
      c.told = s.uuid;
      this.o.send({ type: 'error', kind: 'notice', sessionId, message: waitNotice(s.reason, due) });
    }
    if (now < due || (s.reason === 'error' && !this.o.isOnline())) return;
    const input: HubUserInput = { type: 'user_input', sessionId, text: continueText(s.reason), inputId: `${AUTO_RESUME_INPUT}${s.reason}:${s.uuid}` };
    if (!this.o.deliver(input)) return;
    c.handled = s.uuid;
    c.tries++;
    console.log(`Auto-resume: told terminal chat ${sessionId} to continue (${s.reason}, try ${c.tries}).`);
    this.o.send({ type: 'error', kind: 'notice', sessionId, message: resumeNotice(s.reason) });
  }
}
