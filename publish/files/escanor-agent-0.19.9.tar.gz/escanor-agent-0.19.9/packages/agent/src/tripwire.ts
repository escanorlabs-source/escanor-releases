import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, readFileSync, statSync, watch, type FSWatcher } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { BUILD_DIRS } from '../../shared/src/risk.ts';

/**
 * The tripwire: the last line of the safety layer, for whatever slipped past every check (a script that deletes, a Claude started
 * with its own settings, a tool Escanor does not know). It watches the home folder and the folders a person keeps their life in;
 * when things there vanish fast (or a whole Desktop/Documents/.ssh folder goes) while an AI is running on this computer, every AI
 * process here is paused at once (with everything it started) and the person gets one notice: Resume or Stop.
 *
 * Linux and Mac pause (SIGSTOP / SIGCONT). Windows cannot pause another program from here: the person is told at once, and Stop
 * ends the AI programs.
 */

export type AiProc = { pid: number; parent: number; args: string };
export type TripInfo = { at: number; deleted: string[]; paused: number[]; reason: string };

/** Whole folders whose loss trips at once. */
const PRECIOUS = new Set(['Desktop', 'Documents', '.ssh', '.gnupg', 'Pictures', 'Downloads', '.config', 'Music', 'Videos', 'Movies']);
/** Folders watched deeper: where a person keeps their own files. Not app settings (~/.config): apps rewrite files there all day. */
const DEEP = new Set(['Desktop', 'Documents', 'Pictures', 'Downloads', 'Music', 'Videos', 'Movies', '.ssh', '.gnupg']);
/** Names that come and go by themselves: editor and browser temp files, logs, database journals, locks. */
const NOISE = /^(?:\.#|#)|~$|\.(?:tmp|swp|swx|lock|part|crdownload|temp|pma|ldb)$|^\.goutputstream|^\.~lock|^\.nfs|^\.com\.google\.|^\.org\.chromium\.|^LOG(?:\.old)?$|-(?:journal|wal|shm)$|^(?:Session|Tabs)_\d+$|^LOCK$|^CURRENT$|^MANIFEST-\d+$/i;
/** A name must have been there this long before its loss counts (a temp file written and renamed away is not a delete). */
const YOUNG_MS = 30_000;
const AI = /(?:^|[\\/ ])(?:claude|codex|gemini|copilot)(?:\.exe|\.js|\.mjs)?(?:\s|$)|@anthropic-ai[\\/]claude-code|@openai[\\/]codex|@google[\\/]gemini-cli|@github[\\/]copilot/;

/** The AI programs running as this user, and everything each one started (deepest first, so the delete itself stops first). */
export function aiProcessTrees(exclude: Set<number>, list: () => AiProc[] = listProcs): number[] {
  const procs = list();
  const kids = new Map<number, number[]>();
  for (const p of procs) kids.set(p.parent, [...(kids.get(p.parent) ?? []), p.pid]);
  const roots = procs.filter((p) => AI.test(p.args) && !exclude.has(p.pid));
  const out: number[] = [];
  const seen = new Set<number>();
  const walk = (pid: number) => {
    if (seen.has(pid) || exclude.has(pid)) return;
    seen.add(pid);
    for (const k of kids.get(pid) ?? []) walk(k);
    out.push(pid);
  };
  for (const r of roots) walk(r.pid);
  return out;
}

const DELETER = /^(?:\S*[\\/])?(?:rm|shred|srm|unlink|rmdir|rimraf)(?:\.exe)?\s|^(?:\S*[\\/])?find\s.*\s-(?:delete|exec)\b|^(?:\S*[\\/])?rsync\s.*--del/;
/** Delete commands running right now (rm, shred, find -delete, rsync --delete...). */
export function deleters(procs: AiProc[], exclude: Set<number>): number[] {
  return procs.filter((p) => !exclude.has(p.pid) && DELETER.test(p.args.trim())).map((p) => p.pid);
}

export function listProcs(): AiProc[] {
  const uid = typeof process.getuid === 'function' ? process.getuid() : -1;
  if (existsSync('/proc/self/stat')) {
    const out: AiProc[] = [];
    for (const n of readdirSync('/proc')) {
      if (!/^\d+$/.test(n)) continue;
      try {
        if (uid >= 0 && statSync(`/proc/${n}`).uid !== uid) continue;
        const stat = readFileSync(`/proc/${n}/stat`, 'utf8');
        const parent = Number(stat.slice(stat.lastIndexOf(')') + 2).split(' ')[1]);
        const args = readFileSync(`/proc/${n}/cmdline`, 'utf8').split('\0').join(' ');
        out.push({ pid: Number(n), parent, args });
      } catch {
        /* gone */
      }
    }
    return out;
  }
  try {
    if (process.platform === 'win32') {
      const text = execFileSync('powershell', ['-NoProfile', '-Command', 'Get-CimInstance Win32_Process | ForEach-Object { "$($_.ProcessId)`t$($_.ParentProcessId)`t$($_.CommandLine)" }'], { encoding: 'utf8', timeout: 15_000, windowsHide: true });
      return text.split(/\r?\n/).map((l) => l.split('\t')).filter((f) => f.length >= 3).map(([pid, parent, args]) => ({ pid: Number(pid), parent: Number(parent), args: args ?? '' }));
    }
    const text = execFileSync('ps', ['-axo', 'pid=,ppid=,uid=,args='], { encoding: 'utf8', timeout: 10_000 });
    return text.split('\n').map((l) => /^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/.exec(l)).filter((m): m is RegExpExecArray => !!m && (uid < 0 || Number(m[3]) === uid)).map((m) => ({ pid: Number(m[1]), parent: Number(m[2]), args: m[4] }));
  } catch {
    return [];
  }
}

export type TripwireOptions = {
  home?: string;
  /** Deletes within `windowMs` that trip it. */
  threshold?: number;
  windowMs?: number;
  /** Folders never counted (the undo store). */
  ignore?: string[];
  /** Paths the safety layer kept a copy of (or let go) in the last minute: their deletes are expected, not counted. */
  expected?: () => string[];
  onTrip: (t: TripInfo) => void;
  /** This agent and what runs it: never paused. */
  exclude?: Set<number>;
  procs?: () => AiProc[];
  signal?: (pid: number, sig: NodeJS.Signals) => void;
  now?: () => number;
};

export class Tripwire {
  private watchers: FSWatcher[] = [];
  private recent: Array<{ at: number; path: string }> = [];
  /** When each name in a watched folder was first seen (0: there when watching began). Only filled once start() listed them. */
  private born = new Map<string, number>();
  private listed = false;
  private tripped: TripInfo | null = null;
  private readonly home: string;
  private readonly threshold: number;
  private readonly windowMs: number;
  private readonly now: () => number;
  private readonly signal: (pid: number, sig: NodeJS.Signals) => void;

  constructor(private readonly o: TripwireOptions) {
    this.home = o.home ?? homedir();
    this.threshold = o.threshold ?? 40;
    this.windowMs = o.windowMs ?? 20_000;
    this.now = o.now ?? Date.now;
    this.signal = o.signal ?? ((pid, sig) => process.kill(pid, sig));
  }

  /**
   * The folders watched: the home folder, each folder in it, and the folders a person keeps their life in (Desktop, Documents,
   * Pictures, .ssh...) three levels down, so a delete that empties them from the bottom up is seen early. At most 3000 folders.
   */
  watchedDirs(): string[] {
    const dirs = [this.home];
    const deep = (d: string, levels: number) => {
      if (levels <= 0 || dirs.length > 3000) return;
      for (const s of sub(d)) {
        if (/[\\/]\.git$/.test(s)) continue;
        dirs.push(s);
        // Inside a project (a git repository) files come and go all day (branch switches, builds): only the project itself counts.
        if (existsSync(join(s, '.git'))) continue;
        deep(s, levels - 1);
      }
    };
    const sub = (d: string) => {
      try {
        return readdirSync(d, { withFileTypes: true }).filter((e) => e.isDirectory() && !BUILD_DIRS.has(e.name) && !/^\.(?:cache|npm|cargo|rustup|gradle|m2|pnpm-store|bun|yarn|nvm|local\/share\/Trash)$/.test(e.name)).map((e) => join(d, e.name));
      } catch {
        return [];
      }
    };
    for (const s of sub(this.home)) {
      dirs.push(s);
      const name = s.slice(this.home.length + 1);
      if (DEEP.has(name)) deep(s, 3);
    }
    const ignore = (this.o.ignore ?? []).map((p) => p.replace(/[\\/]+$/, ''));
    return dirs.filter((d) => !ignore.some((i) => d === i || d.startsWith(`${i}/`))).slice(0, 3000);
  }

  start(): void {
    this.listed = true;
    for (const d of this.watchedDirs()) {
      try {
        for (const n of readdirSync(d)) if (this.born.size < 200_000) this.born.set(join(d, n), 0);
      } catch {
        /* unreadable */
      }
      try {
        const w = watch(d, { persistent: false }, (event, name) => {
          if (event === 'rename' && name) this.seen(d, String(name));
        });
        w.on('error', () => w.close());
        this.watchers.push(w);
      } catch {
        /* cannot watch that one */
      }
    }
  }

  stop(): void {
    for (const w of this.watchers) w.close();
    this.watchers = [];
  }

  /** A name changed in a watched folder: counted when it is gone. Exposed for tests. */
  seen(dir: string, name: string): void {
    if (NOISE.test(name) || BUILD_DIRS.has(name)) return;
    const path = join(dir, name);
    const now = this.now();
    if (existsSync(path)) {
      if (this.listed && !this.born.has(path) && this.born.size < 200_000) this.born.set(path, now);
      return;
    }
    // Only what had been there a while counts: never seen (made and gone between two looks) or younger than 30 s is a temp file.
    const born = this.born.get(path);
    this.born.delete(path);
    if (this.listed && (born === undefined || (born > 0 && now - born < YOUNG_MS))) return;
    const expected = this.o.expected?.() ?? [];
    if (expected.some((e) => path === e || path.startsWith(`${e}/`) || path.startsWith(`${e}\\`))) return;
    const at = this.now();
    this.recent.push({ at, path });
    this.recent = this.recent.filter((r) => at - r.at <= this.windowMs);
    const precious = dir === this.home && PRECIOUS.has(name);
    if (precious || this.recent.length >= this.threshold) {
      this.trip(precious ? `Your ${name} folder was deleted.` : `${this.recent.length} files and folders in your home folder were deleted in ${Math.round(this.windowMs / 1000)} seconds.`);
    }
  }

  get state(): TripInfo | null {
    return this.tripped;
  }

  /** Pause every AI here, once per incident. Only while an AI runs: the person's own big clean-up never trips it. */
  trip(reason: string): TripInfo | null {
    if (this.tripped) return null;
    const exclude = this.o.exclude ?? new Set([process.pid]);
    const all = (this.o.procs ?? listProcs)();
    // Every AI and what it started, plus any delete still running on its own (`nohup rm -rf ~ &` outlives the Claude that started it).
    const pids = [...new Set([...deleters(all, exclude), ...aiProcessTrees(exclude, () => all)])];
    if (!pids.length) {
      this.recent = [];
      return null;
    }
    const paused: number[] = [];
    if (process.platform !== 'win32') {
      for (const pid of pids) {
        try {
          this.signal(pid, 'SIGSTOP');
          paused.push(pid);
        } catch {
          /* already gone */
        }
      }
    }
    this.tripped = { at: this.now(), deleted: this.recent.map((r) => r.path).slice(-30), paused: process.platform === 'win32' ? pids : paused, reason };
    this.recent = [];
    this.o.onTrip(this.tripped);
    return this.tripped;
  }

  /** The person said go on: everything paused carries on. */
  resume(): boolean {
    if (!this.tripped) return false;
    for (const pid of [...this.tripped.paused].reverse()) {
      try {
        this.signal(pid, 'SIGCONT');
      } catch {
        /* gone */
      }
    }
    this.tripped = null;
    return true;
  }

  /** The person said stop: the paused AI programs (and what they started) are ended. */
  end(): boolean {
    if (!this.tripped) return false;
    for (const pid of this.tripped.paused) {
      try {
        this.signal(pid, 'SIGKILL');
      } catch {
        /* gone */
      }
    }
    this.tripped = null;
    return true;
  }
}
