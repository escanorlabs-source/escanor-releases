import WebSocket from 'ws';
import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { AgentToHubMessage, HubToAgentMessage } from '@remote-harness/shared';
import { agentMessageUid } from '@remote-harness/shared/validate';
import { isForgedRow } from './trustedRows.js';
import { AGENT_ONLY_ROW_TYPES } from '@remote-harness/shared';

/** One outbox line: "<hex HMAC-SHA256 of the JSON>\t<JSON>". A line that does not verify was not written by this agent. */
export function signLine(key: string, json: string): string {
  return `${createHmac('sha256', key).update(json).digest('hex')}\t${json}`;
}

function verifyLine(key: string, line: string): string | null {
  const tab = line.indexOf('\t');
  if (tab !== 64) return null;
  const json = line.slice(tab + 1);
  const want = Buffer.from(createHmac('sha256', key).update(json).digest('hex'));
  const got = Buffer.from(line.slice(0, tab));
  return got.length === want.length && timingSafeEqual(got, want) ? json : null;
}

const DEFAULT_RECONNECT_DELAY_MS = 3000;
const DEFAULT_MAX_BUFFERED = 1000;
// A link that stayed up this long was healthy: the next wait starts small again. Shorter, it counts as a failed try.
// Twenty seconds, not sixty: the hub's front door (Render's proxy) cuts live links every 45 to 75 seconds for no reason on our
// side, and a link cut at 50 seconds used to count as a failed try, so the waits doubled (3, 6, 12 s ... 33 s seen) for a hub that was fine.
const HEALTHY_AFTER_MS = 20_000;
// After a link that was healthy is cut, the first new try comes this soon (the usual wait is for a hub that is down or refusing).
const QUICK_RETRY_MS = 500;
const RECONNECT_JITTER = 0.25;
// Cloudflare closes WebSockets that are idle for ~100s, so keep traffic flowing. Frequent enough that a dead socket is
// noticed quickly (each ping is also what confirms the messages before it arrived).
const DEFAULT_PING_INTERVAL_MS = 15_000;
// After sleep or a network change the old TCP socket is half-open: writes just queue and 'close' never fires,
// so the agent would stay "connected" to nothing. No pong within this window means the socket is dead.
const DEFAULT_PONG_TIMEOUT_MS = 40_000;

// Live text as it is being written: only worth anything right now, so never buffered or replayed.
// A queue command's answer (queue_result) is only for the request waiting for it right now.
// A preview link's answer (preview_http_*) is for a browser waiting now: never kept in the outbox or sent again.
// A local AI answer (local_ask_event): the running text, progress and notes are live only; the ones that decide the request
// (done, failed, pull_needed) are kept and sent again after a reconnect, so a request never just goes quiet.
const isEphemeral = (m: AgentToHubMessage) =>
  m.type === 'sdk_partial' ||
  m.type === 'cloud_ask' ||
  (m.type === 'local_ask_event' && m.event.kind !== 'done' && m.event.kind !== 'failed' && m.event.kind !== 'pull_needed') || m.type === 'queue_result' || m.type === 'account_result' || m.type === 'device_result' || m.type === 'device_ask' || m.type === 'device_ask_done' || m.type === 'screen_out' || m.type === 'screen_view' || m.type === 'screen_view_end' || m.type === 'subagent_steps_result' || m.type.startsWith('preview_http_');
const HANDSHAKE_TIMEOUT_MS = 15_000;
// What a chat or this machine is like right now: only the latest value matters, so it is never queued behind itself, never
// written to disk, and sent again by its producer after a reconnect (activity.ts, machineState.ts).
const stateKey = (m: AgentToHubMessage): string | null =>
  m.type === 'session_activity' ? `activity:${m.sessionId}` : m.type === 'machine_state' ? 'machine' : m.type === 'local_ai' ? 'localai' : m.type === 'queue_state' ? 'queue' : m.type === 'subagents' ? `subagents:${m.sessionId}` : null;
// The outbox file (DEV8): at most this many bytes; a single message bigger than a quarter of it stays in memory only.
const DEFAULT_MAX_BYTES = 2_000_000;
// Written at most this often while messages stream (and at once when the agent stops or a connection drops).
const DEFAULT_PERSIST_DEBOUNCE_MS = 2_000;

/** Why a hub connection is not up: the hub refused the token (401/403), nothing answered, it was closed, it went silent, or another agent took this machine's place. */
export type HubLinkReason = 'auth' | 'unreachable' | 'closed' | 'silent' | 'replaced' | 'removed' | 'other_agent';
export type HubLinkStatus = { connected: boolean; reason?: HubLinkReason; detail?: string };

export class HubConnection {
  private ws: WebSocket | null = null;
  private closedByUser = false;
  /** The hub said this computer was removed (4003): it asks again every removedRecheckMs, to rejoin after a Restore. */
  private removedRecheck = false;
  private removedRecheckMs = 5 * 60_000;
  private pingTimer: NodeJS.Timeout | null = null;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private buffer: AgentToHubMessage[] = [];
  // Written to the socket but not yet known to have arrived. A pong answers a ping sent after them, and the socket is
  // ordered, so a pong confirms everything sent before its ping. What a socket that died held unconfirmed is sent again
  // on the next connection (the hub ignores the copies it did get: sdk messages by uuid, prompts by requestId).
  private unconfirmed: { msg: AgentToHubMessage; seq: number }[] = [];
  private seq = 0;
  private pingSeqs: number[] = [];
  private reconnectDelayMs: number;
  private failedInARow = 0; // connection tries that never came up, or dropped within HEALTHY_AFTER_MS
  private maxBuffered: number;
  private pingIntervalMs: number;
  private pongTimeoutMs: number;
  private healthyAfterMs: number;
  private quickRetryMs: number;
  /** The link that just ended had been healthy: the next try is quick (see QUICK_RETRY_MS). */
  private quickRetry = false;
  /** Latest state per key (stateKey) produced while offline: sent after the queued events of the next connection. */
  private pendingState = new Map<string, AgentToHubMessage>();
  private outboxFile: string | null;
  private maxBytes: number;
  private persistDebounceMs: number;
  private persistTimer: NodeJS.Timeout | null = null;
  private onFlushed: (() => void) | null;
  private onConfirmed: ((mids: string[]) => void) | null;
  private outboxKey: string | null;
  private onStatus: ((s: HubLinkStatus) => void) | null;
  /** Why the last attempt or connection failed, for the status report (embedded mode shows it to the desktop). */
  private lastFailure: HubLinkReason | null = null;
  /** Connections in a row the hub refused the token for: the wait before the next try grows, so a refused machine does not knock every few seconds. */
  private authFailures = 0;
  /** Connections in a row the hub ended because another agent announced itself under this machine's name: the wait grows, so two agents never take each other's place every few seconds. */
  private replacedInARow = 0;

  constructor(
    private url: string,
    private token: string,
    private onMessage: (msg: HubToAgentMessage) => void,
    private onOpen: () => void,
    opts: {
      reconnectDelayMs?: number;
      removedRecheckMs?: number;
      maxBuffered?: number;
      pingIntervalMs?: number;
      pongTimeoutMs?: number;
      /** How long a link must have stayed up to count as healthy (HEALTHY_AFTER_MS), and how soon the first try after one is cut comes (QUICK_RETRY_MS). */
      healthyAfterMs?: number;
      quickRetryMs?: number;
      /** DEV8: keep what is not yet at the hub in this file (data/outbox.jsonl), so a restart loses nothing. */
      outboxFile?: string;
      maxBytes?: number;
      persistDebounceMs?: number;
      /** After the hello and everything queued went out on a new connection: producers of state send theirs again. */
      onFlushed?: () => void;
      /** Outbox ids the hub is now known to have (a pong after them). */
      onConfirmed?: (mids: string[]) => void;
      /** I2: the secret each outbox line is signed with (ESCANOR_OUTBOX_KEY). Without it nothing is written to or read from disk. */
      outboxKey?: string;
      /** Embedded mode: told when the link comes up and when it goes down (and why: a refused token is told apart from no network). */
      onStatus?: (s: HubLinkStatus) => void;
    } = {},
  ) {
    this.reconnectDelayMs = opts.reconnectDelayMs ?? DEFAULT_RECONNECT_DELAY_MS;
    if (opts.removedRecheckMs !== undefined) this.removedRecheckMs = opts.removedRecheckMs;
    this.maxBuffered = opts.maxBuffered ?? DEFAULT_MAX_BUFFERED;
    this.pingIntervalMs = opts.pingIntervalMs ?? DEFAULT_PING_INTERVAL_MS;
    this.pongTimeoutMs = opts.pongTimeoutMs ?? DEFAULT_PONG_TIMEOUT_MS;
    this.healthyAfterMs = opts.healthyAfterMs ?? HEALTHY_AFTER_MS;
    this.quickRetryMs = opts.quickRetryMs ?? QUICK_RETRY_MS;
    this.outboxFile = opts.outboxFile ?? null;
    this.maxBytes = opts.maxBytes ?? DEFAULT_MAX_BYTES;
    this.persistDebounceMs = opts.persistDebounceMs ?? DEFAULT_PERSIST_DEBOUNCE_MS;
    this.onFlushed = opts.onFlushed ?? null;
    this.onConfirmed = opts.onConfirmed ?? null;
    this.onStatus = opts.onStatus ?? null;
    this.outboxKey = opts.outboxKey && opts.outboxKey.length >= 32 ? opts.outboxKey : null;
    if (this.outboxFile && !this.outboxKey) {
      console.warn('No outbox key (ESCANOR_OUTBOX_KEY): unsent messages are kept in memory only.');
      this.outboxFile = null;
    }
    this.buffer = this.loadOutbox();
  }

  /** A new token (the old one was refused or rotated): used from the next connection on; the one open now keeps running. */
  setToken(token: string): void {
    this.token = token;
  }

  private status(s: HubLinkStatus): void {
    try {
      this.onStatus?.(s);
    } catch (err) {
      console.error('Status listener failed', err);
    }
  }

  /**
   * The wait before the next try. The usual delay when the link was fine, doubling (3 s, 6 s, ... up to 5 minutes) while the hub keeps
   * refusing the token, the machine keeps being replaced, or the hub cannot be reached or keeps dropping the link at once. Each wait
   * is spread by up to 25% either way, so many machines never knock in step. A hub that is down used to be asked every 3 seconds
   * by every machine, which can use up a free hub's daily allowance by itself.
   */
  private nextDelayMs(jitter = false): number {
    const cap = Math.max(this.reconnectDelayMs, 5 * 60_000);
    const doubled = (n: number) => Math.min(this.reconnectDelayMs * 2 ** Math.min(n, 7), cap);
    let wait = this.reconnectDelayMs;
    if (this.replacedInARow > 0) wait = doubled(this.replacedInARow);
    else if (this.authFailures > 1) wait = doubled(this.authFailures - 1);
    else if (this.failedInARow > 0) wait = doubled(this.failedInARow - 1);
    else if (this.quickRetry) wait = Math.min(wait, this.quickRetryMs);
    return jitter ? Math.round(wait * (1 + (Math.random() * 2 - 1) * RECONNECT_JITTER)) : wait;
  }

  /** For tests: the wait that would come next. */
  get retryDelayMs(): number {
    return this.nextDelayMs();
  }

  connect(): void {
    this.closedByUser = false;
    this.lastFailure = null; // each attempt reports its own reason
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    const ws = new WebSocket(this.url, {
      headers: { authorization: `Bearer ${this.token}` },
      handshakeTimeout: HANDSHAKE_TIMEOUT_MS,
    });
    this.ws = ws;
    let lastHeard = Date.now();
    let openedAt = 0;
    const heard = () => { lastHeard = Date.now(); };
    ws.on('pong', () => {
      heard();
      if (this.ws !== ws) return;
      const upTo = this.pingSeqs.shift();
      if (upTo !== undefined) {
        const done = this.unconfirmed.filter((u) => u.seq <= upTo);
        this.unconfirmed = this.unconfirmed.filter((u) => u.seq > upTo);
        if (done.length) {
          this.schedulePersist();
          try {
            this.onConfirmed?.(done.map((u) => u.msg.mid).filter((m): m is string => typeof m === 'string'));
          } catch (err) {
            console.error('Confirm listener failed', err);
          }
        }
      }
    });

    ws.on('open', () => {
      heard();
      openedAt = Date.now();
      this.lastFailure = null;
      this.authFailures = 0;
      const timer = (this.pingTimer = setInterval(() => {
        if (ws.readyState !== WebSocket.OPEN) return;
        if (Date.now() - lastHeard > this.pongTimeoutMs) {
          console.error(`Hub connection silent for ${Math.round((Date.now() - lastHeard) / 1000)}s, reconnecting`);
          this.lastFailure = 'silent';
          ws.terminate(); // emits 'close', which schedules the reconnect
          return;
        }
        this.pingSeqs.push(this.seq);
        ws.ping();
        // A heartbeat the hosted hub answers itself ("pong") and timestamps: it tells a live connection from a half-open one,
        // so a second agent is refused only while this one is really alive (hosted-hub machines.js).
        ws.send('ping');
      }, this.pingIntervalMs));
      ws.once('close', () => clearInterval(timer));
      this.onOpen(); // sends the hello first, so the hub knows who we are before the replay
      this.flush();
      this.status({ connected: true });
      try {
        this.onFlushed?.();
      } catch (err) {
        console.error('Reconnect listener failed', err);
      }
    });
    ws.on('message', (data) => {
      heard();
      if (data.toString() === 'pong') return; // the hub's answer to the heartbeat
      try {
        const msg = JSON.parse(data.toString()) as HubToAgentMessage;
        // The hub says this computer was restored to the workspace: connect again now, not at the next removed-recheck.
        if (msg?.type === 'restored') return void setImmediate(() => this.restored());
        this.onMessage(msg);
      } catch (err) {
        console.error('Failed to parse hub message', err);
      }
    });
    ws.on('close', (code: number, reasonBuf: Buffer) => {
      if (this.ws !== ws) return; // replaced by reconnectNow(): the new socket owns the reconnecting
      this.pingTimer = null;
      if (openedAt) {
        // Say why and how long it was up (the hub names its reason, e.g. "replaced by newer connection"): a link that keeps
        // dropping used to leave nothing in the log but the next "Connected".
        const upSeconds = Math.round((Date.now() - openedAt) / 1000);
        const why = reasonBuf?.toString().replace(/[^\x20-\x7e]/g, '').slice(0, 100) ?? '';
        // The owner removed this computer from the workspace (4003), or another agent on this same computer serves it (4004): not
        // reconnecting is the point, until the agent is started again or set up again.
        if (code === 4003 || code === 4004) {
          this.lastFailure = code === 4003 ? 'removed' : 'other_agent';
          // Removed: not an active link (the status says so), but the hub is asked again now and then, so a Restore in any app brings
          // this computer back and its chats with it, with nobody setting it up by hand. Another agent serving it: stays off.
          this.closedByUser = code === 4004;
          this.removedRecheck = code === 4003;
          console.log(code === 4003 ? 'This computer was removed from the workspace. It stays off until it is restored or set up again.' : 'Another Escanor agent on this computer serves it; this one stays off.');
        }
        const replaced = code === 1000 && /replaced by newer connection/i.test(why);
        console.log(`Hub connection closed after ${upSeconds}s (code ${code}${why ? `, "${why}"` : ''}).${replaced ? ' Another agent connected under this machine\'s name (check for a second copy running with the same name).' : ''}`);
        if (replaced) {
          this.lastFailure = 'replaced';
          this.replacedInARow++;
        } else if (upSeconds >= 180) this.replacedInARow = 0; // it stayed up: the clash is over
      }
      {
        // Whatever this socket never confirmed may be lost: it goes out again, ahead of what was queued since.
        this.buffer = [...this.unconfirmed.map((u) => u.msg).filter((m) => m.type !== 'hello'), ...this.buffer].slice(-this.maxBuffered);
        this.unconfirmed = [];
        this.pingSeqs = [];
        this.schedulePersist();
      }
      this.authFailures = this.lastFailure === 'auth' ? this.authFailures + 1 : 0;
      const healthy = openedAt > 0 && Date.now() - openedAt >= this.healthyAfterMs;
      if (healthy) this.failedInARow = 0;
      else if (this.lastFailure !== 'auth' && this.lastFailure !== 'replaced') this.failedInARow++; // (those two have their own doubling)
      this.quickRetry = healthy && this.lastFailure !== 'auth' && this.lastFailure !== 'replaced';
      if (!this.closedByUser) this.reconnectTimer = setTimeout(() => this.connect(), this.removedRecheck ? this.removedRecheckMs : this.nextDelayMs(true));
      if (this.lastFailure !== 'removed') this.removedRecheck = false;
      this.status({ connected: false, reason: this.lastFailure ?? 'closed' });
    });
    ws.on('error', (err) => {
      console.error('Hub connection error', err.message);
      if (this.ws !== ws) return; // a socket that was replaced does not speak for the new one
      // The hub answers a refused token with a plain 401/403 instead of upgrading the socket.
      const refused = /Unexpected server response: (401|403)\b/.exec(err.message);
      this.lastFailure = refused ? 'auth' : this.lastFailure ?? 'unreachable';
    });
  }

  // Messages produced while the hub is unreachable (a permission request, session_created, session_ended,
  // streamed output) are kept and replayed after reconnect instead of being dropped. The buffer is
  // bounded; when full it sheds streamed sdk_messages first because the critical events can't be re-derived.
  //
  // Every kept message carries an outbox id (`mid`), the same on each copy, so a hub drops a second copy; a message already
  // waiting here (same id, same prompt, same SDK message) is not queued twice. FLOW3: an agent-only row (escanor_tests) that the
  // agent did not make itself is refused here, the one door to the hub.
  /** The socket to the hub is open now (AUTORESUME: a chat cut off by going offline goes on only once it is). */
  get connected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  /**
   * A live picture (remote desktop): sent now or not at all, never kept or sent again. False when the link is not open or already
   * holds more than `maxBacklog` bytes unsent (a slow link): the picture is dropped and the next one goes when there is room.
   */
  sendBinary(data: Buffer, maxBacklog = 1_000_000): boolean {
    const ws = this.ws;
    if (!ws || ws.readyState !== WebSocket.OPEN || ws.bufferedAmount > maxBacklog) return false;
    try {
      ws.send(data, { binary: true });
      return true;
    } catch {
      return false;
    }
  }

  send(msg: AgentToHubMessage): void {
    if (isForgedRow(msg)) {
      console.warn('Refused to send an escanor_tests row the agent did not make itself.');
      return;
    }
    const open = this.ws?.readyState === WebSocket.OPEN;
    if (isEphemeral(msg) || msg.type === 'hello') {
      if (open) this.ws!.send(JSON.stringify(msg));
      return;
    }
    const key = stateKey(msg);
    if (key) {
      if (open) this.ws!.send(JSON.stringify(msg));
      else this.pendingState.set(key, msg);
      return;
    }
    this.push(msg.mid ? msg : { ...msg, mid: randomUUID() });
  }

  /** Queue or send a kept message (already given its outbox id). */
  private push(msg: AgentToHubMessage): void {
    if (this.holds(msg)) return;
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(msg));
      this.unconfirmed.push({ msg, seq: ++this.seq });
      if (this.unconfirmed.length > this.maxBuffered) this.unconfirmed.shift();
      this.schedulePersist();
      return;
    }
    if (this.buffer.length >= this.maxBuffered) {
      const i = this.buffer.findIndex((m) => m.type === 'sdk_message');
      this.buffer.splice(i === -1 ? 0 : i, 1);
    }
    this.buffer.push(msg);
    this.schedulePersist();
  }

  /** Is a copy of this message already waiting to go, or gone but unconfirmed? */
  private holds(msg: AgentToHubMessage): boolean {
    const keys = new Set([agentMessageUid(msg), msg.mid ? `mid:${msg.mid}` : undefined].filter((k): k is string => k !== undefined));
    if (keys.size === 0) return false;
    const same = (m: AgentToHubMessage) => {
      const uid = agentMessageUid(m);
      return (uid !== undefined && keys.has(uid)) || (m.mid !== undefined && keys.has(`mid:${m.mid}`));
    };
    return this.buffer.some(same) || this.unconfirmed.some((u) => same(u.msg));
  }

  // ---------- the outbox file (DEV8) ----------

  /**
   * What the last run left unsent, oldest first. Not taken back: a permission prompt (the chat that asked it died with the old
   * process; the hello's pending list says what still waits) and anything unreadable (set aside, never a crash).
   */
  private loadOutbox(): AgentToHubMessage[] {
    const f = this.outboxFile;
    if (!f || !existsSync(f)) return [];
    let raw = '';
    try {
      raw = readFileSync(f, 'utf8');
    } catch (err) {
      console.error(`Could not read the outbox (${err instanceof Error ? err.message : err}); starting with an empty one.`);
      return [];
    }
    const out: AgentToHubMessage[] = [];
    let bad = 0;
    for (const line of raw.split('\n')) {
      if (!line.trim()) continue;
      const json = verifyLine(this.outboxKey!, line);
      if (json === null) {
        bad++;
        continue;
      }
      let m: AgentToHubMessage;
      try {
        m = JSON.parse(json);
      } catch {
        bad++;
        continue;
      }
      if (typeof m !== 'object' || m === null || typeof m.type !== 'string' || typeof m.mid !== 'string') {
        bad++;
        continue;
      }
      if (m.type === 'hello' || m.type === 'permission_request' || isEphemeral(m) || stateKey(m)) continue;
      // I2: an agent-only row (escanor_tests) is never taken back from disk, signed or not: its seal is in memory only, so the
      // fix that made it is tested again instead (fixTests.ts keeps it in 'testing' until the hub confirmed the row).
      const inner = m.type === 'sdk_message' ? (m.message as { type?: unknown } | null)?.type : undefined;
      if (typeof inner === 'string' && AGENT_ONLY_ROW_TYPES.has(inner)) continue;
      if (out.some((o) => o.mid === m.mid)) continue;
      out.push(m);
    }
    if (bad > 0) {
      const aside = `${f}.corrupt-${Date.now()}`;
      try {
        writeFileSync(aside, raw, { mode: 0o600 });
        console.error(`The outbox had ${bad} unreadable or unsigned line(s), dropped; a copy was kept as ${aside}.`);
      } catch {
        // the readable messages still go out
      }
    }
    if (out.length > 0) console.log(`Outbox: ${out.length} message(s) from before the restart will be sent once connected.`);
    return out.slice(-this.maxBuffered);
  }

  private schedulePersist(): void {
    if (!this.outboxFile || this.persistTimer) return;
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      this.persistNow();
    }, this.persistDebounceMs);
    this.persistTimer.unref();
  }

  /** Write what is not yet confirmed (in the order it would be sent again) to the file: atomic, owner-only, capped. */
  persistNow(): void {
    const f = this.outboxFile;
    if (!f) return;
    if (this.persistTimer) clearTimeout(this.persistTimer);
    this.persistTimer = null;
    const msgs = [...this.unconfirmed.map((u) => u.msg), ...this.buffer].filter((m) => m.type !== 'hello');
    let lines = msgs.map((m) => signLine(this.outboxKey!, JSON.stringify(m))).filter((l) => l.length + 1 <= this.maxBytes / 4);
    let size = lines.reduce((n, l) => n + l.length + 1, 0);
    while (size > this.maxBytes && lines.length > 0) {
      // Streamed output goes first, oldest first; the events the phone cannot work out again go last.
      let i = lines.findIndex((l) => l.slice(65).startsWith('{"type":"sdk_message"'));
      if (i === -1) i = 0;
      size -= lines[i].length + 1;
      lines = [...lines.slice(0, i), ...lines.slice(i + 1)];
    }
    try {
      mkdirSync(dirname(f), { recursive: true, mode: 0o700 });
      const tmp = `${f}.tmp`;
      writeFileSync(tmp, lines.length ? `${lines.join('\n')}\n` : '', { mode: 0o600 });
      renameSync(tmp, f);
    } catch (err) {
      console.error(`Could not write the outbox (${err instanceof Error ? err.message : err}).`);
    }
  }

  /**
   * The machine just woke from sleep: whatever the old socket is (usually half-open, still looking connected) is not
   * trusted. Drop it and connect now instead of waiting for a pong deadline or the retry delay. What the old socket never
   * confirmed is sent again after the hello, like after any reconnect.
   */
  /** The hub said `{type:"restored"}`: this computer is back in the workspace, so it stops waiting out the removed-recheck and connects at once. */
  restored(): void {
    if (this.closedByUser) return;
    console.log('This computer was restored to the workspace: connecting again now.');
    this.removedRecheck = false;
    if (this.lastFailure === 'removed') this.lastFailure = null;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    this.failedInARow = 0;
    this.reconnectNow();
  }

  reconnectNow(): void {
    if (this.closedByUser) return;
    const old = this.ws;
    if (old && old.readyState !== WebSocket.CLOSED) {
      this.buffer = [...this.unconfirmed.map((u) => u.msg).filter((m) => m.type !== 'hello'), ...this.buffer].slice(-this.maxBuffered);
      this.unconfirmed = [];
      this.pingSeqs = [];
      this.schedulePersist();
      if (this.pingTimer) clearInterval(this.pingTimer);
      this.pingTimer = null;
      this.ws = null;
      try {
        old.terminate();
      } catch {
        // already gone
      }
    }
    this.connect();
  }

  private flush(): void {
    const pending = this.buffer;
    this.buffer = [];
    for (const m of pending) {
      // Checked again: a row kept in memory still carries its seal; one from anywhere else (the file) never does.
      if (isForgedRow(m)) console.warn('Dropped an escanor_tests row without the agent\'s seal from the outbox.');
      else this.push(m);
    }
    const state = [...this.pendingState.values()];
    this.pendingState.clear();
    for (const m of state) this.send(m);
  }

  bufferedForTest(): AgentToHubMessage[] {
    return [...this.buffer];
  }

  unconfirmedForTest(): AgentToHubMessage[] {
    return this.unconfirmed.map((u) => u.msg);
  }

  close(): void {
    this.closedByUser = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    this.persistNow(); // the agent is stopping: what is not at the hub yet is on disk now
    this.ws?.close();
  }
}
