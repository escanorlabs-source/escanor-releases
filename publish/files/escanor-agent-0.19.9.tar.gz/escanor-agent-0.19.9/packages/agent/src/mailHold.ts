import { RISK_WHY, type Risk } from '../../shared/src/risk.ts';
import { parseMcpToolName } from './mcpApproval.js';

/**
 * JARVIS1: sending an email (or a reply, or a forward) in the person's name always waits for their yes on the phone, unless the
 * chat is Autonomous. It goes through their connected mail (Gmail through Google Workspace, Outlook through Microsoft Graph, via
 * Escanor MCP's escanor_invoke, or a mail MCP server of their own); it is never done by clicking Send in a browser
 * (computerControl.ts only opens a filled-in email for them to send).
 *
 * Read by the chat's PreToolUse hook (sessionManager.ts) in every mode except Autonomous, whatever ESCANOR_RISK_HOLDS says: an email
 * cannot be taken back once it has left. The hold card says who it goes to and what it is about, in plain words.
 */

/** Providers whose send is mail in the person's own name (not a product's transactional mail such as SendGrid or SES). */
const MAIL_PROVIDERS = /^(google_workspace|gmail|google-mail|msgraph|outlook|microsoft|zoho[-_]?mail)$/i;
/** Chat services whose send is a message in the person's own name. */
const CHAT_PROVIDERS = /^(slack|telegram|whatsapp[-_]?business|whatsapp)$/i;
/** A mail or chat MCP server of the person's own, named for it. */
const MAIL_SERVER = /(gmail|outlook|mail|slack|telegram|whatsapp)/i;

/** Jarvis phase 3: the header Escanor's MCP server hears the chat's mode in (set by the agent from the session, never by the AI). */
export const AUTONOMY_HEADER = 'X-Escanor-Autonomy';
export const AUTONOMY_HEADER_SERVER = 'escanor';

/** Is this operation's name a send (send, send_mail, drafts_send, reply, reply_all, forward), and not "send_as" settings? */
export function isSendOperation(op: string): boolean {
  const words = op
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    if (w === 'send' && words[i + 1] !== 'as') return true;
    if (w === 'sendmail' || w === 'reply' || w === 'replyall' || w === 'forward' || w === 'postmessage') return true;
    // Slack: chat_post_message, chat_post_ephemeral, chat_schedule_message
    if (w === 'post' && (words[i + 1] === 'message' || words[i + 1] === 'ephemeral')) return true;
    if (w === 'schedule' && words[i + 1] === 'message') return true;
  }
  return false;
}

function str(v: unknown): string {
  return typeof v === 'string' ? v : '';
}

/** Gmail's `raw` is the whole message, base64url: the To and Subject lines are read from it for the card. */
function rawHeaders(raw: string): { to: string; subject: string } {
  try {
    const text = Buffer.from(raw.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8').slice(0, 20_000);
    const head = text.split(/\r?\n\r?\n/)[0];
    return { to: /^To:\s*(.+)$/im.exec(head)?.[1]?.trim() ?? '', subject: /^Subject:\s*(.+)$/im.exec(head)?.[1]?.trim() ?? '' };
  } catch {
    return { to: '', subject: '' };
  }
}

/** Who the email goes to and what it is about, from the shapes Gmail, Graph and plain mail tools use. Best effort. */
export function mailSummary(args: Record<string, unknown>): { to: string; subject: string } {
  const body = (args.body && typeof args.body === 'object' ? args.body : args) as Record<string, unknown>;
  const message = (body.message && typeof body.message === 'object' ? body.message : body) as Record<string, unknown>;
  const raw = str(message.raw) || str((body as { raw?: unknown }).raw);
  if (raw) {
    const h = rawHeaders(raw);
    if (h.to || h.subject) return h;
  }
  const recips = message.toRecipients;
  const to = Array.isArray(recips)
    ? recips.map((r) => str((r as { emailAddress?: { address?: unknown } })?.emailAddress?.address)).filter(Boolean).join(', ')
    : Array.isArray(message.to)
      ? (message.to as unknown[]).map(str).filter(Boolean).join(', ')
      : str(message.to) || str(message.recipient);
  return { to, subject: str(message.subject) };
}

/** Who a chat message goes to and what it says, from the shapes Slack, Telegram and WhatsApp Business use. Best effort. */
export function chatSummary(args: Record<string, unknown>): { to: string; text: string } {
  const text = args.text;
  return {
    to: str(args.channel) || str(args.channel_id) || (args.chat_id !== undefined ? String(args.chat_id) : '') || str(args.to),
    text: typeof text === 'string' ? text : str((text as { body?: unknown } | undefined)?.body) || str(args.body),
  };
}

function providerOf(toolName: string, input: unknown): { provider: string; op: string; args: Record<string, unknown>; viaEscanor: boolean } | null {
  const parsed = parseMcpToolName(toolName);
  if (!parsed) return null;
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  if (parsed.tool === 'escanor_invoke') {
    const id = str(i.tool_id);
    const dot = id.indexOf('.');
    if (dot <= 0) return null;
    return { provider: id.slice(0, dot), op: id.slice(dot + 1), args: (i.arguments && typeof i.arguments === 'object' ? i.arguments : {}) as Record<string, unknown>, viaEscanor: true };
  }
  return { provider: parsed.server, op: parsed.tool, args: i, viaEscanor: false };
}

/**
 * Autonomous chats send through escanor_message_send (it tells the person after each send and keeps Undo while the service allows it),
 * so a raw Gmail, Outlook or Slack send through Escanor is turned away with that pointer. Null for anything else.
 */
export function autonomousRedirect(toolName: string, input: unknown): string | null {
  const p = providerOf(toolName, input);
  if (!p || !p.viaEscanor || !(MAIL_PROVIDERS.test(p.provider) || CHAT_PROVIDERS.test(p.provider)) || !isSendOperation(p.op)) return null;
  return (
    'Use escanor_message_send for this, not the provider tool: it sends for the person at once in Autonomous mode, tells them after each send ' +
    'and keeps an Undo where the service allows one. Give it the channel (gmail, outlook, slack, telegram or whatsapp), who it goes to, ' +
    'the subject for mail and the words to send.'
  );
}

/** The line an Autonomous chat shows for a send that goes out on the person's own mail or chat server (not through Escanor). */
export function sendingNotice(toolName: string, input: unknown): string | null {
  const p = providerOf(toolName, input);
  if (!p || p.viaEscanor || !MAIL_SERVER.test(p.provider) || !isSendOperation(p.op)) return null;
  const chat = /slack|telegram|whatsapp/i.test(p.provider);
  const s = chat ? chatSummary(p.args) : mailSummary(p.args);
  const to = s.to ? ` to ${s.to.slice(0, 120)}` : '';
  const what = chat ? `: "${(s as { text: string }).text.slice(0, 80)}"` : (s as { subject: string }).subject ? ` about "${(s as { subject: string }).subject.slice(0, 80)}"` : '';
  return `Sending for you (Autonomous)${to}${what}`;
}

/** Why this tool call must wait (an email or message sent in the person's name), or null for anything else. */
export function mailSendRisk(toolName: string, input: unknown): Risk | null {
  const parsed = parseMcpToolName(toolName);
  if (!parsed) return null;
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  let args: Record<string, unknown> = i;
  let provider = '';
  if (parsed.tool === 'escanor_invoke') {
    const id = str(i.tool_id);
    const dot = id.indexOf('.');
    if (dot <= 0) return null;
    provider = id.slice(0, dot);
    if (!(MAIL_PROVIDERS.test(provider) || CHAT_PROVIDERS.test(provider)) || !isSendOperation(id.slice(dot + 1))) return null;
    args = (i.arguments && typeof i.arguments === 'object' ? i.arguments : {}) as Record<string, unknown>;
  } else {
    if (!MAIL_SERVER.test(parsed.server) || !isSendOperation(parsed.tool)) return null;
    provider = parsed.server;
  }
  if (CHAT_PROVIDERS.test(provider) || /slack|telegram|whatsapp/i.test(provider)) {
    const c = chatSummary(args);
    const name = /slack/i.test(provider) ? 'Slack' : /telegram/i.test(provider) ? 'Telegram' : 'WhatsApp';
    const line = [c.to ? `to ${c.to.slice(0, 200)}` : '', c.text ? `saying "${c.text.replace(/\s+/g, ' ').slice(0, 120)}"` : ''].filter(Boolean).join(', ');
    return { kind: 'send-message', why: `${RISK_WHY['send-message']} (${name}${line ? `, ${line}` : ''})` };
  }
  const s = mailSummary(args);
  const where = /google|gmail/i.test(provider) ? 'Gmail' : /msgraph|outlook|microsoft/i.test(provider) ? 'Outlook' : 'your mail';
  const said = [s.to ? `to ${s.to.slice(0, 200)}` : '', s.subject ? `about "${s.subject.slice(0, 120)}"` : ''].filter(Boolean).join(', ');
  return { kind: 'send-message', why: `${RISK_WHY['send-message']} (${where}${said ? `, ${said}` : ''})` };
}

/** The phone's Autonomous (mobile autonomy.dart isAutonomousMode): 'auto' or 'bypassPermissions', asked for or running. */
export function isAutonomous(s: { requested?: string; mode?: string } | undefined): boolean {
  return s?.requested === 'auto' || s?.requested === 'bypassPermissions' || s?.mode === 'bypassPermissions';
}
