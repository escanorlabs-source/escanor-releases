import { spawn } from 'node:child_process';
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { createConnection, createServer, type Server } from 'node:net';
import { dirname } from 'node:path';
import { desktopEnv } from './computerControl.js';

/**
 * Jarvis phase 4, screen-aware help ("what's on my screen", "where do I click to ...", "fill this form").
 *
 * How it goes, in order:
 *  1. A picture of the screen is taken ONLY because the person asked (a chat's tool call), once, in memory. GNOME's own screen-cast
 *     service gives it with no pop-up (screenControl.takeScreenshot); the picture is never written anywhere that outlives the call.
 *  2. The picture goes to Escanor's server with the question (POST /agent/screen/ask, screen_help.py in the backend). The cheapest
 *     model that can look at a picture answers in plain words and says where on the picture to point. The agent never holds a
 *     model key, and the chat's own model never sees the picture (so it is not kept in the chat's history either).
 *  3. The target is highlighted on the real screen first (a short, click-through overlay), then the answer is given.
 *  4. Clicking or typing is a separate tool (screen_do). It only works where the highlight pointed (a box from the last look), is held
 *     for the person's yes in plain words in every mode but Autonomous (sessionManager.ts), and in Autonomous only inside the one
 *     app the person named. It never types into a password, card or code field.
 *  5. Nothing is stored: the picture is gone when the call ends; only a short text note (what kind of screen it was) is kept, at most
 *     the last NOTES_KEPT, in an owner-only file.
 *
 * The chat's MCP server (computerMcp.ts) runs as the chat's child process and must not hold the hub token, so the question goes to
 * the agent itself over an owner-only Unix socket (a request: one JSON line; the answer: one JSON line).
 */

export const SCREEN_HELP_DIR_ENV = 'ESCANOR_SCREEN_HELP_DIR';
export const SOCKET_NAME = 'screen-help.sock';
export const CONSENT_NAME = 'screen-help-consent.json';
export const NOTES_NAME = 'screen-help-notes.json';
export const NOTES_KEPT = 20;
export const HIGHLIGHT_NAME = 'screen-help-highlight.json';
export const HIGHLIGHT_MS = 15_000;
export const LOOK_FRESH_MS = 10 * 60_000;
export const MODES = ['look', 'where', 'form'] as const;
export type Mode = (typeof MODES)[number];

/** A box on the picture, as fractions (0 to 1) of its width and height. */
export type Box = { x: number; y: number; w: number; h: number; label: string };

export type Answer =
  | { ok: true; say: string; target: Box | null; fields: Box[]; note: string; app: string; used: number; cap: number }
  | { ok: false; reason: string; say: string };

export type Ask = { image: string; mime: 'image/jpeg'; question: string; mode: Mode };

/** What the person is told, as plain words, when screen help is not set up here. */
export const NO_API_SAY =
  'Screen help needs this computer to be connected to Escanor (its hub), so a model that can look at a picture can answer. It is not connected here.';

// ------------------------------------------------------------------------------------------------- the one-time yes and the notes

/** The person's one-time yes to "take a picture of my screen when I ask, send it to an AI model, keep nothing". */
export class ScreenConsent {
  constructor(private readonly file: string) {}
  granted(): boolean {
    try {
      return (JSON.parse(readFileSync(this.file, 'utf8')) as { granted?: unknown }).granted === true;
    } catch {
      return false;
    }
  }
  grant(now: number = Date.now()): void {
    writeOwnerOnly(this.file, JSON.stringify({ granted: true, at: new Date(now).toISOString() }));
  }
}

export function writeOwnerOnly(file: string, text: string): void {
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.tmp-${process.pid}`;
  writeFileSync(tmp, text, { mode: 0o600 });
  renameSync(tmp, file);
}

/** The short text notes kept after a look (never the picture). */
export class NoteLog {
  constructor(private readonly file: string) {}
  list(): Array<{ at: string; note: string }> {
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as unknown;
      return Array.isArray(j) ? (j as Array<{ at: string; note: string }>).filter((n) => n && typeof n.note === 'string') : [];
    } catch {
      return [];
    }
  }
  add(note: string, now: number = Date.now()): void {
    const clean = note.replace(/\s+/g, ' ').trim().slice(0, 160);
    if (!clean) return;
    writeOwnerOnly(this.file, JSON.stringify([...this.list(), { at: new Date(now).toISOString(), note: clean }].slice(-NOTES_KEPT)));
  }
}

// ------------------------------------------------------------------------------------------------- asking the server (agent side)

export type BackendConn = { apiUrl: string | null; hubToken: string; vmName: string; agentVersion: string; fetchImpl?: typeof fetch; timeoutMs?: number };

function box(raw: unknown): Box | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const n = (k: string) => (typeof r[k] === 'number' && Number.isFinite(r[k]) ? (r[k] as number) : NaN);
  const [x, y, w, h] = [n('x'), n('y'), n('w'), n('h')];
  if ([x, y, w, h].some(Number.isNaN) || x < 0 || y < 0 || w <= 0 || h <= 0 || x > 1 || y > 1 || w > 1 || h > 1) return null;
  return { x, y, w: Math.min(w, 1 - x), h: Math.min(h, 1 - y), label: typeof r.label === 'string' ? r.label.replace(/\s+/g, ' ').trim().slice(0, 80) : '' };
}

/** Plain words for a refused or failed ask, from the server's coded answer. Never throws. */
export async function askBackend(conn: BackendConn, ask: Ask): Promise<Answer> {
  if (!conn.apiUrl) return { ok: false, reason: 'unavailable', say: NO_API_SAY };
  let res: Response;
  try {
    res = await (conn.fetchImpl ?? fetch)(`${conn.apiUrl}/agent/screen/ask`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${conn.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${conn.agentVersion}` },
      body: JSON.stringify({ vm_name: conn.vmName, image: ask.image, mime: ask.mime, question: ask.question, mode: ask.mode }),
      signal: AbortSignal.timeout(conn.timeoutMs ?? 50_000),
    });
  } catch {
    return { ok: false, reason: 'offline', say: 'Escanor could not be reached just now, so the screen could not be looked at. Try again in a moment.' };
  }
  let body: Record<string, unknown> = {};
  try {
    body = (await res.json()) as Record<string, unknown>;
  } catch {
    /* an unreadable body is handled below */
  }
  if (res.status === 429) return { ok: false, reason: 'rate_limited', say: 'Too many screen questions at once. Try again in a minute.' };
  if (res.status === 401 || res.status === 404) return { ok: false, reason: 'unavailable', say: NO_API_SAY };
  if (!res.ok) return { ok: false, reason: String(body.reason ?? 'error'), say: typeof body.message === 'string' ? body.message : 'Screen help ran into a problem. Try again in a moment.' };
  if (body.ok !== true) return { ok: false, reason: String(body.reason ?? 'error'), say: typeof body.say === 'string' && body.say ? body.say : 'Screen help is not available right now.' };
  const fields = Array.isArray(body.fields) ? body.fields.map(box).filter((b): b is Box => b !== null).slice(0, 12) : [];
  return {
    ok: true,
    say: String(body.say ?? '').slice(0, 900),
    target: box(body.target),
    fields,
    note: typeof body.note === 'string' ? body.note.slice(0, 160) : '',
    app: typeof body.app === 'string' ? body.app.slice(0, 60) : '',
    used: Number(body.used) || 0,
    cap: Number(body.cap) || 0,
  };
}

// ------------------------------------------------------------------------------------------------- the socket between chat and agent

const MAX_LINE = 4_000_000;

/** The agent's end: answers each request from a chat's MCP server (one JSON line in, one out). The socket is owner-only. */
export function serveScreenHelp(sockPath: string, answer: (a: Ask) => Promise<Answer>): Server | null {
  if (sockPath.length > 100) return null; // a Unix socket path is limited to about 108 bytes
  try {
    if (existsSync(sockPath)) unlinkSync(sockPath); // our own stale socket file from a crashed run, and only that exact path
  } catch {
    return null;
  }
  const server = createServer((c) => {
    let buf = '';
    c.setEncoding('utf8');
    c.on('data', (d: string) => {
      buf += d;
      if (buf.length > MAX_LINE) return void c.destroy();
      const nl = buf.indexOf('\n');
      if (nl < 0) return;
      const line = buf.slice(0, nl);
      buf = '';
      void (async () => {
        let out: Answer;
        try {
          const j = JSON.parse(line) as Partial<Ask>;
          if (typeof j.image !== 'string' || !j.image) throw new Error('no picture');
          out = await answer({ image: j.image, mime: 'image/jpeg', question: typeof j.question === 'string' ? j.question.slice(0, 600) : '', mode: MODES.includes(j.mode as Mode) ? (j.mode as Mode) : 'look' });
        } catch {
          out = { ok: false, reason: 'error', say: 'Screen help could not read the request.' };
        }
        c.end(`${JSON.stringify(out)}\n`);
      })();
    });
    c.on('error', () => c.destroy());
  });
  server.on('error', () => undefined);
  server.listen(sockPath, () => {
    try {
      chmodSync(sockPath, 0o600);
    } catch {
      /* the folder is private anyway */
    }
  });
  server.on('close', () => {
    try {
      unlinkSync(sockPath);
    } catch {
      /* already gone */
    }
  });
  return server;
}

/** The chat's end: ask the agent over its socket. */
export function askAgent(sockPath: string, ask: Ask, timeoutMs = 60_000): Promise<Answer> {
  return new Promise((resolve) => {
    const fail = (say: string): void => resolve({ ok: false, reason: 'unavailable', say });
    if (!sockPath || !existsSync(sockPath)) return fail('Screen help is not running on this computer (the Escanor agent is older or was started without it).');
    const c = createConnection(sockPath);
    let buf = '';
    const timer = setTimeout(() => {
      c.destroy();
      fail('Screen help took too long. Try again in a moment.');
    }, timeoutMs);
    timer.unref();
    c.setEncoding('utf8');
    c.on('connect', () => c.write(`${JSON.stringify(ask)}\n`));
    c.on('data', (d: string) => {
      buf += d;
    });
    c.on('error', () => {
      clearTimeout(timer);
      fail('Screen help could not reach the Escanor agent on this computer.');
    });
    c.on('close', () => {
      clearTimeout(timer);
      try {
        resolve(JSON.parse(buf.trim()) as Answer);
      } catch {
        fail('Screen help gave no answer. Try again in a moment.');
      }
    });
  });
}

// ------------------------------------------------------------------------------------------------- pointing on the real screen

/**
 * A transparent, click-through window over the whole screen with a ring and a label at the target; it closes itself. Input is
 * switched off for the window (an empty input region), so the person's clicks and typing go to the app underneath, and it does not
 * take the keyboard. argv: JSON {x, y, w, h, label, seconds} (fractions of the screen).
 */
export const OVERLAY_PY = `
import sys, json, math
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
import cairo
a = json.loads(sys.argv[1])
win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
win.set_title('Escanor pointer')
win.set_decorated(False)
win.set_app_paintable(True)
win.set_accept_focus(False)
win.set_focus_on_map(False)
win.set_skip_taskbar_hint(True)
win.set_skip_pager_hint(True)
win.set_keep_above(True)
css = Gtk.CssProvider(); css.load_from_data(b'window, window.background { background-color: rgba(0,0,0,0); background-image: none; }')
Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
vis = win.get_screen().get_rgba_visual()
if vis is not None: win.set_visual(vis)
def draw(w, cr):
    cr.set_operator(cairo.OPERATOR_SOURCE); cr.set_source_rgba(0, 0, 0, 0); cr.paint(); cr.set_operator(cairo.OPERATOR_OVER)
    W, H = w.get_allocated_width(), w.get_allocated_height()
    # The window is maximized (a fullscreen one is shown without its transparency), so it covers the work area, not the whole screen:
    # the target is given as fractions of the whole screen and shifted by where the work area starts (top bar on top; the dock side).
    GW, GH, x0, y0 = W, H, 0, 0
    try:
        mon = Gdk.Display.get_default().get_primary_monitor() or Gdk.Display.get_default().get_monitor(0)
        geo = mon.get_geometry(); GW, GH = geo.width, geo.height
        dock = ''
        try:
            import subprocess
            dock = subprocess.run(['gsettings', 'get', 'org.gnome.shell.extensions.dash-to-dock', 'dock-position'], capture_output=True, text=True, timeout=2).stdout.strip().strip("'")
        except Exception: pass
        if dock == 'RIGHT': x0, y0 = 0, GH - H
        elif dock == 'BOTTOM': x0, y0 = 0, 32
        else: x0, y0 = GW - W, GH - H
        x0, y0 = max(0, min(x0, GW - 1)), max(0, min(y0, GH - 1))
    except Exception:
        pass
    x, y, bw, bh = a['x'] * GW - x0, a['y'] * GH - y0, max(a['w'] * GW, 24), max(a['h'] * GH, 24)
    pad = 6
    x, y, bw, bh = x - pad, y - pad, bw + 2 * pad, bh + 2 * pad
    r = 10
    cr.new_sub_path()
    cr.arc(x + bw - r, y + r, r, -math.pi / 2, 0); cr.arc(x + bw - r, y + bh - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + bh - r, r, math.pi / 2, math.pi); cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2); cr.close_path()
    cr.set_source_rgba(1.0, 0.85, 0.1, 0.18); cr.fill_preserve()
    cr.set_source_rgba(1.0, 0.85, 0.1, 0.95); cr.set_line_width(4); cr.stroke()
    label = a.get('label') or ''
    if label:
        cr.select_font_face('Sans', cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD); cr.set_font_size(16)
        ext = cr.text_extents(label); lw, lh = ext.width + 20, 28
        lx = min(max(x, 4), W - lw - 4); ly = y - lh - 6 if y - lh - 6 > 4 else y + bh + 6
        cr.set_source_rgba(0.1, 0.1, 0.12, 0.92); cr.rectangle(lx, ly, lw, lh); cr.fill()
        cr.set_source_rgba(1, 1, 1, 1); cr.move_to(lx + 10, ly + 19); cr.show_text(label)
    return False
win.connect('draw', draw)
def no_input(w, *_):
    gw = w.get_window()
    if gw is not None: gw.input_shape_combine_region(cairo.Region(), 0, 0)
win.connect('realize', no_input)
win.connect('map', no_input)
win.maximize()
win.show_all()
no_input(win)
GLib.timeout_add(int(float(a.get('seconds', 4)) * 1000), Gtk.main_quit)
Gtk.main()
`;

export type Highlighter = (b: Box, seconds: number) => Promise<boolean>;

/** The real overlay (GNOME and other GTK desktops; the other systems get the words only). Resolves when it closes; false when it could not show. */
export const realHighlight: Highlighter = (b, seconds) =>
  new Promise((resolve) => {
    if (process.platform !== 'linux') return resolve(false);
    let done = false;
    const finish = (ok: boolean): void => {
      if (!done) {
        done = true;
        resolve(ok);
      }
    };
    try {
      const child = spawn('python3', ['-c', OVERLAY_PY, JSON.stringify({ x: b.x, y: b.y, w: b.w, h: b.h, label: b.label, seconds })], { env: desktopEnv(process.env), stdio: 'ignore' });
      child.once('error', () => finish(false));
      child.once('close', (code) => finish(code === 0));
      setTimeout(() => {
        child.kill(); // a stuck overlay never outlives its time
        finish(false);
      }, seconds * 1000 + 4000).unref();
    } catch {
      finish(false);
    }
  });

// ------------------------------------------------------------------------------------------------- saying where

/** "top left", "middle", "bottom right" ... for the centre of a box. */
export function whereWords(b: Box): string {
  const cx = b.x + b.w / 2;
  const cy = b.y + b.h / 2;
  const col = cx < 0.34 ? 'left' : cx > 0.66 ? 'right' : 'middle';
  const row = cy < 0.34 ? 'top' : cy > 0.66 ? 'bottom' : 'middle';
  if (row === 'middle' && col === 'middle') return 'the middle of the screen';
  if (row === 'middle') return `the ${col} side of the screen`;
  if (col === 'middle') return `the ${row} of the screen`;
  return `the ${row} ${col} of the screen`;
}

/** Fields whose label says they hold a secret: never typed into by screen help (the sign-in lane owns passwords). */
export const SECRET_LABEL = /pass(word|code|phrase)?|pin\b|otp|one[- ]time|2fa|verification code|security code|cvv|cvc|card number|credit card|secret|token|api key|ssn|aadhaar|passport/i;

/** Is (x, y) inside one of the boxes the last look pointed at? Returns that box, else null. */
export function boxAt(boxes: Box[], x: number, y: number): Box | null {
  const slack = 0.01;
  for (const b of boxes) if (x >= b.x - slack && x <= b.x + b.w + slack && y >= b.y - slack && y <= b.y + b.h + slack) return b;
  return null;
}

export const centre = (b: Box): { x: number; y: number } => ({ x: b.x + b.w / 2, y: b.y + b.h / 2 });

// ------------------------------------------------------------------------------------------------- the live view's highlight

/** Where the last look pointed, for the phone's live view to draw over its picture (in the owner-only data folder, for 15 seconds). */
export function writeHighlight(file: string, b: Box, now: number = Date.now()): void {
  writeOwnerOnly(file, JSON.stringify({ until: now + HIGHLIGHT_MS, ...b }));
}

export function readHighlight(file: string, now: number = Date.now()): Box | null {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
    if (typeof j.until !== 'number' || j.until <= now) return null;
    return box(j);
  } catch {
    return null;
  }
}
