/**
 * The GNOME side of live control, as one Python program (python3 with GObject and GStreamer's PipeWire plugin, both installed with
 * Ubuntu's desktop). It is run with `python3 -I -c` and talks to the agent over its standard input and output (one JSON object per
 * line) and a private picture pipe (file descriptor 3, optional).
 *
 *   argv: <folder for frame.jpg> <picture width> <seconds between pictures> [monitor connector] [pipe]
 *
 * It holds GNOME's own remote-desktop session with a linked screen-cast: no pop-up, nothing to install, and GNOME shows its own
 * screen-sharing indicator while it runs. Everything it opened is let go when it exits, and it exits by itself when the agent's end
 * of its standard input closes.
 *
 *   in (JSON lines, `nr:1` = no answer line needed):
 *     input        move, tap, right, double, middle, drag, scroll, combo, type, btn {b,down,x,y}, key {sym,down}
 *     quality      {width,q,gap,refW,refQ,refine}  picture size, JPEG quality, minimum seconds between pictures, and the sharp picture
 *     clip_get     {id}        read the computer's clipboard text   -> event clip
 *     clip_set     {text}      put text on the computer's clipboard
 *     banner       {title,body}  the "your screen is being viewed" notice with a Stop button (event kill when pressed)
 *     stop
 *   out (JSON lines): ready {width,height}, monitors {list}, done {id}, clip {id,text}, locked {locked}, kill, closed, error {why}
 *   picture pipe: [4 bytes length, big endian][1 byte: 1 = sharp picture][JPEG]
 *
 * Pictures: GNOME sends one when something on the screen changed (and again every second). A picture the same as the last one is
 * not sent. When the screen has been still for a moment, the same picture is sent once more, big and sharp, from a second branch of
 * the pipeline (so it costs nothing while things move).
 */
export const GNOME_LIVE_PY = `
import sys, os, json, threading, time, zlib, struct, select
import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gio, GLib, Gst
outdir, width, gap0 = sys.argv[1], int(sys.argv[2]), float(sys.argv[3])
monitor = sys.argv[4] if len(sys.argv) > 4 else ''
pipe_ok = len(sys.argv) > 5 and sys.argv[5] == 'pipe'
Gst.init(None)
bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
RD, SC = 'org.gnome.Mutter.RemoteDesktop', 'org.gnome.Mutter.ScreenCast'
def call(dest, path, iface, method, args=None, sig=None):
    return bus.call_sync(dest, path, iface, method, GLib.Variant(sig, args) if sig else None, None, Gio.DBusCallFlags.NONE, 10000, None)
def callfd(dest, path, iface, method, args=None, sig=None):
    return bus.call_with_unix_fd_list_sync(dest, path, iface, method, GLib.Variant(sig, args) if sig else None, None, Gio.DBusCallFlags.NONE, 10000, None, None)
def prop(dest, path, iface, name):
    return bus.call_sync(dest, path, 'org.freedesktop.DBus.Properties', 'Get', GLib.Variant('(ss)', (iface, name)), None, Gio.DBusCallFlags.NONE, 5000, None).unpack()[0]
out_lock = threading.Lock()
def say(**k):
    with out_lock:
        sys.stdout.write(json.dumps(k) + '\\n'); sys.stdout.flush()
def list_monitors():
    try:
        r = call('org.gnome.Mutter.DisplayConfig', '/org/gnome/Mutter/DisplayConfig', 'org.gnome.Mutter.DisplayConfig', 'GetCurrentState').unpack()
        info = {}
        for spec, modes, mprops in r[1]:
            cur = [m for m in modes if m[6].get('is-current')]
            info[spec[0]] = {'id': spec[0], 'name': str(mprops.get('display-name') or spec[0]), 'w': cur[0][1] if cur else 0, 'h': cur[0][2] if cur else 0}
        res = []
        for x, y, scale, transform, primary, mons, lp in r[2]:
            for spec in mons:
                d = info.get(spec[0])
                if d: res.append(dict(d, primary=bool(primary), x=int(x), y=int(y)))
        return res
    except Exception:
        return []
try:
    rd = call(RD, '/org/gnome/Mutter/RemoteDesktop', RD, 'CreateSession').unpack()[0]
except Exception as e:
    say(event='error', why='inhibited' if 'inhibited' in str(e) else 'no_session', detail=str(e)[:200]); sys.exit(3)
S = RD + '.Session'
rdid = prop(RD, rd, S, 'SessionId')
sc = call(SC, '/org/gnome/Mutter/ScreenCast', SC, 'CreateSession', ({'remote-desktop-session-id': GLib.Variant('s', rdid)},), '(a{sv})').unpack()[0]
mons = list_monitors()
if monitor and mons and monitor not in [m['id'] for m in mons]: monitor = ''
try:
    stream = call(SC, sc, SC + '.Session', 'RecordMonitor', (monitor, {'cursor-mode': GLib.Variant('u', 1)}), '(sa{sv})').unpack()[0]
except Exception as e:
    say(event='error', why='no_monitor', detail=str(e)[:200]); sys.exit(4)
clip_ok = False
try:
    call(RD, rd, S, 'EnableClipboard', ({},), '(a{sv})'); clip_ok = True
except Exception:
    clip_ok = False
loop = GLib.MainLoop()
st = {'w': 0, 'h': 0, 'gap': gap0, 'refine': True, 'pipe': None}
last = [0.0]
hs = {'last': None, 'ref': False}
held_btn, held_key = set(), set()
pipe_lock = threading.Lock()
def emit(data, sharp):
    try:
        tmp = os.path.join(outdir, 'frame.tmp')
        with open(tmp, 'wb') as f: f.write(data)
        os.replace(tmp, os.path.join(outdir, 'frame.jpg'))
    except Exception:
        pass
    if pipe_ok:
        buf = struct.pack('>IB', len(data), 1 if sharp else 0) + data
        with pipe_lock:
            mv = memoryview(buf)
            while len(mv):
                try:
                    n = os.write(3, mv); mv = mv[n:]
                except BlockingIOError:
                    select.select([], [3], [], 0.2)
                except Exception:
                    return
def on_sample(sink):
    s = sink.emit('pull-sample')
    if s is None: return Gst.FlowReturn.OK
    buf = s.get_buffer(); ok, m = buf.map(Gst.MapFlags.READ)
    if ok:
        try: emit(bytes(m.data), sink.get_name() == 'or')
        finally: buf.unmap(m)
    return Gst.FlowReturn.OK
def gate(pad, info):
    now = time.monotonic()
    if now - last[0] < st['gap']: return Gst.PadProbeReturn.DROP
    p = st.get('pipe')
    b = info.get_buffer()
    h = None
    ok, m = b.map(Gst.MapFlags.READ)
    if ok:
        try: h = zlib.crc32(m.data)
        finally: b.unmap(m)
    if h is not None and h == hs['last']:
        # Nothing changed. The first repeat goes out once more, big and sharp; later repeats are dropped.
        if st['refine'] and not hs['ref'] and p is not None:
            hs['ref'] = True
            p['vr'].set_property('drop', False); p['vb'].set_property('drop', True)
            last[0] = now
            return Gst.PadProbeReturn.OK
        return Gst.PadProbeReturn.DROP
    hs['last'] = h; hs['ref'] = False
    if p is not None:
        p['vr'].set_property('drop', True); p['vb'].set_property('drop', False)
    last[0] = now
    return Gst.PadProbeReturn.OK
def caps(w, fmt=''): return Gst.Caps.from_string('video/x-raw,%swidth=%d,pixel-aspect-ratio=1/1' % (fmt, int(w)))
def set_quality(c):
    p = st.get('pipe')
    hs['last'] = None; hs['ref'] = False  # the next picture goes out again at the new setting
    if c.get('gap') is not None: st['gap'] = max(0.02, min(2.0, float(c['gap'])))
    if 'refine' in c: st['refine'] = bool(c['refine'])
    if p is None: return
    sw = st['w'] or 0
    if c.get('width'):
        w = int(c['width']); w = min(w, sw) if sw else w
        p['cb'].set_property('caps', caps(max(160, w)))
    if c.get('q'): p['eb'].set_property('quality', max(10, min(95, int(c['q']))))
    if c.get('refW'):
        w = int(c['refW']); w = min(w, sw) if sw else w
        p['cr'].set_property('caps', caps(max(160, w), 'format=Y444,'))
    if c.get('refQ'): p['er'].set_property('quality', max(10, min(95, int(c['refQ']))))
def start_pipe(node):
    try:
        w, h = prop(SC, stream, SC + '.Stream', 'Parameters').get('size', (0, 0))
    except Exception:
        w, h = 0, 0
    st['w'], st['h'] = w, h
    bw = min(width, w) if w else width
    rw = min(3840, w) if w else 1920
    desc = ('pipewiresrc path=%d always-copy=true keepalive-time=1000 ! queue name=q leaky=downstream max-size-buffers=1 ! tee name=t '
            't. ! valve name=vb drop=false ! queue leaky=downstream max-size-buffers=1 ! videoconvert ! videoscale method=2 ! capsfilter name=cb caps="video/x-raw,width=%d,pixel-aspect-ratio=1/1" ! jpegenc name=eb quality=55 ! appsink name=ob emit-signals=true max-buffers=1 drop=true sync=false async=false '
            't. ! valve name=vr drop=true ! queue leaky=downstream max-size-buffers=1 ! videoconvert ! videoscale method=3 ! capsfilter name=cr caps="video/x-raw,format=Y444,width=%d,pixel-aspect-ratio=1/1" ! jpegenc name=er quality=85 ! appsink name=or emit-signals=true max-buffers=1 drop=true sync=false') % (node, bw, rw)
    p = Gst.parse_launch(desc)
    for n in ('ob', 'or'): p.get_by_name(n).connect('new-sample', on_sample)
    st['pipe'] = {'p': p, 'vb': p.get_by_name('vb'), 'vr': p.get_by_name('vr'), 'cb': p.get_by_name('cb'), 'cr': p.get_by_name('cr'), 'eb': p.get_by_name('eb'), 'er': p.get_by_name('er')}
    p.get_by_name('q').get_static_pad('src').add_probe(Gst.PadProbeType.BUFFER, gate)
    p.set_state(Gst.State.PLAYING)
    # A still screen sends no first frame: a one-pixel move out and straight back makes one, and the pointer ends where it began.
    def nudge(n=[0]):
        for dx in (1.0, -1.0):
            try: call(RD, rd, S, 'NotifyPointerMotionRelative', (dx, 0.0), '(dd)')
            except Exception: return False
        n[0] += 1
        return n[0] < 3 and hs['last'] is None
    GLib.timeout_add(250, nudge)
    say(event='ready', width=w, height=h, monitor=monitor or (mons[0]['id'] if mons else ''), clipboard=clip_ok)
    say(event='monitors', list=mons)
def on_added(conn, snd, path, iface, sig, params, *a):
    start_pipe(params.unpack()[0])
def on_closed(*a):
    say(event='closed'); loop.quit()
bus.signal_subscribe(SC, SC + '.Stream', 'PipeWireStreamAdded', stream, None, Gio.DBusSignalFlags.NONE, on_added)
bus.signal_subscribe(RD, S, 'Closed', rd, None, Gio.DBusSignalFlags.NONE, on_closed)
def on_lock(conn, snd, path, iface, sig, params, *a):
    say(event='locked', locked=bool(params.unpack()[0]))
bus.signal_subscribe('org.gnome.ScreenSaver', 'org.gnome.ScreenSaver', 'ActiveChanged', '/org/gnome/ScreenSaver', None, Gio.DBusSignalFlags.NONE, on_lock)
# ---- clipboard (GNOME's remote-desktop clipboard: nothing is read until the viewer asks, and nothing is kept)
clip = {'text': '', 'mine': False}
TEXT_MIMES = ['text/plain;charset=utf-8', 'text/plain', 'UTF8_STRING', 'STRING']
def on_transfer(conn, snd, path, iface, sig, params, *a):
    mime, serial = params.unpack()
    try:
        res, fl = callfd(RD, rd, S, 'SelectionWrite', (serial,), '(u)')
        fd = fl.get(res.unpack()[0])
        data = clip['text'].encode('utf-8')
        with os.fdopen(fd, 'wb') as f: f.write(data)
        call(RD, rd, S, 'SelectionWriteDone', (serial, True), '(ub)')
    except Exception:
        try: call(RD, rd, S, 'SelectionWriteDone', (serial, False), '(ub)')
        except Exception: pass
def on_owner(conn, snd, path, iface, sig, params, *a):
    o = params.unpack()[0]
    clip['mine'] = bool(o.get('session-is-owner'))
    clip['types'] = list(o.get('mime-types') or [])
if clip_ok:
    bus.signal_subscribe(RD, S, 'SelectionTransfer', rd, None, Gio.DBusSignalFlags.NONE, on_transfer)
    bus.signal_subscribe(RD, S, 'SelectionOwnerChanged', rd, None, Gio.DBusSignalFlags.NONE, on_owner)
def read_clip(cid):
    text = ''
    try:
        if clip['mine']:
            text = clip['text']
        else:
            types = clip.get('types') or TEXT_MIMES
            mime = next((m for m in TEXT_MIMES if m in types), None) or TEXT_MIMES[0]
            res, fl = callfd(RD, rd, S, 'SelectionRead', (mime,), '(s)')
            fd = fl.get(res.unpack()[0]); buf = b''; t0 = time.time()
            while time.time() - t0 < 3 and len(buf) < 400000:
                r, _, _ = select.select([fd], [], [], 0.4)
                if r:
                    d = os.read(fd, 65536)
                    if not d: break
                    buf += d
            os.close(fd)
            text = buf.decode('utf-8', 'replace')
    except Exception:
        text = ''
    say(event='clip', id=cid, text=text[:100000])
def set_clip(text):
    clip['text'] = text; clip['mine'] = True
    call(RD, rd, S, 'SetSelection', ({'mime-types': GLib.Variant('as', ['text/plain;charset=utf-8', 'text/plain'])},), '(a{sv})')
# ---- the notice on this computer while it is viewed, with a Stop button
N = {'id': 0, 'title': '', 'body': '', 'on': False}
NB = ('org.freedesktop.Notifications', '/org/freedesktop/Notifications', 'org.freedesktop.Notifications')
def post_banner():
    if not N['on']: return False
    try:
        r = call(NB[0], NB[1], NB[2], 'Notify', ('Escanor', N['id'], 'dialog-warning-symbolic', N['title'], N['body'], ['stop', 'Stop viewing now'], {'urgency': GLib.Variant('y', 2), 'resident': GLib.Variant('b', True)}, 0), '(susssasa{sv}i)')
        N['id'] = r.unpack()[0]
    except Exception:
        pass
    return False
def on_action(conn, snd, path, iface, sig, params, *a):
    nid, action = params.unpack()
    if nid == N['id'] and action == 'stop': say(event='kill')
def on_note_closed(conn, snd, path, iface, sig, params, *a):
    nid, reason = params.unpack()
    if nid == N['id'] and N['on'] and reason in (1, 2):
        N['id'] = 0; GLib.timeout_add_seconds(20, post_banner)
bus.signal_subscribe(NB[0], NB[2], 'ActionInvoked', NB[1], None, Gio.DBusSignalFlags.NONE, on_action)
bus.signal_subscribe(NB[0], NB[2], 'NotificationClosed', NB[1], None, Gio.DBusSignalFlags.NONE, on_note_closed)
# ---- input
def mv(x, y):
    if st['w'] and st['h']:
        call(RD, rd, S, 'NotifyPointerMotionAbsolute', (stream, max(0.0, min(1.0, float(x))) * (st['w'] - 1), max(0.0, min(1.0, float(y))) * (st['h'] - 1)), '(sdd)')
def btn(b, down):
    call(RD, rd, S, 'NotifyPointerButton', (b, down), '(ib)')
    (held_btn.add if down else held_btn.discard)(b)
def key(k, down):
    call(RD, rd, S, 'NotifyKeyboardKeysym', (int(k), down), '(ub)')
    (held_key.add if down else held_key.discard)(int(k))
BUTTONS = {'left': 0x110, 'right': 0x111, 'middle': 0x112}
def handle(line):
    ack = True
    try:
        c = json.loads(line); t = c.get('t'); ack = not c.get('nr')
        if t == 'move': mv(c['x'], c['y'])
        elif t in ('tap', 'right', 'double', 'middle'):
            mv(c['x'], c['y']); time.sleep(0.02); b = {'right': 0x111, 'middle': 0x112}.get(t, 0x110)
            for _ in range(2 if t == 'double' else 1):
                btn(b, True); btn(b, False); time.sleep(0.06)
        elif t == 'btn':
            if 'x' in c and 'y' in c: mv(c['x'], c['y'])
            btn(BUTTONS.get(c.get('b'), 0x110), bool(c.get('down')))
        elif t == 'drag':
            mv(c['x'], c['y']); btn(0x110, True)
            for i in range(1, 9):
                mv(c['x'] + (c['x2'] - c['x']) * i / 8, c['y'] + (c['y2'] - c['y']) * i / 8); time.sleep(0.02)
            btn(0x110, False)
        elif t == 'scroll':
            if 'x' in c and 'y' in c: mv(c['x'], c['y'])
            if c.get('dy'): call(RD, rd, S, 'NotifyPointerAxisDiscrete', (0, int(c['dy'])), '(ui)')
            if c.get('dx'): call(RD, rd, S, 'NotifyPointerAxisDiscrete', (1, int(c['dx'])), '(ui)')
        elif t == 'combo':
            ks = c['syms']
            for k in ks: key(k, True)
            for k in reversed(ks): key(k, False)
        elif t == 'key': key(c['sym'], bool(c.get('down')))
        elif t == 'type':
            for k in c['syms']:
                key(k, True); key(k, False); time.sleep(0.008)
        elif t == 'quality': set_quality(c)
        elif t == 'clip_get': threading.Thread(target=read_clip, args=(c.get('id'),), daemon=True).start(); ack = False
        elif t == 'clip_set': set_clip(str(c.get('text', ''))[:100000])
        elif t == 'banner':
            N.update(title=str(c.get('title', ''))[:120], body=str(c.get('body', ''))[:300], on=True); post_banner()
        elif t == 'stop':
            loop.quit(); return False
        if ack: say(event='done', id=c.get('id'))
    except Exception as e:
        say(event='done', id=None, error=str(e)[:200])
    return False
def reader():
    for line in sys.stdin: GLib.idle_add(handle, line)
    GLib.idle_add(loop.quit)
threading.Thread(target=reader, daemon=True).start()
try:
    call(RD, rd, S, 'Start')
    loop.run()
finally:
    # Let go of everything held, close the notice, stop sharing.
    try:
        for b in list(held_btn): call(RD, rd, S, 'NotifyPointerButton', (b, False), '(ib)')
        for k in list(held_key): call(RD, rd, S, 'NotifyKeyboardKeysym', (k, False), '(ub)')
    except Exception: pass
    N['on'] = False
    try:
        if N['id']: call(NB[0], NB[1], NB[2], 'CloseNotification', (N['id'],), '(u)')
    except Exception: pass
    try: st.get('pipe') and st['pipe']['p'].set_state(Gst.State.NULL)
    except Exception: pass
    try: call(RD, rd, S, 'Stop')
    except Exception: pass
`;
