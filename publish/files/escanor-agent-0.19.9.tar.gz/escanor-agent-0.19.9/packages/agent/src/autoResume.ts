import type { RegistryEntry } from './registry.js';

/**
 * AUTORESUME: a chat whose work was cut off goes on by itself, without the person sending "continue".
 *
 * - 'limit': Claude's usage limit stopped the turn. It goes on once the limit resets (the message waits for it like any other).
 * - 'offline': the computer or the agent stopped mid-turn (turned off, restarted, crashed, lost power, or went to sleep). It goes on
 *   once the agent is back and connected to Escanor.
 * - 'error': the AI service could not be reached or dropped the reply (server error, overloaded, network). It is tried again a
 *   little later (1, 5, then 15 minutes), once this machine is online.
 *
 * Never for a chat the person stopped, a fix (fixTests.ts asks Escanor about those) or a chat put away. A turn that ends fine
 * clears it; a chat that keeps being cut off is tried a few times and then left for the person. Chats open in a terminal here are
 * carried on inside that terminal (terminalResume.ts).
 */
export type CutReason = 'limit' | 'offline' | 'error';

export type CutOff = {
  reason: CutReason;
  /** When it was first cut off (ISO). */
  since: string;
  /** How often it was continued automatically since its last turn that went fine. */
  tries: number;
  /** 'limit': when Claude said the limit resets (ms), so a restart in between still waits for it. */
  resetsAt?: number;
  /** 'error': not tried again before this (ms). */
  retryAt?: number;
};

/** Cut off by the limit: tried again after each reset (each try costs nothing while Claude refuses). */
export const MAX_LIMIT_TRIES = 6;
/** Cut off by the computer going away: a chat that keeps dying with it is left for the person after this many tries. */
export const MAX_OFFLINE_TRIES = 3;
/** Cut off by the AI service failing: tried this many times (1, 5 and 15 minutes after the failure). */
export const MAX_ERROR_TRIES = 3;
/** Work cut off longer ago than this is not picked up on its own (a laptop shut for a long weekend still is; weekly limits take days). */
export const MAX_OFFLINE_AGE_MS = 7 * 24 * 3_600_000;
export const MAX_LIMIT_AGE_MS = 8 * 24 * 3_600_000;
export const MAX_ERROR_AGE_MS = 24 * 3_600_000;
/** Held for this long when Claude says the limit is reached but not until when. */
export const UNKNOWN_RESET_MS = 30 * 60_000;

export const maxTries = (r: CutReason) => (r === 'limit' ? MAX_LIMIT_TRIES : r === 'error' ? MAX_ERROR_TRIES : MAX_OFFLINE_TRIES);
const maxAge = (r: CutReason) => (r === 'limit' ? MAX_LIMIT_AGE_MS : r === 'error' ? MAX_ERROR_AGE_MS : MAX_OFFLINE_AGE_MS);

/** How long after a failure of the AI service the next try goes (the `tries` already made). */
export function errorBackoffMs(tries: number): number {
  return [60_000, 5 * 60_000, 15 * 60_000][Math.min(Math.max(tries, 0), 2)];
}

/** The SDK's / transcript's assistant `error` values that mean the AI service failed for now (worth trying again later). */
export const TRANSIENT_ERRORS = new Set(['server_error', 'overloaded']);

/** inputId prefix of the agent's own "continue" (never acked to the hub as a phone message: it starts with 'agent:'). */
export const AUTO_RESUME_INPUT = 'agent:autoresume:';

/** What the queue shows for the agent's own "continue" (never its long instruction to Claude). */
export const AUTO_RESUME_PREVIEW = 'Continues by itself where it left off';

/** The reason inside an auto-resume inputId (`agent:autoresume:<reason>:<id>`). */
export function reasonOfInput(inputId: string | undefined): CutReason | null {
  if (!inputId?.startsWith(AUTO_RESUME_INPUT)) return null;
  const r = inputId.slice(AUTO_RESUME_INPUT.length).split(':')[0];
  return r === 'limit' || r === 'error' || r === 'offline' ? r : 'offline';
}

/** What Claude is told: it was cut off, and must carry on without redoing what is done. */
export function continueText(reason: CutReason): string {
  const why =
    reason === 'limit'
      ? "Claude's usage limit stopped your last turn before it finished; the limit has reset now."
      : reason === 'error'
        ? 'Your last turn was cut off before it finished: the AI service could not be reached or dropped the reply. It is reachable again.'
        : 'Your last turn was cut off before it finished: the computer running this chat went offline (turned off, restarted or slept) and is back now.';
  return (
    `${why} Continue the task from where you stopped. First check what is already done (files, commands, git state) so nothing ` +
    'is done twice, then finish the work and report as you normally would. (This message was sent automatically by Escanor.)'
  );
}

/** What the person sees in the chat when it goes on by itself. */
export function resumeNotice(reason: CutReason): string {
  return reason === 'limit'
    ? "Claude's usage limit has reset: this chat is picking up where it left off by itself."
    : reason === 'error'
      ? 'Trying again: this chat is picking up where it left off by itself.'
      : 'This computer is back online: this chat is picking up where it left off by itself.';
}

/** Said when a chat is cut off and will go on by itself (instead of "send continue"). */
export function waitNotice(reason: CutReason, at?: number): string {
  if (reason === 'limit') {
    const when = at !== undefined ? ` at ${hhmm(at)}` : '';
    return `Claude's usage limit stopped this chat. It picks up where it left off by itself when the limit resets${when}; nothing to do.`;
  }
  if (reason === 'error') {
    const when = at !== undefined ? ` at ${hhmm(at)}` : ' in a minute';
    return `The AI service could not be reached, so this chat stopped. It tries again by itself${when}; nothing to do.`;
  }
  return 'This computer went to sleep or offline while this chat was working. It picks up where it left off by itself as soon as the computer is back online; no need to send "continue".';
}

function hhmm(ms: number): string {
  const d = new Date(ms);
  const zone = new Intl.DateTimeFormat('en-GB', { timeZoneName: 'short' }).formatToParts(d).find((p) => p.type === 'timeZoneName')?.value;
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}${zone ? ` ${zone}` : ''}`;
}

/** Tried too often, or cut off too long ago: left for the person. */
export function exhausted(cut: CutOff, now: number): boolean {
  const since = Date.parse(cut.since);
  return cut.tries >= maxTries(cut.reason) || (Number.isFinite(since) && now - since > maxAge(cut.reason));
}

/** The chats to continue now, with why (marked cut off, due, not too often tried, not too long ago). */
export function chatsToResume(
  entries: RegistryEntry[],
  o: { now: number; skip: (sessionId: string) => boolean },
): { sessionId: string; reason: CutReason }[] {
  const out: { sessionId: string; reason: CutReason }[] = [];
  for (const e of entries) {
    const cut = e.cutOff;
    if (!cut || e.fix || e.archivedAt || o.skip(e.sessionId) || exhausted(cut, o.now)) continue;
    if (cut.retryAt !== undefined && cut.retryAt > o.now) continue;
    out.push({ sessionId: e.sessionId, reason: cut.reason });
  }
  return out;
}

/** The soonest time a chat waiting to be tried again is due (for a timer), if any. */
export function nextRetryAt(entries: RegistryEntry[], now: number): number | undefined {
  const times = entries
    .filter((e) => e.cutOff?.retryAt !== undefined && e.cutOff.retryAt > now && !e.fix && !e.archivedAt && !exhausted(e.cutOff, now))
    .map((e) => e.cutOff!.retryAt!);
  return times.length ? Math.min(...times) : undefined;
}

// ---------- terminal chats (read from Claude Code's transcript) ----------

/**
 * Where a terminal chat's transcript stands, from its last lines (JSONL):
 * - cut: its last word is Claude Code's error for the usage limit ('limit', with the reset Claude named) or for the AI service
 *   failing ('error'), and nobody wrote to it since;
 * - ok: its last reply went through (a chat that recovered: its tries start again from zero);
 * - pending: someone wrote to it after its last reply (a "continue" on its way, or the person), or nothing can be told.
 */
export type TailState =
  | { state: 'cut'; reason: 'limit' | 'error'; uuid: string; at: number; resetsAt?: number }
  | { state: 'ok' }
  | { state: 'pending' };

const SKIP_TYPES = new Set(['system', 'attachment', 'queue-operation', 'api-request', 'api-request-blob', 'last-prompt', 'ai-title', 'summary', 'mode', 'permission-mode', 'pr-link', 'file-history-snapshot', 'custom-title', 'atis-latch', 'tag', 'progress']);

/** resetsAt arrives in Unix seconds; accept milliseconds too. */
const toMs = (t: unknown): number | undefined => (typeof t === 'number' && t > 0 ? (t < 1e12 ? t * 1000 : t) : undefined);

export function tailState(lines: string[], now = Date.now()): TailState {
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    let d: Record<string, unknown>;
    try {
      d = JSON.parse(line);
    } catch {
      continue; // the cut first line of the tail, or a line being written
    }
    if (!d || typeof d !== 'object' || d.isSidechain === true) continue;
    const type = typeof d.type === 'string' ? d.type : '';
    if (SKIP_TYPES.has(type)) continue;
    if (type === 'user') {
      if (d.isMeta === true) continue;
      return { state: 'pending' };
    }
    if (type !== 'assistant') continue;
    if (d.isApiErrorMessage !== true) return { state: 'ok' };
    const err = typeof d.error === 'string' ? d.error : '';
    const reason = err === 'rate_limit' ? 'limit' : TRANSIENT_ERRORS.has(err) ? 'error' : null;
    if (!reason) return { state: 'pending' }; // an error that trying again will not fix (billing, a bad request): left alone
    const uuid = typeof d.uuid === 'string' ? d.uuid : `line-${i}`;
    const ts = typeof d.timestamp === 'string' ? Date.parse(d.timestamp) : NaN;
    const at = Number.isFinite(ts) ? ts : now;
    const q = d.quotaLimits as { resetsAt?: unknown } | undefined;
    const resetsAt = reason === 'limit' ? (toMs(q?.resetsAt) ?? at + UNKNOWN_RESET_MS) : undefined;
    return { state: 'cut', reason, uuid, at, ...(resetsAt !== undefined ? { resetsAt } : {}) };
  }
  return { state: 'pending' };
}
