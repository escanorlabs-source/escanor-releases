import { HOLD_APPROVED_NOTE, holdDescription, riskyToolCall, type Risk } from '@remote-harness/shared/risk';
import { switchOn } from './switches.js';

/**
 * Risky commands wait for the person, in every chat mode (bypass included): a command that cannot be undone or reaches far beyond
 * the work at hand (shared/risk.ts) is sent to the phone as a permission request marked with HOLD_FIELD, and runs only on Approve.
 * The phone and web show the "why" from that field, and the phone's Autonomous auto-answer never answers a request carrying it.
 */

/**
 * The safety net's switch in the agent's environment: ON unless ESCANOR_RISK_HOLDS=0 (false/off/no). Since the safety layer
 * (safetyAgent.ts) keeps a copy of deletes instead of asking, only what no copy can undo still waits for the person, so this is on
 * for everyone (22 Oct 2026; the phone, website and desktop apps all show these holds).
 */
export const RISK_HOLDS_ENV = 'ESCANOR_RISK_HOLDS';
export const riskHoldsOn = (env: NodeJS.ProcessEnv = process.env): boolean => switchOn(env[RISK_HOLDS_ENV], true);

/** The field of a permission request's input that marks it as a risky-command hold (what, why). Never part of the tool's own input. */
export const HOLD_FIELD = 'escanorHold';

/**
 * How long Claude Code waits for our PreToolUse hook (seconds). A hook that times out lets the tool run, so it must outlast any
 * wait for the person: 20 days (setTimeout's limit is about 24.8 days).
 */
export const HOLD_HOOK_TIMEOUT_SECONDS = 20 * 24 * 60 * 60;
/** The agent stops waiting (a no) an hour before Claude Code would give up on the hook and let the command run. */
export const HOLD_WAIT_MS = (HOLD_HOOK_TIMEOUT_SECONDS - 60 * 60) * 1000;

export type HoldMark = { kind: Risk['kind']; why: string; text: string };

/** The input shown on the phone for a held call: the call as it is, plus what is risky about it. */
export function heldInput(input: Record<string, unknown>, risk: Risk): Record<string, unknown> {
  const mark: HoldMark = { kind: risk.kind, why: risk.why, text: holdDescription(risk) };
  return { ...withoutHoldMark(input), [HOLD_FIELD]: mark };
}

/** A call's input without a hold mark: only the agent marks a hold, never the AI writing the call. */
export function withoutHoldMark(input: Record<string, unknown>): Record<string, unknown> {
  if (!input || typeof input !== 'object' || !(HOLD_FIELD in input)) return input;
  const { [HOLD_FIELD]: _drop, ...rest } = input;
  return rest;
}

/** What the AI is told when the person says no. */
export function refusedMessage(risk: Risk, note?: string): string {
  return (
    `The person said no to this command on their phone. ${risk.why} Do not run it, or another command that does the same thing. ` +
    `Say what you needed it for and ask them what to do instead.${note && note !== 'Denied by user' ? ` (${note})` : ''}`
  );
}

/** What the AI is told when an allow came from something that could not show the person why the command is risky. */
export function notShownMessage(risk: Risk): string {
  return (
    `This command was not run: it needs the person's Approve on a phone or web app that shows why it is risky, and the answer came ` +
    `from somewhere that could not show it (an older Escanor app, or an automatic answer). ${risk.why} Do not run it another way. ` +
    'Ask the person to update the Escanor app and approve it there, or to run it themselves.'
  );
}

export type AskPerson = (toolName: string, input: Record<string, unknown>, signal: AbortSignal) => Promise<{ behavior: 'allow' | 'deny'; message?: string }>;

/**
 * Hold a risky call until the person answers. null: the call is not risky (nothing was asked). Otherwise their answer: allow, or
 * deny with what the AI is told.
 */
export async function holdIfRisky(
  toolName: string,
  toolInput: unknown,
  ask: AskPerson,
  signal: AbortSignal,
  waitMs: number = HOLD_WAIT_MS,
  /** The safety layer already found why it must wait (safetyAgent.ts): held for that, whatever riskyToolCall says. */
  forced?: Risk,
): Promise<null | { allow: true } | { allow: false; message: string }> {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  const risk = forced ?? riskyToolCall(toolName, withoutHoldMark(input));
  if (!risk) return null;
  // Stopped turn, or no answer before the hook's own time limit: the wait ends as a no (never as a timeout that lets it run).
  const wait = new AbortController();
  const stop = () => wait.abort();
  if (signal.aborted) wait.abort();
  else signal.addEventListener('abort', stop, { once: true });
  const timer = setTimeout(stop, waitMs);
  let answer: Awaited<ReturnType<AskPerson>>;
  try {
    answer = await ask(toolName, heldInput(input, risk), wait.signal);
  } finally {
    clearTimeout(timer);
    signal.removeEventListener('abort', stop);
  }
  // Only an app that showed the person this hold says so with its Approve (HOLD_APPROVED_NOTE); any other allow (an older app's
  // auto-answer, the hub's own auto-allow) is taken as a no.
  if (answer.behavior === 'allow' && answer.message === HOLD_APPROVED_NOTE) return { allow: true };
  if (answer.behavior === 'allow') return { allow: false, message: notShownMessage(risk) };
  return { allow: false, message: refusedMessage(risk, answer.message) };
}

/**
 * Does this chat work on its own (the phone's Autonomous, or Bypass)? Then nothing in it waits for an Approve: the owner's rule
 * (24 Oct 2026) is that an Autonomous chat never asks. A chat that names no mode counts by the mode it runs in.
 */
export function neverAsks(s: { requested?: string; mode?: string } | undefined): boolean {
  if (!s) return false;
  if (s.requested !== undefined) return s.requested === 'auto' || s.requested === 'bypassPermissions';
  return s.mode === 'bypassPermissions';
}

/** The risk a call carries (what a hold would have asked about), or null. */
export function riskOf(toolName: string, toolInput: unknown, forced?: Risk): Risk | null {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  return forced ?? riskyToolCall(toolName, withoutHoldMark(input)) ?? null;
}

/** The line the chat shows for a risky step an Autonomous chat left for the person instead of asking. */
export const LEFT_FOR_YOU = 'Left for you:';

/** What the AI is told when an Autonomous chat meets a command that cannot be undone: it is not run, and nobody is asked. */
export function leftForPersonMessage(risk: Risk): string {
  return (
    `Escanor did not run this, and did not ask anyone: this chat works on its own, and this command cannot be undone. ${risk.why} ` +
    'Do not run it another way. Carry on with everything else that reaches the goal, and at the end say plainly, in one line, ' +
    'what is left for the person to do themselves.'
  );
}
