import { randomUUID } from 'node:crypto';
import type { AgentPendingRequest, AgentToHubMessage, PermissionDecision } from '@remote-harness/shared';
import { describeCommand } from '@remote-harness/shared/describe';

type Decision = { behavior: PermissionDecision; message?: string };
type Pending = { sessionKey: string; resolve: (d: Decision) => void; info: AgentPendingRequest };

// Tracks tool-permission requests awaiting a human decision. Every path out of "pending" is covered:
// the hub answers, the call is aborted (including already aborted), or the session ends.
// What still waits is listed in the hello and announced again after a reconnect (DEV6), so a prompt is never lost on the way.
export class PermissionBroker {
  private pending = new Map<string, Pending>();

  constructor(
    private send: (msg: AgentToHubMessage) => void,
    private now: () => number = Date.now,
  ) {}

  request(
    sessionKey: string,
    toolName: string,
    input: Record<string, unknown>,
    blockedPath: string | undefined,
    signal: AbortSignal,
  ): Promise<Decision> {
    if (signal.aborted) return Promise.resolve({ behavior: 'deny', message: 'Interrupted' });
    const requestId = randomUUID();
    // What it will do in everyday words, for the phone's approval bar (an older app ignores it and reads the input).
    const summary = describeCommand(toolName, input).summary;
    this.send({ type: 'permission_request', sessionId: sessionKey, requestId, toolName, input, blockedPath, summary });
    return new Promise((resolve) => {
      const info: AgentPendingRequest = {
        requestId,
        sessionId: sessionKey,
        toolName,
        input,
        ...(blockedPath !== undefined ? { blockedPath } : {}),
        summary,
        askedAt: new Date(this.now()).toISOString(),
      };
      this.pending.set(requestId, { sessionKey, resolve, info });
      signal.addEventListener(
        'abort',
        () => {
          if (this.pending.delete(requestId)) resolve({ behavior: 'deny', message: 'Interrupted' });
        },
        { once: true },
      );
    });
  }

  /** The answer reached the waiting call (delivered), or nothing waits for it any more. */
  resolve(requestId: string, behavior: PermissionDecision, message?: string): { delivered: boolean; sessionId?: string } {
    const p = this.pending.get(requestId);
    if (!p) return { delivered: false };
    this.pending.delete(requestId);
    p.resolve({ behavior, message });
    return { delivered: true, sessionId: p.info.sessionId };
  }

  dropSession(sessionKey: string): void {
    for (const [id, p] of this.pending) {
      if (p.sessionKey !== sessionKey) continue;
      this.pending.delete(id);
      p.resolve({ behavior: 'deny', message: 'Session ended' });
    }
  }

  /** A new chat got its real id: its prompts are known by it from now on (a hello after a reconnect lists them so). */
  rename(from: string, to: string): void {
    for (const p of this.pending.values()) {
      if (p.sessionKey === from) p.info = { ...p.info, sessionId: to };
    }
  }

  pendingCount(): number {
    return this.pending.size;
  }

  /** What still waits for an answer, oldest first (hello.pending). */
  pendingList(): AgentPendingRequest[] {
    return [...this.pending.values()].map((p) => p.info);
  }

  /** Announce every waiting prompt again (after the hello of a new connection); the hub stores and pushes each only once. */
  resendPending(): void {
    for (const p of this.pending.values()) {
      const { askedAt: _askedAt, ...req } = p.info;
      this.send({ type: 'permission_request', ...req, resent: true });
    }
  }
}
