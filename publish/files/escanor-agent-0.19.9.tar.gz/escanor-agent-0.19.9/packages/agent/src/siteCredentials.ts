import { execFile, spawn } from 'node:child_process';
import type { Conn } from './machineApi.js';
import { deviceKey, resolveSecrets } from './machineApi.js';
import { GNOME_KEYS_PY, isGnome } from './screenControl.js';

/**
 * The stored sign-in for one site, and typing it (Jarvis phase 2). Both are only reached after the owner's fingerprint yes for that
 * exact site and only when the owner switched typing on for this computer (ESCANOR_JARVIS_TYPE_SECRETS=1); the default is to open
 * the site where the browser's own saved password or passkey fills it. Nothing here logs a value, puts one in a program's arguments
 * (they are visible to every program on the computer) or keeps one: text goes to the typing tool on its standard input.
 *
 * Where a sign-in is kept, in order:
 *  1. Escanor's vault, in this computer's own scope (machine:<id>), as SITE_<HOST>_USER and SITE_<HOST>_PASSWORD (host in capitals,
 *     dots and dashes as underscores): the machine's own key reads it (the vault's /vault/resolve), the same route its git login uses.
 *  2. The OS keyring: Linux libsecret (`secret-tool store --label=... service escanor-jarvis host <host> field password`), macOS
 *     Keychain (`security add-generic-password -s escanor-jarvis -a <host>-password -w`). Windows has no command-line keyring path here.
 */

export const vaultName = (host: string, field: 'USER' | 'PASSWORD'): string => `SITE_${host.toUpperCase().replace(/[^A-Z0-9]/g, '_')}_${field}`;

export type Lookup = (cmd: string, args: string[]) => Promise<string | null>;

const realLookup: Lookup = (cmd, args) =>
  new Promise((resolve) => {
    execFile(cmd, args, { timeout: 5000, windowsHide: true, maxBuffer: 64_000 }, (err, stdout) => resolve(err ? null : stdout.replace(/\r?\n$/, '')));
  });

/** From the OS keyring (libsecret or the macOS Keychain). Null when there is none. */
export async function keyringCredential(host: string, platform: NodeJS.Platform = process.platform, lookup: Lookup = realLookup): Promise<{ user: string; password: string } | null> {
  if (!/^[a-z0-9.-]{1,253}$/.test(host)) return null;
  if (platform === 'linux') {
    const get = (field: string) => lookup('secret-tool', ['lookup', 'service', 'escanor-jarvis', 'host', host, 'field', field]);
    const [user, password] = [await get('user'), await get('password')];
    return password ? { user: user ?? '', password } : null;
  }
  if (platform === 'darwin') {
    const get = (field: string) => lookup('security', ['find-generic-password', '-s', 'escanor-jarvis', '-a', `${host}-${field}`, '-w']);
    const [user, password] = [await get('user'), await get('password')];
    return password ? { user: user ?? '', password } : null;
  }
  return null;
}

/** From Escanor's vault with this machine's own key. Null when it is not there or the vault cannot be reached. */
export async function vaultCredential(conn: Conn, machineId: string, host: string): Promise<{ user: string; password: string } | null> {
  if (!machineId || !/^[a-z0-9.-]{1,253}$/.test(host)) return null;
  const key = await deviceKey(conn);
  if (!key.ok) return null;
  const names = [vaultName(host, 'USER'), vaultName(host, 'PASSWORD')];
  const r = await resolveSecrets(conn, key.value, `machine:${machineId}`, names);
  if (!r.ok) return null;
  const password = r.value.values[names[1]];
  return password ? { user: r.value.values[names[0]] ?? '', password } : null;
}

export type TypeStep = { cmd: string; args: string[]; stdin?: string };

/** X keysyms for `text` (a tab and a new line are the Tab and Return keys; other control characters are left out). */
export function keysymsOf(text: string): number[] {
  const out: number[] = [];
  for (const ch of text.slice(0, 256)) {
    const c = ch.codePointAt(0)!;
    if (c === 9) out.push(0xff09);
    else if (c === 10) out.push(0xff0d);
    else if (c >= 0x20 && c <= 0x7e) out.push(c);
    else if (c > 0xa0) out.push(0x01000000 + c);
  }
  return out;
}

/** How to type `text` with each tool. A tab or a new line is a key press; anything else is read from the tool's standard input. */
export function typeSteps(text: string, platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = {}): TypeStep[] {
  const key = text === '\t' ? 'Tab' : text === '\n' ? 'Return' : null;
  if (platform === 'win32') {
    if (key) return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', `(New-Object -ComObject WScript.Shell).SendKeys('${key === 'Tab' ? '{TAB}' : '{ENTER}'}')`] }];
    return [];
  }
  if (platform === 'darwin') {
    if (key) return [{ cmd: 'osascript', args: ['-e', `tell application "System Events" to key code ${key === 'Tab' ? 48 : 36}`] }];
    return [{ cmd: 'osascript', args: ['-e', 'tell application "System Events" to keystroke (do shell script "cat")'], stdin: text }];
  }
  // GNOME (Wayland or X11): its own remote-desktop service, which needs no tool installed and no pop-up. The keys go in on standard input.
  const gnome: TypeStep[] = isGnome(env) ? [{ cmd: 'python3', args: ['-I', '-c', GNOME_KEYS_PY, '-'], stdin: keysymsOf(text).map((k) => k.toString(16)).join(' ') }] : [];
  if (key) {
    return [
      ...gnome,
      { cmd: 'xdotool', args: ['key', key] },
      { cmd: 'wtype', args: ['-k', key] },
      { cmd: 'ydotool', args: ['key', key === 'Tab' ? '15:1' : '28:1', key === 'Tab' ? '15:0' : '28:0'] },
    ];
  }
  return [
    ...gnome,
    { cmd: 'xdotool', args: ['type', '--clearmodifiers', '--file', '-'], stdin: text },
    { cmd: 'wtype', args: ['-'], stdin: text },
    { cmd: 'ydotool', args: ['type', '--file', '-'], stdin: text },
  ];
}

export type TypeRunner = (step: TypeStep, env: NodeJS.ProcessEnv) => Promise<'ok' | 'missing' | 'failed'>;

const realTypeRunner: TypeRunner = (step, env) =>
  new Promise((resolve) => {
    let child;
    try {
      child = spawn(step.cmd, step.args, { env, stdio: ['pipe', 'ignore', 'ignore'], windowsHide: true });
    } catch {
      return resolve('missing');
    }
    child.once('error', (e: NodeJS.ErrnoException) => resolve(e.code === 'ENOENT' ? 'missing' : 'failed'));
    child.once('close', (code) => resolve(code === 0 ? 'ok' : 'failed'));
    child.stdin?.on('error', () => {});
    child.stdin?.end(step.stdin ?? '');
    setTimeout(() => {
      child.kill();
      resolve('failed');
    }, 10_000).unref();
  });

/** Type `text` into the focused window with the first tool that works. False when no tool can (nothing was typed). */
export async function typeText(text: string, env: NodeJS.ProcessEnv, platform: NodeJS.Platform = process.platform, run: TypeRunner = realTypeRunner): Promise<boolean> {
  for (const s of typeSteps(text, platform, env)) {
    if ((await run(s, env)) === 'ok') return true;
  }
  return false;
}

/** Is there any way to type here? (Checked before the stored sign-in is fetched, so a secret is never read for nothing.) */
export async function canType(env: NodeJS.ProcessEnv, platform: NodeJS.Platform = process.platform, which: (cmd: string) => Promise<boolean> = defaultWhich): Promise<boolean> {
  for (const s of typeSteps('\t', platform, env)) if (await which(s.cmd)) return true;
  return false;
}

const defaultWhich = (cmd: string): Promise<boolean> =>
  new Promise((resolve) => {
    execFile(process.platform === 'win32' ? 'where' : 'which', [cmd], { timeout: 3000, windowsHide: true }, (err) => resolve(!err));
  });
