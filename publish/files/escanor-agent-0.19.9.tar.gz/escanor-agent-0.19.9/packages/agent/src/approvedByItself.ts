/**
 * The line an Autonomous chat leaves for each step it took without asking ("Auto-approved: Edit src/app.ts"). The phone
 * recognises it by this start and draws it small; an older phone shows it as a plain note.
 */
export const APPROVED_BY_ITSELF = 'Auto-approved:';

/** Tools that only look and never change anything: Ask me would not have asked about them either. */
const LOOK_ONLY_TOOLS = new Set(['Read', 'Glob', 'Grep', 'LS', 'NotebookRead', 'TodoWrite', 'TaskList', 'TaskGet', 'ToolSearch', 'WebSearch', 'BashOutput', 'ExitPlanMode']);

/** Plain looking-around commands, with nothing that writes (no redirect, pipe, chain or substitution). */
const LOOK_ONLY_SHELL = /^(ls|cat|pwd|head|tail|wc|grep|rg|echo|which|stat|file|tree|du|df|date|whoami|git\s+(status|log|diff|show|branch|rev-parse|remote\s+-v))(\s[^|&;<>`$]*)?$/;

/** Would "Ask me" have asked about this call? Anything unknown counts as yes, so the owner sees it. */
export function needsApproval(tool: string, input: unknown): boolean {
  if (LOOK_ONLY_TOOLS.has(tool)) return false;
  if (tool === 'Bash') {
    const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
    const command = typeof i.command === 'string' ? i.command.trim() : '';
    if (command && LOOK_ONLY_SHELL.test(command)) return false;
  }
  return true;
}

type Question = { question?: unknown; options?: unknown };

/**
 * An Autonomous chat answers its own questions: the option marked "(Recommended)", else the first one. Returns the tool input
 * with the answers filled in (the shape Claude Code reads), or null when there is nothing to pick from (the AI then decides).
 */
export function autoAnswerQuestions(input: unknown): { input: Record<string, unknown>; picked: string[] } | null {
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const qs = Array.isArray(i.questions) ? (i.questions as Question[]) : [];
  const answers: Record<string, string> = {};
  const picked: string[] = [];
  for (const q of qs) {
    if (!q || typeof q.question !== 'string' || !Array.isArray(q.options)) continue;
    const labels = (q.options as Array<{ label?: unknown }>).map((o) => (o && typeof o.label === 'string' ? o.label : '')).filter(Boolean);
    if (!labels.length) continue;
    const label = labels.find((l) => /\(recommended\)/i.test(l)) ?? labels[0];
    answers[q.question] = label;
    picked.push(label);
  }
  return picked.length ? { input: { ...i, answers }, picked } : null;
}
