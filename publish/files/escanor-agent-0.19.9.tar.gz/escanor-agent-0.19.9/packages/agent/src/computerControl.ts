import { execFileSync, spawn } from 'node:child_process';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { switchOn } from './switches.js';
import type { WinSnap } from './windowFocus.js';

/**
 * Computer control (JARVIS1): the everyday things a person asks of their own computer from the phone ("on my laptop, play lo-fi
 * on YouTube", "pause the music", "open my mail"). Each is one small, known program run with fixed arguments (never a shell, never
 * text the AI wrote as a command), so it can run without a card, the way a person would press the key themselves:
 *  - open a web address (http, https or mailto only) or an installed app, in the person's own browser or desktop;
 *  - YouTube: the search results page for what was asked, or a video link the person gave. The page is opened, never fetched or
 *    read here: YouTube's terms forbid automated access and its robots.txt disallows /results, so picking "the first video" by
 *    reading the page is left out on purpose;
 *  - play, pause, next, previous (MPRIS over D-Bus on Linux: playerctl, else gdbus), volume, lock the screen;
 *  - a new email, filled in (Gmail's compose page or a mailto: link). It is only opened: the person presses Send. Sending for
 *    them goes through their connected mail (Escanor MCP) and is always held for their yes (mailHold.ts), never by clicking.
 * Linux first (GNOME Wayland and X11), with macOS (open, osascript) and Windows (rundll32, PowerShell) paths.
 */

export type MediaOp = 'play' | 'pause' | 'play_pause' | 'next' | 'previous' | 'stop';
export type VolumeOp = 'up' | 'down' | 'mute' | 'unmute' | 'set';

export type ComputerAction =
  | { kind: 'open_url'; url: string }
  | { kind: 'open_app'; app: string }
  | { kind: 'play_youtube'; query?: string; url?: string }
  | { kind: 'media'; op: MediaOp }
  | { kind: 'volume'; op: VolumeOp; level?: number }
  | { kind: 'lock_screen' }
  | { kind: 'compose_mail'; to?: string; subject?: string; body?: string; via?: 'gmail' | 'mailto' };

export type Step = { cmd: string; args: string[]; /** Started and left running (a browser, an app): only a quick failure counts. */ detach?: boolean };
export type RunResult = { code: number | null; stdout: string; /** The program is not installed. */ missing: boolean };
export type Runner = (step: Step, env: NodeJS.ProcessEnv) => Promise<RunResult>;
export type Outcome = { ok: boolean; say: string };

export const COMPUTER_CONTROL_ENV = 'ESCANOR_COMPUTER_CONTROL';
const MAX_TEXT = 2000;
const EMAIL = /^[^\s@<>(),;:"]{1,64}@[A-Za-z0-9.-]{1,253}\.[A-Za-z]{2,63}$/;
const APP_NAME = /^[\p{L}\p{N} ._+-]{1,60}$/u;
const YT_HOSTS = new Set(['youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtu.be']);

/** Is there a desktop here to control (not a server or a container)? macOS and Windows always; Linux when a session is found. */
export function hasDesktop(env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform, exists: (p: string) => boolean = existsSync): boolean {
  if (platform === 'darwin' || platform === 'win32') return true;
  if (env.DISPLAY || env.WAYLAND_DISPLAY) return true;
  const run = runtimeDir(env);
  return Boolean(run && (exists(join(run, 'wayland-0')) || exists(join(run, 'bus')))) || exists('/tmp/.X11-unix/X0');
}

/** On unless switched off; never in an Escanor worker; only where there is a desktop. */
export function computerControlOn(env: NodeJS.ProcessEnv = process.env, opts: { managed: boolean } = { managed: env.ESCANOR_MANAGED === '1' }): boolean {
  if (opts.managed) return false;
  return switchOn(env[COMPUTER_CONTROL_ENV], hasDesktop(env));
}

function runtimeDir(env: NodeJS.ProcessEnv): string | null {
  if (env.XDG_RUNTIME_DIR) return env.XDG_RUNTIME_DIR;
  const uid = typeof process.getuid === 'function' ? process.getuid() : null;
  return uid === null ? null : `/run/user/${uid}`;
}

/** The desktop session's own variables, as systemd's user manager holds them (GNOME and KDE import them at login). */
const SESSION_VARS = ['DISPLAY', 'WAYLAND_DISPLAY', 'XAUTHORITY', 'XDG_SESSION_TYPE', 'XDG_CURRENT_DESKTOP', 'XDG_SESSION_DESKTOP', 'DESKTOP_SESSION', 'DBUS_SESSION_BUS_ADDRESS'];
let sessionCache: { at: number; vars: Record<string, string> } | null = null;

export function parseShowEnvironment(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of text.split('\n')) {
    const i = line.indexOf('=');
    if (i <= 0) continue;
    const k = line.slice(0, i);
    if (SESSION_VARS.includes(k)) out[k] = line.slice(i + 1).replace(/^\$?'(.*)'$/, '$1');
  }
  return out;
}

function systemdSessionVars(run: string | null): Record<string, string> {
  if (sessionCache && Date.now() - sessionCache.at < 60_000) return sessionCache.vars;
  let vars: Record<string, string> = {};
  try {
    const text = execFileSync('systemctl', ['--user', 'show-environment'], { env: { ...process.env, ...(run ? { XDG_RUNTIME_DIR: run } : {}) }, timeout: 3000, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
    vars = parseShowEnvironment(text);
  } catch {
    // no systemd user manager (a container, macOS): the guesses below are used
  }
  sessionCache = { at: Date.now(), vars };
  return vars;
}

/**
 * A background service (the agent's systemd user unit) may start before the desktop session, without its variables: a browser
 * then cannot find the screen (Chrome: "Missing X server or $DISPLAY") and playerctl cannot find the players. Fill in what the
 * session has (systemd's copy first, then the usual sockets). What is set already is kept.
 */
export function desktopEnv(
  env: NodeJS.ProcessEnv,
  platform: NodeJS.Platform = process.platform,
  exists: (p: string) => boolean = existsSync,
  session: (run: string | null) => Record<string, string> = systemdSessionVars,
): NodeJS.ProcessEnv {
  if (platform !== 'linux') return env;
  const out = { ...env };
  const run = runtimeDir(env);
  if (!out.DISPLAY && !out.WAYLAND_DISPLAY) {
    for (const [k, v] of Object.entries(session(run))) out[k] ??= v;
  }
  if (run && exists(run)) {
    out.XDG_RUNTIME_DIR ??= run;
    if (!out.DBUS_SESSION_BUS_ADDRESS && exists(join(run, 'bus'))) out.DBUS_SESSION_BUS_ADDRESS = `unix:path=${join(run, 'bus')}`;
    if (!out.WAYLAND_DISPLAY && !out.DISPLAY && exists(join(run, 'wayland-0'))) {
      out.WAYLAND_DISPLAY = 'wayland-0';
      out.XDG_SESSION_TYPE ??= 'wayland';
    }
  }
  if (!out.DISPLAY && !out.WAYLAND_DISPLAY && exists('/tmp/.X11-unix/X0')) out.DISPLAY = ':0';
  return out;
}

// ------------------------------------------------------------------------------------------------- checking what was asked

const clip = (s: unknown): string => (typeof s === 'string' ? s.trim().slice(0, MAX_TEXT) : '');

/** Only web pages and mail links are opened: never a file, a script, or a custom scheme that starts a program. */
export function safeUrl(raw: string): string | null {
  const t = raw.trim();
  if (!t || t.length > 4000 || /\s/.test(t)) return null;
  let u: URL;
  try {
    u = new URL(/^[a-z][a-z0-9+.-]*:/i.test(t) ? t : `https://${t}`);
  } catch {
    return null;
  }
  if (u.protocol === 'mailto:') return u.href;
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  if (!u.hostname || (!u.hostname.includes('.') && u.hostname !== 'localhost')) return null;
  if (u.username || u.password) return null;
  return u.href;
}

export function youtubeSearchUrl(query: string): string {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(query.trim()).replace(/%20/g, '+')}`;
}

/** A YouTube video or playlist link the person gave, made canonical; null for anything else. */
export function youtubeVideoUrl(raw: string): string | null {
  const href = safeUrl(raw);
  if (!href) return null;
  const u = new URL(href);
  if (!YT_HOSTS.has(u.hostname)) return null;
  if (u.hostname === 'youtu.be') {
    const id = u.pathname.slice(1);
    return /^[A-Za-z0-9_-]{6,20}$/.test(id) ? `https://www.youtube.com/watch?v=${id}` : null;
  }
  const v = u.searchParams.get('v');
  if (u.pathname === '/watch' && v && /^[A-Za-z0-9_-]{6,20}$/.test(v)) return `https://www.youtube.com/watch?v=${v}`;
  const list = u.searchParams.get('list');
  if (u.pathname === '/playlist' && list && /^[A-Za-z0-9_-]{6,64}$/.test(list)) return `https://www.youtube.com/playlist?list=${list}`;
  return null;
}

/** Gmail's own compose page (the person must be signed in to Gmail in that browser), or a mailto: link for their mail app. */
export function composeUrl(m: { to?: string; subject?: string; body?: string; via?: 'gmail' | 'mailto' }): string {
  const to = (m.to ?? '').split(/[,;\s]+/).filter((a) => EMAIL.test(a)).slice(0, 20);
  const subject = clip(m.subject);
  const body = clip(m.body);
  if (m.via === 'mailto') {
    const q = new URLSearchParams();
    if (subject) q.set('subject', subject);
    if (body) q.set('body', body);
    const qs = q.toString().replace(/\+/g, '%20');
    return `mailto:${to.map(encodeURIComponent).join(',')}${qs ? `?${qs}` : ''}`;
  }
  const q = new URLSearchParams({ view: 'cm', fs: '1' });
  if (to.length) q.set('to', to.join(','));
  if (subject) q.set('su', subject);
  if (body) q.set('body', body);
  return `https://mail.google.com/mail/?${q.toString()}`;
}

/** The input a tool call or a message gave, checked. A reason (in words for the person) when it cannot be done. */
export function parseAction(kind: string, input: Record<string, unknown>): ComputerAction | { error: string } {
  switch (kind) {
    case 'open_url': {
      const url = safeUrl(clip(input.url));
      return url ? { kind, url } : { error: 'Only web addresses (http or https) and mailto: links can be opened.' };
    }
    case 'open_app': {
      const app = clip(input.app ?? input.name);
      return APP_NAME.test(app) ? { kind, app } : { error: 'Say the app by its name, like "Firefox" or "Files".' };
    }
    case 'play_youtube': {
      const url = typeof input.url === 'string' && input.url.trim() ? youtubeVideoUrl(input.url) : null;
      if (typeof input.url === 'string' && input.url.trim() && !url) return { error: 'That is not a YouTube video or playlist link.' };
      const query = clip(input.query).slice(0, 200);
      if (!url && !query) return { error: 'Say what to play.' };
      return url ? { kind, url } : { kind, query };
    }
    case 'media': {
      const op = String(input.op ?? input.action ?? '').replace('playpause', 'play_pause').replace('toggle', 'play_pause') as MediaOp;
      return ['play', 'pause', 'play_pause', 'next', 'previous', 'stop'].includes(op) ? { kind, op } : { error: 'Media can play, pause, go to the next or previous one, or stop.' };
    }
    case 'volume': {
      const op = String(input.op ?? input.action ?? '') as VolumeOp;
      if (!['up', 'down', 'mute', 'unmute', 'set'].includes(op)) return { error: 'Volume can go up, down, mute, unmute or be set to a level.' };
      if (op !== 'set') return { kind, op };
      const level = Number(input.level);
      return Number.isInteger(level) && level >= 0 && level <= 100 ? { kind, op, level } : { error: 'Say a volume level from 0 to 100.' };
    }
    case 'lock_screen':
      return { kind };
    case 'compose_mail': {
      const bad = (typeof input.to === 'string' ? input.to : '').split(/[,;\s]+/).filter((a) => a && !EMAIL.test(a));
      if (bad.length) return { error: `"${bad[0]}" is not an email address.` };
      return { kind, to: clip(input.to), subject: clip(input.subject), body: clip(input.body), via: input.via === 'mailto' ? 'mailto' : 'gmail' };
    }
    default:
      return { error: `This computer does not know how to "${kind}".` };
  }
}

// ------------------------------------------------------------------------------------------------- the programs, per platform

/** Open a web address in the default browser, without a shell (Windows' `start` would read & and ^ in it). */
export function openSteps(url: string, platform: NodeJS.Platform): Step[] {
  if (platform === 'darwin') return [{ cmd: 'open', args: [url], detach: true }];
  if (platform === 'win32') return [{ cmd: 'rundll32.exe', args: ['url.dll,FileProtocolHandler', url], detach: true }];
  return [
    { cmd: 'xdg-open', args: [url], detach: true },
    { cmd: 'gio', args: ['open', url], detach: true },
  ];
}

const LINUX_APP_DIRS = (home: string) => [
  join(home, '.local/share/applications'),
  '/usr/share/applications',
  '/usr/local/share/applications',
  '/var/lib/flatpak/exports/share/applications',
  join(home, '.local/share/flatpak/exports/share/applications'),
  '/var/lib/snapd/desktop/applications',
];

/** Common spoken names for apps whose launcher is called something else. */
const APP_ALIASES: Record<string, string[]> = {
  chrome: ['google chrome', 'chromium'],
  'google chrome': ['chromium'],
  browser: ['firefox', 'google chrome', 'chromium'],
  'web browser': ['firefox', 'google chrome', 'chromium'],
  terminal: ['terminal', 'console', 'ptyxis', 'konsole'],
  files: ['files', 'nautilus', 'dolphin'],
  'file manager': ['files', 'nautilus', 'dolphin'],
  code: ['visual studio code', 'code'],
  vscode: ['visual studio code', 'code'],
  'vs code': ['visual studio code', 'code'],
  settings: ['settings'],
  calculator: ['calculator'],
  spotify: ['spotify'],
};

export type DesktopEntry = { id: string; name: string; path: string };

/** The installed apps' launchers (.desktop files), by id and shown name. Hidden and NoDisplay ones are skipped. */
export function linuxDesktopEntries(home = homedir(), dirs = LINUX_APP_DIRS(home)): DesktopEntry[] {
  const out: DesktopEntry[] = [];
  const seen = new Set<string>();
  for (const dir of dirs) {
    let files: string[];
    try {
      files = readdirSync(dir).filter((f) => f.endsWith('.desktop'));
    } catch {
      continue;
    }
    for (const f of files) {
      const id = f.slice(0, -'.desktop'.length);
      if (seen.has(id)) continue;
      try {
        const text = readFileSync(join(dir, f), 'utf8');
        const entry = text.split(/\n\[/)[0];
        if (/^(NoDisplay|Hidden)=true/m.test(entry) || !/^Type=Application/m.test(entry)) continue;
        const name = /^Name=(.+)$/m.exec(entry)?.[1]?.trim() ?? id;
        seen.add(id);
        out.push({ id, name, path: join(dir, f) });
      } catch {
        // unreadable: skipped
      }
    }
  }
  return out;
}

/** The launcher that best matches a spoken app name: exact name, then id, then a name that starts with or contains it. */
export function matchApp(spoken: string, entries: DesktopEntry[]): DesktopEntry | null {
  const want = spoken.trim().toLowerCase().replace(/^the /, '').replace(/ app$/, '');
  const names = [want, ...(APP_ALIASES[want] ?? [])];
  for (const n of names) {
    const exact = entries.find((e) => e.name.toLowerCase() === n || e.id.toLowerCase() === n || e.id.toLowerCase().endsWith(`.${n.replace(/\s+/g, '')}`));
    if (exact) return exact;
  }
  for (const n of names) {
    const starts = entries.find((e) => e.name.toLowerCase().startsWith(n));
    if (starts) return starts;
  }
  for (const n of names) {
    if (n.length < 3) continue;
    const has = entries.find((e) => e.name.toLowerCase().includes(n));
    if (has) return has;
  }
  return null;
}

export function appSteps(app: string, platform: NodeJS.Platform, entries: () => DesktopEntry[] = linuxDesktopEntries): Step[] | null {
  if (platform === 'darwin') return [{ cmd: 'open', args: ['-a', app], detach: true }];
  // `start` is a cmd built-in; the name was checked against APP_NAME (letters, digits, spaces, . _ + -), so cmd reads nothing in it.
  if (platform === 'win32') return [{ cmd: 'cmd.exe', args: ['/d', '/c', 'start', '""', app], detach: true }];
  const e = matchApp(app, entries());
  if (!e) return null;
  return [
    { cmd: 'gtk-launch', args: [e.id], detach: true },
    { cmd: 'gio', args: ['launch', e.path], detach: true },
  ];
}

const PLAYERCTL: Record<MediaOp, string> = { play: 'play', pause: 'pause', play_pause: 'play-pause', next: 'next', previous: 'previous', stop: 'stop' };
const MPRIS_METHOD: Record<MediaOp, string> = { play: 'Play', pause: 'Pause', play_pause: 'PlayPause', next: 'Next', previous: 'Previous', stop: 'Stop' };
/** Windows virtual keys for the media keys. */
const WIN_MEDIA_KEY: Record<MediaOp, number> = { play: 179, pause: 179, play_pause: 179, next: 176, previous: 177, stop: 178 };

const winKey = (vk: number, times = 1): Step => ({
  cmd: 'powershell.exe',
  args: ['-NoProfile', '-NonInteractive', '-Command', `$w = New-Object -ComObject WScript.Shell; 1..${times} | ForEach-Object { $w.SendKeys([char]${vk}) }`],
});

export function mediaSteps(op: MediaOp, platform: NodeJS.Platform): Step[] {
  if (platform === 'darwin') {
    const verb = { play: 'play', pause: 'pause', play_pause: 'playpause', next: 'next track', previous: 'previous track', stop: 'pause' }[op];
    // The two players macOS can script; a browser tab has no scriptable media key.
    return [{ cmd: 'osascript', args: ['Music', 'Spotify'].flatMap((app) => ['-e', `if application "${app}" is running then tell application "${app}" to ${verb}`]) }];
  }
  if (platform === 'win32') return [winKey(WIN_MEDIA_KEY[op])];
  // `playerctl` (pauses all with -a, so "pause" means everything that plays); else straight over D-Bus (see runMedia).
  return [{ cmd: 'playerctl', args: op === 'pause' || op === 'stop' ? ['-a', PLAYERCTL[op]] : [PLAYERCTL[op]] }];
}

export function volumeSteps(op: VolumeOp, level: number | undefined, platform: NodeJS.Platform): Step[] {
  if (platform === 'darwin') {
    const script = {
      up: 'set volume output volume ((output volume of (get volume settings)) + 10)',
      down: 'set volume output volume ((output volume of (get volume settings)) - 10)',
      mute: 'set volume with output muted',
      unmute: 'set volume without output muted',
      set: `set volume output volume ${level ?? 50}`,
    }[op];
    return [{ cmd: 'osascript', args: ['-e', script] }];
  }
  if (platform === 'win32') {
    if (op === 'set') return [winKey(174, 50), winKey(175, Math.round((level ?? 50) / 2))]; // each key is 2%
    return [winKey({ up: 175, down: 174, mute: 173, unmute: 173 }[op], op === 'up' || op === 'down' ? 5 : 1)];
  }
  const pactl = { up: ['set-sink-volume', '@DEFAULT_SINK@', '+10%'], down: ['set-sink-volume', '@DEFAULT_SINK@', '-10%'], mute: ['set-sink-mute', '@DEFAULT_SINK@', '1'], unmute: ['set-sink-mute', '@DEFAULT_SINK@', '0'], set: ['set-sink-volume', '@DEFAULT_SINK@', `${level}%`] }[op];
  const wpctl = { up: ['set-volume', '-l', '1.0', '@DEFAULT_AUDIO_SINK@', '10%+'], down: ['set-volume', '@DEFAULT_AUDIO_SINK@', '10%-'], mute: ['set-mute', '@DEFAULT_AUDIO_SINK@', '1'], unmute: ['set-mute', '@DEFAULT_AUDIO_SINK@', '0'], set: ['set-volume', '@DEFAULT_AUDIO_SINK@', `${level}%`] }[op];
  const amixer = { up: ['-q', 'set', 'Master', '10%+'], down: ['-q', 'set', 'Master', '10%-'], mute: ['-q', 'set', 'Master', 'mute'], unmute: ['-q', 'set', 'Master', 'unmute'], set: ['-q', 'set', 'Master', `${level}%`] }[op];
  return [
    { cmd: 'pactl', args: pactl },
    { cmd: 'wpctl', args: wpctl },
    { cmd: 'amixer', args: amixer },
  ];
}

export function lockSteps(platform: NodeJS.Platform): Step[] {
  if (platform === 'darwin') return [{ cmd: 'pmset', args: ['displaysleepnow'] }];
  if (platform === 'win32') return [{ cmd: 'rundll32.exe', args: ['user32.dll,LockWorkStation'] }];
  return [
    { cmd: 'gdbus', args: ['call', '--session', '--dest', 'org.gnome.ScreenSaver', '--object-path', '/org/gnome/ScreenSaver', '--method', 'org.gnome.ScreenSaver.Lock'] },
    { cmd: 'gdbus', args: ['call', '--session', '--dest', 'org.freedesktop.ScreenSaver', '--object-path', '/org/freedesktop/ScreenSaver', '--method', 'org.freedesktop.ScreenSaver.Lock'] },
    { cmd: 'loginctl', args: ['lock-session'] },
    { cmd: 'xdg-screensaver', args: ['lock'] },
  ];
}

// ------------------------------------------------------------------------------------------------- running them

const START_GRACE_MS = 1500;
const RUN_TIMEOUT_MS = 10_000;

export const realRunner: Runner = (step, env) =>
  new Promise((resolve) => {
    let out = '';
    let settled = false;
    const done = (r: RunResult) => {
      if (!settled) {
        settled = true;
        resolve(r);
      }
    };
    let child;
    try {
      child = spawn(step.cmd, step.args, { env, stdio: ['ignore', 'pipe', 'ignore'], detached: step.detach === true, windowsHide: true });
    } catch {
      return done({ code: null, stdout: '', missing: true });
    }
    child.stdout?.on('data', (d: Buffer) => {
      if (out.length < 64_000) out += d.toString();
    });
    child.once('error', (err: NodeJS.ErrnoException) => done({ code: null, stdout: '', missing: err.code === 'ENOENT' }));
    child.once('close', (code) => done({ code, stdout: out, missing: false }));
    if (step.detach) {
      // A browser or app keeps running: started and not failed at once is success.
      child.once('spawn', () => {
        child.unref();
        setTimeout(() => done({ code: 0, stdout: out, missing: false }), START_GRACE_MS).unref();
      });
    } else {
      setTimeout(() => {
        child.kill();
        done({ code: null, stdout: out, missing: false });
      }, RUN_TIMEOUT_MS).unref();
    }
  });

/** Try each way in turn until one works. Which programs were missing is kept, to say what to install. */
export async function firstThatWorks(steps: Step[], run: Runner, env: NodeJS.ProcessEnv): Promise<{ ok: boolean; missing: string[]; stdout: string }> {
  const missing: string[] = [];
  for (const s of steps) {
    const r = await run(s, env);
    if (r.code === 0) return { ok: true, missing, stdout: r.stdout };
    if (r.missing) missing.push(s.cmd);
  }
  return { ok: false, missing, stdout: '' };
}

/** The MPRIS players on the session bus (org.mpris.MediaPlayer2.*), from gdbus. */
export function mprisPlayers(listNamesOutput: string): string[] {
  return [...listNamesOutput.matchAll(/'(org\.mpris\.MediaPlayer2\.[A-Za-z0-9_.-]+)'/g)].map((m) => m[1]);
}

async function runMedia(op: MediaOp, platform: NodeJS.Platform, run: Runner, env: NodeJS.ProcessEnv): Promise<{ ok: boolean; missing: string[]; none?: boolean }> {
  const first = await firstThatWorks(mediaSteps(op, platform), run, env);
  if (first.ok || platform !== 'linux') return first;
  // No playerctl (or it found no player): ask D-Bus for the players and tell each one straight.
  const names = await run({ cmd: 'gdbus', args: ['call', '--session', '--dest', 'org.freedesktop.DBus', '--object-path', '/org/freedesktop/DBus', '--method', 'org.freedesktop.DBus.ListNames'] }, env);
  if (names.code !== 0) return { ok: false, missing: names.missing ? [...first.missing, 'gdbus'] : first.missing };
  const players = mprisPlayers(names.stdout);
  if (!players.length) return { ok: false, missing: [], none: true };
  const targets = op === 'pause' || op === 'stop' ? players : players.slice(0, 1);
  let ok = false;
  for (const p of targets) {
    const r = await run({ cmd: 'gdbus', args: ['call', '--session', '--dest', p, '--object-path', '/org/mpris/MediaPlayer2', '--method', `org.mpris.MediaPlayer2.Player.${MPRIS_METHOD[op]}`] }, env);
    ok ||= r.code === 0;
  }
  return { ok, missing: [] };
}

const MEDIA_SAID: Record<MediaOp, string> = { play: 'Playing.', pause: 'Paused.', play_pause: 'Done: play/pause pressed.', next: 'Skipped to the next one.', previous: 'Went back to the previous one.', stop: 'Stopped.' };
const VOLUME_SAID = (op: VolumeOp, level?: number) => ({ up: 'Turned the volume up.', down: 'Turned the volume down.', mute: 'Muted the sound.', unmute: 'Sound is back on.', set: `Set the volume to ${level}%.` })[op];

export const install = (missing: string[], platform: NodeJS.Platform) =>
  platform === 'linux' && missing.length ? ` This computer is missing ${[...new Set(missing)].join(', ')}; installing ${missing.includes('playerctl') ? 'playerctl' : missing[0]} fixes it.` : '';

export type Deps = {
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  run?: Runner;
  apps?: () => DesktopEntry[];
  /** Bring the window a page opened in to the front (windowFocus.ts). Off unless given: the MCP server turns it on. */
  focus?: { snapshot: () => Promise<WinSnap>; raise: (before: WinSnap, host: string) => Promise<boolean> };
};

/** Do one action on this computer. Never throws: the answer says, in plain words, what happened. */
export async function runComputerAction(a: ComputerAction, deps: Deps = {}): Promise<Outcome> {
  const platform = deps.platform ?? process.platform;
  const env = desktopEnv(deps.env ?? process.env, platform);
  const run = deps.run ?? realRunner;
  /** Open an address, then bring the browser window it landed in to the front. `shown` says whether that worked, for the answer. */
  const openAndRaise = async (url: string) => {
    const before = deps.focus ? await deps.focus.snapshot().catch(() => ({ ok: false, wins: [] }) as WinSnap) : null;
    const r = await firstThatWorks(openSteps(url, platform), run, env);
    let host = '';
    try {
      host = new URL(url).hostname;
    } catch {
      /* mailto etc. */
    }
    const raised = r.ok && deps.focus && before ? await deps.focus.raise(before, host).catch(() => false) : false;
    return { ...r, raised };
  };
  const SHOWN = (raised: boolean) => (raised ? ' It is now in front.' : ' Take a screen_look to check which window it is in, and bring the browser to the front if you cannot see the page.');
  try {
    switch (a.kind) {
      case 'open_url': {
        const r = await openAndRaise(a.url);
        return r.ok ? { ok: true, say: `Opened ${a.url.startsWith('mailto:') ? 'a new email' : new URL(a.url).hostname} on this computer.${deps.focus ? SHOWN(r.raised) : ''}` } : { ok: false, say: `Could not open it in a browser here.${install(r.missing, platform)}` };
      }
      case 'play_youtube': {
        const url = a.url ?? youtubeSearchUrl(a.query ?? '');
        const r = await openAndRaise(url);
        if (!r.ok) return { ok: false, say: `Could not open YouTube in a browser here.${install(r.missing, platform)}` };
        return { ok: true, say: a.url ? 'Opened that YouTube video in the browser.' : `Opened YouTube results for "${a.query}" in the browser. Pick one to play, or give me a video link to play it straight away.` };
      }
      case 'open_app': {
        const steps = appSteps(a.app, platform, deps.apps);
        if (!steps) return { ok: false, say: `I could not find an app called "${a.app}" on this computer.` };
        const r = await firstThatWorks(steps, run, env);
        return r.ok ? { ok: true, say: `Opened ${a.app}.` } : { ok: false, say: `Could not open ${a.app}.${install(r.missing, platform)}` };
      }
      case 'media': {
        const r = await runMedia(a.op, platform, run, env);
        if (r.ok) return { ok: true, say: MEDIA_SAID[a.op] };
        if (r.none) return { ok: false, say: 'Nothing is playing on this computer.' };
        return { ok: false, say: `Could not reach a music or video player.${install(r.missing.length ? r.missing : ['playerctl'], platform)}` };
      }
      case 'volume': {
        const r = await firstThatWorks(volumeSteps(a.op, a.level, platform), run, env);
        return r.ok ? { ok: true, say: VOLUME_SAID(a.op, a.level) } : { ok: false, say: `Could not change the volume.${install(r.missing, platform)}` };
      }
      case 'lock_screen': {
        const r = await firstThatWorks(lockSteps(platform), run, env);
        return r.ok ? { ok: true, say: 'Locked the screen.' } : { ok: false, say: 'Could not lock the screen from here.' };
      }
      case 'compose_mail': {
        const url = composeUrl(a);
        const r = await openAndRaise(url);
        if (!r.ok) return { ok: false, say: `Could not open a new email here.${install(r.missing, platform)}` };
        return { ok: true, say: `Opened a new email${a.to ? ` to ${a.to}` : ''}${a.via === 'mailto' ? ' in your mail app' : ' in Gmail'}. Nothing is sent: press Send yourself, or ask me to send it through your connected mail.` };
      }
    }
  } catch {
    return { ok: false, say: 'Something went wrong doing that on this computer.' };
  }
}

/** The tools as the AI sees them (computerMcp.ts). */
export const COMPUTER_TOOLS: Array<{ name: ComputerAction['kind']; description: string; inputSchema: Record<string, unknown> }> = [
  { name: 'open_url', description: 'Open a web address (https or mailto) in the default browser on this computer.', inputSchema: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] } },
  { name: 'open_app', description: 'Open an installed app on this computer by its name (e.g. "Firefox", "Files", "Terminal").', inputSchema: { type: 'object', properties: { app: { type: 'string' } }, required: ['app'] } },
  {
    name: 'play_youtube',
    description: 'Open YouTube in the browser: the results for a search, or a video/playlist link straight away. Does not read YouTube pages.',
    inputSchema: { type: 'object', properties: { query: { type: 'string' }, url: { type: 'string', description: 'A youtube.com or youtu.be link' } } },
  },
  { name: 'media', description: 'Control what is playing on this computer (any app or browser tab that plays media).', inputSchema: { type: 'object', properties: { op: { type: 'string', enum: ['play', 'pause', 'play_pause', 'next', 'previous', 'stop'] } }, required: ['op'] } },
  {
    name: 'volume',
    description: 'Change the volume on this computer.',
    inputSchema: { type: 'object', properties: { op: { type: 'string', enum: ['up', 'down', 'mute', 'unmute', 'set'] }, level: { type: 'integer', minimum: 0, maximum: 100 } }, required: ['op'] },
  },
  { name: 'lock_screen', description: 'Lock the screen of this computer.', inputSchema: { type: 'object', properties: {} } },
  {
    name: 'compose_mail',
    description:
      'Open a new email, filled in, for the person to read and send themselves (Gmail compose page, or their mail app with via=mailto). It never sends. To send for them use the connected mail integration (Escanor MCP), which waits for their yes.',
    inputSchema: { type: 'object', properties: { to: { type: 'string' }, subject: { type: 'string' }, body: { type: 'string' }, via: { type: 'string', enum: ['gmail', 'mailto'] } } },
  },
];
