// Claude Code chats run as their own unprivileged OS users, never as the agent's (Escanor's company machines, Task L I6, N1–N4).
//
// The agent holds the hub token (a file only its user can read, HUB_TOKEN_FILE), its registry and the hub's MCP servers with
// their bearer tokens. A chat runs model-chosen shell commands, without asking when it is in bypass, so it must not be able to
// read any of that. The worker container starts the agent as its own user with only CAP_SETUID and CAP_SETGID (ambient), and
// every chat is started through `setpriv` as another user with every capability cleared and `no_new_privs` set, so a chat cannot
// switch back, nor gain anything from a setuid program:
// - an ordinary chat (the workspace's assistant, with the hub's MCP servers) runs as the chat user;
// - an isolated chat (an app builder's, no MCP at all) runs as the app-chat user.
// The two users share nothing writable: each has its own work folder, home, Claude config folder and temporary folder, so one
// cannot plant files (settings, hooks, git config, CLAUDE.md) that the other's chats load. No chat loads filesystem settings at
// all (the session manager passes `settingSources: []`).
// The MCP configuration (with the workspace's bearer token) never touches the disk or a command line: the chat reads it from a
// pipe on its fd 3 (`--mcp-config /dev/fd/3`), which no other user can open.
//
// Without the users configured, or without the capabilities to switch to them, chats run as the agent as before, and the
// agent does not report `chat_user` in its hello: Escanor then never lets a chat run without prompts.
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { isAbsolute, join, relative, resolve } from 'node:path';
import type { SpawnOptions, SpawnedProcess } from '@anthropic-ai/claude-agent-sdk';

export type ChatUser = { uid: number; gid: number; home: string; configDir: string; workDir: string; tmpDir: string };
export type ChatUsers = { chat: ChatUser; appChat: ChatUser };

export const MCP_FD = 3;
const CAP_SETGID = 6;
const CAP_SETUID = 7;

function user(env: NodeJS.ProcessEnv, prefix: string): ChatUser | null {
  const uid = Number(env[`${prefix}_UID`]);
  const gid = Number(env[`${prefix}_GID`] ?? env[`${prefix}_UID`]);
  const home = env[`${prefix}_HOME`]?.trim();
  const configDir = env[`${prefix}_CONFIG_DIR`]?.trim();
  const workDir = env[`${prefix}_WORK_DIR`]?.trim();
  const tmpDir = env[`${prefix}_TMPDIR`]?.trim();
  if (!Number.isInteger(uid) || uid <= 0 || !Number.isInteger(gid) || gid <= 0 || !home || !configDir || !workDir || !tmpDir) return null;
  return { uid, gid, home, configDir, workDir: resolve(workDir), tmpDir };
}

/** The chat users from the environment (ESCANOR_CHAT_*, ESCANOR_APPCHAT_*); null unless both are fully set and share nothing. */
export function chatUsersFrom(env: NodeJS.ProcessEnv): ChatUsers | null {
  const chat = user(env, 'ESCANOR_CHAT');
  const appChat = user(env, 'ESCANOR_APPCHAT');
  if (!chat || !appChat || chat.uid === appChat.uid || chat.gid === appChat.gid) return null;
  for (const k of ['home', 'configDir', 'workDir', 'tmpDir'] as const) if (chat[k] === appChat[k]) return null;
  if (inside(chat.workDir, appChat.workDir) || inside(appChat.workDir, chat.workDir)) return null;
  return { chat, appChat };
}

function inside(root: string, path: string): boolean {
  const rel = relative(root, path);
  return rel === '' || (!rel.startsWith('..') && !isAbsolute(rel));
}

/** What the agent says it does in its hello (AgentHello.capabilities). */
export function helloCapabilities(chatUsers: ChatUsers | null): string[] {
  return ['isolated', ...(chatUsers ? ['chat_user'] : [])];
}

/** Can this process start another as a different user? (Effective CAP_SETUID and CAP_SETGID, from /proc/self/status.) */
export function canSwitchUsers(status = readStatus()): boolean {
  const line = status.split('\n').find((l) => l.startsWith('CapEff:'));
  if (!line) return false;
  const caps = BigInt(`0x${line.split(/\s+/)[1] ?? '0'}`);
  return ((caps >> BigInt(CAP_SETUID)) & 1n) === 1n && ((caps >> BigInt(CAP_SETGID)) & 1n) === 1n;
}

function readStatus(): string {
  try {
    return readFileSync('/proc/self/status', 'utf8');
  } catch {
    return '';
  }
}

/**
 * Where a chat of `chatUser` works: `cwd` (inside the agent's workspace) moved into that user's own work folder. A path already
 * inside it stays; anything else keeps its place relative to the workspace root (so `.` is the user's work folder itself).
 */
export function chatCwd(chatUser: ChatUser, workspaceRoot: string, cwd: string): string {
  if (inside(chatUser.workDir, cwd)) return cwd;
  const rel = relative(resolve(workspaceRoot), cwd);
  return rel && !rel.startsWith('..') && !isAbsolute(rel) ? join(chatUser.workDir, rel) : chatUser.workDir;
}

/** The command line that starts `command args` as `user` in `cwd`: no capability left, no supplementary group, and
 * `no_new_privs`, so a setuid program gives it nothing and it cannot switch back. The folder is entered after the switch
 * (`env --chdir`): a chat's folders are its user's alone, so the agent itself cannot enter them. */
export function asUser(chatUser: ChatUser, command: string, args: string[], cwd?: string): { command: string; args: string[] } {
  return {
    command: 'setpriv',
    args: [`--reuid=${chatUser.uid}`, `--regid=${chatUser.gid}`, '--clear-groups', '--inh-caps=-all', '--ambient-caps=-all', '--no-new-privs',
      '--', 'env', `--chdir=${cwd ?? chatUser.workDir}`, '--', command, ...args],
  };
}

export type SpawnDeps = { spawn?: typeof spawn };

/** Takes the MCP configuration (with its bearer tokens) off the command line the SDK built: `--mcp-config <json>` becomes
 * `--mcp-config /dev/fd/3`, and the json is returned to be written to that pipe. */
function mcpOffArgv(argv: string[]): { args: string[]; mcpConfig: string | null } {
  const args = [...argv];
  const at = args.indexOf('--mcp-config');
  if (at < 0 || typeof args[at + 1] !== 'string') return { args, mcpConfig: null };
  const mcpConfig = args[at + 1];
  args[at + 1] = `/dev/fd/${MCP_FD}`;
  return { args, mcpConfig };
}

// Node hands fd 3 over as a socket, which /dev/fd/3 cannot be opened on: a shell copies it into a real pipe (bash process
// substitution) that the CLI then reads as a file. No secret is on this command line.
const PIPE_SCRIPT = `exec "$0" "$@" ${MCP_FD}< <(cat <&${MCP_FD})`;

function startWithPipe(doSpawn: typeof spawn, command: string, args: string[], opts: { cwd: string; env: NodeJS.ProcessEnv; signal?: AbortSignal }, mcpConfig: string | null): SpawnedProcess {
  const child = doSpawn(command, args, { cwd: opts.cwd, env: opts.env, stdio: ['pipe', 'pipe', 'pipe', ...(mcpConfig !== null ? ['pipe' as const] : [])], signal: opts.signal });
  if (mcpConfig !== null) {
    const pipe = (child.stdio as unknown[])[MCP_FD] as NodeJS.WritableStream | null | undefined;
    pipe?.on?.('error', () => {}); // a chat that exits before reading it must not take the agent down
    pipe?.end(mcpConfig);
  }
  // Nobody else reads the CLI's stderr when the agent starts it: drain it, so a chatty CLI never blocks on a full pipe.
  (child.stderr as { resume?: () => void } | null | undefined)?.resume?.();
  return child as unknown as SpawnedProcess;
}

/** The SDK's `spawnClaudeCodeProcess` for a chat run as `chatUser`. The MCP configuration the SDK put on the command line is
 * handed over on a pipe instead (fd 3), so neither a file nor any process's command line ever holds it. */
export function chatSpawner(chatUser: ChatUser, deps: SpawnDeps = {}): (o: SpawnOptions) => SpawnedProcess {
  const doSpawn = deps.spawn ?? spawn;
  return (o) => {
    const { args, mcpConfig } = mcpOffArgv(o.args);
    const line = mcpConfig === null
      ? asUser(chatUser, o.command, args, o.cwd)
      : asUser(chatUser, 'bash', ['-c', PIPE_SCRIPT, o.command, ...args], o.cwd);
    const env = { ...o.env, HOME: chatUser.home, CLAUDE_CONFIG_DIR: chatUser.configDir, TMPDIR: chatUser.tmpDir, USER: undefined, LOGNAME: undefined };
    return startWithPipe(doSpawn, line.command, line.args, { cwd: '/', env: env as NodeJS.ProcessEnv, signal: o.signal }, mcpConfig);
  };
}

/** The same for a chat run as the agent's own user (a person's own machine): the machine's Escanor MCP key would otherwise sit
 * on the Claude process's command line, which any local user reads with `ps` and `systemctl --user status` prints. */
export function ownUserSpawner(deps: SpawnDeps = {}): (o: SpawnOptions) => SpawnedProcess {
  const doSpawn = deps.spawn ?? spawn;
  return (o) => {
    const { args, mcpConfig } = mcpOffArgv(o.args);
    const env = o.env as NodeJS.ProcessEnv;
    return mcpConfig === null
      ? startWithPipe(doSpawn, o.command, args, { cwd: o.cwd ?? process.cwd(), env, signal: o.signal }, null)
      : startWithPipe(doSpawn, 'bash', ['-c', PIPE_SCRIPT, o.command, ...args], { cwd: o.cwd ?? process.cwd(), env, signal: o.signal }, mcpConfig);
  };
}
