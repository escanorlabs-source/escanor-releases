import { createServer, connect, type Server } from 'node:net';
import { chmodSync, existsSync, unlinkSync } from 'node:fs';

/**
 * This computer (a laptop, or a headless server) lists the owner's other devices and hands them work: "what devices do I have", "open
 * example.com on my desktop", "send this to my laptop", "continue this chat on my laptop", "ask my server how the disk is".
 *
 * It calls Escanor's backend (POST /agent/device/mesh) signed in with this machine's own hub token, the way its device MCP key and
 * speech to text are asked for. The backend only shows this owner's own devices, never lets a machine aim at itself, uses the same
 * fixed action list and size limits as voice, and puts every change through the Guardian: a change it wants a person's yes for comes
 * back as "asked" and runs nothing until that person says yes on a device. Nothing here acts on its own.
 *
 * A chat's `devices` tool (computerMcp.ts) reaches this over an owner-only socket in the data folder (like phoneAsk.ts), so the hub
 * token stays in the agent.
 */

export const MESH_SOCKET_NAME = 'mesh-ask.sock';
export const MESH_OPS = ['list', 'command', 'handoff', 'ask'] as const;
export const MESH_COMPUTER_ACTIONS = ['open_url', 'open_app', 'play_youtube', 'media', 'volume', 'lock_screen', 'compose_mail', 'show'] as const;
/** What a phone may be asked (the hub's fixed list; the phone's own switch decides) and what a watch is shown, said or rung with. */
export const MESH_PHONE_ACTIONS = ['status', 'battery', 'ring', 'stop_ring', 'torch', 'media', 'receive_link', 'open_link', 'open_app', 'notify'] as const;
export const MESH_WATCH_ACTIONS = ['notify', 'talk', 'ring'] as const;
export const MESH_ACTIONS = [...new Set<string>([...MESH_COMPUTER_ACTIONS, ...MESH_PHONE_ACTIONS, ...MESH_WATCH_ACTIONS])];
export const MESH_KINDS = ['link', 'text', 'reading', 'chat'] as const;

export type MeshRequest =
  | { op: 'list' }
  | { op: 'command'; device: string; action: string; args: Record<string, unknown> }
  | { op: 'handoff'; to: string; kind: string; payload: Record<string, unknown> }
  | { op: 'ask'; device: string; task: string };

export type MeshDevice = { id: string; name: string; kind: string; online: boolean; state: string; words: string; can_run_actions: boolean; is_this_device: boolean };
export type MeshReply = { ok: boolean; say: string; outcome?: 'allow' | 'ask' | 'hold' | 'deny'; devices?: MeshDevice[] };
export type MeshConn = { apiUrl: string; hubToken: string; vmName: string; agentVersion: string };

const MAX_LINE = 400_000;
const TIMEOUT_MS = 45_000; // the backend waits up to 20 s for another computer's answer to a job

const str = (v: unknown, n: number): string => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);

/** What a tool call or a spoken sentence asks, checked: the reason in plain words when it is not something that can be done. */
export function parseMeshRequest(raw: unknown): { ok: true; req: MeshRequest } | { ok: false; error: string } {
  const o = isObj(raw) ? raw : {};
  const op = o.op;
  if (typeof op !== 'string' || !(MESH_OPS as readonly string[]).includes(op)) return { ok: false, error: `op must be one of ${MESH_OPS.join(', ')}.` };
  if (op === 'list') return { ok: true, req: { op: 'list' } };
  if (op === 'command') {
    const device = str(o.device, 200);
    const action = str(o.action, 40);
    if (!device) return { ok: false, error: 'Say which device (for example "desktop" or "server").' };
    if (!(MESH_ACTIONS as readonly string[]).includes(action)) return { ok: false, error: `A device can be told to: ${MESH_ACTIONS.join(', ')}.` };
    return { ok: true, req: { op: 'command', device, action, args: isObj(o.args) ? o.args : {} } };
  }
  if (op === 'handoff') {
    const to = str(o.to, 200);
    const kind = str(o.kind, 20);
    if (!to) return { ok: false, error: 'Say which device to hand it to.' };
    if (!(MESH_KINDS as readonly string[]).includes(kind)) return { ok: false, error: `kind must be one of ${MESH_KINDS.join(', ')}.` };
    const payload = isObj(o.payload) ? o.payload : {};
    if (kind === 'link' && !/^https?:\/\/[^\s]{1,2000}$/i.test(str(payload.url, 2100))) return { ok: false, error: 'A link must start with http:// or https://.' };
    return { ok: true, req: { op: 'handoff', to, kind, payload } };
  }
  const device = str(o.device, 200);
  const task = str(o.task, 1000);
  if (!device || !task) return { ok: false, error: 'Say which computer or server, and what to ask it.' };
  return { ok: true, req: { op: 'ask', device, task } };
}

/** What went wrong, in the words said out loud. */
export function meshProblem(status: number, body: unknown): string {
  const o = isObj(body) ? body : {};
  const reason = typeof o.reason === 'string' ? o.reason : '';
  const say = typeof o.say === 'string' ? o.say : typeof o.message === 'string' ? o.message : '';
  if (reason === 'unauthorized' || status === 401) return 'This computer is not signed in to Escanor, so it cannot reach your other devices.';
  if (reason === 'unavailable' || (status === 404 && !say)) return 'Reaching your other devices is not available for this computer right now.';
  if (status === 423) return 'This workspace is paused.';
  if (status === 429) return 'Too many device requests just now. Try again in a minute.';
  if (status === 413) return 'That was too large to send.';
  return say || 'I could not reach your other devices just now. Try again in a moment.';
}

/** One request to the backend. Never throws. */
export async function meshRequest(conn: MeshConn, req: MeshRequest, opts: { fetchImpl?: typeof fetch } = {}): Promise<MeshReply> {
  const doFetch = opts.fetchImpl ?? fetch;
  let res: Response;
  try {
    res = await doFetch(`${conn.apiUrl}/agent/device/mesh`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${conn.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${conn.agentVersion}` },
      body: JSON.stringify({ ...req, vm_name: conn.vmName }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch {
    return { ok: false, say: 'I could not reach Escanor to ask about your other devices. Check the internet connection.' };
  }
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  const o = isObj(body) ? body : {};
  const outcome = typeof o.outcome === 'string' && ['allow', 'ask', 'hold', 'deny'].includes(o.outcome) ? (o.outcome as MeshReply['outcome']) : undefined;
  if (outcome === 'ask') return { ok: false, outcome, say: `${str(o.say, 300) || 'This needs your yes.'} Waiting for your yes in the Escanor app on your phone or desktop; nothing has been done yet.` };
  if (outcome === 'hold') return { ok: false, outcome, say: `${str(o.say, 300)} It is waiting for the owner, nothing has been done yet.`.trim() };
  if (outcome === 'deny') return { ok: false, outcome, say: str(o.say, 300) || 'That is not allowed here.' };
  if (!res.ok) return { ok: false, say: meshProblem(res.status, body) };
  const say = str(o.say, 700);
  if (req.op === 'list') {
    const devices = Array.isArray(o.devices) ? (o.devices.filter((d) => isObj(d) && typeof d.id === 'string' && typeof d.name === 'string') as MeshDevice[]) : [];
    return { ok: true, say: say || 'No other devices yet.', devices };
  }
  return { ok: o.ok === true, say: say || (o.ok === true ? 'Done.' : 'That did not work.'), ...(outcome ? { outcome } : {}) };
}

/** The chat's side: one line out, one line back. Never throws. */
export function askMeshAgent(sockPath: string, req: unknown, timeoutMs = 50_000, caller = ''): Promise<MeshReply> {
  const fail = (say: string): MeshReply => ({ ok: false, say });
  if (!sockPath) return Promise.resolve(fail('This computer is not set up to reach your other devices yet.'));
  return new Promise((resolve) => {
    let done = false;
    let buf = '';
    const finish = (r: MeshReply) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      c.destroy();
      resolve(r);
    };
    const c = connect(sockPath);
    const timer = setTimeout(() => finish(fail('Your other devices did not answer in time.')), timeoutMs);
    c.setEncoding('utf8');
    c.on('connect', () => c.write(`${JSON.stringify(caller && isObj(req) ? { ...req, caller } : req)}\n`));
    c.on('data', (d: string) => {
      buf += d;
      if (buf.length > MAX_LINE) return finish(fail('The answer was too long.'));
      const nl = buf.indexOf('\n');
      if (nl < 0) return;
      try {
        const j = JSON.parse(buf.slice(0, nl)) as MeshReply;
        finish({ ok: j.ok === true, say: typeof j.say === 'string' ? j.say.slice(0, 800) : '', ...(j.outcome ? { outcome: j.outcome } : {}), ...(Array.isArray(j.devices) ? { devices: j.devices } : {}) });
      } catch {
        finish(fail('The answer could not be read.'));
      }
    });
    c.on('error', () => finish(fail('This computer is not connected to Escanor right now, so it cannot reach your other devices.')));
  });
}

/** The agent's side: an owner-only socket; [answer] puts the checked request to the backend. */
export function serveMeshAsk(sockPath: string, answer: (r: MeshRequest, caller: string) => Promise<MeshReply>): Server | null {
  if (sockPath.length > 100) return null;
  try {
    if (existsSync(sockPath)) unlinkSync(sockPath); // our own stale socket file from a crashed run, and only that exact path
  } catch {
    return null;
  }
  const server = createServer((c) => {
    let buf = '';
    c.setEncoding('utf8');
    c.on('data', (d: string) => {
      buf += d;
      if (buf.length > MAX_LINE) return void c.destroy();
      const nl = buf.indexOf('\n');
      if (nl < 0) return;
      const line = buf.slice(0, nl);
      buf = '';
      void (async () => {
        let out: MeshReply;
        try {
          const raw: unknown = JSON.parse(line);
          const p = parseMeshRequest(raw);
          out = p.ok ? await answer(p.req, isObj(raw) ? str(raw.caller, 80) : '') : { ok: false, say: p.error };
        } catch {
          out = { ok: false, say: 'The request could not be read.' };
        }
        c.end(`${JSON.stringify(out)}\n`);
      })();
    });
    c.on('error', () => {});
  });
  server.on('error', () => {});
  try {
    server.listen(sockPath, () => {
      try {
        chmodSync(sockPath, 0o600);
      } catch {
        /* best effort */
      }
    });
  } catch {
    return null;
  }
  return server;
}
