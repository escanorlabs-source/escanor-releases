import { chmodSync, existsSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, unlinkSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { AgentToHubMessage, HubUserInput } from '@remote-harness/shared';
import type { ClaudeProc } from './claudeProcs.js';
import { AGENT_CHAT_ENV } from './childEnv.js';

/**
 * Phone → terminal: a message sent from the app to a chat that is open in a terminal on this computer goes into that same
 * terminal chat, so the phone and the PC are one conversation (no second Claude on the transcript, nothing forks).
 *
 * How: Claude Code's own hooks. The agent adds two hooks to the user's Claude Code settings (SessionStart and Stop, both
 * `asyncRewake`): each starts a tiny waiter (HOOK_SCRIPT) in the background of every terminal chat, which sleeps until the agent
 * drops a message for that chat into its inbox folder, then hands it to Claude and exits with code 2, which wakes the chat
 * (idle or not) with the message as the user's. The next Stop starts the next waiter. A chat that is busy picks the message up
 * when its turn ends, like a message typed while it works. Claude's answer reaches the phone the usual way (terminal sync).
 *
 * The hooks live in user settings, so every Claude on the machine runs them, the agent's own SDK chats too. There the waiter
 * must not run: in an SDK (stream-json) session the SessionStart hook holds the session up until it exits, so the chat never
 * starts (Claude Code runs an asyncRewake hook in the foreground when it is not interactive; 2.1.300 also backgrounds it for
 * streaming input, the SDK's 2.1.295 does not). The agent marks its chats (AGENT_CHAT_ENV, childEnv.ts) and the waiter also
 * skips any Claude run with `--input-format stream-json` or `-p`/`--print`.
 */

/** In every hook command the agent owns, so it can find (and update or remove) its own entries and leave the rest alone. */
export const HOOK_MARK = 'escanor-phone-inbox';
/** Put before the message Claude is woken with: says who wrote it. Also how the transcript line is recognised (isPhoneLine). */
export const PHONE_PREFIX = '[Escanor] The user sent this from the Escanor app on their phone, into this same chat. Treat it exactly like a message typed here and answer here:\n';
/** One line shown in the terminal when a phone message arrives. */
const SUMMARY = 'Message from your phone (Escanor)';
/** A waiter lives at most this long (seconds); a chat left idle longer gets its next waiter after its next turn. */
const WAIT_SECONDS = 7 * 24 * 3600;
const POLL_MS = 1_000;

/**
 * The waiter. POSIX sh, no dependencies: one per terminal chat, sleeping in a 1 s loop. Only the newest waiter of a chat stays
 * (the pid file); it exits quietly when its Claude process is gone (Claude does not stop background hooks it leaves behind).
 * A message is claimed by renaming it first, so it is handed over once even if two waiters overlap for a moment.
 */
export const HOOK_SCRIPT = `#!/bin/sh
# ${HOOK_MARK}: lets the Escanor phone app send messages into this terminal chat. Installed by the Escanor agent.
dir="$1"
in=$(cat)
# Not for the agent's own chats (SDK): there a SessionStart waiter holds the session up until a phone message comes.
[ -n "$${AGENT_CHAT_ENV}" ] && exit 0
sid=$(printf '%s' "$in" | tr -d '\\n' | sed -n 's/.*"session_id"[[:space:]]*:[[:space:]]*"\\([0-9A-Za-z_-]\\{1,80\\}\\)".*/\\1/p')
[ -n "$dir" ] && [ -n "$sid" ] || exit 0
box="$dir/$sid"
# The Claude process this chat runs in: climb past the shells that only wrap this script.
owner=$PPID
for _ in 1 2 3; do
  case "$(cat /proc/$owner/comm 2>/dev/null)" in
    sh|bash|dash|zsh) up=$(sed 's/.*) //' /proc/$owner/stat 2>/dev/null | cut -d' ' -f2); [ -n "$up" ] && owner=$up ;;
    *) break ;;
  esac
done
# Nor for any other Claude that is not an interactive terminal chat: driven over stream-json (SDK or automation callers, IDE
# panels) or one-shot (-p/--print). Such a Claude runs this hook in the foreground and would wait here instead of starting.
tr '\\0' '\\n' 2>/dev/null < /proc/$owner/cmdline | awk '$0=="-p"||$0=="--print"||$0=="--input-format=stream-json"||(p&&$0=="stream-json"){f=1} {p=($0=="--input-format")} END{exit !f}' && exit 0
mkdir -p "$box" 2>/dev/null || exit 0
echo $$ > "$box/waiter"
echo "$owner" > "$box/hooked"
while :; do
  [ "$(cat "$box/waiter" 2>/dev/null)" = "$$" ] || exit 0
  kill -0 "$owner" 2>/dev/null || exit 0
  n=0
  for f in "$box"/*.msg; do
    [ -e "$f" ] || continue
    t="$f.$$.taken"
    if mv "$f" "$t" 2>/dev/null; then
      [ $n -gt 0 ] && printf '\\n\\n' >&2
      cat "$t" >&2
      rm -f "$t"
      n=$((n+1))
    fi
  done
  [ $n -gt 0 ] && exit 2
  sleep 1
done
`;

type HookEntry = { type: 'command'; command: string; asyncRewake: true; timeout: number; rewakeMessage: string; rewakeSummary: string };
type Settings = { hooks?: Record<string, Array<{ matcher?: string; hooks?: Array<Record<string, unknown>> }>> } & Record<string, unknown>;

const quote = (s: string) => `'${s.replace(/'/g, `'\\''`)}'`;

export function claudeSettingsFile(env: NodeJS.ProcessEnv = process.env): string {
  return join(env.CLAUDE_CONFIG_DIR?.trim() || join(homedir(), '.claude'), 'settings.json');
}

/** The hooks object with the agent's entries set (enabled) or taken out (disabled); everything else is kept as it was. */
export function withPhoneHooks(settings: Settings, entry: HookEntry | null): Settings {
  const hooks: NonNullable<Settings['hooks']> = { ...(settings.hooks ?? {}) };
  for (const event of ['SessionStart', 'Stop']) {
    const groups = (hooks[event] ?? [])
      .map((g) => ({ ...g, hooks: (g.hooks ?? []).filter((h) => !String(h.command ?? '').includes(HOOK_MARK)) }))
      .filter((g) => g.hooks.length > 0);
    if (entry) groups.push({ hooks: [{ ...entry }] });
    if (groups.length > 0) hooks[event] = groups;
    else delete hooks[event];
  }
  const out: Settings = { ...settings, hooks };
  if (Object.keys(hooks).length === 0) delete out.hooks;
  return out;
}

/**
 * Writes the waiter script and adds (or, with enabled = false, removes) the hooks in Claude Code's user settings. Leaves a
 * settings file it cannot read as JSON alone. Returns what it did, for the log.
 */
export function installPhoneHooks(o: { dataDir: string; inboxDir: string; enabled: boolean; settingsFile?: string }): string {
  const file = o.settingsFile ?? claudeSettingsFile();
  let settings: Settings = {};
  let before = '';
  if (existsSync(file)) {
    before = readFileSync(file, 'utf8');
    try {
      const parsed = before.trim() ? JSON.parse(before) : {};
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return `not touched: ${file} is not a settings object`;
      settings = parsed;
    } catch {
      return `not touched: ${file} is not valid JSON`;
    }
  }
  let entry: HookEntry | null = null;
  if (o.enabled) {
    const hooksDir = join(o.dataDir, 'hooks');
    mkdirSync(hooksDir, { recursive: true });
    mkdirSync(o.inboxDir, { recursive: true, mode: 0o700 });
    const script = join(hooksDir, `${HOOK_MARK}.sh`);
    if (!existsSync(script) || readFileSync(script, 'utf8') !== HOOK_SCRIPT) writeFileSync(script, HOOK_SCRIPT, { mode: 0o755 });
    chmodSync(script, 0o755);
    entry = {
      type: 'command',
      command: `sh ${quote(script)} ${quote(o.inboxDir)}`,
      asyncRewake: true,
      timeout: WAIT_SECONDS,
      rewakeMessage: PHONE_PREFIX,
      rewakeSummary: SUMMARY,
    };
  }
  const next = withPhoneHooks(settings, entry);
  const text = `${JSON.stringify(next, null, 2)}\n`;
  if (before && JSON.stringify(JSON.parse(before)) === JSON.stringify(next)) return 'already set';
  if (!before && !entry) return 'nothing to remove';
  mkdirSync(join(file, '..'), { recursive: true });
  const tmp = `${file}.escanor-${process.pid}.tmp`;
  writeFileSync(tmp, text, { mode: existsSync(file) ? statSync(file).mode & 0o777 : 0o600 });
  renameSync(tmp, file);
  return entry ? `phone → terminal hooks set in ${file}` : `phone → terminal hooks removed from ${file}`;
}

/** A transcript line that is a phone message handed to a terminal chat (the hub has it already, from the phone). */
export function isPhoneLine(message: unknown): boolean {
  const m = message as { type?: string; message?: { content?: unknown } } | null;
  if (m?.type !== 'user') return false;
  const c = m.message?.content;
  const text = typeof c === 'string' ? c : Array.isArray(c) ? c.map((b) => (b && typeof b === 'object' && 'text' in b ? String(b.text) : '')).join('') : '';
  return text.includes(PHONE_PREFIX.split('\n')[0]);
}

type Pending = { input: HubUserInput; file: string };
let dropSeq = 0;

/** Said once for a message held for a terminal chat that cannot take one yet. */
export const HELD_FOR_TERMINAL =
  'Queued: this chat is open in a terminal on your computer and cannot take a message this moment. It gets yours as soon as it can, without stopping what it is doing.';

export class TerminalInbox {
  private pending: Pending[] = [];
  /** Messages for a terminal chat that is open but cannot take one yet (no waiter in it right now): handed over once it can. */
  private held: HubUserInput[] = [];
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private o: {
      dir: string;
      send: (msg: AgentToHubMessage) => void;
      /** Claude processes open on this machine, by session id. */
      procs: () => Map<string, ClaudeProc>;
      /** A message whose terminal closed before it was picked up: the agent runs it itself (the chat is no longer open). */
      readmit: (input: HubUserInput) => void;
      pollMs?: number;
    },
  ) {}

  /** Does this chat's open terminal Claude run the waiter (so a message dropped here reaches it)? */
  canReach(sessionId: string): boolean {
    const proc = this.o.procs().get(sessionId);
    if (!proc) return false;
    try {
      return Number(readFileSync(join(this.o.dir, sessionId, 'hooked'), 'utf8').trim()) === proc.pid;
    } catch {
      return false;
    }
  }

  /**
   * Hands the message to the terminal chat, never stopping what it does. One open but unable to take it this moment (its waiter
   * starts at its next Stop) is held here and handed over once it can, or run by the agent once its terminal closes. False only
   * when no terminal has this chat open (the caller handles it).
   */
  deliver(input: HubUserInput): boolean {
    const sid = input.sessionId;
    if (!/^[0-9A-Za-z_-]{1,80}$/.test(sid)) return false;
    // Behind an earlier held message for the same chat it waits too, so the terminal gets them in the order they were sent.
    const behind = this.held.some((h) => h.sessionId === sid);
    if (behind || !this.canReach(sid)) {
      if (!behind && !this.o.procs().has(sid)) return false;
      this.held.push(input);
      this.ack(input, 'queued');
      if (!input.inputId?.startsWith('agent:')) this.o.send({ type: 'error', kind: 'notice', sessionId: sid, message: HELD_FOR_TERMINAL });
      this.arm();
      return true;
    }
    return this.drop(input);
  }

  private drop(input: HubUserInput, ack = true): boolean {
    const sid = input.sessionId;
    const box = join(this.o.dir, sid);
    const images = input.images?.length ?? 0;
    const note = images > 0 ? `\n\n[${images} image${images === 1 ? '' : 's'} attached on the phone could not be passed to the terminal.]` : '';
    // Picked up in name order (the waiter's glob): a counter keeps messages written in the same millisecond in order.
    const name = `${String(Date.now()).padStart(15, '0')}-${String(++dropSeq % 1_000_000).padStart(6, '0')}-${randomUUID().slice(0, 8)}.msg`;
    const file = join(box, name);
    try {
      mkdirSync(box, { recursive: true, mode: 0o700 });
      const tmp = join(box, `.${name}.tmp`);
      writeFileSync(tmp, `${input.text}${note}`, { mode: 0o600 });
      renameSync(tmp, file);
    } catch (err) {
      console.error(`[terminal-inbox] ${sid}: ${err instanceof Error ? err.message : err}`);
      return false;
    }
    this.pending.push({ input, file });
    if (ack) this.ack(input, 'queued');
    this.arm();
    return true;
  }

  /** Looks at every message not picked up yet: taken = delivered; its terminal closed = the agent runs it instead. */
  check(): void {
    const procs = this.o.procs();
    const left: Pending[] = [];
    const readmit: HubUserInput[] = [];
    const held = this.held;
    this.held = [];
    for (const input of held) {
      const sid = input.sessionId;
      if (!procs.has(sid)) readmit.push(input); // its terminal closed: the agent runs it
      // In order: once one for a chat stays held, the later ones for it stay behind it.
      else if (this.held.some((h) => h.sessionId === sid) || !this.canReach(sid) || !this.drop(input, false)) this.held.push(input);
    }
    for (const p of this.pending) {
      if (!existsSync(p.file)) {
        this.ack(p.input, 'delivered');
        continue;
      }
      if (procs.has(p.input.sessionId)) {
        left.push(p);
        continue;
      }
      try {
        unlinkSync(p.file); // the terminal was closed: take the message back
        readmit.push(p.input);
      } catch {
        this.ack(p.input, 'delivered'); // a waiter took it just now
      }
    }
    this.pending = left;
    if (this.pending.length === 0 && this.held.length === 0 && this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    for (const input of readmit) this.o.readmit(input);
  }

  /** Inbox folders of chats whose Claude is gone (messages in them were never picked up and are not waited for). */
  sweep(): void {
    let names: string[];
    try {
      names = readdirSync(this.o.dir);
    } catch {
      return;
    }
    const procs = this.o.procs();
    const waited = new Set(this.pending.map((p) => p.input.sessionId));
    for (const sid of names) {
      if (procs.has(sid) || waited.has(sid)) continue;
      rmSync(join(this.o.dir, sid), { recursive: true, force: true });
    }
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private arm(): void {
    if (this.timer) return;
    this.timer = setInterval(() => this.check(), this.o.pollMs ?? POLL_MS);
    this.timer.unref();
  }

  private ack(input: HubUserInput, status: 'delivered' | 'queued'): void {
    if (input.inputId?.startsWith('agent:')) return; // the agent's own message (AUTORESUME): no phone waits for it
    this.o.send({ type: 'input_ack', sessionId: input.sessionId, ...(input.inputId ? { inputId: input.inputId } : {}), status });
  }
}
