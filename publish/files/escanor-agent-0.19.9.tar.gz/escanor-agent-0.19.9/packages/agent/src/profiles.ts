import { existsSync, readdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { join } from 'node:path';
import type { AccountProvider, ClaudeAccount } from '@remote-harness/shared';

export type ClaudeProfile = ClaudeAccount & {
  configDir?: string; // undefined means "use whatever is already logged in on this machine"
  /** 'key': the account runs on an API key kept in its folder (API_KEY_FILE), not a sign-in. */
  method?: 'signin' | 'key';
};

const DEFAULT_PROFILE: ClaudeProfile = { id: 'default', label: 'default', configDir: undefined };

/** In a profile folder: the name the person gave the account (and the email it signed in with), written when it is added from the phone. */
export const ACCOUNT_META_FILE = '.escanor-account.json';
/** In a profile folder while its sign-in is not finished: such a folder is not an account yet. */
export const PENDING_MARK = '.escanor-pending';
/**
 * In the profiles folder: the machine's own login (the one Claude uses with no profile) stays listed next to added accounts.
 * Written when the first account is added from the phone on a machine that only had its own login, so that one is not lost.
 */
export const KEEP_DEFAULT_FILE = '.escanor-default.json';
/** In an account folder added with an API key: the key (0600), handed to that account's chats only. */
export const API_KEY_FILE = '.escanor-api-key';

type Meta = { label?: unknown; email?: unknown; provider?: unknown; method?: unknown };

const PROVIDERS: readonly AccountProvider[] = ['claude', 'chatgpt', 'gemini', 'copilot'];
const EMAIL_MAX = 320;

/** Which AI an account is: from its folder's meta, else from its id (`chatgpt-` / `gemini-` / `copilot-`), else Claude. */
export function providerFromId(id: string): AccountProvider {
  if (id.startsWith('chatgpt-')) return 'chatgpt';
  if (id.startsWith('gemini-')) return 'gemini';
  if (id.startsWith('copilot-')) return 'copilot';
  return 'claude';
}

/** The machine's default account: the first Claude one, else the first of any. */
export function defaultProfile<T extends Pick<ClaudeProfile, 'provider'>>(profiles: T[]): T {
  return profiles.find((p) => providerOf(p) === 'claude') ?? profiles[0];
}

/** The AI a profile runs on ('claude' when it says nothing). */
export function providerOf(p: Pick<ClaudeProfile, 'provider'> | undefined): AccountProvider {
  return p?.provider ?? 'claude';
}

/**
 * The AI an account id belongs to: the listed profile's own provider, else what its id says (an account removed since keeps its
 * chats recognisable). Claude-only work (usage reading, transcript reading, small-chat cleanup) runs only for 'claude'.
 */
export function providerForAccount(profiles: ClaudeProfile[], accountId: string | undefined): AccountProvider {
  const p = profiles.find((x) => x.id === accountId);
  return p ? providerOf(p) : providerFromId(accountId ?? '');
}

/** The API key an account added with one keeps in its folder (API_KEY_FILE), or null. */
export function readAccountKey(configDir: string): string | null {
  try {
    const k = readFileSync(join(configDir, API_KEY_FILE), 'utf8').trim();
    return k || null;
  } catch {
    return null;
  }
}

/** The account as the hub and apps see it: no folder, provider only when it is not Claude, email when known. */
export function toAccount(p: ClaudeProfile): ClaudeAccount {
  return { id: p.id, label: p.label, ...(p.provider && p.provider !== 'claude' ? { provider: p.provider } : {}), ...(p.email ? { email: p.email } : {}) };
}

function readMeta(file: string): Meta | null {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
    return j && typeof j === 'object' ? (j as Meta) : null;
  } catch {
    return null;
  }
}

function labelFrom(meta: Meta | null, fallback: string): string {
  const l = typeof meta?.label === 'string' ? meta.label.trim() : '';
  return l ? l.slice(0, 60) : fallback;
}

export type DiscoverOptions = {
  /**
   * The machine's own Claude config folder (normally ~/.claude). When it holds a sign-in and is not already one of the profile folders
   * (or a link to one), it is listed too, as "default": every Claude account signed in on this computer shows in the apps.
   */
  defaultLoginDir?: string | null;
};

let moduleDefaultLoginDir: string | null = null;
/** Set once at start: every later look at the profiles (discoverProfiles / refreshProfiles) also counts the machine's own login there. */
export function setDefaultLoginDir(dir: string | null): void {
  moduleDefaultLoginDir = dir;
}

const real = (p: string): string => {
  try {
    return realpathSync(p);
  } catch {
    return p;
  }
};

/** True when [dir] holds a Claude sign-in (looks only that the file is there; it is never read). */
export function hasClaudeSignIn(dir: string): boolean {
  return existsSync(join(dir, '.credentials.json'));
}

export function discoverProfiles(profilesDir: string, opts: DiscoverOptions = {}): ClaudeProfile[] {
  const dl = opts.defaultLoginDir !== undefined ? opts.defaultLoginDir : moduleDefaultLoginDir;
  const own = dl && hasClaudeSignIn(dl) ? dl : null;
  if (!existsSync(profilesDir)) return [DEFAULT_PROFILE];
  const keepDefault = readMeta(join(profilesDir, KEEP_DEFAULT_FILE));
  const defaultProfile: ClaudeProfile = { ...DEFAULT_PROFILE, label: labelFrom(keepDefault, DEFAULT_PROFILE.label) };
  // statSync follows symlinks, so a profile entry may be a real directory or
  // a symlink to an existing config dir elsewhere (e.g. one you already use
  // via a shell alias like `claude1='CLAUDE_CONFIG_DIR=~/.claude-account-1 claude'`).
  // Hidden entries are the agent's own (removed accounts, markers) and a folder whose sign-in is not finished is skipped.
  const dirs = readdirSync(profilesDir)
    .filter((name) => {
      if (name.startsWith('.')) return false;
      try {
        return statSync(join(profilesDir, name)).isDirectory() && !existsSync(join(profilesDir, name, PENDING_MARK));
      } catch {
        return false;
      }
    })
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  if (dirs.length === 0) return [defaultProfile];
  const found = dirs.map((id): ClaudeProfile => {
    const meta = readMeta(join(profilesDir, id, ACCOUNT_META_FILE));
    const provider = typeof meta?.provider === 'string' && (PROVIDERS as readonly string[]).includes(meta.provider) ? (meta.provider as AccountProvider) : providerFromId(id);
    const email = typeof meta?.email === 'string' && meta.email.length <= EMAIL_MAX && meta.email.includes('@') ? meta.email : undefined;
    return {
      id,
      label: labelFrom(meta, id),
      ...(provider !== 'claude' ? { provider } : {}),
      ...(email ? { email } : {}),
      ...(meta?.method === 'key' ? { method: 'key' as const } : {}),
      configDir: join(profilesDir, id),
    };
  });
  // Claude accounts first (in their own order): the first account is the machine's default, and that is always a Claude one
  // when there is one (new chats with no account named, terminal chats).
  const ordered = [...found.filter((p) => providerOf(p) === 'claude'), ...found.filter((p) => providerOf(p) !== 'claude')];
  // The machine's own login stays listed when it was kept (KEEP_DEFAULT_FILE) or is signed in and no profile folder is that same login.
  const ownIsListed = own ? found.some((p) => p.configDir && real(p.configDir) === real(own)) : false;
  const showDefault = !dirs.includes(DEFAULT_PROFILE.id) && (!!keepDefault || (!!own && !ownIsListed));
  return showDefault ? [defaultProfile, ...ordered] : ordered;
}

/** What the hub and apps would be told about these profiles: two lists with the same text need no new announcement. */
export function accountsSignature(profiles: ClaudeProfile[]): string {
  return JSON.stringify(profiles.map((p) => [toAccount(p), p.configDir ?? null]));
}

/**
 * Looks again and makes [profiles] match, in place: the session manager and the usage reader hold this same array, so an
 * account added or removed from the phone is used at once, without a restart.
 */
export function refreshProfiles(profiles: ClaudeProfile[], profilesDir: string, opts: DiscoverOptions = {}): ClaudeProfile[] {
  profiles.splice(0, profiles.length, ...discoverProfiles(profilesDir, opts));
  return profiles;
}
