/**
 * Speech to text for push-to-talk on this computer: the recorded sentence goes to Escanor's backend (Groq Whisper) signed in with
 * this machine's own hub token, the way its device MCP key is asked for. Only for a computer on Escanor's hosted hub (or an API
 * named with ESCANOR_API_URL): a self-hosted hub's token is never sent to Escanor. The audio is not kept anywhere.
 */

export type TranscribeConn = { apiUrl: string; hubToken: string; vmName: string; agentVersion: string };

export type Transcript = { ok: true; text: string } | { ok: false; say: string };

const TIMEOUT_MS = 30_000;

/** What went wrong, in the words said out loud. */
export function transcribeProblem(status: number, body: unknown): string {
  const detail = body && typeof body === 'object' && typeof (body as { detail?: unknown }).detail === 'string' ? ((body as { detail: string }).detail) : '';
  const reason = body && typeof body === 'object' && typeof (body as { reason?: unknown }).reason === 'string' ? ((body as { reason: string }).reason) : '';
  if (status === 402) return 'Your workspace is out of credits for voice. Typing still works.';
  if (status === 401 || reason === 'unauthorized') return 'This computer is not signed in to Escanor, so I cannot turn speech into text.';
  if (status === 404 || reason === 'unavailable') return 'Voice is not available for this computer right now.';
  if (status === 413) return 'That was too long. Keep it under two minutes.';
  if (status === 423) return 'This workspace is paused.';
  if (status === 429) return 'Too many voice requests just now. Try again in a minute.';
  if (detail) return detail;
  return 'I could not turn that into text just now. Try again in a moment.';
}

export async function transcribe(conn: TranscribeConn, wav: Buffer, opts: { fetchImpl?: typeof fetch; seconds?: number } = {}): Promise<Transcript> {
  const doFetch = opts.fetchImpl ?? fetch;
  const form = new FormData();
  form.append('file', new Blob([new Uint8Array(wav)], { type: 'audio/wav' }), 'speech.wav');
  if (opts.seconds !== undefined) form.append('duration_seconds', String(Math.round(opts.seconds * 10) / 10));
  let res: Response;
  try {
    res = await doFetch(`${conn.apiUrl}/agent/device/voice/transcribe`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${conn.hubToken}`, 'User-Agent': `escanor-agent/${conn.agentVersion}` },
      body: form,
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch {
    return { ok: false, say: 'I could not reach Escanor to turn that into text. Check the internet connection.' };
  }
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (!res.ok) return { ok: false, say: transcribeProblem(res.status, body) };
  const text = body && typeof body === 'object' && typeof (body as { text?: unknown }).text === 'string' ? (body as { text: string }).text.trim() : '';
  return { ok: true, text };
}
