import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { chmodSync, closeSync, constants as fsc, mkdtempSync, openSync, rmdirSync, unlinkSync, writeFileSync, writeSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { StringDecoder } from 'node:string_decoder';
import { childEnv } from './childEnv.js';
import { Scrubber, runScrubbed } from './machineSecrets.js';

/**
 * How a secret reaches the one program that needs it (signinBroker.ts decides whether it may). Three ways, all in memory:
 *  - `withStdin`: the program's standard input (gh auth login --with-token, gnome-keyring-daemon --unlock).
 *  - `withEnv`: an environment variable of that child only (never the agent's own, never an argument: arguments are visible to every program).
 *  - `sudo`: sudo's askpass. A tiny fixed helper script (it holds no secret) reads the password from a one-use named pipe in a private
 *    folder; the pipe is fed once and only while sudo is running, so nothing is ever written to a file.
 * Whatever the program prints comes back scrubbed of the value and cut short.
 */

export type ExecResult = { code: number; out: string };
export type ExecOpts = { env?: Record<string, string>; timeoutMs?: number; newline?: boolean };

export interface Exec {
  /** A program that takes no secret (a status check). */
  plain(cmd: string, args: string[], o?: ExecOpts): Promise<ExecResult>;
  withStdin(cmd: string, args: string[], secret: string, o?: ExecOpts): Promise<ExecResult>;
  withEnv(cmd: string, args: string[], envName: string, secret: string, o?: ExecOpts): Promise<ExecResult>;
  sudo(argv: string[], secret: string, o?: ExecOpts): Promise<ExecResult>;
}

const MAX_OUT = 4000;
const DEFAULT_TIMEOUT = 60_000;

/** Reads a child's output, scrubbed of `secret`, up to MAX_OUT characters. */
function collect(child: ChildProcess, secret: string): { done: Promise<void>; text: () => string } {
  let text = '';
  const scrub = new Scrubber(secret ? { SECRET: secret } : {});
  const add = (s: string) => {
    if (text.length < MAX_OUT) text += s;
  };
  const done = Promise.all(
    [child.stdout, child.stderr].map(
      (stream) =>
        new Promise<void>((res) => {
          if (!stream) return res();
          const dec = new StringDecoder('utf8');
          stream.on('data', (b: Buffer) => add(scrub.push(dec.write(b))));
          stream.on('end', () => {
            add(scrub.push(dec.end()) + scrub.flush());
            res();
          });
          stream.on('error', () => res());
        }),
    ),
  ).then(() => undefined);
  return { done, text: () => text.slice(0, MAX_OUT) };
}

function finish(child: ChildProcess, c: { done: Promise<void>; text: () => string }, cmd: string, timeoutMs: number): Promise<ExecResult> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => child.kill('SIGKILL'), timeoutMs);
    timer.unref?.();
    child.on('error', (e) => {
      clearTimeout(timer);
      resolve({ code: 127, out: `could not run ${cmd}: ${(e as NodeJS.ErrnoException).code ?? 'error'}` });
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      void c.done.then(() => resolve({ code: code ?? 1, out: c.text() }));
    });
  });
}

/** The agent's own place to find the person's session (the agent runs as a service). */
export function sessionEnv(base: NodeJS.ProcessEnv): Record<string, string> {
  const out: Record<string, string> = {};
  const run = base.XDG_RUNTIME_DIR || (typeof process.getuid === 'function' ? `/run/user/${process.getuid()}` : '');
  if (run) {
    if (!base.XDG_RUNTIME_DIR) out.XDG_RUNTIME_DIR = run;
    if (!base.DBUS_SESSION_BUS_ADDRESS) out.DBUS_SESSION_BUS_ADDRESS = `unix:path=${run}/bus`;
    if (!base.GNOME_KEYRING_CONTROL) out.GNOME_KEYRING_CONTROL = `${run}/keyring`;
  }
  return out;
}

const ASKPASS_SCRIPT = '#!/bin/sh\nexec cat -- "$ESCANOR_ASKPASS_FIFO"\n';

export class RealExec implements Exec {
  constructor(private base: NodeJS.ProcessEnv = process.env, private o: { sudoBin?: string; runDir?: string } = {}) {}

  private env(extra?: Record<string, string>): Record<string, string | undefined> {
    return childEnv(this.base, { ...sessionEnv(this.base), ...(extra ?? {}) });
  }

  plain(cmd: string, args: string[], o: ExecOpts = {}): Promise<ExecResult> {
    const child = spawn(cmd, args, { env: this.env(o.env), stdio: ['ignore', 'pipe', 'pipe'] });
    return finish(child, collect(child, ''), cmd, o.timeoutMs ?? 20_000);
  }

  withStdin(cmd: string, args: string[], secret: string, o: ExecOpts = {}): Promise<ExecResult> {
    const child = spawn(cmd, args, { env: this.env(o.env), stdio: ['pipe', 'pipe', 'pipe'] });
    child.stdin?.on('error', () => {});
    child.stdin?.end(secret + (o.newline === false ? '' : '\n'));
    return finish(child, collect(child, secret), cmd, o.timeoutMs ?? DEFAULT_TIMEOUT);
  }

  async withEnv(cmd: string, args: string[], envName: string, secret: string, o: ExecOpts = {}): Promise<ExecResult> {
    let text = '';
    const add = (s: string) => {
      if (text.length < MAX_OUT) text += s;
    };
    let child: ChildProcess | null = null;
    const timer = setTimeout(() => child?.kill('SIGKILL'), o.timeoutMs ?? DEFAULT_TIMEOUT);
    timer.unref?.();
    const r = await runScrubbed({ cmd: [cmd, ...args], secrets: { [envName]: secret }, baseEnv: { ...this.base, ...sessionEnv(this.base), ...(o.env ?? {}) }, out: add, err: add, stdin: 'ignore', onChild: (c) => (child = c) });
    clearTimeout(timer);
    return { code: r.code, out: text.slice(0, MAX_OUT) };
  }

  async sudo(argv: string[], secret: string, o: ExecOpts = {}): Promise<ExecResult> {
    const dir = mkdtempSync(join(this.o.runDir ?? this.base.XDG_RUNTIME_DIR ?? tmpdir(), 'escanor-askpass-')); // mode 0700
    const fifo = join(dir, 'pw');
    const script = join(dir, 'askpass.sh');
    let writer: ReturnType<typeof setInterval> | null = null;
    try {
      await new Promise<void>((res, rej) => execFile('mkfifo', ['-m', '600', fifo], (e) => (e ? rej(e) : res())));
      writeFileSync(script, ASKPASS_SCRIPT, { mode: 0o700 });
      chmodSync(script, 0o700);
      const child = spawn(this.o.sudoBin ?? 'sudo', ['-A', '--', ...argv], {
        env: this.env({ SUDO_ASKPASS: script, ESCANOR_ASKPASS_FIFO: fifo, ...(o.env ?? {}) }),
        stdio: ['ignore', 'pipe', 'pipe'],
      });
      // Feed the pipe once, the moment sudo's askpass is reading it (a write end cannot open until a reader exists). A second ask,
      // which means the password was wrong, gets an empty line so sudo fails at once instead of waiting.
      let gave = false;
      writer = setInterval(() => {
        let fd = -1;
        try {
          fd = openSync(fifo, fsc.O_WRONLY | fsc.O_NONBLOCK);
        } catch {
          return; // no reader yet
        }
        try {
          writeSync(fd, gave ? '\n' : `${secret}\n`);
          gave = true;
        } catch {
          /* the reader went away */
        } finally {
          closeSync(fd);
        }
      }, 25);
      return await finish(child, collect(child, secret), 'sudo', o.timeoutMs ?? DEFAULT_TIMEOUT);
    } finally {
      if (writer) clearInterval(writer);
      for (const f of [fifo, script]) {
        try {
          unlinkSync(f);
        } catch {
          /* already gone */
        }
      }
      try {
        rmdirSync(dir);
      } catch {
        /* not empty or gone: leave it */
      }
    }
  }
}
