// Notices that this machine has just woken from sleep. A sleeping process is frozen, so its timers simply stop: on waking
// the wall clock has jumped ahead while the monotonic clock (which on Linux and macOS does not count time asleep) has not.
// Where the monotonic clock does count it (Windows), a tick that arrives far later than its interval says the same.
// A plain busy event loop moves both clocks together and never trips the first test; a very late tick only costs an
// unneeded reconnect, which is harmless.
export class ResumeDetector {
  private timer: NodeJS.Timeout | null = null;
  private lastWall: number;
  private lastMono: number;
  private now: () => number;
  private mono: () => number;
  private thresholdMs: number;
  private intervalMs: number;
  private lateMs: number;
  private onResume: (asleepMs: number) => void;

  constructor(opts: {
    onResume: (asleepMs: number) => void;
    now?: () => number;
    mono?: () => number;
    thresholdMs?: number;
    intervalMs?: number;
    lateMs?: number;
  }) {
    this.now = opts.now ?? Date.now;
    this.mono = opts.mono ?? (() => Number(process.hrtime.bigint() / 1_000_000n));
    this.thresholdMs = opts.thresholdMs ?? 10_000;
    this.intervalMs = opts.intervalMs ?? 5000;
    this.lateMs = opts.lateMs ?? 90_000;
    this.onResume = opts.onResume;
    this.lastWall = this.now();
    this.lastMono = this.mono();
  }

  tick(): void {
    const wall = this.now();
    const mono = this.mono();
    const wallGap = wall - this.lastWall;
    const monoGap = mono - this.lastMono;
    this.lastWall = wall;
    this.lastMono = mono;
    const slept = wallGap - monoGap;
    if (slept > this.thresholdMs) this.onResume(slept);
    else if (wallGap - this.intervalMs > this.lateMs) this.onResume(wallGap);
  }

  start(): void {
    if (this.timer) return;
    this.lastWall = this.now();
    this.lastMono = this.mono();
    this.timer = setInterval(() => this.tick(), this.intervalMs);
    this.timer.unref();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
