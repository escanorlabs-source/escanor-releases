import { spawn, type ChildProcess } from 'node:child_process';
import { constants } from 'node:os';
import { StringDecoder } from 'node:string_decoder';
import { childEnv } from './childEnv.js';

/**
 * Git login, SSH key and env secrets from Escanor, with nothing to copy (VAULT3). Everything here is off unless the machine
 * sets ESCANOR_MACHINE_SECRETS=1. No value is ever written to disk or logged; the pieces below are pure so they test without a network.
 */

export const GIT_HOSTS = ['github.com', 'gitlab.com'] as const;
export const MIN_SCRUB_LENGTH = 6;
export const SSH_AGENT_LIFETIME = '12h';

export function machineSecretsEnabled(env: NodeJS.ProcessEnv): boolean {
  return env.ESCANOR_MACHINE_SECRETS === '1';
}

// ---- git credential helper protocol -------------------------------------------------------------------------------------

/** What git writes on stdin: `key=value` lines up to a blank line. Unknown keys are kept; a line with no `=` is ignored. */
export function parseCredentialInput(text: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\r$/, '');
    if (line === '') {
      if (Object.keys(out).length) break;
      continue;
    }
    const eq = line.indexOf('=');
    if (eq <= 0) continue;
    out[line.slice(0, eq)] = line.slice(eq + 1);
  }
  return out;
}

/** What the helper prints for git. A value holding a newline is refused (it would let one line smuggle in another). */
export function formatCredential(c: { username: string; password: string }): string {
  if (/[\r\n\0]/.test(c.username) || /[\r\n\0]/.test(c.password)) throw new Error('credential contains a line break');
  return `username=${c.username}\npassword=${c.password}\n`;
}

/** The host and path to ask for, or null when git's question is not ours to answer (other host, not https). */
export function credentialQuestion(input: Record<string, string>): { protocol: 'https'; host: string; path: string } | null {
  const host = (input.host ?? '').toLowerCase();
  if ((input.protocol ?? 'https') !== 'https' || !(GIT_HOSTS as readonly string[]).includes(host)) return null;
  return { protocol: 'https', host, path: (input.path ?? '').slice(0, 300) };
}

// ---- `git setup`: only our two hosts, never over an existing helper ----------------------------------------------------

export type GitRunner = (args: string[]) => { status: number; stdout: string };

export function shellQuote(s: string): string {
  return `'${s.replace(/'/g, `'\\''`)}'`;
}

/** The value of credential.https://<host>.helper that makes git ask this program. */
export function helperValue(binPath: string): string {
  return `!${shellQuote(binPath)} git-credential`;
}

export interface SetupResult {
  host: string;
  action: 'set' | 'kept';
  /** Set when another credential helper also answers for this host: what that means for the person. */
  note?: string;
}

export function setupGitHelpers(opts: { binPath: string; force: boolean; git: GitRunner }): SetupResult[] {
  const results: SetupResult[] = [];
  const mine = helperValue(opts.binPath);
  // Helpers for every host, from any config file. git asks them before ours, and hands them the login ours gave to save:
  // `useHttpPath` would also stop them matching the logins they already saved. So with one, useHttpPath is left alone and
  // the person is told; `--force` makes Escanor the only helper for github.com / gitlab.com (an empty entry resets the list).
  const generic = opts.git(['config', '--get-all', 'credential.helper']);
  const others = generic.status === 0 ? generic.stdout.split('\n').map((l) => l.trim()).filter((l) => l && l !== mine) : [];
  for (const host of GIT_HOSTS) {
    const key = `credential.https://${host}.helper`;
    const have = opts.git(['config', '--global', '--get-all', key]);
    const existing = have.status === 0 && have.stdout.trim() !== '';
    if (existing && !opts.force) {
      results.push({ host, action: 'kept' });
      continue;
    }
    const only = others.length > 0 && opts.force;
    const wrote = only
      ? [opts.git(['config', '--global', '--replace-all', key, '']), opts.git(['config', '--global', '--add', key, mine])]
      : [opts.git(['config', '--global', '--replace-all', key, mine])];
    if (wrote.some((w) => w.status !== 0)) throw new Error(`git config failed for ${host}`);
    if (others.length && !only) {
      const names = others.join(', ');
      results.push({ host, action: 'set', note: `git also uses ${names} here: it is asked first and may save the login Escanor gives (on disk, for "store"). Use --force to make Escanor the only helper for ${host}.` });
      continue;
    }
    // So git tells the helper which repository it is for, and the right connected account (when there are several) answers.
    const http = opts.git(['config', '--global', '--get', `credential.https://${host}.useHttpPath`]);
    if (http.status !== 0 || http.stdout.trim() === '') opts.git(['config', '--global', `credential.https://${host}.useHttpPath`, 'true']);
    results.push({ host, action: 'set' });
  }
  return results;
}

// ---- scrubbing what a command prints ------------------------------------------------------------------------------------

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Replaces each secret value (length >= 6) in a stream of text with `[secret:NAME]`. Only a tail that could be the start of a
 * value is held back (so a value split across chunks is still found, and a prompt with no newline still shows at once); a
 * shorter value is not marked while a longer one starting the same way may still complete. `flush()` releases the rest.
 */
export class Scrubber {
  private readonly re: RegExp | null;
  private readonly names = new Map<string, string>();
  private readonly hold: number;
  private carry = '';

  constructor(values: Record<string, string>) {
    for (const name of Object.keys(values).sort()) {
      const v = values[name];
      if (typeof v === 'string' && v.length >= MIN_SCRUB_LENGTH && !this.names.has(v)) this.names.set(v, name);
    }
    const longestFirst = [...this.names.keys()].sort((a, b) => b.length - a.length);
    this.re = longestFirst.length ? new RegExp(longestFirst.map(escapeRe).join('|'), 'g') : null;
    this.hold = longestFirst.length ? longestFirst[0].length - 1 : 0;
  }

  private mark(value: string): string {
    return `[secret:${this.names.get(value)}]`;
  }

  /** Whether `s` (text up to the end of what has arrived) is the start of a value longer than it. */
  private couldStart(s: string): boolean {
    for (const v of this.names.keys()) if (v.length > s.length && v.startsWith(s)) return true;
    return false;
  }

  push(chunk: string): string {
    if (!this.re) return chunk;
    const buf = this.carry + chunk;
    let out = '';
    let i = 0;
    let held = -1;
    for (;;) {
      this.re.lastIndex = i;
      const m = this.re.exec(buf);
      if (!m) break;
      if (this.couldStart(buf.slice(m.index))) {
        held = m.index; // a longer value may still complete here
        break;
      }
      out += buf.slice(i, m.index) + this.mark(m[0]);
      i = m.index + m[0].length;
    }
    if (held < 0) {
      held = buf.length;
      for (let j = Math.max(i, buf.length - this.hold); j < buf.length; j++) {
        if (this.couldStart(buf.slice(j))) {
          held = j;
          break;
        }
      }
    }
    out += buf.slice(i, held);
    this.carry = buf.slice(held);
    return out;
  }

  flush(): string {
    const rest = this.carry;
    this.carry = '';
    if (!this.re || !rest) return rest;
    return rest.replace(this.re, (m) => this.mark(m));
  }
}

// ---- `env run` ----------------------------------------------------------------------------------------------------------

const ENV_NAME = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;

/** `--scope` and `--names` and the command after `--`; null when it is not well formed. */
export function parseEnvRunArgs(args: string[]): { scope: string; names?: string[]; cmd: string[] } | null {
  let scope = 'workspace';
  let names: string[] | undefined;
  let i = 0;
  for (; i < args.length; i++) {
    const a = args[i];
    if (a === '--') {
      i++;
      break;
    }
    if (a === '--scope' && args[i + 1]) scope = args[++i];
    else if (a.startsWith('--scope=')) scope = a.slice(8);
    else if (a === '--names' && args[i + 1]) names = args[++i].split(',').map((n) => n.trim()).filter(Boolean);
    else if (a.startsWith('--names=')) names = a.slice(8).split(',').map((n) => n.trim()).filter(Boolean);
    else return null;
  }
  const cmd = args.slice(i);
  if (!cmd.length || !cmd[0] || (names && names.some((n) => !ENV_NAME.test(n)))) return null;
  return { scope, ...(names ? { names } : {}), cmd };
}

/** Only well-named variables with string values reach the command's environment, and never the hub's own (childEnv.ts). */
export function envWith(base: NodeJS.ProcessEnv, secrets: Record<string, unknown>): NodeJS.ProcessEnv {
  const added: Record<string, string> = {};
  for (const [name, value] of Object.entries(secrets)) {
    if (ENV_NAME.test(name) && typeof value === 'string') added[name] = value;
  }
  return childEnv(base, added);
}

export interface RunResult {
  code: number;
}

/** Runs `cmd` with `secrets` added to its environment, its output scrubbed on the way through. Resolves with the exit code. */
export function runScrubbed(opts: {
  cmd: string[];
  secrets: Record<string, string>;
  baseEnv: NodeJS.ProcessEnv;
  out: (s: string) => void;
  err: (s: string) => void;
  stdin?: 'inherit' | 'ignore';
  onChild?: (child: ChildProcess) => void;
}): Promise<RunResult> {
  return new Promise((resolve) => {
    const child = spawn(opts.cmd[0], opts.cmd.slice(1), { env: envWith(opts.baseEnv, opts.secrets), stdio: [opts.stdin ?? 'inherit', 'pipe', 'pipe'] });
    opts.onChild?.(child);
    const streams: Array<[NodeJS.ReadableStream, (s: string) => void]> = [
      [child.stdout!, opts.out],
      [child.stderr!, opts.err],
    ];
    const done: Array<Promise<void>> = streams.map(
      ([stream, write]) =>
        new Promise<void>((res) => {
          const scrub = new Scrubber(opts.secrets);
          const dec = new StringDecoder('utf8');
          stream.on('data', (b: Buffer) => {
            const text = scrub.push(dec.write(b));
            if (text) write(text);
          });
          stream.on('end', () => {
            const text = scrub.push(dec.end()) + scrub.flush();
            if (text) write(text);
            res();
          });
          stream.on('error', () => res());
        }),
    );
    child.on('error', (e) => {
      opts.err(`could not run ${opts.cmd[0]}: ${(e as NodeJS.ErrnoException).code ?? 'error'}\n`);
      resolve({ code: 127 });
    });
    child.on('close', (code, signal) => {
      void Promise.all(done).then(() => resolve({ code: code ?? (signal ? 128 + (constants.signals[signal] ?? 0) : 1) }));
    });
  });
}
