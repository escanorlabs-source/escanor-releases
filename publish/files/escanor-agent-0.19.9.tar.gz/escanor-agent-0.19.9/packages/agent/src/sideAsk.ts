import { randomUUID } from 'node:crypto';
import type { AgentLocalAskEvent, AgentToHubMessage, HubUserInput, LocalAskEvent } from '@remote-harness/shared';

/**
 * `/ask <question>` in a chat: a quick question that is only answered. It never joins the chat's queue, never takes a chat slot, never
 * waits for the running reply and is never given to the chat's own Claude (so it changes nothing in that chat and costs it no time):
 * this computer's own quick AI answers it (localAi/run.ts, task "quick") and the answer is added to the chat as one message
 * (a normal assistant message, so every app and hub shows it).
 */

export const ASK_HEAD = 'Quick answer';

/** The question after `/ask`; '' for a bare `/ask`; null when the text is not an ask. */
export function parseAsk(text: string): string | null {
  const m = /^\s*\/ask(?:\s+([\s\S]*))?$/i.exec(text);
  return m ? (m[1] ?? '').trim() : null;
}

export type Asker = { start(msg: { type: 'local_ask'; requestId: string; task: 'quick'; prompt: string; system?: string; allowCloud?: boolean; allowPull?: boolean }): void };

type Pending = { sessionId: string; tempId?: string; question: string };

export class SideAsk {
  private pending = new Map<string, Pending>();
  private asker: Asker | null = null;

  constructor(
    private readonly d: {
      send: (m: AgentToHubMessage) => void;
      /** Builds the asker; it must send its events to the function given. Null: this computer has no AI to ask. */
      makeAsker: (onEvent: (e: AgentLocalAskEvent) => void) => Asker | null;
      /** A line about the chat, to give the answer something to go on (its title). */
      titleOf?: (sessionId: string) => string | undefined;
    },
  ) {}

  /** The hub's `user_input` was an ask: confirm it, answer it. Never throws. */
  handle(input: HubUserInput, question: string): void {
    this.d.send({
      type: 'input_ack',
      sessionId: input.sessionId,
      ...(input.tempId ? { tempId: input.tempId } : {}),
      ...(input.inputId ? { inputId: input.inputId } : {}),
      status: 'delivered',
    });
    const where = { sessionId: input.sessionId, ...(input.tempId ? { tempId: input.tempId } : {}) };
    if (!question) return this.say(where, 'Ask a question after it, like /ask what does this error mean? It is only answered: it does not start any work.');
    this.asker ??= this.d.makeAsker((e) => this.onEvent(e));
    if (!this.asker) return this.say(where, 'This computer has no AI it can use for quick questions right now.');
    const requestId = `ask:${randomUUID()}`;
    this.pending.set(requestId, { ...where, question });
    const title = this.d.titleOf?.(input.sessionId);
    try {
      this.asker.start({
        type: 'local_ask',
        requestId,
        task: 'quick',
        prompt: question,
        system:
          'Answer the question briefly and directly in plain words. It is a side question asked in the middle of a software chat' +
          (title ? ` called "${title}"` : '') +
          '. Do not run anything and do not offer to do work.',
      });
    } catch {
      this.pending.delete(requestId);
      this.say(where, 'The quick answer could not start. Try again.');
    }
  }

  private onEvent(e: AgentLocalAskEvent): void {
    const p = this.pending.get(e.requestId);
    if (!p) return;
    const ev: LocalAskEvent = e.event;
    if (ev.kind === 'done') {
      this.pending.delete(e.requestId);
      this.say(p, ev.text.trim() || 'There was no answer to that.');
    } else if (ev.kind === 'failed') {
      this.pending.delete(e.requestId);
      this.say(p, `Could not answer that. ${ev.message}`);
    }
  }

  private say(to: { sessionId: string; tempId?: string }, text: string): void {
    this.d.send({
      type: 'sdk_message',
      sessionId: to.sessionId,
      ...(to.tempId ? { tempId: to.tempId } : {}),
      message: {
        type: 'assistant',
        uuid: randomUUID(),
        session_id: to.sessionId,
        parent_tool_use_id: null,
        message: { role: 'assistant', content: [{ type: 'text', text: `**${ASK_HEAD}** (a side question: nothing was run)\n\n${text}` }] },
      },
    });
  }
}
