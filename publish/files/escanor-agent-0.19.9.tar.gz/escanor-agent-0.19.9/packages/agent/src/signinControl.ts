import { createHash } from 'node:crypto';
import type { Exec } from './brokerExec.js';
import type { LoginRecovery, RecoveryReport } from './loginRecovery.js';
import { SUDO_SECRET } from './loginRecovery.js';
import { cleanAllow, cleanSudo, commandLine, type AuditEntry, type BrokerPolicy, type CredentialBroker, type SigninAudit, type SigninStore, type UseProof } from './signinBroker.js';
import { UseWindow, type SigninUse } from './signinApproval.js';

/**
 * The owner-facing side of the credential broker: what the phone's "Let Escanor sign in for me" screen reads and changes, and the
 * running of one approved use. Every use needs a proof (a fingerprint yes for it, or the owner's time window); this file never makes
 * one, jarvis.ts does after checking the phone's signature. Nothing here returns a secret's value.
 */

export type SigninStatus = {
  enabled: boolean;
  /** The computer's own settings (ESCANOR_SIGNIN=0) keep it off; the phone cannot change that. */
  fixedByComputer: boolean;
  allow: string[];
  sudo: string[];
  /** The "allow for N minutes" the owner gave with a fingerprint, if one is running. */
  window: { until: number } | null;
  /** "Let AI chats handle sign-ins": the fingerprint-confirmed time window in which a chat that works on its own may reach saved sign-ins and keys. */
  chatWindow: { until: number } | null;
  log: AuditEntry[];
  report: RecoveryReport | null;
};

export type SigninPatch = { enabled?: boolean; allow?: string[]; sudo?: string[] };

export class SigninControl {
  readonly window: UseWindow;
  /** A separate window: it lets chats that work on their own touch sign-in files (personalGuard 'credentials'), not the saved secrets the broker hands out. */
  readonly chatWindow: UseWindow;

  constructor(private d: { store: SigninStore; audit: SigninAudit; broker: CredentialBroker; recovery: LoginRecovery; exec: Exec; now?: () => number }) {
    this.window = new UseWindow(d.now);
    this.chatWindow = new UseWindow(d.now);
  }

  enabled(): boolean {
    return this.d.store.read().enabled;
  }

  lockedByEnv(): boolean {
    return this.d.store.lockedByEnv();
  }

  status(): SigninStatus {
    const p = this.d.store.read();
    const w = this.window.active();
    const cw = this.chatWindow.active();
    return { enabled: p.enabled, fixedByComputer: this.lockedByEnv(), allow: p.allow, sudo: p.sudo, window: w ? { until: w.until } : null, chatWindow: cw ? { until: cw.until } : null, log: this.d.audit.recent(30), report: this.d.recovery.lastReport() };
  }

  /** The patch as the agent will keep it: lists cleaned. Null when a list holds something that is not valid (nothing is changed then). */
  parse(args: Record<string, unknown>): SigninPatch | null {
    const patch: SigninPatch = {};
    if (args.enabled !== undefined) {
      if (typeof args.enabled !== 'boolean') return null;
      patch.enabled = args.enabled;
    }
    for (const key of ['allow', 'sudo'] as const) {
      const v = args[key];
      if (v === undefined) continue;
      if (!Array.isArray(v) || v.some((x) => typeof x !== 'string')) return null;
      const cleaned = key === 'allow' ? cleanAllow(v) : cleanSudo(v);
      if (cleaned.length !== new Set(v.map((x: string) => x.trim())).size) return null; // an entry that is not valid
      patch[key] = cleaned;
    }
    return patch;
  }

  /** Does this patch let the computer do more than it may now? Then the phone's fingerprint is needed. Taking things away never is. */
  loosens(patch: SigninPatch): boolean {
    const cur = this.d.store.read();
    if (patch.enabled === true && !cur.enabled) return true;
    if (patch.allow?.some((a) => !cur.allow.includes(a))) return true;
    if (patch.sudo?.some((c) => !cur.sudo.includes(c))) return true;
    return false;
  }

  /** What the fingerprint is signed for: stable for the same change, different for another. */
  subjectOf(patch: SigninPatch): string {
    const h = createHash('sha256').update(JSON.stringify({ e: patch.enabled ?? null, a: patch.allow ?? null, s: patch.sudo ?? null })).digest('hex').slice(0, 12);
    return `${patch.enabled === true ? 'on' : 'edit'}:${h}`;
  }

  apply(patch: SigninPatch): BrokerPolicy {
    return this.d.store.write(patch);
  }

  /** Can this request be asked at all? A plain reason when not (nothing is asked of the phone for something that could never run). */
  unavailable(use: SigninUse): string | null {
    const p = this.d.store.read();
    if (!p.enabled) return 'Let Escanor sign in for me is off on this computer. Turn it on first (it asks for your fingerprint).';
    if (use.kind === 'sudo') {
      if (!this.d.broker.sudoAllowed(use.argv ?? [])) return 'That command is not on the list of commands sudo may run for you.';
      if (!this.d.broker.allowed(SUDO_SECRET)) return `${SUDO_SECRET} is not on the list of saved secrets this computer may use.`;
    }
    return null;
  }

  /** Run one approved use. The answer is plain words; it never holds a value. */
  async run(use: SigninUse, proof: UseProof): Promise<{ ok: boolean; say: string }> {
    const why = this.unavailable(use);
    if (why) return { ok: false, say: why };
    if (use.kind === 'sudo') return this.sudo(use.argv ?? [], proof);
    const only = use.kind === 'keyring' ? (['keyring'] as const) : use.kind === 'github' ? (['gh', 'git'] as const) : undefined;
    const report = await this.d.recovery.check({ proof, ...(only ? { only: [...only] } : {}), ...(use.kind === 'github' && use.account ? { account: use.account } : {}), ...(use.force ? { force: true } : {}) });
    const mine = report.items.filter((i) => i.status !== 'skipped' || only === undefined || only.includes(i.id as never));
    const bad = mine.filter((i) => i.status === 'failed');
    const fixed = mine.filter((i) => i.status === 'fixed');
    const say = (fixed.length ? fixed : mine.filter((i) => i.status !== 'skipped' || i.say !== 'Not part of this request.')).map((i) => i.say).join(' ').slice(0, 600) || 'Checked your saved sign-ins.';
    return { ok: bad.length === 0, say };
  }

  /**
   * Run one command with sudo, using the saved password, for one approved use. Only for a command line on the owner's list, exactly.
   * The password is read from the vault, handed to sudo's askpass through a one-use pipe and forgotten; the answer is the command's own output.
   */
  async sudo(argv: string[], proof: UseProof): Promise<{ ok: boolean; say: string }> {
    const line = commandLine(argv);
    if (!this.d.broker.enabled()) return this.refuse(line, 'Let Escanor sign in for me is off on this computer.');
    if (!this.d.broker.sudoAllowed(argv)) return this.refuse(line, 'That command is not on the list of commands sudo may run for you.');
    const r = await this.d.broker.use(SUDO_SECRET, `sudo ${line}`.slice(0, 200), proof, (pw) => this.d.exec.sudo(argv, pw));
    if (!r.ok) return { ok: false, say: r.reason };
    return { ok: r.value.code === 0, say: r.value.out.trim() || (r.value.code === 0 ? 'Done.' : `The command failed (exit ${r.value.code}).`) };
  }

  private refuse(line: string, why: string): { ok: boolean; say: string } {
    this.d.audit.add({ name: SUDO_SECRET, purpose: `sudo ${line}`.slice(0, 200), outcome: 'refused', why });
    return { ok: false, say: why };
  }
}
