import { spawn, type ChildProcess } from 'node:child_process';

/**
 * The microphone for push-to-talk on this computer (`escanor-agent voice`): raw 16 kHz mono 16-bit audio from whichever recorder
 * the computer has, cut at the end of the person's sentence, wrapped as a WAV for the speech to text.
 *
 * No shell is involved; the recorder is a fixed program with fixed arguments. Nothing is kept: the audio lives in memory and goes
 * only to Escanor's speech to text (voiceTranscribe.ts). While it listens the computer's own microphone indicator shows.
 */

export const SAMPLE_RATE = 16000;

export type RecorderSpec = { name: string; cmd: string; args: string[] };

/** The recorders to try, best first. `ESCANOR_MIC` names a device for the ones that take one (ffmpeg on Windows and macOS). */
export function recorderCandidates(platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = process.env): RecorderSpec[] {
  const raw = ['-ac', '1', '-ar', String(SAMPLE_RATE), '-f', 's16le', '-'];
  const mic = (env.ESCANOR_MIC ?? '').trim();
  if (platform === 'linux') {
    return [
      { name: 'parec', cmd: 'parec', args: ['--format=s16le', `--rate=${SAMPLE_RATE}`, '--channels=1', '--latency-msec=40'] },
      { name: 'arecord', cmd: 'arecord', args: ['-q', '-f', 'S16_LE', '-r', String(SAMPLE_RATE), '-c', '1', '-t', 'raw', '-'] },
      { name: 'ffmpeg', cmd: 'ffmpeg', args: ['-loglevel', 'error', '-f', 'pulse', '-i', mic || 'default', ...raw] },
    ];
  }
  if (platform === 'darwin') {
    return [
      { name: 'ffmpeg', cmd: 'ffmpeg', args: ['-loglevel', 'error', '-f', 'avfoundation', '-i', mic || ':default', ...raw] },
      { name: 'sox', cmd: 'rec', args: ['-q', '-r', String(SAMPLE_RATE), '-c', '1', '-b', '16', '-e', 'signed-integer', '-t', 'raw', '-'] },
    ];
  }
  if (platform === 'win32') {
    return [
      { name: 'ffmpeg', cmd: 'ffmpeg', args: ['-loglevel', 'error', '-f', 'dshow', '-i', `audio=${mic || 'default'}`, ...raw] },
      { name: 'sox', cmd: 'sox', args: ['-q', '-d', '-r', String(SAMPLE_RATE), '-c', '1', '-b', '16', '-e', 'signed-integer', '-t', 'raw', '-'] },
    ];
  }
  return [];
}

/** A WAV file around raw 16-bit mono PCM. */
export function wavFromPcm(pcm: Buffer, rate = SAMPLE_RATE): Buffer {
  const head = Buffer.alloc(44);
  head.write('RIFF', 0);
  head.writeUInt32LE(36 + pcm.length, 4);
  head.write('WAVEfmt ', 8);
  head.writeUInt32LE(16, 16);
  head.writeUInt16LE(1, 20); // PCM
  head.writeUInt16LE(1, 22); // mono
  head.writeUInt32LE(rate, 24);
  head.writeUInt32LE(rate * 2, 28);
  head.writeUInt16LE(2, 32);
  head.writeUInt16LE(16, 34);
  head.write('data', 36);
  head.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([head, pcm]);
}

export type EndpointOptions = {
  /** Stop this long after the person stops talking. */
  silenceMs: number;
  /** Give up if nobody starts talking in this long. */
  waitMs: number;
  /** Never listen longer than this. */
  maxMs: number;
  /** Frame size for the loudness reading. */
  frameMs?: number;
};

export const DEFAULT_ENDPOINT: EndpointOptions = { silenceMs: 1300, waitMs: 7000, maxMs: 25_000, frameMs: 20 };

export type EndpointState = 'waiting' | 'speaking' | 'done-spoke' | 'done-silent' | 'done-max';

/**
 * Finds the end of a sentence in raw 16-bit mono audio by loudness: the quiet before the person speaks sets what "quiet" is (its
 * loudest frame in the first 300 ms, times 3, never below a floor), then speech is a run of louder frames, and the sentence ends
 * after `silenceMs` of quiet. Pure: feed it audio, read the state.
 */
export class Endpointer {
  private frame: number;
  private carry = Buffer.alloc(0);
  private frames = 0;
  private floor = 0;
  private threshold = 350;
  private loud = 0;
  private quietRun = 0;
  private spoke = false;
  state: EndpointState = 'waiting';

  constructor(private readonly o: EndpointOptions = DEFAULT_ENDPOINT, private readonly rate = SAMPLE_RATE) {
    this.frame = Math.floor((rate * (o.frameMs ?? 20)) / 1000) * 2;
  }

  get hasSpoken(): boolean {
    return this.spoke;
  }

  get frameMs(): number {
    return this.o.frameMs ?? 20;
  }

  /** Milliseconds of audio seen so far. */
  get ms(): number {
    return this.frames * this.frameMs;
  }

  push(chunk: Buffer): EndpointState {
    if (this.state.startsWith('done')) return this.state;
    let buf = this.carry.length ? Buffer.concat([this.carry, chunk]) : chunk;
    while (buf.length >= this.frame && !this.state.startsWith('done')) {
      this.read(buf.subarray(0, this.frame));
      buf = buf.subarray(this.frame);
    }
    this.carry = Buffer.from(buf);
    return this.state;
  }

  private rms(frame: Buffer): number {
    let sum = 0;
    const n = Math.floor(frame.length / 2);
    for (let i = 0; i < n; i++) {
      const s = frame.readInt16LE(i * 2);
      sum += s * s;
    }
    return n ? Math.sqrt(sum / n) : 0;
  }

  private read(frame: Buffer): void {
    const level = this.rms(frame);
    this.frames++;
    const ms = this.ms;
    if (ms <= 300) {
      // The room before anyone speaks.
      this.floor = Math.max(this.floor, level);
      this.threshold = Math.max(350, this.floor * 3);
      return;
    }
    const isLoud = level >= this.threshold;
    if (isLoud) {
      this.loud++;
      this.quietRun = 0;
      // Three loud frames in a row are speech (a click is not).
      if (!this.spoke && this.loud >= 3) {
        this.spoke = true;
        this.state = 'speaking';
      }
    } else {
      if (!this.spoke) this.loud = 0;
      this.quietRun++;
    }
    if (this.spoke && this.quietRun * this.frameMs >= this.o.silenceMs) this.state = 'done-spoke';
    else if (!this.spoke && ms >= this.o.waitMs) this.state = 'done-silent';
    else if (ms >= this.o.maxMs) this.state = this.spoke ? 'done-spoke' : 'done-max';
  }

  /** The person asked to stop now (the hotkey again). */
  finish(): EndpointState {
    if (!this.state.startsWith('done')) this.state = this.spoke ? 'done-spoke' : 'done-silent';
    return this.state;
  }
}

export type Heard = { wav: Buffer; heard: boolean; ms: number; via: string };

export type RecordDeps = {
  spawnImpl?: (cmd: string, args: string[], env: NodeJS.ProcessEnv) => ChildProcess;
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  options?: EndpointOptions;
  /** Called with the state as it changes ("listening" / "speaking" lights). */
  onState?: (s: EndpointState) => void;
  /** Aborted: stop now and use what was heard. */
  signal?: AbortSignal;
};

export class NoMicrophone extends Error {
  constructor(public readonly tried: string[]) {
    super(`No program to record the microphone was found (tried ${tried.join(', ') || 'none for this system'}).`);
  }
}

const realSpawn = (cmd: string, args: string[], env: NodeJS.ProcessEnv): ChildProcess => spawn(cmd, args, { stdio: ['ignore', 'pipe', 'ignore'], env, windowsHide: true });

/** Record one sentence. Tries each recorder until one starts. Throws NoMicrophone when none is installed. */
export async function recordSentence(d: RecordDeps = {}): Promise<Heard> {
  const env = d.env ?? process.env;
  const tried: string[] = [];
  for (const spec of recorderCandidates(d.platform ?? process.platform, env)) {
    tried.push(spec.name);
    const got = await tryRecorder(spec, d, env);
    if (got) return got;
  }
  throw new NoMicrophone(tried);
}

/** Null when this recorder is not installed (or died at once, e.g. no sound server): the next one is tried. */
function tryRecorder(spec: RecorderSpec, d: RecordDeps, env: NodeJS.ProcessEnv): Promise<Heard | null> {
  return new Promise((resolve) => {
    const options = d.options ?? DEFAULT_ENDPOINT;
    const end = new Endpointer(options);
    const pcm: Buffer[] = [];
    let child: ChildProcess;
    try {
      child = (d.spawnImpl ?? realSpawn)(spec.cmd, spec.args, env);
    } catch {
      return resolve(null);
    }
    let got = 0;
    let finished = false;
    let last: EndpointState = 'waiting';
    const finish = (why: 'end' | 'died') => {
      if (finished) return;
      finished = true;
      clearTimeout(started);
      d.signal?.removeEventListener('abort', onAbort);
      try {
        child.kill('SIGTERM');
      } catch {
        // already gone
      }
      if (why === 'died' && got === 0) return resolve(null);
      resolve({ wav: wavFromPcm(Buffer.concat(pcm)), heard: end.hasSpoken, ms: end.ms, via: spec.name });
    };
    const onAbort = () => {
      end.finish();
      finish('end');
    };
    d.signal?.addEventListener('abort', onAbort, { once: true });
    if (d.signal?.aborted) return onAbort();
    // A recorder that starts but never gives audio (no sound server) is given 3 s before the next one is tried.
    const started = setTimeout(() => {
      if (got === 0) finish('died');
    }, 3000);
    child.stdout?.on('data', (chunk: Buffer) => {
      got += chunk.length;
      pcm.push(chunk);
      const s = end.push(chunk);
      if (s !== last) {
        last = s;
        d.onState?.(s);
      }
      if (s.startsWith('done')) finish('end');
    });
    child.on('error', () => finish('died'));
    child.on('close', () => finish(got > 0 ? 'end' : 'died'));
  });
}
