import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync } from 'node:fs';
import { createServer, connect } from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { findRepos } from './machineState.js';
import { repoSlug, testEnv } from './fixTests.js';
import { redact } from './redact.js';

/**
 * PREVIEW1 fallback, the computer's side: "Open on my computer". A fix pull request with no hosted preview can be looked at here.
 * Escanor's backend (POST /autopilot/runs/{id}/preview/open, owner or admin only) sends `preview_open` to the online agent; the
 * agent fetches the PR into a throwaway git worktree, starts the project and opens it in this computer's browser. It tells Escanor
 * how it went (POST /agent/device/preview-open, signed in with the hub agent token, like resumeCheck.ts).
 *
 * Small and safe on purpose:
 *  - Only a repository the person already has on this computer (a checkout under the workspace, projects or terminal-sync roots
 *    whose `origin` is that repository). It never clones anything.
 *  - Only `git fetch` of the PR's own ref (or its branch) and `git worktree add --detach`. The fetch never runs the PR's code.
 *  - Starting the project runs the pull request's code, so it asks first with the agent's own approval card (the same one a chat
 *    uses for a shell command) and starts only on "allow". Dependencies are never installed here: a `node_modules` the person's own
 *    checkout has is linked in; otherwise the answer says what to run ("how to start it").
 *  - The project gets the test-run environment (no hub token, no git or cloud credentials) and a free port of its own on 127.0.0.1.
 *  - One preview at a time on this machine: opening another stops the first. They are stopped when the agent stops.
 */

export const PREVIEW_CAPABILITY = 'preview_open';
/** SITEPREV3: this agent also serves its running preview through a private hub link (previewRelay.ts). */
export const PREVIEW_LINK_CAPABILITY = 'preview_link';
/** A link lives 30 minutes at most (the hub says when it ends; a later time is cut to this). */
export const MAX_LINK_MS = 30 * 60_000;
const LINK_ID = /^[A-Za-z0-9_-]{16,64}$/;
export const START_WAIT_MS = 90_000;
const GIT_TIMEOUT_MS = 60_000;
const DEP_DIRS = ['node_modules', '.venv', 'venv'];
const REPO = /^[A-Za-z0-9_.-]{1,100}\/[A-Za-z0-9_.-]{1,100}$/;
const BRANCH = /^(?!-)(?!.*\.\.)[A-Za-z0-9._/-]{1,200}$/;
const ID = /^[A-Za-z0-9_.:-]{1,64}$/;

export type PreviewOpenRequest = { requestId: string; runId: string; repo: string; prNumber?: number; branch?: string };
/** preview_share: the same request, plus the link the hub made for it and when that link ends (ms). */
export type PreviewShareRequest = PreviewOpenRequest & { linkId: string; expiresAt: number };
/** Where a link's request goes: the running preview's own port, or why there is none (yet). */
export type LinkTarget = { port: number } | { wait: 'starting' | 'stopped' | 'failed'; message: string };
export type PreviewStatus = 'started' | 'needs_setup' | 'no_start_command' | 'not_here' | 'declined' | 'failed';
export type PreviewReport = { requestId: string; runId: string; status: PreviewStatus; url?: string; how?: string; message: string };
export type StartPlan = {
  cmd: string;
  label: string;
  needsDeps: boolean;
  installHow: string | null;
  /** The exact text of every script that will run, from the pull request's own files ("predev: ...", "dev: ...", "Procfile web: ..."). */
  scripts: string[];
};
/** What the approval card shows (toolName PreviewRun): the exact code that will run and what the pull request changed. */
export type PreviewAsk = {
  command: string;
  scripts: string[];
  dir: string;
  changed: string[] | null;
  risky: string[];
  /** SITEPREV3: the preview will also be reachable through a private internet link (the card says so). */
  shared?: boolean;
  /** It runs already (opened on this computer): the question is only whether to share it. */
  running?: boolean;
};
/** What a card for a share says, so nobody allows a link while thinking it is only for this computer. */
export const SHARE_NOTE =
  'Anyone who has the private link can open this preview over the internet, as if they were on this computer, until the link ends (30 minutes at most) or is taken back.';

/** Files that decide what runs on this computer (scripts, install settings, lockfiles, tool configs a dev server loads). */
const RISKY_FILE = new RegExp(
  [
    '(^|/)package\\.json$',
    '(^|/)\\.npmrc$',
    '(^|/)\\.yarnrc(\\.ya?ml)?$',
    '(^|/)\\.pnpmfile\\.c?js$',
    '(^|/)pnpm-workspace\\.yaml$',
    '(^|/)(package-lock\\.json|npm-shrinkwrap\\.json|pnpm-lock\\.yaml|yarn\\.lock|bun\\.lockb?)$',
    '(^|/)Procfile$',
    '(^|/)(Dockerfile[^/]*|docker-compose[^/]*\\.ya?ml|compose\\.ya?ml)$',
    '(^|/)Makefile$',
    '(^|/)\\.husky/',
    '(^|/)\\.env[^/]*$',
    '(^|/)[^/]*\\.config\\.(c|m)?(j|t)s$',
    '(^|/)\\.(babelrc|postcssrc|eslintrc)[^/]*$',
    '(^|/)\\.escanor/',
  ].join('|'),
);
/** The approval card of an open: its own tool name (PreviewRun, never the shell-command card), the exact scripts, the changed files and a plain warning. */
export function previewCard(req: PreviewOpenRequest, d: PreviewAsk): { sessionId: string; toolName: string; input: Record<string, unknown> } {
  const warning =
    d.changed === null
      ? 'Escanor could not tell what this fix changed. Treat all of it as unchecked.'
      : d.risky.length > 0
        ? `This fix changes files that decide what runs on your computer: ${d.risky.slice(0, 12).join(', ')}${d.risky.length > 12 ? ', and more' : ''}.`
        : null;
  const pr = `pull request #${req.prNumber ?? '?'} (${req.repo})`;
  // The sharing comes first: a phone shows only the start of the description.
  const description = !d.shared
    ? `Run code from ${pr} on this computer`
    : d.running
      ? `Share through a private link for 30 minutes: the preview of ${pr} running on this computer`
      : `Share through a private link for 30 minutes: run code from ${pr} on this computer`;
  return {
    sessionId: `preview-${req.runId}`,
    toolName: 'PreviewRun',
    input: {
      description,
      ...(d.shared ? { sharing: SHARE_NOTE } : {}),
      command: d.scripts.length ? d.scripts.join('\n') : d.command,
      runs: d.command,
      folder: d.dir,
      changedFiles: d.changed ?? [],
      ...(warning ? { warning } : {}),
      note: 'Approved code can also write into the dependency folders of your own copy of this project, which are shared with it.',
    },
  };
}
export const riskyFiles = (files: string[]): string[] => files.filter((f) => RISKY_FILE.test(f));

/** The request, checked field by field; null when anything about it is off (the agent then does nothing). */
export function parseRequest(msg: unknown): PreviewOpenRequest | null {
  if (!msg || typeof msg !== 'object') return null;
  const m = msg as Record<string, unknown>;
  if (typeof m.requestId !== 'string' || !ID.test(m.requestId) || typeof m.runId !== 'string' || !ID.test(m.runId)) return null;
  if (typeof m.repo !== 'string' || !REPO.test(m.repo) || m.repo.split('/').some((p) => p === '.' || p === '..')) return null;
  const pr = m.prNumber;
  const prNumber = typeof pr === 'number' && Number.isInteger(pr) && pr > 0 && pr < 10_000_000 ? pr : undefined;
  const branch = typeof m.branch === 'string' && BRANCH.test(m.branch) ? m.branch : undefined;
  if (pr !== undefined && prNumber === undefined) return null;
  if (m.branch !== undefined && branch === undefined) return null;
  if (prNumber === undefined && branch === undefined) return null;
  return { requestId: m.requestId, runId: m.runId, repo: m.repo.toLowerCase(), ...(prNumber ? { prNumber } : {}), ...(branch ? { branch } : {}) };
}

/** A preview_share, checked like an open; null when anything about it is off. The end is never more than 30 minutes away. */
export function parseShare(msg: unknown, now = Date.now()): PreviewShareRequest | null {
  const req = parseRequest(msg);
  const m = msg as Record<string, unknown>;
  if (!req || typeof m.linkId !== 'string' || !LINK_ID.test(m.linkId)) return null;
  if (typeof m.expiresAt !== 'number' || !Number.isFinite(m.expiresAt) || m.expiresAt <= now) return null;
  return { ...req, linkId: m.linkId, expiresAt: Math.min(m.expiresAt, now + MAX_LINK_MS) };
}

/** How to start the project in `dir` (package.json dev/start, Procfile web, docker compose), or null when nothing says. */
export function detectStart(dir: string): StartPlan | null {
  const has = (f: string) => existsSync(join(dir, f));
  const read = (f: string) => {
    try {
      return readFileSync(join(dir, f), 'utf8');
    } catch {
      return '';
    }
  };
  if (has('package.json')) {
    try {
      const scripts = (JSON.parse(read('package.json')) as { scripts?: Record<string, unknown> }).scripts ?? {};
      const name = ['dev', 'start'].find((n) => typeof scripts[n] === 'string' && String(scripts[n]).trim());
      if (name) {
        const pm = has('pnpm-lock.yaml') ? 'pnpm' : has('yarn.lock') ? 'yarn' : has('bun.lockb') || has('bun.lock') ? 'bun' : 'npm';
        // npm and yarn 1 also run pre<name> and post<name> by themselves: they are shown too.
        const shown = [`pre${name}`, name, `post${name}`].filter((n) => typeof scripts[n] === 'string').map((n) => `${n}: ${String(scripts[n]).slice(0, 500)}`);
        return { cmd: pm === 'npm' || pm === 'bun' ? `${pm} run ${name}` : `${pm} ${name}`, label: `${pm} ${name}`, needsDeps: true, installHow: `${pm} install`, scripts: shown };
      }
    } catch {
      // not JSON: look further
    }
  }
  const web = /^web:\s*(.+)$/m.exec(read('Procfile'))?.[1]?.trim();
  if (web) return { cmd: web.slice(0, 300), label: 'Procfile web', needsDeps: false, installHow: null, scripts: [`Procfile web: ${web.slice(0, 300)}`] };
  // docker compose is not started from here (it builds images and can mount the whole disk): nothing says how, so the answer tells the person.
  return null;
}

/** The local address a program printed, if it printed one (localhost, 127.0.0.1, 0.0.0.0, [::1]); always shown as 127.0.0.1. */
export function urlFromOutput(text: string): string | null {
  const m = /https?:\/\/(?:localhost|127\.0\.0\.1|0\.0\.0\.0|\[::1\]):(\d{2,5})(\/[^\s'")]*)?/.exec(text);
  return m ? `http://127.0.0.1:${m[1]}${m[2] ?? ''}` : null;
}

type Run = (file: string, args: string[], cwd: string, timeoutMs?: number) => Promise<{ code: number; out: string }>;

const realRun: Run = (file, args, cwd, timeoutMs = GIT_TIMEOUT_MS) =>
  new Promise((resolve) => {
    const env = { ...testEnv(), GIT_OPTIONAL_LOCKS: '0', LC_ALL: 'C' } as Record<string, string | undefined>;
    // The person's own git login is needed to fetch from a private repository, so the credential helper and ssh key stay for git.
    delete env.GIT_CONFIG_COUNT;
    delete env.GIT_CONFIG_KEY_0;
    delete env.GIT_CONFIG_VALUE_0;
    delete env.GIT_SSH_COMMAND;
    execFile(file, args, { cwd, timeout: timeoutMs, env, maxBuffer: 4 * 1024 * 1024 }, (err, stdout) => {
      resolve({ code: err ? (typeof (err as { code?: unknown }).code === 'number' ? (err as { code: number }).code : 1) : 0, out: String(stdout ?? '').trim() });
    });
  });

export type PreviewOpenerOptions = {
  /** Folders whose checkouts may be used (the workspace, projects and terminal-sync roots). */
  roots: string[];
  report: (r: PreviewReport) => void | Promise<void>;
  /** Ask the person (the agent's own approval card); true only for "allow". */
  ask: (req: PreviewOpenRequest, details: PreviewAsk) => Promise<'allow' | 'deny' | 'timeout'>;
  run?: Run;
  openBrowser?: (url: string) => void;
  freePort?: () => Promise<number>;
  waitForPort?: (port: number, ms: number) => Promise<boolean>;
  /** Ports something on this computer listens on now (Linux: /proc/net/tcp*); null where that cannot be read. */
  listeningPorts?: () => Set<number> | null;
  startProcess?: (cmd: string, cwd: string, env: Record<string, string | undefined>, onOutput: (t: string) => void) => ChildProcess;
  tmpRoot?: string;
  startWaitMs?: number;
};

function realFreePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const s = createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const port = (s.address() as { port: number }).port;
      s.close(() => resolve(port));
    });
  });
}

function realWaitForPort(port: number, ms: number): Promise<boolean> {
  const until = Date.now() + ms;
  return new Promise((resolve) => {
    const tryOnce = () => {
      const c = connect({ port, host: '127.0.0.1' });
      c.once('connect', () => {
        c.destroy();
        resolve(true);
      });
      c.once('error', () => {
        c.destroy();
        if (Date.now() >= until) resolve(false);
        else setTimeout(tryOnce, 750);
      });
    };
    tryOnce();
  });
}

/** TCP ports in LISTEN state on this computer, read from /proc (Linux); null elsewhere or when it cannot be read. */
export function procListeningPorts(read: (f: string) => string = (f) => readFileSync(f, 'utf8')): Set<number> | null {
  const ports = new Set<number>();
  let any = false;
  for (const f of ['/proc/net/tcp', '/proc/net/tcp6']) {
    let text: string;
    try {
      text = read(f);
      any = true;
    } catch {
      continue;
    }
    for (const line of text.split('\n').slice(1)) {
      const cols = line.trim().split(/\s+/);
      if (cols.length > 3 && cols[3] === '0A') {
        const port = parseInt(cols[1].split(':').pop() ?? '', 16);
        if (port > 0) ports.add(port);
      }
    }
  }
  return any ? ports : null;
}

function realStart(cmd: string, cwd: string, env: Record<string, string | undefined>, onOutput: (t: string) => void): ChildProcess {
  const child = spawn('/bin/sh', ['-c', cmd], { cwd, env, detached: true, stdio: ['ignore', 'pipe', 'pipe'] });
  child.stdout?.on('data', (d: Buffer) => onOutput(d.toString('utf8')));
  child.stderr?.on('data', (d: Buffer) => onOutput(d.toString('utf8')));
  child.on('error', (e) => onOutput(`\n${e.message}`));
  return child;
}

/** Open an address this agent started (only http://127.0.0.1:<port>) in the computer's browser. */
export function openInBrowser(url: string): void {
  if (!/^http:\/\/127\.0\.0\.1:\d{2,5}(\/[^\s]*)?$/.test(url)) return;
  const [file, args] = process.platform === 'darwin' ? ['open', [url]] : process.platform === 'win32' ? ['cmd', ['/c', 'start', '', url]] : ['xdg-open', [url]];
  try {
    const c = spawn(file, args, { detached: true, stdio: 'ignore' });
    c.on('error', () => undefined);
    c.unref();
  } catch {
    // no browser to open: the address is still reported
  }
}

export class PreviewOpener {
  /** `linkable`: the port is surely this preview's own (the one it was given, or one nothing listened on before it started). */
  // `shared`: started for links (stops with its last link). `shareOk`: the person allowed links to it (asked with the share card).
  // `asked`: what the person was shown when it started, to ask again before a preview opened here is shared.
  private current: {
    child: ChildProcess;
    dir: string;
    repo: string;
    runId: string;
    port: number;
    shared: boolean;
    shareOk: boolean;
    linkable: boolean;
    asked: PreviewAsk;
  } | null = null;
  private busy = false;
  /** The run being set up now (asking, fetching, starting), so a link to it says "getting ready". */
  private settingUp: string | null = null;
  /** Why the last try of a run did not start, for a link to it. */
  private lastFailure: { runId: string; message: string } | null = null;
  /** SITEPREV3: the hub links to this computer's preview, by link id. */
  private links = new Map<string, { runId: string; timer: ReturnType<typeof setTimeout> }>();
  private readonly run: Run;

  constructor(private o: PreviewOpenerOptions) {
    this.run = o.run ?? realRun;
  }

  /** Never throws: every outcome is a report. One request at a time. */
  async handle(raw: unknown): Promise<void> {
    const req = parseRequest(raw);
    if (!req) return;
    if (this.busy) {
      await this.say(req, 'failed', 'Another preview is being set up on this computer. Try again in a minute.');
      return;
    }
    await this.guarded(req, false);
  }

  private async guarded(req: PreviewOpenRequest, shared: boolean): Promise<void> {
    this.busy = true;
    this.settingUp = req.runId;
    try {
      await this.open(req, shared);
    } catch (err) {
      await this.say(req, 'failed', `It could not be opened: ${redact(err instanceof Error ? err.message : String(err)).slice(0, 200)}`);
    } finally {
      this.busy = false;
      this.settingUp = null;
    }
  }

  /**
   * SITEPREV3 preview_share: a private link to this run's preview. A preview this computer already runs for the run is reused only
   * once the person allowed sharing it (one opened here for this computer alone is asked about again, with the share card); otherwise
   * it is started like an open (asking first, saying it will be shared), but no browser opens here. When its last link ends, a preview
   * started for links stops. Never throws: every outcome is a report.
   */
  async share(raw: unknown): Promise<void> {
    const req = parseShare(raw);
    if (!req) return;
    const old = this.links.get(req.linkId);
    if (old) clearTimeout(old.timer);
    const timer = setTimeout(() => this.unshare(req.linkId), Math.max(0, req.expiresAt - Date.now()));
    timer.unref?.();
    this.links.set(req.linkId, { runId: req.runId, timer });
    if (this.current?.runId === req.runId && this.current.linkable && this.current.shareOk) {
      await this.say(req, 'started', 'The fix is running on this computer. Open it with the private link; the link works for 30 minutes.', { url: `http://127.0.0.1:${this.current.port}` });
      return;
    }
    if (this.busy) {
      if (this.settingUp !== req.runId) await this.say(req, 'failed', 'Another preview is being set up on this computer. Try again in a minute.');
      return;
    }
    if (this.current?.runId === req.runId && this.current.linkable) {
      await this.askToShare(req);
      return;
    }
    await this.guarded(req, true);
  }

  /** The run's preview was opened on this computer for its own browser: share it only after asking, with the share card. */
  private async askToShare(req: PreviewShareRequest): Promise<void> {
    const cur = this.current!;
    this.busy = true;
    this.settingUp = req.runId;
    let verdict: 'allow' | 'deny' | 'timeout';
    try {
      verdict = await this.o.ask(req, { ...cur.asked, shared: true, running: true });
    } catch {
      verdict = 'deny';
    } finally {
      this.busy = false;
      this.settingUp = null;
    }
    if (verdict === 'allow' && this.current === cur) {
      cur.shareOk = true;
      await this.say(req, 'started', 'The fix is running on this computer. Open it with the private link; the link works for 30 minutes.', { url: `http://127.0.0.1:${cur.port}` });
      return;
    }
    const link = this.links.get(req.linkId);
    if (link) {
      clearTimeout(link.timer);
      this.links.delete(req.linkId); // the preview opened here keeps running, unshared
    }
    await this.say(
      req,
      'declined',
      verdict === 'allow'
        ? 'The preview stopped on the computer before it could be shared. Ask for a new link.'
        : verdict === 'timeout'
          ? 'Not shared: nobody answered the question on your computer in time. Ask again when you can allow it there.'
          : 'Not shared: sharing the preview on this computer through a link was not allowed.',
    );
  }

  /** A link ended or was taken back. The preview it started stops with its last link (one opened on the computer itself stays). */
  unshare(linkId: string): void {
    const link = this.links.get(linkId);
    if (!link) return;
    clearTimeout(link.timer);
    this.links.delete(linkId);
    const cur = this.current;
    if (cur?.shared && cur.runId === link.runId && ![...this.links.values()].some((l) => l.runId === cur.runId)) this.stop();
  }

  /** Where a request through a link goes: only the port of this run's running preview, never anything a request names. */
  target(linkId: string): LinkTarget {
    const link = this.links.get(linkId);
    if (!link) return { wait: 'stopped', message: 'This link is not open on the computer any more. Ask for a new one in the Escanor app.' };
    // Only a preview the person allowed to be shared (asked with the share card) is ever reached through a link.
    if (this.current?.runId === link.runId && this.current.linkable && this.current.shareOk) return { port: this.current.port };
    if (this.settingUp === link.runId) return { wait: 'starting', message: 'Getting the fix ready on the computer. If it asks, allow it there. This page tries again by itself.' };
    if (this.lastFailure?.runId === link.runId) return { wait: 'failed', message: this.lastFailure.message };
    return { wait: 'stopped', message: 'The preview is not running on the computer any more. Ask for a new link in the Escanor app.' };
  }

  /** The agent stops: the preview and every link with it. */
  stopAll(): void {
    for (const l of this.links.values()) clearTimeout(l.timer);
    this.links.clear();
    this.stop();
  }

  stop(): void {
    const cur = this.current;
    this.current = null;
    if (!cur) return;
    killGroup(cur.child.pid);
    void this.removeWorktree(cur.repo, cur.dir);
  }

  private async say(req: PreviewOpenRequest, status: PreviewStatus, message: string, extra: { url?: string; how?: string } = {}): Promise<void> {
    if (status !== 'started') this.lastFailure = { runId: req.runId, message };
    try {
      await this.o.report({ requestId: req.requestId, runId: req.runId, status, message, ...extra });
    } catch {
      // Escanor could not be told; nothing else to do
    }
  }

  /** A checkout the person already has whose origin is `repo`; never made by this agent. */
  private async findCheckout(repo: string): Promise<string | null> {
    const seen = new Set<string>();
    for (const root of this.o.roots) {
      for (const rel of ['.', ...findRepos(root, { maxDepth: 3, maxRepos: 60 })]) {
        const dir = rel === '.' ? root : join(root, rel);
        if (seen.has(dir) || !existsSync(join(dir, '.git'))) continue;
        seen.add(dir);
        const url = await this.run('git', ['-C', dir, 'remote', 'get-url', 'origin'], dir, 5_000);
        if (url.code === 0 && repoSlug(url.out)?.toLowerCase() === repo) return dir;
      }
    }
    return null;
  }

  /** Files the pull request changes against the main branch (merge-base); null when that cannot be worked out here. */
  private async changedFiles(repoDir: string, ref: string): Promise<string[] | null> {
    for (const base of ['refs/remotes/origin/HEAD', 'refs/remotes/origin/main', 'refs/remotes/origin/master']) {
      const mb = await this.run('git', ['-C', repoDir, 'merge-base', ref, base], repoDir, 10_000);
      if (mb.code !== 0 || !/^[0-9a-f]{40}$/.test(mb.out)) continue;
      const diff = await this.run('git', ['-C', repoDir, 'diff', '--name-only', '-z', mb.out, ref], repoDir, 15_000);
      if (diff.code === 0) return diff.out.split('\0').filter(Boolean).slice(0, 500);
    }
    return null;
  }

  private async removeWorktree(repoDir: string, dir: string): Promise<void> {
    await this.run('git', ['-C', repoDir, 'worktree', 'remove', '--force', dir], repoDir, 15_000);
    try {
      rmSync(join(dir, '..'), { recursive: true, force: true });
    } catch {
      // gone already
    }
  }

  private async open(req: PreviewOpenRequest, shared = false): Promise<void> {
    const repoDir = await this.findCheckout(req.repo);
    if (!repoDir) {
      await this.say(req, 'not_here', `This computer has no copy of ${req.repo} that Escanor may use, so it will not download one. Open the pull request on GitHub instead.`);
      return;
    }
    if (this.current) this.stop(); // one preview at a time
    const id = req.runId.replace(/[^A-Za-z0-9]/g, '').slice(0, 8) || 'run';
    const ref = `refs/escanor-preview/${id}`;
    const from = req.prNumber ? `pull/${req.prNumber}/head` : `heads/${req.branch}`;
    const fetched = await this.run('git', ['-C', repoDir, 'fetch', '--quiet', '--no-tags', '--no-recurse-submodules', 'origin', `+refs/${from}:${ref}`], repoDir);
    if (fetched.code !== 0) {
      await this.say(req, 'failed', 'The fix could not be fetched from GitHub with this computer\'s own git login. Open the pull request on GitHub instead.');
      return;
    }
    const base = mkdtempSync(join(this.o.tmpRoot ?? tmpdir(), 'escanor-preview-'));
    const dir = join(base, 'work');
    const added = await this.run('git', ['-C', repoDir, 'worktree', 'add', '--detach', dir, ref], repoDir);
    if (added.code !== 0) {
      rmSync(base, { recursive: true, force: true });
      await this.say(req, 'failed', 'A temporary copy of the fix could not be made on this computer.');
      return;
    }
    const cleanup = () => void this.removeWorktree(repoDir, dir);
    const quoted = `'${repoDir.replace(/'/g, "'\\''")}'`;
    const manual = `cd ${quoted} && git fetch origin ${req.prNumber ? `pull/${req.prNumber}/head` : req.branch} && git checkout FETCH_HEAD`;
    const plan = detectStart(dir);
    if (!plan) {
      cleanup();
      await this.say(req, 'no_start_command', 'Escanor could not tell how to start this project (no dev or start script or Procfile; docker compose is not started from here). Start it yourself on the fix branch, then open it in your browser.', { how: manual });
      return;
    }
    for (const d of DEP_DIRS) {
      if (existsSync(join(repoDir, d)) && !existsSync(join(dir, d))) {
        try {
          mkdirSync(join(dir, d, '..'), { recursive: true });
          symlinkSync(join(repoDir, d), join(dir, d));
        } catch {
          // reported below if it matters
        }
      }
    }
    if (plan.needsDeps && !existsSync(join(dir, 'node_modules'))) {
      cleanup();
      await this.say(req, 'needs_setup', 'This project has no installed packages on this computer, and Escanor does not install packages for you. Install them, then start it.', { how: `${manual} && ${plan.installHow} && ${plan.cmd}` });
      return;
    }
    const changed = await this.changedFiles(repoDir, ref);
    const asked: PreviewAsk = { command: plan.cmd, scripts: plan.scripts, dir, changed, risky: changed ? riskyFiles(changed) : [] };
    const verdict = await this.o.ask(req, shared ? { ...asked, shared: true } : asked);
    if (verdict !== 'allow') {
      cleanup();
      await this.say(req, 'declined', verdict === 'timeout' ? 'Not started: nobody answered the question on your computer in time. Ask again when you can allow it there.' : 'Not started: running the fix on this computer was not allowed.');
      return;
    }
    const port = await (this.o.freePort ?? realFreePort)();
    const before = (this.o.listeningPorts ?? procListeningPorts)();
    let output = '';
    const env = { ...testEnv(), PORT: String(port), HOST: '127.0.0.1', BROWSER: 'none' } as Record<string, string | undefined>;
    delete env.CI;
    const child = (this.o.startProcess ?? realStart)(plan.cmd, dir, env, (t) => {
      output = (output + t).slice(-8_000);
    });
    this.current = { child, dir, repo: repoDir, runId: req.runId, port, shared, shareOk: shared, linkable: false, asked };
    child.once('exit', () => {
      if (this.current?.child === child) {
        this.current = null;
        cleanup();
      }
    });
    const up = await (this.o.waitForPort ?? realWaitForPort)(port, this.o.startWaitMs ?? START_WAIT_MS);
    const url = up ? `http://127.0.0.1:${port}` : urlFromOutput(output);
    if (!url) {
      const tail = redact(output).trim().split('\n').slice(-3).join(' ').slice(0, 240);
      this.stop();
      await this.say(req, 'failed', `It was started with ${plan.label} but nothing opened a local address in time.${tail ? ` It said: ${tail}` : ''}`);
      return;
    }
    // A link may reach only this preview's own port: the one it was given, or one it printed that nothing listened on before it started.
    const used = Number(new URL(url).port);
    const linkable = used === port || (before !== null && !before.has(used));
    if (this.current?.child === child) Object.assign(this.current, { port: used, linkable });
    if (shared && !linkable) {
      this.stop();
      await this.say(req, 'failed', `It started on ${url}, but Escanor could not be sure that address belongs to it, so it is not shared. Make its dev server use the PORT it is given, then ask again.`);
      return;
    }
    if (shared) {
      await this.say(req, 'started', `The fix is running on this computer (${plan.label}). Open it with the private link; the link works for 30 minutes.`, { url });
      return;
    }
    (this.o.openBrowser ?? openInBrowser)(url);
    await this.say(req, 'started', `The fix is running on this computer (${plan.label}) and opened in your browser at ${url}. Opening another preview stops this one.`, { url });
  }
}

function killGroup(pid: number | undefined): void {
  if (!pid) return;
  try {
    process.kill(-pid, 'SIGTERM');
  } catch {
    try {
      process.kill(pid, 'SIGTERM');
    } catch {
      // already gone
    }
  }
}

/** Tell Escanor how an open went (POST /agent/device/preview-open). Never throws; false when it could not be told. */
export async function reportPreviewOpen(opts: {
  apiUrl: string;
  hubToken: string;
  vmName: string;
  agentVersion: string;
  report: PreviewReport;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}): Promise<boolean> {
  try {
    const r = opts.report;
    const res = await (opts.fetchImpl ?? fetch)(`${opts.apiUrl}/agent/device/preview-open`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${opts.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${opts.agentVersion}` },
      body: JSON.stringify({ vm_name: opts.vmName, request_id: r.requestId, run_id: r.runId, status: r.status, message: r.message, ...(r.url ? { url: r.url } : {}), ...(r.how ? { how: r.how } : {}) }),
      signal: AbortSignal.timeout(opts.timeoutMs ?? 10_000),
    });
    return res.ok;
  } catch {
    return false;
  }
}
