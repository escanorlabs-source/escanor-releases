import { execFileSync, spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { delimiter, dirname, join } from 'node:path';
import type { CliProvider } from './cliTools.js';

/**
 * Some of the other AIs' tools need a newer Node.js than the one a computer happens to have first on its PATH (Gemini CLI needs
 * Node 20 or newer; an Ubuntu service often has Node 18). So before one is started: use a new enough Node that is already on
 * the computer (the PATH, this agent's own, nvm, fnm, volta, asdf, n, /usr/local ...), else fetch a portable Node into the
 * agent's tools folder. When even that fails the chat says so in plain words.
 */

/** The oldest Node.js major each tool works with. */
export const MIN_NODE: Record<CliProvider, number> = { chatgpt: 18, gemini: 20, copilot: 20 };

/** The portable Node fetched when a computer has none new enough (an LTS line). */
export const PORTABLE_NODE_VERSION = '22.14.0';

const isWin = () => process.platform === 'win32';
const nodeName = () => (isWin() ? 'node.exe' : 'node');

export function majorOf(version: string): number {
  const m = /^v?(\d+)\./.exec(version.trim());
  return m ? Number(m[1]) : 0;
}

const versionCache = new Map<string, number>();
/** The major version of the node program [file] (asks it once, quickly), 0 when it cannot be run. */
export function nodeMajorOf(file: string): number {
  const hit = versionCache.get(file);
  if (hit !== undefined) return hit;
  let major = 0;
  try {
    major = majorOf(execFileSync(file, ['--version'], { timeout: 4000, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }));
  } catch {
    major = 0;
  }
  if (major > 0) versionCache.set(file, major);
  return major;
}

function pathDirs(env: Record<string, string | undefined>): string[] {
  const key = Object.keys(env).find((k) => k.toUpperCase() === 'PATH');
  return (key ? env[key] ?? '' : '').split(delimiter).filter(Boolean);
}

/** The versioned subfolders of [root] (v22.1.0 ...), newest first, each with [rel] then the node program. */
function versioned(root: string, rel: string[]): string[] {
  let names: string[];
  try {
    names = readdirSync(root);
  } catch {
    return [];
  }
  const ver = (n: string) => n.replace(/^[^\d]*/, '').split('.').map((x) => Number(x) || 0);
  return names
    .filter((n) => /\d/.test(n))
    .sort((a, b) => {
      const x = ver(a);
      const y = ver(b);
      for (let i = 0; i < 3; i++) if ((y[i] ?? 0) !== (x[i] ?? 0)) return (y[i] ?? 0) - (x[i] ?? 0);
      return 0;
    })
    .map((n) => join(root, n, ...rel, nodeName()));
}

/** Where a Node.js may be on this computer, in the order to prefer them (the portable copy last: it is only a fallback). */
export function nodeCandidates(env: Record<string, string | undefined>, profilesDir?: string): string[] {
  const home = env.HOME || env.USERPROFILE || homedir();
  const out: string[] = [];
  for (const d of pathDirs(env)) out.push(join(d.replace(/^"(.*)"$/, '$1'), nodeName()));
  out.push(process.execPath);
  if (isWin()) {
    out.push(join(env.ProgramFiles || 'C:\\Program Files', 'nodejs', 'node.exe'));
    if (env.APPDATA) out.push(...versioned(join(env.APPDATA, 'nvm'), []));
    if (env.LOCALAPPDATA) out.push(join(env.LOCALAPPDATA, 'Volta', 'bin', 'node.exe'), ...versioned(join(env.LOCALAPPDATA, 'fnm', 'node-versions'), ['installation']));
  } else {
    out.push(...versioned(join(env.NVM_DIR || join(home, '.nvm'), 'versions', 'node'), ['bin']));
    out.push(...versioned(join(home, '.local', 'share', 'fnm', 'node-versions'), ['installation', 'bin']));
    out.push(...versioned(join(home, '.fnm', 'node-versions'), ['installation', 'bin']));
    out.push(...versioned(join(home, 'Library', 'Application Support', 'fnm', 'node-versions'), ['installation', 'bin']));
    out.push(...versioned(join(home, '.volta', 'tools', 'image', 'node'), ['bin']));
    out.push(...versioned(join(home, '.asdf', 'installs', 'nodejs'), ['bin']));
    out.push(...versioned(join(home, '.local', 'share', 'mise', 'installs', 'node'), ['bin']));
    out.push(...versioned('/usr/local/n/versions/node', ['bin']));
    out.push(...versioned('/usr/local/lib/nodejs', ['bin']));
    out.push('/usr/local/bin/node', '/opt/homebrew/bin/node', '/opt/homebrew/opt/node/bin/node', '/usr/bin/node');
  }
  if (profilesDir) out.push(portableNodeBin(profilesDir));
  return [...new Set(out.filter(Boolean))];
}

export function portableNodeBin(profilesDir: string): string {
  return isWin() ? join(profilesDir, '.tools', 'node', 'node.exe') : join(profilesDir, '.tools', 'node', 'bin', 'node');
}

/** The first node program that is at least [min]: with its major version, or null. */
export function findNode(
  min: number,
  env: Record<string, string | undefined>,
  profilesDir?: string,
  exists: (f: string) => boolean = existsSync,
  major: (f: string) => number = nodeMajorOf,
): { bin: string; major: number } | null {
  for (const c of nodeCandidates(env, profilesDir)) {
    if (c !== process.execPath && !exists(c)) continue;
    const m = major(c);
    if (m >= min) return { bin: c, major: m };
  }
  return null;
}

/**
 * [env] with a Node of at least [min] first on its PATH, so a `#!/usr/bin/env node` tool starts with it. Unchanged when the first
 * node there is already new enough. When none is found the agent's own Node folder is still added at the end (as before).
 */
export function withNewNode(env: Record<string, string | undefined>, min: number, profilesDir?: string): Record<string, string | undefined> {
  const key = !isWin() ? 'PATH' : Object.keys(env).find((k) => k.toUpperCase() === 'PATH') ?? 'Path';
  const cur = env[key] ?? '';
  const first = pathDirs(env).map((d) => join(d, nodeName())).find((f) => existsSync(f));
  if (first && nodeMajorOf(first) >= min) return env;
  const good = findNode(min, env, profilesDir);
  const dir = good ? dirname(good.bin) : dirname(process.execPath);
  return { ...env, [key]: cur ? (good ? `${dir}${delimiter}${cur}` : `${cur}${delimiter}${dir}`) : dir };
}

/** True when a Node of at least [min] can be used on this computer right now. */
export function hasNewNode(min: number, env: Record<string, string | undefined>, profilesDir?: string): boolean {
  return findNode(min, env, profilesDir) !== null;
}

export type FetchLike = (url: string) => Promise<{ ok: boolean; status: number; arrayBuffer(): Promise<ArrayBuffer>; text(): Promise<string> }>;
export type ExtractFn = (archive: string, into: string) => Promise<boolean>;

export function portableNodeTarget(platform: NodeJS.Platform = process.platform, arch: string = process.arch): { file: string; ext: string } | null {
  const a = arch === 'x64' ? 'x64' : arch === 'arm64' ? 'arm64' : null;
  if (!a) return null;
  const os = platform === 'linux' ? 'linux' : platform === 'darwin' ? 'darwin' : platform === 'win32' ? 'win' : null;
  if (!os) return null;
  const ext = os === 'win' ? 'zip' : 'tar.gz';
  return { file: `node-v${PORTABLE_NODE_VERSION}-${os}-${a}.${ext}`, ext };
}

const realExtract: ExtractFn = (archive, into) =>
  new Promise((resolve) => {
    const p = spawn('tar', ['-xf', archive, '-C', into], { stdio: 'ignore', windowsHide: true });
    p.once('error', () => resolve(false));
    p.once('exit', (c) => resolve(c === 0));
  });

/**
 * Fetches a portable Node.js into <profilesDir>/.tools/node (checked against nodejs.org's published SHA-256 list) and answers its
 * program, or why not in plain words. Nothing is changed outside that folder.
 */
export async function installPortableNode(
  profilesDir: string,
  o: { fetch?: FetchLike; extract?: ExtractFn; platform?: NodeJS.Platform; arch?: string } = {},
): Promise<{ ok: true; bin: string } | { ok: false; error: string }> {
  const target = portableNodeTarget(o.platform ?? process.platform, o.arch ?? process.arch);
  if (!target) return { ok: false, error: 'This kind of computer has no ready-made Node.js to fetch. Install Node.js 20 or newer on it, then try again.' };
  const f: FetchLike = o.fetch ?? ((u) => fetch(u, { signal: AbortSignal.timeout(180_000) }) as never);
  const base = `https://nodejs.org/dist/v${PORTABLE_NODE_VERSION}`;
  const tools = join(profilesDir, '.tools');
  const stage = join(tools, `node-stage-${process.pid}-${Date.now()}`);
  try {
    mkdirSync(stage, { recursive: true });
    const sums = await f(`${base}/SHASUMS256.txt`);
    if (!sums.ok) return { ok: false, error: 'Could not reach nodejs.org to fetch a newer Node.js. Check the internet connection, then try again.' };
    const want = (await sums.text()).split('\n').map((l) => l.trim().split(/\s+/)).find((p) => p[1] === target.file)?.[0];
    if (!want) return { ok: false, error: 'Could not find a matching Node.js download for this computer. Install Node.js 20 or newer on it, then try again.' };
    const res = await f(`${base}/${target.file}`);
    if (!res.ok) return { ok: false, error: 'Could not download a newer Node.js. Check the internet connection, then try again.' };
    const data = Buffer.from(await res.arrayBuffer());
    if (createHash('sha256').update(data).digest('hex') !== want) return { ok: false, error: 'The downloaded Node.js did not match its checksum, so it was not used. Try again later.' };
    const archive = join(stage, target.file);
    writeFileSync(archive, data, { mode: 0o600 });
    if (!(await (o.extract ?? realExtract)(archive, stage))) return { ok: false, error: 'Could not unpack the downloaded Node.js on this computer. Install Node.js 20 or newer on it, then try again.' };
    const inner = join(stage, target.file.replace(/\.(tar\.gz|zip)$/, ''));
    if (!existsSync(inner)) return { ok: false, error: 'The downloaded Node.js had an unexpected layout, so it was not used.' };
    const dest = join(tools, 'node');
    rmSync(dest, { recursive: true, force: true });
    renameSync(inner, dest);
    const bin = portableNodeBin(profilesDir);
    return existsSync(bin) ? { ok: true, bin } : { ok: false, error: 'The downloaded Node.js had an unexpected layout, so it was not used.' };
  } catch {
    return { ok: false, error: 'Could not fetch a newer Node.js. Check the internet connection, then try again.' };
  } finally {
    rmSync(stage, { recursive: true, force: true });
  }
}

/**
 * Makes sure a Node of at least the tool's minimum is usable for [provider]: already there, or fetched. [say] gets the plain
 * progress line ("Gemini needs a newer Node; installing...") before a fetch starts.
 */
export async function ensureNodeFor(
  provider: CliProvider,
  name: string,
  o: { env: Record<string, string | undefined>; profilesDir?: string; say?: (text: string) => void; install?: typeof installPortableNode },
): Promise<{ ok: true } | { ok: false; error: string }> {
  const min = MIN_NODE[provider];
  if (hasNewNode(min, o.env, o.profilesDir)) return { ok: true };
  if (!o.profilesDir) return { ok: false, error: `${name} needs Node.js ${min} or newer, and this computer has an older one. Install a newer Node.js, then try again.` };
  o.say?.(`${name} needs a newer Node (${min} or newer); installing...`);
  const got = await (o.install ?? installPortableNode)(o.profilesDir);
  if (!got.ok) return { ok: false, error: `${name} needs Node.js ${min} or newer, and it could not be set up. ${got.error}` };
  return { ok: true };
}

/** True when a tool's crash text is an old Node failing to load it (the loader stack and "Node.js v18..." line). */
export function oldNodeCrash(stderr: string): boolean {
  return /Node\.js v\d+\.\d+/.test(stderr) && /ModuleLoader|node:internal\/modules|ERR_REQUIRE_ESM|ERR_UNKNOWN_BUILTIN_MODULE|SyntaxError: Unexpected token/.test(stderr);
}
