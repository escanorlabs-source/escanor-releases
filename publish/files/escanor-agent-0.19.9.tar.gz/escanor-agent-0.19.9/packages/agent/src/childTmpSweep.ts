import { lstatSync, readdirSync, realpathSync, rmSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, resolve, sep } from 'node:path';

const WEEK_MS = 7 * 24 * 3_600_000;
export const SWEEP_EVERY_MS = 6 * 3_600_000;

/** True when `dir` is a folder that must never be swept: the root, the home folder, /tmp itself, or a parent of those. */
function dangerous(dir: string, home: string): boolean {
  const bad = ['/', '/tmp', '/var/tmp', home];
  return bad.some((b) => dir === b || b.startsWith(dir + sep) || dir === sep);
}

/**
 * Remove entries directly inside the agent's own temp folder that were last changed more than 7 days ago. Touches only that folder
 * (refuses dangerous or symlinked roots), uses lstat so a symlink is removed as a link and never followed. Never throws.
 */
export function sweepChildTmp(dirIn: string, opts: { now?: number; maxAgeMs?: number; home?: string; log?: (m: string) => void } = {}): string[] {
  const log = opts.log ?? ((m: string) => console.log(m));
  const removed: string[] = [];
  try {
    const dir = resolve(dirIn);
    const home = opts.home ?? homedir();
    if (dangerous(dir, home)) { log(`Temp sweep refused: ${dir} is not a safe folder`); return removed; }
    const st = lstatSync(dir);
    if (!st.isDirectory() || st.isSymbolicLink() || realpathSync(dir) !== dir) { log(`Temp sweep refused: ${dir} is not a plain folder`); return removed; }
    const cutoff = (opts.now ?? Date.now()) - (opts.maxAgeMs ?? WEEK_MS);
    for (const name of readdirSync(dir)) {
      try {
        const p = join(dir, name);
        const s = lstatSync(p);
        if (s.mtimeMs >= cutoff) continue;
        rmSync(p, { recursive: true, force: true }); // a symlink entry is unlinked itself, never followed
        removed.push(name);
      } catch { /* skip this entry */ }
    }
    if (removed.length) log(`Temp sweep removed ${removed.length} old item(s) from ${dir}`);
  } catch { /* never throw */ }
  return removed;
}

export function startChildTmpSweep(dir: string): void {
  sweepChildTmp(dir);
  setInterval(() => sweepChildTmp(dir), SWEEP_EVERY_MS).unref();
}
