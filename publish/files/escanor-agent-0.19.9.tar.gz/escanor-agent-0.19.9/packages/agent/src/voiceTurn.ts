import { spawn } from 'node:child_process';
import { existsSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { desktopEnv, runComputerAction, type ComputerAction } from './computerControl.js';
import { recordSentence, NoMicrophone, type Heard, type RecordDeps } from './voiceAudio.js';
import { speak } from './voiceSpeak.js';
import { transcribe, type TranscribeConn, type Transcript } from './voiceTranscribe.js';
import { answerSentence, type BridgeAnswer, type BridgeRequest, type TurnResult } from './voiceAssistant.js';
import { askBridge, socketPath } from './voiceBridge.js';

/**
 * One push-to-talk turn (`escanor-agent voice`): listen, turn the speech into text, do what it asks, say what happened.
 * The keyboard shortcut starts it; pressing the shortcut again while it runs sends SIGUSR1 to it (the pid file), which ends the
 * listening at once, or stops the talking.
 */

export type TurnIo = {
  record: (signal: AbortSignal) => Promise<Heard>;
  transcribe: (wav: Buffer, seconds: number) => Promise<Transcript>;
  speak: (text: string, signal: AbortSignal) => Promise<string | null>;
  device: (a: ComputerAction) => ReturnType<typeof runComputerAction>;
  bridge: ((r: BridgeRequest) => Promise<BridgeAnswer>) | null;
  /** A short line on screen ("Listening", what was heard). */
  show: (line: string) => void;
};

export type TurnOptions = { text?: string; speakReplies?: boolean };

export type TurnOutcome = { heard: string; reply: string; ok: boolean; result?: TurnResult };

export async function voiceTurn(io: TurnIo, signal: AbortSignal, o: TurnOptions = {}): Promise<TurnOutcome> {
  let heard = (o.text ?? '').trim();
  if (!o.text) {
    io.show('Listening...');
    let got: Heard;
    try {
      got = await io.record(signal);
    } catch (e) {
      const say = e instanceof NoMicrophone ? `I cannot use the microphone: ${e.message} Install pulseaudio-utils (parec) or alsa-utils (arecord).` : 'I could not use the microphone.';
      io.show(say);
      return { heard: '', reply: say, ok: false };
    }
    if (!got.heard) {
      const say = 'I did not hear anything.';
      io.show(say);
      return { heard: '', reply: say, ok: false };
    }
    io.show('Thinking...');
    const t = await io.transcribe(got.wav, got.ms / 1000);
    if (!t.ok) {
      io.show(t.say);
      if (o.speakReplies !== false) await io.speak(t.say, signal).catch(() => null);
      return { heard: '', reply: t.say, ok: false };
    }
    heard = t.text;
    if (!heard) {
      const say = 'I did not catch any words.';
      io.show(say);
      return { heard: '', reply: say, ok: false };
    }
  }
  io.show(`Heard: ${heard}`);
  const result = await answerSentence(heard, { device: io.device, bridge: io.bridge });
  io.show(result.say);
  if (o.speakReplies !== false && !result.stop) await io.speak(result.say, signal).catch(() => null);
  return { heard, reply: result.say, ok: result.ok, result };
}

// ------------------------------------------------------------------------------------------------ the real one

const pidFile = (dataDir: string) => join(dataDir, 'voice.pid');

function alive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/** Another voice turn is running: ask it to stop listening (or talking) and return true. */
export function toggleRunning(dataDir: string, kill: (pid: number, sig: NodeJS.Signals) => void = (p, s) => process.kill(p, s)): boolean {
  const f = pidFile(dataDir);
  if (!existsSync(f)) return false;
  const pid = Number(readFileSync(f, 'utf8').trim());
  if (!Number.isInteger(pid) || pid <= 1 || pid === process.pid || !alive(pid)) return false;
  try {
    kill(pid, 'SIGUSR1');
    return true;
  } catch {
    return false;
  }
}

function notify(line: string): void {
  if (process.platform !== 'linux') return;
  try {
    const p = spawn('notify-send', ['--expire-time=3000', '--app-name=Escanor', 'Escanor', line.slice(0, 200)], { stdio: 'ignore' });
    p.on('error', () => undefined);
    p.unref();
  } catch {
    // no notifier: the line is on the terminal only
  }
}

export type RealOptions = TurnOptions & { dataDir: string; conn: TranscribeConn | string; env?: NodeJS.ProcessEnv; json?: boolean };

/** Run one turn for real. Returns the process exit code. */
export async function runVoice(o: RealOptions, out: (s: string) => void = (s) => process.stdout.write(`${s}\n`)): Promise<number> {
  if (toggleRunning(o.dataDir)) return 0;
  // Started by a keyboard shortcut or a service, the sound server and screen may not be named in its environment: fill them in.
  const env = desktopEnv(o.env ?? process.env);
  const ac = new AbortController();
  const stop = () => ac.abort();
  let phase: 'listening' | 'talking' = 'listening';
  const onUsr1 = () => {
    if (phase === 'talking') speakAbort.abort();
    stop();
  };
  const speakAbort = new AbortController();
  process.on('SIGUSR1', onUsr1);
  const f = pidFile(o.dataDir);
  try {
    writeFileSync(f, String(process.pid), { mode: 0o600 });
  } catch {
    // no data folder: the shortcut just cannot toggle
  }
  try {
    const io: TurnIo = {
      record: (signal) => {
        phase = 'listening';
        const deps: RecordDeps = { signal, env };
        return recordSentence(deps);
      },
      transcribe: async (wav, seconds) => (typeof o.conn === 'string' ? { ok: false, say: `I cannot turn speech into text: ${o.conn}.` } : transcribe(o.conn, wav, { seconds })),
      speak: (text) => {
        phase = 'talking';
        return speak(text, { signal: speakAbort.signal, env });
      },
      device: (a) => runComputerAction(a, { env }),
      bridge: (r) => askBridge(socketPath(o.dataDir), r),
      show: (line) => {
        out(line);
        notify(line);
      },
    };
    const r = await voiceTurn(io, ac.signal, o);
    return r.ok ? 0 : 1;
  } finally {
    process.off('SIGUSR1', onUsr1);
    try {
      if (existsSync(f) && Number(readFileSync(f, 'utf8').trim()) === process.pid) unlinkSync(f);
    } catch {
      // gone already
    }
  }
}
