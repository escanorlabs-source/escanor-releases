import { chmodSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { autonomousBlockReason as autonomousReason, BLOCKED_COMMANDS, BLOCKED_PATHS, normalizeCommand, PROTECTED_BRANCHES, RM_TARGETS } from '@remote-harness/shared/autonomy';
import { riskyToolCall } from '@remote-harness/shared/risk';
import { defaultCtx, personalRisk } from './personalGuard.js';
import { commandRunner, remoteWriteBlockReason } from './writeRepos.js';
import { gitRunner, pushScanVerdict } from './pushScan.js';

/**
 * The Autonomous blocklist (shared/autonomy.ts) for chats on ChatGPT, Gemini and GitHub Copilot accounts. A Claude chat gets it from the agent's
 * PreToolUse hook; these tools run their own tool calls, so each is given the same check its own way:
 * - Codex: a PreToolUse hook (CODEX_HOME/hooks.json) that runs cliGuardHook.ts, which asks autonomousBlockReason itself. Codex
 *   runs hooks only once trusted, so a guarded run passes --dangerously-bypass-hook-trust.
 * - Gemini: a BeforeTool hook in the account's settings.json (the same script), plus a policy file (--policy) with deny rules
 *   for the same commands, as Gemini's policy engine reads them (a second line that holds even if the hook cannot run).
 * - Copilot: a PreToolUse hook in the account's settings.json (COPILOT_HOME), written under Claude Code's event name so Copilot
 *   hands it Claude Code's field names (tool_name, tool_input); run with --copilot, the hook answers in Copilot's way (a JSON
 *   permissionDecision on stdout, which Copilot passes on to the AI with the reason). Copilot's own --deny-tool rules for the worst
 *   commands are a second line (COPILOT_FALLBACK_DENY).
 * The hook only refuses in a run marked ESCANOR_AUTONOMOUS=1 (a chat not explicitly set to "Bypass permissions"); a chat that is
 * explicitly in bypass runs without it, as on Claude.
 */

export const AUTONOMOUS_ENV = 'ESCANOR_AUTONOMOUS';
/**
 * Risky commands (shared/risk.ts), checked in every mode, explicit "Bypass permissions" included, when the safety net is on
 * (riskHold.ts ESCANOR_RISK_HOLDS). A Claude chat holds them for the
 * person's Approve on the phone; these tools cannot wait for that, so their hook refuses them with the reason.
 */
export const RISK_CHECK_ENV = 'ESCANOR_RISK_CHECK';
/** Set in a chat's environment on a personal computer: the stricter rules of personalGuard.ts apply as well. */
export const PERSONAL_ENV = 'ESCANOR_PERSONAL';
/**
 * The push-for-keys check (pushScan.ts), asked for in every mode a ChatGPT or Gemini chat runs in (Autonomous, Bypass, anything), as
 * Claude chats are checked in every mode. Set unless SECRET_PUSH_SCAN=0.
 */
export const PUSH_SCAN_ENV = 'ESCANOR_PUSH_SCAN';
/** The repositories a repo-limited chat may change on a remote (JSON list), checked by the same hook (writeRepos.ts). */
export const WRITE_REPOS_ENV = 'ESCANOR_WRITE_REPOS';
export const GUARD_HOOK_NAME = 'escanor-autonomous-guard';
export const GEMINI_POLICY_FILE = 'escanor-autonomous-policy.toml';

/** What the AI is told when a tool call is refused (the same words as a Claude chat's). */
export function blockedMessage(why: string): string {
  return (
    `Escanor blocked this: ${why} An Autonomous chat never does that on its own. Find another way to reach the goal, or stop and ` +
    'say what you need: the person can do it themselves, or set this chat to "Bypass permissions".'
  );
}

const SHELL_TOOLS = new Set(['Bash', 'shell', 'local_shell', 'exec_command', 'unified_exec', 'run_shell_command', 'container.exec', 'bash', 'powershell', 'PowerShell']);
/** Codex's tools that type into a command already running (its exec sessions), and Copilot's (write_bash / write_powershell). */
const STDIN_TOOLS = new Set(['write_stdin', 'send_input', 'exec_command_input', 'write_bash', 'write_powershell']);

/**
 * Copilot's deny rules (--deny-tool) for a checked chat: a second line under the hook, and the only one where the hook cannot run.
 * Deny rules win over every allow, --allow-all included.
 */
export const COPILOT_FALLBACK_DENY: readonly string[] = ['shell(sudo)', 'shell(rm)', 'shell(git push)', 'shell(dd)'];

/** Copilot's own tool names, where its hook input does not already use Claude Code's. */
const COPILOT_HOOK_NAMES: Record<string, string> = { bash: 'Bash', powershell: 'Bash', view: 'Read', create: 'Write', edit: 'Edit', str_replace: 'Edit' };

/**
 * A Copilot hook call as the checks read it: a patch (Copilot hands its apply_patch over as a bare string, named Edit) becomes
 * apply_patch, `path` becomes `file_path`, its own tool names become Claude Code's.
 */
export function copilotHookCall(toolName: string, toolInput: unknown): { toolName: string; toolInput: unknown } {
  if (typeof toolInput === 'string') return { toolName: 'apply_patch', toolInput: { input: toolInput } };
  const name = COPILOT_HOOK_NAMES[toolName] ?? toolName;
  if (toolInput && typeof toolInput === 'object' && !Array.isArray(toolInput)) {
    const i = { ...(toolInput as Record<string, unknown>) };
    if (i.file_path === undefined && typeof i.path === 'string' && (name === 'Read' || name === 'Write' || name === 'Edit')) i.file_path = i.path;
    if (i.command === undefined && STDIN_TOOLS.has(name) && typeof i.input === 'string') i.chars = i.input;
    return { toolName: name, toolInput: i };
  }
  return { toolName: name, toolInput };
}

/** The hook's answer as Copilot reads it: nothing to let a call run; a JSON refusal (with the reason) otherwise. */
export function copilotHookOutput(v: { code: 0 | 2; stderr?: string }): string {
  if (v.code === 0) return '';
  return JSON.stringify({ hookSpecificOutput: { hookEventName: 'PreToolUse', permissionDecision: 'deny', permissionDecisionReason: v.stderr ?? 'Escanor blocked this.' } });
}

/**
 * Programs that, started with nothing to run, read what to do from their input. Codex can type into a running command
 * (write_stdin) and its hooks never see what it types (probed with codex 0.160), so in a checked chat a shell, interpreter or
 * database client may only be started with its work on the command line (`bash -c ...`, `python3 x.py`, `psql -c ...`).
 */
const SHELLS = new Set(['bash', 'sh', 'zsh', 'dash', 'ksh', 'fish', 'csh', 'tcsh', 'ash', 'busybox']);
const INTERPRETERS = new Set(['python', 'python2', 'python3', 'node', 'nodejs', 'deno', 'bun', 'perl', 'ruby', 'irb', 'php', 'lua', 'R', 'ghci', 'scala', 'jshell', 'tclsh', 'pwsh', 'powershell']);
const DB_CLIENTS: Record<string, string[]> = {
  psql: ['-c', '--command', '-f', '--file', '-l', '--list', '--version', '-V', '--help'],
  mysql: ['-e', '--execute', '--version', '-V', '--help'],
  mariadb: ['-e', '--execute', '--version', '-V', '--help'],
  sqlite3: ['-cmd', '-version', '--version', '-help'],
  mongosh: ['--eval', '-f', '--file', '--version', '--help'],
  mongo: ['--eval', '--version', '--help'],
  'redis-cli': [],
  sqlcmd: ['-Q', '-q', '-i', '-?'],
};
const WRAPPERS = new Set(['sudo', 'exec', 'env', 'nohup', 'time', 'nice', 'stdbuf', 'timeout', 'script', 'unbuffer', 'rlwrap', 'command', 'builtin']);
export const INTERACTIVE_WHY = 'starts a program that reads its commands as they are typed, which Escanor cannot check (put the work on its command line, e.g. bash -c "..." or python3 script.py)';

/** Why this command line starts something the chat could type unchecked commands into, or null. */
export function interactiveReason(command: string): string | null {
  for (const segment of normalizeCommand(command).split(/&&|\|\||[;&\n]/)) {
    // Its input is not the chat's when it comes from a file or a here-document.
    const parts = segment.split('|');
    for (let pi = 0; pi < parts.length; pi++) {
      const part = parts[pi];
      if (/<(?!\()/.test(part)) continue;
      const words = part.trim().split(/ +/).filter(Boolean).map((w) => w.replace(/^["']|["']$/g, ''));
      let i = 0;
      while (i < words.length && (/^[A-Za-z_][A-Za-z0-9_]*=/.test(words[i]) || WRAPPERS.has(words[i].replace(/^.*\//, '')) || (i > 0 && WRAPPERS.has(words[i - 1].replace(/^.*\//, '')) && words[i].startsWith('-')) || /^\d+[smhd]?$/.test(words[i]))) i++;
      if (i >= words.length) continue;
      const prog = words[i].replace(/^.*\//, '');
      const args = words.slice(i + 1);
      const piped = pi > 0; // `curl x | sh`: what it runs comes from the pipe, unseen
      if (SHELLS.has(prog)) {
        const hasC = args.some((a) => /^-[a-zA-Z]*c[a-zA-Z]*$/.test(a) || a === '--command');
        const readsInput = args.some((a) => /^-[a-zA-Z]*[is][a-zA-Z]*$/.test(a) || a === '-' || a === '--interactive');
        const script = args.some((a) => !a.startsWith('-') && !a.startsWith('+'));
        if (readsInput || (!hasC && !script) || (piped && !hasC && !script)) return INTERACTIVE_WHY;
        continue;
      }
      if (INTERPRETERS.has(prog)) {
        const work = args.some((a) => ['-c', '-e', '-m', '--eval', '-p', '--print', '-r', '--version', '-V', '--help', '-h'].includes(a) || (!a.startsWith('-') && a !== '-'));
        const readsInput = args.some((a) => a === '-i' || a === '-' || a === '--interactive' || a === '-a');
        if (readsInput || !work) return INTERACTIVE_WHY;
        continue;
      }
      if (prog in DB_CLIENTS) {
        const flags = DB_CLIENTS[prog];
        const positional = args.filter((a) => !a.startsWith('-'));
        const work = args.some((a) => flags.includes(a) || flags.some((f) => f.startsWith('--') && a.startsWith(`${f}=`))) || (prog === 'sqlite3' && positional.length >= 2) || (prog === 'redis-cli' && positional.length >= 1);
        if (!work) return INTERACTIVE_WHY;
      }
    }
  }
  return null;
}
const GEMINI_FILE_TOOLS: Record<string, string> = { write_file: 'Write', replace: 'Edit' };

/** What the AI is told when a risky command is refused in a ChatGPT or Gemini chat. */
export function riskRefusedMessage(why: string): string {
  return (
    `Escanor stopped this command. ${why} A ChatGPT, Gemini or Copilot chat cannot wait for the person's OK on the phone, so a command like ` +
    'this never runs from it. Find a safer way, or stop and say what you need: the person can run it themselves, or use a Claude chat.'
  );
}

/** Why a tool call is a risky command (only commands count: a patch or a file being written is not one), or null. */
export function riskReason(toolName: string, toolInput: unknown): string | null {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  if (toolName === 'apply_patch' || GEMINI_FILE_TOOLS[toolName]) return null;
  if (STDIN_TOOLS.has(toolName)) return riskyToolCall('Bash', { command: String(input.chars ?? input.input ?? input.text ?? '') })?.why ?? null;
  return riskyToolCall(toolName, input)?.why ?? null;
}

/** Why a call is held on a personal computer (personalGuard.ts), or null. A patch is read by the files it names. */
function personalWhy(toolName: string, toolInput: unknown, cwd: string, env: NodeJS.ProcessEnv): string | null {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  const ctx = defaultCtx(cwd, [], env);
  if (toolName === 'apply_patch') {
    const patch = String(input.input ?? input.patch ?? input.command ?? '');
    for (const f of patchPaths(patch)) {
      const r = personalRisk('Write', { file_path: f }, ctx);
      if (r) return r.why;
    }
    return null;
  }
  const call = GEMINI_FILE_TOOLS[toolName] ? { name: GEMINI_FILE_TOOLS[toolName]!, input: { file_path: input.file_path ?? input.path ?? input.absolute_path } } : STDIN_TOOLS.has(toolName) ? { name: 'Bash', input: { command: String(input.chars ?? input.input ?? input.text ?? '') } } : { name: toolName, input };
  return personalRisk(call.name, call.input, ctx)?.why ?? null;
}

/** The files a Codex apply_patch touches ("*** Update File: path" lines). */
function patchPaths(patch: string): string[] {
  return [...patch.matchAll(/^\*\*\* (?:Add|Update|Delete) File: (.+)$/gm)].map((m) => m[1].trim());
}

/**
 * Why a tool call (as a Codex or Gemini hook sees it: tool_name + tool_input) must not run in an Autonomous chat, or null.
 * Shell tools are checked as Claude's Bash, file tools as Write/Edit, anything else as Claude checks any tool (a command field).
 */
export function guardReason(toolName: string, toolInput: unknown, textAware = false): string | null {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  const autonomousBlockReason = (name: string, i: unknown) => autonomousReason(name, i, { textAware });
  if (SHELL_TOOLS.has(toolName)) {
    const raw = input.command;
    const command = Array.isArray(raw) ? raw.map(String).join(' ') : String(raw ?? input.cmd ?? '');
    const why = autonomousBlockReason('Bash', { command });
    if (why) return why;
    // Gemini's shell runs a command to its end; Codex's can be typed into afterwards (see interactiveReason).
    if (toolName !== 'run_shell_command') {
      const typed = interactiveReason(command);
      if (typed) return `That ${typed}.`;
    }
    return null;
  }
  if (STDIN_TOOLS.has(toolName)) {
    // Should Codex ever show these to its hooks: what is typed is checked as a command.
    return autonomousBlockReason('Bash', { command: String(input.chars ?? input.input ?? input.text ?? '') });
  }
  if (toolName === 'apply_patch') {
    const patch = String(input.command ?? input.patch ?? input.input ?? '');
    for (const file_path of patchPaths(patch)) {
      const why = autonomousBlockReason('Write', { file_path });
      if (why) return why;
    }
    return null;
  }
  if (GEMINI_FILE_TOOLS[toolName]) {
    const file_path = String(input.file_path ?? input.absolute_path ?? input.path ?? '');
    return autonomousBlockReason(GEMINI_FILE_TOOLS[toolName], { file_path });
  }
  return autonomousBlockReason(toolName, input);
}

/** The repositories a repo-limited run may change, from its environment; undefined when it has no limit. */
function writeReposOf(env: NodeJS.ProcessEnv): string[] | undefined {
  const raw = env[WRITE_REPOS_ENV];
  if (raw === undefined || raw === '') return undefined;
  const list = JSON.parse(raw) as unknown;
  if (!Array.isArray(list) || !list.every((r) => typeof r === 'string')) throw new Error('bad repository list');
  return list as string[];
}

/** Codex's and Gemini's tool names for running a command, as Claude's check of a repo-limited chat reads them. */
function asClaudeCall(toolName: string, toolInput: unknown): { name: string; input: unknown } {
  const input = (toolInput && typeof toolInput === 'object' ? toolInput : {}) as Record<string, unknown>;
  if (SHELL_TOOLS.has(toolName)) {
    const raw = input.command;
    return { name: 'Bash', input: { command: Array.isArray(raw) ? raw.map(String).join(' ') : String(raw ?? input.cmd ?? '') } };
  }
  if (STDIN_TOOLS.has(toolName)) return { name: 'Bash', input: { command: String(input.chars ?? input.input ?? '') } };
  return { name: toolName, input };
}

/**
 * The hook's answer for one call: exit 0 (let it run) or 2 with the reason on stderr (both tools then refuse the call). A repo-limited
 * chat (WRITE_REPOS_ENV) is checked as a Claude one is, whatever its mode: git and ssh run as the hook runs, which is as the chat's
 * own commands run (same user, folder and environment).
 */
export async function hookVerdict(
  stdin: string,
  env: NodeJS.ProcessEnv,
  o: { remoteWrite?: typeof remoteWriteBlockReason; pushScan?: typeof pushScanVerdict; copilot?: boolean } = {},
): Promise<{ code: 0 | 2; stderr?: string }> {
  const autonomous = env[AUTONOMOUS_ENV] === '1';
  const risk = env[RISK_CHECK_ENV] === '1';
  if (!autonomous && !risk && !env[WRITE_REPOS_ENV] && env[PUSH_SCAN_ENV] !== '1') return { code: 0 };
  try {
    const j = JSON.parse(stdin) as { tool_name?: unknown; tool_input?: unknown; cwd?: unknown };
    if (o.copilot) {
      const c = copilotHookCall(String(j.tool_name ?? ''), j.tool_input);
      j.tool_name = c.toolName;
      j.tool_input = c.toolInput;
    }
    const toolName = String(j.tool_name ?? '');
    // F2 (pushScan.ts): a push that adds a key, or a pull request or comment whose words hold one, does not run (any mode this
    // hook is installed in). A scan that cannot run lets it through.
    if (SHELL_TOOLS.has(toolName) || STDIN_TOOLS.has(toolName)) {
      const call = asClaudeCall(toolName, j.tool_input);
      const scan = await (o.pushScan ?? pushScanVerdict)(call.input, {
        cwd: typeof j.cwd === 'string' && j.cwd ? j.cwd : process.cwd(),
        env,
        run: gitRunner(env),
      });
      if (scan.why) return { code: 2, stderr: scan.why };
    }
    const repos = writeReposOf(env);
    if (repos) {
      const call = asClaudeCall(toolName, j.tool_input);
      const why = await (o.remoteWrite ?? remoteWriteBlockReason)(call.name, call.input, {
        allowed: repos,
        cwd: typeof j.cwd === 'string' && j.cwd ? j.cwd : process.cwd(),
        home: env.HOME ?? homedir(),
        env,
        run: commandRunner(env),
      });
      if (why) return { code: 2, stderr: why };
    }
    if (autonomous) {
      const why = guardReason(toolName, j.tool_input, risk);
      if (why) return { code: 2, stderr: blockedMessage(why) };
    }
    if (risk) {
      const why = riskReason(toolName, j.tool_input) ?? (env[PERSONAL_ENV] === '1' ? personalWhy(toolName, j.tool_input, typeof j.cwd === 'string' && j.cwd ? j.cwd : process.cwd(), env) : null);
      if (why) return { code: 2, stderr: riskRefusedMessage(why) };
    }
    return { code: 0 };
  } catch {
    // A check that fails must not let the command through.
    return { code: 2, stderr: 'Escanor could not check this command, so it was blocked.' };
  }
}

const sq = (s: string, platform: NodeJS.Platform = process.platform) =>
  platform === 'win32' ? `"${s.replace(/"/g, '')}"` : `'${s.replace(/'/g, `'\\''`)}'`;

/** The command both tools run as the hook: this Node, with tsx (the agent runs from its TypeScript), and cliGuardHook.ts. */
export function guardHookCommand(platform: NodeJS.Platform = process.platform): string | null {
  try {
    // --import takes a URL on Windows (a C:\ path would read as a "c:" scheme); import.meta.resolve already gives one.
    const tsx = import.meta.resolve('tsx');
    const hook = fileURLToPath(new URL('./cliGuardHook.ts', import.meta.url));
    return `${sq(process.execPath, platform)} --import ${sq(tsx, platform)} ${sq(hook, platform)}`;
  } catch {
    return null;
  }
}

function readJson(file: string): Record<string, unknown> {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
    return j && typeof j === 'object' && !Array.isArray(j) ? (j as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

type HookEntry = { matcher?: string; hooks?: Array<Record<string, unknown>> };

/** [list] with our hook as its own entry (replacing an older one of ours), everything else kept. */
function withGuard(list: unknown, hook: Record<string, unknown>): HookEntry[] {
  const kept = (Array.isArray(list) ? (list as HookEntry[]) : []).filter((e) => !e?.hooks?.some((h) => h?.name === GUARD_HOOK_NAME));
  return [...kept, { hooks: [hook] }];
}

function writePrivate(file: string, text: string): void {
  writeFileSync(file, text, { mode: 0o600 });
  chmodSync(file, 0o600);
}

/** Codex: our PreToolUse hook in the account's hooks.json (only written when it changes). */
export function installCodexGuard(codexHome: string, command: string): void {
  const file = join(codexHome, 'hooks.json');
  const cur = readJson(file);
  const hooks = (cur.hooks && typeof cur.hooks === 'object' ? cur.hooks : {}) as Record<string, unknown>;
  const next = { ...cur, hooks: { ...hooks, PreToolUse: withGuard(hooks.PreToolUse, { type: 'command', command, name: GUARD_HOOK_NAME }) } };
  const text = JSON.stringify(next, null, 2);
  if (JSON.stringify(cur, null, 2) === text) return;
  mkdirSync(codexHome, { recursive: true, mode: 0o700 });
  writePrivate(file, text);
}

/**
 * Copilot: our PreToolUse hook in the account's settings.json (COPILOT_HOME). Written under Claude Code's event name, so
 * Copilot gives it Claude Code's field names; run with --copilot so it answers the way Copilot reads.
 */
export function installCopilotGuard(copilotHome: string, command: string): void {
  const file = join(copilotHome, 'settings.json');
  const cur = readJson(file);
  const hooks = (cur.hooks && typeof cur.hooks === 'object' ? cur.hooks : {}) as Record<string, unknown>;
  const next = { ...cur, hooks: { ...hooks, PreToolUse: withGuard(hooks.PreToolUse, { type: 'command', command: `${command} --copilot`, name: GUARD_HOOK_NAME, timeout: 60 }) } };
  const text = JSON.stringify(next, null, 2);
  if (JSON.stringify(cur, null, 2) === text) return;
  mkdirSync(copilotHome, { recursive: true, mode: 0o700 });
  writePrivate(file, text);
}

/** Gemini: our BeforeTool hook in the account's settings.json (GEMINI_CLI_HOME/.gemini), hooks left on. */
export function installGeminiGuard(geminiHome: string, command: string): void {
  const dir = join(geminiHome, '.gemini');
  const file = join(dir, 'settings.json');
  const cur = readJson(file);
  const hooks = (cur.hooks && typeof cur.hooks === 'object' ? cur.hooks : {}) as Record<string, unknown>;
  const hooksConfig = (cur.hooksConfig && typeof cur.hooksConfig === 'object' ? cur.hooksConfig : {}) as Record<string, unknown>;
  const disabled = Array.isArray(hooksConfig.disabled) ? (hooksConfig.disabled as unknown[]).filter((n) => n !== GUARD_HOOK_NAME) : hooksConfig.disabled;
  const next = {
    ...cur,
    hooksConfig: { ...hooksConfig, enabled: true, ...(disabled !== undefined ? { disabled } : {}) },
    hooks: { ...hooks, BeforeTool: withGuard(hooks.BeforeTool, { type: 'command', command, name: GUARD_HOOK_NAME, timeout: 30_000 }) },
  };
  const text = JSON.stringify(next, null, 2);
  if (JSON.stringify(cur, null, 2) === text) return;
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  writePrivate(file, text);
}

/** A regular expression's letters made to match either case (outside escapes and [...] classes): JS has no inline (?i). */
export function caseless(source: string): string {
  let out = '';
  let inClass = false;
  for (let i = 0; i < source.length; i++) {
    const c = source[i];
    if (c === '\\') {
      out += c + (source[i + 1] ?? '');
      i++;
      continue;
    }
    if (c === '[') inClass = true;
    else if (c === ']') inClass = false;
    const lo = c.toLowerCase();
    const up = c.toUpperCase();
    out += !inClass && lo !== up ? `[${lo}${up}]` : c;
  }
  return out;
}

const esc = (s: string) => s.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
/**
 * Gemini refuses a pattern its ReDoS check calls unsafe (isSafeRegExp: a group holding a quantifier, then a quantified group), so
 * these never quantify a group: words are matched with classes instead.
 */
export function isSafeForGemini(pattern: string): boolean {
  try {
    new RegExp(pattern);
  } catch {
    return false;
  }
  return pattern.length <= 2048 && !/\([^)]*[*+?{].*\)[*+?{]/.test(pattern);
}
/** Where a shell word ends inside Gemini's JSON-encoded command: space, quote, an operator, or an escaped newline. */
const END = String.raw`(?:\s|"|;|&|\||\\n)`;
/** Anything up to the end of this command (not into the next one, nor out of the JSON string). */
const SEG = String.raw`[^;&|"\n]*`;
const WORD = String.raw`[^-\s;&|"][^\s;&|"]*`;
/** The end of the command itself (not just of a word). */
const STOP = String.raw`\s*(?:"|;|&|\||\\n)`;
const BRANCH = String.raw`\b(?:${PROTECTED_BRANCHES.map(esc).join('|')})\b`;
const FORCE = String.raw`(?:--force|-[a-zA-Z]*f)`;

type DenyRule = { toolName: string | string[]; commandRegex?: string; argsPattern?: string; why: string };

/** BLOCKED_COMMANDS as Gemini can take them: the same pattern, or a plain one that matches the same commands. */
function commandPattern(source: string, ignoreCase: boolean | undefined): string {
  const s = source === String.raw`\bmkfs(\.\w+)?\b` ? String.raw`\bmkfs\b` : source;
  return ignoreCase ? caseless(s) : s;
}

/**
 * The blocklist as Gemini policy rules. Gemini tests `"command":"<commandRegex>` against the call's JSON arguments (and each
 * command of a `a && b` line on its own), so each rule starts with `.*` to look anywhere in it. The word-by-word rules (rm of a
 * root, force push over a main branch...) are written as patterns: close, not exact (the hook does the exact check).
 */
export function geminiDenyRules(): DenyRule[] {
  const shell = 'run_shell_command';
  const rules: DenyRule[] = BLOCKED_COMMANDS.map((b) => ({ toolName: shell, commandRegex: `.*${commandPattern(b.source, b.ignoreCase)}`, why: b.why }));
  const targets = `(?:${[...new Set(RM_TARGETS.map((t) => (t.length > 1 ? t.replace(/\/$/, '') : t)))].map(esc).join('|')})`;
  const rmFlag = String.raw`(?:-[a-zA-Z]*[rRfF]|--recursive|--force)`;
  // A root, maybe quoted (\" in the JSON), maybe followed by globs or dots (~/*, /home/*/*, ~/.., /./).
  const target = String.raw`\\?"?${targets}\\?"?[/*.]*`;
  const wipe = 'wipes the machine or a home folder';
  const forceMain = 'force-pushes over a main branch';
  const forceAny = 'force-pushes without naming a branch';
  const delMain = 'deletes a main branch on the remote';
  rules.push(
    { toolName: shell, commandRegex: String.raw`.*\brm\b${SEG}\s${rmFlag}${SEG}\s${target}${END}`, why: wipe },
    { toolName: shell, commandRegex: String.raw`.*\brm\b${SEG}\s${target}\s${SEG}${rmFlag}`, why: wipe },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s${FORCE}${SEG}${BRANCH}`, why: forceMain },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}${BRANCH}${SEG}\s${FORCE}`, why: forceMain },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s\+[^\s;&|"]*${BRANCH}`, why: forceMain },
    // A force push naming no branch (at most the remote) goes wherever the push default points, which can be main.
    { toolName: shell, commandRegex: String.raw`.*\bpush\s+${FORCE}[^\s;&|"]*${STOP}`, why: forceAny },
    { toolName: shell, commandRegex: String.raw`.*\bpush\s+${FORCE}[^\s;&|"]*\s+${WORD}${STOP}`, why: forceAny },
    { toolName: shell, commandRegex: String.raw`.*\bpush\s+${WORD}\s+${FORCE}[^\s;&|"]*${STOP}`, why: forceAny },
    // HEAD / @ is the current branch, which may be main.
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s\+(?:HEAD|@)${END}`, why: forceAny },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s${FORCE}${SEG}\s(?:HEAD|@)${END}`, why: forceAny },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s(?:HEAD|@)\s${SEG}${FORCE}`, why: forceAny },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s:[^\s;&|"]*${BRANCH}`, why: delMain },
    { toolName: shell, commandRegex: String.raw`.*\bpush\b${SEG}\s(?:--delete|-[a-zA-Z]*d)\b${SEG}${BRANCH}`, why: delMain },
    { toolName: shell, commandRegex: String.raw`.*\bdd\b${SEG}\bof=/dev/`, why: 'writes straight onto a disk' },
    { toolName: shell, commandRegex: String.raw`.*\bchmod\s${SEG}\b[0-7]*777\s+/${END}`, why: 'opens up every file on the machine' },
  );
  for (const p of BLOCKED_PATHS) {
    const body = p.source.startsWith('^') ? p.source.slice(1) : `[^"]*${p.source.replace(/^\(\?:\^\|\/\)/, '/')}`;
    rules.push({ toolName: ['write_file', 'replace'], argsPattern: `"file_path":"${body.replace(/\$$/, '"')}`, why: `changes ${p.why}` });
  }
  return rules;
}

const tomlString = (s: string) => JSON.stringify(s);

/** Gemini's policy file: one deny rule each, above everything a chat's mode allows (user tier, highest priority). */
export function geminiPolicyToml(): string {
  const lines = ['# Escanor: what an Autonomous chat never does on its own. Written by the Escanor agent; changes are overwritten.', ''];
  for (const r of geminiDenyRules()) {
    lines.push('[[rule]]');
    lines.push(`toolName = ${Array.isArray(r.toolName) ? `[${r.toolName.map(tomlString).join(', ')}]` : tomlString(r.toolName)}`);
    if (r.commandRegex) lines.push(`commandRegex = ${tomlString(r.commandRegex)}`);
    if (r.argsPattern) lines.push(`argsPattern = ${tomlString(r.argsPattern)}`);
    lines.push('decision = "deny"', 'priority = 999', `denyMessage = ${tomlString(blockedMessage(`That ${r.why}.`))}`, '');
  }
  return lines.join('\n');
}

/** Writes the policy file into the account's .gemini folder (0600) and returns its path. */
export function writeGeminiPolicy(geminiHome: string): string {
  const dir = join(geminiHome, '.gemini');
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = join(dir, GEMINI_POLICY_FILE);
  writePrivate(file, geminiPolicyToml());
  return file;
}
