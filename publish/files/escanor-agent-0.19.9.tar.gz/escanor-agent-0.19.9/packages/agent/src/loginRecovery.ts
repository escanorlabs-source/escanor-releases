import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { Exec } from './brokerExec.js';
import type { CredentialBroker, UseProof } from './signinBroker.js';

/**
 * Signing the saved logins back in (uses the credential broker, signinBroker.ts). It runs ONLY for a request the owner approved on the
 * phone with a fingerprint (or inside the window they gave with one), never by itself or on a timer. It looks at how this computer's
 * saved logins are and, for what the owner allowed, signs back in:
 *   1. the desktop keyring (after a restart it is locked, so every stored login stops working): unlocked from the vault secret
 *      LAPTOP_KEYRING_PASSWORD (else LAPTOP_SUDO_PASSWORD) through `gnome-keyring-daemon --unlock` on standard input;
 *   2. the GitHub command line (invalid tokens): `gh auth login --with-token` from the vault secret GITHUB_TOKEN_<ACCOUNT>;
 *   3. git: made to ask the GitHub command line for its login when nothing else answers;
 *   4. sudo: reported as ready or not (the password is only used for the commands the owner listed).
 * The plain-words report of what it checked and fixed is kept (names only, never a value) and shown in the app. After three failures
 * in a row an item is not tried again (a wrong saved password must not lock anything), until the owner approves a fresh check.
 */

export type ItemStatus = 'ok' | 'fixed' | 'failed' | 'skipped';
export type ItemId = 'keyring' | 'gh' | 'git' | 'sudo';
export type RecoveryItem = { id: ItemId; title: string; status: ItemStatus; say: string };
export type CheckOpts = { /** The approval this check rides on. Without one nothing is used. */ proof: UseProof; /** Try again the items that stopped after three failures. */ force?: boolean; /** Only these items (default: all). */ only?: ItemId[]; /** For GitHub: only this account. */ account?: string };
export type RecoveryReport = { at: number; items: RecoveryItem[] };

export const KEYRING_SECRETS = ['LAPTOP_KEYRING_PASSWORD', 'LAPTOP_SUDO_PASSWORD'] as const;
export const SUDO_SECRET = 'LAPTOP_SUDO_PASSWORD';
const MAX_TRIES = 3;

export const ghVaultName = (account: string): string => `GITHUB_TOKEN_${account.toUpperCase().replace(/[^A-Z0-9]/g, '_')}`;

export type GhStatus = { loggedIn: string[]; failing: string[]; notLoggedIn: boolean };

/** What `gh auth status` says, as account names. Handles the current and the older wording. */
export function parseGhStatus(text: string): GhStatus {
  const loggedIn: string[] = [];
  const failing: string[] = [];
  for (const line of text.split('\n')) {
    let m = /Failed to log in to \S+ account (\S+)/i.exec(line);
    if (m) {
      failing.push(m[1]);
      continue;
    }
    m = /Logged in to \S+ account (\S+)/i.exec(line) ?? /Logged in to \S+ as (\S+)/i.exec(line);
    if (m) loggedIn.push(m[1]);
  }
  return { loggedIn, failing, notLoggedIn: /not logged in/i.test(text) };
}

const NO_KEYRING = 'This computer has no desktop keyring to unlock.';

export class LoginRecovery {
  private running = false;
  private failures = new Map<string, number>();
  private last: RecoveryReport | null = null;

  constructor(
    private d: {
      broker: CredentialBroker;
      exec: Exec;
      /** Where the last report is kept (names only). */
      reportFile?: string;
      now?: () => number;
      platform?: NodeJS.Platform;
      /** The secret names on the allow list that are not patterns (to find GitHub accounts when none is logged in). */
      allowNames: () => string[];
      /** Told about each thing it fixed (for the safety log). */
      fixed?: (item: RecoveryItem) => void;
    },
  ) {}

  private now = () => (this.d.now ?? Date.now)();

  lastReport(): RecoveryReport | null {
    if (this.last) return this.last;
    if (!this.d.reportFile) return null;
    try {
      const j = JSON.parse(readFileSync(this.d.reportFile, 'utf8')) as RecoveryReport;
      return typeof j.at === 'number' && Array.isArray(j.items) ? j : null;
    } catch {
      return null;
    }
  }

  /** Look and fix, for one approved request. Never throws, never runs twice at once. */
  async check(o: CheckOpts): Promise<RecoveryReport> {
    if (this.running) return this.last ?? { at: this.now(), items: [] };
    this.running = true;
    try {
      if (o.force) this.failures.clear();
      const want = (id: ItemId) => !o.only || o.only.includes(id);
      const items: RecoveryItem[] = [];
      const skipped = (id: ItemId, title: string): RecoveryItem => ({ id, title, status: 'skipped', say: 'Not part of this request.' });
      const keyring = want('keyring') ? await this.safe('keyring', 'Desktop keyring', () => this.keyring(o.proof)) : skipped('keyring', 'Desktop keyring');
      items.push(keyring);
      const gh = want('gh') ? await this.safe('gh', 'GitHub sign-in', () => this.gh(o.proof, o.account)) : skipped('gh', 'GitHub sign-in');
      items.push(gh);
      items.push(want('git') ? await this.safe('git', 'Git logins', () => this.git(gh)) : skipped('git', 'Git logins'));
      items.push(this.sudo());
      for (const it of items) {
        if (it.status === 'fixed') this.d.fixed?.(it);
        if (it.status === 'failed') this.failures.set(it.id, (this.failures.get(it.id) ?? 0) + 1);
        else if (it.status !== 'skipped') this.failures.delete(it.id);
      }
      const report = { at: this.now(), items };
      this.last = report;
      this.save(report);
      return report;
    } finally {
      this.running = false;
    }
  }

  private save(r: RecoveryReport): void {
    if (!this.d.reportFile) return;
    try {
      mkdirSync(dirname(this.d.reportFile), { recursive: true, mode: 0o700 });
      const tmp = `${this.d.reportFile}.tmp-${process.pid}`;
      writeFileSync(tmp, JSON.stringify(r), { mode: 0o600 });
      renameSync(tmp, this.d.reportFile);
    } catch {
      /* the report is a convenience */
    }
  }

  private async safe(id: RecoveryItem['id'], title: string, f: () => Promise<RecoveryItem>): Promise<RecoveryItem> {
    if ((this.failures.get(id) ?? 0) >= MAX_TRIES) return { id, title, status: 'skipped', say: `Tried ${MAX_TRIES} times and it did not work, so Escanor will not try again by itself. Check the saved secret, then ask again (it needs your fingerprint).` };
    try {
      return await f();
    } catch {
      return { id, title, status: 'failed', say: 'Something went wrong while checking this.' };
    }
  }

  // ---- 1. keyring ------------------------------------------------------------------------------------------------------------

  /** true: locked, false: unlocked, null: cannot tell (no desktop keyring). Reads only the "locked" flag. */
  private async keyringLocked(): Promise<boolean | null> {
    const r = await this.d.exec.plain('busctl', ['--user', 'get-property', 'org.freedesktop.secrets', '/org/freedesktop/secrets/collection/login', 'org.freedesktop.Secret.Collection', 'Locked']);
    if (r.code !== 0) return null;
    const m = /\bb\s+(true|false)\b/.exec(r.out);
    return m ? m[1] === 'true' : null;
  }

  private async keyring(proof: UseProof): Promise<RecoveryItem> {
    const base = { id: 'keyring' as const, title: 'Desktop keyring' };
    if ((this.d.platform ?? process.platform) !== 'linux') return { ...base, status: 'skipped', say: NO_KEYRING };
    const locked = await this.keyringLocked();
    if (locked === null) return { ...base, status: 'skipped', say: NO_KEYRING };
    if (!locked) return { ...base, status: 'ok', say: 'The keyring is unlocked.' };
    const names = KEYRING_SECRETS.filter((n) => this.d.broker.allowed(n));
    if (!names.length) return { ...base, status: 'skipped', say: 'The keyring is locked. Allow LAPTOP_KEYRING_PASSWORD (a saved secret) for this computer so Escanor can unlock it when you ask.' };
    for (const name of names) {
      const r = await this.d.broker.use(name, 'unlock the desktop keyring', proof, (secret) => this.d.exec.withStdin('gnome-keyring-daemon', ['--unlock'], secret, { newline: false, timeoutMs: 20_000 }));
      if (!r.ok) {
        if (names.length === 1 || name === names[names.length - 1]) return { ...base, status: 'failed', say: `Could not unlock the keyring: ${r.reason}` };
        continue;
      }
      if ((await this.keyringLocked()) === false) return { ...base, status: 'fixed', say: `The keyring was locked after the restart. Escanor unlocked it with the saved secret ${name}.` };
    }
    return { ...base, status: 'failed', say: 'The keyring is still locked: the saved password may be wrong.' };
  }

  // ---- 2. gh -----------------------------------------------------------------------------------------------------------------

  private async gh(proof: UseProof, only?: string): Promise<RecoveryItem> {
    const base = { id: 'gh' as const, title: 'GitHub sign-in' };
    const first = await this.d.exec.plain('gh', ['auth', 'status']);
    if (first.code === 127) return { ...base, status: 'skipped', say: 'The GitHub command line (gh) is not installed here.' };
    const st = parseGhStatus(first.out);
    if (first.code === 0 && !st.failing.length) return { ...base, status: 'ok', say: `Signed in to GitHub${st.loggedIn.length ? ` as ${st.loggedIn.join(', ')}` : ''}.` };

    let accounts = st.failing;
    if (!accounts.length && st.notLoggedIn) {
      accounts = this.d.allowNames().filter((n) => n.startsWith('GITHUB_TOKEN_') && !n.endsWith('*')).map((n) => n.slice('GITHUB_TOKEN_'.length));
    }
    if (only) accounts = accounts.filter((a) => a.toLowerCase() === only.toLowerCase());
    if (!accounts.length) return { ...base, status: 'skipped', say: 'GitHub is not signed in, and no GITHUB_TOKEN_<account> secret is allowed for this computer.' };

    const fixed: string[] = [];
    const problems: string[] = [];
    for (const account of accounts) {
      const name = ghVaultName(account);
      if (!this.d.broker.allowed(name)) {
        problems.push(`${account}: allow the saved secret ${name}`);
        continue;
      }
      const r = await this.d.broker.use(name, `sign GitHub in again (${account})`, proof, (token) => this.d.exec.withStdin('gh', ['auth', 'login', '--hostname', 'github.com', '--with-token'], token));
      if (r.ok && r.value.code === 0) fixed.push(account);
      else problems.push(`${account}: ${r.ok ? 'GitHub did not accept the saved token' : r.reason}`);
    }
    const after = await this.d.exec.plain('gh', ['auth', 'status']);
    const stillFailing = parseGhStatus(after.out).failing;
    if (fixed.length && after.code === 0 && !stillFailing.length) return { ...base, status: 'fixed', say: `GitHub had stopped accepting the sign-in. Escanor signed ${fixed.join(', ')} in again from the vault.` };
    if (fixed.length) return { ...base, status: 'failed', say: `Signed ${fixed.join(', ')} in again, but not everything: ${problems.join('; ') || 'a login is still invalid'}.` };
    return { ...base, status: problems.every((p) => p.includes('allow the saved secret')) ? 'skipped' : 'failed', say: `GitHub is not signed in. ${problems.join('; ')}.` };
  }

  // ---- 3. git ----------------------------------------------------------------------------------------------------------------

  private async git(gh: RecoveryItem): Promise<RecoveryItem> {
    const base = { id: 'git' as const, title: 'Git logins' };
    const have = async (key: string) => {
      const r = await this.d.exec.plain('git', ['config', '--get-all', key]);
      return r.code === 0 && r.out.trim() !== '';
    };
    if (gh.status === 'skipped' || gh.status === 'failed') return { ...base, status: 'skipped', say: 'Waiting for the GitHub sign-in.' };
    if ((await have('credential.https://github.com.helper')) || (await have('credential.helper'))) return { ...base, status: 'ok', say: 'Git already has a way to get its GitHub login.' };
    const r = await this.d.exec.plain('gh', ['auth', 'setup-git']);
    if (r.code !== 0) return { ...base, status: 'failed', say: 'Git had no way to get its GitHub login and it could not be set up.' };
    return { ...base, status: 'fixed', say: 'Git had no way to get its GitHub login. It now asks the GitHub command line, which holds it safely.' };
  }

  // ---- 4. sudo ---------------------------------------------------------------------------------------------------------------

  private sudo(): RecoveryItem {
    const base = { id: 'sudo' as const, title: 'sudo' };
    if (!this.d.broker.allowed(SUDO_SECRET)) return { ...base, status: 'skipped', say: `sudo is not set up: allow ${SUDO_SECRET} (a saved secret) and list the commands it may run.` };
    return { ...base, status: 'ok', say: 'sudo can run the commands you listed, each time after your fingerprint, and only those.' };
  }
}
