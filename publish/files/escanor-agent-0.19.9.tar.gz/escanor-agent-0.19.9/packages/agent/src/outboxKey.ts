import { randomBytes } from 'node:crypto';
import { appendFileSync, chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const VALID = /^[0-9a-f]{64}$/;

/**
 * I2: the secret this agent signs its outbox lines with (wsClient.ts), so a line written into data/outbox.jsonl by anything
 * else (a chat's shell) is dropped. ESCANOR_OUTBOX_KEY from the environment (the agent's env file, 0600); on the first start one
 * is made and appended to that file, or kept in <data>/outbox.key (0600) when there is no env file. It is removed from this
 * process's environment and never handed to a child (childEnv.ts).
 */
export function outboxKeyFrom(env: NodeJS.ProcessEnv, o: { envFile: string | null; dataDir: string }): string {
  const given = env.ESCANOR_OUTBOX_KEY?.trim();
  delete env.ESCANOR_OUTBOX_KEY;
  if (given && VALID.test(given)) return given;
  const keyFile = join(o.dataDir, 'outbox.key');
  if (!o.envFile && existsSync(keyFile)) {
    const k = readFileSync(keyFile, 'utf8').trim();
    if (VALID.test(k)) return k;
  }
  const key = randomBytes(32).toString('hex');
  if (o.envFile && existsSync(o.envFile)) {
    const text = readFileSync(o.envFile, 'utf8');
    appendFileSync(o.envFile, `${text.endsWith('\n') || text === '' ? '' : '\n'}ESCANOR_OUTBOX_KEY=${key}\n`);
    chmodSync(o.envFile, 0o600);
  } else {
    mkdirSync(o.dataDir, { recursive: true, mode: 0o700 });
    writeFileSync(keyFile, `${key}\n`, { mode: 0o600 });
    chmodSync(keyFile, 0o600);
  }
  return key;
}
