import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import type { Readable, Writable } from 'node:stream';
import type { PermissionMode } from '@remote-harness/shared';
import { AGENT_CHAT_ENV, childEnv } from './childEnv.js';
import { AUTONOMOUS_ENV, COPILOT_FALLBACK_DENY, PERSONAL_ENV, PUSH_SCAN_ENV, RISK_CHECK_ENV, WRITE_REPOS_ENV, guardHookCommand, installCodexGuard, installCopilotGuard, installGeminiGuard, writeGeminiPolicy } from './cliGuard.js';
import { CLI_INFO, COPILOT_MODELS, launchSpec, resolveCliBin, stripAnsi, type CliProvider } from './cliTools.js';

export { COPILOT_MODELS };
import { MIN_NODE, ensureNodeFor, oldNodeCrash, withNewNode } from './nodeRuntime.js';
import { PERSONAL_ROOTS_ENV } from './personalGuard.js';
import { pushScanOn } from './pushScan.js';
import { readAccountKey } from './profiles.js';
import { AsyncMessageQueue } from './queue.js';

/**
 * A chat on a ChatGPT, Gemini or GitHub Copilot account. The session manager drives every chat through the object the Claude Agent SDK's query()
 * returns (an async iterable of messages, plus interrupt / setPermissionMode / setModel / ...); this is that object for the other
 * AIs' own tools, so everything above it (hub, phone, website, desktop) shows their chats exactly like Claude's.
 *
 * One tool process per turn: the first starts the chat (`codex exec` / `gemini -p ... --session-id <id>` / `copilot -p ...
 * --session-id=<id>`), later ones resume it by the chat's id (`codex exec resume <thread>` / `gemini --resume <id>` / `copilot --resume=<id>`). What the tool prints (JSON lines) is turned into
 * SDK-shaped messages: system/init once, assistant text / thinking / tool_use blocks, user tool_result blocks, stream_event text
 * deltas for Gemini's live text, and one `result` per turn (plus a `rate_limit_event` when the account's limit was reached).
 *
 * What the tools cannot do is a no-op here: MCP servers, effort, context usage, permission cards (the tools are told the mode up
 * front instead: bypass = no limits, plan = read-only, anything else = may change files in the working folder only).
 */

export type CliChild = {
  pid?: number;
  stdout: Readable | null;
  stderr: Readable | null;
  stdin: Writable | null;
  kill(signal?: NodeJS.Signals): boolean;
  once(event: 'exit' | 'close', cb: (code: number | null, signal: NodeJS.Signals | null) => void): unknown;
  once(event: 'error', cb: (err: Error) => void): unknown;
};
export type CliSpawn = (bin: string, args: string[], opts: { cwd: string; env: Record<string, string | undefined> }) => CliChild;

/**
 * Never through a shell (a prompt is data, not commands): a Windows .cmd wrapper is run as its JavaScript with this Node
 * (launchSpec). On other systems the tool leads its own process group, so stopping it stops what it started too (killTree).
 */
const realSpawn: CliSpawn = (bin, args, opts) => {
  const l = launchSpec(bin);
  return spawn(l.command, [...l.args, ...args], { cwd: opts.cwd, env: opts.env, stdio: ['pipe', 'pipe', 'pipe'], detached: process.platform !== 'win32', windowsHide: true });
};

/** Stops a tool and everything it started: its process group on POSIX, `taskkill /T /F` on Windows. */
export function killTree(child: CliChild, signal: NodeJS.Signals): void {
  const pid = child.pid;
  if (!pid) {
    child.kill(signal);
    return;
  }
  if (process.platform === 'win32') {
    try {
      spawn('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }).on('error', () => child.kill(signal));
    } catch {
      child.kill(signal);
    }
    return;
  }
  try {
    process.kill(-pid, signal);
  } catch {
    try {
      child.kill(signal);
    } catch {
      // gone
    }
  }
}

/** After the tool exits, how long its output may still take to close (a helper it left running can hold it open). */
const CLOSE_WAIT_MS = 2000;

export type CliQueryOptions = {
  provider: CliProvider;
  cwd: string;
  permissionMode: PermissionMode;
  /** The chat's id when it is continued (its Codex thread / Gemini session id). */
  resume?: string;
  model?: string | null;
  /** The account folder: that AI's own home for this account (CODEX_HOME / GEMINI_CLI_HOME / COPILOT_HOME). */
  configDir?: string;
  /** The agent's environment; the tool gets childEnv() of it (never the hub's credentials) plus the account's own. */
  env?: NodeJS.ProcessEnv;
  /** Injectable for tests. */
  bin?: string;
  spawn?: CliSpawn;
  /** Where a turn's pasted images are written for the tool (removed after the turn). */
  tmpRoot?: string;
  /** How long a stopped tool gets to end by itself before it is killed. */
  killGraceMs?: number;
  /**
   * Does the Autonomous blocklist apply to this turn (cliGuard.ts)? Asked at the start of every turn; absent means yes. The
   * session manager says no only for a chat explicitly set to "Bypass permissions", as for Claude.
   */
  guarded?: () => boolean;
  /** Injectable for tests: the hook command (otherwise guardHookCommand()); null = no hook can run here. */
  guardCommand?: string | null;
  /** The only repositories this chat may change on a remote (writeRepos.ts), checked by the same hook; none: no limit. */
  writeRepos?: () => string[] | undefined;
  /** The safety net (riskHold.ts, ESCANOR_RISK_HOLDS): risky commands are refused by the hook in every mode. Off when absent. */
  riskCheck?: boolean;
  /** Injectable for tests: how a tool and what it started are stopped. */
  killTree?: (child: CliChild, signal: NodeJS.Signals) => void;
};

type UserMsg = { type?: string; message?: { content?: unknown } };
type Out = Record<string, unknown>;

/** Claude's own model names mean nothing to the other tools: those use their own default instead. */
export function isClaudeModel(model: string | null | undefined): boolean {
  if (!model) return true;
  return /claude|anthropic/i.test(model) || /^(opus|sonnet|haiku|fable|default|best|opusplan)(\[.*\])?$/i.test(model.trim());
}


/**
 * The model a chat's tool is started with, or none (its own default). A Claude model name (from a Claude chat's menu) means
 * nothing to Codex or Gemini; Copilot runs Claude models too, but only under its own ids (`claude-sonnet-5.5`), so for Copilot a
 * model counts when it is one of its ids or does not look like a Claude Code name; `auto` is Copilot's default anyway.
 */
export function modelFor(provider: CliProvider, model: string | null | undefined): string | null {
  const m = model?.trim();
  if (!m) return null;
  if (provider === 'copilot') {
    if (m === 'auto') return null;
    if (COPILOT_MODELS.some((x) => x.value === m)) return m;
    // Copilot's own ids are lower-case words with dots (claude-sonnet-5.5, gpt-6-luna); Claude Code's use dashes or aliases.
    if (/^[a-z0-9][a-z0-9.-]{1,63}$/.test(m) && (!isClaudeModel(m) || /^claude-[a-z]+-\d+\.\d+$/.test(m))) return m;
    return null;
  }
  return isClaudeModel(m) ? null : m;
}

/** The usage-limit words the tools use when an account has no room left. */
export function isLimitText(text: string): boolean {
  return /usage limit|rate limit|rate-limit|\b429\b|quota|resource[_ ]exhausted|too many requests|hit your limit|premium requests? (?:limit|allowance)|out of (?:ai )?credits|monthly limit/i.test(text);
}

/** The flags that tell each tool the chat's permission mode. */
export function permissionArgs(provider: CliProvider, mode: PermissionMode, resuming: boolean): string[] {
  if (provider === 'chatgpt') {
    if (mode === 'bypassPermissions') return ['--dangerously-bypass-approvals-and-sandbox'];
    const sandbox = mode === 'plan' ? 'read-only' : 'workspace-write';
    // `codex exec resume` has no -s: the same setting as a config override.
    return resuming ? ['-c', `sandbox_mode="${sandbox}"`] : ['-s', sandbox];
  }
  if (provider === 'copilot') {
    // Copilot run with -p cannot ask: what no rule allows is refused. Plan: nothing allowed (only commands it knows to be
    // read-only run) and no writes; bypass: everything, any path and address; otherwise its tools run, with files limited to
    // the chat's folder (and the temp folder), which is Copilot's own default.
    if (mode === 'bypassPermissions') return ['--allow-all'];
    if (mode === 'plan') return ['--deny-tool=write'];
    return ['--allow-all-tools'];
  }
  if (mode === 'bypassPermissions') return ['--approval-mode', 'yolo'];
  if (mode === 'plan') return ['--approval-mode', 'plan'];
  return ['--approval-mode', 'auto_edit'];
}

/** The tool's arguments for one turn. Codex reads the prompt from stdin ('-'); Gemini takes it in --prompt. */
export function turnArgs(o: {
  provider: CliProvider;
  cwd: string;
  mode: PermissionMode;
  model?: string | null;
  /** The chat to continue (Codex thread / Gemini session); none: a new chat. */
  resume?: string;
  /** Gemini: the id a new chat is started with. */
  newSessionId?: string;
  images: string[];
  prompt: string;
  imageDir?: string;
  /** Codex: run our guard hook (hooks.json), which Codex otherwise skips until a person trusts it. */
  hookTrust?: boolean;
  /** Gemini: the guard's policy file. */
  policyFile?: string;
  /** Copilot: extra --deny-tool rules (where the guard hook cannot run). */
  denyTools?: string[];
}): string[] {
  const model = modelFor(o.provider, o.model) ?? undefined;
  if (o.provider === 'copilot') {
    // The prompt goes on stdin (`-p ""` makes the run headless and Copilot reads the text from stdin); images as attachments.
    return [
      '-p',
      '',
      '--output-format',
      'json',
      '--stream',
      'on',
      '--no-auto-update',
      '--no-ask-user',
      '--secret-env-vars=COPILOT_GITHUB_TOKEN',
      o.resume ? `--resume=${o.resume}` : `--session-id=${o.newSessionId!}`,
      ...permissionArgs('copilot', o.mode, Boolean(o.resume)),
      ...(o.denyTools ?? []).map((t) => `--deny-tool=${t}`),
      ...(model ? ['--model', model] : []),
      ...o.images.flatMap((f) => ['--attachment', f]),
    ];
  }
  if (o.provider === 'chatgpt') {
    const imgs = o.images.flatMap((f) => ['-i', f]);
    const common = [
      ...imgs,
      '--json',
      '--skip-git-repo-check',
      ...permissionArgs('chatgpt', o.mode, Boolean(o.resume)),
      ...(o.hookTrust ? ['--dangerously-bypass-hook-trust'] : []),
      ...(model ? ['-m', model] : []),
    ];
    return o.resume ? ['exec', 'resume', o.resume, ...common, '-'] : ['exec', ...common, '-C', o.cwd, '-'];
  }
  // The prompt itself goes on stdin (geminiPrompt): `-p ""` only makes the run headless, Gemini reads the text from stdin.
  return [
    '-p',
    '',
    '--output-format',
    'stream-json',
    ...(o.resume ? ['--resume', o.resume] : ['--session-id', o.newSessionId!]),
    '--skip-trust',
    ...permissionArgs('gemini', o.mode, Boolean(o.resume)),
    ...(o.policyFile ? ['--policy', o.policyFile] : []),
    ...(model ? ['-m', model] : []),
    ...(o.images.length && o.imageDir ? ['--include-directories', o.imageDir] : []),
  ];
}

/** What Gemini is sent on stdin for a turn: the text, then each pasted image as an @file reference. */
export function geminiPrompt(prompt: string, images: string[]): string {
  return [prompt, ...images.map((f) => `@${f}`)].filter(Boolean).join('\n');
}

/** Where each tool keeps one account's sign-in and state. */
export const CLI_HOME_ENV: Record<CliProvider, string> = { chatgpt: 'CODEX_HOME', gemini: 'GEMINI_CLI_HOME', copilot: 'COPILOT_HOME' };
/** Keys in the agent's own environment that would sign a chat in as someone else (Copilot takes a GitHub token from these). */
export const FOREIGN_KEYS = ['OPENAI_API_KEY', 'CODEX_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY', 'COPILOT_GITHUB_TOKEN', 'GH_TOKEN', 'GITHUB_TOKEN'];

/** The environment of a ChatGPT / Gemini / Copilot chat: the agent's (minus the hub's credentials), the account's home, its key. */
export function cliChatEnv(provider: CliProvider, base: NodeJS.ProcessEnv, configDir: string | undefined): Record<string, string | undefined> {
  const home: Record<string, string> = configDir ? { [CLI_HOME_ENV[provider]]: configDir } : {};
  const env = withNewNode(childEnv(base, { [AGENT_CHAT_ENV]: '1', ...home }), MIN_NODE[provider], configDir ? dirname(configDir) : undefined);
  // Keys from the agent's own environment would sign the chat in as someone else.
  for (const k of FOREIGN_KEYS) delete env[k];
  const key = configDir ? readAccountKey(configDir) : null;
  if (key && provider === 'gemini') env.GEMINI_API_KEY = key;
  if (key && provider === 'copilot') env.COPILOT_GITHUB_TOKEN = key;
  if (provider === 'copilot') {
    // Copilot updates itself in the background unless told not to; Escanor reads the output of the version it installed.
    env.COPILOT_AUTO_UPDATE = 'false';
  }
  return env;
}

const MAX_TOOL_OUTPUT = 20_000;
const cut = (s: string) => (s.length > MAX_TOOL_OUTPUT ? `${s.slice(0, MAX_TOOL_OUTPUT)}\n… [${s.length - MAX_TOOL_OUTPUT} more characters]` : s);

/** `/bin/bash -lc 'npm test'` -> `npm test`: the command as the AI wrote it. */
export function unwrapShell(command: string): string {
  const m = /^(?:\/(?:usr\/)?bin\/)?(?:ba|z)?sh -l?c '([\s\S]*)'$/.exec(command.trim());
  return m ? m[1].replace(/'\\''/g, "'") : command;
}

const GEMINI_TOOLS: Record<string, string> = {
  run_shell_command: 'Bash',
  write_file: 'Write',
  replace: 'Edit',
  read_file: 'Read',
  read_many_files: 'Read',
  glob: 'Glob',
  search_file_content: 'Grep',
  grep_search: 'Grep',
  list_directory: 'LS',
  web_fetch: 'WebFetch',
  google_web_search: 'WebSearch',
  write_todos: 'TodoWrite',
};

/** A Gemini tool call as Claude Code would name it (so the apps draw it the same), with its path under `file_path`. */
export function geminiTool(name: string, params: unknown): { name: string; input: Record<string, unknown> } {
  const input: Record<string, unknown> = params && typeof params === 'object' && !Array.isArray(params) ? { ...(params as Record<string, unknown>) } : {};
  const mapped = GEMINI_TOOLS[name] ?? name;
  if (input.file_path === undefined) {
    for (const k of ['absolute_path', 'path']) {
      if (typeof input[k] === 'string' && (mapped === 'Read' || mapped === 'Write' || mapped === 'Edit')) {
        input.file_path = input[k];
        break;
      }
    }
  }
  if (mapped === 'TodoWrite' && Array.isArray(input.todos)) {
    input.todos = (input.todos as Array<Record<string, unknown>>).map((t) => ({
      content: String(t.description ?? t.content ?? ''),
      status: t.status === 'completed' ? 'completed' : t.status === 'in_progress' ? 'in_progress' : 'pending',
      activeForm: String(t.description ?? t.content ?? ''),
    }));
  }
  return { name: mapped, input };
}

/** One SDKUserMessage as the tool takes it: its text, and its images as files. */
function promptOf(msg: UserMsg): { text: string; images: Array<{ mediaType: string; data: string }> } {
  const content = msg.message?.content;
  if (typeof content === 'string') return { text: content, images: [] };
  const parts: string[] = [];
  const images: Array<{ mediaType: string; data: string }> = [];
  if (Array.isArray(content)) {
    for (const c of content as Array<Record<string, unknown>>) {
      if (c.type === 'text' && typeof c.text === 'string') parts.push(c.text);
      const src = c.source as { type?: string; media_type?: string; data?: string } | undefined;
      if (c.type === 'image' && src?.type === 'base64' && typeof src.data === 'string') images.push({ mediaType: src.media_type ?? 'image/png', data: src.data });
    }
  }
  return { text: parts.join('\n\n'), images };
}

const EXT: Record<string, string> = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/gif': 'gif', 'image/webp': 'webp' };

/** A tool's last words when it failed, in plain words (its own message when it gave one). */
export function failureText(provider: CliProvider, said: string | null, stderr: string, code: number | null): string {
  const name = CLI_INFO[provider].name;
  if (oldNodeCrash(`${said ?? ''}\n${stderr}`)) return `${name} could not start because this computer's Node.js is too old (it needs Node ${MIN_NODE[provider]} or newer). Install a newer Node.js there, then try again.`;
  const raw = (said ?? '').trim() || stripAnsi(stderr).trim().split('\n').filter((l) => l.trim() && !/^\d{4}-\d\d-\d\dT/.test(l)).slice(-3).join(' ');
  if (provider === 'copilot') {
    const all = `${raw}\n${stripAnsi(stderr)}`;
    if (/model\b[^\n]*\bis not available|not available[^\n]*model|unknown model|invalid model/i.test(all)) {
      return `${name} can't use that model on this account's plan. Pick Auto (Copilot picks) or another model, then try again.`;
    }
    if (/no (?:active )?copilot (?:subscription|access|plan)|not (?:have|enabled)[^\n]*copilot|copilot[^\n]*(?:not enabled|disabled|no access)|access to (?:github )?copilot|\b403\b/i.test(all)) {
      return `${name} isn't available on this GitHub account. Turn on Copilot Free (or a paid plan) at github.com/settings/copilot, then try again.`;
    }
    if (/not (?:logged|signed) in|no (?:auth|authentication|token)|login required|please (?:log|sign) in|\/login|copilot login|unauthori[sz]ed|\b401\b|bad credentials|token[^\n]*(?:expired|invalid|revoked)/i.test(all)) {
      return `${name} is not signed in on this account any more. Remove the account and add it again, or sign in on this computer with \`copilot login\`.`;
    }
  }
  if (/throwIneligibleOrProjectIdError|_doSetupUser|GOOGLE_CLOUD_PROJECT/i.test(`${raw}\n${stderr}`)) {
    return `${name} isn't set up for this account (needs a Google Cloud project). Pick another model or set GOOGLE_CLOUD_PROJECT.`;
  }
  if (isLimitText(raw)) return `${name} says this account has reached its usage limit. ${raw}`.trim();
  if (/not logged in|login|sign in|unauthori[sz]ed|401|invalid api key|api key not valid|authenticat/i.test(raw)) {
    return `${name} is not signed in on this account any more. Remove the account and add it again. (${raw.slice(0, 300)})`;
  }
  return raw ? `${name} stopped with an error: ${raw.slice(0, 600)}` : `${name} stopped with an error (exit code ${code ?? 'unknown'}).`;
}

export class CliQuery implements AsyncIterable<Out> {
  private out = new AsyncMessageQueue<Out>();
  private mode: PermissionMode;
  private model: string | null;
  private provider: CliProvider;
  /** The chat's id as the hub knows it ('' until the first turn names it). */
  private sessionId: string;
  /** The tool's own id to resume with (Codex thread / Gemini session); undefined until it exists. */
  private resumeId: string | undefined;
  private initSent = false;
  private child: CliChild | null = null;
  private stopping = false;
  private closed = false;

  constructor(
    private prompt: AsyncIterable<UserMsg>,
    private o: CliQueryOptions,
  ) {
    this.provider = o.provider;
    this.mode = o.permissionMode;
    this.model = modelFor(o.provider, o.model);
    this.resumeId = o.resume;
    // Gemini and Copilot start a new chat under an id given to them; Codex names its own.
    this.sessionId = o.resume ?? (o.provider !== 'chatgpt' ? randomUUID() : '');
    void this.drive();
  }

  [Symbol.asyncIterator](): AsyncIterator<Out> {
    return this.out[Symbol.asyncIterator]();
  }

  async interrupt(): Promise<void> {
    this.stopChild();
  }

  async setPermissionMode(mode: PermissionMode): Promise<void> {
    this.mode = mode;
  }

  async setModel(model?: string): Promise<void> {
    this.model = modelFor(this.provider, model);
  }

  async applyFlagSettings(_settings: unknown): Promise<void> {}

  async setMcpServers(_servers: unknown): Promise<{ added: string[]; removed: string[]; errors: Record<string, string> }> {
    return { added: [], removed: [], errors: {} };
  }

  async mcpServerStatus(): Promise<Array<{ name: string; status: string; error?: string }>> {
    return [];
  }

  async getContextUsage(_o?: unknown): Promise<{ percentage?: number; totalTokens?: number; maxTokens?: number }> {
    return {};
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    this.stopChild();
    this.out.close();
  }

  private stopChild(): void {
    const child = this.child;
    if (!child) return;
    this.stopping = true;
    const kill = this.o.killTree ?? killTree;
    try {
      kill(child, 'SIGINT');
    } catch {
      // gone
    }
    const t = setTimeout(() => {
      try {
        if (this.child === child) kill(child, 'SIGKILL');
      } catch {
        // gone
      }
    }, this.o.killGraceMs ?? 3000);
    t.unref?.();
  }

  private emit(m: Out): void {
    if (this.closed) return;
    this.out.push({ ...m, uuid: randomUUID(), session_id: this.sessionId });
  }

  private sendInit(): void {
    // A chat Codex never named has no id: nothing is made up (its turn ends with the error alone).
    if (this.initSent || !this.sessionId) return;
    this.initSent = true;
    this.emit({
      type: 'system',
      subtype: 'init',
      cwd: this.o.cwd,
      model: this.model ?? CLI_INFO[this.provider].name,
      permissionMode: this.mode,
      tools: [],
      slash_commands: [],
      apiKeySource: 'none',
      output_style: 'default',
      provider: this.provider,
    });
  }

  private async drive(): Promise<void> {
    try {
      for await (const msg of this.prompt) {
        if (this.closed) break;
        await this.runTurn(msg);
      }
    } catch (err) {
      console.error(`[${this.provider}] chat failed:`, err instanceof Error ? err.message : err);
    } finally {
      this.out.close();
    }
  }

  private assistant(content: Out[]): void {
    this.emit({
      type: 'assistant',
      parent_tool_use_id: null,
      message: {
        id: `msg_${randomUUID().replace(/-/g, '').slice(0, 24)}`,
        type: 'message',
        role: 'assistant',
        model: this.model ?? this.provider,
        content,
        stop_reason: null,
        stop_sequence: null,
        usage: { input_tokens: 0, output_tokens: 0 },
      },
    });
  }

  private toolResult(toolUseId: string, content: string, isError: boolean): void {
    this.emit({
      type: 'user',
      parent_tool_use_id: null,
      message: { role: 'user', content: [{ type: 'tool_result', tool_use_id: toolUseId, content: cut(content), is_error: isError }] },
    });
  }

  private result(o: { ok: boolean; interrupted?: boolean; text: string; usage?: { input?: number; output?: number; cached?: number } }): void {
    const ms = Date.now() - this.turnStarted;
    if (!o.ok && !o.interrupted && isLimitText(o.text)) this.emit({ type: 'rate_limit_event', rate_limit_info: { status: 'rejected' } });
    this.emit({
      type: 'result',
      subtype: o.interrupted ? 'error_during_execution' : 'success',
      is_error: !o.ok,
      duration_ms: ms,
      duration_api_ms: ms,
      num_turns: 1,
      result: o.text,
      ...(o.interrupted ? { errors: [o.text] } : {}),
      stop_reason: null,
      total_cost_usd: 0,
      usage: { input_tokens: o.usage?.input ?? 0, output_tokens: o.usage?.output ?? 0, cache_read_input_tokens: o.usage?.cached ?? 0, cache_creation_input_tokens: 0 },
      modelUsage: {},
      permission_denials: [],
    });
  }

  private turnStarted = Date.now();

  private async runTurn(msg: UserMsg): Promise<void> {
    this.turnStarted = Date.now();
    this.stopping = false;
    const { text, images } = promptOf(msg);
    // The session manager's /compact for a long chat: these tools keep their own context, so there is nothing to do.
    if (text.trim() === '/compact' && images.length === 0) {
      this.sendInit();
      this.result({ ok: true, text: '' });
      return;
    }
    const bin = this.o.bin ?? resolveCliBin(this.provider, this.o.env ?? process.env, this.o.configDir ? dirname(this.o.configDir) : undefined);
    if (!bin) {
      this.sendInit();
      const t =
        this.provider === 'copilot'
          ? `${CLI_INFO.copilot.name} isn't set up on this computer. Install it with \`npm install -g @github/copilot\`, then sign in with \`copilot login\`, or remove this account and add it again from the app.`
          : `${CLI_INFO[this.provider].name}'s tool is not installed on this computer any more. Remove this account and add it again.`;
      this.assistant([{ type: 'text', text: t }]);
      this.result({ ok: false, text: t });
      return;
    }
    let imageDir: string | undefined;
    try {
      const files: string[] = [];
      if (images.length) {
        const root = this.o.tmpRoot ?? tmpdir();
        mkdirSync(root, { recursive: true });
        imageDir = mkdtempSync(join(root, 'escanor-img-'));
        images.forEach((img, i) => {
          const f = join(imageDir!, `image-${i + 1}.${EXT[img.mediaType] ?? 'png'}`);
          writeFileSync(f, Buffer.from(img.data, 'base64'), { mode: 0o600 });
          files.push(f);
        });
      }
      const newSessionId = this.provider !== 'chatgpt' && !this.resumeId ? this.sessionId : undefined;
      // A tool that needs a newer Node than this computer's first one: use another, or fetch one, before starting it.
      if (!this.o.spawn) {
        const node = await ensureNodeFor(this.provider, CLI_INFO[this.provider].name, {
          env: this.o.env ?? process.env,
          profilesDir: this.o.configDir ? dirname(this.o.configDir) : undefined,
          say: (line) => {
            this.sendInit();
            this.assistant([{ type: 'text', text: line }]);
          },
        });
        if (!node.ok) {
          this.sendInit();
          this.assistant([{ type: 'text', text: node.error }]);
          this.result({ ok: false, text: node.error });
          return;
        }
      }
      const env = cliChatEnv(this.provider, this.o.env ?? process.env, this.o.configDir);
      const guard = this.applyGuard(env);
      if ('refuse' in guard) {
        this.sendInit();
        this.assistant([{ type: 'text', text: guard.refuse }]);
        this.result({ ok: false, text: guard.refuse });
        return;
      }
      const args = turnArgs({
        provider: this.provider,
        cwd: this.o.cwd,
        mode: guard.mode,
        model: this.model,
        resume: this.resumeId,
        newSessionId,
        images: files,
        prompt: text,
        imageDir,
        hookTrust: guard.hookTrust,
        policyFile: guard.policyFile,
        denyTools: guard.denyTools,
      });
      await this.runProcess(bin, args, env, this.provider === 'gemini' ? geminiPrompt(text, files) : this.provider === 'copilot' && !text.trim() && files.length ? 'Look at the attached image.' : text);
    } catch (err) {
      this.sendInit();
      const t = failureText(this.provider, err instanceof Error ? err.message : String(err), '', -1);
      this.assistant([{ type: 'text', text: t }]);
      this.result({ ok: false, text: t });
    } finally {
      if (imageDir) rmSync(imageDir, { recursive: true, force: true });
    }
  }

  /**
   * The Autonomous blocklist for this turn (cliGuard.ts): the hook marked on in the tool's environment, Codex told to run it,
   * Gemini given its policy file too. Where no hook can run, a Codex turn in bypass runs in its sandbox instead.
   */
  private applyGuard(env: Record<string, string | undefined>): { mode: PermissionMode; hookTrust?: boolean; policyFile?: string; denyTools?: string[] } | { refuse: string } {
    delete env[AUTONOMOUS_ENV];
    delete env[WRITE_REPOS_ENV];
    delete env[RISK_CHECK_ENV];
    delete env[PERSONAL_ENV];
    delete env[PERSONAL_ROOTS_ENV];
    delete env[PUSH_SCAN_ENV];
    const guarded = !this.o.guarded || this.o.guarded();
    const repos = this.o.writeRepos?.();
    // No key leaves in a push, in every mode (pushScan.ts): the hook runs for every turn, as it does for the risky-command check.
    const keyScan = pushScanOn(process.env);
    if (keyScan) env[PUSH_SCAN_ENV] = '1';
    const risk = this.o.riskCheck === true;
    const checked = risk || keyScan;
    // With the safety net on, risky commands are refused in every mode (cliGuard.ts RISK_CHECK_ENV), so the hook runs for every turn.
    if (risk) env[RISK_CHECK_ENV] = '1';
    if (process.env.ESCANOR_MACHINE_KIND?.trim() === 'personal') {
      env[PERSONAL_ENV] = '1';
      env[PERSONAL_ROOTS_ENV] = JSON.stringify([this.o.cwd]);
    }
    const command = this.o.guardCommand !== undefined ? this.o.guardCommand : guardHookCommand();
    const home = this.o.configDir;
    if (!guarded && !repos && !checked) return { mode: this.mode };
    if (!guarded && !repos) {
      // A chat explicitly in "Bypass permissions": only the risky-command and key-in-push checks. Where the hook cannot be set up, never looser than
      // it can be checked: no bypass without it (the tool asks, or runs in its sandbox).
      // (The key-in-a-push check alone does not take the bypass away: it is a second line, not a condition.)
      const unchecked = { mode: risk && this.mode === 'bypassPermissions' ? ('default' as const) : this.mode };
      if (!command || !home) return unchecked;
      try {
        if (this.provider === 'chatgpt') {
          installCodexGuard(home, command);
          return { mode: this.mode, hookTrust: true };
        }
        if (this.provider === 'copilot') {
          installCopilotGuard(home, command);
          return { mode: this.mode };
        }
        installGeminiGuard(home, command);
        return { mode: this.mode };
      } catch (err) {
        console.error(`[${this.provider}] could not set up the risky-command and key checks:`, err instanceof Error ? err.message : err);
        return unchecked;
      }
    }
    if (guarded) env[AUTONOMOUS_ENV] = '1';
    if (repos) env[WRITE_REPOS_ENV] = JSON.stringify(repos);
    // A chat limited to some repositories is only run where the hook that checks that can run.
    const noRepoCheck = `This chat may change only ${repos?.join(', ')}, and ${CLI_INFO[this.provider].name} on this computer cannot be held to that. Run it on a Claude account.`;
    try {
      if (!command || !home) {
        if (repos) return { refuse: noRepoCheck };
        if (this.provider === 'chatgpt') return { mode: this.mode === 'bypassPermissions' ? 'default' : this.mode };
        // Copilot without the hook: no bypass, and its own deny rules for the worst commands as the second line.
        if (this.provider === 'copilot') return { mode: this.mode === 'bypassPermissions' ? 'default' : this.mode, denyTools: [...COPILOT_FALLBACK_DENY] };
        // With the safety net on, the policy file alone does not check risky commands: no bypass then either.
        const mode = risk && this.mode === 'bypassPermissions' ? 'default' : this.mode;
        return { mode, policyFile: writeGeminiPolicy(home ?? mkdtempSync(join(this.o.tmpRoot ?? tmpdir(), 'escanor-gemini-'))) };
      }
      if (this.provider === 'chatgpt') {
        installCodexGuard(home, command);
        return { mode: this.mode, hookTrust: true };
      }
      if (this.provider === 'copilot') {
        installCopilotGuard(home, command);
        // A second line that holds even if the hook cannot run: Copilot's own deny rules for the worst commands.
        return { mode: this.mode, ...(guarded ? { denyTools: [...COPILOT_FALLBACK_DENY] } : {}) };
      }
      installGeminiGuard(home, command);
      return { mode: this.mode, ...(guarded ? { policyFile: writeGeminiPolicy(home) } : {}) };
    } catch (err) {
      console.error(`[${this.provider}] could not set up the Autonomous checks:`, err instanceof Error ? err.message : err);
      if (repos) return { refuse: noRepoCheck };
      // Never looser than it can be checked: no bypass without the checks.
      return { mode: this.mode === 'bypassPermissions' ? 'default' : this.mode, ...(this.provider === 'copilot' ? { denyTools: [...COPILOT_FALLBACK_DENY] } : {}) };
    }
  }

  private runProcess(bin: string, args: string[], env: Record<string, string | undefined>, stdinText: string | undefined): Promise<void> {
    return new Promise((resolve) => {
      let child: CliChild;
      try {
        child = (this.o.spawn ?? realSpawn)(bin, args, { cwd: this.o.cwd, env });
      } catch (err) {
        this.sendInit();
        const t = failureText(this.provider, err instanceof Error ? err.message : String(err), '', -1);
        this.assistant([{ type: 'text', text: t }]);
        this.result({ ok: false, text: t });
        resolve();
        return;
      }
      this.child = child;
      const tr = this.provider === 'chatgpt' ? new CodexTurn(this) : this.provider === 'copilot' ? new CopilotTurn(this) : new GeminiTurn(this);
      let buf = '';
      let stderr = '';
      let finished = false;
      const onLine = (line: string) => {
        const l = line.trim();
        if (!l.startsWith('{')) return;
        let ev: Record<string, unknown>;
        try {
          ev = JSON.parse(l) as Record<string, unknown>;
        } catch {
          return;
        }
        try {
          tr.handle(ev);
        } catch (err) {
          console.error(`[${this.provider}] could not read a line:`, err instanceof Error ? err.message : err);
        }
      };
      child.stdout?.on('data', (b: Buffer | string) => {
        buf += b.toString();
        let i: number;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i);
          buf = buf.slice(i + 1);
          onLine(line);
        }
      });
      child.stderr?.on('data', (b: Buffer | string) => {
        stderr = (stderr + b.toString()).slice(-16_384);
      });
      const done = (code: number | null) => {
        if (finished) return;
        finished = true;
        if (buf) onLine(buf);
        buf = '';
        this.child = null;
        tr.end(code, stderr, this.stopping);
        this.stopping = false;
        resolve();
      };
      // The turn ends once the tool's output has closed (all of it read), not at its exit; a helper it left running that holds
      // the output open does not keep the turn going.
      child.once('close', (code) => done(code));
      child.once('exit', (code) => {
        const t = setTimeout(() => done(code), CLOSE_WAIT_MS);
        t.unref?.();
      });
      child.once('error', (err) => {
        stderr += `\n${err.message}`;
        done(-1);
      });
      try {
        child.stdin?.on('error', () => undefined);
        if (stdinText !== undefined) child.stdin?.write(stdinText);
        child.stdin?.end();
      } catch {
        // it already went
      }
    });
  }

  // ---- used by the per-tool readers below ----

  /** The tool named the chat: the first time, that is the chat's id (and the one later turns resume). */
  named(id: string): void {
    if (!this.resumeId) this.resumeId = id;
    if (!this.sessionId) this.sessionId = id;
    this.sendInit();
  }
  ensureInit(): void {
    this.sendInit();
  }
  textBlock(text: string): void {
    if (text) this.assistant([{ type: 'text', text }]);
  }
  thinkingBlock(text: string): void {
    if (text) this.assistant([{ type: 'thinking', thinking: text, signature: '' }]);
  }
  toolUse(id: string, name: string, input: Record<string, unknown>): void {
    this.assistant([{ type: 'tool_use', id, name, input }]);
  }
  toolDone(id: string, content: string, isError: boolean): void {
    this.toolResult(id, content, isError);
  }
  delta(text: string, first: boolean): void {
    if (first) this.emit({ type: 'stream_event', parent_tool_use_id: null, event: { type: 'message_start' } });
    this.emit({ type: 'stream_event', parent_tool_use_id: null, event: { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } } });
  }
  finishTurn(o: { ok: boolean; interrupted?: boolean; text: string; usage?: { input?: number; output?: number; cached?: number } }): void {
    this.sendInit();
    if (!o.ok && !o.interrupted && o.text) this.textBlock(o.text);
    this.result(o);
  }
  get cliProvider(): CliProvider {
    return this.provider;
  }
  /** The person stopped this turn (the tool was told to stop). */
  get stoppingNow(): boolean {
    return this.stopping;
  }
  /** Gemini / Copilot started the chat under the id it was given: later turns resume it. */
  markSession(): void {
    if (!this.resumeId) this.resumeId = this.sessionId;
  }
  failure(said: string | null, stderr: string, code: number | null): string {
    return failureText(this.provider, said, stderr, code);
  }
}

const STOPPED = 'Stopped.';

/** Reads `codex exec --json` for one turn. */
class CodexTurn {
  private started = new Set<string>();
  private prefix = `cx${randomUUID().slice(0, 8)}_`;
  private lastText = '';
  private error: string | null = null;
  private done = false;
  private todoCount = 0;

  constructor(private q: CliQuery) {}

  private id(item: Record<string, unknown>): string {
    return this.prefix + String(item.id ?? randomUUID());
  }

  handle(ev: Record<string, unknown>): void {
    // Exactly one result a turn: anything printed after it is not part of it.
    if (this.done) return;
    switch (ev.type) {
      case 'thread.started':
        if (typeof ev.thread_id === 'string') this.q.named(ev.thread_id);
        return;
      case 'item.started':
      case 'item.updated':
      case 'item.completed': {
        this.q.ensureInit();
        const item = (ev.item ?? {}) as Record<string, unknown>;
        this.item(item, ev.type === 'item.completed', ev.type === 'item.updated');
        return;
      }
      case 'turn.completed': {
        const u = (ev.usage ?? {}) as Record<string, number>;
        this.done = true;
        this.q.finishTurn({ ok: true, text: this.lastText, usage: { input: u.input_tokens, output: u.output_tokens, cached: u.cached_input_tokens } });
        return;
      }
      case 'turn.failed': {
        const e = ev.error as { message?: string } | undefined;
        this.error = e?.message ?? this.error ?? 'The turn failed.';
        return;
      }
      case 'error':
        if (typeof ev.message === 'string') this.error = ev.message;
        return;
      default:
        return;
    }
  }

  private item(item: Record<string, unknown>, completed: boolean, updated: boolean): void {
    const id = this.id(item);
    const first = !this.started.has(id);
    switch (item.type) {
      case 'agent_message':
        if (completed && typeof item.text === 'string') {
          this.lastText = item.text;
          this.q.textBlock(item.text);
        }
        return;
      case 'reasoning':
        if (completed && typeof item.text === 'string') this.q.thinkingBlock(item.text);
        return;
      case 'todo_list': {
        // Every new version of the list is a new plan for the apps (Claude's TodoWrite).
        if (completed && !first) return;
        this.started.add(id);
        const items = Array.isArray(item.items) ? (item.items as Array<{ text?: string; completed?: boolean }>) : [];
        const todos = items.map((t, i) => {
          const done = t.completed === true;
          const firstOpen = !done && items.slice(0, i).every((x) => x.completed === true);
          return { content: String(t.text ?? ''), status: done ? 'completed' : firstOpen ? 'in_progress' : 'pending', activeForm: String(t.text ?? '') };
        });
        const tid = `${id}_${this.todoCount++}`;
        this.q.toolUse(tid, 'TodoWrite', { todos });
        this.q.toolDone(tid, 'Plan updated', false);
        return;
      }
      case 'command_execution':
      case 'web_search':
      case 'mcp_tool_call':
      case 'file_change': {
        if (updated) return;
        if (first) {
          this.started.add(id);
          for (const [i, t] of this.tools(item).entries()) this.q.toolUse(i === 0 ? id : `${id}_${i}`, t.name, t.input);
        }
        if (completed) {
          const { content, isError } = this.outcome(item);
          const n = Math.max(1, this.tools(item).length);
          for (let i = 0; i < n; i++) this.q.toolDone(i === 0 ? id : `${id}_${i}`, content, isError);
        }
        return;
      }
      case 'error':
        // Codex's own note that our guard hook runs without a person's review (--dangerously-bypass-hook-trust) is not a failure.
        if (completed && typeof item.message === 'string' && !item.message.includes('bypass-hook-trust')) this.error = item.message;
        return;
      default:
        return;
    }
  }

  private tools(item: Record<string, unknown>): Array<{ name: string; input: Record<string, unknown> }> {
    switch (item.type) {
      case 'command_execution':
        return [{ name: 'Bash', input: { command: unwrapShell(String(item.command ?? '')) } }];
      case 'web_search':
        return [{ name: 'WebSearch', input: { query: String(item.query ?? '') } }];
      case 'mcp_tool_call':
        return [{ name: `mcp__${String(item.server ?? 'server')}__${String(item.tool ?? 'tool')}`, input: (item.arguments && typeof item.arguments === 'object' ? item.arguments : {}) as Record<string, unknown> }];
      case 'file_change': {
        const changes = Array.isArray(item.changes) ? (item.changes as Array<{ path?: string; kind?: string }>) : [];
        if (!changes.length) return [{ name: 'Edit', input: { file_path: '' } }];
        return changes.map((c) => ({ name: c.kind === 'add' ? 'Write' : 'Edit', input: { file_path: String(c.path ?? '') } }));
      }
      default:
        return [];
    }
  }

  private outcome(item: Record<string, unknown>): { content: string; isError: boolean } {
    const failed = item.status === 'failed' || item.status === 'declined';
    switch (item.type) {
      case 'command_execution': {
        const code = typeof item.exit_code === 'number' ? item.exit_code : null;
        const outText = String(item.aggregated_output ?? '');
        return { content: outText || (code === 0 ? '(no output)' : `Exit code ${code ?? 'unknown'}`), isError: failed || (code !== null && code !== 0) };
      }
      case 'mcp_tool_call': {
        const err = item.error as { message?: string } | null | undefined;
        if (err?.message) return { content: err.message, isError: true };
        const res = item.result as { content?: Array<{ type?: string; text?: string }> } | null | undefined;
        const text = (res?.content ?? []).map((c) => (c.type === 'text' ? (c.text ?? '') : `[${c.type ?? 'content'}]`)).join('\n');
        return { content: text || JSON.stringify(res ?? {}), isError: failed };
      }
      case 'file_change':
        return { content: failed ? 'The change was not made.' : 'Done', isError: failed };
      default:
        return { content: failed ? 'Failed' : 'Done', isError: failed };
    }
  }

  end(code: number | null, stderr: string, stopped: boolean): void {
    if (this.done) return;
    this.done = true;
    if (stopped) return this.q.finishTurn({ ok: false, interrupted: true, text: STOPPED });
    if (code === 0 && !this.error) return this.q.finishTurn({ ok: true, text: this.lastText });
    this.q.finishTurn({ ok: false, text: this.q.failure(this.error, stderr, code) });
  }
}

/** Reads `gemini --output-format stream-json` for one turn. */
class GeminiTurn {
  private text = '';
  private inText = false;
  private lastText = '';
  private error: string | null = null;
  private done = false;
  private prefix = `gm${randomUUID().slice(0, 8)}_`;

  constructor(private q: CliQuery) {}

  /** The text streamed so far becomes a real message (before a tool call, and at the end). */
  private flush(): void {
    if (this.text) {
      this.q.textBlock(this.text);
      this.lastText = this.text;
    }
    this.text = '';
    this.inText = false;
  }

  handle(ev: Record<string, unknown>): void {
    if (this.done) return;
    switch (ev.type) {
      case 'init':
        this.q.markSession();
        if (typeof ev.session_id === 'string') this.q.named(ev.session_id);
        else this.q.ensureInit();
        return;
      case 'message': {
        if (ev.role !== 'assistant' || typeof ev.content !== 'string') return;
        this.q.ensureInit();
        if (ev.delta === true) {
          this.q.delta(ev.content, !this.inText);
          this.inText = true;
          this.text += ev.content;
        } else {
          this.flush();
          this.q.textBlock(ev.content);
          this.lastText = ev.content;
        }
        return;
      }
      case 'tool_use': {
        this.flush();
        const t = geminiTool(String(ev.tool_name ?? 'tool'), ev.parameters);
        this.q.toolUse(this.prefix + String(ev.tool_id ?? randomUUID()), t.name, t.input);
        return;
      }
      case 'tool_result': {
        const err = ev.error as { message?: string } | undefined;
        const isError = ev.status === 'error';
        const content = isError ? (err?.message ?? String(ev.output ?? 'Tool error')) : String(ev.output ?? '') || 'Done';
        this.q.toolDone(this.prefix + String(ev.tool_id ?? ''), content, isError);
        return;
      }
      case 'error':
        if (ev.severity !== 'warning' && typeof ev.message === 'string') this.error = ev.message;
        return;
      case 'result': {
        this.flush();
        this.done = true;
        const stats = (ev.stats ?? {}) as Record<string, number>;
        const usage = { input: stats.input_tokens ?? stats.input, output: stats.output_tokens, cached: stats.cached };
        if (ev.status === 'success') this.q.finishTurn({ ok: true, text: this.lastText, usage });
        else {
          const e = ev.error as { message?: string } | undefined;
          this.q.finishTurn({ ok: false, text: this.q.failure(e?.message ?? this.error, '', null), usage });
        }
        return;
      }
      default:
        return;
    }
  }

  end(code: number | null, stderr: string, stopped: boolean): void {
    if (this.done) return;
    this.flush();
    this.done = true;
    if (stopped) return this.q.finishTurn({ ok: false, interrupted: true, text: STOPPED });
    if (code === 0 && !this.error) return this.q.finishTurn({ ok: true, text: this.lastText });
    this.q.finishTurn({ ok: false, text: this.q.failure(this.error, stderr, code) });
  }
}

/** Copilot's own bookkeeping tools (its session database, its "what I'm doing" note): not work the person needs to see. */
const COPILOT_QUIET_TOOLS = new Set(['report_intent', 'sql']);

const COPILOT_TOOLS: Record<string, string> = {
  bash: 'Bash',
  powershell: 'Bash',
  write_bash: 'Bash',
  write_powershell: 'Bash',
  read_bash: 'BashOutput',
  read_powershell: 'BashOutput',
  stop_bash: 'KillShell',
  stop_powershell: 'KillShell',
  view: 'Read',
  create: 'Write',
  edit: 'Edit',
  str_replace: 'Edit',
  str_replace_editor: 'Edit',
  glob: 'Glob',
  grep: 'Grep',
  rg: 'Grep',
  web_fetch: 'WebFetch',
  fetch: 'WebFetch',
  web_search: 'WebSearch',
  task: 'Task',
  update_todo: 'TodoWrite',
};

/** The files a patch touches, with how ("*** Add File: path" -> Write, Update / Delete -> Edit). */
export function patchFiles(patch: string): Array<{ path: string; kind: 'add' | 'update' | 'delete' }> {
  return [...patch.matchAll(/^\*\*\* (Add|Update|Delete) File: (.+)$/gm)].map((m) => ({ path: m[2].trim(), kind: m[1].toLowerCase() as 'add' | 'update' | 'delete' }));
}

/** A Copilot tool call as Claude Code would name it (so the apps draw it the same): one entry, or one per file of a patch. */
export function copilotTools(name: string, args: unknown): Array<{ name: string; input: Record<string, unknown> }> {
  if (name === 'apply_patch') {
    const patch = typeof args === 'string' ? args : String((args as Record<string, unknown> | null)?.input ?? (args as Record<string, unknown> | null)?.patch ?? '');
    const files = patchFiles(patch);
    if (!files.length) return [{ name: 'Edit', input: { file_path: '' } }];
    return files.map((f) => ({ name: f.kind === 'add' ? 'Write' : 'Edit', input: { file_path: f.path } }));
  }
  const input: Record<string, unknown> = args && typeof args === 'object' && !Array.isArray(args) ? { ...(args as Record<string, unknown>) } : {};
  const mapped = COPILOT_TOOLS[name] ?? name;
  if ((name === 'write_bash' || name === 'write_powershell') && input.command === undefined) input.command = String(input.input ?? '');
  if (input.file_path === undefined && typeof input.path === 'string' && (mapped === 'Read' || mapped === 'Write' || mapped === 'Edit')) input.file_path = input.path;
  if (mapped === 'Write' && input.content === undefined && typeof input.file_text === 'string') input.content = input.file_text;
  if (mapped === 'Edit') {
    if (input.old_string === undefined && typeof input.old_str === 'string') input.old_string = input.old_str;
    if (input.new_string === undefined && typeof input.new_str === 'string') input.new_string = input.new_str;
  }
  if ((mapped === 'Glob' || mapped === 'Grep') && input.path === undefined && typeof input.paths === 'string') input.path = input.paths;
  return [{ name: mapped, input }];
}

/** Copilot's note on a finished shell command ("<shellId: 0 completed with exit code 0>") is not the command's output. */
export function cleanShellOutput(text: string): string {
  return text.replace(/\n?<shellId: [^>]*>\s*$/, '');
}

/** Reads `copilot -p ... --output-format json` (one JSON object a line) for one turn. */
class CopilotTurn {
  private text = '';
  private inText = false;
  private lastText = '';
  private error: string | null = null;
  private done = false;
  private prefix = `cp${randomUUID().slice(0, 8)}_`;
  /** Tool calls shown, by Copilot's id: how many entries each became (a patch can touch several files). */
  private shown = new Map<string, number>();

  constructor(private q: CliQuery) {}

  private flush(): void {
    if (this.text) {
      this.q.textBlock(this.text);
      this.lastText = this.text;
    }
    this.text = '';
    this.inText = false;
  }

  private id(callId: string, i: number): string {
    return i === 0 ? this.prefix + callId : `${this.prefix}${callId}_${i}`;
  }

  handle(ev: Record<string, unknown>): void {
    if (this.done) return;
    const d = (ev.data && typeof ev.data === 'object' ? ev.data : {}) as Record<string, unknown>;
    switch (ev.type) {
      case 'session.start':
        this.q.markSession();
        if (typeof d.sessionId === 'string' && d.sessionId) this.q.named(d.sessionId);
        else this.q.ensureInit();
        return;
      case 'session.resume':
        this.q.ensureInit();
        return;
      case 'assistant.message_delta': {
        if (typeof d.deltaContent !== 'string' || !d.deltaContent) return;
        this.q.ensureInit();
        this.q.delta(d.deltaContent, !this.inText);
        this.inText = true;
        this.text += d.deltaContent;
        return;
      }
      case 'assistant.reasoning':
        if (typeof d.content === 'string' && d.content.trim()) this.q.thinkingBlock(d.content);
        return;
      case 'assistant.message': {
        this.q.ensureInit();
        const content = typeof d.content === 'string' ? d.content : '';
        // The whole message replaces what streamed of it.
        this.text = '';
        this.inText = false;
        if (content.trim()) {
          this.q.textBlock(content);
          this.lastText = content;
        }
        return;
      }
      case 'tool.execution_start': {
        this.flush();
        const name = String(d.toolName ?? 'tool');
        if (COPILOT_QUIET_TOOLS.has(name)) return;
        const callId = String(d.toolCallId ?? randomUUID());
        const tools = copilotTools(name, d.arguments);
        this.shown.set(callId, tools.length);
        tools.forEach((t, i) => this.q.toolUse(this.id(callId, i), t.name, t.input));
        return;
      }
      case 'tool.execution_complete': {
        const callId = String(d.toolCallId ?? '');
        const n = this.shown.get(callId);
        if (n === undefined) return;
        this.shown.delete(callId);
        const res = (d.result && typeof d.result === 'object' ? d.result : {}) as Record<string, unknown>;
        const err = (d.error && typeof d.error === 'object' ? d.error : {}) as Record<string, unknown>;
        const shell = (d.shellExecution && typeof d.shellExecution === 'object' ? d.shellExecution : {}) as Record<string, unknown>;
        const exit = typeof shell.exitCode === 'number' ? shell.exitCode : null;
        const failed = d.success === false || (exit !== null && exit !== 0);
        let content = d.success === false ? String(err.message ?? res.content ?? 'Tool error') : cleanShellOutput(String(res.content ?? ''));
        if (!content.trim()) content = exit !== null && exit !== 0 ? `Exit code ${exit}` : 'Done';
        for (let i = 0; i < n; i++) this.q.toolDone(this.id(callId, i), content, failed);
        return;
      }
      case 'session.error':
        if (typeof d.message === 'string') this.error = d.message.replace(/^Execution failed:\s*/, '');
        return;
      case 'result': {
        this.flush();
        this.done = true;
        const code = typeof ev.exitCode === 'number' ? ev.exitCode : null;
        if (this.q.stoppingNow) this.q.finishTurn({ ok: false, interrupted: true, text: STOPPED });
        else if (code === 0 && !this.error) this.q.finishTurn({ ok: true, text: this.lastText });
        else this.q.finishTurn({ ok: false, text: this.q.failure(this.error, '', code) });
        return;
      }
      default:
        return;
    }
  }

  end(code: number | null, stderr: string, stopped: boolean): void {
    if (this.done) return;
    this.flush();
    this.done = true;
    if (stopped) return this.q.finishTurn({ ok: false, interrupted: true, text: STOPPED });
    if (code === 0 && !this.error) return this.q.finishTurn({ ok: true, text: this.lastText });
    this.q.finishTurn({ ok: false, text: this.q.failure(this.error, stderr, code) });
  }
}

/** The same call shape as the SDK's query(): `cliQuery({ prompt, options })`. */
export function cliQuery(args: { prompt: AsyncIterable<UserMsg>; options: CliQueryOptions }): CliQuery {
  return new CliQuery(args.prompt, args.options);
}
