import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

/**
 * No-gap upgrades (AGENT-INDEP D, 16 Nov 2026). A new agent version starts alongside the one that is running and takes over the hub
 * connection; the old one stops by itself. Only one agent answers at a time, and no command runs twice.
 *
 * How, in order (both processes share this computer's data folder, so one small file, `agent-lease.json`, is the lease):
 *  1. The new process asks `waitForTurn()` before it starts anything. With no live holder it simply takes the lease and goes on.
 *     Otherwise it does nothing but wait: the running agent keeps serving, so nothing goes offline and nothing runs twice.
 *  2. When the holder reports itself idle (nothing running and nothing waiting) for a few seconds, the new one writes `handoverTo`
 *     into the lease and starts up. A holder that never gets idle is not waited for forever (MAX_WAIT): then it is replaced as a
 *     restart would, and what it was doing is picked up again by the new one (resume).
 *  3. The holder sees `handoverTo` and drains: it ignores new messages from the apps (it does not confirm them, so the hub keeps them
 *     and sends them to the new agent when it connects, the same way it does after any reconnect). It keeps its hub link until it is
 *     replaced, so the computer never shows as offline.
 *  4. The new agent connects. The hub closes the old connection ("replaced") at that moment. The new agent then `claim()`s the lease.
 *  5. The old process sees it was replaced and that its lease went to a live newer process: it stops everything and exits. It does not
 *     reconnect, so the two never take the hub from each other.
 * If the new agent dies before it connects, the holder takes its drain back (the new agent's process is gone, or it took too long).
 */

export interface Lease {
  pid: number;
  startedAt: number;
  version: string;
  busy: boolean;
  beat: number;
  /** A newer process asked to take over (its pid) and when. */
  handoverTo?: number;
  handoverAt?: number;
}

export const BEAT_MS = 3_000;
export const STALE_MS = 20_000;
export const IDLE_FOR_MS = 5_000;
export const MAX_WAIT_MS = 20 * 60_000;
export const HANDOVER_TIMEOUT_MS = 2 * 60_000;

export type Turn = 'free' | 'handover' | 'forced';

export interface HandoverDeps {
  file: string;
  version: string;
  pid?: number;
  now?: () => number;
  alive?: (pid: number) => boolean;
  sleep?: (ms: number) => Promise<void>;
  log?: (line: string) => void;
}

function pidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'EPERM';
  }
}

function clean(raw: unknown): Lease | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  if (typeof r.pid !== 'number' || typeof r.beat !== 'number') return null;
  return {
    pid: r.pid,
    startedAt: typeof r.startedAt === 'number' ? r.startedAt : 0,
    version: typeof r.version === 'string' ? r.version : '',
    busy: r.busy === true,
    beat: r.beat,
    ...(typeof r.handoverTo === 'number' ? { handoverTo: r.handoverTo, handoverAt: typeof r.handoverAt === 'number' ? r.handoverAt : r.beat } : {}),
  };
}

export class Handover {
  private pid: number;
  private now: () => number;
  private alive: (pid: number) => boolean;
  private sleep: (ms: number) => Promise<void>;
  private startedAt: number;
  private timer: ReturnType<typeof setInterval> | null = null;
  private busy: () => boolean = () => false;
  private serving = false;
  private _draining = false;
  private _superseded = false;
  onSuperseded?: () => void;

  constructor(private d: HandoverDeps) {
    this.pid = d.pid ?? process.pid;
    this.now = d.now ?? Date.now;
    this.alive = d.alive ?? pidAlive;
    this.sleep = d.sleep ?? ((ms) => new Promise((r) => setTimeout(r, ms)));
    this.startedAt = this.now();
  }

  read(): Lease | null {
    try {
      return clean(JSON.parse(readFileSync(this.d.file, 'utf8')));
    } catch {
      return null;
    }
  }

  private write(l: Lease): void {
    mkdirSync(dirname(this.d.file), { recursive: true, mode: 0o700 });
    const tmp = `${this.d.file}.${this.pid}.tmp`;
    writeFileSync(tmp, JSON.stringify(l), { mode: 0o600 });
    renameSync(tmp, this.d.file);
  }

  private mine(extra: Partial<Lease> = {}): Lease {
    return { pid: this.pid, startedAt: this.startedAt, version: this.d.version, busy: this.busy(), beat: this.now(), ...extra };
  }

  /** Another process holds the lease, is alive and has beaten lately. */
  private holder(): Lease | null {
    const l = this.read();
    if (!l || l.pid === this.pid || !this.alive(l.pid) || this.now() - l.beat > STALE_MS) return null;
    return l;
  }

  /**
   * Called before this process starts anything. Resolves when it may start: 'free' (nobody else serves: the lease is taken now),
   * 'handover' (the holder is idle and drains; this process starts up and claims the lease once its hub link is up) or 'forced'
   * (the holder stayed busy for MAX_WAIT: it is replaced as a restart would).
   */
  async waitForTurn(o: { maxWaitMs?: number; idleForMs?: number; pollMs?: number } = {}): Promise<Turn> {
    const maxWait = o.maxWaitMs ?? MAX_WAIT_MS;
    const idleFor = o.idleForMs ?? IDLE_FOR_MS;
    const poll = o.pollMs ?? 1_000;
    const began = this.now();
    let idleSince: number | null = null;
    let announced = false;
    for (;;) {
      const h = this.holder();
      if (!h) {
        this.write(this.mine());
        this.serving = true;
        return 'free';
      }
      if (!announced) {
        this.d.log?.(`Another agent (pid ${h.pid}, ${h.version || 'unknown version'}) is serving this computer. This one (${this.d.version}) waits until it is idle, then takes over.`);
        announced = true;
      }
      if (h.busy) idleSince = null;
      else idleSince ??= this.now();
      const idle = idleSince !== null && this.now() - idleSince >= idleFor;
      const waited = this.now() - began >= maxWait;
      if (idle || waited) {
        this.write({ ...h, handoverTo: this.pid, handoverAt: this.now() });
        return idle ? 'handover' : 'forced';
      }
      await this.sleep(poll);
    }
  }

  /** The new agent's hub link is up (it replaced the old connection): take the lease and start beating. */
  claim(busy: () => boolean): void {
    this.busy = busy;
    this.serving = true;
    this.write(this.mine());
    this.startBeat();
  }

  /** A process that took the lease at waitForTurn (nobody else serving): keeps it fresh. */
  start(busy: () => boolean): void {
    this.busy = busy;
    if (this.serving) this.startBeat();
  }

  private startBeat(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.beat(), BEAT_MS);
    this.timer.unref?.();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    const l = this.read();
    if (l && l.pid === this.pid && !l.handoverTo) {
      // Leaving by itself, with nobody taking over: the lease is marked stale at once so the next agent does not wait for it.
      try {
        this.write({ ...l, beat: 0, busy: false });
      } catch {
        // the data folder is gone: nothing to leave
      }
    }
  }

  /** One heartbeat: keep the lease fresh, notice a handover request, and notice this process was superseded. */
  beat(): void {
    if (!this.serving) return;
    const l = this.read();
    if (l && l.pid !== this.pid) {
      // A newer agent claimed the lease: this one is done once the hub has replaced it.
      if (this.alive(l.pid) && !this._superseded) {
        this._superseded = true;
        this._draining = true;
        this.onSuperseded?.();
      }
      return;
    }
    if (l?.handoverTo !== undefined) {
      const gone = !this.alive(l.handoverTo);
      const slow = this.now() - (l.handoverAt ?? l.beat) > HANDOVER_TIMEOUT_MS;
      if (gone || slow) {
        // The newer agent never came up: this one keeps serving.
        this._draining = false;
        this.d.log?.('The agent that asked to take over did not come up; carrying on.');
        this.write(this.mine());
        return;
      }
      this._draining = true;
      this.write(this.mine({ handoverTo: l.handoverTo, handoverAt: l.handoverAt }));
      return;
    }
    this.write(this.mine());
  }

  /** A newer agent asked to take over: do not take new work from the apps (the hub keeps it for the new agent). */
  get draining(): boolean {
    return this._draining;
  }

  get superseded(): boolean {
    return this._superseded;
  }

  /** The hub replaced this connection. True when it went to a live newer agent of this computer: this process should stop, not reconnect. */
  replacedByNewer(): boolean {
    const l = this.read();
    if (!l) return false;
    if (l.pid !== this.pid && this.alive(l.pid)) return true;
    return l.pid === this.pid && l.handoverTo !== undefined && this.alive(l.handoverTo);
  }
}
