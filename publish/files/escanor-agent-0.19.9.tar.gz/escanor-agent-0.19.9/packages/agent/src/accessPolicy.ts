import { readFileSync } from 'node:fs';

/**
 * The one place the owner's access policy plugs into remote viewing: who may look at this computer's screen, when, for how long, and how
 * strong the proof must be. The rest of the agent only asks this hook and does what it answers; it never decides these things itself.
 *
 *  - The default is the rule that shipped with live view: a fingerprint yes from a paired phone for 10 minutes, renewed by itself while
 *    the viewer is in use, up to an hour, then a new fingerprint.
 *  - `access-policy.json` in the agent's data folder (written by the owner at the computer, never by the phone) changes it. It is read
 *    on every request, so an edit applies at once. A broken file means the default, never "allow everything".
 *  - The access-policy service the other agent builds plugs in by handing `Jarvis` its own object with this shape (or by writing the file).
 *
 * File shape (every field optional):
 *   { "view": { "allow": true, "stepUp": "fingerprint", "minutes": 10, "maxMinutes": 60, "autoRenew": true, "viewOnly": false,
 *               "clipboard": true, "allowLocked": true, "hours": { "from": "07:00", "to": "23:00" } } }
 */

export type ViewRequest = {
  /** The computer's id (the id fingerprint answers are signed for). */
  machine: string;
  /** Milliseconds since 1970. */
  now: number;
};

export type ViewDecision =
  | { allow: false; reason: string }
  | {
      allow: true;
      /** `fingerprint`: the paired phone must say yes first. `none`: Remote control being on is enough (only when the owner's file says so). */
      stepUp: 'fingerprint' | 'none';
      /** How long one yes lasts. */
      minutes: number;
      /** The longest one view may last in total, however often it is renewed. */
      maxMinutes: number;
      /** Renew by itself while the viewer is in use (up to maxMinutes). */
      autoRenew: boolean;
      /** Look but do not touch: no mouse, keyboard or clipboard. */
      viewOnly: boolean;
      /** Copy and paste between the viewer and this computer. */
      clipboard: boolean;
      /** May a view unlock a locked screen of this person's own session? (Jarvis checks the lock itself when this is false.) */
      allowLocked: boolean;
    };

export interface AccessPolicy {
  forView(r: ViewRequest): ViewDecision;
}

export const DEFAULT_VIEW_MINUTES = 10;
export const DEFAULT_MAX_VIEW_MINUTES = 60;

export const DEFAULT_VIEW_DECISION: Extract<ViewDecision, { allow: true }> = {
  allow: true,
  stepUp: 'fingerprint',
  minutes: DEFAULT_VIEW_MINUTES,
  maxMinutes: DEFAULT_MAX_VIEW_MINUTES,
  autoRenew: true,
  viewOnly: false,
  clipboard: true,
  allowLocked: true,
};

export class DefaultPolicy implements AccessPolicy {
  forView(): ViewDecision {
    return { ...DEFAULT_VIEW_DECISION };
  }
}

const minutesOf = (v: unknown, dflt: number, max: number): number => (typeof v === 'number' && Number.isFinite(v) && v >= 1 ? Math.min(Math.floor(v), max) : dflt);
const clock = /^([01]\d|2[0-3]):([0-5]\d)$/;

/** Minutes after midnight (local time) of "HH:MM", or null. */
const hm = (v: unknown): number | null => {
  const m = typeof v === 'string' ? clock.exec(v) : null;
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
};

/** The owner's file, read at every request. */
export class FilePolicy implements AccessPolicy {
  constructor(private file: string, private fallback: AccessPolicy = new DefaultPolicy()) {}

  forView(r: ViewRequest): ViewDecision {
    const base = this.fallback.forView(r);
    let raw: Record<string, unknown> | null = null;
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as { view?: unknown };
      raw = j.view && typeof j.view === 'object' && !Array.isArray(j.view) ? (j.view as Record<string, unknown>) : null;
    } catch {
      raw = null; // no file or a broken one: the default rule, never a looser one
    }
    if (!raw || !base.allow) return base;
    if (raw.allow === false) return { allow: false, reason: 'Your access policy does not allow viewing this computer.' };
    const hours = raw.hours && typeof raw.hours === 'object' ? (raw.hours as Record<string, unknown>) : null;
    if (hours) {
      const from = hm(hours.from);
      const to = hm(hours.to);
      if (from !== null && to !== null) {
        const d = new Date(r.now);
        const at = d.getHours() * 60 + d.getMinutes();
        const inside = from <= to ? at >= from && at < to : at >= from || at < to;
        if (!inside) return { allow: false, reason: `Your access policy allows viewing this computer between ${String(hours.from)} and ${String(hours.to)}.` };
      }
    }
    const maxMinutes = minutesOf(raw.maxMinutes, base.maxMinutes, 240);
    return {
      allow: true,
      stepUp: raw.stepUp === 'none' ? 'none' : 'fingerprint',
      minutes: Math.min(minutesOf(raw.minutes, base.minutes, 240), maxMinutes),
      maxMinutes,
      autoRenew: typeof raw.autoRenew === 'boolean' ? raw.autoRenew : base.autoRenew,
      viewOnly: raw.viewOnly === true,
      clipboard: typeof raw.clipboard === 'boolean' ? raw.clipboard : base.clipboard,
      allowLocked: raw.allowLocked !== false,
    };
  }
}
