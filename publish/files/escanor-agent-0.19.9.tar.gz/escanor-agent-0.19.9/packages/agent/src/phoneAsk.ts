import { createServer, connect, type Server } from 'node:net';
import { chmodSync, existsSync, unlinkSync } from 'node:fs';

/**
 * "Ring my phone", "what is my phone battery", "send this link to my phone" from a chat on this computer. The chat's escanor_computer
 * tool `phone` asks this agent over an owner-only socket in its data folder (the same pattern as screen help); the agent passes one
 * `phone_command` through the hub to the owner's phone and waits for the one `phone_result`. The hub token stays here, and the hub
 * checks the action against a fixed list (ring, stop_ring, battery, status, torch, media, receive_link, open_link, open_app): never calls,
 * notifications, messages or typing. The phone answers only if its owner switched on "Let my other devices ask this phone".
 */

export const PHONE_SOCKET_NAME = 'phone-ask.sock';
export const PHONE_ACTIONS = ['ring', 'stop_ring', 'battery', 'status', 'torch', 'media', 'receive_link', 'open_link', 'open_app'] as const;
export type PhoneAction = (typeof PHONE_ACTIONS)[number];
export type PhoneAsk = { action: PhoneAction; args: Record<string, unknown> };
export type PhoneReply = { ok: boolean; say: string; data?: Record<string, unknown> };

const MAX_LINE = 4096;
const MEDIA = new Set(['play', 'pause', 'play_pause', 'next', 'previous', 'stop']);

/** What a tool call asks, checked: null with the reason in plain words when it is not a thing a phone can be asked. */
export function parsePhoneAsk(raw: unknown): { ok: true; ask: PhoneAsk } | { ok: false; error: string } {
  const o = (raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}) as Record<string, unknown>;
  const action = o.action;
  if (typeof action !== 'string' || !(PHONE_ACTIONS as readonly string[]).includes(action)) {
    return { ok: false, error: `The phone can be asked to: ${PHONE_ACTIONS.join(', ')}. Not calls, apps, messages or notifications.` };
  }
  const args: Record<string, unknown> = {};
  if (action === 'ring' && o.seconds !== undefined) {
    if (typeof o.seconds !== 'number' || !Number.isFinite(o.seconds)) return { ok: false, error: 'seconds must be a number (5 to 60).' };
    args.seconds = Math.min(60, Math.max(5, Math.round(o.seconds)));
  }
  if (action === 'torch') {
    if (typeof o.on !== 'boolean') return { ok: false, error: 'Say whether the flashlight should be on (true) or off (false).' };
    args.on = o.on;
  }
  if (action === 'media') {
    if (typeof o.op !== 'string' || !MEDIA.has(o.op)) return { ok: false, error: `op must be one of ${[...MEDIA].join(', ')}.` };
    args.op = o.op;
  }
  if (action === 'open_app') {
    const name = typeof o.app === 'string' ? o.app.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim() : '';
    if (!name || name.length > 60 || /[/\\:;|&$`<>]/.test(name)) return { ok: false, error: 'Say which app to open, by its name (for example YouTube).' };
    args.app = name;
  }
  if (action === 'receive_link' || action === 'open_link') {
    if (typeof o.url !== 'string' || o.url.length > 2000 || !/^https?:\/\/[^\s]+$/i.test(o.url)) return { ok: false, error: 'url must be a web link starting with http:// or https://.' };
    args.url = o.url;
  }
  return { ok: true, ask: { action: action as PhoneAction, args } };
}

/** The chat's side: one line out, one line back. Never throws. */
export function askPhoneAgent(sockPath: string, ask: PhoneAsk, timeoutMs = 20_000): Promise<PhoneReply> {
  const fail = (say: string): PhoneReply => ({ ok: false, say });
  if (!sockPath) return Promise.resolve(fail('This computer is not set up to ask your phone yet.'));
  return new Promise((resolve) => {
    let done = false;
    let buf = '';
    const finish = (r: PhoneReply) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      c.destroy();
      resolve(r);
    };
    const c = connect(sockPath);
    const timer = setTimeout(() => finish(fail('Your phone did not answer in time.')), timeoutMs);
    c.setEncoding('utf8');
    c.on('connect', () => c.write(`${JSON.stringify(ask)}\n`));
    c.on('data', (d: string) => {
      buf += d;
      if (buf.length > MAX_LINE * 4) return finish(fail('The answer was too long.'));
      const nl = buf.indexOf('\n');
      if (nl < 0) return;
      try {
        const j = JSON.parse(buf.slice(0, nl)) as PhoneReply;
        finish({ ok: j.ok === true, say: typeof j.say === 'string' ? j.say.slice(0, 500) : '', ...(j.data && typeof j.data === 'object' ? { data: j.data } : {}) });
      } catch {
        finish(fail('The answer could not be read.'));
      }
    });
    c.on('error', () => finish(fail('This computer is not connected to Escanor right now, so it cannot reach your phone.')));
  });
}

/** The agent's side: listens on an owner-only socket; [answer] puts the ask through the hub. */
export function servePhoneAsk(sockPath: string, answer: (a: PhoneAsk) => Promise<PhoneReply>): Server | null {
  if (sockPath.length > 100) return null;
  try {
    if (existsSync(sockPath)) unlinkSync(sockPath); // our own stale socket file from a crashed run, and only that exact path
  } catch {
    return null;
  }
  const server = createServer((c) => {
    let buf = '';
    c.setEncoding('utf8');
    c.on('data', (d: string) => {
      buf += d;
      if (buf.length > MAX_LINE) return void c.destroy();
      const nl = buf.indexOf('\n');
      if (nl < 0) return;
      const line = buf.slice(0, nl);
      buf = '';
      void (async () => {
        let out: PhoneReply;
        try {
          // The asking side sends { action, args: {...} }; the checker reads the arguments beside the action.
          const raw = JSON.parse(line) as Record<string, unknown>;
          const p = parsePhoneAsk({ ...(raw && typeof raw.args === 'object' && raw.args && !Array.isArray(raw.args) ? (raw.args as object) : {}), action: raw?.action });
          out = p.ok ? await answer(p.ask) : { ok: false, say: p.error };
        } catch {
          out = { ok: false, say: 'The request could not be read.' };
        }
        c.end(`${JSON.stringify(out)}\n`);
      })();
    });
    c.on('error', () => {});
  });
  server.on('error', () => {});
  try {
    server.listen(sockPath, () => {
      try {
        chmodSync(sockPath, 0o600); // owner-only, like the screen help socket
      } catch {
        /* best effort */
      }
    });
  } catch {
    return null;
  }
  return server;
}

/** Matches `phone_result` frames from the hub to the ask that is waiting for them. */
export class PhoneRequests {
  private waiting = new Map<string, (r: PhoneReply) => void>();
  constructor(private readonly send: (msg: { type: 'phone_command'; requestId: string; action: string; args: Record<string, unknown> }) => void, private readonly newId: () => string, private readonly timeoutMs = 15_000) {}

  ask(a: PhoneAsk): Promise<PhoneReply> {
    if (this.waiting.size >= 5) return Promise.resolve({ ok: false, say: 'Your phone is still busy with earlier requests. Try again in a moment.' });
    const requestId = this.newId();
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.waiting.delete(requestId);
        resolve({ ok: false, say: 'Your phone did not answer. Check that the Escanor app is open on it and connected, and that "Let my other devices ask this phone" is on.' });
      }, this.timeoutMs);
      this.waiting.set(requestId, (r) => (clearTimeout(timer), resolve(r)));
      this.send({ type: 'phone_command', requestId, action: a.action, args: a.args });
    });
  }

  /** A `phone_result` frame from the hub. Unknown ids are ignored. */
  result(m: { requestId?: unknown; ok?: unknown; say?: unknown; data?: unknown }): void {
    const id = typeof m.requestId === 'string' ? m.requestId : '';
    const w = this.waiting.get(id);
    if (!w) return;
    this.waiting.delete(id);
    w({ ok: m.ok === true, say: typeof m.say === 'string' ? m.say : '', ...(m.data && typeof m.data === 'object' ? { data: m.data as Record<string, unknown> } : {}) });
  }
}
