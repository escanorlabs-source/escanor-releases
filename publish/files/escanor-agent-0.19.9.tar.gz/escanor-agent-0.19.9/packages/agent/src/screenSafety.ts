import { createHash, randomBytes } from 'node:crypto';
import { existsSync, readFileSync, renameSync, unlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { desktopEnv, realRunner, type Runner } from './computerControl.js';

/**
 * What keeps the AI's use of the screen safe for any everyday task (used by computerMcp.ts):
 *
 *  1. ScreenLease: one chat drives the screen at a time. Several chats each run their own screen server; without this they click
 *     and type over one another. A small file in the runtime folder names the driver (process id), renewed on every action and
 *     free after a short quiet time or when that process is gone. Others wait a few seconds, then are told the screen is busy.
 *  2. TypeGuard: text is only typed where a text field has the keyboard focus (read from the accessibility service, AT-SPI),
 *     because typing onto a page triggers its single-key shortcuts (a mail trashed, a video skipped). When the desktop cannot
 *     say, typing is allowed only after a click or an address-bar key press since the page last changed.
 *  3. settle: after an action, wait until the picture stops changing (up to a cap) before it is returned, so the AI never judges
 *     a page that is half loaded.
 */

// ------------------------------------------------------------------------------------------------- 1. the screen lease

export const LEASE_FILE_ENV = 'ESCANOR_SCREEN_LEASE_FILE';
type LeaseBody = { pid: number; token: string; at: number; ttl: number };

export type LeaseDeps = {
  file?: string;
  pid?: number;
  now?: () => number;
  alive?: (pid: number) => boolean;
  sleep?: (ms: number) => Promise<void>;
  /** How long a driver keeps the screen without acting. */
  ttlMs?: number;
};

const napMs = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const pidAlive = (pid: number): boolean => {
  try {
    process.kill(pid, 0);
    return true;
  } catch (e) {
    return (e as NodeJS.ErrnoException).code === 'EPERM';
  }
};

export function leaseFile(env: NodeJS.ProcessEnv = process.env): string {
  if (env[LEASE_FILE_ENV]) return env[LEASE_FILE_ENV]!;
  const dir = env.XDG_RUNTIME_DIR || tmpdir();
  const uid = typeof process.getuid === 'function' ? process.getuid() : 0;
  return join(dir, env.XDG_RUNTIME_DIR ? 'escanor-screen.lock' : `escanor-screen-${uid}.lock`);
}

export const BUSY_SAY =
  'The screen is busy with another task right now (another chat on this computer is using it). Do not click or type meanwhile: that would disturb the other task. Wait a minute and try again, or tell the person the screen is in use.';

export class ScreenLease {
  private readonly token = randomBytes(8).toString('hex');
  private held = false;
  constructor(private readonly d: LeaseDeps = {}) {}

  private get file() {
    return this.d.file ?? leaseFile();
  }
  private now() {
    return (this.d.now ?? Date.now)();
  }
  private read(): LeaseBody | null {
    try {
      const b = JSON.parse(readFileSync(this.file, 'utf8')) as LeaseBody;
      return b && typeof b.pid === 'number' && typeof b.token === 'string' && typeof b.at === 'number' ? b : null;
    } catch {
      return null;
    }
  }
  private body(): string {
    return JSON.stringify({ pid: this.d.pid ?? process.pid, token: this.token, at: this.now(), ttl: this.d.ttlMs ?? 90_000 } satisfies LeaseBody);
  }
  private stale(b: LeaseBody | null): boolean {
    if (!b) return true;
    if (b.token === this.token) return false;
    return this.now() > b.at + b.ttl || !(this.d.alive ?? pidAlive)(b.pid);
  }
  /** One attempt: true when this chat now holds (or renewed) the screen. */
  tryAcquire(): boolean {
    const cur = this.read();
    if (cur && cur.token === this.token) {
      try {
        writeFileSync(this.file, this.body(), { mode: 0o600 });
        this.held = true;
        return true;
      } catch {
        return false;
      }
    }
    if (cur && !this.stale(cur)) return false;
    if (existsSync(this.file)) {
      // Move the stale (or unreadable) file aside in one atomic step: of several chats finding it stale, only one gets it.
      const aside = `${this.file}.old.${this.token}`;
      try {
        renameSync(this.file, aside);
      } catch {
        return false;
      }
      try {
        const got = JSON.parse(readFileSync(aside, 'utf8')) as LeaseBody;
        if (cur && got.token !== cur.token && !this.stale(got)) {
          // Moved aside a lease that someone had just taken: put it back and give way.
          try {
            writeFileSync(this.file, JSON.stringify(got), { flag: 'wx', mode: 0o600 });
          } catch {
            /* theirs will be rewritten on their next action */
          }
          unlinkSync(aside);
          return false;
        }
      } catch {
        /* unreadable leftovers are stale anyway */
      }
      try {
        unlinkSync(aside);
      } catch {
        /* gone already */
      }
    }
    try {
      writeFileSync(this.file, this.body(), { flag: 'wx', mode: 0o600 });
      this.held = true;
      return true;
    } catch {
      return false; // another chat created it a moment before
    }
  }
  /** Take the screen, waiting up to `waitMs` for the current driver to finish. Renews when already held. */
  async acquire(waitMs = 8000): Promise<{ ok: true } | { ok: false; say: string }> {
    const sleep = this.d.sleep ?? napMs;
    const end = this.now() + waitMs;
    for (;;) {
      if (this.tryAcquire()) return { ok: true };
      if (this.now() >= end) return { ok: false, say: BUSY_SAY };
      await sleep(250);
    }
  }
  /** Let go (after the quiet time, or when this server ends). Only ever removes this chat's own lease. */
  release(): void {
    if (!this.held) return;
    this.held = false;
    const cur = this.read();
    if (cur && cur.token === this.token) {
      try {
        unlinkSync(this.file);
      } catch {
        /* gone already */
      }
    }
  }
  get holding(): boolean {
    return this.held;
  }
}

// ------------------------------------------------------------------------------------------------- 2. typing only into a text field

/** Reads the focused element from AT-SPI: only the active window is searched, bounded in time and size. Prints one JSON line. */
export const ATSPI_FOCUS_PY = `
import json, time
out = {"found": False}
try:
    import gi
    gi.require_version('Atspi', '2.0')
    from gi.repository import Atspi
    end = time.time() + 2.0
    FOCUSED, EDITABLE, ACTIVE = Atspi.StateType.FOCUSED, Atspi.StateType.EDITABLE, Atspi.StateType.ACTIVE
    best = None
    desktop = Atspi.get_desktop(0)
    seen = 0
    for i in range(desktop.get_child_count()):
        app = desktop.get_child_at_index(i)
        if app is None: continue
        for j in range(app.get_child_count()):
            win = app.get_child_at_index(j)
            if win is None: continue
            try:
                if not win.get_state_set().contains(ACTIVE): continue
            except Exception: continue
            stack = [(win, 0)]
            while stack and time.time() < end and seen < 6000:
                node, depth = stack.pop()
                seen += 1
                try:
                    st = node.get_state_set()
                    if st.contains(FOCUSED):
                        role = node.get_role_name()
                        ed = st.contains(EDITABLE) or role in ('entry', 'password text', 'terminal', 'spin button')
                        if best is None or depth >= best[0]:
                            best = (depth, role, ed)
                    for k in range(node.get_child_count()):
                        c = node.get_child_at_index(k)
                        if c is not None: stack.append((c, depth + 1))
                except Exception: pass
    if best is not None:
        out = {"found": True, "role": best[1], "editable": bool(best[2])}
except Exception:
    pass
print(json.dumps(out))
`;

export type Focus = { found: boolean; editable?: boolean; role?: string };

export async function readFocus(d: { run?: Runner; env?: NodeJS.ProcessEnv; platform?: NodeJS.Platform } = {}): Promise<Focus> {
  const platform = d.platform ?? process.platform;
  if (platform !== 'linux') return { found: false };
  const env = desktopEnv(d.env ?? process.env, platform);
  const r = await (d.run ?? realRunner)({ cmd: 'python3', args: ['-c', ATSPI_FOCUS_PY] }, env);
  if (r.missing || r.code !== 0) return { found: false };
  try {
    const line = r.stdout.trim().split('\n').pop() ?? '';
    const o = JSON.parse(line) as Focus;
    return o && o.found === true ? { found: true, editable: o.editable === true, role: typeof o.role === 'string' ? o.role : undefined } : { found: false };
  } catch {
    return { found: false };
  }
}

/** Key presses that put the keyboard in an input (the browser's address bar, find box) or on one. */
const FOCUS_KEYS = new Set(['ctrl+l', 'ctrl+k', 'ctrl+e', 'ctrl+f', 'ctrl+t', 'f6', 'alt+d', 'ctrl+shift+l']);
/** Key presses after which the page has changed, so the old click no longer says where the keyboard is. */
const RESET_KEYS = new Set(['enter', 'return', 'esc', 'escape', 'ctrl+w', 'alt+left', 'alt+right', 'ctrl+tab', 'ctrl+shift+tab', 'alt+tab', 'super']);
/** Keys that are safe on a page whatever has focus (scrolling and moving), so they are never refused. */
const MOVE_KEYS = new Set(['space', 'enter', 'return', 'tab', 'esc', 'escape', 'up', 'down', 'left', 'right', 'home', 'end', 'pageup', 'pagedown', 'backspace', 'delete']);

export const normalizeKeys = (k: string) => k.trim().toLowerCase().replace(/\s+/g, '').replace(/control/g, 'ctrl');

export function describeFocus(f: Focus): string {
  return f.found ? `the keyboard is on a ${f.role || 'page element'}, not a text field` : 'no text field is known to have the keyboard';
}

export class TypeGuard {
  private armed = false;
  constructor(private readonly read: () => Promise<Focus>) {}

  /** The page changed under the AI (a page was opened, a window switched): an older click no longer says where the keyboard is. */
  reset(): void {
    this.armed = false;
  }
  /** Note a click or key press, to know whether the keyboard was put in a field. */
  noteClick(button: unknown): void {
    if (button === 'right' || button === 'middle') return;
    this.armed = true;
  }
  noteKeys(keys: string): void {
    const k = normalizeKeys(keys);
    if (FOCUS_KEYS.has(k)) this.armed = true;
    else if (RESET_KEYS.has(k)) this.armed = false;
  }
  /** May this text be typed now? Reads the focus first. */
  async checkType(): Promise<{ ok: true } | { ok: false; say: string }> {
    const f = await this.read();
    if (f.found && f.editable) return { ok: true };
    if (!f.found && this.armed) return { ok: true }; // the desktop cannot say (a browser page without accessibility): trust the click
    return {
      ok: false,
      say: `Not typed: ${describeFocus(f)}${f.found ? '' : ' (nothing was clicked since the page last changed)'}. Typing onto a page can trigger its shortcuts (delete, archive, skip) instead of writing text. Click the text field first (or press ctrl+l to type an address), take a screen_look to check the cursor is in it, then type.`,
    };
  }
  /** A single letter or symbol pressed alone acts as a shortcut on most pages: refuse it when the keyboard is surely not in a text field. */
  async checkKeys(keys: string): Promise<{ ok: true } | { ok: false; say: string }> {
    const k = normalizeKeys(keys);
    if (!/^(shift\+)?[^+]$/.test(k) || MOVE_KEYS.has(k)) return { ok: true };
    const f = await this.read();
    if (f.found && !f.editable) {
      return { ok: false, say: `Not pressed: "${keys}" alone is a page shortcut (it can delete, archive or send things) and ${describeFocus(f)}. Click the text field first if you meant to type, or use the page's own buttons.` };
    }
    return { ok: true };
  }
}

// ------------------------------------------------------------------------------------------------- 3. wait for the picture to settle

export type Frame = { b64: string; bytes: number; width: number; height: number };

/** Two pictures count as the same when identical, or the same size within a hair (a blinking cursor or a clock changes a few bytes). */
export function sameFrame(a: Frame, b: Frame): boolean {
  if (a.width !== b.width || a.height !== b.height) return false;
  if (a.b64 === b.b64) return true;
  return Math.abs(a.bytes - b.bytes) <= Math.max(16, a.bytes * 0.002) && hashSample(a.b64) === hashSample(b.b64);
}
/** A picture's coarse fingerprint: some characters spread over the whole file (a change on screen moves most of them). */
function hashSample(b64: string): string {
  const step = Math.max(1, Math.floor(b64.length / 512));
  let s = '';
  for (let i = 0; i < b64.length; i += step) s += b64[i];
  return createHash('sha1').update(s).digest('hex');
}

/**
 * Take pictures until two in a row match (the page stopped changing), at most `capMs`. Returns the last one and whether it settled.
 * `first` is a picture already in hand to start from.
 */
export async function settle<T extends Frame>(snap: () => Promise<T | null>, opts: { capMs: number; everyMs?: number; sleep?: (ms: number) => Promise<void>; now?: () => number; first?: T | null }): Promise<{ shot: T | null; settled: boolean; waitedMs: number }> {
  const sleep = opts.sleep ?? napMs;
  const now = opts.now ?? Date.now;
  const every = opts.everyMs ?? 350;
  const start = now();
  let prev = opts.first === undefined ? await snap() : opts.first;
  if (opts.capMs <= 0 || !prev) return { shot: prev, settled: opts.capMs <= 0, waitedMs: 0 };
  let older: T | null = null;
  for (;;) {
    if (now() - start >= opts.capMs) return { shot: prev, settled: false, waitedMs: now() - start };
    await sleep(every);
    const cur = await snap();
    if (!cur) return { shot: prev, settled: false, waitedMs: now() - start };
    // The same as the last picture, or as the one before it (a blinking cursor flips between two): the page is not moving.
    if (sameFrame(prev, cur) || (older && sameFrame(older, cur))) return { shot: cur, settled: true, waitedMs: now() - start };
    older = prev;
    prev = cur;
  }
}
