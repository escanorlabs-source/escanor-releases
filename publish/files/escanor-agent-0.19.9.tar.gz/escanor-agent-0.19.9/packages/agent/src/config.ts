import { existsSync } from 'node:fs';
import { homedir, hostname } from 'node:os';
import { resolveMachineId } from './machineId.js';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isValidMcpServerName, type ManagedMcpServer, type PermissionMode } from '@remote-harness/shared';
import { isPermissionMode } from '@remote-harness/shared/validate';
import { workspaceRootFrom } from './paths.js';
import { canSwitchUsers, chatUsersFrom } from './chatUser.js';
import { hubTokenFrom } from './hubToken.js';
import { keepAwakeModeFrom } from './keepAwake.js';
import { chatLimitsFrom } from './chatPolicy.js';
import { outboxKeyFrom } from './outboxKey.js';
import { guardLimitsFrom } from './resourceGuard.js';
import { userFirstLimitsFrom } from './userFirst.js';

export { ensurePrivate } from './envPerms.js';

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var ${name}`);
  return v;
}

// Throws rather than defaulting to "/" when neither WORKSPACE_ROOT nor HOME is set.
const workspaceRoot = workspaceRootFrom(process.env);

// Set by the Escanor worker container: this agent runs in a sandbox, so its local tools need no approval.
const managed = process.env.ESCANOR_MANAGED === '1';

/**
 * A per-machine MCP entry, given by whoever started this machine (an incident's): `{name, url, token, autoAllow?,
 * autoAllowReads?}`. It replaces the hub's entry of the same name on this machine, so a machine sent to look at one
 * incident uses the incident's own short-lived, read-only token instead of the workspace's standing, auto-allowed one.
 * The variable is removed from the environment once read, so a shell the agent starts does not inherit it.
 */
export function parseMcpOverride(raw: string | undefined): Omit<ManagedMcpServer, 'updatedAt'> | null {
  if (!raw) return null;
  try {
    const o = JSON.parse(raw) as Record<string, unknown>;
    const name = typeof o.name === 'string' ? o.name : '';
    const url = typeof o.url === 'string' ? o.url : '';
    const token = typeof o.token === 'string' ? o.token : '';
    if (!isValidMcpServerName(name) || !/^https?:\/\//.test(url) || !token) return null;
    return {
      name,
      url,
      headers: { Authorization: `Bearer ${token}` },
      // Fails closed: anything that changes something waits for a person, unless the entry explicitly says otherwise.
      autoAllow: o.autoAllow === true,
      autoAllowReads: o.autoAllowReads !== false,
      // Only a list of well-formed tool ids counts; anything else is ignored, which leaves the entry stricter.
      ...(Array.isArray(o.autoAllowTools)
        ? { autoAllowTools: o.autoAllowTools.filter((t): t is string => typeof t === 'string' && /^[a-z0-9][a-z0-9_-]{0,39}\.(?:[a-z0-9_.-]{1,80}|[a-z0-9_.-]{0,79}\*)$/.test(t)).slice(0, 120) }
        : {}),
      alwaysLoad: true,
      managedBy: 'override',
    };
  } catch {
    return null;
  }
}

const mcpOverride = parseMcpOverride(process.env.ESCANOR_MCP_OVERRIDE);
delete process.env.ESCANOR_MCP_OVERRIDE;

/**
 * The mode a chat starts in when the app picks none (DEFAULT_PERMISSION_MODE, written at install from the owner's plan).
 * 'bypassPermissions' = this machine does everything itself: chats never wait for the phone to approve anything (and the
 * app's "Autonomous" runs as bypass here). Unset or unknown = 'default'.
 */
export function defaultModeFrom(raw: string | undefined): PermissionMode {
  const v = raw?.trim();
  if (v && isPermissionMode(v)) return v;
  if (v) console.warn(`DEFAULT_PERMISSION_MODE=${v} is not a permission mode; using 'default'.`);
  return 'default';
}

let currentHubToken = hubTokenFrom(process.env);
export function setHubToken(token: string): void {
  currentHubToken = token;
}

const chatUsersWanted = chatUsersFrom(process.env);
const chatUsers = chatUsersWanted && canSwitchUsers() ? chatUsersWanted : null;
if (chatUsersWanted && !chatUsers) console.warn('Chat users are configured but this agent cannot switch users: chats run as the agent.');

export const config = {
  // Fewer chats, Claude's limits respected (chatPolicy.ts): REUSE_IDLE_HOURS=12 (0 = never continue an open chat when a new one
  // is asked for), MAX_OPEN_SESSIONS=5, MAX_LIVE_SESSIONS=3, COMPACT_AT_PERCENT=75, COMPACT_AFTER_TURNS=40.
  chatLimits: chatLimitsFrom(process.env),
  // The person using the computer wins over our work (resourceGuard.ts): ESCANOR_RESOURCE_GUARD=0 (off), ESCANOR_MIN_FREE_MEM_PERCENT=10,
  // ESCANOR_CRITICAL_FREE_MEM_PERCENT=3, ESCANOR_MAX_MEMORY_MB=0 (auto: half the memory, at least 1 GB), ESCANOR_MAX_LOAD_PER_CORE=0.9,
  // ESCANOR_MAX_CPU_PERCENT=70, ESCANOR_NICE=10 (0 = leave priority), ESCANOR_GUARD_INTERVAL_SEC=15, ESCANOR_IDLE_CLOSE_MIN=30 (0 = never).
  resourceGuard: guardLimitsFrom(process.env),
  // The person comes first (userFirst.ts): USER_FIRST=on|gentle|off (starting mode; the phone's setting wins), USER_FIRST_IDLE_MIN=2,
  // USER_FIRST_PAUSE_CPU=70, USER_FIRST_YIELD_CPU=40, USER_FIRST_PAUSE_FREE_MEM=15, USER_FIRST_INTERVAL_SEC=5.
  userFirst: userFirstLimitsFrom(process.env),
  // Keep a laptop awake while chats run: KEEP_AWAKE_WHILE_WORKING=on (default) | ac (only while plugged in) | off.
  keepAwake: keepAwakeModeFrom(process.env.KEEP_AWAKE_WHILE_WORKING),
  // Chats run as these users (chatUser.ts); null when not configured or not possible here.
  chatUsers,
  // Set by the machine's startup script for each boot: Escanor delivers waiting messages only to the agent of the current boot.
  bootId: process.env.ESCANOR_BOOT_ID?.trim() || '',
  mcpOverride,
  defaultMode: defaultModeFrom(process.env.DEFAULT_PERMISSION_MODE),
  managed,
  // A short briefing appended to the assistant's system prompt (what it can reach and how to work).
  guideFile: process.env.ESCANOR_GUIDE_FILE?.trim() || '',
  // Embedded in Escanor Desktop (embed.ts): the computer's stable id (the desktop's install id) and its kind. Absent on servers and laptops.
  embedded: process.env.ESCANOR_EMBEDDED === '1',
  // The id the hub keeps this computer under: given by the Desktop app that starts its own agent, else the one derived from the operating system
  // (machineId.ts: not tied to the computer's name; an older name-based id from an older Desktop is swapped for it).
  machineId: resolveMachineId(process.env),
  machineKind: process.env.ESCANOR_MACHINE_KIND?.trim() === 'personal' ? ('personal' as const) : null,
  hubUrl: required('HUB_URL'),
  // Read at the moment of use (a getter): update_token in embedded mode changes it for every call to Escanor, not only the hub socket.
  get hubToken(): string {
    return currentHubToken;
  },
  vmName: process.env.VM_NAME?.trim() || hostname(),
  workspaceRoot,
  // Where the "new chat" project picker looks for subfolders. Defaults to
  // the workspace root itself, but can be narrower (e.g. everything lives
  // under WORKSPACE_ROOT but your actual projects are under ~/projects).
  projectsRoot: resolve(process.env.PROJECTS_ROOT || workspaceRoot),
  dataDir: resolve(process.env.DATA_DIR || './data'),
  // Show Claude Code sessions started in a terminal on this machine (inside TERMINAL_SYNC_ROOT) in the app. A managed
  // worker has no terminal user, so it is off there.
  syncTerminalSessions: process.env.SYNC_TERMINAL_SESSIONS ? process.env.SYNC_TERMINAL_SESSIONS !== '0' : !managed,
  // Which terminal sessions show up: those started inside this folder. Defaults to WORKSPACE_ROOT; set it wider (e.g.
  // $HOME) when terminals are opened outside the workspace. Only for showing and resuming those chats: new chats from
  // the app still start inside WORKSPACE_ROOT.
  terminalSyncRoot: resolve(process.env.TERMINAL_SYNC_ROOT?.trim() || workspaceRoot),
  // A message from the app for a chat still open in a terminal here goes into that terminal chat (terminalInbox.ts: two hooks
  // the agent adds to ~/.claude/settings.json). PHONE_TO_TERMINAL=0 turns it off and takes the hooks out again.
  phoneToTerminal: process.env.PHONE_TO_TERMINAL ? process.env.PHONE_TO_TERMINAL !== '0' : !managed,
  // Small chats this machine opens for itself (automation runs nobody typed in, terminal sessions with no reply such as
  // /model) are deleted from the app and from this machine once they have been quiet this long. CLEAN_SMALL_SESSIONS=0 keeps
  // them; SMALL_SESSION_KEEP_MIN sets the wait (default 60).
  cleanSmallSessions: process.env.CLEAN_SMALL_SESSIONS !== '0',
  smallSessionKeepMs: Math.max(1, Number(process.env.SMALL_SESSION_KEEP_MIN) || 60) * 60_000,
  profilesDir: resolve(process.env.PROFILES_DIR || `${homedir()}/.claude-profiles`),
  // DEV7: what runs on this machine (ports, dev servers, docker, git, tests, agents, health) every 60 s and on change.
  // MACHINE_STATE=0 turns it off.
  machineState: process.env.MACHINE_STATE !== '0',
  // FLOW3: after each turn of a fix done on this computer, run the repository's tests on the base and the pushed fix and report
  // them (escanor_tests). FIX_TESTS=0 turns it off; FIX_TEST_TIMEOUT_MIN caps each run (default 15).
  fixTests: process.env.FIX_TESTS !== '0',
  fixTestTimeoutMs: Math.max(1, Number(process.env.FIX_TEST_TIMEOUT_MIN) || 15) * 60_000,
  // I2: signs data/outbox.jsonl. Kept in the agent's env file: ESCANOR_ENV_FILE, else ./.env (install.sh), else ../../agent.env
  // (the desktop/laptop layout, where systemd reads agent.env); made on the first start.
  outboxKey: outboxKeyFrom(process.env, {
    // Embedded: no env file at all, the key lives in <data>/outbox.key.
    envFile: process.env.ESCANOR_EMBEDDED === '1' ? null : [process.env.ESCANOR_ENV_FILE?.trim(), resolve('.env'), resolve('../../agent.env')].find((f): f is string => !!f && existsSync(f)) ?? null,
    dataDir: resolve(process.env.DATA_DIR || './data'),
  }),
  // In a managed worker WebFetch asks unless its host is listed here (comma separated; `*.example.com` allowed).
  fetchAllow: (process.env.ESCANOR_FETCH_ALLOW ?? '').split(',').map((h) => h.trim()).filter(Boolean),
  // The assistant may not change these on its own, even inside its workspace: this agent's code and its data
  // (planting code there is persistent execution as the agent's user).
  protectedPaths: [resolve(fileURLToPath(new URL('..', import.meta.url))), resolve(process.env.DATA_DIR || './data')],
};
