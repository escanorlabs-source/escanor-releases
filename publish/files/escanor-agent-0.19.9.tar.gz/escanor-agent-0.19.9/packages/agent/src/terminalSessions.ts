import { messagePreview } from './sessionPreview.js';
import { watch, type FSWatcher } from 'node:fs';
import { deleteSession, getSessionInfo, getSessionMessages, listSessions, type SDKSessionInfo, type SessionMessage } from '@anthropic-ai/claude-agent-sdk';
import type { AgentToHubMessage } from '@remote-harness/shared';
import { claudeSessionsDir, readClaudeProcs, type ClaudeProc } from './claudeProcs.js';
import { isInside, realpathLoose } from './paths.js';
import type { RegistryEntry, SessionRegistry } from './registry.js';
import { titleFrom } from './sessionManager.js';
import { isPhoneLine } from './terminalInbox.js';
import { hasRealReply, onlyCommands } from './smallSessions.js';
import { TurnState } from './turnState.js';
import { backgroundAt, type BackgroundScan } from './background.js';


// A first import sends only the recent part of a chat, trimmed: transcripts here run to tens of MB, mostly tool output.
// Claude itself still resumes from the full transcript on this machine; this is only what the app displays.
const MAX_BACKFILL = 500;
const MAX_TEXT = 20_000;
const MAX_IMAGE_BASE64 = 300_000;
const DEFAULT_INTERVAL_MS = 60_000;
// Sessions whose Claude process is still open are looked at this often (a stat of the transcript; it is read only when it changed).
const DEFAULT_LIVE_INTERVAL_MS = 2_000;
// A transcript is read whole (tens of MB, up to a second): while it keeps changing, wait at least this long, and at least ten
// times as long as the last read took, before reading it again, so a busy chat costs this machine little.
const DEFAULT_MIN_READ_GAP_MS = 2_000;
// Claude Code rewrites a session's record (~/.claude/sessions/<pid>.json) when it goes busy or idle: look soon after.
const WATCH_DEBOUNCE_MS = 300;

/** Running a turn, or waiting for an answer in the terminal: the chat is not done. */
const isRunning = (p: ClaudeProc | undefined) => p !== undefined && (p.status === 'busy' || p.status === 'waiting');

/**
 * Makes Claude Code sessions run in a terminal on this machine show up in the app: each one inside the workspace is
 * registered (so the app can resume it) and its transcript is sent to the hub, then kept current while it continues
 * in the terminal. Sessions the agent itself is running are skipped; their messages already reach the hub live.
 *
 * Truthful state: a session whose Claude process is still open and busy (claudeProcs.ts) stays "active" on the hub, and its new
 * lines go out within seconds (a live tick plus a watch on Claude's session records). It is ended (`session_ended`, idle on the
 * phone) once, when Claude goes idle or the terminal is closed, not after every sync.
 */
export class TerminalSessionSync {
  private running = false;
  private timer: NodeJS.Timeout | null = null;
  private liveTimer: NodeJS.Timeout | null = null;
  private watcher: FSWatcher | null = null;
  private watchTimer: NodeJS.Timeout | null = null;
  private liveRunning = false;
  /** What the hub was last told about each chat's background work (to send only changes). */
  private bgSent = new Map<string, string>();
  /** What the hub was last told per terminal session: running (active) or not (ended). */
  private reported = new Map<string, boolean>();
  /** When each transcript was last read, and how long that took (to space out reads of big ones). */
  private lastRead = new Map<string, { at: number; tookMs: number }>();
  private procs = new Map<string, ClaudeProc>();

  constructor(
    private o: {
      workspaceRoot: string;
      registry: SessionRegistry;
      send: (msg: AgentToHubMessage) => void;
      isLive: (sessionId: string) => boolean;
      /** The account terminal chats are tagged with (asked each time: the machine's accounts can change). */
      accountId: string | (() => string);
      /** Is this chat on a Claude account? A ChatGPT / Gemini chat has no Claude transcript: it is never read or synced here. */
      isClaudeChat?: (e: RegistryEntry) => boolean;
      intervalMs?: number;
      liveIntervalMs?: number;
      minReadGapMs?: number;
      list?: typeof listSessions;
      read?: typeof getSessionMessages;
      info?: typeof getSessionInfo;
      /** Claude processes alive on this machine, by session id (claudeProcs.ts). */
      procs?: () => Map<string, ClaudeProc>;
      sessionsDir?: string;
      /** Watch Claude's session records for busy/idle changes (default on). */
      watch?: boolean;
      now?: () => number;
      /**
       * A terminal session that never got a reply from Claude (only /model, /clear...) is not shown in the app; once its
       * terminal is closed and it has been quiet this long, its transcript is deleted from this machine. Unset: kept.
       */
      smallKeepMs?: number;
      remove?: typeof deleteSession;
      /**
       * Has this chat's last turn ended, by its transcript (turnState.ts)? Claude's process record can stay `busy` long after the
       * reply is done (background jobs still open); then the chat is idle, not working. Default: read the transcript.
       */
      turnEnded?: (sessionId: string, cwd: string | undefined) => boolean;
      /** What the chat left running in the background, by its transcript (background.ts). Default: read the transcript. */
      background?: (sessionId: string, cwd: string | undefined) => BackgroundScan | null;
    },
  ) {}

  private turns = new TurnState();

  /** Running a turn (or waiting for an answer) by its process record, and not finished by its transcript. */
  private runningNow(sessionId: string): boolean {
    const p = this.procs.get(sessionId);
    if (!isRunning(p)) return false;
    const ended = this.o.turnEnded ?? ((id: string, cwd: string | undefined) => this.turns.ended(id, cwd));
    return !ended(sessionId, p!.cwd);
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.syncOnce(), this.o.intervalMs ?? DEFAULT_INTERVAL_MS);
    this.timer.unref();
    this.liveTimer = setInterval(() => void this.syncLive(), this.o.liveIntervalMs ?? DEFAULT_LIVE_INTERVAL_MS);
    this.liveTimer.unref();
    if (this.o.watch !== false) {
      try {
        this.watcher = watch(this.o.sessionsDir ?? claudeSessionsDir(), { persistent: false }, () => {
          if (this.watchTimer) return;
          this.watchTimer = setTimeout(() => {
            this.watchTimer = null;
            void this.syncLive();
          }, WATCH_DEBOUNCE_MS);
          this.watchTimer.unref();
        });
        this.watcher.on('error', () => this.watcher?.close());
      } catch {
        // No session records folder yet (Claude Code never ran here): the live tick still notices changes.
      }
    }
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    if (this.liveTimer) clearInterval(this.liveTimer);
    if (this.watchTimer) clearTimeout(this.watchTimer);
    this.watcher?.close();
    this.timer = this.liveTimer = this.watchTimer = null;
    this.watcher = null;
  }

  /** Is this terminal session running a turn (or waiting for an answer in the terminal) right now? */
  isBusy(sessionId: string): boolean {
    return this.runningNow(sessionId);
  }

  /** Read Claude's session records again (before a hello, so it lists terminal sessions that are busy as active). */
  refreshProcs(): Map<string, ClaudeProc> {
    return this.readProcs();
  }

  private readProcs(): Map<string, ClaudeProc> {
    try {
      this.procs = (this.o.procs ?? readClaudeProcs)();
    } catch {
      this.procs = new Map();
    }
    return this.procs;
  }

  async syncOnce(): Promise<void> {
    if (this.running || this.liveRunning) return; // one sync at a time, or a chat is imported/backfilled twice
    this.running = true;
    try {
      this.readProcs();
      const root = realpathLoose(this.o.workspaceRoot);
      const infos = await (this.o.list ?? listSessions)({});
      for (const info of infos) {
        if (!info.cwd || !isInside(root, realpathLoose(info.cwd))) continue;
        try {
          await this.syncSession(info, { force: true });
        } catch (err) {
          console.error(`[terminal-sync] ${info.sessionId}: ${err instanceof Error ? err.message : err}`);
        }
      }
    } catch (err) {
      console.error(`[terminal-sync] ${err instanceof Error ? err.message : err}`);
    } finally {
      this.running = false;
    }
  }

  /** Only the sessions whose Claude process is open (and those just closed): cheap, so it runs every couple of seconds. */
  async syncLive(): Promise<void> {
    if (this.liveRunning || this.running) return;
    this.liveRunning = true;
    try {
      const procs = this.readProcs();
      const root = realpathLoose(this.o.workspaceRoot);
      const ids = new Set([...procs.keys(), ...[...this.reported].filter(([, running]) => running).map(([id]) => id)]);
      for (const id of ids) {
        if (this.o.isLive(id)) continue;
        try {
          const dir = procs.get(id)?.cwd ?? this.o.registry.get(id)?.cwd;
          if (!dir || !isInside(root, realpathLoose(dir))) continue;
          const info = await (this.o.info ?? getSessionInfo)(id, { dir });
          if (!info?.cwd) {
            if (!procs.has(id)) this.reportState(id, false); // closed before it wrote anything we could read
            continue;
          }
          if (!isInside(root, realpathLoose(info.cwd))) continue;
          await this.syncSession(info, { force: false });
        } catch (err) {
          console.error(`[terminal-sync] ${id}: ${err instanceof Error ? err.message : err}`);
        }
      }
    } finally {
      this.liveRunning = false;
    }
  }

  /** Tell the hub when a terminal session stops running (it shows idle); starting again shows from its new messages. */
  private reportState(id: string, running: boolean): boolean {
    const was = this.reported.get(id);
    this.reported.set(id, running);
    if (!running) {
      if (was === true) this.o.send({ type: 'session_ended', sessionId: id });
      this.reported.delete(id);
    }
    return was === true && !running;
  }

  /** A turn the agent ran has finished: the hub already has its messages, so remember where its transcript stops. */
  async markSynced(sessionId: string, cwd: string): Promise<void> {
    const entry = this.o.registry.get(sessionId);
    if (!entry) return;
    if (this.o.isClaudeChat && !this.o.isClaudeChat(entry)) return;
    try {
      const msgs = await this.readAll(sessionId, cwd);
      const last = msgs.at(-1)?.uuid;
      if (last) this.o.registry.upsert({ ...entry, syncedUuid: last, syncedMtime: undefined });
    } catch {
      // the next sync baselines it instead
    }
  }

  private async syncSession(info: SDKSessionInfo, opts: { force: boolean }): Promise<void> {
    const id = info.sessionId;
    const entry = this.o.registry.get(id);
    const running = !this.o.isLive(id) && this.runningNow(id);
    if (entry?.syncedMtime !== undefined && info.lastModified <= entry.syncedMtime) {
      // Nothing new in the transcript; the hub may still need to hear that it stopped running (or that a wake-up time passed).
      if (!this.o.isLive(id)) this.settle(id, running, false);
      return;
    }
    if (!opts.force && entry && !this.readDue(id)) return;

    const started = this.now();
    const msgs = await this.readAll(id, info.cwd!);
    this.lastRead.set(id, { at: this.now(), tookMs: this.now() - started });
    if (this.o.isLive(id)) {
      // Its messages reach the hub live. Keep the marker at the end of its transcript anyway: the chat stays open until
      // the agent stops, and a marker left behind would resend everything since then after the next start.
      const last = msgs.at(-1)?.uuid;
      if (entry && last) this.o.registry.upsert({ ...entry, syncedUuid: last, syncedMtime: info.lastModified });
      return;
    }

    let next: RegistryEntry;
    let toSend: SessionMessage[];
    if (!entry && !running && !hasRealReply(msgs) && onlyCommands(msgs)) {
      // A small session the terminal opened and used only for commands (/model, /clear...): not shown in the app, and deleted
      // here once used up. One that is busy shows at once (its reply is on the way), and so does a request that got no answer.
      await this.dropSmall(info);
      return;
    }
    if (!entry) {
      next = {
        sessionId: id,
        cwd: realpathLoose(info.cwd!),
        title: titleFrom(info.customTitle || info.summary || info.firstPrompt || ''),
        createdAt: new Date(info.createdAt ?? info.lastModified).toISOString(),
        accountId: typeof this.o.accountId === 'function' ? this.o.accountId() : this.o.accountId,
        source: 'terminal',
      };
      // tempId = sessionId: the hub stores it like a new chat without aliasing anything, and tells open apps about it.
      this.o.send({ type: 'session_created', tempId: id, sessionId: id, cwd: next.cwd, title: next.title, accountId: next.accountId, source: 'terminal' });
      toSend = msgs.slice(-MAX_BACKFILL);
    } else if (!entry.syncedUuid) {
      // Made by the agent before this sync existed (or it stopped mid-chat): the hub has its messages already.
      next = entry;
      toSend = [];
    } else {
      next = entry;
      const at = msgs.findIndex((m) => m.uuid === entry.syncedUuid);
      // Not found means the transcript was rewound or compacted; resending it all would duplicate the history.
      toSend = at === -1 ? [] : msgs.slice(at + 1);
    }

    // A message the phone handed to this terminal chat (terminalInbox.ts) is on the hub already, as the phone sent it.
    toSend = toSend.filter((m) => !isPhoneLine(m));
    for (let i = 0; i < toSend.length; i++) {
      this.o.send({ type: 'sdk_message', sessionId: id, message: slim(toSend[i]) });
      if (i % 100 === 99) await new Promise((r) => setImmediate(r));
    }
    for (let i = toSend.length - 1; i >= 0; i--) {
      const pv = messagePreview(toSend[i]);
      if (pv) { next = { ...next, preview: pv }; break; }
    }
    // Any sdk_message marks the session active on the hub. Ended only when it is not running here (its terminal is idle or
    // closed); a session still busy in its terminal stays active, and is ended once it stops (reportState).
    this.settle(id, running, toSend.length > 0 || !entry);

    // Re-read: the person may have changed this chat's mode/model/effort while the messages were going out.
    this.o.registry.upsert({ ...next, ...this.o.registry.get(id), ...(next.preview ? { preview: next.preview } : {}), syncedUuid: msgs.at(-1)?.uuid ?? next.syncedUuid, syncedMtime: info.lastModified });
  }

  /**
   * Where a chat stands after a sync. A turn under way: active. A turn over but work left running in the background (helpers,
   * commands, a scheduled wake-up; Claude Code wakes the chat by itself for each): still active, the hub hears what runs (a
   * background_tasks_changed line like an SDK chat's, with `turn_over` and `wake_at`), and it is not ended, so the phone shows it
   * working in the background and a message to it goes straight in. Nothing left: ended (idle).
   */
  private settle(id: string, running: boolean, sentLines: boolean): void {
    // A turn under way is active whatever runs beside it: the (big) transcript is read for background work only once it is over.
    if (running) {
      this.reported.set(id, true);
      return;
    }
    const proc = this.procs.get(id);
    // Its terminal closed: what it ran in the background went with it.
    const scan = proc ? (this.o.background ?? ((i: string, c: string | undefined) => this.turns.background(i, c)))(id, proc.cwd) : null;
    const work = backgroundAt(scan, this.now());
    this.reportBackground(id, work ? scan : null, work?.wakeAt, !running);
    if (running || work) {
      this.reported.set(id, true);
      return;
    }
    if (!this.reportState(id, false) && sentLines) this.o.send({ type: 'session_ended', sessionId: id });
  }

  private reportBackground(id: string, scan: BackgroundScan | null, wakeAt: string | undefined, turnOver: boolean): void {
    const tasks = scan
      ? [
          ...scan.helpers.map((t) => ({ task_id: t.id, task_type: 'local_agent', subagent_type: 'helper', description: t.description })),
          ...scan.commands.map((t) => ({ task_id: t.id, task_type: 'local_bash', description: t.description })),
        ]
      : [];
    const sig = JSON.stringify([tasks.map((t) => t.task_id), wakeAt ?? null, scan ? turnOver : null]);
    const was = this.bgSent.get(id);
    if (was === undefined && !scan) return; // nothing ran in the background, and the hub was never told otherwise
    if (sig === was) return;
    if (scan) this.bgSent.set(id, sig);
    else this.bgSent.delete(id);
    this.o.send({
      type: 'sdk_message',
      sessionId: id,
      message: { type: 'system', subtype: 'background_tasks_changed', tasks, ...(wakeAt ? { wake_at: wakeAt } : {}), ...(scan && turnOver ? { turn_over: true } : {}) },
    });
  }

  private async dropSmall(info: SDKSessionInfo): Promise<void> {
    const keep = this.o.smallKeepMs;
    if (keep === undefined || this.procs.has(info.sessionId) || this.o.isLive(info.sessionId)) return;
    if (this.now() - info.lastModified < keep) return;
    try {
      await (this.o.remove ?? deleteSession)(info.sessionId, { dir: info.cwd });
      this.lastRead.delete(info.sessionId);
      console.log(`[terminal-sync] deleted a used-up terminal session with no reply: ${info.sessionId}`);
    } catch {
      // already gone
    }
  }

  private now(): number {
    return (this.o.now ?? Date.now)();
  }

  private readDue(id: string): boolean {
    const last = this.lastRead.get(id);
    if (!last) return true;
    const gap = Math.max(this.o.minReadGapMs ?? DEFAULT_MIN_READ_GAP_MS, last.tookMs * 10);
    return this.now() - last.at >= gap;
  }

  private readAll(sessionId: string, dir: string): Promise<SessionMessage[]> {
    return (this.o.read ?? getSessionMessages)(sessionId, { dir });
  }
}

/** Copy of a transcript message small enough for the hub: long strings cut, big images replaced by a note. */
export function slim<T>(value: T): T {
  if (typeof value === 'string') {
    return (value.length > MAX_TEXT ? `${value.slice(0, MAX_TEXT)}\n… [${value.length - MAX_TEXT} more characters on the computer]` : value) as T;
  }
  if (Array.isArray(value)) return value.map(slim) as T;
  if (value && typeof value === 'object') {
    const o = value as Record<string, unknown>;
    const src = o.source as { type?: string; data?: unknown } | undefined;
    if (o.type === 'image' && src?.type === 'base64' && typeof src.data === 'string' && src.data.length > MAX_IMAGE_BASE64) {
      return { type: 'text', text: '[image too large to show here]' } as T;
    }
    return Object.fromEntries(Object.entries(o).map(([k, v]) => [k, slim(v)])) as T;
  }
  return value;
}
