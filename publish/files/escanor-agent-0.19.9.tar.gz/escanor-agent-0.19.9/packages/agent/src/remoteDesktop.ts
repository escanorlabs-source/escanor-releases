import { jpegSize } from './screenControl.js';
import { parseEvents, type LiveEvent, type LiveScreen } from './liveControl.js';

/**
 * Remote desktop: the live screen of this computer, streamed to the viewers (phone, web) the hub connects, and their input back
 * (docs/REMOTE_DESKTOP.md). This file owns the viewers of a view, the two-pictures-in-flight rule (a slow link drops pictures instead of
 * building a queue), the quality ladder that follows the link, input checking, clipboard and the end of a view. It never decides who may
 * look: `Jarvis` (the fingerprint yes, the Remote control switch, the access policy) says whether a view is valid and ends it.
 */

export const MAGIC = 0x45;
export const KIND_JPEG = 1;
/** At most this many pictures sent and not yet drawn, per view. */
export const MAX_IN_FLIGHT = 2;
export const MAX_CLIP = 100_000;
const VIEWER_IDLE_MS = 30_000;
const INPUT_PER_SECOND = 400;
const RESTART_WINDOW_MS = 20_000;

/**
 * The ladder, worst to best: picture width, JPEG quality, fewest seconds between pictures. These are the pictures sent while things
 * move; the sharp picture sent when the screen is still is always as big as the screen itself (see applyQuality). The top rungs are
 * the screen's own pixels, so nothing is scaled down and blurred on the way.
 */
export const LADDER: ReadonlyArray<{ width: number; q: number; gap: number }> = [
  { width: 640, q: 30, gap: 0.2 },
  { width: 960, q: 45, gap: 0.12 },
  { width: 1280, q: 55, gap: 0.08 },
  { width: 1600, q: 62, gap: 0.06 },
  { width: 1920, q: 70, gap: 0.05 },
  { width: 2560, q: 76, gap: 0.05 },
];
/** Auto never uses more than this many kilobits a second, however good the link looks (mobile data plans are real money). */
export const AUTO_MAX_KBPS = 9000;
/** The hub drops a picture over 1.5 MB: one bigger than this is never sent (the next, smaller one goes instead). */
export const MAX_FRAME_BYTES = 1_400_000;
/** The sharp picture when the screen is still: never wider than this (a 4K screen is shown at 3840). */
export const SHARP_MAX_WIDTH = 3840;
export type Level = 'auto' | 'low' | 'medium' | 'high';
/** Which rungs each choice may use, and where it starts. */
export const LEVELS: Record<Level, { min: number; max: number; start: number }> = {
  auto: { min: 0, max: 4, start: 3 },
  low: { min: 0, max: 0, start: 0 },
  medium: { min: 2, max: 2, start: 2 },
  high: { min: 4, max: 5, start: 5 },
};

/** The picture sizes and qualities for a rung and the viewer's widest screen (pure, tested). */
export function qualityFor(rung: number, level: Level, narrowest: number): { width: number; q: number; gap: number; refine: boolean; refW: number; refQ: number } {
  const r = LADDER[Math.max(0, Math.min(LADDER.length - 1, rung))]!;
  // The viewer says how many pixels it can show; pictures never need to be wider than that.
  const width = narrowest ? Math.min(r.width, narrowest) : r.width;
  return {
    width,
    q: r.q,
    gap: r.gap,
    refine: level !== 'low' && rung >= 1,
    refW: Math.max(width, Math.min(SHARP_MAX_WIDTH, narrowest || 1920)),
    refQ: rung >= 4 ? 88 : rung >= 3 ? 84 : rung === 2 ? 78 : 70,
  };
}

/** One picture on the wire: 0x45, 0x01, header length (2 bytes), header JSON, JPEG. */
export function encodeFrame(header: { v: string; s: number; w: number; h: number; m: string; k: 0 | 1 }, jpeg: Buffer): Buffer {
  const h = Buffer.from(JSON.stringify(header), 'utf8');
  const head = Buffer.alloc(4);
  head[0] = MAGIC;
  head[1] = KIND_JPEG;
  head.writeUInt16BE(h.length, 2);
  return Buffer.concat([head, h, jpeg]);
}

/** The header and the JPEG of a wire picture, or null when it is not one (tests and the hub's checks use the same rules). */
export function decodeFrame(buf: Buffer): { header: Record<string, unknown>; jpeg: Buffer } | null {
  if (buf.length < 8 || buf[0] !== MAGIC || buf[1] !== KIND_JPEG) return null;
  const n = buf.readUInt16BE(2);
  if (n < 2 || buf.length < 4 + n + 2) return null;
  try {
    const header = JSON.parse(buf.subarray(4, 4 + n).toString('utf8')) as Record<string, unknown>;
    if (!header || typeof header !== 'object') return null;
    return { header, jpeg: buf.subarray(4 + n) };
  } catch {
    return null;
  }
}

/** What this file needs from the one that owns the views (Jarvis). */
export type StreamHost = {
  /** The view as granted, or null when it is unknown, ended or ran out. */
  check(viewId: string): { expiresAt: number; viewOnly: boolean; clipboard: boolean } | null;
  /** Is Remote control on? */
  remoteOn(): boolean;
  /** The viewer is being used: the view may renew itself. Returns the new end time when it did. */
  renew(viewId: string): number | null;
  /** End the view for good, and say why. */
  end(viewId: string, why: string): Promise<void>;
  /** One plain line in the safety log (never text, clipboard or pictures). */
  record(action: string, why: string): void;
  /** The screen may need unlocking before sharing starts (the fingerprint yes covered it). Starts the live session. */
  startLive(): Promise<{ ok: true; unlocked: boolean } | { ok: false; say: string }>;
};

export type StreamDeps = {
  live: LiveScreen;
  host: StreamHost;
  /** Text for one viewer, or for all viewers of a view when `viewer` is undefined. */
  sendText(viewId: string, viewer: string | undefined, msg: Record<string, unknown>): void;
  /** A binary picture for all viewers of the view. False when the link to the hub is too busy: the picture is dropped. */
  sendFrame(frame: Buffer): boolean;
  now?: () => number;
  /** Tests call tick() themselves. */
  autoTick?: boolean;
};

type Viewer = {
  id: string;
  client: 'phone' | 'web' | 'other';
  name: string;
  maxWidth: number;
  acked: number;
  lastSeen: number;
  held: Set<string>;
  inputBudget: number;
  inputAt: number;
  inputs: number;
};

type Stream = {
  viewId: string;
  viewers: Map<string, Viewer>;
  seq: number;
  /** Pictures sent: seq -> when. */
  sent: Map<number, number>;
  pending: { jpeg: Buffer; sharp: boolean } | null;
  latest: { jpeg: Buffer; sharp: boolean } | null;
  level: Level;
  rung: number;
  rtt: number;
  stalls: number;
  calm: number;
  frames: number;
  bytes: number;
  statsAt: number;
  lastInputLog: number;
  inputsSinceLog: number;
  x11Timer: ReturnType<typeof setInterval> | null;
  x11Last: number;
};

const label = (c: string): 'phone' | 'web' | 'other' => (c === 'phone' ? 'phone' : c === 'web' ? 'web' : 'other');
const words = (client: string) => (client === 'phone' ? 'the Escanor phone app' : client === 'web' ? 'the Escanor website' : 'an Escanor app');

export class ScreenStreams {
  private streams = new Map<string, Stream>();
  private off: Array<() => void> = [];
  private timer: ReturnType<typeof setInterval> | null = null;
  private restarts: number[] = [];
  private bannerOn = false;

  constructor(private d: StreamDeps) {
    if (d.autoTick !== false) {
      this.timer = setInterval(() => this.tick(), 1000);
      this.timer.unref?.();
    }
  }

  private now = () => (this.d.now ?? Date.now)();

  /** How many views have a viewer connected now. */
  get active(): number {
    let n = 0;
    for (const s of this.streams.values()) if (s.viewers.size) n++;
    return n;
  }

  private listen(): void {
    if (this.off.length) return;
    this.off.push(
      this.d.live.onFrame((jpeg, sharp) => this.onPicture(jpeg, sharp)),
      this.d.live.onEvent((o) => void this.onLiveEvent(o)),
    );
  }

  private unlisten(): void {
    for (const f of this.off.splice(0)) f();
  }

  // ------------------------------------------------------------------------------------------------- viewers come and go

  async open(viewId: string, viewer: string, client: string): Promise<void> {
    const g = this.d.host.check(viewId);
    if (!g || !this.d.host.remoteOn()) {
      this.d.sendText(viewId, viewer, { t: 'ended', why: !this.d.host.remoteOn() ? 'Remote control is off on this computer.' : 'This view has ended. Ask for it again.' });
      return;
    }
    let s = this.streams.get(viewId);
    if (!s) {
      s = {
        viewId, viewers: new Map(), seq: 0, sent: new Map(), pending: null, latest: null, level: 'auto', rung: LEVELS.auto.start, rtt: 0, stalls: 0, calm: 0,
        frames: 0, bytes: 0, statsAt: this.now(), lastInputLog: this.now(), inputsSinceLog: 0, x11Timer: null, x11Last: 0,
      };
      this.streams.set(viewId, s);
    }
    if (s.viewers.size >= 3 && !s.viewers.has(viewer)) {
      this.d.sendText(viewId, viewer, { t: 'ended', why: 'This view already has enough viewers.' });
      return;
    }
    s.viewers.set(viewer, { id: viewer, client: label(client), name: '', maxWidth: 0, acked: s.seq, lastSeen: this.now(), held: new Set(), inputBudget: INPUT_PER_SECOND, inputAt: this.now(), inputs: 0 });
    this.d.host.record('view_open', `a viewer opened the live screen from ${words(client)}`);
    this.listen();
    const started = await this.d.host.startLive();
    if (!started.ok) {
      this.d.sendText(viewId, viewer, { t: 'note', say: started.say });
      this.d.sendText(viewId, viewer, { t: 'ended', why: started.say });
      this.dropViewer(viewId, viewer, 'could not start');
      return;
    }
    if (started.unlocked) this.d.host.record('unlock_screen', 'unlocked the screen for the live view the owner approved with a fingerprint');
    if (!this.bannerOn) {
      this.bannerOn = true;
      this.d.live.banner('Escanor: your screen is being viewed', `From ${words(client)}. Press Stop to end it now.`);
    }
    this.applyQuality(s);
    this.sendReady(s, viewer);
    if (this.d.live.kind === 'x11' || this.d.live.kind === 'native') this.startPolling(s);
    // A viewer that joins late gets the picture as it is now, without waiting for the screen to change.
    if (s.latest) this.sendPicture(s, s.latest.jpeg, s.latest.sharp);
  }

  close(viewId: string, viewer: string): void {
    this.dropViewer(viewId, viewer, 'the viewer closed');
  }

  private dropViewer(viewId: string, viewerId: string, why: string): void {
    const s = this.streams.get(viewId);
    const v = s?.viewers.get(viewerId);
    if (!s || !v) return;
    this.letGo(v);
    s.viewers.delete(viewerId);
    this.d.host.record('view_close', `a viewer left the live screen (${why})`);
    if (s.viewers.size === 0) this.idle(s);
  }

  /** Nobody is looking at this view any more (the view itself may still be valid): stop the pictures. */
  private idle(s: Stream): void {
    if (s.x11Timer) clearInterval(s.x11Timer);
    s.x11Timer = null;
    s.pending = null;
    if (![...this.streams.values()].some((o) => o.viewers.size)) {
      // Nobody anywhere: the live session itself goes (the notice on the computer goes with it).
      this.unlisten();
      this.bannerOn = false;
      this.d.live.stop();
    }
  }

  /** Every key and button this viewer left held is let go, so a lost connection never leaves Shift stuck down. */
  private letGo(v: Viewer): void {
    const events: LiveEvent[] = [];
    for (const h of v.held) {
      if (h.startsWith('k:')) events.push({ t: 'key', key: h.slice(2), down: false });
      else if (h.startsWith('b:')) events.push({ t: 'btn', b: h.slice(2) as 'left' | 'right' | 'middle', down: false });
    }
    v.held.clear();
    if (events.length && this.d.live.running) void this.d.live.send(events, { fast: true }).catch(() => {});
  }

  /** The view is over (stopped, ran out, Remote control off): every viewer is told why and let go. */
  endView(viewId: string, why: string): void {
    const s = this.streams.get(viewId);
    if (!s) return;
    this.d.sendText(viewId, undefined, { t: 'ended', why });
    for (const v of s.viewers.values()) this.letGo(v);
    s.viewers.clear();
    this.idle(s);
    this.streams.delete(viewId);
  }

  endAll(why: string): void {
    for (const id of [...this.streams.keys()]) this.endView(id, why);
  }

  // ------------------------------------------------------------------------------------------------- what the viewers send

  async inbound(viewId: string, viewer: string, msg: Record<string, unknown>): Promise<void> {
    const s = this.streams.get(viewId);
    const v = s?.viewers.get(viewer);
    if (!s || !v) return;
    const g = this.d.host.check(viewId);
    if (!g || !this.d.host.remoteOn()) {
      await this.d.host.end(viewId, !this.d.host.remoteOn() ? 'Remote control was turned off.' : 'The time ran out.');
      return;
    }
    v.lastSeen = this.now();
    switch (msg.t) {
      case 'hello': {
        v.client = label(String(msg.client));
        v.name = typeof msg.name === 'string' ? msg.name.replace(/[\u0000-\u001f]/g, ' ').slice(0, 40) : '';
        v.maxWidth = typeof msg.maxWidth === 'number' && Number.isFinite(msg.maxWidth) ? Math.max(320, Math.min(4096, Math.floor(msg.maxWidth))) : 0;
        this.applyQuality(s);
        return;
      }
      case 'ack': {
        const n = typeof msg.seq === 'number' && Number.isInteger(msg.seq) ? msg.seq : -1;
        if (n < 0 || n > s.seq) return;
        if (n > v.acked) v.acked = n;
        this.onAck(s, n);
        return;
      }
      case 'quality': {
        const level = msg.level === 'low' || msg.level === 'medium' || msg.level === 'high' || msg.level === 'auto' ? msg.level : null;
        if (!level) return;
        s.level = level;
        s.rung = LEVELS[level].start;
        s.stalls = 0;
        s.calm = 0;
        this.applyQuality(s);
        this.d.sendText(viewId, undefined, { t: 'ready', ...this.readyData(s) });
        return;
      }
      case 'monitor': {
        const id = typeof msg.id === 'string' ? msg.id : '';
        if (g.viewOnly) return;
        const r = await this.d.live.switchMonitor(id);
        this.d.host.record('view_monitor', r.ok ? 'switched the monitor shown' : `could not switch the monitor: ${r.say}`);
        if (!r.ok) this.d.sendText(viewId, viewer, { t: 'note', say: r.say });
        else {
          s.latest = null;
          s.pending = null;
          this.applyQuality(s);
          this.d.sendText(viewId, undefined, { t: 'ready', ...this.readyData(s) });
        }
        return;
      }
      case 'in': {
        if (g.viewOnly) {
          this.d.sendText(viewId, viewer, { t: 'note', say: 'Your access policy lets you look at this computer but not use it.' });
          return;
        }
        const parsed = parseEvents(msg.events);
        if (!parsed.ok) {
          this.d.sendText(viewId, viewer, { t: 'note', say: parsed.error });
          return;
        }
        const now = this.now();
        v.inputBudget = Math.min(INPUT_PER_SECOND, v.inputBudget + ((now - v.inputAt) / 1000) * INPUT_PER_SECOND);
        v.inputAt = now;
        if (v.inputBudget < parsed.events.length) return; // too many too fast: dropped, the screen stays as it is
        v.inputBudget -= parsed.events.length;
        for (const e of parsed.events) {
          if (e.t === 'key') (e.down ? v.held.add(`k:${e.key}`) : v.held.delete(`k:${e.key}`));
          else if (e.t === 'btn') (e.down ? v.held.add(`b:${e.b}`) : v.held.delete(`b:${e.b}`));
        }
        if (!this.d.live.running) {
          const st = await this.d.host.startLive();
          if (!st.ok) {
            this.d.sendText(viewId, viewer, { t: 'note', say: st.say });
            return;
          }
        }
        await this.d.live.send(parsed.events, { fast: true });
        v.inputs += parsed.events.length;
        s.inputsSinceLog += parsed.events.length;
        if (s.inputsSinceLog === parsed.events.length || now - s.lastInputLog > 60_000) {
          this.d.host.record('input', `the viewer used the mouse or keyboard (${s.inputsSinceLog} actions since the last note), live control`);
          s.lastInputLog = now;
          s.inputsSinceLog = 0;
        }
        this.maybeRenew(s);
        return;
      }
      case 'clip_set': {
        if (g.viewOnly || !g.clipboard) {
          this.d.sendText(viewId, viewer, { t: 'note', say: 'Your access policy does not allow copy and paste here.' });
          return;
        }
        const text = typeof msg.text === 'string' ? msg.text.slice(0, MAX_CLIP) : null;
        if (text === null) return;
        const ok = this.d.live.clipSet(text);
        this.d.host.record('clipboard', ok ? `put ${[...text].length} characters on this computer's clipboard from the viewer` : 'could not reach the clipboard');
        if (!ok) this.d.sendText(viewId, viewer, { t: 'note', say: 'This computer\'s clipboard could not be reached.' });
        return;
      }
      case 'clip_get': {
        if (g.viewOnly || !g.clipboard) {
          this.d.sendText(viewId, viewer, { t: 'note', say: 'Your access policy does not allow copy and paste here.' });
          return;
        }
        const text = await this.d.live.clipGet();
        this.d.host.record('clipboard', text === null ? 'the viewer asked for the clipboard; it could not be read' : `the viewer read this computer's clipboard (${[...text].length} characters)`);
        this.d.sendText(viewId, viewer, text === null ? { t: 'note', say: 'The clipboard could not be read.' } : { t: 'clip', text: text.slice(0, MAX_CLIP) });
        return;
      }
      case 'ping': {
        const n = typeof msg.n === 'number' && Number.isFinite(msg.n) ? msg.n : 0;
        this.d.sendText(viewId, viewer, { t: 'pong', n });
        return;
      }
      case 'end':
        await this.d.host.end(viewId, 'The viewer stopped it.');
        return;
      default:
        return;
    }
  }

  // ------------------------------------------------------------------------------------------------- pictures

  private readyData(s: Stream): Record<string, unknown> {
    const live = this.d.live;
    const size = live.screenSize;
    const g = this.d.host.check(s.viewId);
    return {
      viewId: s.viewId,
      width: size?.w ?? 0,
      height: size?.h ?? 0,
      monitors: live.monitors.map((m) => ({ id: m.id, name: m.name, w: m.w, h: m.h, primary: m.primary })),
      monitor: live.monitor,
      expiresAt: g?.expiresAt ?? 0,
      clipboard: live.hasClipboard && (g?.clipboard ?? false) && !(g?.viewOnly ?? false),
      input: !(g?.viewOnly ?? false),
      level: s.level,
    };
  }

  private sendReady(s: Stream, viewer: string): void {
    this.d.sendText(s.viewId, viewer, { t: 'ready', ...this.readyData(s) });
  }

  private onPicture(jpeg: Buffer, sharp: boolean): void {
    for (const s of this.streams.values()) {
      if (!s.viewers.size) continue;
      s.latest = { jpeg, sharp };
      this.sendPicture(s, jpeg, sharp);
    }
  }

  private inFlight(s: Stream): number {
    let acked = Infinity;
    for (const v of s.viewers.values()) acked = Math.min(acked, v.acked);
    return Number.isFinite(acked) ? s.seq - acked : 0;
  }

  private sendPicture(s: Stream, jpeg: Buffer, sharp: boolean): void {
    if (this.inFlight(s) >= MAX_IN_FLIGHT) {
      s.pending = { jpeg, sharp };
      s.stalls++;
      return;
    }
    const dim = jpegSize(jpeg);
    if (!dim) return;
    if (jpeg.length > MAX_FRAME_BYTES) {
      // Too big for the hub: skip it. A sharp one is only the nicer copy of a picture the viewer already has.
      if (!sharp) s.stalls++;
      return;
    }
    const seq = s.seq + 1;
    const frame = encodeFrame({ v: s.viewId, s: seq, w: dim.width, h: dim.height, m: this.d.live.monitor, k: sharp ? 1 : 0 }, jpeg);
    if (!this.d.sendFrame(frame)) {
      // The link to the hub is too busy right now: this one is dropped, the next one goes when there is room.
      s.stalls++;
      return;
    }
    s.seq = seq;
    s.sent.set(seq, this.now());
    if (s.sent.size > 16) s.sent.delete(s.sent.keys().next().value as number);
    s.pending = null;
    s.frames++;
    s.bytes += frame.length;
  }

  private onAck(s: Stream, seq: number): void {
    const at = s.sent.get(seq);
    if (at !== undefined) {
      const rtt = this.now() - at;
      s.rtt = s.rtt ? s.rtt * 0.7 + rtt * 0.3 : rtt;
      for (const k of [...s.sent.keys()]) if (k <= seq) s.sent.delete(k);
    }
    // The newest picture that arrived while the viewer was busy goes now.
    if (s.pending && this.inFlight(s) < MAX_IN_FLIGHT) this.sendPicture(s, s.pending.jpeg, s.pending.sharp);
    this.maybeRenew(s);
  }

  private maybeRenew(s: Stream): void {
    const g = this.d.host.check(s.viewId);
    if (g && g.expiresAt - this.now() < 120_000) this.d.host.renew(s.viewId);
  }

  /** Picture size, quality and rate for the rung this view is on (the narrowest viewer may lower the size). */
  private applyQuality(s: Stream): void {
    let narrowest = 0;
    for (const v of s.viewers.values()) if (v.maxWidth && (!narrowest || v.maxWidth < narrowest)) narrowest = v.maxWidth;
    this.d.live.setQuality(qualityFor(s.rung, s.level, narrowest));
  }

  /** Once a second: follow the link, send the numbers, drop viewers that went quiet. */
  tick(): void {
    const now = this.now();
    for (const s of this.streams.values()) {
      for (const v of [...s.viewers.values()]) {
        if (now - v.lastSeen > VIEWER_IDLE_MS) this.dropViewer(s.viewId, v.id, 'it went quiet');
      }
      if (!s.viewers.size) continue;
      const bounds = LEVELS[s.level];
      const kbps = ((s.bytes * 8) / 1000) / Math.max(0.5, (now - s.statsAt) / 1000);
      const heavy = s.level === 'auto' && kbps > AUTO_MAX_KBPS;
      const slow = s.rtt > 450 || s.stalls >= 3 || heavy;
      if (slow && s.rung > bounds.min) {
        s.rung--;
        s.calm = 0;
        this.applyQuality(s);
      } else if (!slow && s.rtt > 0 && s.rtt < 140 && !(s.level === 'auto' && kbps > AUTO_MAX_KBPS * 0.7)) {
        s.calm++;
        if (s.calm >= 6 && s.rung < bounds.max) {
          s.rung++;
          s.calm = 0;
          this.applyQuality(s);
        }
      } else s.calm = 0;
      s.stalls = 0;
      const secs = Math.max(0.5, (now - s.statsAt) / 1000);
      this.d.sendText(s.viewId, undefined, { t: 'stats', fps: Math.round((s.frames / secs) * 10) / 10, kbps: Math.round((s.bytes * 8) / 1000 / secs), level: s.rung, rtt: Math.round(s.rtt) });
      s.frames = 0;
      s.bytes = 0;
      s.statsAt = now;
      const g = this.d.host.check(s.viewId);
      if (g) this.d.sendText(s.viewId, undefined, { t: 'expires', expiresAt: g.expiresAt });
    }
  }

  // ------------------------------------------------------------------------------------------------- the helper's own events

  private async onLiveEvent(o: Record<string, unknown>): Promise<void> {
    if (o.event === 'locked') {
      for (const s of this.streams.values()) if (s.viewers.size) this.d.sendText(s.viewId, undefined, { t: 'locked', locked: o.locked === true });
      return;
    }
    if (o.event === 'monitors') {
      for (const s of this.streams.values()) if (s.viewers.size) this.d.sendText(s.viewId, undefined, { t: 'monitors', monitors: this.d.live.monitors });
      return;
    }
    if (o.event === 'closed') {
      // The helper went away (the screen locked, or the desktop shut the sharing). While a view is valid and someone is looking: start again, a few times.
      const now = this.now();
      this.restarts = this.restarts.filter((t) => now - t < RESTART_WINDOW_MS);
      const watching = [...this.streams.values()].filter((s) => s.viewers.size);
      if (!watching.length) return;
      if (this.restarts.length >= 3) {
        for (const s of watching) await this.d.host.end(s.viewId, 'The screen could not be shared any more. Open it again.');
        return;
      }
      this.restarts.push(now);
      for (const s of watching) this.d.sendText(s.viewId, undefined, { t: 'note', say: 'The screen changed state (for example it locked). Reconnecting.' });
      const r = await this.d.host.startLive();
      if (!r.ok) {
        for (const s of watching) await this.d.host.end(s.viewId, r.say);
        return;
      }
      if (r.unlocked) this.d.host.record('unlock_screen', 'unlocked the screen again for the live view the owner approved with a fingerprint');
      this.bannerOn = true;
      this.d.live.banner('Escanor: your screen is being viewed', 'Press Stop to end it now.');
      for (const s of watching) {
        this.applyQuality(s);
        this.sendReady(s, [...s.viewers.keys()][0]!);
      }
    }
  }

  /** X11 without GNOME, macOS and Windows have no picture pipe: ask for a screenshot about twice a second while someone looks. */
  private startPolling(s: Stream): void {
    if (s.x11Timer) return;
    s.x11Timer = setInterval(() => {
      if (!s.viewers.size || this.inFlight(s) >= MAX_IN_FLIGHT) return;
      void this.d.live.frame(2000).then((shot) => {
        if (!shot || !s.viewers.size) return;
        const jpeg = Buffer.from(shot.b64, 'base64');
        const sig = jpeg.length * 31 + (jpeg[jpeg.length >> 1] ?? 0);
        if (sig === s.x11Last) return;
        s.x11Last = sig;
        s.latest = { jpeg, sharp: false };
        this.sendPicture(s, jpeg, false);
      });
    }, 500);
    s.x11Timer.unref?.();
  }

  stopAll(): void {
    this.endAll('Remote viewing stopped.');
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}

