import { execFile } from 'node:child_process';
import { readFileSync } from 'node:fs';

/**
 * "Set up this computer": checks which tools Escanor's features need, and plans (then runs, once the owner said yes) the installs with
 * the package manager of this OS or distro. Windows: winget, user scope where the package allows it. macOS: brew. Debian/Ubuntu: apt,
 * Fedora: dnf, Arch: pacman. Nothing here runs a command it was not built from this fixed list, and a plan never runs by itself:
 * jarvis asks for a fingerprint first. Anything that needs admin or sudo is marked, grouped so sudo is asked for once, and when it
 * cannot be done unattended it is reported as "still needs you" with the exact command to run.
 */

export type Pm = 'winget' | 'brew' | 'apt' | 'dnf' | 'pacman';
export type Host = { os: 'windows' | 'macos' | 'linux' | 'other'; distro: string | null; pm: Pm | null };
export type Exec = (file: string, args: string[]) => Promise<string>;
export type Cmd = { file: string; args: string[] };

/** The OS and, on Linux, the distro family from /etc/os-release (ID and ID_LIKE). */
export function detectHost(platform: NodeJS.Platform = process.platform, osRelease: string | null = readOsRelease(platform)): Host {
  if (platform === 'win32') return { os: 'windows', distro: null, pm: 'winget' };
  if (platform === 'darwin') return { os: 'macos', distro: null, pm: 'brew' };
  if (platform !== 'linux') return { os: 'other', distro: null, pm: null };
  const f = (k: string): string[] => {
    const m = new RegExp(`^${k}=("?)(.*)\\1$`, 'm').exec(osRelease ?? '');
    return m ? m[2]!.toLowerCase().split(/\s+/).filter(Boolean) : [];
  };
  const ids = [...f('ID'), ...f('ID_LIKE')];
  const pick = (names: string[], pm: Pm): Host | null => (ids.some((i) => names.includes(i)) ? { os: 'linux', distro: f('ID')[0] ?? names[0]!, pm } : null);
  return (
    pick(['debian', 'ubuntu'], 'apt') ?? pick(['fedora', 'rhel', 'centos'], 'dnf') ?? pick(['arch', 'manjaro'], 'pacman') ?? { os: 'linux', distro: f('ID')[0] ?? null, pm: null }
  );
}

function readOsRelease(platform: NodeJS.Platform): string | null {
  if (platform !== 'linux') return null;
  try {
    return readFileSync('/etc/os-release', 'utf8');
  } catch {
    return null;
  }
}

/** Where a dependency comes from on each package manager. `admin` is true when that install needs admin or sudo. Absent = not offered there. */
type Source = { pkg: string; admin: boolean; cask?: boolean };
type Dep = {
  id: string;
  label: string;
  /** What in Escanor uses it, shown to the person. */
  why: string;
  /** Feature names; a plan can be limited to the features in use. */
  features: string[];
  probe: Cmd;
  /** Does the probe output show a good enough version? */
  ok: (out: string) => boolean;
  windowsOnly?: boolean;
  /** Installed with npm (user level) instead of the system package manager. */
  npm?: string;
  after?: string;
  src: Partial<Record<Pm, Source>>;
  /** Shown when no package manager can do it. */
  manual?: string;
};

const major = (out: string, re: RegExp): number => {
  const m = re.exec(out);
  return m ? Number(m[1]) : 0;
};

export const DEPS: readonly Dep[] = [
  { id: 'git', label: 'Git', why: 'work on code and repositories', features: ['code'], probe: { file: 'git', args: ['--version'] }, ok: (o) => /git version/i.test(o),
    src: { winget: { pkg: 'Git.Git', admin: false }, brew: { pkg: 'git', admin: false }, apt: { pkg: 'git', admin: true }, dnf: { pkg: 'git', admin: true }, pacman: { pkg: 'git', admin: true } } },
  { id: 'gh', label: 'GitHub CLI', why: 'sign in to GitHub and open pull requests', features: ['code'], probe: { file: 'gh', args: ['--version'] }, ok: (o) => /gh version/i.test(o),
    src: { winget: { pkg: 'GitHub.cli', admin: false }, brew: { pkg: 'gh', admin: false }, apt: { pkg: 'gh', admin: true }, dnf: { pkg: 'gh', admin: true }, pacman: { pkg: 'github-cli', admin: true } } },
  { id: 'node', label: 'Node.js (LTS) with npm', why: 'run JavaScript tools and the Claude Code CLI', features: ['code', 'node'], probe: { file: 'node', args: ['--version'] }, ok: (o) => major(o, /v(\d+)\./) >= 20,
    src: { winget: { pkg: 'OpenJS.NodeJS.LTS', admin: false }, brew: { pkg: 'node', admin: false }, apt: { pkg: 'nodejs npm', admin: true }, dnf: { pkg: 'nodejs npm', admin: true }, pacman: { pkg: 'nodejs npm', admin: true } } },
  { id: 'pnpm', label: 'pnpm', why: 'install packages in JavaScript projects', features: ['node'], probe: { file: 'pnpm', args: ['--version'] }, ok: (o) => /^\d+\./.test(o.trim()), npm: 'pnpm', after: 'node', src: {} },
  { id: 'yarn', label: 'yarn', why: 'install packages in JavaScript projects', features: ['node'], probe: { file: 'yarn', args: ['--version'] }, ok: (o) => /^\d+\./.test(o.trim()), npm: 'yarn', after: 'node', src: {} },
  { id: 'tsx', label: 'tsx', why: 'run TypeScript files directly', features: ['node'], probe: { file: 'tsx', args: ['--version'] }, ok: (o) => /\d+\.\d+/.test(o), npm: 'tsx', after: 'node', src: {} },
  { id: 'claude', label: 'Claude Code', why: 'the AI coding assistant Escanor runs', features: ['claude'], probe: { file: 'claude', args: ['--version'] }, ok: (o) => /\d+\.\d+/.test(o), npm: '@anthropic-ai/claude-code', after: 'node', src: {} },
  { id: 'python', label: 'Python 3', why: 'run Python scripts and tools', features: ['python'], probe: { file: 'python3', args: ['--version'] }, ok: (o) => /Python 3\.(1\d|[2-9]\d)/.test(o),
    src: { winget: { pkg: 'Python.Python.3.13', admin: true }, brew: { pkg: 'python@3.13', admin: false }, apt: { pkg: 'python3', admin: true }, dnf: { pkg: 'python3', admin: true }, pacman: { pkg: 'python', admin: true } } },
  { id: 'java', label: 'Java 21', why: 'build and run Java and Android projects', features: ['java'], probe: { file: 'java', args: ['-version'] }, ok: (o) => major(o, /version "(\d+)/) >= 21,
    src: { winget: { pkg: 'EclipseAdoptium.Temurin.21.JDK', admin: true }, brew: { pkg: 'openjdk@21', admin: false }, apt: { pkg: 'openjdk-21-jdk', admin: true }, dnf: { pkg: 'java-21-openjdk-devel', admin: true }, pacman: { pkg: 'jdk21-openjdk', admin: true } } },
  { id: 'pwsh', label: 'PowerShell 7', why: 'scripts that need modern PowerShell', features: ['powershell'], probe: { file: 'pwsh', args: ['-NoLogo', '-NoProfile', '-Command', '$PSVersionTable.PSVersion.Major'] }, ok: (o) => Number(o.trim()) >= 7,
    src: { winget: { pkg: 'Microsoft.PowerShell', admin: true }, brew: { pkg: 'powershell', admin: true, cask: true } },
    manual: 'PowerShell 7 is not in this distro\'s own packages. See https://learn.microsoft.com/powershell/scripting/install/installing-powershell-on-linux' },
  { id: 'vcredist', label: 'Visual C++ runtime', why: 'the Cloudflare workerd tool needs it on Windows', features: ['workerd'], windowsOnly: true,
    probe: { file: 'reg', args: ['query', 'HKLM\\SOFTWARE\\Microsoft\\VisualStudio\\14.0\\VC\\Runtimes\\X64', '/v', 'Installed'] }, ok: (o) => /Installed\s+REG_DWORD\s+0x1/i.test(o),
    src: { winget: { pkg: 'Microsoft.VCRedist.2015+.x64', admin: true } } },
];

export const ALL_FEATURES: readonly string[] = [...new Set(DEPS.flatMap((d) => d.features))];

export type DepRow = { id: string; label: string; why: string; present: boolean };

const realExec: Exec = (file, args) =>
  new Promise((resolve, reject) => {
    // Java prints its version on stderr, so both streams are kept.
    execFile(file, args, { timeout: 15_000, maxBuffer: 1_000_000, windowsHide: true }, (err, stdout, stderr) => (err ? reject(err) : resolve(`${stdout}\n${stderr}`)));
  });

const inScope = (d: Dep, host: Host, features?: readonly string[]): boolean =>
  (!d.windowsOnly || host.os === 'windows') && (!features || d.features.some((f) => features.includes(f)));

/** Read-only: runs each fixed version probe. A program that is missing or answers badly counts as not present. */
export async function checkDeps(o: { host?: Host; features?: readonly string[]; exec?: Exec } = {}): Promise<DepRow[]> {
  const host = o.host ?? detectHost();
  const exec = o.exec ?? realExec;
  const rows: DepRow[] = [];
  for (const d of DEPS.filter((x) => inScope(x, host, o.features))) {
    let present = false;
    try {
      const p = d.id === 'python' && host.os === 'windows' ? { file: 'python', args: d.probe.args } : d.probe; // python3 on Windows is the Store stub
      present = d.ok(await exec(p.file, p.args));
    } catch {
      present = false;
    }
    rows.push({ id: d.id, label: d.label, why: d.why, present });
  }
  return rows;
}

export type Step = {
  id: string;
  /** Plain words for the person. */
  label: string;
  /** Dependencies this step covers. */
  covers: string[];
  admin: boolean;
  /** The command to run; null when nothing can do it unattended (then `manual` says what to do). */
  cmd: Cmd | null;
  manual?: string;
};
export type Plan = { host: Host; steps: Step[]; needsAdmin: boolean; nothingToDo: boolean };

const pmName: Record<Pm, string> = { winget: 'winget', brew: 'Homebrew', apt: 'apt', dnf: 'dnf', pacman: 'pacman' };

/** Builds the install steps for what is missing. System packages of apt, dnf and pacman are one step, so sudo is asked for once. */
export function buildPlan(rows: DepRow[], host: Host, home = ''): Plan {
  const missing = rows.filter((r) => !r.present).map((r) => DEPS.find((d) => d.id === r.id)!);
  const steps: Step[] = [];
  const batch: { dep: Dep; src: Source }[] = [];
  const nodeComing = missing.some((d) => d.id === 'node') && !!host.pm && !!DEPS.find((d) => d.id === 'node')!.src[host.pm];
  const nodeHere = rows.some((r) => r.id === 'node' && r.present);
  for (const d of missing) {
    if (d.npm) {
      const prefix = host.os === 'linux' && home ? ['--prefix', `${home}/.local`] : [];
      if (!nodeHere && !nodeComing) {
        steps.push({ id: d.id, label: `${d.label}: needs Node.js first`, covers: [d.id], admin: false, cmd: null, manual: 'Install Node.js, then run Set up this computer again.' });
      } else steps.push({ id: d.id, label: `Install ${d.label} with npm (your user only)`, covers: [d.id], admin: false, cmd: { file: 'npm', args: ['install', '-g', ...prefix, d.npm] } });
      continue;
    }
    const src = host.pm ? d.src[host.pm] : undefined;
    if (!host.pm || !src) {
      steps.push({ id: d.id, label: `${d.label}: cannot be installed automatically here`, covers: [d.id], admin: false, cmd: null, manual: d.manual ?? `Install ${d.label} yourself; this computer has no package manager Escanor knows.` });
      continue;
    }
    if (host.pm === 'apt' || host.pm === 'dnf' || host.pm === 'pacman') batch.push({ dep: d, src });
    else if (host.pm === 'winget') {
      steps.push({
        id: d.id,
        label: `Install ${d.label} with winget${src.admin ? ' (Windows will ask you to allow it)' : ' (your user only)'}`,
        covers: [d.id],
        admin: src.admin,
        cmd: { file: 'winget', args: ['install', '--id', src.pkg, '-e', '--silent', '--accept-package-agreements', '--accept-source-agreements', ...(src.admin ? [] : ['--scope', 'user'])] },
      });
    } else {
      steps.push({ id: d.id, label: `Install ${d.label} with Homebrew`, covers: [d.id], admin: src.admin, cmd: { file: 'brew', args: ['install', ...(src.cask ? ['--cask'] : []), src.pkg] } });
    }
  }
  if (batch.length && host.pm) {
    const pkgs = batch.flatMap((b) => b.src.pkg.split(' '));
    const args = host.pm === 'apt' ? ['apt-get', 'install', '-y', ...pkgs] : host.pm === 'dnf' ? ['dnf', 'install', '-y', ...pkgs] : ['pacman', '-S', '--noconfirm', '--needed', ...pkgs];
    steps.unshift({ id: `${host.pm}-system`, label: `Install ${batch.map((b) => b.dep.label).join(', ')} with ${pmName[host.pm]} (needs sudo, asked once)`, covers: batch.map((b) => b.dep.id), admin: true, cmd: { file: 'sudo', args: ['-n', ...args] } });
  }
  // System installs (node) go before the npm tools that need them.
  steps.sort((a, b) => Number(!!a.cmd && a.cmd.file === 'npm') - Number(!!b.cmd && b.cmd.file === 'npm'));
  return { host, steps, needsAdmin: steps.some((s) => s.admin), nothingToDo: steps.length === 0 };
}

/** The plain-words list shown before anything runs. */
export function describePlan(p: Plan): string[] {
  if (p.nothingToDo) return ['Everything Escanor needs is already on this computer.'];
  const lines = p.steps.map((s) => `${s.cmd ? '- ' : '- (you) '}${s.label}`);
  if (p.needsAdmin) lines.push(p.host.os === 'windows' ? 'Some of these open a Windows permission prompt (UAC); you answer it once per install.' : 'Some of these need admin rights; you say yes once, before they run.');
  return lines;
}

export type StepResult = { id: string; label: string; state: 'done' | 'failed' | 'needs_you'; say: string; manualCommand?: string };
export type RunReport = { results: StepResult[]; stillMissing: string[]; say: string };

const shown = (c: Cmd): string => [c.file, ...c.args.map((a) => (/\s/.test(a) ? `"${a}"` : a))].join(' ');

/**
 * Runs the plan after the person said yes. Admin steps run only when `allowAdmin` is true (the one yes). A sudo that cannot run without a
 * password does not hang or ask silently: it is reported as "needs you", with the exact command. Then every touched tool is probed again.
 */
export async function runPlan(plan: Plan, o: { allowAdmin: boolean; exec?: Exec; features?: readonly string[] }): Promise<RunReport> {
  const exec = o.exec ?? realExec;
  const results: StepResult[] = [];
  const failedNode = new Set<string>();
  for (const s of plan.steps) {
    if (!s.cmd) {
      results.push({ id: s.id, label: s.label, state: 'needs_you', say: s.manual ?? 'This one needs you.' });
      continue;
    }
    if (s.admin && !o.allowAdmin) {
      results.push({ id: s.id, label: s.label, state: 'needs_you', say: 'This needs admin rights and was not approved.', manualCommand: shown(s.cmd) });
      continue;
    }
    if (s.cmd.file === 'npm' && failedNode.has('node')) {
      results.push({ id: s.id, label: s.label, state: 'needs_you', say: 'Node.js did not install, so this was skipped.' });
      continue;
    }
    try {
      await exec(s.cmd.file, s.cmd.args);
      results.push({ id: s.id, label: s.label, state: 'done', say: 'Installed.' });
    } catch (e) {
      if (s.covers.includes('node')) failedNode.add('node');
      const sudoPassword = s.cmd.file === 'sudo' && /password|terminal is required/i.test(String((e as { stderr?: string }).stderr ?? (e as Error).message));
      results.push({
        id: s.id,
        label: s.label,
        state: sudoPassword || s.admin ? 'needs_you' : 'failed',
        say: sudoPassword ? 'sudo needs your password, which Escanor never types. Run the command yourself.' : s.admin ? 'It did not finish (the permission prompt may have been declined).' : 'It did not finish.',
        ...(s.admin ? { manualCommand: shown(s.cmd) } : {}),
      });
    }
  }
  const after = await checkDeps({ host: plan.host, features: o.features, exec });
  const stillMissing = after.filter((r) => !r.present).map((r) => r.label);
  const done = results.filter((r) => r.state === 'done').length;
  const say = stillMissing.length ? `${done} installed. Still missing: ${stillMissing.join(', ')}.` : 'Everything is installed.';
  return { results, stillMissing, say };
}
