/**
 * What kind of machine this is, found by looking, so the app never has to ask: a laptop, a desktop, a server, a small device
 * (Raspberry Pi), or a virtual machine, and for one in a cloud which cloud, with the names that cloud knows it by (project and
 * zone, region and instance, subscription and resource group). Nothing here is a secret and nothing leaves the machine but this
 * summary, sent in the hello. Every probe has a short deadline and failing is normal: the kind is then "unknown", and the app
 * asks once.
 */
import { execFile } from 'node:child_process';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { networkInterfaces, platform } from 'node:os';

export type MachineKind = 'laptop' | 'desktop' | 'server' | 'device' | 'vm' | 'unknown';
export type CloudName = 'gcp' | 'aws' | 'azure' | 'oci';

export interface MachineInfo {
  kind: MachineKind;
  os: string;
  /** Set when the machine is a VM that a cloud reports itself as. */
  cloud?: CloudName;
  /** The cloud's own names for it: gcp {project, zone, instance}; aws {region, instanceId}; azure {subscriptionId, resourceGroup, vmName}; oci {region, instanceId}. */
  cloudInfo?: Record<string, string>;
  /** Hardware addresses of its network cards, for waking it over the network. */
  macs: string[];
}

const read = (p: string): string => {
  try {
    return readFileSync(p, 'utf8').trim();
  } catch {
    return '';
  }
};

const run = (cmd: string, args: string[], ms = 3000): Promise<string> =>
  new Promise((resolve) => {
    try {
      execFile(cmd, args, { timeout: ms, windowsHide: true }, (err, out) => resolve(err ? '' : String(out).trim()));
    } catch {
      resolve('');
    }
  });

/** DMI chassis types: 3 desktop, 4 low profile, 5 pizza box, 6 mini tower, 7 tower, 8 portable, 9 laptop, 10 notebook, 11 handheld, 13 all in one, 14 sub notebook, 17 main server, 23 rack mount, 30 tablet, 31 convertible, 32 detachable. */
export function kindFromChassis(type: number): MachineKind {
  if ([8, 9, 10, 11, 14, 30, 31, 32].includes(type)) return 'laptop';
  if ([17, 23, 24, 25, 28].includes(type)) return 'server';
  if ([3, 4, 5, 6, 7, 13, 15, 16, 34, 35, 36].includes(type)) return 'desktop';
  return 'unknown';
}

/** From what a machine says about its maker and product: a virtual machine and which cloud, or null. */
export function virtualFrom(vendor: string, product: string, biosVendor = ''): { vm: true; cloud?: CloudName } | null {
  const all = `${vendor} ${product} ${biosVendor}`.toLowerCase();
  if (all.includes('google')) return { vm: true, cloud: 'gcp' };
  if (all.includes('amazon ec2') || all.includes('amazon') && all.includes('ec2')) return { vm: true, cloud: 'aws' };
  if (all.includes('microsoft') && all.includes('virtual machine')) return { vm: true, cloud: 'azure' };
  if (all.includes('oraclecloud') || (all.includes('oracle') && all.includes('kvm'))) return { vm: true, cloud: 'oci' };
  if (/(kvm|qemu|vmware|virtualbox|xen|bochs|parallels|hyper-v|bhyve|virtual machine|openstack|digitalocean|hetzner|vultr|linode)/.test(all)) return { vm: true };
  return null;
}

async function fetchText(url: string, init: { method?: string; headers?: Record<string, string> } = {}): Promise<string | null> {
  try {
    const res = await fetch(url, { ...init, signal: AbortSignal.timeout(900) });
    return res.ok ? await res.text() : null;
  } catch {
    return null;
  }
}

/** Ask the cloud's metadata address who this VM is. Each is link-local and answers only from inside that cloud. */
export async function cloudDetails(): Promise<{ cloud: CloudName; info: Record<string, string> } | null> {
  const gcp = await fetchText('http://metadata.google.internal/computeMetadata/v1/instance/?recursive=true', { headers: { 'Metadata-Flavor': 'Google' } });
  if (gcp) {
    try {
      const j = JSON.parse(gcp) as { name?: string; zone?: string };
      const project = (await fetchText('http://metadata.google.internal/computeMetadata/v1/project/project-id', { headers: { 'Metadata-Flavor': 'Google' } })) ?? '';
      return { cloud: 'gcp', info: { project: project.trim(), zone: String(j.zone ?? '').split('/').pop() ?? '', instance: String(j.name ?? '') } };
    } catch {
      /* fall through */
    }
  }
  const azure = await fetchText('http://169.254.169.254/metadata/instance?api-version=2021-02-01', { headers: { Metadata: 'true' } });
  if (azure) {
    try {
      const c = (JSON.parse(azure) as { compute?: Record<string, string> }).compute ?? {};
      if (c.subscriptionId) return { cloud: 'azure', info: { subscriptionId: c.subscriptionId, resourceGroup: c.resourceGroupName ?? '', vmName: c.name ?? '' } };
    } catch {
      /* fall through */
    }
  }
  const oci = await fetchText('http://169.254.169.254/opc/v2/instance/', { headers: { Authorization: 'Bearer Oracle' } });
  if (oci) {
    try {
      const j = JSON.parse(oci) as { id?: string; region?: string; canonicalRegionName?: string };
      if (j.id) return { cloud: 'oci', info: { region: j.canonicalRegionName ?? j.region ?? '', instanceId: j.id } };
    } catch {
      /* fall through */
    }
  }
  try {
    const tokenRes = await fetch('http://169.254.169.254/latest/api/token', { method: 'PUT', headers: { 'X-aws-ec2-metadata-token-ttl-seconds': '60' }, signal: AbortSignal.timeout(900) });
    if (tokenRes.ok) {
      const token = await tokenRes.text();
      const h = { 'X-aws-ec2-metadata-token': token };
      const id = await fetchText('http://169.254.169.254/latest/meta-data/instance-id', { headers: h });
      const region = await fetchText('http://169.254.169.254/latest/meta-data/placement/region', { headers: h });
      if (id) return { cloud: 'aws', info: { region: (region ?? '').trim(), instanceId: id.trim() } };
    }
  } catch {
    /* not AWS */
  }
  return null;
}

export function macAddresses(): string[] {
  const out = new Set<string>();
  for (const list of Object.values(networkInterfaces())) {
    for (const n of list ?? []) if (!n.internal && n.mac && n.mac !== '00:00:00:00:00:00') out.add(n.mac.toLowerCase());
  }
  return [...out].slice(0, 6);
}

async function localKind(os: string): Promise<{ kind: MachineKind; virtual: ReturnType<typeof virtualFrom> }> {
  if (os === 'linux') {
    const vendor = read('/sys/class/dmi/id/sys_vendor');
    const product = read('/sys/class/dmi/id/product_name');
    const bios = read('/sys/class/dmi/id/bios_vendor');
    const virtual = virtualFrom(vendor, product, bios);
    const model = read('/proc/device-tree/model').replace(/\0/g, '');
    if (/raspberry|odroid|jetson|orange pi|banana pi/i.test(model)) return { kind: 'device', virtual };
    if (virtual) return { kind: 'vm', virtual };
    const chassis = Number(read('/sys/class/dmi/id/chassis_type'));
    let kind = Number.isFinite(chassis) && chassis > 0 ? kindFromChassis(chassis) : 'unknown';
    try {
      if (kind === 'unknown' && readdirSync('/sys/class/power_supply').some((d) => /^BAT/i.test(d))) kind = 'laptop';
    } catch {
      /* none */
    }
    if (kind === 'unknown' && existsSync('/proc/vz') ) kind = 'vm';
    return { kind, virtual };
  }
  if (os === 'darwin') {
    const model = await run('sysctl', ['-n', 'hw.model']);
    if (/vmware|virtual|parallels/i.test(model)) return { kind: 'vm', virtual: { vm: true } };
    return { kind: /book/i.test(model) ? 'laptop' : /server/i.test(model) ? 'server' : 'desktop', virtual: null };
  }
  if (os === 'win32') {
    const chassis = await run('powershell.exe', ['-NoProfile', '-Command', '(Get-CimInstance Win32_SystemEnclosure).ChassisTypes -join \',\''], 6000);
    const model = await run('powershell.exe', ['-NoProfile', '-Command', '(Get-CimInstance Win32_ComputerSystem).Manufacturer + \' \' + (Get-CimInstance Win32_ComputerSystem).Model'], 6000);
    const virtual = virtualFrom(model, model);
    if (virtual) return { kind: 'vm', virtual };
    const first = Number(chassis.split(',')[0]);
    return { kind: Number.isFinite(first) && first > 0 ? kindFromChassis(first) : 'unknown', virtual };
  }
  return { kind: 'unknown', virtual: null };
}

/** Look at this machine. Never throws; slow probes are cut short. */
export async function detectMachine(os: string = platform()): Promise<MachineInfo> {
  const info: MachineInfo = { kind: 'unknown', os, macs: macAddresses() };
  try {
    const { kind, virtual } = await localKind(os);
    info.kind = kind;
    // Only a machine that looks virtual (or whose kind is unknown) asks a cloud's metadata address: a laptop never does.
    if (virtual || kind === 'unknown') {
      const c = await cloudDetails();
      if (c) {
        info.cloud = c.cloud;
        info.cloudInfo = c.info;
        info.kind = 'vm';
      }
    }
  } catch {
    /* unknown is fine */
  }
  return info;
}

// ---------------------------------------------------------------------------- doing something about its power, when the hub asks

/** The command that puts this machine to sleep, or null where there is no way. */
export function suspendCommand(os: string = platform()): { cmd: string; args: string[] } | null {
  if (os === 'linux') return { cmd: 'systemctl', args: ['suspend'] };
  if (os === 'darwin') return { cmd: 'pmset', args: ['sleepnow'] };
  if (os === 'win32') return { cmd: 'rundll32.exe', args: ['powrprof.dll,SetSuspendState', '0,1,0'] };
  return null;
}

export const MAC_RE = /^([0-9a-f]{2}:){5}[0-9a-f]{2}$/i;

/** The magic packet that wakes a machine whose network card listens for it: six 0xff bytes, then its address sixteen times. */
export function magicPacket(mac: string): Buffer | null {
  if (!MAC_RE.test(mac)) return null;
  const bytes = Buffer.from(mac.replace(/:/g, ''), 'hex');
  return Buffer.concat([Buffer.alloc(6, 0xff), ...Array.from({ length: 16 }, () => bytes)]);
}

/** Every broadcast address of this machine's networks, plus the general one, to send a wake-up on. */
export function broadcastAddresses(): string[] {
  const out = new Set<string>(['255.255.255.255']);
  for (const list of Object.values(networkInterfaces())) {
    for (const n of list ?? []) {
      if (n.family !== 'IPv4' || n.internal) continue;
      const ip = n.address.split('.').map(Number);
      const mask = n.netmask.split('.').map(Number);
      out.add(ip.map((b, i) => (b | (~mask[i]! & 255)) & 255).join('.'));
    }
  }
  return [...out];
}
