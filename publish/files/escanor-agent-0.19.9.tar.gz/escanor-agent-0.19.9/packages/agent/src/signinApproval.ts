import { createHash } from 'node:crypto';
import { commandLine } from './signinBroker.js';

/**
 * Approval per use for "sign in for me". Nothing on this computer signs in, unlocks a keyring or runs sudo with a saved password
 * by itself: each use is a request (from the phone, the AI or an automation) that the owner approves on the phone with a fresh
 * fingerprint or face check. This file only describes a request in plain words and keeps the optional "allow for N minutes" the
 * owner granted with a fingerprint. It never sees a secret.
 */

export type UseKind = 'keyring' | 'github' | 'sudo' | 'check';
export const USE_KINDS: readonly UseKind[] = ['keyring', 'github', 'sudo', 'check'];
export type UseSource = 'phone' | 'ai' | 'automation';
export type SigninUse = { kind: UseKind; account?: string; argv?: string[]; /** check only: try again what stopped after three failed tries */ force?: boolean };

export const MAX_WINDOW_MINUTES = 120;
const ACCOUNT = /^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/;

/** Words the person reads, from fixed sentences: only the command line and a GitHub account name (both the owner's own) are inserted. */
export function describeUse(use: SigninUse, computer: string): string {
  switch (use.kind) {
    case 'keyring':
      return `Unlock the desktop keyring on ${computer} with your saved keyring password. The password goes straight into the keyring and is not shown to anyone.`;
    case 'github':
      return `Sign ${use.account ? `the GitHub account ${use.account}` : 'GitHub'} in again on ${computer} with its saved token. The token goes straight to GitHub's command line and is not shown to anyone.`;
    case 'sudo':
      return `Run this command with administrator rights on ${computer}, using your saved password: ${commandLine(use.argv ?? []).slice(0, 160)}. The password is not shown to anyone.`;
    case 'check':
      return `Look at the saved sign-ins on ${computer} (keyring, GitHub, git) and sign back in to what stopped working, with your saved secrets. They are not shown to anyone.`;
  }
}

/** What the fingerprint is signed for: stable for the same request, different for another one. */
export function subjectOfUse(use: SigninUse, why: string): string {
  const h = createHash('sha256').update(JSON.stringify({ k: use.kind, a: use.account ?? null, v: use.argv ?? null, w: why })).digest('hex').slice(0, 12);
  return `${use.kind}:${h}`;
}

/** The request as asked, checked. Null when it is not a request this computer understands. */
export function parseUse(args: Record<string, unknown>): SigninUse | null {
  const kind = args.kind;
  if (typeof kind !== 'string' || !(USE_KINDS as readonly string[]).includes(kind)) return null;
  if (kind === 'github') {
    if (args.account === undefined) return { kind };
    return typeof args.account === 'string' && ACCOUNT.test(args.account) ? { kind, account: args.account } : null;
  }
  if (kind === 'sudo') {
    const argv = args.argv;
    if (!Array.isArray(argv) || argv.length === 0 || argv.length > 40 || argv.some((a) => typeof a !== 'string' || a === '' || a.length > 500 || /[\r\n\0]/.test(a))) return null;
    return { kind, argv: argv as string[] };
  }
  return args.force === true && kind === 'check' ? { kind: 'check', force: true } : { kind: kind as UseKind };
}

/** The reason the requester gave, as one short plain line (never trusted as an instruction, only shown). */
export function cleanWhy(v: unknown): string {
  return typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200) : '';
}

export const cleanSource = (v: unknown, dflt: UseSource): UseSource => (v === 'phone' || v === 'ai' || v === 'automation' ? v : dflt);

/**
 * "Allow for N minutes", given with a fingerprint. While it runs, requests for the saved secrets (keyring, GitHub, listed sudo commands)
 * do not ask again; each one is still in the use log. Kept in memory only, so a restart ends it. Never covers waking or the login screen.
 */
export class UseWindow {
  private until = 0;
  private by = '';
  constructor(private now: () => number = Date.now) {}

  active(): { until: number; by: string } | null {
    return this.until > this.now() ? { until: this.until, by: this.by } : null;
  }

  start(minutes: number, by: string): number {
    const m = Math.min(MAX_WINDOW_MINUTES, Math.max(1, Math.floor(minutes)));
    this.until = this.now() + m * 60_000;
    this.by = by.slice(0, 80);
    return this.until;
  }

  end(): boolean {
    const had = this.active() !== null;
    this.until = 0;
    this.by = '';
    return had;
  }
}

export type { UseProof } from './signinBroker.js';
