/**
 * The stricter safety rules of a PERSONAL computer (the agent inside Escanor Desktop, machine kind `personal`): somebody's own PC
 * holds their passwords, browser logins and everything they own, so on top of the net every machine has (shared/risk.ts and the
 * safety layer's copies) these wait for the person's Approve as well:
 *  - anything that reaches a credential store or keychain (SSH, cloud and git keys, the OS keychain, browser logins, password
 *    managers, the sign-ins of Escanor and of the AI tools themselves, the process environments that hold Escanor's own tokens);
 *  - changing files outside the person's own folders (home, the chat's folder, the temp folders);
 *  - changing what starts by itself (shell startup files, autostart, user services, scheduled jobs, the registry's Run keys);
 *  - deleting a folder (even though a copy would be kept), throwing away unsaved git work;
 *  - changing the computer itself: power, services, users, the registry, administrator rights.
 * A hold goes to the phone, the website and the desktop like any other (riskHold.ts); it never runs on anything but their Approve.
 *
 * What this is NOT (known limits, on purpose): it reads the text of a command, so a program that builds a path at run time
 * (`python -c`, `node -e` with a name put together in code), a link that already points at a credential folder, `curl -o`/`tar -C`/
 * `git clone` into a place outside home, `docker run -v /:/host` and `env`/`printenv` are not caught here. It is a layer on top of
 * the safety layer, not a sandbox.
 */
import { homedir, tmpdir } from 'node:os';
import { posix, win32 } from 'node:path';
import { riskAndPlan, RISK_WHY, type Risk } from '../../shared/src/risk.ts';
import { commandOf } from '../../shared/src/safety.ts';
import { parseShell, programName, type Command } from '../../shared/src/shellParse.ts';

export type PersonalCtx = {
  home: string;
  /** Where the command runs from. */
  cwd: string;
  platform: NodeJS.Platform;
  tmp?: string[];
  /** The folders the person chose to work in (the chat's folder, the workspace): changes inside them are ordinary work. */
  roots?: string[];
};

export const PERSONAL_ROOTS_ENV = 'ESCANOR_PERSONAL_ROOTS';

export const defaultCtx = (cwd: string, roots: string[] = [], env: NodeJS.ProcessEnv = process.env): PersonalCtx => {
  let more: string[] = [];
  try {
    const j = JSON.parse(env[PERSONAL_ROOTS_ENV] ?? '[]') as unknown;
    if (Array.isArray(j)) more = j.filter((x): x is string => typeof x === 'string' && x.length > 0).slice(0, 10);
  } catch {
    // none
  }
  return { home: homedir(), cwd, platform: process.platform, tmp: [tmpdir()], roots: [...roots, ...more].filter(Boolean) };
};

const risk = (kind: Risk['kind'], extra = ''): Risk => ({ kind, why: extra ? `${RISK_WHY[kind]} (${extra})` : RISK_WHY[kind] });

// ------------------------------------------------------------------------------------------------- paths

const win = (c: PersonalCtx) => c.platform === 'win32';
const lowerCase = (c: PersonalCtx) => win(c) || c.platform === 'darwin';

/** The folder variables the spellings `%X%`, `$env:X`, `$X` and `${X}` stand for. */
function knownVars(c: PersonalCtx): Record<string, string> {
  const h = c.home.replace(/\\/g, '/');
  return {
    HOME: h,
    USERPROFILE: h,
    LOCALAPPDATA: `${h}/AppData/Local`,
    APPDATA: `${h}/AppData/Roaming`,
    PROGRAMDATA: 'c:/programdata',
    PROGRAMFILES: 'c:/program files',
    SYSTEMROOT: 'c:/windows',
    WINDIR: 'c:/windows',
    SYSTEMDRIVE: 'c:',
    TEMP: `${h}/AppData/Local/Temp`,
    TMP: `${h}/AppData/Local/Temp`,
    TMPDIR: '/tmp',
    XDG_CONFIG_HOME: `${h}/.config`,
    XDG_DATA_HOME: `${h}/.local/share`,
  };
}

/** Fills in `~`, the folder variables and the variables set earlier in the same line. null: a value that is not known. */
function expand(raw: string, c: PersonalCtx, vars: Record<string, string>): string | null {
  const all = { ...knownVars(c), ...vars };
  let p = raw.trim();
  if (!p || p.includes('$(') || p.includes('`')) return null;
  p = p.replace(/^~(?=$|[\\/])/, all.HOME!);
  if (/^~[^\\/]/.test(p)) return null; // another user's home
  let unknown = false;
  p = p.replace(/%([A-Za-z_][A-Za-z0-9_]*)%|\$env:([A-Za-z_][A-Za-z0-9_]*)|\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)/g, (_m, a, b, d, e) => {
    const name = String(a ?? b ?? d ?? e);
    const v = all[name] ?? all[name.toUpperCase()];
    if (v === undefined) {
      unknown = true;
      return '';
    }
    return v;
  });
  return unknown ? null : p;
}

/** A path in one spelling: forward slashes, variables filled in, relative ones made absolute, `..` resolved, lower case on Windows/macOS. */
export function resolvePath(raw: string, c: PersonalCtx, base: string | null = c.cwd, vars: Record<string, string> = {}): string | null {
  let p = expand(raw, c, vars);
  if (p === null) return null;
  // Git Bash and WSL spell C:\Users as /c/Users and /mnt/c/Users.
  if (win(c)) p = p.replace(/^\/mnt\/([a-zA-Z])(?=\/|$)/, '$1:').replace(/^\/([a-zA-Z])(?=\/|$)/, '$1:');
  const n = win(c) ? win32 : posix;
  if (!n.isAbsolute(p) && base === null) return null;
  const abs = n.isAbsolute(p) ? n.normalize(p) : n.resolve(base!, p);
  const slash = abs.replace(/\\/g, '/').replace(/\/+$/, '');
  return lowerCase(c) ? slash.toLowerCase() : slash;
}

const norm = (p: string, c: PersonalCtx): string => {
  const s = p.replace(/\\/g, '/').replace(/\/+$/, '');
  return lowerCase(c) ? s.toLowerCase() : s;
};

const inside = (p: string, dir: string): boolean => p === dir || p.startsWith(`${dir}/`);

const TEMP = ['/tmp', '/var/tmp', '/private/tmp', '/dev/shm', '/dev/null', '/dev/stdout', '/dev/stderr', '/dev/stdin'];

function inHomeOrTemp(p: string, c: PersonalCtx): boolean {
  if (inside(p, norm(c.home, c))) return true;
  for (const t of [...TEMP, ...(c.tmp ?? [])]) if (inside(p, norm(t, c))) return true;
  for (const r of c.roots ?? []) if (r && inside(p, norm(r, c))) return true;
  return false;
}

const inRoots = (p: string, c: PersonalCtx): boolean => (c.roots ?? []).some((r) => r && inside(p, norm(r, c)));

// A credential store or keychain, wherever it is (matched on the lower-case path with forward slashes).
const STRONG_CREDENTIAL_PATHS: RegExp[] = [
  /(^|\/)\.ssh(\/|$)/,
  /(^|\/)\.aws(\/|$)/,
  /(^|\/)\.gnupg(\/|$)/,
  /(^|\/)\.kube\/config/,
  /(^|\/)\.docker\/config\.json$/,
  /(^|\/)\.config\/(gcloud|gh|hub|doctl|op|rclone|pulumi|heroku)(\/|$)/,
  /(^|\/)\.azure(\/|$)/,
  /(^|\/)\.(git-credentials|pgpass|s3cfg|vault-token)$/,
  /(^|\/)\.terraform\.d\/credentials/,
  /(^|\/)\.password-store(\/|$)/,
  /(^|\/)\.local\/share\/(keyrings|kwalletd|opencode)(\/|$)/,
  /(^|\/)\.config\/(keepassxc|bitwarden|1password)(\/|$)/,
  /(^|\/)library\/keychains(\/|$)/,
  /(^|\/)library\/(application support\/(google\/chrome|firefox|microsoft edge|bravesoftware|com\.apple\.sharedfilelist)|cookies|safari)(\/|$)/,
  /(^|\/)appdata\/(local|roaming)\/(google\/chrome|microsoft\/edge|mozilla\/firefox|bravesoftware|microsoft\/credentials|microsoft\/vault|microsoft\/protect)(\/|$)/,
  /(^|\/)\.config\/(google-chrome|chromium|microsoft-edge|brave-browser|bravesoftware)(\/|$)/,
  /(^|\/)\.mozilla\/firefox(\/|$)/,
  /(^|\/)\.snap\/.*\/(chromium|firefox)(\/|$)/,
  /(^|\/)(id_rsa|id_dsa|id_ecdsa|id_ed25519)(\.pub)?$/,
  /(^|\/)windows\/system32\/config\/(sam|security|system|software)$/,
  /(^|\/)etc\/(shadow|gshadow|sudoers)(\.d(\/|$)|$)/,
  // Escanor's own sign-ins and the AI tools' own: whoever holds them is the person
  /(^|\/)\.config\/@?escanor(\/|$)/,
  /(^|\/)(library\/application support|appdata\/(roaming|local))\/@?escanor(\/|$)/,
  /(^|\/)\.escanor(\/|$)/,
  // Only the sign-in file of an AI account counts, not the folder around it: notes, settings.json and projects/ in a profile are ordinary files.
  /(^|\/)\.claude-profiles\/[^/]+\/\.credentials\.json$/,
  /(^|\/)\.claude\/\.credentials\.json$/,
  /(^|\/)\.codex\/auth\.json$/,
  /(^|\/)\.gemini\/oauth_creds\.json$/,
  /(^|\/)\.qwen\/oauth_creds\.json$/,
  // the environment of a running program (the agent's own holds Escanor's token)
  /(^|\/)proc\/[^/]*\/environ$/,
];

// Names that mean a credential file only outside the folder the person is working in (a project may keep its own .npmrc or test keys).
const WEAK_CREDENTIAL_PATHS: RegExp[] = [
  /(^|\/)\.(netrc|_netrc|pypirc|npmrc|yarnrc|boto|terraformrc)$/,
  /(^|\/)(login data|cookies|web data|key[34]\.db|logins\.json|cert9\.db|local state)$/,
  /\.(pem|p12|pfx|keystore|jks|kdbx|ppk)$/,
];

export function isCredentialPath(p: string, c?: PersonalCtx): boolean {
  const l = p.toLowerCase();
  if (STRONG_CREDENTIAL_PATHS.some((r) => r.test(l))) return true;
  if (c && inRoots(l, c)) return false;
  return WEAK_CREDENTIAL_PATHS.some((r) => r.test(l));
}

/** Names directly under home that a wildcard must not be allowed to reach unseen. */
const SENSITIVE_HOME_NAMES = ['.ssh', '.aws', '.gnupg', '.kube', '.docker', '.azure', '.config', '.local', '.password-store', '.netrc', '.git-credentials', '.npmrc', '.mozilla', '.claude', '.claude-profiles', '.codex', '.gemini', '.qwen', '.escanor', 'library', 'appdata'];

const globToRegExp = (g: string): RegExp => new RegExp(`^${g.replace(/[.+^${}()|\\]/g, '\\$&').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/\[!/g, '[^')}$`, 'i');

/** A word with `*`, `?` or `[` right under home that could stand for a sensitive folder (`~/.s*`, `~/.[a-z]sh`). */
function globReachesSensitive(p: string, c: PersonalCtx): boolean {
  const home = norm(c.home, c);
  const rest = p.startsWith(`${home}/`) ? p.slice(home.length + 1) : null;
  if (rest === null) return false;
  const first = rest.split('/')[0]!;
  if (!/[*?[]/.test(first) || first.replace(/[*?[\]]/g, '').length === 0) return false; // no wildcard, or nothing but wildcards (`~/*` is every ordinary file)
  let re: RegExp;
  try {
    re = globToRegExp(first);
  } catch {
    return true; // a pattern that cannot be read is held
  }
  return SENSITIVE_HOME_NAMES.some((n) => re.test(n) && (!n.startsWith('.') || first.startsWith('.') || first.startsWith('[.')));
}

// Places that run something by themselves: a write there is "starting something at login", wherever it is.
const STARTUP_PATHS: RegExp[] = [
  /(^|\/)\.(bashrc|bash_profile|bash_login|bash_logout|profile|zshrc|zprofile|zshenv|zlogin|xprofile|xinitrc|xsession)$/,
  /(^|\/)\.config\/(fish\/config\.fish|autostart\/|systemd\/user\/|environment\.d\/)/,
  /(^|\/)library\/(launchagents|launchdaemons)\//,
  /(^|\/)appdata\/roaming\/microsoft\/windows\/start menu\/programs\/startup\//,
  /(^|\/)programdata\/microsoft\/windows\/start menu\/programs\/startup\//,
  /(^|\/)\.local\/share\/applications\//,
];

// ------------------------------------------------------------------------------------------------- programs

/** Programs that read or hand out stored credentials, whatever their arguments. */
const KEYCHAIN_PROGRAMS = new Set(['cmdkey', 'vaultcmd', 'secret-tool', 'kwalletcli', 'kwallet-query', 'keyctl', 'pass', 'gopass', 'bw', 'op', 'lpass', 'gnome-keyring-daemon', 'credential-manager', 'keepassxc-cli', 'gh-token']);
const SECURITY_SUBCOMMANDS = /^(find-generic-password|find-internet-password|find-certificate|find-identity|dump-keychain|export|import|delete-generic-password|delete-internet-password|delete-keychain|unlock-keychain|set-.*|add-.*|authorizationdb|list-keychains)$/;
const GIT_CREDENTIAL = /^credential(-.*)?$/;


/** Programs that only show names or sizes: `ls ~/.ssh` lists what is there, it reads no secret. Their redirects still count. */
const NAME_ONLY_PROGRAMS = new Set(['ls', 'dir', 'tree', 'stat', 'du', 'vdir', 'exa', 'eza', 'lsd', 'readlink', 'realpath', 'basename', 'dirname', 'get-childitem', 'gci']);
const SEARCH_PROGRAMS = new Set(['grep', 'egrep', 'fgrep', 'zgrep', 'rg', 'ag', 'ack']);
/** Options whose next word is a pattern, a glob or a message, never a place. */
const PATTERN_OPTIONS: Record<string, RegExp> = {
  grep: /^(-e|--regexp|--include|--exclude|--exclude-dir|--include-dir)$/,
  rg: /^(-e|--regexp|-g|--glob|--iglob|-t|-T|--type|--type-not)$/,
  git: /^(-e|-S|-G|--grep|-m|--message|--author|--committer|--pickaxe-regex)$/,
};

/**
 * The words of a command that are places. A search pattern (`git grep -e "claude-profiles"`, `grep -rn "\.ssh" src`), a commit
 * message or a name handed to a program that only lists is a string, not a file being opened.
 */
function placesOf(prog: string, cmd: Cmd, isSwitchWord: (a: string) => boolean, nested: boolean): string[] {
  if (NAME_ONLY_PROGRAMS.has(prog) && !nested) return cmd.redirects.filter((r) => r.target).map((r) => r.target!);
  const searchLike = SEARCH_PROGRAMS.has(prog) || (prog === 'git' && cmd.words.slice(1).some((a) => !isSwitchWord(a) && /^(grep|log|commit|tag|notes|shortlog)$/.test(a)));
  if (!searchLike && prog !== 'git') return placeWords(cmd);
  const opts = prog === 'git' ? PATTERN_OPTIONS.git! : prog === 'rg' ? PATTERN_OPTIONS.rg! : PATTERN_OPTIONS.grep!;
  const out: string[] = [];
  const args = cmd.words.slice(1);
  let patternSeen = prog === 'git';
  for (let i = 0; i < args.length; i++) {
    const w = args[i]!;
    if (w === '-f' || w === '--file') {
      patternSeen = true; // a file of patterns: the file is a place
      if (args[i + 1] !== undefined) out.push(args[++i]!);
      continue;
    }
    if (opts.test(w)) {
      patternSeen = true;
      i++; // its value
      continue;
    }
    if (isSwitchWord(w)) {
      // --regexp=x, --grep=x, -ex: the part after `=` is a pattern; any other `--file=/x` still names a place
      const eq = w.indexOf('=');
      if (eq > 0 && !opts.test(w.slice(0, eq)) && /^--/.test(w)) out.push(w.slice(eq + 1));
      continue;
    }
    if (!patternSeen) {
      patternSeen = true; // the first plain word of grep/rg is the pattern
      continue;
    }
    out.push(w);
  }
  for (const r of cmd.redirects) if (r.target) out.push(r.target);
  return out;
}

const SHELL_RC = /(^|\/)\.(bashrc|bash_profile|bash_login|bash_logout|profile|zshrc|zprofile|zshenv|zlogin)$/;
/** One line a person adds to their shell startup file to make a shortcut: `alias x=...`, nothing that runs a command. */
const SHORTCUT_LINE = /^\s*(?:(?:\$|\d*)\s*[aic]\\?\s*)?alias\s+[A-Za-z0-9_.-]+=[^\n;|&`]*$/;
const hasSubstitution = (w: string) => /\$\(|`|<\(/.test(w);

const POWER = new Set(['shutdown', 'reboot', 'halt', 'poweroff', 'init', 'telinit', 'logoff', 'restart-computer', 'stop-computer']);
const ADMIN = new Set(['sudo', 'su', 'doas', 'runas', 'pkexec', 'gsudo']);
const ACCOUNTS = new Set(['useradd', 'userdel', 'usermod', 'passwd', 'chpasswd', 'adduser', 'deluser', 'visudo', 'dscl', 'sysadminctl', 'groupadd', 'groupdel', 'net', 'net1', 'new-localuser', 'remove-localuser', 'set-localuser']);
const SYSTEM_TOOLS = new Set(['diskpart', 'bcdedit', 'netsh', 'sc', 'sc.exe', 'schtasks', 'schtasks.exe', 'wmic', 'fdisk', 'parted', 'mkfs', 'format', 'format.com', 'launchctl', 'csrutil', 'spctl', 'tmutil', 'defaults', 'scutil', 'networksetup', 'pmset', 'systemsetup', 'sysctl', 'modprobe', 'rmmod', 'insmod', 'update-grub', 'grub-install', 'efibootmgr', 'setx', 'new-service', 'set-service', 'remove-service', 'stop-service', 'set-executionpolicy', 'disable-windowsoptionalfeature', 'set-mppreference', 'add-mppreference', 'register-scheduledtask', 'new-itemproperty', 'set-itemproperty', 'remove-itemproperty', 'disable-netfirewallrule', 'set-netfirewallprofile', 'disable-netfirewallprofile', 'osascript']);
const REGISTRY = new Set(['reg', 'reg.exe', 'regedit', 'regedit.exe']);

/** Programs that put something at (or take something from) a path they are given: where files outside home matter. */
const WRITERS = new Set(['rm', 'rmdir', 'unlink', 'shred', 'mv', 'cp', 'tee', 'touch', 'mkdir', 'chmod', 'chown', 'chgrp', 'ln', 'install', 'truncate', 'rsync', 'dd', 'sed', 'perl', 'ed', 'patch', 'rimraf', 'del', 'erase', 'rd', 'move', 'copy', 'xcopy', 'robocopy', 'remove-item', 'move-item', 'copy-item', 'set-content', 'add-content', 'out-file', 'new-item', 'rename-item', 'ren', 'mklink', 'icacls', 'takeown', 'attrib', 'gc']);

/** Programs whose first plain word is a script or expression, not a place. */
const EXPRESSION_PROGRAMS = new Set(['sed', 'perl', 'ed', 'patch', 'dd', 'truncate']);

const SERVICE_VERBS = /^(disable|mask|stop|kill|poweroff|reboot|halt|suspend|hibernate|isolate|set-default|daemon-reload|edit|link|enable|unmask|remove|delete|bootout|unload)$/;
const USER_SERVICE_VERBS = /^(enable|link|mask|edit|disable)$/;
const CD_PROGRAMS = new Set(['cd', 'pushd', 'chdir', 'set-location', 'sl', 'push-location']);

/** What the checks need of a command: its words (as the program receives them) and where it redirects output. */
type Cmd = { words: string[]; redirects: { op: string; target: string | null }[] };

const fromParsed = (cmd: Command): Cmd => ({ words: cmd.words.map((w) => w.text), redirects: cmd.redirects.map((r) => ({ op: r.op, target: r.target ? r.target.text : null })) });

/** cmd.exe and PowerShell are not bash: a backslash is a path separator, not an escape. Read words with double quotes only. */
function windowsCommands(src: string): { commands: Cmd[]; unterminated: boolean } {
  const commands: Cmd[] = [];
  let words: string[] = [];
  let redirects: Cmd['redirects'] = [];
  let cur = '';
  let has = false;
  let quote = false;
  let pendingRedirect: string | null = null;
  const endWord = () => {
    if (!has) return;
    if (pendingRedirect !== null) redirects.push({ op: pendingRedirect, target: cur });
    else words.push(cur);
    pendingRedirect = null;
    cur = '';
    has = false;
  };
  const endCmd = () => {
    endWord();
    if (words.length || redirects.length) commands.push({ words, redirects });
    words = [];
    redirects = [];
  };
  for (let i = 0; i < src.length; i++) {
    const ch = src[i]!;
    if (ch === '"') {
      quote = !quote;
      has = true;
    } else if (quote) {
      cur += ch;
      has = true;
    } else if (/\s/.test(ch)) endWord();
    else if (ch === '&' || ch === '|' || ch === ';' || ch === '\n') {
      endCmd();
      if ((ch === '&' || ch === '|') && src[i + 1] === ch) i++;
    } else if (ch === '>') {
      endWord();
      const op = src[i + 1] === '>' ? '>>' : '>';
      if (op === '>>') i++;
      pendingRedirect = op;
    } else if (ch === "'" && !has) {
      const j = src.indexOf("'", i + 1);
      if (j < 0) return { commands, unterminated: true };
      cur += src.slice(i + 1, j);
      has = true;
      i = j;
    } else {
      cur += ch;
      has = true;
    }
  }
  endCmd();
  return { commands, unterminated: quote };
}

/** Every thing a command refers to as a place: its words and what it redirects into/out of. */
function placeWords(cmd: Cmd): string[] {
  const out: string[] = [];
  for (const w of cmd.words.slice(1)) {
    out.push(w);
    // --file=/x, of=/x, if=/x: the path after the first `=`
    const eq = w.indexOf('=');
    if (eq > 0 && eq < w.length - 1) out.push(w.slice(eq + 1));
  }
  for (const r of cmd.redirects) if (r.target) out.push(r.target);
  return out;
}

// ------------------------------------------------------------------------------------------------- the checks

/** The Windows forms that matter, read from the text of the line (PowerShell and cmd). */
function windowsRisk(command: string): Risk | null {
  if (/\b(?:remove-item|ri|rm|del|erase|rd|rmdir)\b[^\n|;&]*(?:-recurse|\/s\b)/i.test(command) || /\|\s*(?:remove-item|ri|del|rm)\b/i.test(command) || (/\bremove-item\b/i.test(command) && /-recurse/i.test(command))) return risk('delete-folder');
  if (/\b(?:format(?:\.com)?\s+[a-z]:|diskpart|bcdedit|cipher\s+\/w|vssadmin\s+delete|wbadmin\s+delete|wevtutil\s+cl)\b/i.test(command)) return risk('disk');
  if (/\b(?:cmdkey|vaultcmd|get-storedcredential|passwordvault|credentialmanager|protecteddata)\b|\[windows\.security\.credentials/i.test(command) || /microsoft[\\/](?:credentials|vault|protect)/i.test(command)) return risk('credentials');
  if (
    /\b(?:reg(?:\.exe)?\s+(?:delete|add|import|load|save|export)|regedit|sc(?:\.exe)?\s+(?:delete|config|create|stop)|schtasks(?:\.exe)?\s+\/(?:create|delete|change)|set-executionpolicy|new-service|remove-service|stop-service|set-service|stop-computer|restart-computer|register-scheduledtask|new-itemproperty|set-itemproperty|remove-itemproperty|disable-netfirewall\w*|set-netfirewall\w*|net1?\s+user|netsh\s+(?:advfirewall|interface)|icacls|takeown|invoke-expression|\biex\b)\b/i.test(command) ||
    /start-process\b[^\n]*-verb\s+runas/i.test(command) ||
    /\bpowershell(?:\.exe)?\b[^\n]*\s-(?:enc|encodedcommand|e)\b/i.test(command) ||
    /\bosascript\b[^\n]*administrator privileges/i.test(command)
  )
    return risk('system-change');
  return null;
}


/** Does this command only add `alias` lines to a shell startup file (every other word is an option or that file)? */
function shortcutOnlyEdit(cmd: Cmd, at: (w: string) => string | null, isSwitch: (a: string) => boolean): boolean {
  const prog = programName(cmd.words[0]!.replace(/\\/g, '/')).toLowerCase();
  if (!['sed', 'echo', 'printf', 'tee'].includes(prog)) return false;
  const texts = cmd.words.slice(1).filter((w) => !isSwitch(w) && !(at(w) !== null && SHELL_RC.test(at(w)!)));
  if (prog !== 'tee' && texts.length === 0) return false;
  return texts.every((w) => !hasSubstitution(w) && SHORTCUT_LINE.test(w));
}

/** A `find` that deletes: not seen as a folder delete by the safety plan, but it empties one. */
const FIND_DELETE = /\bfind\b[^\n|;&]*(?:-delete\b|-exec(?:dir)?\s+(?:\S*\/)?(?:rm|rmdir|shred|unlink)\b)/;

type Shell = 'posix' | 'windows';

const POSIX_SHELLS = new Set(['bash', 'sh', 'zsh', 'dash', 'ksh', 'fish', 'ash', 'busybox']);

/** The line a shell program is handed as text, if it is: `sh -c "..."`, `eval ...`, `powershell -Command ...`, `cmd /c ...`. */
function innerCommand(prog: string, args: string[]): { text: string; shell?: Shell } | null {
  if (POSIX_SHELLS.has(prog)) {
    const i = args.findIndex((a) => /^-[a-z]*c[a-z]*$/.test(a));
    return i >= 0 && args[i + 1] !== undefined ? { text: args[i + 1]! } : null;
  }
  if (prog === 'eval') return args.length ? { text: args.join(' ') } : null;
  if (prog === 'powershell' || prog === 'pwsh') {
    const i = args.findIndex((a) => /^-(c|command)$/i.test(a));
    return i >= 0 && args[i + 1] !== undefined ? { text: args.slice(i + 1).join(' '), shell: 'windows' } : null;
  }
  if (prog === 'cmd') {
    const i = args.findIndex((a) => /^\/[ck]$/i.test(a));
    return i >= 0 && args[i + 1] !== undefined ? { text: args.slice(i + 1).join(' '), shell: 'windows' } : null;
  }
  return null;
}

function commandRisk(command: string, c: PersonalCtx, shell: Shell): Risk | null {
  if (command.length > 100_000) return risk('unreadable');
  let list: Cmd[];
  if (shell === 'windows') {
    const w = windowsCommands(command);
    if (w.unterminated) return risk('unreadable');
    list = w.commands;
    // Unquoted spaces split a Windows path into words: the whole line is also read for the places that hold logins.
    if (isCredentialPath(expandLine(command, c).replace(/\\/g, '/'))) return risk('credentials');
  } else {
    const parsed = parseShell(command);
    if (parsed.unterminated || parsed.tooDeep) return risk('unreadable');
    list = parsed.commands.map(fromParsed);
  }
  // A line with `$(...)`, backticks or `<(...)` hands one command's output to another: a listing there is not just a listing.
  const nestedLine = hasSubstitution(command);
  let base: string | null = c.cwd;
  const vars: Record<string, string> = {};
  const isSwitch = (a: string) => a.startsWith('-') || (shell === 'windows' && /^\/[a-z?]{1,3}(:.*)?$/i.test(a));
  const at = (w: string): string | null => resolvePath(w, c, base, vars);
  /** A word that names credentials, directly or through a wildcard. */
  const credentialWord = (w: string): boolean => {
    const p = at(w);
    if (p === null) return false;
    if (isCredentialPath(p, c)) return true;
    return /[*?[]/.test(w) && globReachesSensitive(p, c);
  };
  for (const cmd of list) {
    // NAME=value assignments (alone, or in front of a command) are remembered so `D=~/.ssh; cat $D/id_rsa` is read as it will run
    let skip = 0;
    for (const w of cmd.words) {
      const m = /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/.exec(w);
      if (!m) break;
      const v = expand(m[2]!, c, vars);
      if (v !== null) vars[m[1]!] = v.replace(/\\/g, '/');
      skip++;
    }
    const words = cmd.words.slice(skip);
    if (words.length === 0) {
      for (const r of cmd.redirects) if (r.target) {
        const p = at(r.target);
        if (p && isCredentialPath(p, c)) return risk('credentials');
        if (p && !inHomeOrTemp(p, c)) return risk('outside-home', r.target);
      }
      continue;
    }
    const cmdx: Cmd = { words, redirects: cmd.redirects };
    const prog = programName(words[0]!.replace(/\\/g, '/')).toLowerCase().replace(/\.(exe|cmd|bat|com)$/, '');
    const args = words.slice(1);
    const flagless = args.filter((a) => !isSwitch(a));
    if (CD_PROGRAMS.has(prog)) {
      const t = flagless[0];
      const p = t === undefined ? norm(c.home, c) : at(t);
      if (p && isCredentialPath(p, c)) return risk('credentials');
      base = p; // null (not known) from here on: a relative path is not known either
      continue;
    }
    if (prog === 'popd') {
      base = null;
      continue;
    }
    // --- a command given to another shell as text (`bash -c "..."`, `eval`, `powershell -Command`, `cmd /c`): read as the line it is
    const inner = innerCommand(prog, args);
    if (inner) {
      const r = commandRisk(inner.text, { ...c, cwd: base ?? c.cwd }, inner.shell ?? shell);
      if (r) return r;
    }
    // --- a credential store is never read or written by an AI without the person's OK
    if (KEYCHAIN_PROGRAMS.has(prog)) return risk('credentials', prog);
    if (prog === 'security' && flagless.some((a) => SECURITY_SUBCOMMANDS.test(a))) return risk('credentials', 'the macOS keychain');
    if (prog === 'git' && flagless.some((a) => GIT_CREDENTIAL.test(a))) return risk('credentials', "git's saved logins");
    if (prog === 'gpg' && args.some((a) => /^--(export-secret|export-ownertrust|delete-secret)/.test(a))) return risk('credentials', 'GPG secret keys');
    if (prog === 'ps' && args.some((a) => /^[a-z]*e[a-z]*$/i.test(a))) return risk('credentials', "the programs' environments");
    for (const w of placesOf(prog, cmdx, isSwitch, nestedLine)) if (credentialWord(w)) return risk('credentials');
    // --- the computer itself
    if (ADMIN.has(prog)) return risk('system-change', 'administrator rights');
    if (POWER.has(prog)) return risk('system-change', 'power');
    if (REGISTRY.has(prog) || SYSTEM_TOOLS.has(prog) || SYSTEM_TOOLS.has(`${prog}.exe`)) {
      // read-only forms are fine: `defaults read`, `sysctl -n`, `netsh ... show`, `sc query`, `schtasks /query`, `reg query`
      const verb = (flagless[0] ?? '').toLowerCase();
      const quiet =
        /^(read|read-type|list|print|query|show|get|print-disabled|status|find|export-no)$/.test(verb) ||
        args.some((a) => /^\/query$/i.test(a)) ||
        (prog === 'sysctl' && !args.some((a) => a.includes('=') || a === '-w')) ||
        (prog === 'pmset' && verb === '-g') ||
        (prog === 'osascript' && !args.some((a) => /administrator privileges/i.test(a)));
      if (!quiet) return risk('system-change', prog);
    }
    if (ACCOUNTS.has(prog)) {
      if (prog === 'net' || prog === 'net1') {
        if (/^(user|localgroup|accounts|share|use|stop|start)$/i.test(flagless[0] ?? '') && flagless.length > 1) return risk('system-change', 'accounts');
      } else return risk('system-change', 'accounts');
    }
    if (prog === 'systemctl' || prog === 'service' || prog === 'rc-service' || prog === 'chkconfig') {
      const user = args.includes('--user');
      if (flagless.some((a) => (user ? USER_SERVICE_VERBS : SERVICE_VERBS).test(a))) return risk('system-change', user ? 'what starts at login' : 'services');
    }
    if (prog === 'crontab' && !args.includes('-l')) return risk('system-change', 'scheduled jobs');
    if (prog === 'at' || prog === 'batch') return risk('system-change', 'scheduled jobs');
    if (prog === 'chmod' || prog === 'chown' || prog === 'chgrp') {
      if (args.some((a) => /^-[a-zA-Z]*R/.test(a) || a === '--recursive')) {
        const targets = flagless.slice(1);
        if (targets.some((t) => { const p = at(t); return p === null || !inHomeOrTemp(p, c) || p === norm(c.home, c); })) return risk('system-change', 'permissions of many files');
      }
    }
    // --- changing files outside the person's own folders, or what starts by itself
    const writes: string[] = [];
    if (WRITERS.has(prog)) for (const a of placeWords(cmdx)) if (!isSwitch(a) || a.includes('=')) writes.push(a);
    for (const r of cmd.redirects) if (r.target && />/.test(r.op)) writes.push(r.target);
    for (const t of writes) {
      const p = at(t);
      const placeLike = /^(?:[A-Za-z]:|[\\/]|~|\.\.?[\\/]|\$|%)/.test(t) || t.includes('/') || t.includes('\\');
      if (p === null) {
        // a relative name after a folder change that is not known: where it lands is not known
        if (base === null && !placeLike && !(EXPRESSION_PROGRAMS.has(prog))) return risk('outside-home', 'a folder that could not be worked out');
        continue;
      }
      if (STARTUP_PATHS.some((r) => r.test(p))) {
        // Adding a shortcut (an alias) to a shell startup file is ordinary setup, not changing what runs at login.
        if (SHELL_RC.test(p) && shortcutOnlyEdit(cmdx, at, isSwitch)) continue;
        return risk('system-change', 'what starts at login');
      }
      if (inHomeOrTemp(p, c)) continue;
      // a sed/perl/dd word that is not a path (an expression, a count) is not a place
      if (EXPRESSION_PROGRAMS.has(prog) && !placeLike) continue;
      return risk('outside-home', t);
    }
  }
  // --- strict deleting, on top of the copies the safety layer keeps
  if (FIND_DELETE.test(command)) return risk('delete-folder');
  const { plan } = riskAndPlan(command);
  if (plan.deletes.some((d) => d.recursive && !d.routine && !d.checkOnly && !d.overwrite)) return risk('delete-folder');
  if (plan.git.length > 0) return risk('discard-work');
  return windowsRisk(command);
}

/** The line with its folder variables filled in (for the whole-line check of a Windows command). */
function expandLine(line: string, c: PersonalCtx): string {
  const all = knownVars(c);
  return line
    .replace(/%([A-Za-z_][A-Za-z0-9_]*)%|\$env:([A-Za-z_][A-Za-z0-9_]*)/g, (m, a, b) => all[String(a ?? b).toUpperCase()] ?? m)
    .toLowerCase();
}

// ------------------------------------------------------------------------------------------------- file tools

const PATH_KEYS = ['file_path', 'notebook_path', 'path', 'filePath', 'target_file', 'source', 'destination', 'dest', 'src', 'directory', 'dir', 'folder', 'filename', 'file'];
const GLOB_KEYS = ['pattern', 'glob'];

/** File tools: the paths they touch (also in lists, as MCP file tools take them). */
function pathsOf(input: unknown): { paths: string[]; globs: string[] } {
  const f = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const paths: string[] = [];
  for (const k of PATH_KEYS) {
    const v = f[k];
    if (typeof v === 'string' && v) paths.push(v);
  }
  for (const v of Array.isArray(f.paths) ? f.paths : []) if (typeof v === 'string' && v) paths.push(v);
  const globs: string[] = [];
  for (const k of GLOB_KEYS) {
    const v = f[k];
    if (typeof v === 'string' && v) globs.push(v);
  }
  return { paths: paths.slice(0, 50), globs: globs.slice(0, 10) };
}

const WRITE_TOOLS = /(^|__|_|-)(write|edit|multiedit|notebookedit|create|replace|move|delete|remove|append|save|rename|copy|mkdir|patch|insert|put|upload)/i;

/** Why this tool call needs the person's OK on a personal computer, or null. Never throws: what cannot be read is held. */
export function personalRisk(toolName: string, input: unknown, c: PersonalCtx): Risk | null {
  try {
    const command = commandOf(input);
    if (command !== null) {
      // Claude's Bash tool is a POSIX shell everywhere (Git Bash on Windows); other shell tools are PowerShell or cmd on Windows.
      const shell: Shell = win(c) && !/^bash$/i.test(toolName) ? 'windows' : 'posix';
      return commandRisk(command, c, shell);
    }
    const { paths, globs: allGlobs } = pathsOf(input);
    const writes = WRITE_TOOLS.test(toolName);
    // A search tool's `pattern` is a regular expression, a text to look for: only its `glob` (which files) is a place.
    const searches = /(^|__|_|-)(grep|search)/i.test(toolName);
    const globs = searches ? allGlobs.filter((g) => (input as Record<string, unknown>).glob === g) : allGlobs;
    // A tool that lists names (LS, Glob) shows what is there, it reads no file.
    if (!writes && /^(ls|glob|list|listdir|list_dir|list_directory)$/i.test(toolName.replace(/^.*__/, ''))) return null;
    for (const raw of paths) {
      const p = resolvePath(raw, c);
      if (p === null) {
        if (writes) return risk('outside-home', raw);
        continue;
      }
      if (isCredentialPath(p, c)) return risk('credentials');
      if (/[*?[]/.test(raw) && globReachesSensitive(p, c)) return risk('credentials');
      if (writes) {
        if (STARTUP_PATHS.some((r) => r.test(p))) return risk('system-change', 'what starts at login');
        if (!inHomeOrTemp(p, c)) return risk('outside-home', raw);
      }
    }
    // a search pattern may be a whole path (`/home/u/.ssh/*`) or sit under the folder named in `path`
    const f = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
    for (const g of globs) {
      const root = typeof f.path === 'string' && f.path ? f.path : c.cwd;
      for (const raw of [g, `${root.replace(/[\\/]+$/, '')}/${g}`]) {
        const p = resolvePath(raw, c);
        if (p !== null && (isCredentialPath(p, c) || globReachesSensitive(p, c))) return risk('credentials');
      }
    }
    return null;
  } catch {
    return risk('unreadable');
  }
}

/** The switches a personal computer always has on, whatever the environment says. */
export function personalEnvOverrides(): Record<string, string> {
  return { ESCANOR_RISK_HOLDS: '1', ESCANOR_SAFETY: '1', CHAT_KEY_SCRUB: '1', SECRET_PUSH_SCAN: '1' };
}
