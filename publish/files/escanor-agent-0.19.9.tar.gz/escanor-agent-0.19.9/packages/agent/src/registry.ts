import { copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import type { EffortLevel, PermissionMode } from '@remote-harness/shared';
import type { CutOff } from './autoResume.js';

export type RegistryEntry = {
  sessionId: string;
  cwd: string;
  title: string;
  createdAt: string;
  accountId: string;
  /** 'terminal' = a Claude Code session started outside the agent and imported by TerminalSessionSync. */
  source?: 'terminal' | 'desktop';
  /** The last prompt or reply (sessionPreview.ts), shown in the session list. */
  preview?: { role: 'prompt' | 'reply'; text: string };
  /** Last transcript message the hub has, so a session continued in the terminal only sends what is new. */
  syncedUuid?: string;
  /** Transcript mtime at the last sync; an unchanged file is not re-read. */
  syncedMtime?: number;
  /** What the person last chose for this chat. A resumed chat starts with these instead of the defaults. */
  permissionMode?: PermissionMode;
  model?: string;
  effort?: EffortLevel | null;
  /** An isolated chat (HubUserInput.isolated): it stays so when resumed. */
  isolated?: true;
  /** WATCHLIST (writeRepos.ts): the only repositories this chat may change on a remote; kept so a resumed chat keeps the limit. */
  writeRepos?: string[];
  /** When the chat last finished a turn (or started one), for "continue the recent chat" and "put away the oldest". */
  lastActiveAt?: string;
  /** How its last turn ended. Only a chat whose last turn went fine (or was cut off by Claude's usage limit) is continued. */
  lastOutcome?: 'ok' | 'error' | 'interrupted' | 'rate_limited';
  /** Put away to keep this machine under its open-chat cap: not continued automatically, still resumable by a message. */
  archivedAt?: string;
  /** Context use after its last turn, in percent, and turns since it was last compacted (chatPolicy.needsCompaction). */
  contextPct?: number;
  turnsSinceCompact?: number;
  /** A fix done on this computer in this chat (fixTests.ts): kept here so it is picked up again after the agent restarts. */
  fix?: FixRecord;
  /**
   * AUTORESUME: a turn the agent runs for this chat has not ended. Still set when the agent starts = the agent or the computer
   * stopped mid-turn, so the chat is continued by itself (autoResume.ts).
   */
  turnOpen?: true;
  /** AUTORESUME: the chat was cut off (usage limit, or the computer went offline) and goes on by itself. */
  cutOff?: CutOff;
  /** The person marked it Priority (set_priority): its waiting work goes first, and it may take one slot above the cap. */
  priority?: true;
};

export type FixRecord = {
  /** 'run': a run's chat with no fix branch (a kept run started from the phone, FLOW4 minor 4): picked up again, never tested. */
  kind?: 'run';
  /** The branch the fix is delivered on (escanor/fix-...); '' for a run. */
  branch: string;
  /** The backend conversation's id prefix from the chat's first message (AGRESUME: how Escanor finds the run to answer for). */
  conv?: string;
  startedAt: string;
  /** working: the model is on it; testing: the agent is running the tests; reported: the result row was sent for reportedHead. */
  state: 'working' | 'testing' | 'reported';
  /** A turn was asked for and has not ended: an agent restart cut it off, so it is continued on the next start. */
  turnOpen: boolean;
  /** How often it was continued after a restart (at most 3). */
  resumes: number;
  reportedHead?: string;
  /** I5: the task asked for its tests to be run (Fix & verify and up); without it the agent runs nothing. */
  verify?: boolean;
  /** I4: test runs started again after a restart cut one off (at most 2). */
  testReruns?: number;
  /** The row sent and not yet confirmed by the hub (outbox id), and the head it tested. */
  sentMid?: string;
  sentHead?: string;
};

const isEntry = (e: unknown): e is RegistryEntry =>
  typeof e === 'object' && e !== null &&
  ['sessionId', 'cwd', 'title', 'createdAt', 'accountId'].every((k) => typeof (e as Record<string, unknown>)[k] === 'string');

function readEntries(path: string): RegistryEntry[] {
  const raw = JSON.parse(readFileSync(path, 'utf-8'));
  if (!Array.isArray(raw)) throw new Error('registry is not an array');
  return raw.filter(isEntry);
}

export class SessionRegistry {
  private path: string;
  private entries = new Map<string, RegistryEntry>();

  constructor(dataDir: string) {
    mkdirSync(dataDir, { recursive: true });
    this.path = join(dataDir, 'sessions.json');
    for (const e of this.load()) this.entries.set(e.sessionId, e);
  }

  // A corrupt registry used to be treated as empty, which silently turned "resume" into a brand-new
  // conversation with no history. Fall back to the previous good copy, and never discard a file we
  // couldn't read: quarantine it so it can be recovered by hand.
  private load(): RegistryEntry[] {
    const bak = `${this.path}.bak`;
    if (existsSync(this.path)) {
      try {
        return readEntries(this.path);
      } catch (err) {
        console.error(`[registry] ${this.path} unreadable (${err instanceof Error ? err.message : err})`);
        if (existsSync(bak)) {
          try {
            const recovered = readEntries(bak);
            console.error('[registry] recovered sessions from backup');
            this.quarantine();
            return recovered;
          } catch {
            // fall through to quarantine
          }
        }
        this.quarantine();
        return [];
      }
    }
    if (existsSync(bak)) {
      try {
        return readEntries(bak);
      } catch {
        return [];
      }
    }
    return [];
  }

  private quarantine(): void {
    const dest = `${this.path}.corrupt-${Date.now()}`;
    try {
      renameSync(this.path, dest);
      console.error(`[registry] kept unreadable file as ${dest}`);
    } catch {
      // already gone
    }
  }

  all(): RegistryEntry[] {
    return [...this.entries.values()];
  }

  get(sessionId: string): RegistryEntry | undefined {
    return this.entries.get(sessionId);
  }

  upsert(entry: RegistryEntry): void {
    this.entries.set(entry.sessionId, entry);
    this.persist();
  }

  /** Change some fields of a known session (nothing happens for one this VM has no record of). */
  update(sessionId: string, patch: Partial<Omit<RegistryEntry, 'sessionId'>>): void {
    const e = this.entries.get(sessionId);
    if (!e) return;
    const next = { ...e, ...patch };
    if (JSON.stringify(next) === JSON.stringify(e)) return;
    this.entries.set(sessionId, next);
    this.persist();
  }

  /** Forget a session (a small chat deleted after use, smallSessions.ts). */
  remove(sessionId: string): void {
    if (this.entries.delete(sessionId)) this.persist();
  }

  // Write to a temp file and rename, so a crash mid-write can never leave a truncated sessions.json.
  private persist(): void {
    const tmp = `${this.path}.tmp`;
    writeFileSync(tmp, JSON.stringify(this.all(), null, 2), { mode: 0o600 });
    if (existsSync(this.path)) copyFileSync(this.path, `${this.path}.bak`);
    renameSync(tmp, this.path);
  }
}
