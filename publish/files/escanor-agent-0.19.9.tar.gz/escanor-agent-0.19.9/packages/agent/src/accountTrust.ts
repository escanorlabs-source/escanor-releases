import type { Conn } from './machineApi.js';
import { deviceKey } from './machineApi.js';

/**
 * The account's side of Jarvis: the person's Escanor account (the backend) can check a fingerprint yes for this computer, so a phone
 * does not have to be paired at the laptop, and it holds the person's access policy (when, what, and how sure Escanor must be).
 * The computer asks with its own device key (the one it already uses for its vault and git login). Nothing here throws: a failure is a
 * short reason, and the caller then falls back to what this computer knows by itself (phones paired in front of it, built-in rules).
 */

export type Auth = 'fingerprint' | 'password' | 'totp';
export type Decision = { allow: boolean; auth: Auth[]; why: string; code?: string };
export type AccountPhones = { paired: boolean; keyIds: string[]; /** The phones' public keys (not secret), for the sign-in helper; absent from an older account server. */ keys?: { keyId: string; publicKey: string; name: string }[] };
export type VerifyAnswer = { ok: true; deviceName: string } | { ok: false; why: string };

export interface AccountTrust {
  phones(): Promise<AccountPhones | null>;
  verify(body: { purpose: string; subject: string; nonce: string; machine: string; keyId?: string; signature?: string; need: Auth[]; recheck?: { password?: string; code?: string } }): Promise<VerifyAnswer | null>;
  /** May `action` be done to this computer now, and what must be shown first? Null when the account cannot be reached. */
  policy(machine: string, action: string): Promise<Decision | null>;
}

const TIMEOUT_MS = 15_000;

export class BackendTrust implements AccountTrust {
  private cache: { at: number; value: AccountPhones } | null = null;
  constructor(private c: Conn, private now: () => number = Date.now) {}

  private async post(path: string, body: unknown): Promise<Record<string, unknown> | null> {
    const key = await deviceKey(this.c);
    if (!key.ok) return null;
    try {
      const res = await (this.c.fetchImpl ?? fetch)(`${this.c.apiUrl}${path}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${key.value}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${this.c.agentVersion}` },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(TIMEOUT_MS),
      });
      if (!res.ok) return null;
      const j = (await res.json()) as unknown;
      return j && typeof j === 'object' ? (j as Record<string, unknown>) : null;
    } catch {
      return null;
    }
  }

  async phones(): Promise<AccountPhones | null> {
    if (this.cache && this.now() - this.cache.at < 30_000) return this.cache.value;
    const r = await this.post('/machines/jarvis-check', {});
    if (!r || r.ok !== true) return null;
    const keys = Array.isArray(r.keys)
      ? r.keys.slice(0, 10).flatMap((k) => {
          const o = (k && typeof k === 'object' ? k : {}) as Record<string, unknown>;
          return typeof o.key_id === 'string' && typeof o.public_key === 'string' ? [{ keyId: o.key_id, publicKey: o.public_key, name: typeof o.name === 'string' ? o.name.slice(0, 40) : 'Phone' }] : [];
        })
      : [];
    const value = { paired: r.paired === true, keyIds: Array.isArray(r.key_ids) ? r.key_ids.filter((k): k is string => typeof k === 'string') : [], ...(keys.length ? { keys } : {}) };
    this.cache = { at: this.now(), value };
    return value;
  }

  async verify(b: Parameters<AccountTrust['verify']>[0]): Promise<VerifyAnswer | null> {
    const r = await this.post('/machines/jarvis-check', { purpose: b.purpose, subject: b.subject, nonce: b.nonce, machine: b.machine, key_id: b.keyId ?? '', signature: b.signature ?? '', need: b.need, ...(b.recheck ? { recheck: b.recheck } : {}) });
    if (!r) return null;
    return r.ok === true ? { ok: true, deviceName: typeof r.device_name === 'string' ? r.device_name : 'Phone' } : { ok: false, why: typeof r.why === 'string' ? r.why : 'bad_signature' };
  }

  async policy(machine: string, action: string): Promise<Decision | null> {
    const r = await this.post('/machines/jarvis-policy', { machine, action });
    if (!r || r.ok !== true || typeof r.allow !== 'boolean') return null;
    const auth = Array.isArray(r.auth) ? r.auth.filter((a): a is Auth => a === 'fingerprint' || a === 'password' || a === 'totp') : [];
    return { allow: r.allow, auth, why: typeof r.why === 'string' ? r.why : '', ...(typeof r.code === 'string' ? { code: r.code } : {}) };
  }
}
