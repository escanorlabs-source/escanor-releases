import { REVOKED_GUIDE, REVOKED_NOTICE, REVOKED_STATUS } from './deviceMcp.js';
import { messagePreview, sessionSource } from './sessionPreview.js';
import { query as sdkQuery, type McpServerConfig, type Options, type SDKUserMessage } from '@anthropic-ai/claude-agent-sdk';
import { NO_ATTRIBUTION } from './noAttribution.js';
import { randomUUID } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { AGENT_ONLY_ROW_TYPES, isValidMcpServerName, MAX_QUEUE_ITEMS, QUEUE_PREVIEW_CHARS } from '@remote-harness/shared';
import { autonomousBlockReason } from '@remote-harness/shared/autonomy';
import { describeCommand } from '@remote-harness/shared/describe';
import { APPROVED_BY_ITSELF, autoAnswerQuestions, needsApproval } from './approvedByItself.js';
import { isSandboxAutoAllowed } from './sandboxPolicy.js';
import { isAutoAllowedMcpTool, parseMcpToolName } from './mcpApproval.js';
import { COMPUTER_MCP_NAME, computerMcpConfig } from './computerMcp.js';
import { AUTONOMY_HEADER, AUTONOMY_HEADER_SERVER, autonomousRedirect, isAutonomous, mailSendRisk, sendingNotice } from './mailHold.js';
import { screenVerdict } from './screenHold.js';
import { CONSENT_NAME, ScreenConsent } from './screenHelp.js';
import { AGENT_CHAT_ENV, childEnv } from './childEnv.js';
import { asUser, chatCwd, chatSpawner, ownUserSpawner, type ChatUsers, type SpawnDeps } from './chatUser.js';
import { PermissionBroker } from './permissions.js';
import { HOLD_HOOK_TIMEOUT_SECONDS, holdIfRisky, LEFT_FOR_YOU, leftForPersonMessage, neverAsks, riskOf, withoutHoldMark } from './riskHold.js';
import { defaultCtx, personalRisk } from './personalGuard.js';
import type { SafetyAgent } from './safetyAgent.ts';
import type { Risk } from '@remote-harness/shared/risk';
import { resolveInside, resumeCwd } from './paths.js';
import type {
  AgentMcpServerStatus,
  AgentSessionSummary,
  AgentQueueState,
  AgentToHubMessage,
  EffortLevel,
  HubQueueCommand,
  HubUserInput,
  ImageAttachment,
  ManagedMcpServer,
  PermissionDecision,
  PermissionMode,
} from '@remote-harness/shared';
import { BACKGROUND_STALE_MS, backgroundFresh, WAKE_GRACE_MS, WakeWatch } from './background.js';
import { AsyncMessageQueue } from './queue.js';
import { Verifier, verifyOn } from './verifyDone.js';
import { commandRunner, narrowRepos, remoteWriteBlockReason, reposOf } from './writeRepos.js';
import { gitRunner, pushScanVerdict } from './pushScan.js';
import type { LeakSink } from './keyLeaks.js';
import { PartialText } from './partialText.js';
import { SessionRegistry, type RegistryEntry } from './registry.js';
import { BUSY_NOTICE, type GuardState, type ResourceGuard } from './resourceGuard.js';
import { AiLimitHolds, NEAR_LIMIT_PCT, RATE_WAIT_MS, limitStatusText, parseLimitText, type LimitEntry, type LimitSource, type LimitStore } from './aiLimits.js';
import { waitingNotice, type UserFirst, type UserFirstState } from './userFirst.js';
import { loadWaiting, savable, saveWaiting, type Waiting } from './waitingStore.js';
import type { QueuedInput } from './seenInputs.js';
import { findTranscript } from './sessionAdopt.js';
import { copyTranscript, signedOutReply, signedOutText } from './signedIn.js';
import { profileConfigDir } from './accountUsage.js';
import { defaultProfile, providerForAccount, providerFromId, providerOf, readAccountKey, type ClaudeProfile } from './profiles.js';
import { cliQuery } from './cliEngine.js';
import {
  AUTO_RESUME_INPUT,
  AUTO_RESUME_PREVIEW,
  chatsToResume,
  continueText,
  errorBackoffMs,
  nextRetryAt,
  reasonOfInput,
  resumeNotice,
  TRANSIENT_ERRORS,
  UNKNOWN_RESET_MS,
  waitNotice,
  type CutOff,
} from './autoResume.js';
import {
  chatStats,
  DEFAULT_CHAT_LIMITS,
  explicitNewChat,
  isOpen,
  limitNotice,
  needsCompaction,
  pickOldestIdle,
  pickReusable,
  UsageLimits,
  type ChatLimits,
} from './chatPolicy.js';

type LiveSession = {
  queue: AsyncMessageQueue<SDKUserMessage>;
  cwd: string;
  interrupt: () => Promise<unknown>;
  setPermissionMode: (mode: PermissionMode) => Promise<void>;
  setModel: (model?: string) => Promise<void>;
  setEffort: (effort: EffortLevel | null) => Promise<void>;
  setMcpServers: (servers: Record<string, McpServerConfig>) => Promise<unknown>;
  mcpServerStatus: () => Promise<Array<{ name: string; status: string; error?: string }>>;
  close: () => void;
  /**
   * The mode the chat is in now as far as the agent is concerned (after effectiveMode). In bypass, canUseTool answers everything
   * itself. A stricter mode is set here at once, before Claude Code has taken it (see confirmed).
   */
  mode: PermissionMode;
  /**
   * The mode Claude Code has confirmed it runs in (after effectiveMode). It can lag mode, or stay behind for good when Claude Code
   * refuses a switch: while it is bypass, Claude Code never calls canUseTool, so the hook must keep checking (see guarded).
   */
  confirmed: PermissionMode;
  /** Counts mode switches, so a late confirmation of a looser switch cannot undo a stricter one made after it. */
  modeSwitches: number;
  /**
   * The mode the phone or app explicitly asked for ('auto' stays 'auto' here even where it runs as bypass), or undefined when
   * none was (the machine's default applies). Decides whether the blocklist applies.
   */
  requested: PermissionMode | undefined;
  appliedMcp: string; // the MCP config this session was last given, so an unchanged re-push is a no-op
  /** Reaches nothing outside its folder (HubUserInput.isolated): no MCP servers, and every MCP tool is refused. */
  isolated: boolean;
  /** WATCHLIST (HubUserInput.writeRepos, writeRepos.ts): the only repositories its commands may change on a remote; none: no limit. */
  writeRepos?: string[];
  /** Claude's id for the chat ('' until Claude names a new one). */
  sessionId: string;
  /** Random, per chat, known before the chat has an id: the chat's tools show it so the agent can tell which chat is calling (callerSessionId). */
  callerKey: string;
  /** The Claude account (profile) it runs on: Claude's usage limits are per account. */
  accountId: string;
  /** Context use as Claude Code reports it (percentage of the window). */
  contextUsage: () => Promise<{ percentage?: number; totalTokens?: number; maxTokens?: number }>;
  /** The person stopped the running turn (its result then counts as interrupted, not failed). */
  stopped: boolean;
  /** Claude refused a request in the running turn for the usage limit (its result then counts as rate-limited). */
  limited: boolean;
  /** AUTORESUME: the running turn's last reply was the AI service failing (server error, overloaded): it is tried again later. */
  transient: boolean;
  /** Being closed to make room: no longer counted as running. */
  closing: boolean;
  /** /compact turns the agent asked for and not yet finished (their summary and command echo are not shown as messages). */
  compacting: number;
  /**
   * Background helpers and commands it left running after its turn (Claude Code's background_tasks_changed). Claude Code wakes
   * the chat by itself when one finishes, so a chat with any is working: it is never closed to make room, and keeps the machine up.
   */
  background?: number;
  /** When it was last heard from (any SDK message): background work stops counting once it has been quiet too long. */
  heardAt?: number;
  /** Looks again once its background work would go stale (to free its slot and let the machine sleep). */
  staleTimer?: ReturnType<typeof setTimeout>;
  /** After a result with turns still counted: clears them when none of them started (see settleTurns). */
  settleTimer?: ReturnType<typeof setTimeout>;
  /** Its scheduled wake-up (ScheduleWakeup): Claude Code starts a turn by itself then, so the chat must stay open until it. */
  wake?: WakeWatch;
  /** The person's latest message into it: sent again on a signed-in account when this one turns out to be signed out. */
  lastInput?: HubUserInput;
  /** Claude Code stopped the running turn with "Not logged in" (signedIn.ts). */
  signedOut?: boolean;
  /** Run once its process is gone (the chat going on under another account). */
  onGone?: () => void;
};

/**
 * Still working after its turn ended: background helpers or commands it started (while it has been heard from within
 * BACKGROUND_STALE_MS: a crashed helper or a never-ending command must not hold a slot for ever), or a wake-up it scheduled.
 */
/** See settleTurns. */
const SETTLE_MS = 30_000;
const inBackground = (s: LiveSession, now: number) => ((s.background ?? 0) > 0 && backgroundFresh(s.heardAt, now)) || s.wake?.pending(now) === true;

/** Sent to Claude Code to shrink a long chat before it is continued (the same as typing /compact in the CLI). */
const COMPACT = '/compact';
/** Told when a chat is for a ChatGPT / Gemini / Copilot account that is no longer on this machine. */
export const ACCOUNT_REMOVED = 'That account was removed from this computer. Start a new chat.';
/** Told when no Claude account on this computer is signed in (signedIn.ts). */
export const NO_SIGNED_IN_ACCOUNT =
  'No Claude account on this computer is signed in, so this chat could not run. Open Machines, then Accounts, and sign an account in (or add one); the chat can then go on.';
/** Told when a chat moved from a signed-out account to a signed-in one. */
export const signedOutMoved = (from: string, to: string): string => `${from} is not signed in on this computer, so this chat moved to ${to} and goes on there by itself.`;
/** Told when a new chat starts on a signed-in account instead of the signed-out one it was for. */
export const signedOutUsing = (from: string, to: string): string => `${from} is not signed in on this computer, so this chat runs on ${to}.`;
const signedOutNewChats = (from: string, to: string): string => `${from} is not signed in on this computer. New chats use ${to}; send your message again to go on.`;
/** Told to a chat that waits for a free slot on this machine. */
export const QUEUED_MESSAGE =
  'Queued: this machine is already working on as many chats as it runs at once. This one starts as soon as one of them finishes.';
const HOUR_MS = 3_600_000;
/** Said for a message the person cancelled from the machine's queue (its input_ack). */
export const CANCELLED_FROM_QUEUE = 'Cancelled from the queue';
/** Said for a message that waited when its chat was stopped. */
export const STOPPED_WHILE_WAITING = 'Stopped before it started';
const NOT_WAITING = 'That message is no longer waiting: it has started, or it was cancelled.';
const CRITICAL_BUSY =
  'This computer is almost out of memory, so nothing new can start right now. It is now first in line and starts by itself as soon as there is room.';
const ALL_BUSY =
  'Every chat on this computer is busy, and a running chat is never stopped to make room. It is now first in line and starts as soon as one finishes.';
const MAX_EDIT_CHARS = 200_000;
type QueueOutcome = { ok: true; text?: string } | { ok: false; error: string };

/** Told to the person when a message is for a chat that is still open in a terminal on this machine. */
export const OPEN_IN_TERMINAL =
  'This chat is open in a terminal on this computer that cannot take messages from the phone yet (it was started before the ' +
  'phone link was set up). Send one message in that terminal and the phone can reach it from then on; or close it there and ' +
  'send this again.';

/** A Stop from the phone for a chat that runs in a terminal here, not in this agent: it can only be stopped there. */
export const STOP_IN_TERMINAL =
  'This chat is running in a terminal on this computer, not from the phone, so the phone cannot stop it. Press Esc in that terminal to stop it.';

/** Told to Claude when an isolated chat (an app builder's) tries an MCP tool. */
const ISOLATED_MCP = 'This chat works only on the app in its folder: it has no connected services. Do the work with the files here.';
const isMcpTool = (toolName: string): boolean => toolName.startsWith('mcp__');

/** Claude Code will not run in bypass mode as root (it exits), so there the agent itself says yes to everything instead. */
const runningAsRoot = (): boolean => typeof process.getuid === 'function' && process.getuid() === 0;

/** Told to Claude when the blocklist stops something in an Autonomous chat. */
const blockedMessage = (why: string): string =>
  `Escanor blocked this: ${why} An Autonomous chat never does that on its own. Find another way to reach the goal, or stop and say ` +
  'what you need: the person can do it themselves, or set this chat to "Bypass permissions".';

// A wedged session must not stop the rest (or the status report) from converging.
const MCP_APPLY_TIMEOUT_MS = 15_000;

function withTimeout<T>(p: Promise<T>, ms: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timed out after ${ms}ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

function toUserMessage(text: string, images: ImageAttachment[] | undefined): SDKUserMessage {
  const content: Array<Record<string, unknown>> = [];
  if (text) content.push({ type: 'text', text });
  for (const img of images ?? []) {
    content.push({
      type: 'image',
      source: { type: 'base64', media_type: img.mediaType, data: img.dataBase64 },
    });
  }
  return {
    type: 'user',
    message: { role: 'user', content: content as never },
    parent_tool_use_id: null,
  };
}

export function titleFrom(text: string): string {
  // The standing instructions an app adds after what was typed are never part of a title.
  const at = text.indexOf('[escanor:auto]');
  const typed = at >= 0 ? text.slice(0, at) : text;
  const oneLine = typed.trim().replace(/\s+/g, ' ');
  return oneLine.length > 60 ? `${oneLine.slice(0, 57)}...` : oneLine || 'New session';
}

/** Shown on a chat whose turn was cut off because the machine went to sleep. */
export const SLEPT_MESSAGE = 'This machine went to sleep while it was working, which stopped the run. Send "continue" to pick up where it left off.';

export class SessionManager {
  private live = new Map<string, LiveSession>();
  private permissions: PermissionBroker;
  private registry: SessionRegistry;
  // The hub's declarative set of MCP servers. Every session, new or already running, is made to match it.
  private mcpServers = new Map<string, ManagedMcpServer>();
  // What the hub last pushed, this machine's own Escanor key (deviceMcp.ts), and a server name revoked for this machine.
  private hubServers: ManagedMcpServer[] = [];
  private deviceMcp: Omit<ManagedMcpServer, 'updatedAt'> | null = null;
  private blockedMcp: string | null = null;
  // What each running session's own MCP client last reported, so the hub can show real connection state.
  private mcpSessionStatus = new Map<LiveSession, Map<string, { status: string; error?: string }>>();
  private lastMcpReport = '';
  /** Called after each turn of a session this agent runs, and when it stops (TerminalSessionSync records where its transcript ends). */
  onTurnEnded: ((sessionId: string, cwd: string) => void) | null = null;
  /** A copy was kept before a delete in this chat (safetyAgent.ts): the agent tells the apps. */
  onUndoKept: ((sessionId: string, undoId: string) => void) | null = null;
  /** Called when the agent goes from nothing running to something running (true) and back (false): drives keep-awake. */
  onWorkChange: ((working: boolean) => void) | null = null;
  /** A chat this agent is not running but that is busy elsewhere on this machine (a terminal session, terminalSessions.ts). */
  isRunningElsewhere: ((sessionId: string) => boolean) | null = null;
  /** A chat whose Claude process is open elsewhere on this machine (a terminal), busy or not: never resumed here as well. */
  isOpenElsewhere: ((sessionId: string) => boolean) | null = null;
  /** Hands a message for a chat open in a terminal here to that terminal Claude itself (terminalInbox.ts); false = it cannot. */
  deliverToTerminal: ((input: HubUserInput) => boolean) | null = null;
  /** AUTORESUME: whether this machine is connected to Escanor now (a chat cut off by going offline goes on only once it is). */
  isOnline: (() => boolean) | null = null;
  /** The agent is stopping: chats closed now were cut off, not finished (they go on by themselves on the next start). */
  private stopping = false;
  private resumeTimer: ReturnType<typeof setTimeout> | null = null;
  private retryTimer: ReturnType<typeof setTimeout> | null = null;
  // Turns asked for and not yet answered, per running chat: a message counts from arrival (queued behind a running turn too)
  // until its result. A chat that is open but between turns is idle.
  private turns = new Map<LiveSession, number>();
  private wasWorking = false;
  // Chats that were mid-turn when the machine went to sleep: if they end, the person is told why.
  private sleptMidTurn = new Set<LiveSession>();
  private limits: ChatLimits;
  /** Claude's last word on each account's usage (rate_limit_event). */
  private usage = new UsageLimits();
  private verifier: Verifier<LiveSession>;
  /**
   * Work that waits: for a free slot ('cap') or for Claude's usage limit to reset ('limit'). Tried in this order (the person can
   * change it from the apps), kept on disk (data/queue.json) so a restart loses none of it, and reported as queue_state.
   */
  private waiting: Waiting[] = [];
  private queueFile: string;
  // An empty queue is what the hub assumes until told otherwise (resendQueueState tells it again on every connect).
  private lastQueueReport = '[]';
  private lastQueueSaved = '';
  private draining = false;
  /** A person's own "Start now" is running through admit: the resource pause does not hold it (unless memory is critical). */
  private forceStart = false;
  private releaseTimer: ReturnType<typeof setTimeout> | null = null;
  /** AI accounts that hit their limit, and when each resets (persisted). */
  private limitHolds: AiLimitHolds;
  /** Chats already told about a hold (`account@resetsAt:chat`), so each hears it once. */
  private limitTold = new Set<string>();
  /** The apps hear that the held accounts changed (machine status). */
  onLimitsChange?: () => void;
  /** A new chat's temp id -> the existing chat it continued, so later messages and controls sent to the temp id reach it. */
  private aliases = new Map<string, string>();
  /** The Remote control switch (jarvis.ts): the AI's screen tools work only while it is on. */
  private remoteFile: string;
  private dataDir: string;
  /** What this agent was started with: the machine permissions only narrow these, never add to them. */
  private base: { computerControl: boolean; meshTools: boolean; defaultMode: PermissionMode | undefined };

  constructor(
    private workspaceRoot: string,
    dataDir: string,
    private profiles: ClaudeProfile[],
    private send: (msg: AgentToHubMessage) => void,
    private opts: {
      managed?: boolean;
      guide?: string;
      mcpOverride?: Omit<ManagedMcpServer, 'updatedAt'> | null;
      /** Directories the sandbox policy never lets the assistant change on its own (the agent's code, data and .env). */
      protectedPaths?: string[];
      /** Hosts WebFetch may reach without a card in a managed worker. */
      fetchAllow?: string[];
      /** The SDK's query(); injectable so tests can see exactly what a session is started with. */
      query?: typeof sdkQuery;
      /** The same for a chat on a ChatGPT / Gemini account (cliEngine.ts). */
      cliQuery?: typeof cliQuery;
      /**
       * The mode a chat starts in when nothing was chosen for it (DEFAULT_PERMISSION_MODE, set from the owner's plan at
       * install). 'bypassPermissions' is a machine that does everything itself: its chats never wait for the phone, and the
       * app's "Autonomous" means bypass there too.
       */
      defaultMode?: PermissionMode;
      /** Injectable for tests; otherwise whether this process runs as root. */
      isRoot?: boolean;
      /** Chats run as these users, never as the agent's (chatUser.ts): ordinary chats as `chat`, isolated ones as `appChat`. */
      chatUsers?: ChatUsers | null;
      /** Injectable for tests: how a chat's process is started as its user. */
      spawnDeps?: SpawnDeps;
      /** Injectable for tests; otherwise process.platform. The MCP-key pipe needs bash and /dev/fd, so Windows keeps the SDK's own spawn. */
      platform?: NodeJS.Platform;
      /** Reuse window, caps and compaction thresholds (chatPolicy.ts; config.ts reads them from the environment). */
      limits?: Partial<ChatLimits>;
      /** Held work goes out this long after Claude's limit resets (the reset is Claude's clock, not ours). */
      limitMarginMs?: number;
      /** Injectable clock for tests. */
      now?: () => number;
      /** After a turn's result with more turns still counted, how long the chat must stay silent before they count as folded in (default 30 s). */
      settleMs?: number;
      /** AUTORESUME (autoResume.ts): cut-off chats go on by themselves. On unless false (AUTO_RESUME=0). */
      autoResume?: boolean;
      /** F2 (keyLeaks.ts): where keys a push scan refused are reported (fingerprints only). */
      leaks?: LeakSink;
      /** The safety net (riskHold.ts): risky commands wait for the person's Approve in every mode. On unless ESCANOR_RISK_HOLDS=0. */
      riskHolds?: boolean;
      /** A personal computer (Escanor Desktop's agent): the stricter rules of personalGuard.ts hold as well, and nothing turns the holds off. */
      personal?: boolean;
      /** The owner's fingerprint-confirmed "Let AI chats handle sign-ins" window (signinControl.chatWindow): while it runs, a chat that works on its own may touch sign-in files. Null/absent: it asks the phone. */
      credentialGrant?: () => { until: number; by: string } | null;
      /** The safety layer (safetyAgent.ts): never-delete blocks and undo copies before deletes, in every mode. */
      safety?: SafetyAgent;
      /** JARVIS1 (computerControl.ts): chats get this computer's everyday actions as the escanor_computer tools. */
      computerControl?: boolean;
      /** Mesh: chats (here, a headless server's too) get the `devices` tool: list the owner's other devices and hand them work (meshAsk.ts). */
      meshTools?: boolean;
      /** L1-VERIFY (verifyDone.ts): a chat that changed code runs the project's checks before it is done. Off unless ESCANOR_VERIFY_DONE=1. */
      verifyDone?: boolean;
      /** Injectable for tests. */
      verifier?: Verifier<LiveSession>;
      /** The person wins over our work (resourceGuard.ts): over its limits new work waits and idle chats are put away. */
      guard?: ResourceGuard;
      /** The person comes first (userFirst.ts): while it yields or pauses, new work waits and idle chats are put away on memory trouble. */
      userFirst?: UserFirst;
      /** Where the held AI accounts and their reset times are kept (aiLimits.ts), so a restart or sleep does not lose them. */
      limitStore?: LimitStore;
      /** Claude config folders to look in for a chat missing from the list (tests). */
      claudeDirs?: () => string[];
      /** Which accounts are signed in (signedIn.ts). Absent: every account counts as signed in. */
      signIn?: { signedIn: (p: ClaudeProfile) => boolean; mark: (p: ClaudeProfile) => void };
    } = {},
  ) {
    this.limits = { ...DEFAULT_CHAT_LIMITS, ...opts.limits };
    this.verifier = opts.verifier ?? new Verifier<LiveSession>();
    this.registry = new SessionRegistry(dataDir);
    this.queueFile = join(dataDir, 'queue.json');
    this.remoteFile = join(dataDir, 'remote-control.json');
    this.dataDir = dataDir;
    this.base = { computerControl: !!opts.computerControl, meshTools: !!opts.meshTools, defaultMode: opts.defaultMode };
    // What waited when the agent last stopped. It is tried again by restoreQueue(), once the hub link is up.
    this.waiting = loadWaiting(this.queueFile);
    this.lastQueueSaved = JSON.stringify(this.waiting.filter(savable));
    this.markCutOffAtStart();
    this.permissions = new PermissionBroker((msg) => this.send(msg), () => this.now());
    opts.guard?.onChange((state, prev) => this.onGuard(state, prev));
    opts.userFirst?.onChange((state, prev) => this.onUserFirst(state, prev));
    this.limitHolds = new AiLimitHolds({
      store: opts.limitStore,
      now: () => this.now(),
      marginMs: opts.limitMarginMs,
      onRelease: (ids) => this.onLimitRelease(ids),
      onChange: () => this.limitsChanged(),
    });
    // What was held when the agent last stopped is still held until its reset.
    for (const e of this.limitHolds.all()) this.usage.note(e.accountId, { status: 'rejected', resetsAt: e.resetsAt }, this.now());
    // Present from the first session on, before the hub has pushed anything.
    if (opts.mcpOverride) this.mcpServers.set(opts.mcpOverride.name, { ...opts.mcpOverride, updatedAt: new Date().toISOString() });
  }

  private resolveProfile(accountId: string | undefined): ClaudeProfile {
    return this.profiles.find((p) => p.id === accountId) ?? defaultProfile(this.profiles);
  }

  private signedIn(p: ClaudeProfile): boolean {
    return this.opts.signIn?.signedIn(p) ?? true;
  }

  /** Another Claude account that is signed in (one that is not held for its limit first), or undefined. */
  private signedInInstead(not: ClaudeProfile): ClaudeProfile | undefined {
    const others = this.profiles.filter((p) => p.id !== not.id && providerOf(p) === 'claude' && this.signedIn(p));
    return others.find((p) => this.usage.state(p.id, this.now()).status !== 'rejected') ?? others[0];
  }

  /**
   * The account a new chat runs on: the one asked for (else the default), unless it is a Claude account that is not signed in on
   * this computer and another one is. The agent switches by itself instead of stopping at "Please run /login".
   */
  private chooseAccount(accountId: string | undefined): ClaudeProfile {
    const p = this.resolveProfile(accountId);
    if (providerOf(p) !== 'claude' || this.signedIn(p)) return p;
    return this.signedInInstead(p) ?? p;
  }

  /** Plain name of an account for the chat's notices. */
  private accountName(p: ClaudeProfile): string {
    return `"${this.accountLabel(p.id)}"`;
  }

  /**
   * A Claude chat whose account is not signed in goes on under one that is: its history is copied to that account's folder and the
   * chat is listed under it. Returns the account it now runs on (the same one when nothing better was found).
   */
  private moveChat(sessionId: string, from: ClaudeProfile): ClaudeProfile | undefined {
    if (this.opts.chatUsers || providerOf(from) !== 'claude') return undefined;
    const to = this.signedInInstead(from);
    if (!to) return undefined;
    if (!copyTranscript(sessionId, profileConfigDir(from), profileConfigDir(to))) return undefined;
    this.registry.update(sessionId, { accountId: to.id });
    return to;
  }

  /** A chat on a Claude account (ChatGPT / Gemini chats are never compacted with /compact, nor read as Claude transcripts). */
  private isClaudeAccount(accountId: string | undefined): boolean {
    return providerForAccount(this.profiles, accountId) === 'claude';
  }

  get sessionRegistry(): SessionRegistry {
    return this.registry;
  }

  /** How many chats are in a turn now. */
  workingCount(): number {
    return this.turns.size;
  }

  /** Is anything running or waiting to run? (A chat that is open but between turns is not.) */
  isWorking(): boolean {
    return this.turns.size > 0 || this.runningSessions().some((s) => inBackground(s, this.now()));
  }

  private beginTurn(session: LiveSession): void {
    this.turns.set(session, (this.turns.get(session) ?? 0) + 1);
    // AUTORESUME: on disk while it runs, so a computer that goes away mid-turn picks it up on the next start.
    if (session.sessionId) this.registry.update(session.sessionId, { turnOpen: true });
    this.notifyWork();
  }

  private endTurn(session: LiveSession): void {
    const n = (this.turns.get(session) ?? 0) - 1;
    if (n > 0) {
      this.turns.set(session, n);
      this.settleTurns(session);
    } else this.turns.delete(session);
    if (n <= 0 && session.sessionId) this.registry.update(session.sessionId, { turnOpen: undefined });
    this.notifyWork();
    if (n <= 0) this.closeIfLimited(session); // its account hit the limit: nothing stays running for it
    if (n <= 0) this.drain(); // a chat went idle: a queued one may start now
  }

  /**
   * A message that reaches a chat while it is working is folded by Claude Code into the turn already running: two messages, one
   * result. The count above then stays at one for ever, and a chat that finished long ago looks busy: it is never closed to make
   * room, so chats queued for a slot wait for ever. A turn that is really queued behind the one that ended starts within seconds
   * and is heard from; so a chat still counted after its result that stays silent is idle, and its count is cleared.
   */
  private settleTurns(session: LiveSession): void {
    if (session.settleTimer) clearTimeout(session.settleTimer);
    const resultAt = this.now();
    const t = setTimeout(() => {
      session.settleTimer = undefined;
      if (session.closing || this.stopping || !this.turns.has(session)) return;
      if ((session.heardAt ?? 0) > resultAt || session.compacting > 0) return; // the next turn is under way: its own result settles it
      this.turns.delete(session);
      if (session.sessionId) this.registry.update(session.sessionId, { turnOpen: undefined });
      this.notifyWork();
      this.drain();
    }, this.opts.settleMs ?? SETTLE_MS);
    t.unref?.();
    session.settleTimer = t;
  }

  // ---------- AUTORESUME: cut-off chats go on by themselves (autoResume.ts) ----------

  private get autoResumeOn(): boolean {
    return this.opts.autoResume !== false;
  }

  /**
   * At start: a chat whose turn was still open when the last agent stopped was cut off (the computer was turned off, restarted,
   * lost power, or the agent crashed). It is marked so, and resumeCutOff() carries it on once this machine is connected.
   */
  private markCutOffAtStart(): void {
    for (const e of this.registry.all()) {
      if (!e.turnOpen) continue;
      const cutOff: CutOff | undefined =
        !this.autoResumeOn || e.fix
          ? e.cutOff
          : (e.cutOff ?? { reason: 'offline', since: e.lastActiveAt ?? e.createdAt, tries: 0 });
      this.registry.update(e.sessionId, { turnOpen: undefined, cutOff });
    }
  }

  /** Was cut off: it goes on by itself (once the limit resets / the computer is back). Keeps the first time and the tries so far. */
  private markCutOff(sessionId: string, reason: CutOff['reason'], at: { resetsAt?: number; retryAt?: number } = {}): void {
    if (!this.autoResumeOn || !sessionId) return;
    const e = this.registry.get(sessionId);
    if (!e || e.fix) return;
    const prev = e.cutOff;
    this.registry.update(sessionId, {
      cutOff: {
        reason,
        since: prev?.since ?? new Date(this.now()).toISOString(),
        tries: prev?.tries ?? 0,
        ...(at.resetsAt !== undefined ? { resetsAt: at.resetsAt } : {}),
        ...(at.retryAt !== undefined ? { retryAt: at.retryAt } : {}),
      },
    });
  }

  /**
   * A chat the agent itself does not run (a terminal chat that was busy when the computer went off: terminalResume.ts) is carried
   * on here, as a chat of this agent, once this machine is connected.
   */
  markOffline(sessionId: string): boolean {
    const e = this.registry.get(sessionId);
    if (!this.autoResumeOn || !e || e.fix || e.archivedAt || e.cutOff) return false;
    this.markCutOff(sessionId, 'offline');
    return true;
  }

  /** The next chat waiting to be tried again after the AI service failed: tried then. */
  private scheduleRetry(): void {
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = null;
    if (!this.autoResumeOn || this.stopping) return;
    const at = nextRetryAt(this.registry.all(), this.now());
    if (at === undefined) return;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = null;
      this.resumeCutOff();
    }, Math.max(0, at - this.now()) + 50);
    this.retryTimer.unref?.();
  }

  /** It went on fine, or the person stopped it: nothing to pick up any more. */
  private clearCutOff(sessionId: string): void {
    if (sessionId && this.registry.get(sessionId)?.cutOff) this.registry.update(sessionId, { cutOff: undefined });
  }

  /**
   * Ended mid-turn without a result (its Claude died, or failed): not picked up on its own. Decided a moment later, because when
   * the whole computer is going down its Claude processes are killed a moment before the agent hears it is stopping.
   */
  private settleTurnOpen(sessionId: string): void {
    if (!sessionId) return;
    const t = setTimeout(() => {
      const live = this.live.get(sessionId);
      if (this.stopping || (live && this.turns.has(live))) return;
      this.registry.update(sessionId, { turnOpen: undefined });
    }, 3_000);
    t.unref?.();
  }

  /** resumeCutOff() after `delayMs` (one pending at a time; a newer ask replaces it). */
  resumeCutOffSoon(delayMs = 0): void {
    if (!this.autoResumeOn || this.stopping) return;
    if (this.resumeTimer) clearTimeout(this.resumeTimer);
    this.resumeTimer = setTimeout(() => {
      this.resumeTimer = null;
      this.resumeCutOff();
    }, delayMs);
    this.resumeTimer.unref?.();
  }

  /**
   * Carry on every cut-off chat that can go on now: a "continue" from the agent goes in like any message, so one cut off by the
   * limit waits for the reset (queue reason 'limit'), and one cut off by going offline waits for the hub link. Never a chat that
   * is running, has messages waiting, or is open in a terminal (the person carries it on there).
   */
  resumeCutOff(): void {
    if (!this.autoResumeOn || this.stopping || this.guardPaused()) return; // paused: started again when the guard lifts (onGuard)
    const online = this.isOnline?.() ?? true;
    const picks = chatsToResume(this.registry.all(), {
      now: this.now(),
      skip: (id) => this.isBusy(id) || Boolean(this.isOpenElsewhere?.(id)),
    });
    let changed = false;
    for (const { sessionId, reason } of picks) {
      if (reason !== 'limit' && !online) continue;
      const e = this.registry.get(sessionId)!;
      const cut = e.cutOff!;
      // After a restart Claude's word on the limit is gone: what it said then still holds until the reset.
      if (cut.resetsAt !== undefined && cut.resetsAt > this.now() && this.usage.state(e.accountId, this.now()).status !== 'rejected') {
        this.usage.note(e.accountId, { status: 'rejected', resetsAt: cut.resetsAt }, this.now());
      }
      this.registry.update(sessionId, { cutOff: { ...cut, tries: cut.tries + 1, retryAt: undefined } });
      // told 'limit': the person already heard it goes on by itself when the limit resets (waitNotice), not said again.
      const input: HubUserInput = { type: 'user_input', sessionId, text: continueText(reason), inputId: `${AUTO_RESUME_INPUT}${reason}:${randomUUID()}` };
      this.admit(input, reason === 'limit' ? 'limit' : undefined);
      changed = true;
    }
    if (changed) this.queueChanged();
    this.scheduleRetry();
  }

  /** Right before the agent's own "continue" starts: the chat says it goes on by itself. */
  private announceResume(input: HubUserInput): void {
    const reason = reasonOfInput(input.inputId);
    if (!reason) return;
    this.send({ type: 'error', kind: 'notice', sessionId: input.sessionId, message: resumeNotice(reason) });
  }

  private clearTurns(session: LiveSession): void {
    this.turns.delete(session);
    this.notifyWork();
  }

  private notifyWork(): void {
    const working = this.isWorking();
    if (working === this.wasWorking) return;
    this.wasWorking = working;
    try {
      this.onWorkChange?.(working);
    } catch (err) {
      console.error('Work-change listener failed', err);
    }
  }

  /**
   * The machine just woke from sleep. A turn that was running was cut off (its connection to the model died with the network),
   * so if it ends, the chat says why and how to go on, instead of showing a bare error.
   */
  noteResume(): void {
    for (const s of this.turns.keys()) this.sleptMidTurn.add(s);
    this.limitHolds.check(); // a limit may have reset while it slept: its work starts now
    void this.opts.userFirst?.tick();
    this.drain(); // a usage limit may have reset while it slept
  }

  /** A chat cut off because the machine slept: it goes on by itself once connected again (else the person is told to continue). */
  private sleptNotice(sessionId: string): string {
    if (!this.autoResumeOn || !sessionId || !this.registry.get(sessionId)) return SLEPT_MESSAGE;
    this.markCutOff(sessionId, 'offline', {});
    this.registry.update(sessionId, { turnOpen: undefined });
    if (this.isOnline?.() ?? true) this.resumeCutOffSoon(5_000);
    return waitNotice('offline');
  }

  /** The chat id of the chat whose tools carry [callerKey] ('' if it is not running or Claude has not named it yet). Lets a tool say "this chat" without the model knowing the id. */
  callerSessionId(callerKey: string): string {
    if (!callerKey) return '';
    for (const s of this.live.values()) if (s.callerKey === callerKey) return s.sessionId;
    return '';
  }

  isLive(sessionId: string): boolean {
    return this.live.has(sessionId);
  }

  /** The chats this agent runs right now, by id (the other Claude processes here are terminal chats). */
  liveIds(): Set<string> {
    return new Set(this.live.keys());
  }

  summaries(): AgentSessionSummary[] {
    return this.registry.all().map((e) => ({
      sessionId: e.sessionId,
      cwd: e.cwd,
      title: e.title,
      createdAt: e.createdAt,
      status: this.live.has(e.sessionId) || this.isRunningElsewhere?.(e.sessionId) ? 'active' : 'idle',
      accountId: e.accountId,
      ...(e.archivedAt ? { archived: true } : {}),
      source: sessionSource(e),
      ...(e.preview ? { preview: e.preview } : {}),
      ...(e.priority ? { priority: true as const } : {}),
    }));
  }

  // ---------- Priority chats ----------

  /** Marked Priority by the person (a new chat's temp id counts once it continued an existing chat). */
  isPriority(sessionId: string | undefined): boolean {
    return sessionId !== undefined && this.registry.get(this.resolveId(sessionId))?.priority === true;
  }

  /**
   * Mark a chat Priority, or take the mark off: kept in the registry (so it survives a restart), said to the hub, and the queue
   * is reordered at once (its waiting messages first) and tried again, so a Priority chat waiting for a slot starts now if it may.
   */
  setPriority(rawId: string, priority: boolean): void {
    const sessionId = this.resolveId(rawId);
    if (!this.registry.get(sessionId)) return;
    this.registry.update(sessionId, { priority: priority ? true : undefined });
    this.send({ type: 'session_priority', sessionId, priority });
    this.waiting = this.byPriority(this.waiting);
    this.queueChanged();
    this.drain();
  }

  /** The waiting work with Priority chats' messages first; otherwise in the order it was (each chat's messages stay in order). */
  private byPriority(items: Waiting[]): Waiting[] {
    const first = items.filter((w) => this.isPriority(w.input.sessionId));
    return first.length === 0 ? items : [...first, ...items.filter((w) => !first.includes(w))];
  }

  /** Running chats that are Priority. */
  private priorityRunning(): number {
    return this.runningSessions().filter((s) => s.sessionId !== undefined && s.sessionId !== '' && this.isPriority(s.sessionId)).length;
  }

  private resolveCwd(requested: string | undefined): string {
    // Symlink-aware: a link inside the workspace pointing outside it does not make the outside part of the workspace.
    return resolveInside(this.workspaceRoot, requested);
  }

  // ---------- hub-managed MCP servers ----------

  private sdkMcpConfig(autonomous = false, callerKey = ''): Record<string, McpServerConfig> {
    const out: Record<string, McpServerConfig> = {};
    for (const s of this.mcpServers.values()) {
      // JARVIS3: Escanor's own server is told the chat's mode here, by the agent (never by the AI): only in Autonomous may a send in the
      // person's name go without a card (and then only for a person who opted in, which the API checks again).
      const headers = { ...(s.headers ?? {}), ...(autonomous && s.name === AUTONOMY_HEADER_SERVER ? { [AUTONOMY_HEADER]: 'auto' } : {}) };
      out[s.name] = {
        type: 'http',
        url: s.url,
        ...(Object.keys(headers).length > 0 ? { headers } : {}),
        // Escanor exposes a handful of tools, so have them in the very first prompt instead of
        // deferred behind tool search: "available automatically" means the model can call them at once.
        ...(s.alwaysLoad !== false ? { alwaysLoad: true } : {}),
      };
    }
    // This computer's own actions (JARVIS1): set last, so a pushed server of the same name never stands in for it.
    if (this.opts.computerControl) out[COMPUTER_MCP_NAME] = { ...computerMcpConfig(this.remoteFile, this.dataDir, false, callerKey), alwaysLoad: true };
    else if (this.opts.meshTools) out[COMPUTER_MCP_NAME] = { ...computerMcpConfig(this.remoteFile, this.dataDir, true, callerKey), alwaysLoad: true };
    return out;
  }

  // Decided per call, from the *current* set (see mcpApproval.ts), so turning auto-approve off takes effect in chats already open.
  private isAutoAllowedMcpTool(toolName: string, input: Record<string, unknown>): boolean {
    // JARVIS1: opening a page or an app, media keys, volume, lock: what the person would press themselves, so no card.
    if (this.opts.computerControl && parseMcpToolName(toolName)?.server === COMPUTER_MCP_NAME) return true;
    // The devices tool only asks the backend, whose safety check decides (allow, ask a person, hold, deny): no extra card here.
    if (this.opts.meshTools && parseMcpToolName(toolName)?.server === COMPUTER_MCP_NAME && parseMcpToolName(toolName)?.tool === 'devices') return true;
    return isAutoAllowedMcpTool(this.mcpServers.values(), toolName, input);
  }

  /** Replace the managed MCP servers and make every running session match, without restarting it. */
  async setMcpServers(servers: ManagedMcpServer[]): Promise<void> {
    this.hubServers = servers;
    await this.applyMcpServers();
  }

  /**
   * This machine's own Escanor key (deviceMcp.ts), or null to stop using one. It replaces the hub's entry of the same name on
   * this machine only, and a hub push that leaves it out cannot remove it. `block` (the key was revoked) also drops the hub's
   * entry of that name, so a revoked machine keeps no Escanor connection at all until it is paired again. An incident's
   * ESCANOR_MCP_OVERRIDE still wins over both.
   */
  async setDeviceMcp(entry: Omit<ManagedMcpServer, 'updatedAt'> | null, opts: { block?: string } = {}): Promise<void> {
    const valid = entry && /^https?:\/\//.test(entry.url) && isValidMcpServerName(entry.name) ? entry : null;
    const block = valid ? null : (opts.block ?? null);
    const same = JSON.stringify(valid) === JSON.stringify(this.deviceMcp) && block === this.blockedMcp;
    const newlyBlocked = block !== null && this.blockedMcp === null;
    this.deviceMcp = valid;
    this.blockedMcp = block;
    if (!same) await this.applyMcpServers();
    if (newlyBlocked) this.tellRevoked();
  }

  /** The machine's key was just revoked: each running chat is told once, in plain words, that Escanor's tools are off here and how to bring them back. */
  private tellRevoked(): void {
    const seen = new Set<unknown>();
    for (const [key, session] of this.live.entries()) {
      if (seen.has(session) || session.isolated) continue;
      seen.add(session);
      this.send({ type: 'error', kind: 'notice', sessionId: key, message: REVOKED_NOTICE });
    }
  }

  private async applyMcpServers(): Promise<void> {
    const next = new Map<string, ManagedMcpServer>();
    for (const s of this.hubServers) {
      // The hub validates already; a bad entry here must never reach a session's config.
      if (/^https?:\/\//.test(s.url) && isValidMcpServerName(s.name) && s.name !== this.blockedMcp) next.set(s.name, s);
    }
    if (this.deviceMcp) next.set(this.deviceMcp.name, { ...this.deviceMcp, updatedAt: new Date().toISOString() });
    // This machine's own entry wins over the hub's of the same name, and is never dropped by a push that omits it.
    if (this.opts.mcpOverride) next.set(this.opts.mcpOverride.name, { ...this.opts.mcpOverride, updatedAt: new Date().toISOString() });
    this.mcpServers = next;
    const sessions = new Set(this.live.values());
    let applied = 0;
    await Promise.all(
      [...this.live.entries()].map(async ([key, session]) => {
        if (!sessions.delete(session)) return; // the same session is briefly registered under two keys
        if (session.isolated) return; // never given the hub's servers
        try {
          const config = this.sdkMcpConfig(isAutonomous(session), session.callerKey);
          const configJson = JSON.stringify(config);
          if (session.appliedMcp !== configJson) {
            await withTimeout(session.setMcpServers(config), MCP_APPLY_TIMEOUT_MS);
            session.appliedMcp = configJson;
          }
          const status = await withTimeout(session.mcpServerStatus(), MCP_APPLY_TIMEOUT_MS);
          this.mcpSessionStatus.set(session, new Map(status.map((s) => [s.name, { status: s.status, error: s.error }])));
          applied++;
        } catch (err) {
          console.error(`Could not apply MCP servers to session ${key}:`, err instanceof Error ? err.message : err);
        }
      }),
    );
    this.reportMcpStatus(applied);
  }

  // Keyed by the session object, not its id: a new chat is re-keyed from its temp id to its real one
  // straight after init, and a lookup by the old key would find nothing.
  private refreshMcpStatusLater(session: LiveSession, attempt = 0): void {
    setTimeout(async () => {
      if (![...this.live.values()].includes(session)) return;
      try {
        const status = await withTimeout(session.mcpServerStatus(), MCP_APPLY_TIMEOUT_MS);
        this.mcpSessionStatus.set(session, new Map(status.map((s) => [s.name, { status: s.status, error: s.error }])));
        this.reportMcpStatus();
        if (status.some((s) => s.status === 'pending') && attempt < 4) this.refreshMcpStatusLater(session, attempt + 1);
      } catch {
        // the session ended or is busy; the next init or change reports again
      }
    }, 3000);
  }

  private reportMcpStatus(liveSessions = this.live.size): void {
    const servers: AgentMcpServerStatus[] = [...this.mcpServers.keys()].map((name) => {
      const reports = [...this.mcpSessionStatus.values()].map((m) => m.get(name)).filter((r) => r !== undefined);
      if (reports.length === 0) return { name, status: 'configured' };
      // One healthy session is proof the server works from this VM; otherwise show the most recent problem.
      const best = reports.find((r) => r.status === 'connected') ?? reports[reports.length - 1];
      return { name, status: best.status as AgentMcpServerStatus['status'], ...(best.error ? { error: best.error } : {}) };
    });
    // A revoked machine has dropped the server, so it is no longer in the list: say so instead of showing nothing.
    if (this.blockedMcp && !servers.some((x) => x.name === this.blockedMcp)) servers.push({ name: this.blockedMcp, status: 'disabled', error: REVOKED_STATUS });
    const payload = JSON.stringify({ servers, liveSessions });
    if (payload === this.lastMcpReport) return;
    this.lastMcpReport = payload;
    this.send({ type: 'mcp_status', servers, liveSessions });
  }

  /** Stop every running Claude Code process. Without this they outlive the agent that started them. */
  shutdown(): void {
    this.stopping = true; // what ends now was cut off: turnOpen stays on disk, and the next start carries it on
    if (this.resumeTimer) clearTimeout(this.resumeTimer);
    if (this.retryTimer) clearTimeout(this.retryTimer);
    for (const session of new Set(this.live.values())) {
      try {
        session.close();
      } catch {
        // already gone
      }
    }
  }

  /** The hub (re)connected: it has forgotten what we last told it. */
  resetMcpReport(): void {
    this.lastMcpReport = '';
  }

  handleUserInput(input: HubUserInput): void {
    // The hub sends a message again when this machine never confirmed it (after a restart, the ones that waited here): one that
    // is already waiting is only confirmed again, never queued twice.
    if (input.inputId && !input.inputId.startsWith('agent:') && this.waiting.some((w) => w.input.inputId === input.inputId)) {
      this.ack(input, 'queued');
      return;
    }
    // AUTORESUME: the person wrote to a cut-off chat themselves: their message carries it on, the agent's "continue" is dropped.
    if (!input.inputId?.startsWith('agent:')) {
      const id = this.resolveId(input.sessionId);
      const auto = this.waiting.filter((w) => w.input.sessionId === id && w.input.inputId?.startsWith(AUTO_RESUME_INPUT));
      if (auto.length) this.waiting = this.waiting.filter((w) => !auto.includes(w));
    }
    this.admit(input);
    this.queueChanged();
  }

  private now(): number {
    return this.opts.now?.() ?? Date.now();
  }

  /** Claude folders to look in for a chat this agent does not list: every account's folder and this computer's own login. */
  private claudeDirs(): string[] {
    if (this.opts.claudeDirs) return this.opts.claudeDirs();
    const own = process.env.CLAUDE_CONFIG_DIR?.trim() || join(homedir(), '.claude');
    return [...this.profiles.flatMap((p) => (p.configDir ? [p.configDir] : [])), own, join(homedir(), '.claude')];
  }

  /** The chat's transcript is on this computer but this agent never listed it: take it in under the account whose folder holds it. */
  private adoptFromDisk(sessionId: string): boolean {
    const found = findTranscript(sessionId, this.claudeDirs());
    if (!found) return false;
    const owner = this.profiles.find((p) => p.configDir && p.configDir === found.configDir) ?? this.profiles.find((p) => !p.configDir) ?? defaultProfile(this.profiles);
    this.registry.upsert({
      sessionId,
      cwd: found.cwd,
      title: titleFrom(found.title),
      createdAt: found.createdAt,
      accountId: owner.id,
      lastActiveAt: new Date(this.now()).toISOString(),
    });
    console.log(`Chat ${sessionId.slice(0, 8)} was not in this agent's list; found on this computer and taken in.`);
    return true;
  }

  /** The chat a temp id became when it continued an existing one. */
  private resolveId(sessionId: string): string {
    return this.aliases.get(sessionId) ?? sessionId;
  }

  /**
   * Every message goes through here, again when it waited. In order: Claude's usage limit (hold), an open chat (queue the
   * message into it), a new chat that can continue an open one (chatPolicy.pickReusable), and else a new Claude process
   * within this machine's caps (or wait for a slot). `told` = what the person was already told about this message.
   */
  private admit(raw: HubUserInput, told?: 'cap' | 'limit', meta?: WaitMeta): void {
    let input = { ...raw, sessionId: this.resolveId(raw.sessionId) };
    // One being closed to make room takes no more messages: the chat is resumed in a new process instead.
    const open = this.live.get(input.sessionId);
    const live = open && !open.closing ? open : undefined;
    const entry = this.registry.get(input.sessionId);
    // A second message for a new chat that is still waiting for a slot waits behind it.
    if (!live && !input.tempId && !entry) {
      const ahead = this.waiting.find((w) => w.input.tempId === input.sessionId);
      if (ahead) {
        const item: Waiting = { ...this.waitMeta(meta), input, told: ahead.told, ...(ahead.accountId ? { accountId: ahead.accountId } : {}) };
        if (told === undefined && input.priority === true) this.placeAtFront(item);
        else this.waiting.push(item);
        if (told === undefined) this.ack(input, 'queued');
        return;
      }
      // Without a tempId this is a resume of a chat this agent has no registry row for (the other agent on this computer, or an
      // older data folder, may hold it). The person is never stuck: first the chat is found on disk and taken in, else it goes on
      // in a new conversation that the hub is told IS this chat (session_created names the old id as the temp id), so the
      // history stays on screen and the message is answered.
      if (this.adoptFromDisk(input.sessionId)) {
        this.admit(raw, told, meta);
        return;
      }
      this.admit({ ...raw, sessionId: input.sessionId, tempId: input.sessionId, fresh: true }, told, meta);
      return;
    }
    const isNew = Boolean(input.tempId) && !live;
    let fresh = input.fresh === true;
    if (isNew) {
      const asked = explicitNewChat(input.text);
      if (asked.fresh) {
        fresh = true;
        // Kept on the message, so it is still a separate chat if it has to wait and is tried again.
        input = { ...input, text: asked.text, fresh: true };
        if (!input.text.trim() && !input.images?.length) {
          this.send({ type: 'error', tempId: input.tempId, message: 'Write what the new chat should do after /new.' });
          this.ack(input, 'refused', 'Nothing to do after /new.');
          return;
        }
      }
      // A task limited to some repositories never continues another chat (it would limit that chat too): it gets its own.
      if (!fresh && reposOf(input) !== undefined) {
        fresh = true;
        input = { ...input, fresh: true };
      }
    }
    if (isNew) {
      // Not signed in on this computer: the chat starts on a signed-in account instead (said only when one was picked by name).
      const wanted = this.resolveProfile(input.accountId);
      const chosen = this.chooseAccount(input.accountId);
      if (chosen.id !== wanted.id) {
        const named = Boolean(input.accountId);
        input = { ...input, accountId: chosen.id };
        if (named && told === undefined) this.send({ type: 'error', kind: 'notice', tempId: input.tempId, message: signedOutUsing(this.accountName(wanted), this.accountName(chosen)) });
      }
    }
    const accountId = live ? live.accountId : isNew ? this.resolveProfile(input.accountId).id : entry!.accountId;
    const usage = this.usage.state(accountId, this.now());
    if (usage.status === 'rejected') {
      this.hold(input, 'limit', told, limitNotice(usage.resetsAt ?? this.now()), { ...this.waitMeta(meta), accountId });
      return;
    }
    // The computer is busy or short of memory (resourceGuard.ts): nothing new starts, it waits. A message into a chat that is
    // already working takes nothing more, so it goes in.
    const pausedHold = this.guardPaused() && !this.forceStart && !(live && this.turns.has(live));
    if (live) {
      if (pausedHold) {
        this.hold(input, 'cap', told, this.busyNotice(), { ...this.waitMeta(meta), accountId });
        return;
      }
      this.announceResume(input);
      this.continueLive(input.sessionId, live, input);
      return;
    }
    // Resuming a chat that is still open in a terminal would run it in a second Claude on the same transcript (it forks, and
    // two Claudes edit one repo). The message goes into that terminal chat instead, so phone and PC stay one conversation; a
    // terminal that cannot take messages (no phone hook in it) is said so. The error also ends the turn the hub opened for it.
    if (!isNew && !open && this.isOpenElsewhere?.(input.sessionId)) {
      if (this.deliverToTerminal?.(input)) return;
      this.send({ type: 'error', sessionId: input.sessionId, message: OPEN_IN_TERMINAL });
      this.ack(input, 'refused', OPEN_IN_TERMINAL);
      // The hub marked the chat active when the message arrived; an idle terminal chat would keep a "Working" dot.
      if (!this.isRunningElsewhere?.(input.sessionId)) this.send({ type: 'session_ended', sessionId: input.sessionId });
      return;
    }
    if (pausedHold) {
      this.hold(input, 'cap', told, this.busyNotice(), { ...this.waitMeta(meta), accountId });
      return;
    }
    if (isNew && !fresh) {
      const reuse = this.findReusable(input, accountId, usage.status === 'allowed_warning');
      if (reuse) {
        this.continueExisting(input, reuse, told, meta);
        return;
      }
    }
    if (!this.makeRoom(isNew ? undefined : input.sessionId, input.jobSlot === true)) {
      this.hold(input, 'cap', told, QUEUED_MESSAGE, { ...this.waitMeta(meta), accountId });
      return;
    }
    if (!isNew && entry?.archivedAt) this.registry.update(input.sessionId, { archivedAt: undefined });
    this.announceResume(input);
    this.startSession(input, !isNew && needsCompaction(entry, this.limits) && this.isClaudeAccount(entry?.accountId));
  }

  /** A message for a running chat: queued behind its turn (compacting it first when its context is nearly full). */
  private continueLive(sessionId: string, live: LiveSession, input: HubUserInput): void {
    if (input.isolated === true && !live.isolated) this.isolate(sessionId, live);
    live.lastInput = input;
    const repos = reposOf(input);
    if (repos) {
      // Sticky, and only ever narrower: before the message's turn starts, so its first command is already checked.
      live.writeRepos = narrowRepos(live.writeRepos, repos);
      this.remember(sessionId, { writeRepos: live.writeRepos });
    }
    if (needsCompaction(this.registry.get(sessionId), this.limits) && this.isClaudeAccount(live.accountId)) this.compact(live, sessionId);
    this.beginTurn(live);
    this.verifyStart(live);
    live.queue.push(toUserMessage(input.text, input.images), () => this.ack(input, 'delivered'));
  }

  /** L1-VERIFY: a message of the person starts a check job (the tree as it is before the turn), for Claude chats that qualify. */
  private verifyStart(session: LiveSession): void {
    if (this.opts.verifyDone !== true || session.isolated || !this.isClaudeAccount(session.accountId)) return;
    if (session.sessionId && this.registry.get(session.sessionId)?.fix) return;
    this.verifier.userTurn(session, session.cwd);
  }

  /**
   * L1-VERIFY: the chat went idle after a good turn. When the turn changed code and the project's checks fail, the failure goes back
   * into the same chat (3 rounds at most, and a time cap); still red, the chat says so in plain words.
   */
  private verifyAfterTurn(session: LiveSession, sessionId: string): void {
    if (!this.verifier.has(session)) return;
    if (this.stopping || session.closing || this.turns.has(session) || session.compacting > 0 || this.registry.get(sessionId)?.lastOutcome !== 'ok') {
      if (this.registry.get(sessionId)?.lastOutcome !== 'ok' || session.closing) this.verifier.drop(session);
      return;
    }
    void this.verifier
      .finish(session, session.cwd, () => !this.stopping && !session.closing && !this.turns.has(session))
      .then((o) => {
        if (this.stopping || session.closing || this.turns.has(session)) return;
        if (o.kind === 'followup') {
          this.beginTurn(session);
          session.queue.push(toUserMessage(o.text, undefined));
        } else if (o.kind === 'giveup') {
          this.send({ type: 'error', kind: 'notice', sessionId, message: o.notice });
        }
      })
      .catch(() => this.verifier.drop(session));
  }

  /** DEV6: tell the hub where a message from the phone stands on this machine (input_ack). */
  private ack(input: HubUserInput, status: 'delivered' | 'queued' | 'refused', reason?: string): void {
    if (input.inputId?.startsWith('agent:')) return; // the agent's own message (a fix continued after a restart): no phone waits for it
    this.send({
      type: 'input_ack',
      sessionId: input.sessionId,
      ...(input.tempId ? { tempId: input.tempId } : {}),
      ...(input.inputId ? { inputId: input.inputId } : {}),
      status,
      ...(reason ? { reason } : {}),
    });
  }

  private compact(live: LiveSession, sessionId: string): void {
    // Counted once asked for, so a second message right behind it does not ask again.
    this.registry.update(sessionId, { turnsSinceCompact: 0, contextPct: undefined });
    this.beginTurn(live);
    live.compacting++;
    live.queue.push(toUserMessage(COMPACT, undefined));
  }

  /**
   * A new chat continues `e`: the hub is told the new chat's temp id IS that chat (session_created, as for any new chat), so it
   * moves the first message there and the phone opens it; then the message goes to it like any other.
   */
  private continueExisting(input: HubUserInput, e: RegistryEntry, told?: 'cap' | 'limit', meta?: WaitMeta): void {
    const tempId = input.tempId!;
    this.aliases.set(tempId, e.sessionId);
    if (this.aliases.size > 500) this.aliases.delete(this.aliases.keys().next().value!);
    this.send({ type: 'session_created', tempId, sessionId: e.sessionId, cwd: e.cwd, title: e.title, accountId: e.accountId });
    const next: HubUserInput = { type: 'user_input', sessionId: e.sessionId, text: input.text };
    if (input.inputId) next.inputId = input.inputId;
    if (input.images) next.images = input.images;
    if (input.permissionMode !== undefined) next.permissionMode = input.permissionMode;
    if (input.model !== undefined) next.model = input.model;
    if (input.effort !== undefined) next.effort = input.effort;
    if (input.isolated === true) next.isolated = true;
    if (input.writeRepos !== undefined) next.writeRepos = input.writeRepos;
    const live = this.live.get(e.sessionId);
    if (live && !live.closing) {
      // What the new request asked for applies to the chat it continues (a resumed one gets it from the message itself).
      if (next.permissionMode !== undefined && next.permissionMode !== live.requested) this.setPermissionMode(e.sessionId, next.permissionMode);
      if (next.model !== undefined && next.model !== (e.model ?? '')) this.setModel(e.sessionId, next.model || undefined);
      if (next.effort !== undefined && next.effort !== (e.effort ?? null)) this.setEffort(e.sessionId, next.effort);
    }
    this.admit(next, told, meta);
  }

  /** Where a chat for `requested` runs (as its chat user, that user's copy of the folder). */
  private chatCwdFor(requested: string | undefined, isolated: boolean): string {
    const asked = this.resolveCwd(requested);
    const chatUser = this.opts.chatUsers ? (isolated ? this.opts.chatUsers.appChat : this.opts.chatUsers.chat) : null;
    return chatUser ? chatCwd(chatUser, this.workspaceRoot, asked) : asked;
  }

  private findReusable(input: HubUserInput, accountId: string, relaxed: boolean): RegistryEntry | undefined {
    const isolated = input.isolated === true;
    return pickReusable(
      this.registry.all(),
      { cwd: this.chatCwdFor(input.cwd, isolated), accountId, isolated },
      { now: this.now(), maxAgeMs: this.limits.reuseIdleHours * HOUR_MS, relaxed, running: (id) => this.isBusy(id) },
    );
  }

  /** Working (a turn running or waiting for the person) or with messages waiting to go to it. */
  private isBusy(sessionId: string): boolean {
    const live = this.live.get(sessionId);
    if (live && !live.closing && (this.turns.has(live) || inBackground(live, this.now()))) return true;
    return this.waiting.some((w) => w.input.sessionId === sessionId);
  }

  private runningSessions(): LiveSession[] {
    return [...new Set(this.live.values())].filter((s) => !s.closing);
  }

  private closeLive(live: LiveSession): void {
    live.closing = true;
    try {
      live.close();
    } catch {
      // already gone
    }
  }

  // ---------- the person wins over our work (resourceGuard.ts) ----------

  private guardPaused(): boolean {
    return this.opts.guard?.state.paused === true || this.opts.userFirst?.holding === true;
  }

  private busyKind(): 'memory' | 'load' | 'user' {
    const u = this.opts.userFirst?.state;
    if (u && u.level !== 'normal') return u.why === 'using' ? 'user' : u.why === 'memory' ? 'memory' : 'load';
    const r = this.opts.guard?.state.reason;
    return r === 'memory' || r === 'our-memory' ? 'memory' : 'load';
  }

  private busyNotice(): string {
    const u = this.opts.userFirst?.state;
    if (u && u.level !== 'normal' && !this.opts.guard?.state.paused) return waitingNotice(u.why);
    return BUSY_NOTICE(this.opts.guard?.state.reason ?? null);
  }

  /** The person comes first (userFirst.ts): memory short for a while puts idle chats away; when it lifts the waiting work goes on. */
  private onUserFirst(state: UserFirstState, prev: UserFirstState): void {
    if (this.stopping) return;
    if (state.memoryCritical && state.level === 'pause') this.putIdleAway(0);
    // Only a pause holds work (yield runs it gently): leaving a pause lets what waited go on.
    if (prev.level === 'pause' && state.level !== 'pause') {
      this.drain();
      this.resumeCutOff();
    }
    if (prev.level !== state.level || prev.why !== state.why) {
      this.queueChanged(); // the apps see why it waits, or that it no longer does
      this.limitsChanged();
    }
  }

  // ---------- AI limits: the whole account waits for the reset (aiLimits.ts) ----------

  /** Start the reset clock (call once the agent is up). */
  startLimitClock(): void {
    this.limitHolds.start();
  }

  stopLimitClock(): void {
    this.limitHolds.stop();
  }

  /** Accounts that are held now, for the machine status. */
  heldAccounts(): (LimitEntry & { label: string })[] {
    return this.limitHolds.all().map((e) => ({ ...e, label: e.label ?? this.accountLabel(e.accountId) }));
  }

  private accountLabel(accountId: string): string {
    const p = this.profiles.find((x) => x.id === accountId);
    return p?.label && p.label !== 'default' ? p.label : p?.email ?? (accountId === 'default' ? 'this computer' : accountId);
  }

  /**
   * An account reached its limit: ALL work on it waits for `resetsAt` (new messages are held by admit through the usage record),
   * its idle chat processes are ended to free their memory (resumable), and the reset starts everything again by itself.
   * `accountId` undefined = every account (the Escanor plan's limit).
   */
  noteAccountLimit(accountId: string | undefined, resetsAt: number, source: LimitSource): void {
    const ids = accountId ? [accountId] : this.profiles.map((p) => p.id);
    for (const id of ids) this.holdAccount(id, resetsAt, source);
  }

  private holdAccount(accountId: string, resetsAt: number, source: LimitSource): void {
    if (resetsAt <= this.now()) return;
    const label = this.accountLabel(accountId);
    this.limitHolds.hold(accountId, resetsAt, source, label);
    const held = this.limitHolds.get(accountId);
    if (!held) return;
    this.usage.note(accountId, { status: 'rejected', resetsAt: held.resetsAt }, this.now());
    this.scheduleRelease();
    this.tellHeldChats(accountId, held);
    for (const s of this.runningSessions()) if (s.accountId === accountId) this.closeIfLimited(s);
    this.queueChanged();
  }

  /**
   * Claude's own usage figures for an account (accountUsage.ts): at NEAR_LIMIT_PCT or more of the five-hour (or weekly) window the
   * account is held before it hits the wall, until the window resets; below it again, a hold made this way is lifted.
   */
  noteAccountUsage(accountId: string, u: { five_hour_pct: number; resets_at: string | null; seven_day_pct?: number; seven_day_resets_at?: string | null }): void {
    const five = u.five_hour_pct >= NEAR_LIMIT_PCT && u.resets_at ? Date.parse(u.resets_at) : NaN;
    const seven = (u.seven_day_pct ?? 0) >= NEAR_LIMIT_PCT && u.seven_day_resets_at ? Date.parse(u.seven_day_resets_at) : NaN;
    const at = Math.max(Number.isFinite(five) ? five : 0, Number.isFinite(seven) ? seven : 0);
    if (at > this.now()) this.holdAccount(accountId, at, 'usage');
    else this.limitHolds.lift(accountId, 'usage');
  }

  /** A chat on a held account that has nothing running is ended now (its process and memory go); it stays resumable. */
  private closeIfLimited(session: LiveSession): void {
    if (session.closing || !this.limitHolds.get(session.accountId)) return;
    if (this.turns.has(session) || inBackground(session, this.now())) return;
    this.closeLive(session);
  }

  /**
   * The other chats of that account that are open here hear the hold once (the chat that hit the limit is told by its own cut-off
   * notice, and a message that waits by its own queue notice).
   */
  private tellHeldChats(accountId: string, e: LimitEntry): void {
    const text = limitStatusText(e.label, e.resetsAt, this.now());
    for (const s of this.runningSessions()) {
      if (s.accountId !== accountId || !s.sessionId || s.limited) continue;
      const key = `${accountId}@${e.resetsAt}:${s.sessionId}`;
      if (this.limitTold.has(key)) continue;
      this.limitTold.add(key);
      this.send({ type: 'error', kind: 'notice', sessionId: s.sessionId, message: text });
    }
  }

  private onLimitRelease(accountIds: string[]): void {
    if (this.stopping) return;
    for (const id of accountIds) this.usage.note(id, { status: 'allowed' }, this.now());
    this.drain(); // the held work goes first, oldest / Priority first, within the caps; the person busy now = it waits for that
    this.resumeCutOff();
  }

  private limitsChanged(): void {
    try {
      this.onLimitsChange?.();
    } catch (err) {
      console.error('Limit-change listener failed', err);
    }
  }

  /** Every look of the guard: over a memory limit idle chats are put away, and when it lifts the waiting work and cut-off chats go on. */
  private onGuard(state: GuardState, prev: GuardState): void {
    if (this.stopping) return;
    if (state.paused && (state.reason === 'memory' || state.reason === 'our-memory')) this.putIdleAway(0);
    else if (!state.paused) this.putIdleAway(this.opts.guard?.limits.idleCloseMs ?? 0);
    if (prev.paused && !state.paused) {
      this.drain();
      this.resumeCutOff();
    }
    if (prev.paused !== state.paused || prev.reason !== state.reason) this.queueChanged(); // the apps see why it waits, or that it no longer does
  }

  /**
   * Idle chat processes (no turn, no background work, nothing waiting for them) quiet for at least `quietMs` are closed: their memory
   * is freed and they stay resumable, as makeRoom does for a slot. A running chat is never touched.
   */
  private putIdleAway(quietMs: number): void {
    if (quietMs === 0 && !this.guardPaused()) return;
    for (const s of this.runningSessions()) {
      if (!s.sessionId || this.turns.has(s) || inBackground(s, this.now()) || this.isBusy(s.sessionId)) continue;
      const e = this.registry.get(s.sessionId);
      if (!e) continue;
      const last = Date.parse(e.lastActiveAt ?? e.createdAt) || 0;
      if (quietMs > 0 && this.now() - last < quietMs) continue;
      if (quietMs === 0 && this.now() - last < 5_000) continue; // just answered: not in the same breath
      this.closeLive(s);
    }
  }

  /**
   * Room for one more Claude process (a new chat, or `resumeId` resumed): under the open-chat cap the least recently active idle
   * chat is put away, under the running cap the least recently active idle process is closed (it stays resumable). False when
   * every chat is busy: the work then waits.
   */
  private makeRoom(resumeId?: string, jobSlot = false): boolean {
    const resuming = resumeId ? this.registry.get(resumeId) : undefined;
    // A Priority chat, or a chat Escanor starts for a goal (jobSlot, never a person's own chat): the same one slot above the cap.
    const priority = resuming?.priority === true || jobSlot;
    if (!resumeId || resuming?.archivedAt) {
      const open = () => {
        const registered = this.registry.all().filter(isOpen);
        const pendingNew = this.runningSessions().filter((s) => !s.sessionId).length;
        return { registered, count: registered.length + pendingNew };
      };
      for (let o = open(); o.count >= this.limits.maxOpen; o = open()) {
        const victim = pickOldestIdle(o.registered, (id) => this.isBusy(id), resumeId);
        if (!victim) {
          // A Priority chat may open one above the cap when none of the open ones is Priority; nothing is closed for it.
          if (priority && o.count < this.limits.maxOpen + 1 && !o.registered.some((e) => e.priority === true && e.sessionId !== resumeId)) break;
          return false;
        }
        this.registry.update(victim.sessionId, { archivedAt: new Date(this.now()).toISOString() });
        const live = this.live.get(victim.sessionId);
        if (live) this.closeLive(live);
      }
    }
    const running = this.runningSessions();
    if (running.length >= this.limits.maxLive) {
      const idle = running
        .filter((s) => s.sessionId && !this.turns.has(s) && !inBackground(s, this.now()))
        .map((s) => this.registry.get(s.sessionId))
        .filter((e): e is RegistryEntry => e !== undefined);
      // Every one counts until it is closed, so close as many as it takes.
      let over = running.length - this.limits.maxLive + 1;
      if (idle.length < over) {
        // Every slot is held by chats at work. A Priority chat gets one slot above the cap when none of them is Priority (it never
        // stops another chat); else it waits, first in line.
        return priority && running.length < this.limits.maxLive + 1 && this.priorityRunning() === 0;
      }
      while (over-- > 0) {
        const victim = pickOldestIdle(idle, () => false)!;
        idle.splice(idle.indexOf(victim), 1);
        const live = this.live.get(victim.sessionId);
        if (live) this.closeLive(live);
      }
    }
    return true;
  }

  /** The message waits (for a slot, or for Claude's limit to reset). The person is told once per reason. */
  private hold(input: HubUserInput, why: 'cap' | 'limit', told: 'cap' | 'limit' | undefined, notice: string, meta: WaitMeta & { accountId: string }): void {
    const item: Waiting = { id: meta.id, queuedAt: meta.queuedAt, accountId: meta.accountId, input, told: why };
    // "Send as priority": a message that has only just arrived waits at the front. (One that waited before and is tried again keeps
    // its place, so an order the person set by hand holds.)
    if (told === undefined && input.priority === true) {
      this.placeAtFront(item);
    } else if (this.isPriority(input.sessionId)) {
      // A Priority chat's message waits ahead of every other chat's (behind earlier Priority ones).
      const at = this.waiting.findIndex((w) => !this.isPriority(w.input.sessionId));
      if (at < 0) this.waiting.push(item);
      else this.waiting.splice(at, 0, item);
    } else this.waiting.push(item);
    if (told === undefined) this.ack(input, 'queued');
    if (told !== why) {
      this.send(input.tempId ? { type: 'error', kind: 'notice', tempId: input.tempId, message: notice } : { type: 'error', kind: 'notice', sessionId: input.sessionId, message: notice });
    }
    if (why === 'limit') this.scheduleRelease();
  }

  /**
   * A message sent as priority waits at the front of the queue, behind messages that were sent as priority before it. The chat's
   * other waiting messages go with it and keep their order (a chat reads them in the order they were sent).
   */
  private placeAtFront(item: Waiting): void {
    const key = this.chatKey(item);
    const group = this.waiting.filter((x) => this.chatKey(x) === key);
    const rest = this.waiting.filter((x) => !group.includes(x));
    let at = 0;
    while (at < rest.length && rest[at].input.priority === true) at++;
    this.waiting = [...rest.slice(0, at), ...group, item, ...rest.slice(at)];
  }

  private scheduleRelease(): void {
    // No reset ahead any more (it passed since the work was held): what waits goes at once instead of waiting for good.
    const at = this.usage.nextReset(this.now()) ?? this.now();
    if (this.releaseTimer) clearTimeout(this.releaseTimer);
    this.releaseTimer = setTimeout(() => {
      this.releaseTimer = null;
      this.drain();
    }, Math.max(0, at - this.now()) + (this.opts.limitMarginMs ?? 5000));
    this.releaseTimer.unref?.();
  }

  /** Once a chat's wake-up time has passed (with its grace), a message waiting for a slot may take it. */
  private drainAfterWake(session: LiveSession): void {
    const at = session.wake?.wakeAt;
    if (at == null) return;
    const t = setTimeout(() => {
      this.notifyWork();
      if (!inBackground(session, this.now()) && !this.turns.has(session)) this.drain();
    }, Math.min(Math.max(0, at + WAKE_GRACE_MS - this.now()) + 1_000, 2 ** 31 - 1));
    t.unref?.();
  }

  /** Once its background helpers and commands would go stale (nothing heard for BACKGROUND_STALE_MS), its slot is freed. */
  private armStale(session: LiveSession): void {
    if (session.staleTimer) clearTimeout(session.staleTimer);
    session.staleTimer = undefined;
    if (!(session.background ?? 0)) return;
    const t = setTimeout(() => {
      session.staleTimer = undefined;
      if (session.closing || !(session.background ?? 0)) return;
      if (backgroundFresh(session.heardAt, this.now())) return this.armStale(session); // heard from since: look again later
      this.notifyWork();
      if (!inBackground(session, this.now()) && !this.turns.has(session)) this.drain();
    }, Math.max(0, (session.heardAt ?? this.now()) + BACKGROUND_STALE_MS - this.now()) + 1_000);
    t.unref?.();
    session.staleTimer = t;
  }

  /** Try the waiting work again, in arrival order (what still cannot go waits again, without a second notice). */

  private drain(): void {
    if (this.draining || this.waiting.length === 0) return;
    this.draining = true;
    try {
      // Priority chats' messages are tried first, so a freed slot goes to them.
      const items = this.byPriority(this.waiting);
      this.waiting = [];
      for (const w of items) this.admit(w.input, w.told, w);
    } finally {
      this.draining = false;
    }
    this.queueChanged();
  }

  /** An item that waits again keeps its id and its time; a new one gets its own. */
  private waitMeta(meta: WaitMeta | undefined): WaitMeta {
    return meta ? { id: meta.id, queuedAt: meta.queuedAt } : { id: randomUUID(), queuedAt: this.now() };
  }

  // ---------- the queue as the apps see it (QUEUEUI) ----------

  /** After the agent restarted: what waited when it stopped is tried again (call once the hub link is up). */
  restoreQueue(): void {
    this.drain();
    this.queueChanged();
  }

  /** The app messages that wait (loaded from the saved queue at start): seenInputs.keepQueued remembers them across the restart. */
  queuedInputs(): QueuedInput[] {
    return this.waiting
      .filter((w) => w.input.inputId && savable(w))
      .map((w) => ({ inputId: w.input.inputId!, sessionId: w.input.sessionId, ...(w.input.tempId ? { tempId: w.input.tempId } : {}) }));
  }

  /** What waits, in order: first words only, never a whole message. */
  queueSnapshot(): AgentQueueState {
    const items = this.waiting.slice(0, MAX_QUEUE_ITEMS).map((w, position) => {
      const { input } = w;
      const entry = this.registry.get(input.sessionId);
      const newChat = Boolean(input.tempId) || (!entry && this.waiting.some((o) => o.input.tempId === input.sessionId));
      const accountId = w.accountId ?? entry?.accountId ?? this.chooseAccount(input.accountId).id;
      const usage = w.told === 'limit' ? this.usage.state(accountId, this.now()) : undefined;
      const images = input.images?.length ?? 0;
      return {
        id: w.id,
        ...(input.inputId ? { inputId: input.inputId } : {}),
        sessionId: input.sessionId,
        ...(newChat ? { tempId: input.tempId ?? input.sessionId } : {}),
        newChat,
        ...(!newChat && entry?.title ? { chatTitle: entry.title.slice(0, 300) } : {}),
        preview: reasonOfInput(input.inputId) || (!splitHidden(input.text).typed && input.text.includes(HIDDEN_MARKER)) ? AUTO_RESUME_PREVIEW : previewOf(splitHidden(input.text).typed),
        ...(images ? { images } : {}),
        ...(input.priority === true ? { priority: true as const } : {}),
        reason: w.told,
        ...(w.told === 'cap' && this.guardPaused() ? { busy: this.busyKind() } : {}),
        position,
        queuedAt: new Date(w.queuedAt).toISOString(),
        ...(usage?.resetsAt !== undefined ? { resetsAt: new Date(usage.resetsAt).toISOString() } : {}),
      };
    });
    return { type: 'queue_state', items, maxOpen: this.limits.maxOpen, maxLive: this.limits.maxLive, at: new Date(this.now()).toISOString() };
  }

  /** The hub (re)connected: it hears the queue again, whether or not it changed. */
  resendQueueState(): void {
    this.lastQueueReport = '';
    this.reportQueue();
  }

  private reportQueue(): void {
    const state = this.queueSnapshot();
    const key = JSON.stringify(state.items);
    if (key === this.lastQueueReport) return;
    this.lastQueueReport = key;
    this.send(state);
  }

  /** After any change to what waits: kept on disk, and the apps hear of it. Not mid-drain (it ends with one call). */
  private queueChanged(): void {
    if (this.draining) return;
    const saved = JSON.stringify(this.waiting.filter(savable));
    if (saved !== this.lastQueueSaved) {
      this.lastQueueSaved = saved;
      saveWaiting(this.queueFile, this.waiting);
    }
    this.reportQueue();
  }

  /** A queue command from the apps: done, or refused in plain words (queue_result). */
  handleQueueCommand(cmd: HubQueueCommand): void {
    let r: QueueOutcome;
    try {
      r =
        cmd.type === 'queue_cancel'
          ? this.queueCancel(cmd.id)
          : cmd.type === 'queue_edit'
            ? this.queueEdit(cmd.id, cmd.text)
            : cmd.type === 'queue_move'
              ? this.queueMove(cmd.id, cmd.to)
              : cmd.type === 'queue_start_now'
                ? this.queueStartNow(cmd.id)
                : cmd.type === 'queue_get'
                  ? this.queueGet(cmd.id)
                  : { ok: false, error: 'Unknown queue command' };
    } catch (err) {
      console.error('Queue command failed', err);
      r = { ok: false, error: 'The computer could not do that just now.' };
    }
    this.queueChanged();
    if (typeof cmd.requestId === 'string' && cmd.requestId) this.send({ type: 'queue_result', requestId: cmd.requestId, ok: r.ok, ...(r.ok ? (r.text !== undefined ? { text: r.text } : {}) : { error: r.error }) });
  }

  /** The chat a waiting message is for: a new chat's temp id (its later messages name it too) or the chat's id. */
  private chatKey(w: Waiting): string {
    return w.input.tempId ?? w.input.sessionId;
  }

  /** Nothing waits for the chat and it does not run here: the apps stop showing it as working. */
  private settleIfIdle(key: string): void {
    if (this.waiting.some((w) => this.chatKey(w) === key) || this.live.has(key) || this.live.has(this.resolveId(key))) return;
    this.send({ type: 'session_ended', sessionId: key });
  }

  private queueCancel(id: string): QueueOutcome {
    const w = this.waiting.find((x) => x.id === id);
    if (!w) return { ok: false, error: NOT_WAITING };
    const key = this.chatKey(w);
    // A new chat's first message goes with the ones waiting behind it: without it there is no chat for them.
    const drop = w.input.tempId ? this.waiting.filter((x) => this.chatKey(x) === key) : [w];
    this.waiting = this.waiting.filter((x) => !drop.includes(x));
    for (const x of drop) this.ack(x.input, 'refused', CANCELLED_FROM_QUEUE);
    // The agent's own "continue" cancelled from the queue: the person does not want it picked up on its own.
    for (const x of drop) if (x.input.inputId?.startsWith(AUTO_RESUME_INPUT)) this.clearCutOff(x.input.sessionId);
    this.settleIfIdle(key);
    return { ok: true };
  }

  /** Its whole current text, for Edit (an edit made here or on another device included). */
  private queueGet(id: string): QueueOutcome {
    const w = this.waiting.find((x) => x.id === id);
    // Only what the person typed: the instructions the app added for the machine stay out of sight and are kept on save.
    return w ? { ok: true, text: splitHidden(w.input.text).typed } : { ok: false, error: NOT_WAITING };
  }

  private queueEdit(id: string, text: unknown): QueueOutcome {
    const w = this.waiting.find((x) => x.id === id);
    if (!w) return { ok: false, error: NOT_WAITING };
    if (typeof text !== 'string' || text.length > MAX_EDIT_CHARS) return { ok: false, error: 'That text is too long.' };
    if (!text.trim() && !w.input.images?.length) return { ok: false, error: 'Write something for it to do, or cancel it instead.' };
    // The edit replaces what the person typed; the app's hidden instructions on the original go on after it (unless the
    // app sent them again itself, as apps did before the machine kept them).
    const hidden = splitHidden(w.input.text).hidden;
    w.input = { ...w.input, text: hidden && !text.includes(HIDDEN_MARKER) ? `${text.trimEnd()}${hidden}` : text };
    return { ok: true };
  }

  private queueMove(id: string, to: unknown): QueueOutcome {
    const w = this.waiting.find((x) => x.id === id);
    if (!w) return { ok: false, error: NOT_WAITING };
    if (to !== 'top' && to !== 'up' && !(typeof to === 'number' && Number.isInteger(to) && to >= 0)) return { ok: false, error: 'That is not a place in the queue.' };
    // Messages for one chat move together and keep their order (a chat reads them in the order they were sent).
    const key = this.chatKey(w);
    const group = this.waiting.filter((x) => this.chatKey(x) === key);
    const first = this.waiting.indexOf(group[0]);
    const rest = this.waiting.filter((x) => !group.includes(x));
    const at = to === 'top' ? 0 : to === 'up' ? Math.max(0, first - 1) : Math.min(to as number, rest.length);
    // Put in a place by hand, a message is no longer "priority": the order shown is the order it starts in.
    if (to !== 'top') for (const x of group) if (x.input.priority) x.input = { ...x.input, priority: undefined };
    this.waiting = [...rest.slice(0, at), ...group, ...rest.slice(at)];
    return { ok: true };
  }

  /**
   * Start it now, ahead of the rest, if this machine can make room by putting its least recently active idle chat away (what
   * makeRoom does); a running chat is never stopped for it. Otherwise it stays where it was.
   */
  private queueStartNow(id: string): QueueOutcome {
    const w = this.waiting.find((x) => x.id === id);
    if (!w) return { ok: false, error: NOT_WAITING };
    const entry = this.registry.get(w.input.sessionId);
    const accountId = w.accountId ?? entry?.accountId ?? this.chooseAccount(w.input.accountId).id;
    const usage = this.usage.state(accountId, this.now());
    if (usage.status === 'rejected') {
      const at = usage.resetsAt !== undefined ? ` (${new Date(usage.resetsAt).toISOString()})` : '';
      return { ok: false, error: `This one waits for Claude's usage limit to reset${at}. Claude would refuse it until then.` };
    }
    const key = this.chatKey(w);
    const group = this.waiting.filter((x) => this.chatKey(x) === key);
    if (this.opts.guard?.state.critical) {
      // Memory is critically low: not even a person's Start now may start another Claude. First in line, starts when it recovers.
      this.waiting = [...group, ...this.waiting.filter((x) => !group.includes(x))];
      this.queueChanged();
      return { ok: false, error: CRITICAL_BUSY };
    }
    const before = this.waiting.filter((x) => !group.includes(x));
    this.waiting = before;
    this.draining = true; // one report at the end, not one per message
    this.forceStart = true;
    try {
      for (const x of group) this.admit(x.input, x.told, x);
    } finally {
      this.draining = false;
      this.forceStart = false;
    }
    const started = !this.waiting.some((x) => x.id === group[0].id);
    if (!started) {
      // No room: the chat's messages go to the top of the queue, first in line, as they were.
      const ids = new Set(group.map((x) => x.id));
      this.waiting = this.waiting.filter((x) => !ids.has(x.id));
      this.waiting.unshift(...group);
    }
    this.drain(); // a chat put away meanwhile may have made room the others can use (a drain asked for above was skipped)
    return started ? { ok: true } : { ok: false, error: ALL_BUSY };
  }

  /** A running chat becomes isolated: its MCP servers go before its next step, and it is remembered so. */
  private isolate(sessionId: string, live: LiveSession): void {
    live.isolated = true;
    this.remember(sessionId, { isolated: true });
    this.control(sessionId, 'Disconnecting services', async (l) => {
      await l.setMcpServers({});
      l.appliedMcp = '{}';
    });
  }

  private get isRoot(): boolean {
    return this.opts.isRoot ?? runningAsRoot();
  }

  /**
   * The app's "Autonomous" ('auto') runs as bypass: nothing waits for the phone, so it works with the phone closed. Handed to
   * Claude Code as is, 'auto' is its own classifier mode, which refuses some commands and then asks the person to run them by
   * hand. Autonomous is not "Bypass permissions": the blocklist and the safety layer still apply (see guarded). A managed
   * worker, or a machine that gives each chat its own user (never there), keeps 'auto' as it is; a managed worker still follows a bypass default.
   */
  private effectiveMode(mode: PermissionMode): PermissionMode {
    if (mode !== 'auto') return mode;
    // A managed worker keeps its sandbox policy. A machine that gives each chat its own user skips the safety layer (the
    // copy-first guard cannot run as another user), so Autonomous never becomes bypass there: Claude Code's own 'auto' stays,
    // and anything it does ask about still goes to the phone.
    if (this.opts.chatUsers) return mode;
    if (this.opts.defaultMode === 'bypassPermissions') return 'bypassPermissions';
    return this.opts.managed ? mode : 'bypassPermissions';
  }

  /**
   * An Autonomous chat says each step it took without asking, in the chat ("Approved by itself: ..."), so nothing it does is
   * hidden. Only what Ask me would have asked about: reading and looking around stay quiet.
   */
  private noteApprovedByItself(session: LiveSession | undefined, sessionKey: string | undefined, tool: string, input: unknown): void {
    if (!session || !sessionKey || session.requested !== 'auto' || session.mode !== 'bypassPermissions') return;
    if (!needsApproval(tool, input)) return;
    this.send({ type: 'error', kind: 'notice', sessionId: sessionKey, message: `${APPROVED_BY_ITSELF} ${describeCommand(tool, input).summary}` });
  }

  /**
   * Bypass as root: Claude Code refuses it, so the run stays in default mode and canUseTool says yes itself. Not for a managed
   * worker, which keeps its sandbox policy instead.
   */
  private get rootFallback(): boolean {
    return this.isRoot && !this.opts.managed;
  }

  /**
   * Bypass with the phone's blocklist (see @remote-harness/shared/autonomy): any chat in bypass that was not explicitly set to
   * "Bypass permissions" (an Autonomous chat, or one whose bypass comes only from the machine's default, such as a request from
   * the assistant that names no mode), and the root fallback. Only a chat the phone or app explicitly set to "Bypass
   * permissions" (not as root) runs without it.
   */
  private guarded(session: LiveSession | undefined): boolean {
    // Either the chat is meant to be in bypass, or Claude Code still is (a switch out of it not yet confirmed, or refused).
    if (!session || (session.mode !== 'bypassPermissions' && session.confirmed !== 'bypassPermissions')) return false;
    return session.requested !== 'bypassPermissions' || this.rootFallback;
  }

  /** The mode Claude Code itself runs in: as root, bypass is answered by canUseTool instead (see runningAsRoot). */
  private sdkMode(mode: PermissionMode): PermissionMode {
    return mode === 'bypassPermissions' && this.isRoot ? 'default' : mode;
  }

  private startSession(input: HubUserInput, compactFirst = false): void {
    const tempId = input.tempId;
    const existingEntry = this.registry.get(input.sessionId);
    const isResume = Boolean(existingEntry) && !tempId;
    const asked = isResume
      ? resumeCwd(this.workspaceRoot, input.cwd, existingEntry, !this.opts.managed && !this.opts.chatUsers)
      : this.resolveCwd(input.cwd ?? existingEntry?.cwd);
    const wanted = isResume ? existingEntry?.accountId : input.accountId;
    let profile = isResume ? this.resolveProfile(wanted) : this.chooseAccount(wanted);
    // Continuing a chat whose account is signed out: it goes on, with its history, under a signed-in account.
    if (isResume && providerOf(profile) === 'claude' && !this.signedIn(profile)) {
      const from = profile;
      const to = this.moveChat(input.sessionId, from);
      if (to) {
        profile = to;
        this.send({ type: 'error', kind: 'notice', sessionId: input.sessionId, message: signedOutMoved(this.accountName(from), this.accountName(to)) });
      }
    }
    // ChatGPT / Gemini accounts run their own tool through the same interface (cliEngine.ts); Claude's path is unchanged.
    const engine = providerOf(profile);
    const refuse = (why: string) => {
      this.send({ type: 'error', ...(isResume ? { sessionId: input.sessionId } : {}), tempId, message: why });
      this.ack(input, 'refused', why);
      if (isResume) this.send({ type: 'session_ended', sessionId: input.sessionId });
    };
    // A ChatGPT / Gemini chat whose account is gone is never continued on another AI.
    if (wanted && !this.profiles.some((p) => p.id === wanted) && providerFromId(wanted) !== 'claude') {
      refuse(ACCOUNT_REMOVED);
      return;
    }
    if (engine !== 'claude' && this.opts.chatUsers) {
      refuse('ChatGPT, Gemini and GitHub Copilot accounts cannot run chats on this computer: its chats run as separate users. Pick a Claude account.');
      return;
    }

    let resolvedSessionId = isResume ? input.sessionId : '';
    const queue = new AsyncMessageQueue<SDKUserMessage>();
    // What this chat runs with: what came with the message, else what was last chosen for it here, else the defaults
    // (the machine's own default mode included).
    const choices = {
      permissionMode: input.permissionMode ?? existingEntry?.permissionMode,
      model: input.model !== undefined ? input.model : existingEntry?.model,
      effort: input.effort !== undefined ? input.effort : existingEntry?.effort,
      // Sticky: a chat isolated once is never given the hub's MCP servers again.
      isolated: input.isolated === true || existingEntry?.isolated === true ? (true as const) : undefined,
      // Sticky too: a resumed chat keeps its repositories, and a message can only narrow them.
      writeRepos: narrowRepos(existingEntry?.writeRepos, reposOf(input)),
    };
    const isolated = choices.isolated === true;
    // As its own user (chatUser.ts): an isolated chat as the app-chat user, any other as the chat user; never as the agent's.
    // Each works in its own folder, so neither can plant files the other loads.
    const chatUser = this.opts.chatUsers ? (isolated ? this.opts.chatUsers.appChat : this.opts.chatUsers.chat) : null;
    const cwd = chatUser ? chatCwd(chatUser, this.workspaceRoot, asked) : asked;
    // The run starts in the chosen mode. Claude Code refuses a later switch to bypass in a run launched without the SDK's
    // opt-in, so every run gets it (bypass is open to every plan when the person picks it). The opt-in only makes the switch
    // possible: a chat in default mode still asks for everything it asked for before (in the SDK's non-interactive runs it
    // does not even change plan mode). Never as root, where Claude Code refuses it outright.
    const requested = choices.permissionMode;
    const startMode = this.effectiveMode(requested ?? this.opts.defaultMode ?? 'default');
    let session!: LiveSession;
    const callerKey = randomUUID();
    const options: Options = {
      cwd,
      // No "Co-Authored-By" or "Generated with" line in anything a chat commits or opens (noAttribution.ts).
      settings: { ...NO_ATTRIBUTION, attribution: { ...NO_ATTRIBUTION.attribution } },
      permissionMode: this.sdkMode(startMode),
      ...(!this.isRoot ? { allowDangerouslySkipPermissions: true } : {}),
      ...(choices.effort ? { effort: choices.effort } : {}),
      // Ask for summarized thinking so the web UI can show it like the CLI's transcript view.
      thinking: { type: 'adaptive', display: 'summarized' },
      // Stream the reply as it is written, so the phone shows it live instead of all at once at the end (see PartialText).
      includePartialMessages: true,
      // Session config is built from the *current* managed set, so a chat opened after the hub
      // changed it gets the change with no restart.
      mcpServers: isolated ? {} : this.sdkMcpConfig(isAutonomous({ requested, mode: startMode }), callerKey),
      // Only the servers above. Without this the CLI also loads a project's own .mcp.json, and a repo that declares a server
      // called "escanor" would inherit the approvals meant for the real one (approval is decided by name).
      strictMcpConfig: true,
      // On a managed or chat-user machine no chat loads filesystem settings (user, project or local, and so no CLAUDE.md): a
      // chat could otherwise plant hooks or settings that another chat (or a later one) runs. People's own machines keep theirs.
      ...(this.opts.chatUsers || this.opts.managed ? { settingSources: [] } : {}),
      // Runs before every tool use, whatever the mode (bypass included): an Autonomous chat in bypass, and the root fallback,
      // still never do what the phone would refuse.
      // Then, whatever the mode, a risky command (shared/risk.ts) waits for the person's Approve on the phone (riskHold.ts).
      hooks: {
        PreToolUse: [
          {
            // A hook that times out lets the tool run: with the safety net on it may wait for the person, so it outlasts any wait.
            // An email in the person's name always waits for them (mailHold.ts), so a chat with the computer tools needs it too.
            ...(this.opts.riskHolds || this.opts.safety || this.opts.computerControl ? { timeout: HOLD_HOOK_TIMEOUT_SECONDS } : {}),
            hooks: [
              async (hookInput, _toolUseId, hookOpts) => {
                const deny = (reason: string) => ({ hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'deny' as const, permissionDecisionReason: reason } });
                try {
                  if (hookInput.hook_event_name !== 'PreToolUse') return {};
                  // Before any mode check: in bypass Claude Code never calls canUseTool, so this is where it is refused.
                  if (session?.isolated && isMcpTool(hookInput.tool_name)) return deny(ISOLATED_MCP);
                  // F2 (pushScan.ts): whatever the mode (bypass and isolated app chats included), a push that adds a key, or a pull
                  // request or comment whose words hold one, does not run. A scan that cannot run lets it through.
                  if (!isMcpTool(hookInput.tool_name)) {
                    const env = chatUser ? { ...options.env, HOME: chatUser.home, TMPDIR: chatUser.tmpDir, USER: undefined, LOGNAME: undefined } : (options.env ?? process.env);
                    const scan = await pushScanVerdict(hookInput.tool_input, {
                      cwd: hookInput.cwd || session?.cwd || cwd,
                      env: chatUser ? { ...process.env, HOME: chatUser.home } : process.env,
                      run: gitRunner(env, chatUser ? (command, args, dir) => asUser(chatUser, command, args, dir) : undefined),
                      log: (line) => console.warn(line),
                    });
                    if (scan.why) {
                      this.opts.leaks?.report(scan.findings, scan.where, 'push');
                      return deny(scan.why);
                    }
                  }
                  // WATCHLIST: whatever the mode, a chat limited to some repositories changes no other one on a remote.
                  if (session?.writeRepos) {
                    // The repository is worked out with git run as the chat runs its commands (its user, HOME, environment),
                    // so the chat's own git settings are the ones read.
                    const env = chatUser ? { ...options.env, HOME: chatUser.home, TMPDIR: chatUser.tmpDir, USER: undefined, LOGNAME: undefined } : (options.env ?? process.env);
                    const why = await remoteWriteBlockReason(hookInput.tool_name, hookInput.tool_input, {
                      allowed: session.writeRepos,
                      cwd: hookInput.cwd || session.cwd,
                      home: chatUser ? chatUser.home : homedir(),
                      env,
                      run: commandRunner(env, chatUser ? (command, args, cwd) => asUser(chatUser, command, args, cwd) : undefined),
                    });
                    if (why) return deny(why);
                  }
                  if (this.guarded(session)) {
                    const why = autonomousBlockReason(hookInput.tool_name, hookInput.tool_input, { textAware: this.opts.riskHolds === true });
                    if (why) return deny(blockedMessage(why));
                  }
                  // JARVIS1 (mailHold.ts): an email in the person's name waits for their yes, unless the chat is Autonomous. Not
                  // tied to ESCANOR_RISK_HOLDS: a sent email cannot be taken back.
                  // In Autonomous a send through Escanor goes by escanor_message_send (it tells the person after each send and keeps an
                  // Undo where the service allows one), so the raw provider call is turned away with that pointer.
                  const redirect = isAutonomous(session) ? autonomousRedirect(hookInput.tool_name, hookInput.tool_input) : null;
                  if (redirect) return deny(redirect);
                  const own = isAutonomous(session) ? sendingNotice(hookInput.tool_name, hookInput.tool_input) : null;
                  if (own) {
                    const key = resolvedSessionId || tempId;
                    if (key) this.send({ type: 'error', kind: 'notice', sessionId: key, message: own });
                  }
                  const mail = isAutonomous(session) ? null : mailSendRisk(hookInput.tool_name, hookInput.tool_input);
                  if (mail) {
                    const held = await holdIfRisky(
                      hookInput.tool_name,
                      hookInput.tool_input,
                      (toolName, input, s) => this.permissions.request(resolvedSessionId || tempId || '', toolName, input, undefined, s),
                      hookOpts?.signal ?? new AbortController().signal,
                      undefined,
                      mail,
                    );
                    if (held && !held.allow) return deny(held.message);
                    return { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'allow' as const, permissionDecisionReason: 'The person approved sending this email on their phone.' } };
                  }
                  // Screen help (screenHold.ts): the first look, and every click or typing, wait for the person's yes (Autonomous: only
                  // inside the app they named). Not tied to ESCANOR_RISK_HOLDS.
                  if (this.opts.computerControl) {
                    const consent = new ScreenConsent(join(this.dataDir, CONSENT_NAME));
                    const sv = screenVerdict(hookInput.tool_name, hookInput.tool_input, { consented: consent.granted(), autonomous: isAutonomous(session) });
                    if (sv.kind === 'deny') return deny(sv.message);
                    if (sv.kind === 'allow') {
                      if (sv.grantsConsent) consent.grant();
                      return { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'allow' as const, permissionDecisionReason: 'An Autonomous chat: the person chose to let it work on its own.' } };
                    }
                    if (sv.kind === 'hold') {
                      const held = await holdIfRisky(
                        hookInput.tool_name,
                        hookInput.tool_input,
                        (toolName, input, s) => this.permissions.request(resolvedSessionId || tempId || '', toolName, input, undefined, s),
                        hookOpts?.signal ?? new AbortController().signal,
                        undefined,
                        sv.risk,
                      );
                      if (held && !held.allow) return deny(held.message);
                      if (sv.grantsConsent) consent.grant();
                      return { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'allow' as const, permissionDecisionReason: 'The person said yes on their phone.' } };
                    }
                  }
                  // The safety layer (safetyAgent.ts, shared/safety.ts): disasters never run; a delete or discarded git work gets a
                  // copy kept first and then runs with nobody asked; only what no copy can undo goes on to the person below.
                  let forced: Risk | undefined;
                  // A personal computer holds more (credential stores, files outside home, the computer itself, every folder delete),
                  // even what the safety layer would only have kept a copy of.
                  const personal = this.opts.personal ? personalRisk(hookInput.tool_name, hookInput.tool_input, defaultCtx(hookInput.cwd || session?.cwd || cwd, [this.workspaceRoot, cwd, session?.cwd ?? cwd])) : null;
                  if (this.opts.safety && !chatUser) {
                    const env = options.env ?? process.env;
                    const g = await this.opts.safety.check(hookInput.tool_name, hookInput.tool_input, { cwd: hookInput.cwd || session?.cwd || cwd, session: resolvedSessionId || tempId, env });
                    if (g.kind === 'deny') return deny(g.message);
                    if (g.kind === 'run' && !personal) {
                      if (g.undoId) this.onUndoKept?.(resolvedSessionId || tempId || '', g.undoId);
                      this.noteApprovedByItself(session, resolvedSessionId || tempId, hookInput.tool_name, hookInput.tool_input);
                      return g.undoId ? { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, additionalContext: g.note } } : {};
                    }
                    if (g.kind === 'run' && g.undoId) this.onUndoKept?.(resolvedSessionId || tempId || '', g.undoId);
                    forced = g.kind === 'hold' ? g.risk : personal ?? undefined;
                  } else if (personal) forced = personal;
                  // Risky: held for the person in every mode that asks (safety net on). Their Approve lets it run without a second prompt.
                  if (!this.opts.riskHolds) {
                    this.noteApprovedByItself(session, resolvedSessionId || tempId, hookInput.tool_name, hookInput.tool_input);
                    return {};
                  }
                  // An Autonomous chat never waits for an Approve (owner, 24 Oct): what cannot be undone is not run, nobody is
                  // asked, the chat says what was left for the person, and the AI carries on with the rest.
                  if (neverAsks(session)) {
                    const risk = riskOf(hookInput.tool_name, hookInput.tool_input, forced);
                    if (!risk) {
                      this.noteApprovedByItself(session, resolvedSessionId || tempId, hookInput.tool_name, hookInput.tool_input);
                      return {};
                    }
                    const key = resolvedSessionId || tempId;
                    if (risk.kind !== 'credentials') {
                      if (key) this.send({ type: 'error', kind: 'notice', sessionId: key, message: `${LEFT_FOR_YOU} ${describeCommand(hookInput.tool_name, hookInput.tool_input).summary}` });
                      return deny(leftForPersonMessage(risk));
                    }
                    // Sign-ins and keys (owner, 14 Nov 2026) are not a dead end. With the fingerprint-confirmed permission "Let AI chats
                    // handle sign-ins" (jarvis set_chat_signin_window, from the app only) it runs, shown in the chat; without it the
                    // request goes to the phone and this waits for the answer, below.
                    const grant = this.opts.credentialGrant?.();
                    const what = describeCommand(hookInput.tool_name, hookInput.tool_input).summary;
                    if (grant) {
                      console.warn(`[credential-grant] allowed under the owner's permission until ${new Date(grant.until).toISOString()}: ${what.slice(0, 200)}`);
                      if (key) this.send({ type: 'error', kind: 'notice', sessionId: key, message: `Used your permission for AI chats to handle sign-ins: ${what}` });
                      return { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'allow' as const, permissionDecisionReason: "The owner's permission for AI chats to handle sign-ins is on." } };
                    }
                    if (key) this.send({ type: 'error', kind: 'notice', sessionId: key, message: `Sent to your phone for approval: ${what}` });
                  }
                  const held = await holdIfRisky(
                    hookInput.tool_name,
                    hookInput.tool_input,
                    (toolName, input, s) => this.permissions.request(resolvedSessionId || tempId || '', toolName, input, undefined, s),
                    hookOpts?.signal ?? new AbortController().signal,
                    undefined,
                    forced,
                  );
                  if (!held) {
                    this.noteApprovedByItself(session, resolvedSessionId || tempId, hookInput.tool_name, hookInput.tool_input);
                    return {};
                  }
                  if (!held.allow) return deny(held.message);
                  return { hookSpecificOutput: { hookEventName: 'PreToolUse' as const, permissionDecision: 'allow' as const, permissionDecisionReason: 'The person approved this command on their phone.' } };
                } catch {
                  // A check that fails must not let the command through.
                  return deny('Escanor could not check this command, so it was blocked.');
                }
              },
            ],
          },
        ],
      },
      canUseTool: async (toolName, toolInput, opts) => {
        if (session?.isolated && isMcpTool(toolName)) return { behavior: 'deny' as const, message: ISOLATED_MCP };
        if (this.isAutoAllowedMcpTool(toolName, toolInput)) return { behavior: 'allow' as const, updatedInput: toolInput };
        // Bypass: the person chose no limits, so nothing waits for the phone. What still reaches here (a question for the
        // person, or anything at all in the root fallback) is answered on the spot; the blocklist hook ran before this.
        if (session?.mode === 'bypassPermissions' && (!this.isRoot || this.rootFallback)) {
          if (this.guarded(session)) {
            const why = autonomousBlockReason(toolName, toolInput, { textAware: this.opts.riskHolds === true });
            if (why) return { behavior: 'deny' as const, message: blockedMessage(why) };
          }
          if (toolName === 'AskUserQuestion') {
            // Autonomous: the question is answered on the spot with the suggested (else the first) option, and the chat says so.
            const auto = session.requested === 'auto' ? autoAnswerQuestions(toolInput) : null;
            if (auto) {
              const key = resolvedSessionId || tempId;
              if (key) this.send({ type: 'error', kind: 'notice', sessionId: key, message: `${APPROVED_BY_ITSELF} answered a question with "${auto.picked.join('", "')}"` });
              return { behavior: 'allow' as const, updatedInput: auto.input };
            }
            return { behavior: 'deny' as const, message: 'Nobody is watching this chat to answer. Do not ask: decide yourself and carry on.' };
          }
          return { behavior: 'allow' as const, updatedInput: toolInput };
        }
        // A managed worker is a sandbox: local work runs freely, so the assistant can edit, run and fix in a loop.
        if (this.opts.managed && isSandboxAutoAllowed(toolName, toolInput, { root: this.workspaceRoot, protectedPaths: this.opts.protectedPaths, fetchAllow: this.opts.fetchAllow })) {
          return { behavior: 'allow' as const, updatedInput: toolInput };
        }
        const decision = await this.permissions.request(
          resolvedSessionId || tempId || '',
          toolName,
          // Only the agent marks a risky-command hold (the hook above); a mark the AI wrote into its own call is not shown.
          withoutHoldMark(toolInput),
          opts.blockedPath,
          opts.signal,
        );
        return decision.behavior === 'allow'
          ? { behavior: 'allow' as const, updatedInput: toolInput }
          : { behavior: 'deny' as const, message: decision.message ?? 'Denied by user' };
      },
    };
    const guide = [this.opts.guide, this.blockedMcp && !input.isolated ? REVOKED_GUIDE : ''].filter(Boolean).join('\n\n');
    if (guide) options.systemPrompt = { type: 'preset', preset: 'claude_code', append: guide };
    if (isResume) options.resume = input.sessionId;
    // Always built here: the Claude process runs model-chosen shell commands, so it must not inherit the hub credentials.
    // Marked as the agent's own chat, so the phone-inbox hook (terminalInbox.ts) does not hold its start up.
    // A Claude account added with an API key runs on that key (kept in its folder).
    const claudeKey = engine === 'claude' && profile.method === 'key' && profile.configDir ? readAccountKey(profile.configDir) : null;
    options.env = childEnv(process.env, { [AGENT_CHAT_ENV]: '1', ...(profile.configDir ? { CLAUDE_CONFIG_DIR: profile.configDir } : {}), ...(claudeKey ? { ANTHROPIC_API_KEY: claudeKey } : {}) });
    if (chatUser) options.spawnClaudeCodeProcess = chatSpawner(chatUser, this.opts.spawnDeps);
    // Bearer keys in the MCP config (this machine's own Escanor key among them) go over a pipe, never on the command line.
    else if ((this.opts.platform ?? process.platform) !== 'win32' && options.mcpServers && Object.keys(options.mcpServers).length > 0) options.spawnClaudeCodeProcess = ownUserSpawner(this.opts.spawnDeps);

    const q =
      engine === 'claude'
        ? (this.opts.query ?? sdkQuery)({ prompt: queue, options })
        : ((this.opts.cliQuery ?? cliQuery)({
            prompt: queue,
            options: {
              provider: engine,
              cwd,
              permissionMode: startMode,
              ...(isResume ? { resume: input.sessionId } : {}),
              model: choices.model,
              configDir: profile.configDir,
              // The Autonomous blocklist, in the tool's own hooks / policy (cliGuard.ts): every turn except in a chat explicitly set to
              // "Bypass permissions" (these tools never ask the phone, so their other modes get it too).
              guarded: () => !(session?.requested === 'bypassPermissions' && session.mode === 'bypassPermissions' && !this.rootFallback),
              // WATCHLIST: a repo-limited chat is held to its repositories by the same hook, whatever its mode.
              writeRepos: () => session?.writeRepos,
              // The safety net: risky commands refused by the same hook in every mode (these tools cannot wait for the phone).
              riskCheck: this.opts.riskHolds === true,
            },
          }) as unknown as ReturnType<typeof sdkQuery>);
    if (compactFirst) {
      queue.push(toUserMessage(COMPACT, undefined));
      this.registry.update(input.sessionId, { turnsSinceCompact: 0, contextPct: undefined });
    }
    queue.push(toUserMessage(input.text, input.images), () => this.ack(input, 'delivered'));

    const liveKey = tempId ?? input.sessionId;
    session = {
      queue,
      cwd,
      mode: startMode,
      confirmed: startMode,
      modeSwitches: 0,
      requested,
      interrupt: () => q.interrupt(),
      setPermissionMode: (mode) => q.setPermissionMode(engine === 'claude' ? this.sdkMode(mode) : mode),
      setModel: (model) => q.setModel(model),
      setEffort: (effort) => q.applyFlagSettings({ effortLevel: effort }),
      setMcpServers: (servers) => q.setMcpServers(servers),
      mcpServerStatus: () => q.mcpServerStatus(),
      close: () => q.close(),
      appliedMcp: JSON.stringify(options.mcpServers ?? {}),
      isolated,
      ...(choices.writeRepos ? { writeRepos: choices.writeRepos } : {}),
      sessionId: isResume ? input.sessionId : '',
      callerKey,
      accountId: profile.id,
      lastInput: input,
      contextUsage: () => q.getContextUsage({ detail: 'summary' }),
      stopped: false,
      limited: false,
      transient: false,
      closing: false,
      compacting: compactFirst ? 1 : 0,
    };
    this.live.set(liveKey, session);
    if (compactFirst) this.beginTurn(session);
    this.beginTurn(session);
    this.verifyStart(session);
    // A model id this Claude Code does not know must not stop the chat from starting: it is switched to once running, and a
    // refusal shows on the chat (see control()).
    if (choices.model) this.control(liveKey, 'Switching the model', (live) => live.setModel(choices.model || undefined));
    if (isResume) this.remember(input.sessionId, choices);
    else this.pendingChoices.set(liveKey, choices);

    void this.pump(q, {
      session,
      tempId,
      cwd,
      accountId: profile.id,
      seedTitle: input.text,
      liveKey,
      getSessionId: () => resolvedSessionId,
      setSessionId: (id) => (resolvedSessionId = id),
    });
  }

  private async pump(
    q: AsyncIterable<unknown>,
    ctx: {
      session: LiveSession;
      tempId?: string;
      cwd: string;
      accountId: string;
      seedTitle: string;
      liveKey: string;
      getSessionId: () => string;
      setSessionId: (id: string) => void;
    },
  ): Promise<void> {
    let sleptHandled = false;
    const partial = new PartialText((text) =>
      this.send({ type: 'sdk_partial', sessionId: ctx.getSessionId() || ctx.tempId || ctx.liveKey, tempId: ctx.tempId, text }),
    );
    try {
      for await (const message of q) {
        if ((message as { type?: string }).type === 'stream_event') {
          partial.feed(message as Parameters<PartialText['feed']>[0]);
          continue;
        }
        const msg = message as {
          type?: string;
          subtype?: string;
          session_id?: string;
          mcp_servers?: Array<{ name: string; status: string; error?: string }>;
        };
        // Rows only this agent writes (the fix's own test report, FLOW3) are never taken from Claude's side, whatever it prints.
        if (typeof msg.type === 'string' && AGENT_ONLY_ROW_TYPES.has(msg.type)) {
          console.warn(`Dropped a '${msg.type}' message that came from Claude: only the agent itself sends those.`);
          continue;
        }
        if (msg.type === 'system' && msg.subtype === 'init' && Array.isArray(msg.mcp_servers)) {
          this.mcpSessionStatus.set(ctx.session, new Map(msg.mcp_servers.map((s) => [s.name, { status: s.status, error: s.error }])));
          this.reportMcpStatus();
          // MCP servers connect in the background, so init can say 'pending'. Ask again once they have
          // had time to settle, or the hub would show "pending" for as long as the chat stays open.
          if (msg.mcp_servers.some((s) => s.status === 'pending')) this.refreshMcpStatusLater(ctx.session);
        }
        if (msg.type === 'system' && msg.subtype === 'init' && msg.session_id && !ctx.getSessionId()) {
          const sessionId = msg.session_id;
          ctx.setSessionId(sessionId);
          ctx.session.sessionId = sessionId;
          const title = titleFrom(ctx.seedTitle);
          const at = new Date(this.now()).toISOString();
          this.registry.upsert({
            sessionId,
            cwd: ctx.cwd,
            title,
            createdAt: at,
            accountId: ctx.accountId,
            lastActiveAt: at,
            ...definedOnly(this.pendingChoices.get(ctx.liveKey)),
            ...(this.turns.has(ctx.session) ? { turnOpen: true as const } : {}),
          });
          this.pendingChoices.delete(ctx.liveKey);
          if (ctx.liveKey !== sessionId) {
            const entry = this.live.get(ctx.liveKey);
            if (entry) {
              this.live.delete(ctx.liveKey);
              this.live.set(sessionId, entry);
            }
          }
          if (ctx.tempId) {
            this.permissions.rename(ctx.tempId, sessionId);
            this.send({ type: 'session_created', tempId: ctx.tempId, sessionId, cwd: ctx.cwd, title, accountId: ctx.accountId });
          }
        }
        // The summary Claude Code writes when the agent compacts a chat, and the command's echo, are not the person's words.
        const synthetic = message as { isSynthetic?: boolean; isReplay?: boolean };
        if (msg.type === 'user' && ctx.session.compacting > 0 && (synthetic.isSynthetic === true || synthetic.isReplay === true)) continue;
        if (msg.type === 'assistant') {
          // AUTORESUME: the AI service failed for now (its final word after Claude Code's own retries); a later reply clears it.
          const err = (message as { error?: string }).error;
          ctx.session.transient = typeof err === 'string' && TRANSIENT_ERRORS.has(err);
          if (signedOutReply(message)) ctx.session.signedOut = true;
        }
        ctx.session.heardAt = this.now();
        if (msg.type === 'system' && msg.subtype === 'background_tasks_changed') {
          // The full set of what still runs in the background, replaced each time.
          const tasks = (message as { tasks?: Array<{ ambient?: boolean } | null> }).tasks;
          ctx.session.background = Array.isArray(tasks) ? tasks.filter((t) => t && !t.ambient).length : 0;
          this.armStale(ctx.session);
          this.notifyWork();
          // Its background work is over: a message waiting for a free slot may start now.
          if (!inBackground(ctx.session, this.now()) && !this.turns.has(ctx.session)) this.drain();
        }
        if ((msg.type === 'assistant' || msg.type === 'user') && (ctx.session.wake ??= new WakeWatch(() => this.now())).feed(message)) {
          this.notifyWork();
          this.drainAfterWake(ctx.session);
        }
        if (msg.type === 'rate_limit_event') this.noteUsage(ctx.session, (message as { rate_limit_info?: { status?: string; resetsAt?: number } }).rate_limit_info);
        if (msg.type === 'system' && msg.subtype === 'compact_boundary' && ctx.getSessionId()) {
          this.registry.update(ctx.getSessionId(), { turnsSinceCompact: 0, contextPct: undefined });
        }
        if (msg.type === 'result') this.noteTurnResult(ctx.session, ctx.getSessionId(), message as { subtype?: string; is_error?: boolean; result?: string });
        if (msg.type === 'assistant' || msg.type === 'result') partial.reset();
        const pv = ctx.getSessionId() ? messagePreview(message) : null;
        if (pv) this.registry.update(ctx.getSessionId(), { preview: pv });
        this.send({
          type: 'sdk_message',
          sessionId: ctx.getSessionId() || ctx.tempId || ctx.liveKey,
          tempId: ctx.tempId,
          message,
        });
        if (msg.type === 'result') this.endTurn(ctx.session);
        // Its turns finished after the machine woke: it was not cut off by the sleep after all.
        if (msg.type === 'result' && !this.turns.has(ctx.session)) this.sleptMidTurn.delete(ctx.session);
        if (msg.type === 'result' && ctx.getSessionId()) this.onTurnEnded?.(ctx.getSessionId(), ctx.cwd);
        if (msg.type === 'result') this.verifyAfterTurn(ctx.session, ctx.getSessionId());
        if (msg.type === 'result' && ctx.session.signedOut) this.recoverSignIn(ctx.session, ctx.getSessionId());
        // AUTORESUME: cut off by the limit and nothing else for it here: its "continue" waits for the reset.
        if (msg.type === 'result' && !this.turns.has(ctx.session) && this.registry.get(ctx.getSessionId())?.cutOff?.reason === 'limit') this.resumeCutOff();
      }
    } catch (err) {
      const slept = this.sleptMidTurn.delete(ctx.session);
      if (slept) sleptHandled = true;
      if (ctx.getSessionId() && !ctx.session.closing && !this.stopping) {
        this.registry.update(ctx.getSessionId(), { lastActiveAt: new Date(this.now()).toISOString(), lastOutcome: slept || ctx.session.stopped ? 'interrupted' : 'error' });
      }
      this.send({
        type: 'error',
        sessionId: ctx.getSessionId() || undefined,
        tempId: ctx.tempId,
        message: slept && !this.stopping ? this.sleptNotice(ctx.getSessionId()) : err instanceof Error ? err.message : String(err),
      });
    } finally {
      if (this.sleptMidTurn.delete(ctx.session)) {
        sleptHandled = true;
        this.send({ type: 'error', sessionId: ctx.getSessionId() || undefined, tempId: ctx.tempId, message: this.stopping ? SLEPT_MESSAGE : this.sleptNotice(ctx.getSessionId()) });
      }
      // AUTORESUME: its process ended mid-turn without a result (and not because the agent is stopping or the machine slept).
      if (!sleptHandled && !this.stopping && this.turns.has(ctx.session)) this.settleTurnOpen(ctx.getSessionId());
      this.clearTurns(ctx.session);
      this.verifier.drop(ctx.session);
      partial.reset();
      const sessionId = ctx.getSessionId();
      // Cards still waiting for an answer belong to a session that no longer exists: deny them and drop the entries.
      for (const key of new Set([sessionId, ctx.tempId, ctx.liveKey])) if (key) this.permissions.dropSession(key);
      // Only this run's own entries: the same chat may already have been resumed in a new process (it was closed to make room).
      for (const key of [ctx.liveKey, sessionId]) if (key && this.live.get(key) === ctx.session) this.live.delete(key);
      this.pendingChoices.delete(ctx.liveKey);
      this.mcpSessionStatus.delete(ctx.session);
      this.reportMcpStatus();
      this.send({ type: 'session_ended', sessionId: sessionId || ctx.tempId || ctx.liveKey });
      if (sessionId) this.onTurnEnded?.(sessionId, ctx.cwd);
      const next = ctx.session.onGone;
      ctx.session.onGone = undefined;
      if (next && !this.stopping) next();
      this.drain(); // a slot is free
    }
  }

  /**
   * The turn stopped at "Not logged in": the account is marked signed out, and the chat goes on under a signed-in account with the
   * person's message sent again, by itself. With no signed-in account left, the person is told plainly what to do.
   */
  private recoverSignIn(session: LiveSession, sessionId: string): void {
    session.signedOut = false;
    const from = this.resolveProfile(session.accountId);
    if (providerOf(from) !== 'claude') return;
    this.opts.signIn?.mark(from);
    const input = session.lastInput;
    const to = this.opts.chatUsers ? undefined : this.signedInInstead(from);
    const tell = (message: string) => this.send({ type: 'error', kind: 'notice', sessionId: sessionId || undefined, tempId: sessionId ? undefined : input?.tempId, message });
    if (!to) return tell(NO_SIGNED_IN_ACCOUNT);
    if (!input || session.closing) return tell(signedOutNewChats(this.accountName(from), this.accountName(to)));
    const inputId = `agent:signin:${randomUUID()}`;
    let again: HubUserInput;
    if (sessionId && this.moveChat(sessionId, from)) {
      // Its history now sits under `to` as well: the chat resumes there.
      again = { ...input, sessionId, tempId: undefined, fresh: undefined, accountId: to.id, inputId };
    } else if (!sessionId || !findTranscript(sessionId, [profileConfigDir(from)])) {
      // Nothing written yet (it stopped at its first message): the same chat starts again under `to`, and the hub is told the new
      // conversation IS this chat (session_created names this id as the temp id).
      if (sessionId) this.registry.remove(sessionId);
      const id = sessionId || input.tempId || input.sessionId;
      again = { ...input, sessionId: id, tempId: id, fresh: true, accountId: to.id, inputId };
    } else {
      return tell(signedOutNewChats(this.accountName(from), this.accountName(to)));
    }
    tell(signedOutMoved(this.accountName(from), this.accountName(to)));
    session.onGone = () => this.handleUserInput(again);
    session.closing = true;
    try {
      session.close();
    } catch {
      // already gone: the finally of its pump still runs onGone
    }
  }

  /** Claude's word on the account's usage. Rejected: new work waits for the reset. Allowed again: what waited goes now. */
  private noteUsage(session: LiveSession, info: { status?: string; resetsAt?: number } | undefined): void {
    if (!info) return;
    this.usage.note(session.accountId, info, this.now());
    if (info.status === 'rejected') {
      session.limited = true;
      // The whole account waits, not just this chat: the reset time is Claude's own word.
      const at = this.usage.state(session.accountId, this.now()).resetsAt;
      if (at !== undefined) this.holdAccount(session.accountId, at, 'message');
    }
    if (info.status === 'allowed') {
      this.limitHolds.lift(session.accountId, 'message');
      this.drain();
    }
  }

  /** After each turn: when and how it ended (for "continue the recent chat"), and how full its context now is. */
  private noteTurnResult(session: LiveSession, sessionId: string, result: { subtype?: string; is_error?: boolean; result?: string }): void {
    // Turns end in the order they were sent, so the first result after a /compact is the compaction's.
    const wasCompaction = session.compacting > 0;
    if (wasCompaction) session.compacting--;
    const failed = result.is_error === true || (result.subtype ?? '').startsWith('error');
    if (failed && !session.stopped && signedOutText(result.result)) session.signedOut = true;
    // A limit told only in words (an API key's rate or quota limit, the Escanor plan's): the reset time in the text, else a short wait.
    const words = failed && !session.stopped && typeof result.result === 'string' ? parseLimitText(result.result, this.now()) : null;
    const outcome = !failed ? 'ok' : session.stopped ? 'interrupted' : session.limited || words || this.usage.state(session.accountId, this.now()).status === 'rejected' ? 'rate_limited' : 'error';
    if (words && !session.limited) {
      session.limited = true;
      const at = words.resetsAt ?? this.now() + (words.kind === 'rate' ? RATE_WAIT_MS : UNKNOWN_RESET_MS);
      this.usage.note(session.accountId, { status: 'rejected', resetsAt: at }, this.now());
      this.holdAccount(session.accountId, this.usage.state(session.accountId, this.now()).resetsAt ?? at, 'message');
    }
    const transient = session.transient && !session.stopped && outcome !== 'rate_limited';
    session.stopped = false;
    session.limited = false;
    session.transient = false;
    if (!sessionId) return;
    const turns = (this.registry.get(sessionId)?.turnsSinceCompact ?? 0) + (wasCompaction ? 0 : 1);
    this.registry.update(sessionId, { lastActiveAt: new Date(this.now()).toISOString(), lastOutcome: outcome, turnsSinceCompact: turns });
    // AUTORESUME: cut off by the limit = goes on by itself after the reset; fine or stopped by the person = nothing to pick up.
    // An error keeps a cut-off as it was (the next connect tries again, a few times at most).
    if (outcome === 'rate_limited' && !wasCompaction) {
      const resetsAt = this.usage.state(session.accountId, this.now()).resetsAt;
      const first = this.registry.get(sessionId)?.cutOff?.reason !== 'limit';
      this.markCutOff(sessionId, 'limit', { resetsAt });
      if (first && this.autoResumeOn) this.send({ type: 'error', kind: 'notice', sessionId, message: waitNotice('limit', resetsAt) });
    } else if (transient && !wasCompaction) {
      // The AI service failed: tried again by itself a little later (1, 5, then 15 minutes), told once per incident.
      const prev = this.registry.get(sessionId)?.cutOff;
      const retryAt = this.now() + errorBackoffMs(prev?.reason === 'error' ? prev.tries : 0);
      this.markCutOff(sessionId, 'error', { retryAt });
      const cut = this.registry.get(sessionId)?.cutOff;
      if (cut && prev?.reason !== 'error' && this.autoResumeOn) this.send({ type: 'error', kind: 'notice', sessionId, message: waitNotice('error', retryAt) });
      this.scheduleRetry();
    } else if (outcome === 'ok' || outcome === 'interrupted') this.clearCutOff(sessionId);
    // Never in the way of the turn itself: an older Claude Code without the call, or one that fails, just reports nothing.
    withTimeout(Promise.resolve().then(() => session.contextUsage()), MCP_APPLY_TIMEOUT_MS)
      .then((u) => {
        const pct = typeof u?.percentage === 'number' ? u.percentage : u?.totalTokens && u?.maxTokens ? (u.totalTokens / u.maxTokens) * 100 : NaN;
        if (Number.isFinite(pct)) this.registry.update(sessionId, { contextPct: Math.round(pct) });
        this.sendStats(session, sessionId);
      })
      .catch(() => {
        // an older Claude Code, or the chat closed: the turn count still triggers compaction
        this.sendStats(session, sessionId);
      });
  }

  /** What the chat's header shows (see chatStats): sent as a message in the chat, so no hub needs to know about it. */
  private sendStats(session: LiveSession, sessionId: string): void {
    this.send({
      type: 'sdk_message',
      sessionId,
      message: chatStats(sessionId, this.registry.get(sessionId), this.limits, this.usage.state(session.accountId, this.now())),
    });
  }

  /** The phone's answer to a prompt: whether it reached a chat that was waiting for it (permission_ack). */
  resolvePermission(requestId: string, behavior: PermissionDecision, message?: string): { delivered: boolean; sessionId?: string } {
    return this.permissions.resolve(requestId, behavior, message);
  }

  /** An approval card for something the agent itself is about to run (not inside a chat); true only for "allow". Interrupted = no. */
  async askPermission(key: string, toolName: string, input: Record<string, unknown>, signal: AbortSignal): Promise<boolean> {
    return (await this.permissions.request(key, toolName, input, undefined, signal)).behavior === 'allow';
  }

  /** Prompts still waiting for an answer here (hello.pending). */
  pendingPermissions() {
    return this.permissions.pendingList();
  }

  /** Announce the waiting prompts again, after the hello of a new connection. */
  resendPendingPermissions(): void {
    this.permissions.resendPending();
  }

  interrupt(rawId: string): void {
    const sessionId = this.resolveId(rawId);
    // AUTORESUME: the person stopped it: never picked up on its own (now, or after a restart).
    this.registry.update(sessionId, { turnOpen: undefined, cutOff: undefined });
    // Stopping a chat that waits on this machine drops what waited (each is answered, so no app keeps waiting for it).
    const dropped = this.waiting.filter((w) => w.input.sessionId === sessionId);
    if (dropped.length) {
      this.waiting = this.waiting.filter((w) => !dropped.includes(w));
      for (const w of dropped) this.ack(w.input, 'refused', STOPPED_WHILE_WAITING);
      this.queueChanged();
    }
    // A stop must never leave the machine held awake, whether or not the run answers it with a result.
    const live = this.live.get(sessionId);
    if (!live) {
      // Nothing of this chat runs in this agent, so there is nothing here to stop. Say so instead of staying silent: a chat busy
      // in its terminal can only be stopped there; any other "Working" the phone still shows (a run lost in a restart) settles.
      if (this.isRunningElsewhere?.(sessionId)) this.send({ type: 'error', kind: 'notice', sessionId, message: STOP_IN_TERMINAL });
      else this.send({ type: 'session_ended', sessionId });
      return;
    }
    live.stopped = true;
    this.clearTurns(live);
    this.control(sessionId, 'Stop', (live) => live.interrupt());
  }

  // A change is remembered for the chat even when it is not running, so the next message resumes it with that change
  // (it used to be dropped, and a resumed chat ran with the defaults whatever the phone showed).
  setPermissionMode(rawId: string, requested: PermissionMode): void {
    const sessionId = this.resolveId(rawId);
    this.remember(sessionId, { permissionMode: requested });
    const live = this.live.get(sessionId);
    if (!live) return;
    const mode = this.effectiveMode(requested);
    const turn = ++live.modeSwitches;
    // Every run (not as root) was launched with the opt-in, so even a switch to bypass is just Claude Code's own set-mode.
    // Order matters for safety. A STRICTER state (the blocklist and the phone's approval now apply: anything but an explicit
    // "Bypass permissions", and never a chat that was not already answering by itself) takes effect here at once, before Claude
    // Code is told. Until Claude Code confirms, `confirmed` keeps the mode it still runs in, so a chat leaving bypass stays
    // guarded by the hook (Claude Code in bypass never calls canUseTool); if Claude Code refuses, it stays guarded for good and
    // the error shows. A LOOSER one (into bypass, or into answering by itself) takes effect only once Claude Code has taken it,
    // and only if no other switch was asked for in the meantime.
    const looser = requested === 'bypassPermissions' || (mode === 'bypassPermissions' && live.mode !== 'bypassPermissions');
    if (!looser) {
      live.requested = requested;
      live.mode = mode;
      void this.applyMcpServers(); // leaving Autonomous: Escanor's server stops hearing "auto" at once
    }
    this.control(sessionId, 'Changing the permission mode', async (l) => {
      await l.setPermissionMode(mode);
      l.confirmed = mode;
      if (looser && l.modeSwitches === turn) {
        l.requested = requested;
        l.mode = mode;
        void this.applyMcpServers(); // entering Autonomous, once Claude Code has taken it
      }
    });
  }

  /**
   * The machine's permissions as the owner set them from any device (machinePermissions.ts). Each is the narrowing of what this agent
   * was started with: it never adds a power the computer does not have (a server has no desktop to control). Chats started from now on
   * use it; a chat already running keeps the tools it began with.
   */
  setPolicy(p: { computerControl?: boolean; meshTools?: boolean; defaultMode?: PermissionMode | null }): void {
    if (p.computerControl !== undefined) this.opts.computerControl = this.base.computerControl && p.computerControl;
    if (p.meshTools !== undefined) this.opts.meshTools = this.base.meshTools && p.meshTools;
    if (p.defaultMode !== undefined) this.opts.defaultMode = p.defaultMode ?? this.base.defaultMode;
  }

  /** What this computer is allowed right now, for the machine permissions report. */
  policy(): { computerControl: boolean; meshTools: boolean; defaultMode: PermissionMode } {
    return { computerControl: !!this.opts.computerControl, meshTools: !!this.opts.meshTools, defaultMode: this.opts.defaultMode ?? 'default' };
  }

  setModel(rawId: string, model: string | undefined): void {
    const sessionId = this.resolveId(rawId);
    this.remember(sessionId, { model: model ?? '' });
    this.control(sessionId, 'Switching the model', (live) => live.setModel(model));
  }

  setEffort(rawId: string, effort: EffortLevel | null): void {
    const sessionId = this.resolveId(rawId);
    this.remember(sessionId, { effort });
    this.control(sessionId, 'Changing the effort', (live) => live.setEffort(effort));
  }

  /** Mode, model and effort a new chat started with, until Claude names it (then they go into the registry). */
  private pendingChoices = new Map<string, SessionChoices>();

  private remember(sessionId: string, choices: SessionChoices): void {
    const pending = this.pendingChoices.get(sessionId);
    if (pending) {
      this.pendingChoices.set(sessionId, { ...pending, ...definedOnly(choices) });
      return;
    }
    this.registry.update(sessionId, definedOnly(choices));
  }

  // The SDK rejects control requests it can't honour (e.g. a model id its catalog doesn't know). Left unhandled, that
  // rejection kills the whole agent and every session on it, so report it on the session instead.
  private control(sessionId: string, what: string, run: (live: LiveSession) => Promise<unknown>): void {
    const live = this.live.get(sessionId);
    if (!live) return;
    run(live).catch((err) => {
      this.send({ type: 'error', sessionId, message: `${what} failed: ${err instanceof Error ? err.message : String(err)}` });
    });
  }
}

type WaitMeta = { id: string; queuedAt: number };

/** Marks the standing instructions an app adds after what the person typed (autonomous chats); apps hide everything from it on. */
const HIDDEN_MARKER = '[escanor:auto]';

/** What the person typed, and the hidden instructions after it (with the blank line before them), or '' when there are none. */
export function splitHidden(text: string): { typed: string; hidden: string } {
  const at = text.indexOf(HIDDEN_MARKER);
  if (at < 0) return { typed: text, hidden: '' };
  const typed = text.slice(0, at).trimEnd();
  return { typed, hidden: typed ? text.slice(typed.length) : `\n\n${text.slice(at)}` };
}

/** A message's first words on one line, for the queue (never the whole message). */
function previewOf(text: string): string {
  const oneLine = text.trim().replace(/\s+/g, ' ');
  return oneLine.length > QUEUE_PREVIEW_CHARS ? `${oneLine.slice(0, QUEUE_PREVIEW_CHARS - 3)}...` : oneLine;
}

type SessionChoices = { permissionMode?: PermissionMode; model?: string; effort?: EffortLevel | null; isolated?: true; writeRepos?: string[] };

function definedOnly(c: SessionChoices | undefined): SessionChoices {
  const out: SessionChoices = {};
  if (!c) return out;
  if (c.permissionMode !== undefined) out.permissionMode = c.permissionMode;
  if (c.model !== undefined) out.model = c.model;
  if (c.effort !== undefined) out.effort = c.effort;
  if (c.isolated === true) out.isolated = true;
  if (c.writeRepos !== undefined) out.writeRepos = [...c.writeRepos];
  return out;
}
