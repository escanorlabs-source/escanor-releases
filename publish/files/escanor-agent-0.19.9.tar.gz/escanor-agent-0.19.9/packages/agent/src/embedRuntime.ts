/**
 * The handle embedded mode (embed.ts) uses to look at and steer the running agent. index.ts registers it once everything is
 * built; a normal install never reads it. Kept apart from index.ts so the control channel can be tested with a fake runtime.
 */
import type { HubLinkStatus } from './wsClient.js';

export type AgentRuntime = {
  agentVersion: string;
  /** The hub socket is open now. */
  connected: () => boolean;
  sessions: () => { total: number; active: number };
  reconnect: () => void;
  setToken: (token: string) => void;
  /** Stops chats and tools cleanly and closes the hub link. Does not exit the process. */
  stop: () => void;
};

let runtime: AgentRuntime | null = null;
const statusListeners = new Set<(s: HubLinkStatus) => void>();
let lastStatus: HubLinkStatus | null = null;

export function registerRuntime(r: AgentRuntime): void {
  runtime = r;
}
export function getRuntime(): AgentRuntime | null {
  return runtime;
}

/** index.ts forwards every hub link change here. */
export function publishLinkStatus(s: HubLinkStatus): void {
  lastStatus = s;
  for (const l of statusListeners) {
    try {
      l(s);
    } catch {
      // a listener must not break the link
    }
  }
}
export function onLinkStatus(l: (s: HubLinkStatus) => void): () => void {
  statusListeners.add(l);
  return () => statusListeners.delete(l);
}
export function currentLinkStatus(): HubLinkStatus | null {
  return lastStatus;
}

/** The Escanor app that started this agent (embed.ts) hands in how to ask it for an update; a stand-alone agent has none. */
let updateRequester: (() => boolean) | null = null;
export function setUpdateRequester(f: (() => boolean) | null): void {
  updateRequester = f;
}
/** Asks the host app to update itself. False when there is no host app (the agent runs on its own). */
export function requestHostUpdate(): boolean {
  try {
    return updateRequester ? updateRequester() : false;
  } catch {
    return false;
  }
}
