import { readFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import type { AccountUsage } from '@remote-harness/shared';
import { providerOf, type ClaudeProfile } from './profiles.js';
import { isManaged, switchOn } from './switches.js';

/**
 * VAULT6: how much of each Claude account's usage window is used, so the phone can send a new chat to the account with the most
 * room. Read-only and only the person's own accounts: each profile's own OAuth login (its `.credentials.json`) asks Anthropic's
 * usage endpoint, nothing else. The token is read for the request and never logged, stored or sent anywhere but that endpoint.
 * At most one look per profile every 5 minutes (on demand after a chat ends, at least MIN_GAP_MS apart), longer after errors.
 * On by default (off by default in an Escanor worker container, ESCANOR_MANAGED=1); ESCANOR_ACCOUNT_USAGE=0 turns it off.
 */

export const USAGE_URL = 'https://api.anthropic.com/api/oauth/usage';
export const POLL_MS = 5 * 60_000;
/** After a chat ends the accounts are looked at again, but never sooner than this after the last look. */
export const MIN_GAP_MS = 60_000;
export const MAX_BACKOFF_MS = 60 * 60_000;
/** The anthropic endpoint answers 429 when several accounts are read at once: one account at a time, this far apart. */
export const STAGGER_MS = 4_000;
/** After a 429 the next try is no sooner than this (doubling after each one, up to MAX_BACKOFF_MS). */
export const RATE_LIMIT_BACKOFF_MS = 10 * 60_000;
/** A rise of this many points of the five-hour window between two readings, with none of our chats using the account, is someone else's use. */
export const OUTSIDE_RISE_PTS = 3;
const TIMEOUT_MS = 10_000;

export type UsageFetch = (url: string, init: { headers: Record<string, string>; signal?: AbortSignal }) => Promise<{ status: number; ok: boolean; headers?: { get(name: string): string | null }; json(): Promise<unknown> }>;

export function accountUsageEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchOn(env.ESCANOR_ACCOUNT_USAGE, !isManaged(env));
}

/** Where a profile keeps its login: its config dir, or (the default profile) the dir Claude uses when none is set. */
export function profileConfigDir(p: ClaudeProfile, env: NodeJS.ProcessEnv = process.env): string {
  return p.configDir ?? (env.CLAUDE_CONFIG_DIR?.trim() || join(homedir(), '.claude'));
}

const pct = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) ? Math.min(100, Math.max(0, Math.round(v * 10) / 10)) : null);
const iso = (v: unknown): string | null => {
  if (typeof v !== 'string') return null;
  const t = Date.parse(v);
  return Number.isFinite(t) ? new Date(t).toISOString() : null;
};

/** The endpoint's answer as the numbers this keeps (null when there is no five-hour figure). */
export function parseUsage(body: unknown, checkedAt: string): AccountUsage | null {
  if (!body || typeof body !== 'object') return null;
  const b = body as Record<string, unknown>;
  const five = b.five_hour as Record<string, unknown> | null | undefined;
  const used = pct(five?.utilization);
  if (used === null) return null;
  const seven = b.seven_day as Record<string, unknown> | null | undefined;
  const sevenPct = pct(seven?.utilization);
  return {
    five_hour_pct: used,
    resets_at: iso(five?.resets_at),
    ...(sevenPct !== null ? { seven_day_pct: sevenPct, seven_day_resets_at: iso(seven?.resets_at) } : {}),
    checked_at: checkedAt,
  };
}

type Entry = { usage: AccountUsage | null; nextAt: number; failures: number; busy: boolean; failedStatus: number | null; usedByUs: boolean; outside: boolean };

export class AccountUsagePoller {
  private entries = new Map<string, Entry>();
  private timer: NodeJS.Timeout | null = null;
  private running = false;
  private fetchFn: UsageFetch;
  private now: () => number;
  private readToken: (p: ClaudeProfile) => Promise<string | null>;

  constructor(
    private profiles: ClaudeProfile[],
    private o: {
      fetch?: UsageFetch;
      now?: () => number;
      /** Test hook: the access token of a profile. */
      readToken?: (p: ClaudeProfile) => Promise<string | null>;
      pollMs?: number;
      minGapMs?: number;
      onChange?: () => void;
      /** The account ids a chat is running with right now. */
      activeAccounts?: () => Iterable<string>;
      /** Test hook: the wait between two accounts' readings. */
      staggerMs?: number;
    } = {},
  ) {
    this.fetchFn = o.fetch ?? ((url, init) => fetch(url, init) as ReturnType<UsageFetch>);
    this.now = o.now ?? Date.now;
    this.readToken = o.readToken ?? readAccessToken;
  }

  start(): void {
    if (this.timer) return;
    void this.pollDue();
    this.timer = setInterval(() => void this.pollDue(), 30_000);
    this.timer.unref();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /** The last good figures per profile id (a profile never read is absent). */
  snapshot(): Record<string, AccountUsage> | undefined {
    const out: Record<string, AccountUsage> = {};
    const active = new Set(this.o.activeAccounts?.() ?? []);
    for (const [id, e] of this.entries) {
      if (!e.usage) continue;
      out[id] = { ...e.usage, ...(active.has(id) ? { in_use: true } : {}), ...(e.outside ? { outside_use: true } : {}), ...(e.failures > 0 ? { stale: true } : {}) };
    }
    return Object.keys(out).length > 0 ? out : undefined;
  }

  /** A chat ended: its account used some of its room, look again (still not more often than the minimum gap). */
  chatEnded(accountId?: string): void {
    for (const [id, e] of this.entries) if (!accountId || id === accountId) e.usedByUs = true;
    const gap = this.o.minGapMs ?? MIN_GAP_MS;
    for (const p of this.claudeSignIns()) {
      const e = this.entry(p.id);
      if (e.failures === 0 && e.nextAt - (this.o.pollMs ?? POLL_MS) + gap <= this.now()) e.nextAt = this.now();
    }
    void this.pollDue();
  }

  /** Looks at every profile whose time has come. */
  async pollDue(): Promise<void> {
    if (this.running) return;
    this.running = true;
    try {
      const stagger = this.o.staggerMs ?? STAGGER_MS;
      const due = this.claudeSignIns().filter((p) => this.entry(p.id).nextAt <= this.now() && !this.entry(p.id).busy);
      for (let i = 0; i < due.length; i++) {
        if (i > 0 && stagger > 0) await new Promise((r) => setTimeout(r, stagger));
        await this.pollOne(due[i]!);
      }
    } finally {
      this.running = false;
    }
  }

  /** Only Claude accounts signed in with Claude have this usage to read: never ChatGPT / Gemini ones, nor one on an API key. */
  private claudeSignIns(): ClaudeProfile[] {
    return this.profiles.filter((p) => providerOf(p) === 'claude' && p.method !== 'key');
  }

  private entry(id: string): Entry {
    let e = this.entries.get(id);
    if (!e) this.entries.set(id, (e = { usage: null, nextAt: 0, failures: 0, busy: false, failedStatus: null, usedByUs: false, outside: false }));
    return e;
  }

  private async pollOne(p: ClaudeProfile): Promise<void> {
    const e = this.entry(p.id);
    e.busy = true;
    if (new Set(this.o.activeAccounts?.() ?? []).has(p.id)) e.usedByUs = true;
    const poll = this.o.pollMs ?? POLL_MS;
    let retryAfterMs = 0;
    try {
      const token = await this.readToken(p);
      if (!token) throw new Error('no login');
      const res = await this.fetchFn(USAGE_URL, {
        headers: { Authorization: `Bearer ${token}`, 'anthropic-beta': 'oauth-2025-04-20' },
        signal: AbortSignal.timeout(TIMEOUT_MS),
      });
      if (!res.ok) {
        const ra = Number(res.headers?.get('retry-after'));
        if (Number.isFinite(ra) && ra > 0) retryAfterMs = ra * 1000;
        e.failedStatus = res.status;
        throw new Error(`status ${res.status}`);
      }
      const usage = parseUsage(await res.json(), new Date(this.now()).toISOString());
      if (!usage) throw new Error('no five-hour figure');
      // Someone else is using this account: the window climbed (same window, so not a reset) and none of our chats used it since the last reading.
      const before = e.usage;
      if (before && before.resets_at === usage.resets_at) {
        if (usage.five_hour_pct - before.five_hour_pct >= OUTSIDE_RISE_PTS && !e.usedByUs) e.outside = true;
        else if (usage.five_hour_pct - before.five_hour_pct < OUTSIDE_RISE_PTS && !e.usedByUs) e.outside = false;
      } else if (before) e.outside = false;
      e.usedByUs = new Set(this.o.activeAccounts?.() ?? []).has(p.id);
      e.usage = usage;
      e.failedStatus = null;
      e.failures = 0;
      e.nextAt = this.now() + poll;
      this.o.onChange?.();
    } catch (err) {
      // Never the token: only what went wrong in words.
      e.failures += 1;
      // A rate limit (429) waits longer than another failure: asking again soon only keeps it limiting us.
      const base = e.failedStatus === 429 ? Math.max(poll, RATE_LIMIT_BACKOFF_MS) : poll;
      const backoff = Math.min(MAX_BACKOFF_MS, base * 2 ** Math.min(e.failures - 1, 6));
      e.nextAt = this.now() + Math.min(MAX_BACKOFF_MS, Math.max(backoff, retryAfterMs));
      if (e.failures === 1) console.warn(`Account usage for "${p.id}" not read: ${err instanceof Error ? err.message.replace(/Bearer\s+\S+/g, 'Bearer ***') : 'failed'}`);
    } finally {
      e.busy = false;
    }
  }
}

async function readAccessToken(p: ClaudeProfile): Promise<string | null> {
  try {
    const j = JSON.parse(await readFile(join(profileConfigDir(p), '.credentials.json'), 'utf8')) as { claudeAiOauth?: { accessToken?: unknown } };
    const t = j.claudeAiOauth?.accessToken;
    return typeof t === 'string' && t ? t : null;
  } catch {
    return null;
  }
}
