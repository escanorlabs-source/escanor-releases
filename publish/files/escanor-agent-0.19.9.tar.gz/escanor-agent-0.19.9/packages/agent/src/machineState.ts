import { execFile } from 'node:child_process';
import { readdirSync, readFileSync, readlinkSync, statfsSync, statSync } from 'node:fs';
import { cpus, freemem, loadavg, totalmem, uptime } from 'node:os';
import { join, relative } from 'node:path';
import type { AgentToHubMessage, MachineRunResult, MachineState } from '@remote-harness/shared';
import { readClaudeProcs, type ClaudeProc } from './claudeProcs.js';
import { childEnv } from './childEnv.js';
import { oneLine } from './redact.js';
import { batteryExec, readBattery } from './battery.js';
import { presenceBucket, type PresenceReport } from './presence.js';

/**
 * DEV7: what runs on this machine, for the phone's "Now on this PC": listening ports and dev servers, Docker containers, the git
 * state of the repositories in the workspace, test/build runs, coding agents, and health. Sent as `machine_state` every 60 s and
 * on change (looked at every 15 s; git and Docker once a minute). Cheap, and nothing secret: no environment values and no
 * command lines; a process is named by its program or a known tool word ("next dev", "pytest"), never by its arguments.
 */

export const STATE_INTERVAL_MS = 60_000;
export const STATE_LOOK_MS = 15_000;
const REPO_RESCAN_MS = 10 * 60_000;
const EXEC_TIMEOUT_MS = 4_000;
const LIMITS = { ports: 50, devServers: 20, docker: 30, repos: 40, running: 20, agents: 30 };

export type ProcInfo = { pid: number; argv: string[]; cwd?: string };

export type MachineDeps = {
  exec: (cmd: string, args: string[], timeoutMs: number) => Promise<{ code: number; stdout: string }>;
  /** This user's processes (pid and argv); cwd is looked up only for the few that matter (cwdOf). */
  procs: () => ProcInfo[];
  cwdOf: (pid: number) => string | undefined;
  claudeProcs: () => Map<string, ClaudeProc>;
  /** Repositories under the workspace, relative paths ('.' = the workspace itself). */
  repos: (root: string) => string[];
  disk: (path: string) => { usedPct: number; freeGb: number } | null;
  battery: () => Promise<{ pct: number; charging: boolean } | null> | { pct: number; charging: boolean } | null;
  /** What changes when a repository does (its index, HEAD, fetched refs, top folder): git is asked again only when this changed. */
  repoStamp?: (root: string, path: string) => string | null;
};

/** mtimes of a repository's index, HEAD, FETCH_HEAD, refs and its top folder (a worktree's git folder followed). */
export function repoStamp(root: string, path: string): string | null {
  const dir = join(root, path);
  let gitDir = join(dir, '.git');
  try {
    if (statSync(gitDir).isFile()) {
      const m = /^gitdir:\s*(.+)$/m.exec(readFileSync(gitDir, 'utf8'));
      if (m) gitDir = m[1].trim().startsWith('/') ? m[1].trim() : join(dir, m[1].trim());
    }
  } catch {
    return null;
  }
  const parts: number[] = [];
  for (const f of [dir, join(gitDir, 'index'), join(gitDir, 'HEAD'), join(gitDir, 'FETCH_HEAD'), join(gitDir, 'refs', 'heads'), join(gitDir, 'packed-refs')]) {
    try {
      parts.push(statSync(f).mtimeMs);
    } catch {
      parts.push(0);
    }
  }
  return parts.join(':');
}

// ---------- parsers ----------

/** `ss -ltnpH`: one row per port and process (IPv4 and IPv6 of the same socket count once). */
export function parseSsListen(out: string): MachineState['ports'] {
  const rows = new Map<string, MachineState['ports'][number]>();
  for (const line of out.split('\n')) {
    const cols = line.trim().split(/\s+/);
    if (cols.length < 4 || cols[0] !== 'LISTEN') continue;
    const local = cols[3];
    const m = /^(.*):(\d+)$/.exec(local);
    if (!m) continue;
    const port = Number(m[2]);
    const addr = m[1].replace(/^\[|\]$/g, '').replace(/%.*$/, '');
    const users = /users:\(\("([^"]+)",pid=(\d+)/.exec(line);
    const key = `${port}:${users?.[2] ?? addr}`;
    if (rows.has(key)) continue;
    rows.set(key, { port, addr: addr === '::' ? '0.0.0.0' : addr, ...(users ? { process: users[1], pid: Number(users[2]) } : {}) });
  }
  return [...rows.values()].sort((a, b) => a.port - b.port || (a.pid ?? 0) - (b.pid ?? 0));
}

/** `lsof -nP -iTCP -sTCP:LISTEN` (macOS). */
export function parseLsofListen(out: string): MachineState['ports'] {
  const rows = new Map<string, MachineState['ports'][number]>();
  for (const line of out.split('\n').slice(1)) {
    const cols = line.trim().split(/\s+/);
    const name = cols.find((c) => /:\d+$/.test(c));
    if (cols.length < 9 || !name) continue;
    const m = /^(.*):(\d+)$/.exec(name)!;
    const port = Number(m[2]);
    const pid = Number(cols[1]);
    const key = `${port}:${pid}`;
    if (!rows.has(key)) rows.set(key, { port, addr: m[1].replace(/^\[|\]$/g, ''), process: cols[0], pid });
  }
  return [...rows.values()].sort((a, b) => a.port - b.port);
}

/** `docker ps --format '{{json .}}'`: only what the phone shows (no labels, command or env). */
export function parseDockerPs(out: string): NonNullable<MachineState['docker']> {
  const rows: NonNullable<MachineState['docker']> = [];
  for (const line of out.split('\n')) {
    if (!line.trim()) continue;
    try {
      const c = JSON.parse(line) as Record<string, unknown>;
      const s = (k: string, max = 120) => oneLine(String(c[k] ?? ''), max);
      rows.push({ id: s('ID', 12), name: s('Names'), image: s('Image'), state: s('State', 20), status: s('Status', 60), ports: s('Ports', 200) });
    } catch {
      // not a container line
    }
  }
  return rows;
}

/** `git status --porcelain=v2 --branch`. */
export function parseGitStatusV2(out: string): { branch: string | null; head: string | null; ahead: number | null; behind: number | null; changes: number } {
  let branch: string | null = null;
  let head: string | null = null;
  let ahead: number | null = null;
  let behind: number | null = null;
  let changes = 0;
  for (const line of out.split('\n')) {
    if (!line) continue;
    if (line.startsWith('# branch.oid ')) {
      const oid = line.slice(13).trim();
      head = /^[0-9a-f]{7,}$/.test(oid) ? oid.slice(0, 7) : null;
    } else if (line.startsWith('# branch.head ')) {
      const b = line.slice(14).trim();
      branch = b === '(detached)' ? null : b;
    } else if (line.startsWith('# branch.ab ')) {
      const m = /\+(\d+) -(\d+)/.exec(line);
      if (m) {
        ahead = Number(m[1]);
        behind = Number(m[2]);
      }
    } else if (!line.startsWith('#')) changes++;
  }
  return { branch, head, ahead, behind, changes };
}

// ---------- naming processes without their arguments ----------

const base = (s: string | undefined) => (s ?? '').split(/[\\/]/).pop() ?? '';
/** The words a process command is made of: program names (no paths), never values. */
function words(argv: string[]): string[] {
  return argv.map((a) => base(a).replace(/\.(c?js|mjs|py)$/, ''));
}

const DEV_TOOLS: Array<[string[], string, string?]> = [
  [['next'], 'next', 'dev|start'],
  [['vite'], 'vite'],
  [['nuxt', 'nuxi'], 'nuxt'],
  [['astro'], 'astro'],
  [['remix'], 'remix'],
  [['react-scripts'], 'react-scripts start'],
  [['webpack-dev-server'], 'webpack dev server'],
  [['webpack'], 'webpack serve'],
  [['ng'], 'ng serve'],
  [['expo'], 'expo'],
  [['storybook', 'start-storybook'], 'storybook'],
  [['uvicorn'], 'uvicorn'],
  [['gunicorn'], 'gunicorn'],
  [['hypercorn'], 'hypercorn'],
  [['flask'], 'flask'],
  [['rails'], 'rails server'],
  [['hugo'], 'hugo server'],
  [['jekyll'], 'jekyll serve'],
  [['wrangler'], 'wrangler dev'],
  [['firebase'], 'firebase emulators'],
  [['nodemon'], 'nodemon'],
  [['ts-node-dev'], 'ts-node-dev'],
  [['nest'], 'nest start'],
  [['parcel'], 'parcel'],
  [['live-server'], 'live-server'],
  [['http-server'], 'http-server'],
  [['serve'], 'serve'],
  [['tsx'], 'tsx'],
];
const INTERPRETERS = new Set(['node', 'nodejs', 'bun', 'deno', 'python', 'python3', 'ruby', 'java', 'php', 'go', 'dotnet', 'beam.smp', 'uwsgi']);

/** A listening process that looks like a dev server: a known tool's name, else its interpreter's; null for anything else. */
export function devServerLabel(argv: string[]): string | null {
  const w = words(argv);
  if (w.includes('manage') && w.includes('runserver')) return 'django runserver';
  if (w.includes('http.server')) return 'python http.server';
  for (const [names, label, sub] of DEV_TOOLS) {
    const i = w.findIndex((x) => names.includes(x));
    if (i === -1) continue;
    if (sub) {
      const next = w[i + 1];
      return next && new RegExp(`^(${sub})$`).test(next) ? `${label} ${next}` : label;
    }
    return label;
  }
  const pm = packageManagerRun(w);
  if (pm && /^(dev|start|serve|preview)/.test(pm.script)) return `${pm.pm} run ${pm.script}`;
  const prog = w[0]?.replace(/\d+(\.\d+)*$/, '') ?? '';
  return INTERPRETERS.has(w[0]) || INTERPRETERS.has(prog) ? w[0] : null;
}

/** `npm test`, `pnpm run build`, `node .../npm-cli.js run x`: the package manager and the script (a name, not a value). */
function packageManagerRun(w: string[]): { pm: string; script: string } | null {
  let i = w.findIndex((x) => ['npm', 'pnpm', 'yarn', 'bun', 'npm-cli', 'pnpm.cjs', 'yarn.cjs'].includes(x));
  if (i === -1) return null;
  const pm = w[i].replace(/(-cli|\.cjs)$/, '');
  i++;
  if (w[i] === 'run' || w[i] === 'run-script') i++;
  const script = w[i] ?? '';
  return /^[\w:.-]{1,40}$/.test(script) ? { pm, script } : null;
}

const TEST_TOOLS = ['vitest', 'jest', 'mocha', 'pytest', 'py.test', 'ava', 'phpunit', 'rspec', 'karma', 'jasmine'];

/** A test or build run, by its process. */
export function runKind(argv: string[]): { kind: 'test' | 'build'; label: string } | null {
  const w = words(argv);
  const pm = packageManagerRun(w);
  if (pm) {
    if (/^test/.test(pm.script)) return { kind: 'test', label: w.includes('run') ? `${pm.pm} run ${pm.script}` : `${pm.pm} ${pm.script}` };
    if (/^build/.test(pm.script)) return { kind: 'build', label: `${pm.pm} run ${pm.script}` };
    return null;
  }
  const tool = w.find((x) => TEST_TOOLS.includes(x));
  if (tool) return { kind: 'test', label: tool === 'py.test' ? 'pytest' : tool };
  const pair = (a: string, subs: string[]) => {
    const i = w.indexOf(a);
    return i !== -1 && subs.includes(w[i + 1] ?? '') ? `${a} ${w[i + 1]}` : null;
  };
  for (const [a, t, b] of [
    ['go', ['test'], ['build']],
    ['cargo', ['test'], ['build']],
    ['flutter', ['test'], ['build']],
    ['dotnet', ['test'], ['build', 'publish']],
    ['mvn', ['test'], ['package', 'install']],
    ['gradle', ['test'], ['build', 'assemble', 'assembleRelease', 'assembleDebug']],
    ['gradlew', ['test'], ['build', 'assemble', 'assembleRelease', 'assembleDebug']],
    ['make', ['test', 'check'], ['build', 'all']],
    ['playwright', ['test'], []],
    ['next', [], ['build']],
    ['vite', [], ['build']],
    ['docker', [], ['build']],
  ] as Array<[string, string[], string[]]>) {
    const tl = pair(a, t);
    if (tl) return { kind: 'test', label: tl };
    const bl = pair(a, b);
    if (bl) return { kind: 'build', label: bl };
  }
  if (w[0] === 'node' && w.includes('--test')) return { kind: 'test', label: 'node --test' };
  if (w.includes('tsc') && !argv.some((a) => a === '--watch' || a === '-w')) return { kind: 'build', label: 'tsc' };
  return null;
}

/** Is a shell command a test or a build run? (For the commands a chat runs, read from its messages.) */
export function testOrBuild(cmd: string): 'test' | 'build' | null {
  for (const part of cmd.split(/&&|\|\||;|\|/)) {
    const argv = part.trim().split(/\s+/).filter((t) => t && !/^[A-Z_][A-Z0-9_]*=/.test(t) && t !== 'cd');
    if (argv[0] === 'timeout') argv.splice(0, 2);
    const k = runKind(argv);
    if (k) return k.kind;
  }
  return null;
}

/** Another coding agent, by its process (Claude itself is known from its own records, claudeProcs.ts). */
export function agentKind(argv: string[]): string | null {
  const w = words(argv.slice(0, 2));
  const path = argv.slice(0, 2).join(' ');
  if (w.includes('codex') || /@openai[\\/]codex/.test(path)) return 'codex';
  if (w.includes('aider')) return 'aider';
  if (w.includes('cursor-agent')) return 'cursor-agent';
  if (w.includes('gemini') || /@google[\\/]gemini-cli/.test(path)) return 'gemini';
  if (w.includes('copilot') || /@github[\\/]copilot/.test(path)) return 'copilot';
  if (w.includes('opencode')) return 'opencode';
  if (w.includes('goose')) return 'goose';
  return null;
}

// ---------- the machine itself ----------

const SKIP_DIRS = new Set(['node_modules', 'vendor', 'dist', 'build', 'target', 'venv', '__pycache__', 'Pods', 'DerivedData']);

/** The repositories worked on most recently first (by their git index, else the folder), at most `max`. */
export function recentRepos(root: string, max = LIMITS.repos): string[] {
  const touched = (rel: string) => {
    for (const f of [join(root, rel, '.git', 'index'), join(root, rel, '.git'), join(root, rel)]) {
      try {
        return statSync(f).mtimeMs;
      } catch {
        // next
      }
    }
    return 0;
  };
  return findRepos(root, { maxRepos: 200 })
    .map((r) => ({ r, t: touched(r) }))
    .sort((a, b) => b.t - a.t)
    .slice(0, max)
    .map((x) => x.r);
}

/** Git repositories under `root` (a worktree's `.git` file counts), breadth first, bounded. */
export function findRepos(root: string, o: { maxDepth?: number; maxRepos?: number; maxDirs?: number } = {}): string[] {
  const maxDepth = o.maxDepth ?? 3;
  const maxRepos = o.maxRepos ?? LIMITS.repos;
  let budget = o.maxDirs ?? 3000;
  const out: string[] = [];
  let level = [root];
  for (let depth = 0; depth <= maxDepth && level.length && out.length < maxRepos; depth++) {
    const next: string[] = [];
    for (const dir of level) {
      if (budget-- <= 0) return out;
      let entries: import('node:fs').Dirent[];
      try {
        entries = readdirSync(dir, { withFileTypes: true });
      } catch {
        continue;
      }
      if (entries.some((e) => e.name === '.git')) {
        out.push(relative(root, dir) || '.');
        if (out.length >= maxRepos) return out;
      }
      for (const e of entries) {
        if (e.isDirectory() && !e.name.startsWith('.') && !SKIP_DIRS.has(e.name)) next.push(join(dir, e.name));
      }
    }
    level = next;
  }
  return out;
}

function linuxProcs(): ProcInfo[] {
  const uid = process.getuid?.();
  const out: ProcInfo[] = [];
  let names: string[];
  try {
    names = readdirSync('/proc');
  } catch {
    return out;
  }
  for (const n of names) {
    if (!/^\d+$/.test(n)) continue;
    try {
      if (uid !== undefined && statSync(`/proc/${n}`).uid !== uid) continue;
      const argv = readFileSync(`/proc/${n}/cmdline`, 'utf8').split('\0').filter(Boolean);
      if (argv.length) out.push({ pid: Number(n), argv });
    } catch {
      // gone, or not ours
    }
  }
  return out;
}

/** Linux reads a file each time; macOS and Windows start a program, so they are asked at most once a minute. */
function cachedBattery(): MachineDeps['battery'] {
  let at = 0;
  let last: { pct: number; charging: boolean } | null = null;
  return async () => {
    if (process.platform === 'linux') return readBattery(batteryExec, process.platform);
    if (Date.now() - at < 60_000) return last;
    last = await readBattery(batteryExec, process.platform);
    at = Date.now();
    return last;
  };
}

export function systemDeps(): MachineDeps {
  const linux = process.platform === 'linux';
  const exec: MachineDeps['exec'] = (cmd, args, timeoutMs) =>
      new Promise((resolve, reject) => {
        // The child gets no hub credentials and never touches git's index lock (a status here must not get in the way of a commit).
        const env = { ...childEnv(process.env), GIT_OPTIONAL_LOCKS: '0', LC_ALL: 'C' };
        execFile(cmd, args, { timeout: timeoutMs, maxBuffer: 4 * 1024 * 1024, env }, (err, stdout) => {
          if (err && (err as NodeJS.ErrnoException).code === 'ENOENT') return reject(err);
          resolve({ code: err ? (typeof (err as { code?: unknown }).code === 'number' ? ((err as { code: number }).code) : 1) : 0, stdout: String(stdout ?? '') });
        });
      });
  return {
    exec,
    procs: linux ? linuxProcs : () => [],
    cwdOf: (pid) => {
      if (!linux) return undefined;
      try {
        return readlinkSync(`/proc/${pid}/cwd`);
      } catch {
        return undefined;
      }
    },
    claudeProcs: () => readClaudeProcs(),
    repos: (root) => recentRepos(root),
    disk: (path) => {
      try {
        const s = statfsSync(path);
        const total = s.blocks * s.bsize;
        const free = s.bavail * s.bsize;
        return total > 0 ? { usedPct: Math.round((1 - free / total) * 100), freeGb: Math.round((free / 1e9) * 10) / 10 } : null;
      } catch {
        return null;
      }
    },
    battery: cachedBattery(),
    repoStamp,
  };
}

type Snapshot = { sessionId: string; waiting: boolean; step: string | null };

export class MachineStateReporter {
  private deps: MachineDeps;
  private now: () => number;
  private lastSentAt = -Infinity;
  private lastSig = '';
  private lastSlow = -Infinity;
  private slow: { docker: MachineState['docker']; repos: MachineState['repos'] } = { docker: null, repos: [] };
  private repoList: string[] = [];
  /** The last git answer per repository, and the stamp it was given for. */
  private repoCache = new Map<string, { stamp: string; row: MachineState['repos'][number] | null }>();
  private repoListAt = -Infinity;
  private cpuPrev: { idle: number; total: number } | null = null;
  private lastTest: MachineRunResult | null = null;
  private lastBuild: MachineRunResult | null = null;
  /** Test/build commands a chat started, by tool_use id, until their result comes back. */
  private pendingRuns = new Map<string, { kind: 'test' | 'build'; cmd: string; sessionId: string }>();
  private timer: NodeJS.Timeout | null = null;
  private soon: NodeJS.Timeout | null = null;
  private busy = false;

  constructor(
    private send: (msg: AgentToHubMessage) => void,
    private o: {
      workspaceRoot: string;
      deps?: MachineDeps;
      /** Chats working right now (activity.ts). */
      activity: () => Snapshot[];
      /** Chats this agent runs (the rest of Claude's processes are terminal chats). */
      liveSessions: () => Set<string>;
      /** VAULT6: the latest usage per Claude account (accountUsage.ts); undefined when not reported. */
      usage?: () => MachineState['usage'];
      /** "Give way to me" (userFirst.ts) and the AI accounts held for their limit (aiLimits.ts). */
      giveWay?: () => MachineState['giveWay'];
      aiLimits?: () => MachineState['aiLimits'];
      /** Device mesh: is the person at this computer (presence.ts), and what this computer can do for the mesh. */
      presence?: () => PresenceReport | undefined;
      deviceCaps?: () => string[];
      now?: () => number;
      intervalMs?: number;
      lookMs?: number;
    },
  ) {
    this.deps = o.deps ?? systemDeps();
    this.now = o.now ?? Date.now;
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.tick(), this.o.lookMs ?? STATE_LOOK_MS);
    this.timer.unref();
    void this.tick();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    if (this.soon) clearTimeout(this.soon);
    this.timer = null;
    this.soon = null;
  }

  /** The hub reconnected (or something changed now): send a fresh snapshot whatever the last one was. */
  sendNow(): void {
    void this.tick(true);
  }

  /** A test or build result the agent itself knows (FLOW3's own test runs). */
  noteRun(kind: 'test' | 'build', r: MachineRunResult): void {
    if (kind === 'test') this.lastTest = r;
    else this.lastBuild = r;
    this.later();
  }

  /** Every message to the hub passes through here: test/build commands chats run, and how they ended. */
  observe(msg: AgentToHubMessage): void {
    if (msg.type !== 'sdk_message') return;
    const m = (msg.message ?? {}) as { type?: string; message?: { content?: unknown } };
    const content = Array.isArray(m.message?.content) ? (m.message!.content as Array<Record<string, unknown>>) : [];
    if (m.type === 'assistant') {
      for (const b of content) {
        if (b.type !== 'tool_use' || b.name !== 'Bash' || typeof b.id !== 'string') continue;
        const cmd = String((b.input as { command?: unknown })?.command ?? '');
        const kind = testOrBuild(cmd);
        if (kind && this.pendingRuns.size < 100) this.pendingRuns.set(b.id, { kind, cmd: oneLine(cmd.split('\n')[0], 160), sessionId: msg.sessionId });
      }
    } else if (m.type === 'user') {
      for (const b of content) {
        const run = b.type === 'tool_result' && typeof b.tool_use_id === 'string' ? this.pendingRuns.get(b.tool_use_id) : undefined;
        if (!run) continue;
        this.pendingRuns.delete(b.tool_use_id as string);
        this.noteRun(run.kind, { cmd: run.cmd, ok: b.is_error !== true, at: new Date(this.now()).toISOString(), sessionId: run.sessionId, by: 'chat' });
      }
    }
  }

  /** Soon after a change the agent saw itself (not on every message). */
  private later(): void {
    if (this.soon || !this.timer) return;
    this.soon = setTimeout(() => {
      this.soon = null;
      void this.tick();
    }, 3_000);
    this.soon.unref();
  }

  async tick(force = false): Promise<void> {
    if (this.busy) return;
    this.busy = true;
    try {
      const state = await this.collect();
      const { at: _at, health, presence, ...rest } = state;
      // A plug or unplug, or a low level changing, is sent at once; the rest of the health waits for the minute.
      const bat = health.battery ? { charging: health.battery.charging, pct: health.battery.pct <= 25 ? health.battery.pct : 100 } : null;
      // Presence changes the picture only when it moves between using / recent / idle / locked, never by its seconds.
      const sig = JSON.stringify({ ...rest, bat, presence: presenceBucket(presence) });
      const due = this.now() - this.lastSentAt >= (this.o.intervalMs ?? STATE_INTERVAL_MS);
      if (!force && !due && sig === this.lastSig) return;
      this.lastSig = sig;
      this.lastSentAt = this.now();
      this.send({ type: 'machine_state', state });
    } catch (err) {
      console.error('Could not read this machine\'s state:', err instanceof Error ? err.message : err);
    } finally {
      this.busy = false;
    }
  }

  private async run(cmd: string, args: string[]): Promise<{ code: number; stdout: string } | null> {
    try {
      return await this.deps.exec(cmd, args, EXEC_TIMEOUT_MS);
    } catch {
      return null; // not installed here
    }
  }

  private async ports(): Promise<MachineState['ports']> {
    const ss = await this.run('ss', ['-ltnpH']);
    if (ss && ss.code === 0) return parseSsListen(ss.stdout);
    if (process.platform === 'darwin') {
      const lsof = await this.run('lsof', ['-nP', '-iTCP', '-sTCP:LISTEN']);
      if (lsof && lsof.code === 0) return parseLsofListen(lsof.stdout);
    }
    return [];
  }

  private async docker(): Promise<MachineState['docker']> {
    const r = await this.run('docker', ['ps', '--format', '{{json .}}']);
    return r && r.code === 0 ? parseDockerPs(r.stdout).slice(0, LIMITS.docker) : null;
  }

  private async repos(): Promise<MachineState['repos']> {
    if (this.now() - this.repoListAt >= REPO_RESCAN_MS) {
      this.repoList = this.deps.repos(this.o.workspaceRoot).slice(0, LIMITS.repos);
      this.repoListAt = this.now();
      for (const k of this.repoCache.keys()) if (!this.repoList.includes(k)) this.repoCache.delete(k);
    }
    const out: MachineState['repos'] = [];
    // A few at a time: one slow repository does not hold up the rest for long.
    for (let i = 0; i < this.repoList.length; i += 4) {
      const batch = await Promise.all(
        this.repoList.slice(i, i + 4).map(async (path) => {
          const stamp = this.deps.repoStamp?.(this.o.workspaceRoot, path) ?? null;
          const cached = this.repoCache.get(path);
          if (stamp !== null && cached?.stamp === stamp) return cached.row; // nothing changed in it since git was last asked
          const r = await this.run('git', ['-C', join(this.o.workspaceRoot, path), 'status', '--porcelain=v2', '--branch', '--untracked-files=normal']);
          // Not readable (a worktree whose repository is gone): nothing to tell.
          const s = r && r.code === 0 ? parseGitStatusV2(r.stdout) : null;
          const row = s ? { path, branch: s.branch, head: s.head, dirty: s.changes > 0, changes: s.changes, ahead: s.ahead, behind: s.behind } : null;
          if (stamp !== null) this.repoCache.set(path, { stamp, row });
          return row;
        }),
      );
      out.push(...batch.filter((b): b is MachineState['repos'][number] => b !== null));
    }
    return out;
  }

  private health(battery: { pct: number; charging: boolean } | null): MachineState['health'] {
    const cs = cpus();
    const idle = cs.reduce((n, c) => n + c.times.idle, 0);
    const total = cs.reduce((n, c) => n + c.times.user + c.times.nice + c.times.sys + c.times.idle + c.times.irq, 0);
    const prev = this.cpuPrev;
    this.cpuPrev = { idle, total };
    const cpuPct = prev && total > prev.total ? Math.round((1 - (idle - prev.idle) / (total - prev.total)) * 100) : null;
    const disk = this.deps.disk(this.o.workspaceRoot);
    const mem = totalmem();
    return {
      cpuPct,
      load1: Math.round(loadavg()[0] * 100) / 100,
      cores: cs.length,
      memUsedPct: Math.round((1 - freemem() / mem) * 100),
      memTotalMb: Math.round(mem / 1048576),
      diskUsedPct: disk?.usedPct ?? null,
      diskFreeGb: disk?.freeGb ?? null,
      uptimeS: Math.round(uptime()),
      battery,
    };
  }

  async collect(): Promise<MachineState> {
    const slowDue = this.now() - this.lastSlow >= (this.o.intervalMs ?? STATE_INTERVAL_MS);
    const [ports, docker, repos] = await Promise.all([
      this.ports(),
      slowDue ? this.docker() : Promise.resolve(this.slow.docker),
      slowDue ? this.repos() : Promise.resolve(this.slow.repos),
    ]);
    if (slowDue) {
      this.slow = { docker, repos };
      this.lastSlow = this.now();
    }
    const procs = this.deps.procs();
    const byPid = new Map(procs.map((p) => [p.pid, p]));
    const cwd = (p: ProcInfo) => p.cwd ?? this.deps.cwdOf(p.pid);

    const devServers: MachineState['devServers'] = [];
    const seen = new Set<string>();
    for (const port of ports) {
      const p = port.pid !== undefined ? byPid.get(port.pid) : undefined;
      const label = p ? devServerLabel(p.argv) : null;
      if (!p || !label || seen.has(`${port.port}`)) continue;
      seen.add(`${port.port}`);
      const dir = cwd(p);
      devServers.push({ port: port.port, url: `http://localhost:${port.port}`, label, pid: p.pid, ...(dir ? { cwd: dir } : {}) });
    }

    const running: MachineState['running'] = [];
    const runKeys = new Set<string>();
    const others: MachineState['agents'] = [];
    for (const p of procs) {
      const k = runKind(p.argv);
      if (k) {
        const dir = cwd(p);
        const key = `${k.kind}:${dir ?? ''}`;
        if (!runKeys.has(key)) {
          runKeys.add(key);
          running.push({ kind: k.kind, label: k.label, pid: p.pid, ...(dir ? { cwd: dir } : {}) });
        }
      }
      const a = agentKind(p.argv);
      if (a) {
        const dir = cwd(p);
        others.push({ kind: a, state: 'running', pid: p.pid, ...(dir ? { cwd: dir } : {}), source: 'process' });
      }
    }
    const agents: MachineState['agents'] = [];
    const live = this.o.liveSessions();
    const claude = this.deps.claudeProcs();
    for (const c of claude.values()) {
      agents.push({ kind: 'claude', state: c.status, pid: c.pid, sessionId: c.sessionId, ...(c.cwd ? { cwd: c.cwd } : {}), source: live.has(c.sessionId) ? 'escanor' : 'terminal' });
    }
    for (const a of this.o.activity()) {
      if (claude.has(a.sessionId)) continue;
      agents.push({ kind: 'claude', state: a.waiting ? 'waiting' : 'busy', sessionId: a.sessionId, source: live.has(a.sessionId) ? 'escanor' : 'terminal' });
    }
    agents.push(...others);

    const usage = this.o.usage?.();
    const battery = await Promise.resolve(this.deps.battery()).catch(() => null);
    const giveWay = this.o.giveWay?.();
    const aiLimits = this.o.aiLimits?.();
    const presence = this.o.presence?.();
    const deviceCaps = this.o.deviceCaps?.();
    return {
      at: new Date(this.now()).toISOString(),
      health: this.health(battery),
      ports: ports.slice(0, LIMITS.ports),
      devServers: devServers.slice(0, LIMITS.devServers),
      docker,
      repos,
      running: running.slice(0, LIMITS.running),
      agents: agents.slice(0, LIMITS.agents),
      lastTest: this.lastTest,
      lastBuild: this.lastBuild,
      ...(usage ? { usage } : {}),
      ...(giveWay ? { giveWay } : {}),
      ...(aiLimits && aiLimits.length ? { aiLimits } : {}),
      ...(presence ? { presence } : {}),
      ...(deviceCaps ? { deviceCaps } : {}),
    };
  }
}

