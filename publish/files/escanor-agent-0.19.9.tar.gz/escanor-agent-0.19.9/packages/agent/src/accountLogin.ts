import { spawn } from 'node:child_process';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import type { Readable, Writable } from 'node:stream';
import type { AccountProvider, AgentAccountResult, ClaudeAccount, HubAccountCommand } from '@remote-harness/shared';
import { MIN_NODE, withNewNode } from './nodeRuntime.js';
import { childEnv } from './childEnv.js';
import { ensureCli, launchSpec, resolveCliBin, geminiOAuthClient, stripAnsi, type CliProvider, type RunFn, type RunResult } from './cliTools.js';
import { CLI_HOME_ENV, FOREIGN_KEYS } from './cliEngine.js';
import { ACCOUNT_META_FILE, API_KEY_FILE, KEEP_DEFAULT_FILE, PENDING_MARK, providerOf, refreshProfiles, toAccount, type ClaudeProfile } from './profiles.js';
import { isManaged, switchOn } from './switches.js';

/**
 * Adding a second (third...) Claude account to this machine from the phone, signed in with that account's own email or Google.
 *
 * The machine runs Claude's own sign-in, `claude auth login`, for a new account folder (PROFILES_DIR/<id>, used as that account's
 * CLAUDE_CONFIG_DIR, like the claude1/claude2 folders install.sh makes). Claude prints its sign-in page; the phone opens it, the
 * person signs in there and copies the code the page shows; the phone sends the code back and the machine hands it to the same
 * `claude auth login`, which finishes the sign-in and keeps the login in that folder. Escanor never sees a password or a token:
 * only the one-time code passes through, straight to Claude's own sign-in, and it is never written down or logged.
 *
 * On by default (the hello then lists the `account_login` capability); ESCANOR_ACCOUNT_LOGIN=0 turns it off. Off by default in an
 * Escanor worker container (ESCANOR_MANAGED=1). Never with chat users (ESCANOR_CHAT_*): those chats use their own login folder,
 * not the accounts (index.ts).
 *
 * The same works for ChatGPT and Gemini accounts (the `account_provider_chatgpt` / `account_provider_gemini` capabilities), each
 * in its own folder too, with that AI's own tool:
 * - ChatGPT (Codex CLI, CODEX_HOME=<folder>): `codex login --device-auth` prints a page and a one-time code; the person types the
 *   code on that page and approves, and the phone then says so (`code` = 'device-approved'); the machine waits for Codex to finish.
 *   That device sign-in only works once the person turned on "device code sign-in" in their ChatGPT security settings, which most
 *   never have. So a newer phone (it sees `account_chatgpt_browser` in the hello) at once sends `code` = 'browser-signin': the
 *   machine then runs Codex's normal sign-in, `codex login`, instead, which needs no setting. ChatGPT's page sends the browser back
 *   to http://127.0.0.1:1455/auth/callback?code=...&state=...; the phone catches that address itself (or the person pastes it)
 *   and sends it as the `code`, and the machine hands it to Codex's own sign-in server on this computer, which finishes.
 * - Gemini (Gemini CLI, GEMINI_CLI_HOME=<folder>): the agent runs Gemini CLI's own Google "user code" sign-in itself (the same
 *   client, read from the installed CLI), and writes the login where Gemini CLI keeps it (<folder>/.gemini).
 * - GitHub Copilot (Copilot CLI, COPILOT_HOME=<folder>): `copilot login --device-code` prints GitHub's device page and a code; the
 *   person enters the code there and approves, the phone then says so (`code` = 'device-approved') and the machine waits for Copilot
 *   to finish. Copilot keeps the sign-in itself (the system's credential store, else that folder).
 * - Any of them with a key instead (method 'key'): the key is the `code`; it is kept only in that account's folder (0600). For
 *   Copilot that is a GitHub token with Copilot access (a fine-grained token with "Copilot Requests", or a GitHub CLI token).
 */

export const ACCOUNT_LOGIN_CAPABILITY = 'account_login';
export const ACCOUNT_PROVIDER_CHATGPT_CAPABILITY = 'account_provider_chatgpt';
export const ACCOUNT_PROVIDER_GEMINI_CAPABILITY = 'account_provider_gemini';
export const ACCOUNT_PROVIDER_COPILOT_CAPABILITY = 'account_provider_copilot';
/** ChatGPT can also sign in with Codex's normal browser sign-in (no ChatGPT setting needed): see BROWSER_SIGNIN. */
export const ACCOUNT_CHATGPT_BROWSER_CAPABILITY = 'account_chatgpt_browser';
/** What the hello lists when account login is on. */
export const ACCOUNT_CAPABILITIES = [ACCOUNT_LOGIN_CAPABILITY, ACCOUNT_PROVIDER_CHATGPT_CAPABILITY, ACCOUNT_PROVIDER_GEMINI_CAPABILITY, ACCOUNT_PROVIDER_COPILOT_CAPABILITY, ACCOUNT_CHATGPT_BROWSER_CAPABILITY];
/** How long `claude auth login` may take to print its sign-in page. */
export const URL_WAIT_MS = 30_000;
/** How long Claude may take to finish once it has the code. */
export const CODE_WAIT_MS = 60_000;
/** A sign-in nobody finished is stopped and its folder removed after this. */
export const FLOW_TTL_MS = 15 * 60_000;
export const MAX_ACCOUNTS = 20;
export const MAX_LABEL = 60;

/** Where Claude's sign-in page may be. Anything else the CLI printed is never handed to the phone. */
const SIGN_IN_HOSTS = ['claude.com', 'claude.ai', 'anthropic.com'];
const URL_RE = /https:\/\/[^\s"'<>]+\/oauth\/authorize\?[^\s"'<>]+/;
/** ChatGPT's device sign-in page, as `codex login --device-auth` prints it. */
export const CODEX_DEVICE_URL = 'https://auth.openai.com/codex/device';
const DEVICE_URL_RE = /https:\/\/auth\.openai\.com\/codex\/device\b[^\s"'<>]*/;
const DEVICE_CODE_RE = /one-time code[\s\S]*?\b([A-Z0-9]{3,8}-[A-Z0-9]{3,8})\b/;
/** GitHub's device sign-in page, as `copilot login --device-code` prints it, and the code shown with it. */
export const COPILOT_DEVICE_URL = 'https://github.com/login/device';
const COPILOT_DEVICE_RE = /https:\/\/github\.com\/login\/device\b[\s\S]*?\bcode\s+([A-Z0-9]{4}-[A-Z0-9]{4})\b/;
const GITHUB_USER_URL = 'https://api.github.com/user';
const COPILOT_USER_URL = 'https://api.github.com/copilot_internal/user';
/** Gemini CLI's own Google sign-in ("user code" flow): the page shows the code the person pastes back. */
export const GEMINI_REDIRECT_URI = 'https://codeassist.google.com/authcode';
export const GEMINI_SCOPES = ['https://www.googleapis.com/auth/cloud-platform', 'https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/userinfo.profile'];
const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const GOOGLE_USERINFO_URL = 'https://www.googleapis.com/oauth2/v2/userinfo';
/** What the phone sends as the "code" of a ChatGPT sign-in: the person approved it on the page. Ignored here. */
export const DEVICE_APPROVED = 'device-approved';
/** What a newer phone sends as the "code" of a ChatGPT sign-in just started: use Codex's normal browser sign-in instead. */
export const BROWSER_SIGNIN = 'browser-signin';
/** ChatGPT's sign-in page as `codex login` prints it. */
const CODEX_AUTHORIZE_RE = /https:\/\/auth\.openai\.com\/oauth\/authorize\?[^\s"'<>]+/;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,253}\.[^\s@]{1,63}$/;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u001f\u007f]/;

export function accountLoginEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchOn(env.ESCANOR_ACCOUNT_LOGIN, !isManaged(env));
}

/** A running process as far as this needs it (a fake one in tests). */
export type LoginProc = {
  stdout: Readable | null;
  stderr: Readable | null;
  stdin: Writable | null;
  kill(signal?: NodeJS.Signals): boolean;
  once(event: 'exit', cb: (code: number | null) => void): unknown;
  once(event: 'error', cb: (err: Error) => void): unknown;
};
export type SpawnFn = (bin: string, args: string[], env: Record<string, string | undefined>) => LoginProc;

/** Never through a shell: on Windows an npm `.cmd` wrapper (codex, npm) is run as its JavaScript with this Node (launchSpec). */
const realSpawn: SpawnFn = (bin, args, env) => {
  const l = launchSpec(bin);
  return spawn(l.command, [...l.args, ...args], { env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
};

/**
 * The Claude command to run: ESCANOR_CLAUDE_BIN, else the Claude binary the Agent SDK ships for this platform (the one the chats
 * use), else `claude` on the PATH.
 */
export function resolveClaudeBin(env: NodeJS.ProcessEnv = process.env): string {
  const set = env.ESCANOR_CLAUDE_BIN?.trim();
  if (set) return set;
  const require = createRequire(import.meta.url);
  const exe = process.platform === 'win32' ? 'claude.exe' : 'claude';
  const base = `@anthropic-ai/claude-agent-sdk-${process.platform}-${process.arch}`;
  for (const pkg of process.platform === 'linux' ? [base, `${base}-musl`] : [base]) {
    try {
      const bin = join(dirname(require.resolve(`${pkg}/package.json`)), exe);
      if (existsSync(bin)) return bin;
    } catch {
      // not installed for this platform
    }
  }
  return 'claude';
}

/** A folder name for a new account: from its name or email, lower-case letters, digits, '.', '_' and '-', not yet taken. */
export function accountIdFor(label: string | undefined, email: string | undefined, taken: (id: string) => boolean, prefix = ''): string {
  const from = (email?.split('@')[0] || label || '').toLowerCase().normalize('NFKD');
  let base = from.replace(/[^a-z0-9._-]+/g, '-').replace(/^[-._]+|[-._]+$/g, '').slice(0, 32) || 'account';
  if (base === 'default') base = 'default-2';
  // A ChatGPT / Gemini account's id says which AI it is (an old hub that drops `provider` keeps that); a Claude one never
  // looks like theirs.
  if (prefix) base = `${prefix}${base.startsWith(prefix) ? base.slice(prefix.length) || 'account' : base}`.slice(0, 40);
  else if (base.startsWith('chatgpt-') || base.startsWith('gemini-') || base.startsWith('copilot-')) base = `claude-${base}`.slice(0, 40);
  if (!taken(base)) return base;
  for (let n = 2; n < 1000; n++) {
    const id = `${base.slice(0, 28)}-${n}`;
    if (!taken(id)) return id;
  }
  return `account-${randomUUID().slice(0, 8)}`;
}

/** The sign-in page in what `claude auth login` printed, only if it is Claude's own (https, a Claude or Anthropic host). */
export function signInUrlIn(text: string): string | null {
  const m = URL_RE.exec(text);
  if (!m) return null;
  try {
    const u = new URL(m[0]);
    const host = u.hostname.toLowerCase();
    if (u.protocol !== 'https:' || !SIGN_IN_HOSTS.some((h) => host === h || host.endsWith(`.${h}`))) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function cleanLabel(v: unknown): string | null {
  if (typeof v !== 'string') return null;
  const l = v.trim().replace(/\s+/g, ' ');
  if (!l || l.length > MAX_LABEL || CONTROL.test(l)) return null;
  return l;
}

/** The code Claude's page shows ("code#state"): one line, no spaces, plain characters. */
export function cleanCode(v: unknown): string | null {
  if (typeof v !== 'string') return null;
  const c = v.trim();
  if (c.length < 8 || c.length > 2048 || !/^[\x21-\x7e]+$/.test(c)) return null;
  return c;
}

/** ChatGPT's page and one-time code in what `codex login --device-auth` printed (colours removed), once both are there. */
export function deviceLoginIn(raw: string): { url: string; userCode: string } | null {
  const text = stripAnsi(raw);
  const u = DEVICE_URL_RE.exec(text);
  const c = DEVICE_CODE_RE.exec(text);
  if (!u || !c) return null;
  return { url: u[0].replace(/[.,;)]+$/, ''), userCode: c[1] };
}

/** GitHub's device page and code in what `copilot login --device-code` printed (colours removed), once both are there. */
export function copilotDeviceIn(raw: string): { url: string; userCode: string } | null {
  const m = COPILOT_DEVICE_RE.exec(stripAnsi(raw));
  return m ? { url: COPILOT_DEVICE_URL, userCode: m[1] } : null;
}

/** The GitHub account Copilot signed in to in an account folder (its config.json), or null. */
export function copilotLoginIn(copilotHome: string): string | null {
  try {
    // Copilot writes comment lines above the JSON.
    const raw = readFileSync(join(copilotHome, 'config.json'), 'utf8').replace(/^\s*\/\/.*$/gm, '');
    const j = JSON.parse(raw) as { lastLoggedInUser?: { login?: unknown }; loggedInUsers?: Array<{ login?: unknown }> };
    const login = j.lastLoggedInUser?.login ?? j.loggedInUsers?.[0]?.login;
    return typeof login === 'string' && /^[A-Za-z0-9-]{1,39}$/.test(login) ? login : null;
  } catch {
    return null;
  }
}

/** Codex's normal sign-in, as `codex login` printed it: the page to open, and where (on this computer) the page sends the browser back. */
export type CodexBrowserLogin = { url: string; state: string; callback: string };

/** ChatGPT's sign-in page in what `codex login` printed, only if it sends the browser back to this computer's own Codex. */
export function codexBrowserLoginIn(raw: string): CodexBrowserLogin | null {
  const m = CODEX_AUTHORIZE_RE.exec(stripAnsi(raw));
  if (!m) return null;
  try {
    const u = new URL(m[0]);
    const state = u.searchParams.get('state');
    const r = new URL(u.searchParams.get('redirect_uri') ?? '');
    if (u.hostname !== 'auth.openai.com' || !state) return null;
    if (r.protocol !== 'http:' || (r.hostname !== '127.0.0.1' && r.hostname !== 'localhost') || !r.port || r.pathname !== '/auth/callback') return null;
    return { url: u.toString(), state, callback: `http://${r.hostname}:${r.port}/auth/callback` };
  } catch {
    return null;
  }
}

/**
 * What ChatGPT's page sent the browser back with (the whole address the phone caught or the person pasted, or only its
 * `?code=...&state=...` part): its code and state. `error` when the person cancelled there; null when it is not that address.
 */
export function codexCallbackIn(raw: unknown): { code: string; state: string } | { error: string } | null {
  if (typeof raw !== 'string') return null;
  const t = raw.trim();
  const q = t.indexOf('?');
  if (q < 0 || t.length > 4096 || /\s/.test(t)) return null;
  const p = new URLSearchParams(t.slice(q + 1).split('#')[0]);
  const err = p.get('error');
  if (err) return { error: err };
  const code = p.get('code');
  const state = p.get('state');
  if (!code || !state || code.length > 2048 || state.length > 512) return null;
  return { code, state };
}

/** An API key as pasted: one line, no spaces, plain characters, and shaped like that AI's keys. */
export function cleanApiKey(provider: AccountProvider, v: unknown): { key: string } | { error: string } {
  if (typeof v !== 'string') return { error: 'Paste the API key, with nothing else.' };
  const k = v.trim();
  if (k.length < 20 || k.length > 512 || !/^[\x21-\x7e]+$/.test(k)) return { error: 'Paste the whole API key on one line, with nothing else.' };
  if (provider === 'claude' && !k.startsWith('sk-ant-')) return { error: 'That is not an Anthropic API key. Those start with sk-ant-.' };
  if (provider === 'chatgpt' && !k.startsWith('sk-')) return { error: 'That is not an OpenAI API key. Those start with sk-.' };
  // Google AI Studio keys come in two shapes: the older AIza... and the newer AQ.... (Nov 2026).
  if (provider === 'gemini' && !/^(AIza|AQ\.)/.test(k)) return { error: 'That is not a Google AI Studio key. Those start with AIza or AQ.' };
  if (provider === 'copilot') {
    if (k.startsWith('ghp_')) return { error: 'GitHub Copilot does not take classic tokens (ghp_). Make a fine-grained token with the "Copilot Requests" permission instead.' };
    if (!/^(github_pat_|gho_|ghu_)/.test(k)) return { error: 'That is not a GitHub token Copilot takes. Use a fine-grained token (github_pat_...) with the "Copilot Requests" permission.' };
  }
  return { key: k };
}

/** The email inside a sign-in's id token (a JWT), if it has one. Read only, never checked: the tool that got it already did. */
export function emailFromIdToken(token: unknown): string | null {
  if (typeof token !== 'string') return null;
  const part = token.split('.')[1];
  if (!part) return null;
  try {
    const j = JSON.parse(Buffer.from(part, 'base64url').toString('utf8')) as { email?: unknown };
    return typeof j.email === 'string' && EMAIL_RE.test(j.email) ? j.email.toLowerCase() : null;
  } catch {
    return null;
  }
}

const b64url = (b: Buffer) => b.toString('base64url');

/** Gemini CLI's Google sign-in page for a new account, with its PKCE verifier (kept here, sent with the code later). */
export function geminiSignIn(client: { clientId: string }): { url: string; verifier: string; state: string } {
  const verifier = b64url(randomBytes(32));
  const challenge = b64url(createHash('sha256').update(verifier).digest());
  const state = randomBytes(32).toString('hex');
  const q = new URLSearchParams({
    client_id: client.clientId,
    redirect_uri: GEMINI_REDIRECT_URI,
    response_type: 'code',
    scope: GEMINI_SCOPES.join(' '),
    access_type: 'offline',
    prompt: 'consent',
    code_challenge_method: 'S256',
    code_challenge: challenge,
    state,
  });
  return { url: `${GOOGLE_AUTH_URL}?${q.toString()}`, verifier, state };
}

export type FetchFn = (url: string, init: { method?: string; headers?: Record<string, string>; body?: string; signal?: AbortSignal }) => Promise<{ ok: boolean; status: number; json(): Promise<unknown> }>;

type Flow = {
  id: string;
  accountId: string;
  dir: string;
  label: string;
  email?: string;
  provider: AccountProvider;
  method: 'signin' | 'key';
  /** The sign-in tool running for it (Claude, ChatGPT and Copilot sign-ins only). */
  proc?: LoginProc;
  /** The AI's own tool (ChatGPT, Gemini, Copilot). */
  bin?: string;
  /** Gemini sign-in: what the code is exchanged with. */
  google?: { clientId: string; clientSecret: string; verifier: string };
  /** ChatGPT with Codex's normal sign-in (after BROWSER_SIGNIN): where Codex waits for the page's answer on this computer. */
  browser?: { state: string; callback: string };
  exited: number | null | undefined;
  onExit: Array<(code: number | null) => void>;
  timer: NodeJS.Timeout;
  /** The machine had only its own login when this sign-in started. */
  onlyDefault: boolean;
};

export type AccountLoginDeps = {
  profilesDir: string;
  /** The agent's account list; changed in place (refreshProfiles). */
  profiles: ClaudeProfile[];
  /** Accounts with a chat running now: those are not removed. */
  busyAccounts: () => Set<string>;
  /** Workspace accounts (workspaceAccounts.ts): share one with every machine, and know which accounts come from the workspace. */
  workspace?: { share(accountId: string): Promise<{ ok: true } | { ok: false; error: string }>; isShared(accountId: string): boolean; autoShare: boolean };
  spawn?: SpawnFn;
  claudeBin?: string;
  env?: NodeJS.ProcessEnv;
  urlWaitMs?: number;
  codeWaitMs?: number;
  flowTtlMs?: number;
  /** Injectable for tests: the ChatGPT / Gemini tool to use (otherwise found, or installed, by ensureCli). */
  cliBins?: Partial<Record<CliProvider, string>>;
  /** Injectable for tests: Gemini CLI's sign-in client (otherwise read from the installed Gemini CLI). */
  googleClient?: { clientId: string; clientSecret: string } | null;
  /** Injectable for tests: Google's token and user-info endpoints. */
  fetch?: FetchFn;
  /** Injectable for tests: hands ChatGPT's answer to Codex's own sign-in server on this computer (a GET of that address). */
  forwardCallback?: (url: string) => Promise<void>;
  now?: () => number;
};

/** A GET of Codex's own sign-in address on this computer (loopback only: codexBrowserLoginIn checked it). */
async function forwardCallback(url: string): Promise<void> {
  const res = await fetch(url, { redirect: 'manual', signal: AbortSignal.timeout(CODE_WAIT_MS) });
  await res.arrayBuffer().catch(() => undefined);
}

export class AccountLogin {
  private flows = new Map<string, Flow>();
  private spawnFn: SpawnFn;
  private bin: string;
  private env: NodeJS.ProcessEnv;
  private fetchFn: FetchFn;

  constructor(private d: AccountLoginDeps) {
    this.spawnFn = d.spawn ?? realSpawn;
    this.env = d.env ?? process.env;
    this.bin = d.claudeBin ?? resolveClaudeBin(this.env);
    this.fetchFn = d.fetch ?? ((url, init) => fetch(url, init) as ReturnType<FetchFn>);
  }

  accounts(): ClaudeAccount[] {
    return this.d.profiles.map(toAccount);
  }

  /** Stops every sign-in still waiting (the agent is stopping). */
  stopAll(): void {
    for (const f of [...this.flows.values()]) this.drop(f, true);
  }

  async handle(cmd: HubAccountCommand): Promise<AgentAccountResult> {
    const base = { type: 'account_result' as const, requestId: cmd.requestId };
    try {
      const r = await this.run(cmd);
      return { ...base, ...r };
    } catch (err) {
      console.error('Account command failed:', err instanceof Error ? err.message : err);
      return { ...base, ok: false, error: 'This computer could not do that. Try again.' };
    }
  }

  private async run(cmd: HubAccountCommand): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    switch (cmd.action) {
      case 'start':
        return this.start(cmd.label, cmd.email, cmd.provider, cmd.method);
      case 'code':
        return this.code(cmd.flowId, cmd.code);
      case 'cancel': {
        const f = this.flows.get(cmd.flowId);
        if (f) this.drop(f, true);
        return { ok: true };
      }
      case 'rename':
        return this.rename(cmd.accountId, cmd.label);
      case 'remove':
        return this.remove(cmd.accountId);
      case 'share': {
        // "Make available on all machines": this machine's sign-in of the account goes to the workspace, every machine can then use it.
        if (!this.d.workspace) return { ok: false, error: 'This computer cannot share accounts with the workspace. Update its Escanor agent.' };
        const r = await this.d.workspace.share(typeof cmd.accountId === 'string' ? cmd.accountId : '');
        return r.ok ? { ok: true, accounts: this.accounts() } : { ok: false, error: r.error };
      }
      default:
        return { ok: false, error: 'This computer does not know that account action. Update its Escanor agent.' };
    }
  }

  private async start(rawLabel: unknown, rawEmail: unknown, rawProvider: unknown, rawMethod: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const provider = rawProvider === undefined ? 'claude' : rawProvider;
    if (provider !== 'claude' && provider !== 'chatgpt' && provider !== 'gemini' && provider !== 'copilot') return { ok: false, error: 'This computer cannot add that kind of account. Update its Escanor agent.' };
    const method = rawMethod === undefined ? 'signin' : rawMethod;
    if (method !== 'signin' && method !== 'key') return { ok: false, error: 'This computer does not know that way of adding an account. Update its Escanor agent.' };
    const email = typeof rawEmail === 'string' && rawEmail.trim() ? rawEmail.trim().toLowerCase() : undefined;
    if (email !== undefined && !EMAIL_RE.test(email)) return { ok: false, error: 'That email does not look right.' };
    const label = rawLabel === undefined || rawLabel === '' ? (email ?? null) : cleanLabel(rawLabel);
    if (rawLabel !== undefined && rawLabel !== '' && label === null) return { ok: false, error: `A name is 1 to ${MAX_LABEL} characters on one line.` };
    if (this.d.profiles.length >= MAX_ACCOUNTS) return { ok: false, error: `This computer already has ${MAX_ACCOUNTS} accounts. Remove one first.` };
    // One sign-in at a time on a machine: a new one replaces one left open.
    for (const f of [...this.flows.values()]) this.drop(f, true);

    // ChatGPT, Gemini and Copilot run with their own tool: found, or installed now (before any folder is made).
    let bin: string | undefined;
    if (provider !== 'claude') {
      const got = this.d.cliBins?.[provider]
        ? { ok: true as const, bin: this.d.cliBins[provider]! }
        : await ensureCli(provider, { env: this.env, profilesDir: this.d.profilesDir, run: this.runFn });
      if (!got.ok) return { ok: false, error: got.error };
      bin = got.bin;
    }
    let google: Flow['google'];
    let googleUrl: string | undefined;
    if (provider === 'gemini' && method === 'signin') {
      const client = this.d.googleClient !== undefined ? this.d.googleClient : geminiOAuthClient(bin!);
      if (!client) return { ok: false, error: 'The Gemini tool on this computer could not start a Google sign-in. Update Gemini CLI there, then try again.' };
      const s = geminiSignIn(client);
      google = { ...client, verifier: s.verifier };
      googleUrl = s.url;
    }

    const onlyDefault = this.d.profiles.length === 1 && this.d.profiles[0].configDir === undefined;
    mkdirSync(this.d.profilesDir, { recursive: true, mode: 0o700 });
    const prefix = provider === 'claude' ? '' : `${provider}-`;
    const accountId = accountIdFor(label ?? undefined, email, (id) => existsSync(join(this.d.profilesDir, id)) || this.d.profiles.some((p) => p.id === id), prefix);
    const dir = join(this.d.profilesDir, accountId);
    mkdirSync(dir, { mode: 0o700 });
    chmodSync(dir, 0o700);
    writeFileSync(join(dir, PENDING_MARK), '');

    if (method === 'key' || provider === 'gemini') {
      // Nothing runs until the key (or the code from Google's page) arrives.
      const flow = this.newFlow({ accountId, dir, label: label ?? accountId, email, provider, method, onlyDefault, bin, google });
      return method === 'key' ? { ok: true, flowId: flow.id, method: 'key' } : { ok: true, flowId: flow.id, url: googleUrl!, method: 'signin' };
    }
    if (provider === 'chatgpt') return this.startDevice({ accountId, dir, label: label ?? accountId, email, onlyDefault, bin: bin! });
    if (provider === 'copilot') return this.startCopilotDevice({ accountId, dir, label: label ?? undefined, email, onlyDefault, bin: bin! });

    const args = ['auth', 'login', '--claudeai', ...(email ? ['--email', email] : [])];
    // The sign-in page opens on the phone, never in a browser on this machine.
    const env = childEnv(this.env, { CLAUDE_CONFIG_DIR: dir, BROWSER: 'true' });
    delete env.DISPLAY;
    delete env.WAYLAND_DISPLAY;
    let proc: LoginProc;
    try {
      proc = this.spawnFn(this.bin, args, env);
    } catch {
      rmSync(dir, { recursive: true, force: true });
      return { ok: false, error: 'Claude could not be started on this computer to sign in.' };
    }
    const flow = this.newFlow({ accountId, dir, label: label ?? accountId, email, provider: 'claude', method: 'signin', onlyDefault, proc });

    const url = await new Promise<string | null>((resolve) => {
      let text = '';
      const done = (v: string | null) => {
        clearTimeout(t);
        proc.stdout?.off('data', onData);
        proc.stderr?.off('data', onData);
        resolve(v);
      };
      const onData = (b: Buffer | string) => {
        text = (text + b.toString()).slice(-16_384);
        const u = signInUrlIn(text);
        if (u) done(u);
      };
      const t = setTimeout(() => done(null), this.d.urlWaitMs ?? URL_WAIT_MS);
      proc.stdout?.on('data', onData);
      proc.stderr?.on('data', onData);
      flow.onExit.push(() => done(signInUrlIn(text)));
    });
    if (!url || flow.exited !== undefined) {
      this.drop(flow, true);
      return { ok: false, error: 'Claude did not show a sign-in page on this computer. Check that Claude Code is installed there, then try again.' };
    }
    // Keep reading so Claude never blocks on a full pipe; nothing it prints is kept.
    proc.stdout?.resume();
    proc.stderr?.resume();
    return { ok: true, flowId: flow.id, url };
  }

  private newFlow(f: Omit<Flow, 'id' | 'exited' | 'onExit' | 'timer'>): Flow {
    const flow: Flow = {
      ...f,
      id: randomUUID(),
      exited: f.proc ? undefined : null,
      onExit: [],
      timer: setTimeout(() => this.drop(flow, true), this.d.flowTtlMs ?? FLOW_TTL_MS),
    };
    if (!flow.email) delete flow.email;
    flow.timer.unref?.();
    this.flows.set(flow.id, flow);
    if (f.proc) this.attach(flow, f.proc);
    return flow;
  }

  /** [proc] is the sign-in tool of [flow] now: its end is the flow's (an earlier tool's end no longer counts). */
  private attach(flow: Flow, proc: LoginProc): void {
    flow.proc = proc;
    flow.exited = undefined;
    flow.onExit = [];
    const exitNow = (code: number | null) => {
      if (flow.proc !== proc || flow.exited !== undefined) return;
      flow.exited = code;
      for (const cb of flow.onExit.splice(0)) cb(code);
    };
    proc.once('exit', exitNow);
    proc.once('error', () => exitNow(-1));
  }

  /** The environment a ChatGPT / Gemini / Copilot tool runs with for one account folder: its own home, never the hub's credentials. */
  private cliEnv(provider: CliProvider, dir: string): Record<string, string | undefined> {
    const env = withNewNode(childEnv(this.env, { [CLI_HOME_ENV[provider]]: dir }), MIN_NODE[provider], this.d.profilesDir);
    // Another account's key in the agent's own environment must not take over this one.
    for (const k of FOREIGN_KEYS) delete env[k];
    if (provider === 'copilot') env.COPILOT_AUTO_UPDATE = 'false';
    return env;
  }

  /** Copilot: GitHub's device sign-in prints its page and a code; Copilot itself waits for the person to approve. */
  private async startCopilotDevice(f: { accountId: string; dir: string; label?: string; email?: string; onlyDefault: boolean; bin: string }): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const env = this.cliEnv('copilot', f.dir);
    env.BROWSER = 'true';
    delete env.DISPLAY;
    delete env.WAYLAND_DISPLAY;
    let proc: LoginProc;
    try {
      proc = this.spawnFn(f.bin, ['login', '--device-code'], env);
    } catch {
      rmSync(f.dir, { recursive: true, force: true });
      return { ok: false, error: 'GitHub Copilot could not be started on this computer to sign in.' };
    }
    // No name given: the GitHub account's own name is used once it is known (copilotDeviceDone).
    const flow = this.newFlow({ ...f, label: f.label ?? '', provider: 'copilot', method: 'signin', proc });
    const got = await new Promise<{ url: string; userCode: string } | null>((resolve) => {
      let text = '';
      const done = (v: { url: string; userCode: string } | null) => {
        clearTimeout(t);
        proc.stdout?.off('data', onData);
        proc.stderr?.off('data', onData);
        resolve(v);
      };
      const onData = (b: Buffer | string) => {
        text = (text + b.toString()).slice(-16_384);
        const v = copilotDeviceIn(text);
        if (v) done(v);
      };
      const t = setTimeout(() => done(null), this.d.urlWaitMs ?? URL_WAIT_MS);
      proc.stdout?.on('data', onData);
      proc.stderr?.on('data', onData);
      flow.onExit.push(() => done(copilotDeviceIn(text)));
    });
    if (!got || flow.exited !== undefined) {
      this.drop(flow, true);
      return { ok: false, error: 'GitHub Copilot did not show a sign-in code on this computer. Try again in a minute.' };
    }
    proc.stdout?.resume();
    proc.stderr?.resume();
    return { ok: true, flowId: flow.id, url: got.url, userCode: got.userCode, method: 'signin' };
  }

  /** Copilot: the person approved the code on GitHub's page; Copilot finishes by itself (up to CODE_WAIT_MS). */
  private async copilotDeviceDone(flow: Flow): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const exit = await new Promise<number | null>((resolve) => {
      if (flow.exited !== undefined) return resolve(flow.exited);
      const t = setTimeout(() => resolve(-2), this.d.codeWaitMs ?? CODE_WAIT_MS);
      flow.onExit.push((c) => {
        clearTimeout(t);
        resolve(c);
      });
    });
    if (exit === -2) {
      // Still waiting for the approval: the sign-in stays open, so "Done" can be tapped again.
      return { ok: false, error: 'GitHub has not seen the approval yet. Enter the code on the GitHub page and approve it, then try again.' };
    }
    const login = copilotLoginIn(flow.dir);
    if (exit !== 0 || !login) {
      this.drop(flow, true);
      return { ok: false, error: 'GitHub Copilot did not finish signing in, or the code expired. Start again.' };
    }
    if (!flow.label) flow.label = `${login} (Copilot)`;
    return this.finish(flow, flow.email);
  }

  /**
   * Copilot with a token: GitHub says whose it is (a token GitHub refuses is turned away), and, where it can tell, whether that
   * account has Copilot for the command line. Returns the GitHub account's name, or why the token cannot be used.
   */
  private async copilotToken(key: string): Promise<{ login: string | null } | { error: string; retry?: boolean }> {
    const headers = { Authorization: `Bearer ${key}`, Accept: 'application/vnd.github+json', 'User-Agent': 'escanor-agent' };
    let login: string | null = null;
    try {
      const res = await this.fetchFn(GITHUB_USER_URL, { headers, signal: AbortSignal.timeout(15_000) });
      if (res.status === 401) return { error: 'GitHub did not accept that token. Check it on github.com/settings/tokens, then paste it again.', retry: true };
      const j = (await res.json().catch(() => ({}))) as { login?: unknown };
      if (res.ok && typeof j.login === 'string') login = j.login;
    } catch {
      return { error: 'This computer could not reach GitHub to check the token. Check its internet connection, then paste it again.', retry: true };
    }
    try {
      const res = await this.fetchFn(COPILOT_USER_URL, { headers, signal: AbortSignal.timeout(15_000) });
      if (res.ok) {
        const j = (await res.json().catch(() => ({}))) as { chat_enabled?: unknown; cli_enabled?: unknown };
        if (j.chat_enabled === false || j.cli_enabled === false) {
          return { error: 'This GitHub account has no Copilot for the command line. Turn on Copilot Free (or a paid plan) at github.com/settings/copilot, then start again.' };
        }
      }
    } catch {
      // Copilot itself says so at the first chat.
    }
    return { login };
  }

  /** ChatGPT: Codex's device sign-in prints its page and a one-time code; Codex itself waits for the person to approve. */
  private async startDevice(f: { accountId: string; dir: string; label: string; email?: string; onlyDefault: boolean; bin: string }): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const env = this.cliEnv('chatgpt', f.dir);
    env.BROWSER = 'true';
    delete env.DISPLAY;
    delete env.WAYLAND_DISPLAY;
    let proc: LoginProc;
    try {
      proc = this.spawnFn(f.bin, ['login', '--device-auth'], env);
    } catch {
      rmSync(f.dir, { recursive: true, force: true });
      return { ok: false, error: 'ChatGPT could not be started on this computer to sign in.' };
    }
    const flow = this.newFlow({ ...f, provider: 'chatgpt', method: 'signin', proc });
    const got = await new Promise<{ url: string; userCode: string } | null>((resolve) => {
      let text = '';
      const done = (v: { url: string; userCode: string } | null) => {
        clearTimeout(t);
        proc.stdout?.off('data', onData);
        proc.stderr?.off('data', onData);
        resolve(v);
      };
      const onData = (b: Buffer | string) => {
        text = (text + b.toString()).slice(-16_384);
        const v = deviceLoginIn(text);
        if (v) done(v);
      };
      const t = setTimeout(() => done(null), this.d.urlWaitMs ?? URL_WAIT_MS);
      proc.stdout?.on('data', onData);
      proc.stderr?.on('data', onData);
      flow.onExit.push(() => done(deviceLoginIn(text)));
    });
    if (!got || flow.exited !== undefined) {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT did not show a sign-in code on this computer. Try again in a minute.' };
    }
    proc.stdout?.resume();
    proc.stderr?.resume();
    return { ok: true, flowId: flow.id, url: got.url, userCode: got.userCode, method: 'signin' };
  }

  private async code(flowId: unknown, rawCode: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const flow = typeof flowId === 'string' ? this.flows.get(flowId) : undefined;
    if (!flow) return { ok: false, error: 'That sign-in has ended. Start again.' };
    if (flow.method === 'key') return this.keyCode(flow, rawCode);
    if (flow.provider === 'chatgpt' && rawCode === BROWSER_SIGNIN) return this.startBrowser(flow);
    if (flow.provider === 'chatgpt' && flow.browser) return this.browserDone(flow, rawCode);
    if (flow.provider === 'chatgpt') return this.deviceDone(flow);
    if (flow.provider === 'gemini') return this.googleCode(flow, rawCode);
    if (flow.provider === 'copilot') return this.copilotDeviceDone(flow);
    const code = cleanCode(rawCode);
    if (!code) return { ok: false, error: 'Paste the whole code from the Claude page, with nothing else.' };
    const exit = await new Promise<number | null>((resolve) => {
      if (flow.exited !== undefined) return resolve(flow.exited);
      const t = setTimeout(() => resolve(-2), this.d.codeWaitMs ?? CODE_WAIT_MS);
      flow.onExit.push((c) => {
        clearTimeout(t);
        resolve(c);
      });
      try {
        flow.proc?.stdin?.write(`${code}\n`);
      } catch {
        clearTimeout(t);
        resolve(-1);
      }
    });
    if (exit !== 0) {
      this.drop(flow, true);
      return {
        ok: false,
        error: exit === -2 ? 'Claude did not finish signing in. Start again.' : 'That code did not work, or it expired. Start again and paste the newest code.',
      };
    }
    const status = await this.authStatus(flow.dir);
    if (!status.loggedIn) {
      this.drop(flow, true);
      return { ok: false, error: 'Claude did not keep the sign-in. Start again.' };
    }
    return this.finish(flow, status.email ?? flow.email);
  }

  /** Finished: the folder becomes an account. */
  private async finish(flow: Flow, email: string | undefined): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const meta = {
      label: flow.label,
      ...(email ? { email } : {}),
      provider: flow.provider,
      ...(flow.method === 'key' ? { method: 'key' } : {}),
      addedFrom: 'phone',
    };
    writeFileSync(join(flow.dir, ACCOUNT_META_FILE), JSON.stringify(meta), { mode: 0o600 });
    if (flow.onlyDefault && !existsSync(join(this.d.profilesDir, KEEP_DEFAULT_FILE)) && (await this.authStatus(undefined)).loggedIn) {
      // The account the machine was already signed in with stays next to the new one.
      writeFileSync(join(this.d.profilesDir, KEEP_DEFAULT_FILE), JSON.stringify({ label: this.d.profiles[0]?.label ?? 'default' }), { mode: 0o600 });
    }
    rmSync(join(flow.dir, PENDING_MARK), { force: true });
    this.drop(flow, false);
    refreshProfiles(this.d.profiles, this.d.profilesDir);
    // Signed in once, usable everywhere: a Claude sign-in goes to the workspace (the backend renews it from now on).
    if (flow.provider === 'claude' && flow.method !== 'key' && this.d.workspace?.autoShare) await this.d.workspace.share(flow.accountId).catch(() => undefined);
    const account = this.accounts().find((a) => a.id === flow.accountId) ?? { id: flow.accountId, label: flow.label };
    return { ok: true, account, accounts: this.accounts() };
  }

  /** An API key for the account: kept only in its folder (0600), and for ChatGPT given to Codex's own login too. */
  private async keyCode(flow: Flow, raw: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const k = cleanApiKey(flow.provider, raw);
    // The flow stays open after a mistyped key, so the person can paste it again.
    if ('error' in k) return { ok: false, error: k.error };
    if (flow.provider === 'chatgpt') {
      const r = await this.runCmd(flow.bin!, ['login', '--with-api-key'], this.cliEnv('chatgpt', flow.dir), 30_000, `${k.key}\n`);
      const st = r.code === 0 ? await this.runCmd(flow.bin!, ['login', 'status'], this.cliEnv('chatgpt', flow.dir), 20_000) : null;
      if (!st || st.code !== 0) {
        this.drop(flow, true);
        return { ok: false, error: 'ChatGPT did not take that key. Check it on platform.openai.com, then start again.' };
      }
    } else {
      if (flow.provider === 'copilot') {
        const who = await this.copilotToken(k.key);
        if ('error' in who) {
          // A token GitHub refused (or that could not be checked) can be pasted again; an account without Copilot cannot.
          if (!who.retry) this.drop(flow, true);
          return { ok: false, error: who.error };
        }
        if (who.login && flow.label === flow.accountId) flow.label = `${who.login} (Copilot)`;
      }
      writeFileSync(join(flow.dir, API_KEY_FILE), k.key, { mode: 0o600 });
      chmodSync(join(flow.dir, API_KEY_FILE), 0o600);
      if (flow.provider === 'gemini') this.writeGeminiFiles(flow.dir, 'gemini-api-key');
    }
    return this.finish(flow, flow.email);
  }

  /** ChatGPT: the person approved the code on the page; Codex finishes by itself (up to CODE_WAIT_MS). */
  private async deviceDone(flow: Flow): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const exit = await new Promise<number | null>((resolve) => {
      if (flow.exited !== undefined) return resolve(flow.exited);
      const t = setTimeout(() => resolve(-2), this.d.codeWaitMs ?? CODE_WAIT_MS);
      flow.onExit.push((c) => {
        clearTimeout(t);
        resolve(c);
      });
    });
    if (exit === -2) {
      // Still waiting for the approval: the sign-in stays open, so "I've approved it" can be tapped again.
      return { ok: false, error: 'ChatGPT has not seen the approval yet. Enter the code on the page and approve it, then try again.' };
    }
    if (exit !== 0) {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT did not finish signing in, or the code expired. Start again.' };
    }
    return this.chatgptDone(flow);
  }

  /**
   * ChatGPT, newer phones: Codex's normal sign-in (`codex login`) replaces the device sign-in, so nothing has to be turned on in
   * ChatGPT's settings. Answers with ChatGPT's page; the flow and its folder stay the same.
   */
  private async startBrowser(flow: Flow): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    if (flow.browser) return { ok: false, error: 'This sign-in already uses the ChatGPT page. Start again.' };
    const old = flow.proc;
    const oldExited = flow.exited;
    const env = this.cliEnv('chatgpt', flow.dir);
    env.BROWSER = 'true';
    delete env.DISPLAY;
    delete env.WAYLAND_DISPLAY;
    let proc: LoginProc;
    try {
      proc = this.spawnFn(flow.bin!, ['login'], env);
    } catch {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT could not be started on this computer to sign in.' };
    }
    this.attach(flow, proc);
    if (old && oldExited === undefined) {
      try {
        old.kill('SIGTERM');
      } catch {
        // already gone
      }
    }
    const got = await new Promise<CodexBrowserLogin | null>((resolve) => {
      let text = '';
      const done = (v: CodexBrowserLogin | null) => {
        clearTimeout(t);
        proc.stdout?.off('data', onData);
        proc.stderr?.off('data', onData);
        resolve(v);
      };
      const onData = (b: Buffer | string) => {
        text = (text + b.toString()).slice(-16_384);
        const v = codexBrowserLoginIn(text);
        if (v) done(v);
      };
      const t = setTimeout(() => done(null), this.d.urlWaitMs ?? URL_WAIT_MS);
      proc.stdout?.on('data', onData);
      proc.stderr?.on('data', onData);
      flow.onExit.push(() => done(null));
    });
    if (!got || flow.exited !== undefined) {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT did not show a sign-in page on this computer. Try again in a minute.' };
    }
    proc.stdout?.resume();
    proc.stderr?.resume();
    flow.browser = { state: got.state, callback: got.callback };
    return { ok: true, flowId: flow.id, url: got.url, method: 'signin' };
  }

  /** ChatGPT, Codex's normal sign-in: the address ChatGPT's page sent the browser back to goes to Codex here, which finishes. */
  private async browserDone(flow: Flow, raw: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const b = flow.browser!;
    const got = codexCallbackIn(raw);
    // A wrong paste keeps the sign-in open, so the person can paste the right address.
    if (!got) return { ok: false, error: 'That is not the address ChatGPT\'s page went to. Sign in on the ChatGPT page, then copy the address it shows and paste it here.' };
    if ('error' in got) {
      this.drop(flow, true);
      return { ok: false, error: 'The sign-in was cancelled on the ChatGPT page. Start again.' };
    }
    if (got.state !== b.state) return { ok: false, error: 'That is not the address of this sign-in. Paste the address the newest ChatGPT page went to.' };
    if (flow.exited !== undefined) {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT did not finish signing in. Start again.' };
    }
    const exit = await new Promise<number | null>((resolve) => {
      const t = setTimeout(() => resolve(-2), this.d.codeWaitMs ?? CODE_WAIT_MS);
      flow.onExit.push((c) => {
        clearTimeout(t);
        resolve(c);
      });
      const url = `${b.callback}?${new URLSearchParams({ code: got.code, state: got.state }).toString()}`;
      (this.d.forwardCallback ?? forwardCallback)(url).catch(() => {
        // Codex answers once it has finished; its exit says how that went.
      });
    });
    if (exit !== 0) {
      this.drop(flow, true);
      return { ok: false, error: exit === -2 ? 'ChatGPT did not finish signing in. Start again.' : 'ChatGPT did not accept that sign-in, or it expired. Start again.' };
    }
    return this.chatgptDone(flow);
  }

  /** ChatGPT's tool has finished signing in: checked, then the folder becomes an account. */
  private async chatgptDone(flow: Flow): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const st = await this.runCmd(flow.bin!, ['login', 'status'], this.cliEnv('chatgpt', flow.dir), 20_000);
    if (st.code !== 0) {
      this.drop(flow, true);
      return { ok: false, error: 'ChatGPT did not keep the sign-in. Start again.' };
    }
    let email: string | null = null;
    try {
      email = emailFromIdToken((JSON.parse(readFileSync(join(flow.dir, 'auth.json'), 'utf8')) as { tokens?: { id_token?: unknown } }).tokens?.id_token);
    } catch {
      // no email to show: the name is enough
    }
    return this.finish(flow, email ?? flow.email);
  }

  /** Gemini: the code from Google's page is exchanged for the login, written where Gemini CLI keeps it. */
  private async googleCode(flow: Flow, raw: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const code = cleanCode(raw);
    if (!code || !flow.google) return { ok: false, error: 'Paste the whole code from the Google page, with nothing else.' };
    const g = flow.google;
    let tokens: { access_token?: unknown; refresh_token?: unknown; expires_in?: unknown; scope?: unknown; token_type?: unknown; id_token?: unknown };
    try {
      const res = await this.fetchFn(GOOGLE_TOKEN_URL, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ code, client_id: g.clientId, client_secret: g.clientSecret, code_verifier: g.verifier, grant_type: 'authorization_code', redirect_uri: GEMINI_REDIRECT_URI }).toString(),
        signal: AbortSignal.timeout(20_000),
      });
      tokens = (await res.json()) as typeof tokens;
      if (!res.ok || typeof tokens.access_token !== 'string') {
        this.drop(flow, true);
        return { ok: false, error: 'That code did not work, or it expired. Start again and paste the newest code.' };
      }
    } catch {
      return { ok: false, error: 'This computer could not reach Google to finish signing in. Check its internet connection, then paste the code again.' };
    }
    const now = (this.d.now ?? Date.now)();
    const expiresIn = typeof tokens.expires_in === 'number' ? tokens.expires_in : 3600;
    const creds = {
      access_token: tokens.access_token,
      ...(typeof tokens.refresh_token === 'string' ? { refresh_token: tokens.refresh_token } : {}),
      ...(typeof tokens.scope === 'string' ? { scope: tokens.scope } : {}),
      token_type: typeof tokens.token_type === 'string' ? tokens.token_type : 'Bearer',
      ...(typeof tokens.id_token === 'string' ? { id_token: tokens.id_token } : {}),
      expiry_date: now + expiresIn * 1000,
    };
    const gdir = join(flow.dir, '.gemini');
    mkdirSync(gdir, { recursive: true, mode: 0o700 });
    writeFileSync(join(gdir, 'oauth_creds.json'), JSON.stringify(creds, null, 2), { mode: 0o600 });
    chmodSync(join(gdir, 'oauth_creds.json'), 0o600);
    this.writeGeminiFiles(flow.dir, 'oauth-personal');
    let email = emailFromIdToken(tokens.id_token);
    try {
      const res = await this.fetchFn(GOOGLE_USERINFO_URL, { headers: { Authorization: `Bearer ${tokens.access_token}` }, signal: AbortSignal.timeout(15_000) });
      const info = (await res.json()) as { email?: unknown };
      if (res.ok && typeof info.email === 'string' && EMAIL_RE.test(info.email)) email = info.email.toLowerCase();
    } catch {
      // the id token's email (if any) is enough
    }
    if (email) writeFileSync(join(gdir, 'google_accounts.json'), JSON.stringify({ active: email, old: [] }, null, 2), { mode: 0o600 });
    return this.finish(flow, email ?? flow.email);
  }

  /** Gemini CLI's settings for the account folder: how it signs in (kept with whatever else is already set there). */
  private writeGeminiFiles(dir: string, selectedType: 'oauth-personal' | 'gemini-api-key'): void {
    const gdir = join(dir, '.gemini');
    mkdirSync(gdir, { recursive: true, mode: 0o700 });
    const file = join(gdir, 'settings.json');
    let prev: Record<string, unknown> = {};
    try {
      prev = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
    } catch {
      prev = {};
    }
    const security = (prev.security && typeof prev.security === 'object' ? prev.security : {}) as Record<string, unknown>;
    const auth = (security.auth && typeof security.auth === 'object' ? security.auth : {}) as Record<string, unknown>;
    writeFileSync(file, JSON.stringify({ ...prev, security: { ...security, auth: { ...auth, selectedType } } }, null, 2), { mode: 0o600 });
  }

  private rename(accountId: unknown, rawLabel: unknown): Omit<AgentAccountResult, 'type' | 'requestId'> {
    const p = this.d.profiles.find((x) => x.id === accountId);
    if (!p) return { ok: false, error: 'That account is not on this computer.' };
    const label = cleanLabel(rawLabel);
    if (!label) return { ok: false, error: `A name is 1 to ${MAX_LABEL} characters on one line.` };
    mkdirSync(this.d.profilesDir, { recursive: true, mode: 0o700 });
    const file = p.configDir ? join(p.configDir, ACCOUNT_META_FILE) : join(this.d.profilesDir, KEEP_DEFAULT_FILE);
    let prev: Record<string, unknown> = {};
    try {
      prev = JSON.parse(readFileSync(file, 'utf8')) as Record<string, unknown>;
    } catch {
      prev = {};
    }
    writeFileSync(file, JSON.stringify({ ...prev, label }), { mode: 0o600 });
    refreshProfiles(this.d.profiles, this.d.profilesDir);
    const account = this.accounts().find((a) => a.id === p.id) ?? { id: p.id, label };
    return { ok: true, account, accounts: this.accounts() };
  }

  private async remove(accountId: unknown): Promise<Omit<AgentAccountResult, 'type' | 'requestId'>> {
    const p = this.d.profiles.find((x) => x.id === accountId);
    if (!p) return { ok: false, error: 'That account is not on this computer.' };
    if (this.d.profiles.length <= 1) return { ok: false, error: 'This is the only account on this computer, so it stays.' };
    if (this.d.busyAccounts().has(p.id)) return { ok: false, error: 'A chat is running on this account. Stop it first, then remove the account.' };
    if (this.d.workspace?.isShared(p.id)) return { ok: false, error: 'This account is shared by the whole workspace. Remove it from the workspace\'s accounts list (Accounts, shared accounts) and every machine drops it.' };
    if (!p.configDir) {
      // The machine's own login is only hidden from Escanor: signing it out would sign out Claude in this computer's terminal too.
      rmSync(join(this.d.profilesDir, KEEP_DEFAULT_FILE), { force: true });
    } else {
      const provider = providerOf(p);
      if (provider === 'claude') await this.runClaude(['auth', 'logout'], p.configDir, 20_000);
      else if (provider === 'chatgpt') {
        const bin = this.d.cliBins?.chatgpt ?? resolveCliBin('chatgpt', this.env, this.d.profilesDir);
        if (bin) await this.runCmd(bin, ['logout'], this.cliEnv('chatgpt', p.configDir), 20_000);
      }
      // The login and any key are not kept aside with the chats.
      for (const f of [API_KEY_FILE, 'auth.json', join('.gemini', 'oauth_creds.json')]) rmSync(join(p.configDir, f), { force: true });
      const aside = join(this.d.profilesDir, '.removed');
      mkdirSync(aside, { recursive: true, mode: 0o700 });
      // Kept aside, not deleted: its chat history stays on this computer.
      renameSync(p.configDir, join(aside, `${p.id}-${Date.now()}`));
    }
    refreshProfiles(this.d.profiles, this.d.profilesDir);
    return { ok: true, accounts: this.accounts() };
  }

  private drop(flow: Flow, removeFolder: boolean): void {
    clearTimeout(flow.timer);
    this.flows.delete(flow.id);
    if (flow.exited === undefined && flow.proc) {
      try {
        flow.proc.kill('SIGTERM');
      } catch {
        // already gone
      }
    }
    if (removeFolder && existsSync(join(flow.dir, PENDING_MARK))) rmSync(flow.dir, { recursive: true, force: true });
  }

  private async authStatus(configDir: string | undefined): Promise<{ loggedIn: boolean; email: string | null }> {
    const out = await this.runClaude(['auth', 'status', '--json'], configDir, 20_000);
    try {
      const j = JSON.parse(out.slice(out.indexOf('{'))) as { loggedIn?: unknown; email?: unknown };
      return { loggedIn: j.loggedIn === true, email: typeof j.email === 'string' && j.email ? j.email : null };
    } catch {
      return { loggedIn: false, email: null };
    }
  }

  /** Runs a short Claude command for one account folder (the machine's own login when none), and returns what it printed. */
  private async runClaude(args: string[], configDir: string | undefined, timeoutMs: number): Promise<string> {
    return (await this.runCmd(this.bin, args, childEnv(this.env, configDir ? { CLAUDE_CONFIG_DIR: configDir } : {}), timeoutMs)).out;
  }

  /** Commands run to their end through the same spawn (npm installs included), so tests see every one. */
  private runFn: RunFn = (bin, args, o) => this.runCmd(bin, args, o.env, o.timeoutMs, o.input);

  /** Runs a short command and returns how it ended and what it printed ([input] written to it first, then its stdin closed). */
  private runCmd(bin: string, args: string[], env: Record<string, string | undefined>, timeoutMs: number, input?: string): Promise<RunResult> {
    return new Promise((resolve) => {
      let out = '';
      let err = '';
      let settled = false;
      const finish = (r: RunResult) => {
        if (settled) return;
        settled = true;
        clearTimeout(t);
        resolve(r);
      };
      let proc: LoginProc;
      try {
        proc = this.spawnFn(bin, args, env);
      } catch {
        resolve({ code: -1, out: '', err: '', missing: true });
        return;
      }
      const t = setTimeout(() => {
        try {
          proc.kill('SIGTERM');
        } catch {
          // gone
        }
        finish({ code: -2, out, err });
      }, timeoutMs);
      proc.stdout?.on('data', (b: Buffer | string) => {
        out = (out + b.toString()).slice(-65_536);
      });
      proc.stderr?.on('data', (b: Buffer | string) => {
        err = (err + b.toString()).slice(-16_384);
      });
      try {
        if (input) proc.stdin?.write(input);
        proc.stdin?.end();
      } catch {
        // it already went
      }
      proc.once('exit', (code) => finish({ code, out, err }));
      proc.once('error', (e) => finish({ code: -1, out, err, missing: (e as NodeJS.ErrnoException).code === 'ENOENT' }));
    });
  }
}
