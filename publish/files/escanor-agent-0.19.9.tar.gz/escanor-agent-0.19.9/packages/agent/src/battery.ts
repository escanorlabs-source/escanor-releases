/**
 * The battery of this computer, on Linux, macOS and Windows: its level and whether it is on mains power. Reading it fails quietly:
 * a machine without a battery (a desktop, a server, a VM) gives null and is never told to plug in.
 */
import { execFile } from 'node:child_process';
import { readdirSync, readFileSync } from 'node:fs';

export type Battery = { pct: number; charging: boolean };
export type BatteryExec = (cmd: string, args: string[], timeoutMs: number) => Promise<{ code: number; stdout: string }>;

const clampPct = (n: number): number | null => (Number.isFinite(n) && n >= 0 && n <= 100 ? Math.round(n) : null);

/** Linux /sys/class/power_supply/BAT*: capacity ("57") and status ("Discharging", "Charging", "Full", "Not charging", "Unknown"). Only "Discharging" is on battery; "Unknown" is not taken to mean unplugged. */
export function parseLinuxBattery(capacity: string, status: string): Battery | null {
  const pct = /^\d{1,3}$/.test(capacity.trim()) ? clampPct(Number(capacity.trim())) : null;
  if (pct === null) return null;
  return { pct, charging: status.trim().toLowerCase() !== 'discharging' };
}

/** macOS `pmset -g batt`: "Now drawing from 'Battery Power'" or "'AC Power'", then " -InternalBattery-0 (id=...)\t57%; discharging; 3:10 remaining". No battery line = null. */
export function parsePmset(out: string): Battery | null {
  const m = /(\d{1,3})%;\s*([^;\n]*)/.exec(out);
  if (!m) return null;
  const pct = clampPct(Number(m[1]));
  if (pct === null) return null;
  const onBattery = /drawing from 'ac power'/i.test(out) ? false : /drawing from 'battery power'/i.test(out) || /^\s*discharging\s*$/i.test(m[2] ?? '');
  return { pct, charging: !onBattery };
}

/** Windows, from `Get-CimInstance Win32_Battery | % { "$($_.EstimatedChargeRemaining),$($_.BatteryStatus)" }`. BatteryStatus 1 = discharging, 4 = low, 5 = critical (all on battery); 2, 3, 6-9 = on mains. No line = no battery. */
export function parseWindowsBattery(out: string): Battery | null {
  const m = /^\s*(\d{1,3})\s*,\s*(\d+)\s*$/m.exec(out);
  if (!m) return null;
  const pct = clampPct(Number(m[1]));
  if (pct === null) return null;
  return { pct, charging: ![1, 4, 5].includes(Number(m[2])) };
}

function linuxBattery(): Battery | null {
  try {
    const bat = readdirSync('/sys/class/power_supply').filter((d) => /^BAT/.test(d)).sort()[0];
    if (!bat) return null;
    return parseLinuxBattery(readFileSync(`/sys/class/power_supply/${bat}/capacity`, 'utf8'), readFileSync(`/sys/class/power_supply/${bat}/status`, 'utf8'));
  } catch {
    return null;
  }
}

/** One reading for this computer, or null when there is no battery or it cannot be read. */
export async function readBattery(exec: BatteryExec, platform: NodeJS.Platform = process.platform): Promise<Battery | null> {
  try {
    if (platform === 'linux') return linuxBattery();
    if (platform === 'darwin') {
      const r = await exec('pmset', ['-g', 'batt'], 3000);
      return r.code === 0 ? parsePmset(r.stdout) : null;
    }
    if (platform === 'win32') {
      const r = await exec('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Get-CimInstance Win32_Battery | ForEach-Object { "$($_.EstimatedChargeRemaining),$($_.BatteryStatus)" }`], 6000);
      return r.code === 0 ? parseWindowsBattery(r.stdout) : null;
    }
  } catch {
    // no such program: no battery to tell about
  }
  return null;
}

/** A plain run with the normal environment (PowerShell needs its system variables), a short deadline, and no window on Windows. */
export const batteryExec: BatteryExec = (cmd, args, timeoutMs) =>
  new Promise((resolve, reject) => {
    execFile(cmd, args, { timeout: timeoutMs, windowsHide: true, maxBuffer: 64 * 1024 }, (err, stdout) => {
      if (err && (err as NodeJS.ErrnoException).code === 'ENOENT') return reject(err);
      resolve({ code: err ? 1 : 0, stdout: String(stdout ?? '') });
    });
  });
