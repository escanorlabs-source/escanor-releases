import { fetchDeviceMcp } from './deviceMcp.js';

/**
 * Asks Escanor's API for this machine's git login, SSH key and env secrets (VAULT3). The machine signs in with its own device key,
 * which it gets with the hub agent token it already has (deviceMcp.ts, the same route the agent itself uses); the key lives in
 * this process's memory only. Never throws: a failure is a short reason a person can act on, with no value in it.
 */

export type Result<T> = { ok: true; value: T } | { ok: false; reason: string };

export interface Conn {
  apiUrl: string;
  hubToken: string;
  vmName: string;
  agentVersion: string;
  fetchImpl?: typeof fetch;
}

const TIMEOUT_MS = 20_000;

export async function deviceKey(c: Conn): Promise<Result<string>> {
  const r = await fetchDeviceMcp({ apiUrl: c.apiUrl, hubToken: c.hubToken, vmName: c.vmName, agentVersion: c.agentVersion, fetchImpl: c.fetchImpl });
  if (r.kind === 'ok') return { ok: true, value: (r.server.headers?.Authorization ?? '').replace(/^Bearer\s+/i, '') };
  if (r.kind === 'limit') return { ok: false, reason: r.message };
  return { ok: false, reason: r.kind === 'drop' ? `this machine's Escanor key was ${r.reason}; pair it again` : `could not get this machine's key (${r.reason})` };
}

async function call(c: Conn, key: string, method: 'GET' | 'POST', path: string, body?: unknown): Promise<Result<Record<string, unknown>>> {
  const doFetch = c.fetchImpl ?? fetch;
  let res: Response;
  try {
    res = await doFetch(`${c.apiUrl}${path}`, {
      method,
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${c.agentVersion}` },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.name : 'network' };
  }
  let json: unknown = null;
  try {
    json = await res.json();
  } catch {
    json = null;
  }
  if (!res.ok) return { ok: false, reason: `HTTP ${res.status}` };
  if (!json || typeof json !== 'object') return { ok: false, reason: 'malformed answer' };
  return { ok: true, value: json as Record<string, unknown> };
}

export async function gitCredential(c: Conn, key: string, q: { protocol: string; host: string; path: string }): Promise<Result<{ username: string; password: string }>> {
  const r = await call(c, key, 'POST', '/machines/git-credential', q);
  if (!r.ok) return r;
  const { username, password } = r.value;
  if (typeof username !== 'string' || typeof password !== 'string' || !password) return { ok: false, reason: 'malformed answer' };
  return { ok: true, value: { username, password } };
}

export async function resolveSecrets(c: Conn, key: string, scope: string, names?: string[]): Promise<Result<{ values: Record<string, string>; missing: string[] }>> {
  const r = await call(c, key, 'POST', '/vault/resolve', { scope, ...(names ? { names } : {}) });
  if (!r.ok) return r;
  const raw = (r.value.values ?? r.value.secrets) as Record<string, unknown> | undefined;
  if (!raw || typeof raw !== 'object') return { ok: false, reason: 'malformed answer' };
  const values: Record<string, string> = {};
  for (const [k, v] of Object.entries(raw)) if (typeof v === 'string') values[k] = v;
  const missing = Array.isArray(r.value.missing) ? r.value.missing.filter((m): m is string => typeof m === 'string') : [];
  return { ok: true, value: { values, missing } };
}

export interface SshKeyInfo {
  public_key: string;
  fingerprint: string;
  added_to_github: boolean;
  message?: string;
}

export async function ensureSshKey(c: Conn, key: string): Promise<Result<SshKeyInfo>> {
  const r = await call(c, key, 'POST', '/machines/ssh-key');
  if (!r.ok) return r;
  const v = r.value;
  if (typeof v.public_key !== 'string' || typeof v.fingerprint !== 'string') return { ok: false, reason: 'malformed answer' };
  return { ok: true, value: { public_key: v.public_key, fingerprint: v.fingerprint, added_to_github: v.added_to_github === true, ...(typeof v.message === 'string' ? { message: v.message } : {}) } };
}

export async function sshPrivateKey(c: Conn, key: string): Promise<Result<string>> {
  const r = await call(c, key, 'GET', '/machines/ssh-key/private');
  if (!r.ok) return r;
  return typeof r.value.private_key === 'string' && r.value.private_key ? { ok: true, value: r.value.private_key } : { ok: false, reason: 'malformed answer' };
}

/**
 * F2: tell Escanor which keys a push scan or a chat scrub found here, as SHA-256 fingerprints with where each was found (never a
 * key). Escanor tells the workspace's owner once for each that is one of the workspace's own stored keys (mongo-backend key_leaks.py).
 */
export async function leakReport(
  c: Conn,
  key: string,
  body: { findings: Array<{ fingerprint: string; where: string }>; source: 'push' | 'chat' },
): Promise<Result<{ told: number }>> {
  const r = await call(c, key, 'POST', '/machines/leak-report', { findings: body.findings.slice(0, 50), source: body.source });
  if (!r.ok) return r;
  return { ok: true, value: { told: typeof r.value.told === 'number' ? r.value.told : 0 } };
}
