import type { MeshRequest } from './meshAsk.js';
import type { PhoneAsk } from './phoneAsk.js';

/**
 * Device mesh by voice, the computer's side: a spoken sentence that names the owner's phone ("ring my phone", "what is my phone
 * battery", "send example.com to my phone", "pause the music on my phone") becomes one of the phone's fixed requests (phoneAsk.ts),
 * which the agent passes through the hub. Only the requests the hub already allows (ring, stop_ring, battery, torch, media,
 * receive_link, open_link, open_app): nothing new that acts on its own. Any other sentence that names the phone is turned away in words instead of being
 * run on this computer by mistake ("open example.com on my phone" must never open an app here).
 */

export type MeshVoice = { kind: 'phone'; ask: PhoneAsk; wording: string } | { kind: 'mesh'; req: MeshRequest; wording: string } | { kind: 'refuse'; say: string };

const PHONE = '(?:phone|mobile|cell|smartphone|android)';
const ON_PHONE = new RegExp(`\\b(?:on|to|in|onto|at)\\s+(?:my|the)\\s+${PHONE}\\b`);
const MY_PHONE = new RegExp(`\\b(?:my|the)\\s+${PHONE}\\b`);
const URL_RE = /https?:\/\/[^\s]+/i;
const DOMAIN_RE = /\b((?:[a-z0-9-]+\.)+(?:com|in|org|net|io|ai|co|app|dev|me|tv|edu|gov)(?:\/[^\s]*)?)\b/i;

const plain = (s: string): string =>
  s
    .toLowerCase()
    .replace(/[?!,;]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

/** The link in a sentence: a full address, or a bare site name, or null. Only http(s). */
export function linkIn(raw: string, said: string): string | null {
  const full = raw.match(URL_RE);
  if (full) return full[0].replace(/[.)]+$/, '');
  const dom = said.match(DOMAIN_RE);
  if (dom) return `https://${dom[1]}`;
  const name = said.match(/\b(?:open|show|send|share|push)\s+(youtube|google|gmail|maps)\b/);
  if (name) return name[1] === 'youtube' ? 'https://www.youtube.com/' : name[1] === 'maps' ? 'https://maps.google.com/' : `https://${name[1]}.com/`;
  return null;
}

// Another of the owner's computers (a desktop, a second laptop, a server or VM), named as "my desktop" / "the server".
const COMPUTER = '(?:desktop|laptop|computer|pc|server|vm|workstation|mac|macbook)';
// "my laptop", "my computer", "my pc" usually mean the computer being spoken to, so they stay local unless qualified ("my other laptop").
const OTHER = '(?:other|second|work|home|office)';
const NAMED = `(?:(?:${OTHER}\\s+)(?:desktop|laptop|computer|pc|server|vm|workstation|mac|macbook)|desktop|server|vm|workstation)`;
const ON_COMPUTER = new RegExp(`\\b(?:on|to|in|onto|at)\\s+(?:my|the)\\s+(${NAMED})\\b`);
const LOCK_COMPUTER = new RegExp(`\\block\\s+(?:my|the)\\s+(${NAMED})\\b`);
const ASK_COMPUTER = new RegExp(`\\bask\\s+(?:my|the)\\s+(${NAMED})\\s+(?:to\\s+|if\\s+|whether\\s+|what\\s+|how\\s+|for\\s+)?(.+)$`);

/** A sentence that names another computer (not the phone): list the devices, open a page or app there, hand it a link, ask it something. */
function routeComputers(raw: string, said: string): MeshVoice | null {
  if (/\b(?:what|which|list|show)\b.*\b(?:devices|computers)\b/.test(said) && /\b(?:my|do i|have)\b/.test(said)) {
    return { kind: 'mesh', req: { op: 'list' }, wording: 'Looking at your devices.' };
  }
  const ask = said.match(ASK_COMPUTER);
  if (ask) {
    const task = raw.replace(new RegExp(`^.*?\\bask\\s+(?:my|the)\\s+${ask[1].replace(' ', '\\s+')}\\s+`, 'i'), '').trim();
    if (task) return { kind: 'mesh', req: { op: 'ask', device: ask[1], task }, wording: `Asking your ${ask[1]}.` };
  }
  const lock = said.match(LOCK_COMPUTER);
  if (lock) return { kind: 'mesh', req: { op: 'command', device: lock[1], action: 'lock_screen', args: {} }, wording: `Locking your ${lock[1]}.` };
  const on = said.match(ON_COMPUTER);
  if (!on) return null;
  const device = on[1];
  const link = linkIn(raw, said);
  if (link && /\b(?:send|share|push|forward|hand)\b/.test(said)) {
    return { kind: 'mesh', req: { op: 'handoff', to: device, kind: 'link', payload: { url: link } }, wording: `Sending the link to your ${device}.` };
  }
  if (link && /\b(?:open|show|put|load|go to)\b/.test(said)) {
    return { kind: 'mesh', req: { op: 'command', device, action: 'open_url', args: { url: link } }, wording: `Opening it on your ${device}.` };
  }
  const app = said.match(/\b(?:open|launch|start)\s+(?:the\s+)?([a-z][a-z0-9 ]{1,30}?)\s+(?:app\s+)?(?:on|in|onto)\s+(?:my|the)\b/);
  if (app && !/\b(?:link|page|site|website)\b/.test(app[1])) {
    return { kind: 'mesh', req: { op: 'command', device, action: 'open_app', args: { app: app[1].trim() } }, wording: `Opening ${app[1].trim()} on your ${device}.` };
  }
  const media = said.match(/\b(play|pause|resume|next|skip|previous|stop)\b/);
  if (media && /\b(?:music|song|track|media|video|playing|play|pause|resume|next|skip|previous)\b/.test(said)) {
    const op = ({ play: 'play', resume: 'play', pause: 'pause', next: 'next', skip: 'next', previous: 'previous', stop: 'stop' } as const)[media[1] as 'play'];
    return { kind: 'mesh', req: { op: 'command', device, action: 'media', args: { op } }, wording: `Okay, ${op} on your ${device}.` };
  }
  return null;
}

export function routeMesh(raw: string): MeshVoice | null {
  const said = plain(raw);
  if (!said) return null;
  if (!MY_PHONE.test(said)) return routeComputers(raw, said);

  if (/\bwhere(?:'s| is| has)\b.*\bmy\b/.test(said) || /\b(?:ring|find|buzz|locate)\b/.test(said)) {
    if (/\b(?:stop|quiet|silence|enough)\b/.test(said)) return { kind: 'phone', ask: { action: 'stop_ring', args: {} }, wording: 'Stopping the ringing on your phone.' };
    return { kind: 'phone', ask: { action: 'ring', args: { seconds: 20 } }, wording: 'Ringing your phone.' };
  }
  if (/\b(?:stop|silence)\b.*\b(?:ring|ringing)\b/.test(said)) return { kind: 'phone', ask: { action: 'stop_ring', args: {} }, wording: 'Stopping the ringing on your phone.' };
  if (/\b(?:battery|charge|charged|charging)\b/.test(said)) return { kind: 'phone', ask: { action: 'battery', args: {} }, wording: 'Asking your phone for its battery.' };
  const torch = said.match(/\b(?:turn|switch)\s+(on|off)\b.*\b(?:flashlight|torch)\b/) ?? said.match(/\b(?:flashlight|torch)\b.*\b(on|off)\b/);
  if (torch) return { kind: 'phone', ask: { action: 'torch', args: { on: torch[1] === 'on' } }, wording: `Turning the flashlight ${torch[1]} on your phone.` };

  const app = said.match(new RegExp(`\\b(?:open|launch|start)\\s+(?:the\\s+)?([a-z][a-z0-9 ]{1,30}?)\\s+(?:app\\s+)?(?:on|in|onto)\\s+(?:my|the)\\s+${PHONE}\\b`));
  if (app && !/\b(?:link|page|site|website)\b/.test(app[1])) {
    return { kind: 'phone', ask: { action: 'open_app', args: { app: app[1].trim() } }, wording: `Opening ${app[1].trim()} on your phone.` };
  }
  const link = linkIn(raw, said);
  if (link && /\b(?:open|show|put|go to|load)\b/.test(said) && !/\b(?:send|share|push|forward)\b/.test(said)) {
    return { kind: 'phone', ask: { action: 'open_link', args: { url: link } }, wording: 'Opening the link on your phone. If it does not open by itself, tap the notice there.' };
  }
  if (link && /\b(?:send|share|push|forward)\b/.test(said)) {
    return { kind: 'phone', ask: { action: 'receive_link', args: { url: link } }, wording: 'Sending the link to your phone. Tap the notice there to open it.' };
  }

  if (ON_PHONE.test(said) || /\b(?:play|pause|resume|next|skip|previous|stop)\b/.test(said)) {
    const media = said.match(/\b(play|pause|resume|next|skip|previous|stop)\b(?:\s+(?:the\s+)?(?:music|song|track|media|video|playing))?/);
    if (media && /\b(?:music|song|track|media|video|playing|play|pause|resume|next|skip|previous)\b/.test(said) && !/\b(?:open|launch|start)\b/.test(said)) {
      const op = ({ play: 'play', resume: 'play', pause: 'pause', next: 'next', skip: 'next', previous: 'previous', stop: 'stop' } as const)[media[1] as 'play'];
      return { kind: 'phone', ask: { action: 'media', args: { op } }, wording: `Okay, ${op} on your phone.` };
    }
  }

  if (ON_PHONE.test(said)) {
    return {
      kind: 'refuse',
      say: 'I can ring your phone, ask its battery, switch its flashlight, press its media buttons, send it a link, or open a link or an app on it. Calls and messages are done from the phone itself.',
    };
  }
  return null;
}
