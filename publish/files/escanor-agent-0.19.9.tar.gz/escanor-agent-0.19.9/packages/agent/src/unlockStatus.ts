import type { Runner } from './computerControl.js';
import { realRunner } from './computerControl.js';
import { atLoginScreen, findSession } from './screenControl.js';
import type { HelperSession, SessionHelperApi } from './sessionHelper.js';

/**
 * What the phone shows beside "Unlock / Turn on": can this computer be unlocked from the phone, and what state is it in. Words, not
 * codes. It reads only (the login manager, logind, the helper's status); it changes nothing.
 */

export type UnlockState = 'ready' | 'not_set_up' | 'needs_phone' | 'no_screen' | 'unsupported';
export type ScreenState = HelperSession;

export const HEADLINES: Record<UnlockState, string> = {
  ready: 'Ready (needs your fingerprint)',
  not_set_up: 'Not set up on this computer: update Escanor',
  needs_phone: 'Turn on fingerprint approvals on your phone first (Remote control, Turn on fingerprint approvals)',
  no_screen: 'No screen here. Keyring and sudo need your fingerprint.',
  unsupported: 'This computer cannot be unlocked remotely: its own sign-in is the only way in.',
};

export type UnlockStatus = {
  state: UnlockState;
  headline: string;
  screen: ScreenState;
  kind: string;
  /** The id a signed yes names for this computer (the phone signs it into a pre-approved sign-in). */
  machine: string;
  window: { until: number } | null;
  wakeRoutes: string[];
  /** The phones (key ids) that can sign in at the login screen, when this computer knows (it handed them to the helper itself). */
  phones?: string[];
};

export type UnlockDeps = {
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  run?: Runner;
  uid?: number | null;
  helper: Pick<SessionHelperApi, 'status'>;
  /** The machine kind the agent reported to the hub (laptop, desktop, server, vm, personal, device, unknown). */
  machineKind: string;
  machine: string;
  window: () => { until: number } | null;
  wakeRoutes: () => Promise<string[]>;
  /** Does anyone's phone approve things for this computer (paired here or on the account)? */
  hasPhone: () => Promise<boolean>;
};

/** Where the screen is now: signed out at the login screen, locked, open, or nothing to unlock. */
export async function screenState(d: Pick<UnlockDeps, 'platform' | 'env' | 'run' | 'uid'>): Promise<ScreenState> {
  const platform = d.platform ?? process.platform;
  if (platform !== 'linux') return 'unknown';
  const run = d.run ?? realRunner;
  const env = d.env ?? process.env;
  const uid = d.uid === undefined ? (typeof process.getuid === 'function' ? process.getuid() : null) : d.uid;
  const session = await findSession(run, env, uid).catch(() => null);
  if (!session) {
    const list = await run({ cmd: 'loginctl', args: ['list-sessions', '--no-legend'] }, env);
    if (list.code !== 0) return 'unknown';
    return atLoginScreen(list.stdout) ? 'login_screen' : 'none';
  }
  const hint = await run({ cmd: 'loginctl', args: ['show-session', session, '-p', 'LockedHint'] }, env);
  if (hint.code !== 0) return 'unknown';
  return /LockedHint=yes/.test(hint.stdout) ? 'locked' : 'unlocked';
}

export async function unlockStatus(d: UnlockDeps): Promise<UnlockStatus> {
  const platform = d.platform ?? process.platform;
  const base = { kind: d.machineKind, machine: d.machine, window: d.window(), wakeRoutes: [] as string[] };
  const out = (state: UnlockState, screen: ScreenState, wakeRoutes: string[] = base.wakeRoutes): UnlockStatus => ({ state, headline: HEADLINES[state], screen, kind: base.kind, machine: base.machine, window: base.window, wakeRoutes });
  if (platform === 'darwin' || platform === 'win32') return out('unsupported', 'unknown');
  const [helper, screen, wake] = await Promise.all([d.helper.status().catch(() => null), screenState(d).catch(() => 'unknown' as ScreenState), d.wakeRoutes().catch(() => [] as string[])]);
  if (!helper) {
    // Not installed. A server or VM has no screen to unlock anyway; keyring and sudo work there without it.
    return out(['server', 'vm', 'device'].includes(d.machineKind) && screen !== 'login_screen' && screen !== 'locked' ? 'no_screen' : 'not_set_up', screen, wake);
  }
  if (helper.dm === 'none' || helper.kind === 'server' || helper.kind === 'vm') return out('no_screen', screen, wake);
  if (helper.enrolled === 0 && !(await d.hasPhone().catch(() => false))) return out('needs_phone', helper.session === 'unknown' ? screen : helper.session, wake);
  return out('ready', helper.session === 'unknown' ? screen : helper.session, wake);
}
