import { chmodSync, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, statSync, watch, writeFileSync, type FSWatcher } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path';
import { escanorApiUrl } from './deviceMcp.js';
import { readMark, retryAfterMs } from './workspaceAccounts.js';
import { scanText } from './secretScan.js';
import { switchOn } from './switches.js';

/**
 * Claude set-up sync: skills, agents, CLAUDE.md, memory notes, the plugin list and a few everyday settings are kept once for the
 * workspace (POST /agent/device/claude-setup, signed in with the hub agent token like /agent/device/ai-accounts) and follow the person
 * to every machine. NOT sign-ins (see workspaceAccounts.ts), NOT plugin files, NOT anything of this machine's safety layer.
 *
 * What is shared (and nothing else):
 *   settings.json  only the keys in SHARED_SETTINGS_KEYS (hooks, permissions, sandbox, statusLine, apiKeyHelper, MCP servers stay here);
 *                  `env` without anything key-like or machine-specific; absolute paths under the home folder travel as ${HOME}
 *   plugins.json   enabledPlugins + extraKnownMarketplaces, taken out of settings.json
 *   CLAUDE.md, skills/**, agents/**, memory (projects/<folder>/memory/*.md, the folder name travels with the home part as `@home`)
 *   overrides/<this machine>/settings.json  from the local file `.escanor-settings-override.json`, merged over the shared settings here
 *
 * Every file is scanned for keys before it leaves this machine and refused if one is found. Files this agent writes are listed in
 * `.escanor-setup-manifest.json` (what it wrote, its checksum, the workspace version); a file the person changed since is a local
 * edit and goes UP instead of being overwritten. Files the workspace does not know are never deleted.
 */

export const MANIFEST_FILE = '.escanor-setup-manifest.json';
export const OVERRIDE_FILE = '.escanor-settings-override.json';
export const SYNC_MS = 30 * 60_000;
export const RETRY_MS = 60_000;
export const MAX_RETRY_MS = 15 * 60_000;
export const WATCH_DEBOUNCE_MS = 15_000;
/** A hub (re)connect asks for a visit only when the last good one is older than this (a flapping link used to run one per connect). */
export const CONNECT_GAP_MS = 10 * 60_000;
/** Watched files changing this soon after a visit are the visit's own writes (pulled files): no new visit for them. */
const SELF_WRITE_MS = 3_000;
export const MAX_FILE_BYTES = 200 * 1024;
const TIMEOUT_MS = 30_000;
const HOME_TOKEN = '${HOME}';

/** The settings keys that are shared. Everything else in settings.json stays on its machine. */
export const SHARED_SETTINGS_KEYS = ['model', 'theme', 'enabledPlugins', 'extraKnownMarketplaces', 'includeCoAuthoredBy', 'env', 'outputStyle', 'language', 'verbose', 'cleanupPeriodDays', 'alwaysThinkingEnabled', 'spinnerTipsEnabled', 'preferredNotifChannel', 'editorMode'] as const;
/** Moved to plugins.json. */
const PLUGIN_KEYS = ['enabledPlugins', 'extraKnownMarketplaces'] as const;
/** Settings keys whose objects are merged key by key (the machine keeps its own entries); every other shared key is replaced. */
const MERGED_KEYS = new Set<string>(['env', 'enabledPlugins', 'extraKnownMarketplaces']);
/** Never shared, whatever the setting says (kept as a list for the tests; the whitelist above already excludes them). */
export const NEVER_SHARED = ['hooks', 'permissions', 'sandbox', 'statusLine', 'apiKeyHelper', 'mcpServers', 'awsAuthRefresh', 'awsCredentialExport', 'otelHeadersHelper', 'forceLoginOrgUUID'];

const DENY_NAME = /(^\.?credentials|credentials\.json$|\.credentials|^\.env($|\.)|\.pem$|\.key$|\.p12$|\.pfx$|\.keystore$|^id_(rsa|dsa|ecdsa|ed25519)|^\.netrc$|^\.npmrc$|^\.pypirc$|(secrets?|tokens?)\.(json|ya?ml|toml|txt)$|\.sqlite3?$|\.db$)/i;
// .trash: Claude Code's own bin for removed skills (hundreds of fonts and schemas that are never shared and were reported every visit).
const SKIP_DIRS = new Set(['node_modules', '.git', '__pycache__', '.removed', '.trash']);
const ENV_SECRET_NAME = /(key|token|secret|passw|credential|auth|cookie|bearer|session|private)/i;

export function claudeSetupEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchOn(env.ESCANOR_CLAUDE_SETUP, true);
}

type Json = Record<string, unknown>;
const isObj = (v: unknown): v is Json => !!v && typeof v === 'object' && !Array.isArray(v);
const sha = (s: string): string => createHash('sha256').update(s, 'utf8').digest('hex');

// ---------------------------------------------------------------------------------------------------------------- paths and home

/** Claude Code's folder name for a working folder: every character that is not a letter or digit becomes '-'. */
export const encodeProject = (cwd: string): string => cwd.replace(/[^A-Za-z0-9]/g, '-');

/** A path this machine owns under its home folder becomes ${HOME}/...; the rest of the string is kept (backslashes become '/'). */
export function rewriteHome(value: string, home: string): string {
  const variants = [home, home.replace(/\\/g, '/')].filter((h, i, a) => h && a.indexOf(h) === i);
  for (const h of variants) {
    const base = h.replace(/[\\/]+$/, '');
    if (value === base) return HOME_TOKEN;
    if (value.startsWith(base + '/') || value.startsWith(base + '\\')) return HOME_TOKEN + value.slice(base.length).replace(/\\/g, '/');
  }
  return value;
}

export function expandHome(value: string, home: string): string {
  return value.includes(HOME_TOKEN) ? value.split(HOME_TOKEN).join(home.replace(/[\\/]+$/, '').replace(/\\/g, '/')) : value;
}

const isAbsPath = (v: string): boolean => v.startsWith('/') || /^[A-Za-z]:[\\/]/.test(v) || v.startsWith('\\\\');

function mapStrings(v: unknown, f: (s: string) => string): unknown {
  if (typeof v === 'string') return f(v);
  if (Array.isArray(v)) return v.map((x) => mapStrings(x, f));
  if (isObj(v)) return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, mapStrings(x, f)]));
  return v;
}

/** Any string left that is an absolute path of this machine (not under home). */
function hasForeignPath(v: unknown): boolean {
  if (typeof v === 'string') return isAbsPath(v);
  if (Array.isArray(v)) return v.some(hasForeignPath);
  if (isObj(v)) return Object.values(v).some(hasForeignPath);
  return false;
}

export function deepMerge(base: unknown, over: unknown): unknown {
  if (!isObj(base) || !isObj(over)) return over === undefined ? base : over;
  const out: Json = { ...base };
  for (const [k, v] of Object.entries(over)) out[k] = k in base ? deepMerge(base[k], v) : v;
  return out;
}

const canonical = (v: unknown): unknown => (Array.isArray(v) ? v.map(canonical) : isObj(v) ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, canonical(v[k])])) : v);
const stringify = (v: unknown): string => JSON.stringify(canonical(v), null, 2) + '\n';

// ---------------------------------------------------------------------------------------------------------------- collector

export type Collected = {
  /** remote path -> text */
  files: Map<string, string>;
  /** remote path -> path inside the profile folder (forward slashes) */
  local: Map<string, string>;
  refused: Array<{ path: string; reason: string }>;
};

function readText(file: string): string | null {
  try {
    const st = lstatSync(file);
    if (!st.isFile() || st.size > MAX_FILE_BYTES) return st.isFile() ? '\u0000too-large' : null;
    const t = readFileSync(file, 'utf8');
    return t.includes('\u0000') ? '\u0000binary' : t;
  } catch {
    return null;
  }
}

function walk(root: string, rel = ''): string[] {
  const out: string[] = [];
  let names: string[] = [];
  try {
    names = readdirSync(join(root, rel));
  } catch {
    return out;
  }
  for (const name of names.sort()) {
    const r = rel ? `${rel}/${name}` : name;
    let st;
    try {
      st = lstatSync(join(root, r));
    } catch {
      continue;
    }
    if (st.isSymbolicLink()) continue;
    if (st.isDirectory()) {
      if (!SKIP_DIRS.has(name)) out.push(...walk(root, r));
    } else if (st.isFile()) out.push(r);
  }
  return out;
}

/** The set-up's shared view of a settings.json (`{settings, plugins}` objects), already free of machine-specific parts. */
export function sharedViewOfSettings(raw: Json, home: string): { settings: Json; plugins: Json; dropped: string[] } {
  const dropped: string[] = [];
  const settings: Json = {};
  const plugins: Json = {};
  for (const key of SHARED_SETTINGS_KEYS) {
    if (!(key in raw)) continue;
    let value = mapStrings(raw[key], (s) => rewriteHome(s, home));
    if (key === 'env' && isObj(value)) {
      const env: Json = {};
      for (const [name, v] of Object.entries(value)) {
        const text = typeof v === 'string' ? v : String(v);
        if ((ENV_SECRET_NAME.test(name) && !/_TOKENS$/i.test(name)) || scanText(`${name}=${text}`, '', { includeSoft: true }).length || hasForeignPath(v)) {
          dropped.push(`env.${name}`);
          continue;
        }
        env[name] = v;
      }
      value = env;
    } else if (key === 'extraKnownMarketplaces' && isObj(value)) {
      // a marketplace that lives in a folder only this machine has is left out
      const kept: Json = {};
      for (const [name, v] of Object.entries(value)) {
        if (hasForeignPath(v)) dropped.push(`extraKnownMarketplaces.${name}`);
        else kept[name] = v;
      }
      value = kept;
    } else if (hasForeignPath(value)) {
      dropped.push(key);
      continue;
    }
    (PLUGIN_KEYS as readonly string[]).includes(key) ? (plugins[key] = value) : (settings[key] = value);
  }
  return { settings, plugins, dropped };
}

/** Everything of this profile folder that belongs in the shared set-up. A file with a key in it, or named like a credential, is left out and listed in `refused`. */
export function collect(profileDir: string, o: { home?: string; machine?: string } = {}): Collected {
  const home = o.home ?? homedir();
  const out: Collected = { files: new Map(), local: new Map(), refused: [] };
  const add = (remote: string, localRel: string, text: string | null, scan = true): void => {
    if (text === null) return;
    const name = remote.split('/').pop() ?? '';
    if (text.startsWith('\u0000')) {
      out.refused.push({ path: remote, reason: text === '\u0000too-large' ? 'larger than 200 KB' : 'not a text file' });
      return;
    }
    if (DENY_NAME.test(name) || remote.split('/').some((p) => DENY_NAME.test(p))) {
      out.refused.push({ path: remote, reason: 'named like a sign-in or a key' });
      return;
    }
    if (scan) {
      const found = scanText(text, '', { includeSoft: true })[0];
      if (found) {
        out.refused.push({ path: remote, reason: `holds a ${found.label}` });
        return;
      }
    }
    out.files.set(remote, text);
    out.local.set(remote, localRel);
  };

  const settingsText = readText(join(profileDir, 'settings.json'));
  if (settingsText !== null && !settingsText.startsWith('\u0000')) {
    try {
      const parsed = JSON.parse(settingsText) as unknown;
      if (isObj(parsed)) {
        const v = sharedViewOfSettings(parsed, home);
        if (Object.keys(v.settings).length) add('settings.json', 'settings.json', stringify(v.settings));
        if (Object.keys(v.plugins).length) add('plugins.json', 'settings.json', stringify(v.plugins));
      }
    } catch {
      out.refused.push({ path: 'settings.json', reason: 'not valid JSON' });
    }
  }
  add('CLAUDE.md', 'CLAUDE.md', readText(join(profileDir, 'CLAUDE.md')));
  for (const root of ['skills', 'agents']) {
    for (const rel of walk(join(profileDir, root))) add(`${root}/${rel}`, `${root}/${rel}`, readText(join(profileDir, root, rel)));
  }
  const projects = join(profileDir, 'projects');
  const encHome = encodeProject(home);
  if (existsSync(projects)) {
    for (const folder of readdirSync(projects).sort()) {
      const mem = join(projects, folder, 'memory');
      let files: string[] = [];
      try {
        files = readdirSync(mem).filter((n) => n.toLowerCase().endsWith('.md') && lstatSync(join(mem, n)).isFile()).sort();
      } catch {
        continue;
      }
      const key = folder === encHome ? '@home' : folder.startsWith(encHome + '-') ? '@home' + folder.slice(encHome.length) : folder;
      for (const n of files) add(`memory/${key}/${n}`, `projects/${folder}/memory/${n}`, readText(join(mem, n)));
    }
  }
  if (o.machine) add(`overrides/${deviceSlug(o.machine)}/settings.json`, OVERRIDE_FILE, readText(join(profileDir, OVERRIDE_FILE)));
  return out;
}

/** The backend's name for a machine in a path (claude_setup/store.py device_slug). */
export function deviceSlug(name: string): string {
  const s = name.replace(/[\u0000-\u001f\u007f]+/g, ' ').split(/\s+/).filter(Boolean).join(' ').slice(0, 60).replace(/[^A-Za-z0-9_.-]+/g, '_').replace(/^[._-]+|[._-]+$/g, '');
  return s || 'machine';
}

/** Where a workspace path lives in this profile folder, or null when it does not map to a safe place here. */
export function localPathFor(remote: string, machine: string, home: string): string | null {
  const parts = remote.split('/');
  if (parts.some((p) => !p || p === '.' || p === '..' || /[\\:]/.test(p))) return null;
  if (remote === 'CLAUDE.md') return 'CLAUDE.md';
  if (remote === 'settings.json' || remote === 'plugins.json') return 'settings.json';
  if ((parts[0] === 'skills' || parts[0] === 'agents') && parts.length >= 2) return remote;
  if (parts[0] === 'memory' && parts.length === 3) {
    const key = parts[1];
    const folder = key === '@home' ? encodeProject(home) : key.startsWith('@home-') ? encodeProject(home) + key.slice(5) : key;
    return `projects/${folder}/memory/${parts[2]}`;
  }
  if (remote === `overrides/${deviceSlug(machine)}/settings.json`) return OVERRIDE_FILE;
  return null;
}

// ---------------------------------------------------------------------------------------------------------------- manifest + files

export type ManifestEntry = { sha: string; version: number };
export type Manifest = { v: 1; files: Record<string, ManifestEntry>; lastSync?: string };

export function readManifest(dir: string): Manifest {
  try {
    const j = JSON.parse(readFileSync(join(dir, MANIFEST_FILE), 'utf8')) as unknown;
    if (isObj(j) && isObj(j.files)) {
      const files: Record<string, ManifestEntry> = {};
      for (const [k, v] of Object.entries(j.files)) if (isObj(v) && typeof v.sha === 'string' && typeof v.version === 'number') files[k] = { sha: v.sha, version: v.version };
      return { v: 1, files, ...(typeof j.lastSync === 'string' ? { lastSync: j.lastSync } : {}) };
    }
  } catch {
    // none yet
  }
  return { v: 1, files: {} };
}

function writeAtomic(file: string, text: string, mode = 0o644): void {
  mkdirSync(dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, text, { mode });
  renameSync(tmp, file);
  try {
    chmodSync(file, mode);
  } catch {
    // not supported on this file system (Windows)
  }
}

/** A path inside the profile folder that is not a link and does not leave it. */
function safeTarget(profileDir: string, rel: string): string | null {
  const root = resolve(profileDir);
  const target = resolve(root, ...rel.split('/'));
  const back = relative(root, target);
  if (!back || back.startsWith('..') || isAbsolute(back)) return null;
  let cur = root;
  for (const part of back.split(sep)) {
    cur = join(cur, part);
    try {
      if (lstatSync(cur).isSymbolicLink()) return null;
    } catch {
      break;
    }
  }
  return target;
}

// ---------------------------------------------------------------------------------------------------------------- the workspace side

export type RemoteFile = { path: string; version: number; sha256: string; deleted?: boolean };
export type PutResult = { saved: RemoteFile[]; conflicts: Array<{ path: string; version: number }>; rejected: Array<{ path: string; reason: string }> };
export type Remote = {
  list(): Promise<RemoteFile[]>;
  get(paths: string[]): Promise<Array<RemoteFile & { content: string }>>;
  put(files: Array<{ path: string; content: string; base_version: number | null }>, force: boolean): Promise<PutResult>;
  del(paths: string[], baseVersions: Record<string, number>, force: boolean): Promise<{ deleted: string[]; conflicts: Array<{ path: string; version: number }> }>;
};

export class SetupUnavailable extends Error {
  constructor(readonly status: number, readonly retryAfterMs?: number) {
    super(`HTTP ${status}`);
  }
}

/**
 * The workspace's file list read once per visit, not once per account folder (every folder syncs the same workspace set): read again
 * only after a folder changed something there.
 */
export function listOncePerVisit(r: Remote): Remote {
  let cached: Promise<RemoteFile[]> | null = null;
  return {
    list: () => (cached ??= r.list().catch((err: unknown) => { cached = null; throw err; })),
    get: (paths) => r.get(paths),
    put: async (files, force) => {
      cached = null;
      return r.put(files, force);
    },
    del: async (paths, base, force) => {
      cached = null;
      return r.del(paths, base, force);
    },
  };
}

export type Conn = { apiUrl: string; hubToken: () => string; vmName: string; agentVersion: string; fetchImpl?: typeof fetch };

export function httpRemote(c: Conn): Remote {
  const call = async (body: Json): Promise<Json> => {
    const res = await (c.fetchImpl ?? fetch)(`${c.apiUrl}/agent/device/claude-setup`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${c.hubToken()}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${c.agentVersion}` },
      body: JSON.stringify({ vm_name: c.vmName, agent_version: c.agentVersion, ...body }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    let j: unknown = null;
    try {
      j = await res.json();
    } catch {
      j = null;
    }
    if (res.status === 200 && isObj(j) && j.ok === true) return j;
    throw new SetupUnavailable(res.status, retryAfterMs((res as { headers?: { get?: (k: string) => string | null } }).headers?.get?.('retry-after')));
  };
  const arr = <T>(v: unknown): T[] => (Array.isArray(v) ? (v.filter(isObj) as unknown as T[]) : []);
  return {
    list: async () => arr<RemoteFile>((await call({ op: 'list' })).files),
    get: async (paths) => {
      const out: Array<RemoteFile & { content: string }> = [];
      for (let i = 0; i < paths.length; i += 100) out.push(...arr<RemoteFile & { content: string }>((await call({ op: 'get', paths: paths.slice(i, i + 100) })).files));
      return out;
    },
    put: async (files, force) => {
      const r: PutResult = { saved: [], conflicts: [], rejected: [] };
      for (let i = 0; i < files.length; i += 50) {
        const j = await call({ op: 'put', files: files.slice(i, i + 50), ...(force ? { force: true } : {}) });
        r.saved.push(...arr<RemoteFile>(j.saved));
        r.conflicts.push(...arr<{ path: string; version: number }>(j.conflicts));
        r.rejected.push(...arr<{ path: string; reason: string }>(j.rejected));
      }
      return r;
    },
    del: async (paths, baseVersions, force) => {
      const j = await call({ op: 'delete', paths, base_versions: baseVersions, ...(force ? { force: true } : {}) });
      return { deleted: arr<never>(j.deleted) as unknown as string[], conflicts: arr<{ path: string; version: number }>(j.conflicts) };
    },
  };
}

// ---------------------------------------------------------------------------------------------------------------- one profile folder, one visit

export type Mode = 'sync' | 'push' | 'pull';
export type SetupResult = {
  pulled: string[];
  pushed: string[];
  removed: string[];
  conflicts: string[];
  refused: Array<{ path: string; reason: string }>;
};

/**
 * One visit for one profile folder. `push`: only local changes go up. `pull`: only the workspace's changes are written here.
 * `force`: a conflict is settled for this side (push: this machine wins; pull: the workspace wins).
 */
export async function syncProfile(profileDir: string, remote: Remote, o: { machine: string; home?: string; mode?: Mode; force?: boolean; now?: () => Date }): Promise<SetupResult> {
  const home = o.home ?? homedir();
  const mode = o.mode ?? 'sync';
  const res: SetupResult = { pulled: [], pushed: [], removed: [], conflicts: [], refused: [] };
  const mine = collect(profileDir, { home, machine: o.machine });
  res.refused.push(...mine.refused);
  const manifest = readManifest(profileDir);
  const rows = new Map((await remote.list()).map((r) => [r.path, r]));
  const wsPaths = new Set<string>([...rows.keys(), ...Object.keys(manifest.files), ...mine.files.keys()]);

  const toGet: string[] = [];
  const toPut: Array<{ path: string; content: string; base_version: number | null }> = [];
  const toDelete: Record<string, number> = {};
  const adopt: Record<string, ManifestEntry> = {};
  const drop = new Set<string>();
  const localRemovals: string[] = [];
  const settingsPaths = new Set(['settings.json', 'plugins.json']);

  for (const path of [...wsPaths].sort()) {
    if (localPathFor(path, o.machine, home) === null && !mine.files.has(path)) continue;
    const r = rows.get(path);
    const live = !!r && !r.deleted;
    const m = manifest.files[path];
    const local = mine.files.get(path);
    const lsha = local === undefined ? null : sha(local);
    const wantsPush = mode !== 'pull';
    const wantsPull = mode !== 'push';
    if (lsha === null) {
      if (!m) {
        if (live && wantsPull) toGet.push(path);
      } else if (!r || r.deleted) {
        drop.add(path); // gone on both sides
      } else if (r.version === m.version) {
        if (wantsPush && !settingsPaths.has(path)) toDelete[path] = m.version; // removed here, unchanged in the workspace
        else if (wantsPull) toGet.push(path);
      } else if (wantsPull) toGet.push(path); // changed in the workspace while it was removed here: the workspace's copy comes back
      continue;
    }
    if (!m) {
      if (live && r.sha256 === lsha) adopt[path] = { sha: lsha, version: r.version };
      else if (live && settingsPaths.has(path) && wantsPull && !o.force) toGet.push(path); // settings.json already holds this machine's own choices: the shared keys are merged in, nothing else is touched
      else if (live) {
        if (o.force && wantsPush) toPut.push({ path, content: local as string, base_version: r.version });
        else if (o.force && wantsPull) toGet.push(path);
        else res.conflicts.push(path); // a file of the same name already here that this agent never wrote: kept as it is
      } else if (wantsPush) toPut.push({ path, content: local as string, base_version: r ? r.version : null });
      continue;
    }
    const localChanged = lsha !== m.sha;
    const remoteChanged = !r || r.deleted || r.version !== m.version;
    if (!localChanged && !remoteChanged) continue;
    if (!localChanged) {
      if (!wantsPull) continue;
      if (live) toGet.push(path);
      else if (r?.deleted) localRemovals.push(path);
      continue;
    }
    if (!remoteChanged) {
      if (wantsPush) toPut.push({ path, content: local as string, base_version: m.version });
      continue;
    }
    if (live && r.sha256 === lsha) adopt[path] = { sha: lsha, version: r.version };
    else if (o.force && wantsPush) toPut.push({ path, content: local as string, base_version: r ? r.version : null });
    else if (o.force && wantsPull && live) toGet.push(path);
    else res.conflicts.push(path);
  }

  // --- the settings pieces are written together (a change in the plugin list, the override or either file rebuilds the merge)
  const overrideTouched = toPut.some((x) => x.path.startsWith('overrides/'));
  const settingsWrites = overrideTouched || toGet.some((p) => settingsPaths.has(p) || p.startsWith('overrides/'));
  if (settingsWrites) for (const p of settingsPaths) if (rows.get(p) && !rows.get(p)!.deleted && !toGet.includes(p) && !res.conflicts.includes(p) && !toPut.some((x) => x.path === p)) toGet.push(p);

  const got = new Map<string, string>();
  const gotRows = new Map<string, RemoteFile>();
  if (toGet.length) {
    for (const f of await remote.get(toGet)) {
      got.set(f.path, f.content);
      gotRows.set(f.path, f);
    }
  }

  const written: Record<string, ManifestEntry> = {};
  const deferred: string[] = [];
  for (const path of toGet) {
    const f = gotRows.get(path);
    const text = got.get(path);
    if (!f || text === undefined) continue;
    const rel = localPathFor(path, o.machine, home);
    if (!rel) continue;
    if (settingsPaths.has(path)) {
      deferred.push(path);
      continue;
    }
    const target = safeTarget(profileDir, rel);
    if (!target) continue;
    writeAtomic(target, text);
    written[path] = { sha: sha(text), version: f.version };
    res.pulled.push(path);
  }
  for (const path of localRemovals) {
    const rel = localPathFor(path, o.machine, home);
    const target = rel ? safeTarget(profileDir, rel) : null;
    if (target && !settingsPaths.has(path)) {
      rmSync(target, { force: true });
      res.removed.push(path);
    }
    drop.add(path);
  }

  if (deferred.length || settingsWrites) {
    const text = (p: string): string | undefined => got.get(p);
    const sharedSettings = text('settings.json') ?? undefined;
    const sharedPlugins = text('plugins.json') ?? undefined;
    const overrideText = readText(join(profileDir, OVERRIDE_FILE));
    applySettings(profileDir, home, { settings: sharedSettings, plugins: sharedPlugins, override: overrideText && !overrideText.startsWith('\u0000') ? overrideText : undefined });
    for (const p of deferred) {
      const f = gotRows.get(p);
      if (f) res.pulled.push(p);
    }
  }

  // --- push (a settings edit made on a machine with an override keeps the workspace's value for the overridden keys)
  const ov = mine.files.get(`overrides/${deviceSlug(o.machine)}/settings.json`);
  if (ov) {
    for (const item of toPut) {
      if (!settingsPaths.has(item.path)) continue;
      const row = rows.get(item.path);
      const current = row && !row.deleted ? (await remote.get([item.path]))[0]?.content : undefined;
      item.content = keepOverridden(item.content, ov, current);
    }
  }
  // --- push
  const pushedOk = new Set<string>();
  if (toPut.length) {
    const r = await remote.put(toPut, !!o.force);
    for (const s of r.saved) {
      pushedOk.add(s.path);
      res.pushed.push(s.path);
      adopt[s.path] = { sha: '', version: s.version }; // sha filled in below from the local view
    }
    for (const c of r.conflicts) res.conflicts.push(c.path);
    for (const x of r.rejected) res.refused.push({ path: x.path, reason: x.reason });
  }
  const deletedOk: string[] = [];
  if (Object.keys(toDelete).length) {
    const r = await remote.del(Object.keys(toDelete), toDelete, !!o.force);
    deletedOk.push(...r.deleted);
    for (const c of r.conflicts) res.conflicts.push(c.path);
  }
  for (const p of deletedOk) drop.add(p);

  // --- manifest: re-read what is here now so the record matches the files exactly
  const after = collect(profileDir, { home, machine: o.machine });
  const next: Manifest = { v: 1, files: { ...manifest.files }, lastSync: (o.now?.() ?? new Date()).toISOString() };
  for (const p of drop) delete next.files[p];
  const settle = (path: string, version: number): void => {
    const t = after.files.get(path);
    if (t !== undefined) next.files[path] = { sha: sha(t), version };
  };
  for (const [p, e] of Object.entries(adopt)) settle(p, e.version);
  for (const [p, e] of Object.entries(written)) settle(p, e.version);
  for (const p of deferred) {
    const f = gotRows.get(p);
    if (f) settle(p, f.version);
  }
  writeAtomic(join(profileDir, MANIFEST_FILE), JSON.stringify(next, null, 2), 0o600);
  res.conflicts = [...new Set(res.conflicts)];
  return res;
}

/** What goes up for a local edit of the settings: the keys this machine's override sets keep the workspace's value (the override is this machine's only). */
export function keepOverridden(local: string, override: string, workspaceText: string | undefined): string {
  try {
    const o = JSON.parse(override) as unknown;
    const l = JSON.parse(local) as unknown;
    const w = workspaceText ? (JSON.parse(workspaceText) as unknown) : {};
    if (!isObj(o) || !isObj(l)) return local;
    const keep = (obj: Json, over: Json, base: Json): Json => {
      const out: Json = { ...obj };
      for (const [k, v] of Object.entries(over)) {
        if (isObj(v) && isObj(out[k])) out[k] = keep(out[k] as Json, v, isObj(base[k]) ? (base[k] as Json) : {});
        else if (k in base) out[k] = base[k];
        else delete out[k];
      }
      return out;
    };
    return stringify(keep(l, o, isObj(w) ? w : {}));
  } catch {
    return local;
  }
}

/** Writes the shared settings (merged with this machine's override) into settings.json: only the shared keys, the rest of the file as it was. */
export function applySettings(profileDir: string, home: string, parts: { settings?: string; plugins?: string; override?: string }): void {
  const parse = (t: string | undefined): Json => {
    if (!t) return {};
    try {
      const j = JSON.parse(t) as unknown;
      return isObj(j) ? j : {};
    } catch {
      return {};
    }
  };
  const target = safeTarget(profileDir, 'settings.json');
  if (!target) return;
  let local: Json = {};
  if (existsSync(target)) {
    try {
      const j = JSON.parse(readFileSync(target, 'utf8')) as unknown;
      if (!isObj(j)) return; // not something this agent understands: never touched
      local = j;
    } catch {
      return;
    }
  }
  const shared = deepMerge(deepMerge(parse(parts.settings), parse(parts.plugins)), parse(parts.override)) as Json;
  const allowed = new Set<string>(SHARED_SETTINGS_KEYS);
  for (const [key, raw] of Object.entries(shared)) {
    if (!allowed.has(key)) continue;
    const value = mapStrings(raw, (s) => expandHome(s, home));
    local[key] = MERGED_KEYS.has(key) && isObj(value) && isObj(local[key]) ? { ...(local[key] as Json), ...value } : value;
  }
  writeAtomic(target, JSON.stringify(local, null, 2) + '\n');
}

// ---------------------------------------------------------------------------------------------------------------- the running agent

export type Opts = {
  conn: Conn;
  profilesDir: string;
  /** Profile ids (folder names under profilesDir) or absolute folders that are synced even without a workspace mark. */
  extra?: string[];
  home?: string;
  fetchImpl?: typeof fetch;
  log?: (line: string) => void;
  setTimer?: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  debounceMs?: number;
  watchFiles?: boolean;
};

/** ESCANOR_CLAUDE_SETUP_PROFILES: comma-separated profile ids or folders. */
export function extraProfiles(env: NodeJS.ProcessEnv = process.env): string[] {
  return (env.ESCANOR_CLAUDE_SETUP_PROFILES ?? '').split(',').map((s) => s.trim()).filter(Boolean);
}

export function claudeSetupApiUrl(env: NodeJS.ProcessEnv, hubUrl: string, opts: { managed: boolean }): string | null {
  if (opts.managed || !claudeSetupEnabled(env)) return null;
  return escanorApiUrl(env, hubUrl);
}

export class ClaudeSetupSync {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private debounce: ReturnType<typeof setTimeout> | null = null;
  private inFlight: Promise<void> | null = null;
  private watchers = new Map<string, FSWatcher>();
  private failures = 0;
  private stopped = false;
  /** The last line said per topic (one per folder for refusals and conflicts): a line is said again only when what it says changed. */
  private lastSay = new Map<string, string>();
  private lastOkAt = 0;
  private visitEndedAt = 0;
  readonly last = new Map<string, SetupResult>();

  constructor(private readonly o: Opts) {}

  private say(key: string, line: string, topic = 'status'): void {
    if (this.lastSay.get(topic) === key) return;
    this.lastSay.set(topic, key);
    (this.o.log ?? console.log)(line);
  }

  /** The hub (re)connected: a visit only when the last good one is older than CONNECT_GAP_MS and no retry is already waiting. */
  syncOnConnect(): Promise<void> {
    if (this.lastOkAt && Date.now() - this.lastOkAt < CONNECT_GAP_MS) return Promise.resolve();
    if (this.failures > 0 && this.timer) return Promise.resolve();
    return this.syncNow();
  }

  /** The folders that are synced: workspace-marked account folders, plus the ones the person listed. */
  folders(): string[] {
    const out = new Set<string>();
    if (existsSync(this.o.profilesDir)) {
      for (const name of readdirSync(this.o.profilesDir)) {
        if (name.startsWith('.')) continue;
        const dir = join(this.o.profilesDir, name);
        try {
          if (statSync(dir).isDirectory() && readMark(dir)) out.add(dir);
        } catch {
          // gone
        }
      }
    }
    for (const e of this.o.extra ?? []) {
      const dir = isAbsolute(e) ? e : join(this.o.profilesDir, e);
      if (existsSync(dir)) out.add(dir);
    }
    return [...out].sort();
  }

  start(): void {
    this.stopped = false;
    void this.syncNow();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    if (this.debounce) clearTimeout(this.debounce);
    this.timer = this.debounce = null;
    for (const w of this.watchers.values()) w.close();
    this.watchers.clear();
  }

  private schedule(ms: number): void {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    const t = (this.o.setTimer ?? setTimeout)(() => void this.syncNow(), ms);
    (t as { unref?: () => void }).unref?.();
    this.timer = t;
  }

  /** One visit now (the hub connected, a timer, or a watched file changed). A visit already running is waited for, not doubled. */
  syncNow(): Promise<void> {
    if (this.stopped) return Promise.resolve();
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.run().finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  private async run(): Promise<void> {
    let pulled = false;
    const remote = listOncePerVisit(httpRemote({ ...this.o.conn, fetchImpl: this.o.fetchImpl ?? this.o.conn.fetchImpl }));
    try {
      for (const dir of this.folders()) {
        const r = await syncProfile(dir, remote, { machine: this.o.conn.vmName, ...(this.o.home ? { home: this.o.home } : {}) });
        this.last.set(dir, r);
        if (r.pulled.length || r.removed.length) pulled = true;
        if (r.conflicts.length) this.say(`conflict:${dir}:${r.conflicts.join(',')}`, `Claude set-up: ${r.conflicts.length} file(s) differ between this computer and the workspace (${r.conflicts.slice(0, 3).join(', ')}); kept as they are here.`, `conflict:${dir}`);
        if (r.refused.length) this.say(`refused:${dir}:${r.refused.map((x) => x.path).join(',')}`, `Claude set-up: ${r.refused.length} file(s) not shared (${r.refused.slice(0, 3).map((x) => `${x.path}: ${x.reason}`).join('; ')}).`, `refused:${dir}`);
      }
      this.failures = 0;
      this.lastOkAt = Date.now();
      this.armWatchers();
      this.schedule(SYNC_MS);
    } catch (err) {
      if (err instanceof SetupUnavailable && [404, 401, 409].includes(err.status)) {
        this.schedule(SYNC_MS * 3);
        return;
      }
      this.failures += 1;
      const why = err instanceof Error ? err.message || err.name : 'network';
      this.say(`retry:${why}`, `Claude set-up: could not reach Escanor (${why}); keeping what this computer has and trying again.`);
      // A 429 says how long to wait (Retry-After): never sooner than that.
      const after = err instanceof SetupUnavailable ? err.retryAfterMs ?? 0 : 0;
      this.schedule(Math.max(after, Math.min(MAX_RETRY_MS, RETRY_MS * 2 ** Math.min(this.failures - 1, 6))));
    } finally {
      if (pulled) this.visitEndedAt = Date.now();
    }
  }

  private changed(): void {
    if (this.stopped) return;
    // The visit's own writes (it just wrote pulled files) are not a change to send back: no second visit for them.
    if (this.inFlight || Date.now() - this.visitEndedAt < SELF_WRITE_MS) return;
    // While waiting out a failure (a 429), a changed file does not ask again early: the scheduled retry takes it.
    if (this.failures > 0) return;
    if (this.debounce) clearTimeout(this.debounce);
    this.debounce = setTimeout(() => void this.syncNow(), this.o.debounceMs ?? WATCH_DEBOUNCE_MS);
    this.debounce.unref?.();
  }

  /** Watches the few places that matter (not the whole folder: chat transcripts are written there all the time). */
  private armWatchers(): void {
    if (this.o.watchFiles === false) return;
    const want = new Map<string, boolean>();
    for (const dir of this.folders()) {
      want.set(dir, false);
      for (const sub of ['skills', 'agents']) if (existsSync(join(dir, sub))) want.set(join(dir, sub), true);
      const projects = join(dir, 'projects');
      try {
        for (const f of readdirSync(projects)) if (existsSync(join(projects, f, 'memory'))) want.set(join(projects, f, 'memory'), false);
      } catch {
        // no projects yet
      }
    }
    for (const [p, w] of [...this.watchers]) {
      if (!want.has(p)) {
        w.close();
        this.watchers.delete(p);
      }
    }
    for (const [p, recursive] of want) {
      if (this.watchers.has(p)) continue;
      try {
        const isProfile = !recursive && !p.endsWith(`${sep}memory`);
        const w = watch(p, { recursive }, (_ev, name) => {
          const n = String(name ?? '');
          if (isProfile && !['settings.json', 'CLAUDE.md', OVERRIDE_FILE].includes(n)) return;
          if (n.split(/[\\/]/).includes('.trash')) return; // Claude Code emptying its own bin
          this.changed();
        });
        w.on('error', () => {
          w.close();
          this.watchers.delete(p);
        });
        this.watchers.set(p, w);
      } catch {
        // watching is a convenience: the timer still visits
      }
    }
  }
}

/** `escanor-agent claude-setup push|pull <profileDir>`: one visit for one folder, now. */
export async function runCommand(conn: Conn, dir: string, mode: Mode, o: { force?: boolean; home?: string } = {}): Promise<SetupResult> {
  if (!existsSync(dir) || !statSync(dir).isDirectory()) throw new Error(`${dir} is not a folder`);
  return syncProfile(resolve(dir), httpRemote(conn), { machine: conn.vmName, mode, ...(o.force ? { force: true } : {}), ...(o.home ? { home: o.home } : {}) });
}
