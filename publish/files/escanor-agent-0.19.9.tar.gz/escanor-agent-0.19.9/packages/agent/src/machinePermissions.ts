import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

/**
 * This computer's permissions, set from any device (AGENT-INDEP, 16 Nov 2026). The source of truth is Escanor's backend, one record per
 * computer; the phone, the website and the desktop app all change that record. This agent asks for it over the hub agent token it already
 * has (POST /agent/device/permissions), every 20 seconds and at once when the hub says it changed, applies it, keeps the last answer in a
 * file (so a computer that is offline or has just restarted still follows the last choice), and reports back which version it applied and
 * what it now does.
 *
 * Nothing here needs the Desktop app. A computer that asks for the first time is given the default set by the backend: running the
 * install command was the consent, so no chat or feature waits for anyone to allow anything.
 *
 * The set is only what this agent really enforces (see machinePermissionsApply in index.ts): remote control, computer control (chats may
 * open pages and apps), devices (chats may use the owner's other devices) and how a new chat starts. null = this computer's own choice.
 */

export const PERMISSION_MODES = ['default', 'acceptEdits', 'auto', 'bypassPermissions'] as const;
export type PermissionModeName = (typeof PERMISSION_MODES)[number];

export interface PermissionSet {
  remote_control: boolean | null;
  computer_control: boolean | null;
  devices: boolean | null;
  default_mode: PermissionModeName | null;
}

export type Effective = Partial<PermissionSet>;

export const POLL_MS = 20_000;
export const RETRY_MAX_MS = 5 * 60_000;
const TIMEOUT_MS = 15_000;

/** A clean set from whatever the backend sent: unknown keys dropped, anything invalid is "this computer's own choice". */
export function cleanSet(raw: unknown): PermissionSet {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const b = (v: unknown): boolean | null => (typeof v === 'boolean' ? v : null);
  const mode = typeof r.default_mode === 'string' && (PERMISSION_MODES as readonly string[]).includes(r.default_mode) ? (r.default_mode as PermissionModeName) : null;
  return { remote_control: b(r.remote_control), computer_control: b(r.computer_control), devices: b(r.devices), default_mode: mode };
}

export type PermissionAnswer = { version: number; permissions: PermissionSet; pollMs: number };

export type PullResult = { kind: 'ok'; answer: PermissionAnswer } | { kind: 'gone'; reason: string } | { kind: 'retry'; reason: string };

/** One request. Never throws. 401/403/404 mean this computer is not asked for permissions at all (not a hosted-hub machine, or unpaired). */
export async function pullPermissions(o: {
  apiUrl: string;
  hubToken: string;
  vmName: string;
  agentVersion: string;
  appliedVersion?: number;
  effective?: Effective;
  fetchImpl?: typeof fetch;
}): Promise<PullResult> {
  const doFetch = o.fetchImpl ?? fetch;
  let res: Response;
  try {
    res = await doFetch(`${o.apiUrl}/agent/device/permissions`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${o.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${o.agentVersion}` },
      body: JSON.stringify({ vm_name: o.vmName, ...(o.appliedVersion !== undefined ? { applied_version: o.appliedVersion } : {}), ...(o.effective ? { effective: o.effective } : {}) }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (err) {
    return { kind: 'retry', reason: err instanceof Error ? err.name : 'network' };
  }
  if (res.status === 401 || res.status === 403 || res.status === 404) return { kind: 'gone', reason: `HTTP ${res.status}` };
  if (!res.ok) return { kind: 'retry', reason: `HTTP ${res.status}` };
  let body: unknown;
  try {
    body = await res.json();
  } catch {
    return { kind: 'retry', reason: 'malformed answer' };
  }
  const b = body as Record<string, unknown> | null;
  if (!b || typeof b !== 'object' || typeof b.version !== 'number' || !Number.isFinite(b.version)) return { kind: 'retry', reason: 'malformed answer' };
  const seconds = typeof b.poll_seconds === 'number' && Number.isFinite(b.poll_seconds) ? b.poll_seconds : 20;
  return { kind: 'ok', answer: { version: b.version, permissions: cleanSet(b.permissions), pollMs: Math.min(5 * 60_000, Math.max(5_000, seconds * 1000)) } };
}

type Saved = { version: number; permissions: PermissionSet };

function load(file: string): Saved | null {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as { version?: unknown; permissions?: unknown };
    if (typeof j.version !== 'number') return null;
    return { version: j.version, permissions: cleanSet(j.permissions) };
  } catch {
    return null;
  }
}

function save(file: string, s: Saved): void {
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.tmp`;
  writeFileSync(tmp, JSON.stringify(s), { mode: 0o600 });
  renameSync(tmp, file);
}

export interface PermissionsDeps {
  apiUrl: string;
  hubToken: () => string;
  vmName: string;
  agentVersion: string;
  /** Where the last answer is kept. */
  file: string;
  /** Puts a set into effect. Returns what this computer now really does (a set may be narrowed by what the computer can do). */
  apply: (set: PermissionSet) => Effective;
  fetchImpl?: typeof fetch;
  log?: (line: string) => void;
}

export class MachinePermissions {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;
  private inFlight = false;
  private failures = 0;
  private current: Saved | null;
  private reported: number | null = null;
  private again = false;
  private effective: Effective = {};

  constructor(private d: PermissionsDeps) {
    this.current = load(d.file);
  }

  /** The version in force and its set (what is kept, until the first answer). */
  get version(): number | null {
    return this.current?.version ?? null;
  }

  /** Follow the last saved choice at once (no network), then ask the backend. */
  start(): void {
    if (this.current) this.effective = this.d.apply(this.current.permissions);
    void this.tick();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  /** The hub said the set changed: ask now (a second call while one is running runs once more after it). */
  refreshNow(): Promise<void> {
    if (this.inFlight) {
      this.again = true;
      return Promise.resolve();
    }
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    return this.tick();
  }

  private schedule(ms: number): void {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.tick(), ms);
    this.timer.unref?.();
  }

  private async tick(): Promise<void> {
    if (this.stopped || this.inFlight) return;
    this.inFlight = true;
    let next = POLL_MS;
    try {
      const r = await pullPermissions({
        apiUrl: this.d.apiUrl,
        hubToken: this.d.hubToken(),
        vmName: this.d.vmName,
        agentVersion: this.d.agentVersion,
        ...(this.reported !== null ? { appliedVersion: this.reported } : {}),
        ...(this.reported !== null ? { effective: this.effective } : {}),
        fetchImpl: this.d.fetchImpl,
      });
      if (r.kind === 'ok') {
        this.failures = 0;
        next = r.answer.pollMs;
        const changed = !this.current || this.current.version !== r.answer.version;
        if (changed) {
          this.current = { version: r.answer.version, permissions: r.answer.permissions };
          try {
            save(this.d.file, this.current);
          } catch (err) {
            this.d.log?.(`Could not keep the permissions on disk: ${err instanceof Error ? err.message : 'unknown'}`);
          }
          this.effective = this.d.apply(r.answer.permissions);
          this.d.log?.(`Permissions version ${r.answer.version} applied.`);
        }
        // Tell the backend what is in force (first answer, or a new version): the next request carries it, and a change is reported now.
        if (this.reported !== r.answer.version) {
          this.reported = r.answer.version;
          this.again = true;
        }
      } else if (r.kind === 'gone') {
        next = 30 * 60_000; // not a computer the backend answers for (self-hosted hub, unpaired): ask rarely, change nothing
      } else {
        this.failures += 1;
        next = Math.min(RETRY_MAX_MS, POLL_MS * 2 ** Math.min(this.failures, 4));
      }
    } finally {
      this.inFlight = false;
    }
    if (this.again) {
      this.again = false;
      next = Math.min(next, 500);
    }
    this.schedule(next);
  }
}
