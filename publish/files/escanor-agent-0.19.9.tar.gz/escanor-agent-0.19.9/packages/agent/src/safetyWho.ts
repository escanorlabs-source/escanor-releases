import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

/** Which program runs the machine-wide safety hook (safetyHook.ts): the agent's own chat, a headless Claude, a person's terminal. */
export type Proc = { pid: number; parent: number; args: string[] };

/** This hook's ancestors, nearest first (the shell Claude runs it in, Claude, what started Claude...). */
export function ancestors(pid = process.ppid, depth = 6): Proc[] | null {
  const out: Proc[] = [];
  for (let p = pid; out.length < depth && p > 1; ) {
    try {
      const args = readFileSync(`/proc/${p}/cmdline`, 'utf8').split('\0').filter(Boolean);
      const stat = readFileSync(`/proc/${p}/stat`, 'utf8');
      const parent = Number(stat.slice(stat.lastIndexOf(')') + 2).split(' ')[1]);
      out.push({ pid: p, parent, args });
      p = parent;
    } catch {
      try {
        const line = execFileSync('ps', ['-o', 'ppid=,args=', '-p', String(p)], { encoding: 'utf8', timeout: 2000 }).trim();
        const m = /^(\d+)\s+(.*)$/.exec(line);
        if (!m) return out.length ? out : null;
        out.push({ pid: p, parent: Number(m[1]), args: m[2].split(/\s+/) });
        p = Number(m[1]);
      } catch {
        return out.length ? out : null;
      }
    }
  }
  return out;
}

const isClaude = (args: string[]) => args.some((a) => /(?:^|[\\/])claude(?:\.exe|\.js|\.mjs)?$|@anthropic-ai[\\/]claude-(?:code|agent-sdk)/.test(a));

/**
 * Who runs this hook. agentChat: a chat the Escanor agent started itself (that Claude's parent is the running agent, whose pid is
 * in <root>/agent.pid): the agent checks those calls itself, with the phone's Approve. A Claude started by anything else, even
 * from inside an agent chat, is checked here. headless: `claude -p` / stream-json, with nobody to answer an "ask".
 */
export function whoRuns(root: string, chain = ancestors(), check: (pid: number) => boolean = isAgent): { agentChat: boolean; headless: boolean } {
  if (!chain) return { agentChat: false, headless: process.platform !== 'win32' };
  const claude = chain.find((p) => isClaude(p.args));
  if (!claude) return { agentChat: false, headless: !process.stdin.isTTY && process.platform !== 'win32' };
  let agentPid = 0;
  try {
    agentPid = Number(readFileSync(join(root, 'agent.pid'), 'utf8').trim());
  } catch {
    /* no agent running */
  }
  // The pid file alone proves nothing (an AI could write its own Claude's parent into it): that process must be the agent.
  if (agentPid > 1 && claude.parent === agentPid && !check(agentPid)) agentPid = 0;
  const headless = claude.args.some((a) => a === '-p' || a === '--print' || a === 'stream-json' || a === '--input-format=stream-json');
  return { agentChat: agentPid > 1 && claude.parent === agentPid, headless };
}

/** Is this pid the Escanor agent (its command line runs the agent's index.ts / escanor-agent)? */
export function isAgent(pid: number): boolean {
  let args = '';
  try {
    args = readFileSync(`/proc/${pid}/cmdline`, 'utf8').split('\0').join(' ');
  } catch {
    try {
      args = execFileSync('ps', ['-o', 'args=', '-p', String(pid)], { encoding: 'utf8', timeout: 2000 });
    } catch {
      return false;
    }
  }
  // The agent run by itself (src/index.ts) or inside Escanor Desktop (bin/embed.mjs).
  return /packages[\\/]agent[\\/](?:src[\\/]index\.ts|bin[\\/]embed\.mjs)|escanor-agent/.test(args);
}
