/**
 * Device mesh presence: is the person at this computer right now? Read from what the computer already knows: how long since the last
 * keyboard or mouse input (the same reader the "give way to me" feature uses) and whether the screen is locked. Only these few facts
 * leave the computer, inside machine_state: no window titles, no keystrokes, no pictures. A computer with no screen (a server, a VM)
 * reports nothing, and the mesh then shows it as "has not said".
 */

export type PresenceReport = {
  /** When it was read, ISO. */
  at: string;
  /** Seconds since the last input; absent when this computer cannot tell. */
  idleSeconds?: number;
  /** Input within the last minute. */
  active?: boolean;
  locked?: boolean;
};

/** Mesh capabilities of this computer, in the words the backend and the apps use. */
export type MeshCaps = Array<'computer_control' | 'screen' | 'notifications'>;

export const ACTIVE_WITHIN_S = 60;

/** The report for one reading. `idleMs` null = cannot tell. */
export function presenceFrom(idleMs: number | null, locked: boolean | null, nowMs: number): PresenceReport {
  const out: PresenceReport = { at: new Date(nowMs).toISOString() };
  if (idleMs !== null && Number.isFinite(idleMs) && idleMs >= 0) {
    out.idleSeconds = Math.floor(idleMs / 1000);
    out.active = out.idleSeconds <= ACTIVE_WITHIN_S;
  }
  if (locked !== null) out.locked = locked;
  return out;
}

/** What this computer can do for the mesh: control (direct commands with Remote control on), a live screen, notices. */
export function meshCaps(o: { jarvis: boolean; remoteOn: boolean; hasDesktop: boolean }): MeshCaps {
  if (!o.jarvis || !o.hasDesktop) return [];
  return o.remoteOn ? ['computer_control', 'screen', 'notifications'] : ['notifications'];
}

export class PresenceWatcher {
  private last: PresenceReport | undefined;
  private timer: NodeJS.Timeout | null = null;
  private busy = false;

  constructor(
    private o: {
      idle: () => Promise<number | null>;
      locked: () => Promise<boolean | null>;
      now?: () => number;
      intervalMs?: number;
    },
  ) {}

  /** The latest reading (up to one interval old), or undefined before the first or when nothing can be read. */
  current(): PresenceReport | undefined {
    return this.last;
  }

  async refresh(): Promise<PresenceReport | undefined> {
    if (this.busy) return this.last;
    this.busy = true;
    try {
      const [idle, locked] = await Promise.all([this.o.idle().catch(() => null), this.o.locked().catch(() => null)]);
      this.last = idle === null && locked === null ? undefined : presenceFrom(idle, locked, (this.o.now ?? Date.now)());
    } finally {
      this.busy = false;
    }
    return this.last;
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.refresh(), this.o.intervalMs ?? 15_000);
    this.timer.unref();
    void this.refresh();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}

/** What changes the picture: input going from "using" to "away" and back, or the lock. Seconds alone never count as a change. */
export function presenceBucket(p: PresenceReport | undefined): string {
  if (!p) return 'none';
  const s = p.idleSeconds;
  const level = s === undefined ? 'unknown' : s <= 120 ? 'using' : s <= 900 ? 'recent' : 'idle';
  return `${level}:${p.locked === true ? 'locked' : 'open'}`;
}
