import { routeJarvis, type JarvisIntent } from '@remote-harness/shared/jarvis';
import { routeMesh } from './meshVoice.js';
import type { MeshRequest } from './meshAsk.js';
import type { PhoneAsk } from './phoneAsk.js';
import { parseAction, type ComputerAction, type Outcome } from './computerControl.js';

/**
 * What the agent does with a sentence spoken at (or typed to) this computer: the Jarvis brain reads it (the same one the phone and
 * the desktop use), simple computer actions are done here at once with no model turn, and everything else becomes one short chat
 * turn on this computer through the running agent (voiceBridge.ts), whose answer is spoken.
 *
 * What stays off this path on purpose: approving a plan (the fingerprint yes exists only on the phone), unlocking and looking at
 * the screen (phone with a fingerprint), and sending mail (the chat holds it for the person's yes, like any chat).
 */

export type BridgeRequest =
  | { op: 'chat'; text: string }
  | { op: 'status' }
  | { op: 'wake' }
  | { op: 'keep_awake'; minutes: number }
  /** Sign something in with a saved secret (waits for the owner's fingerprint on the phone). */
  | { op: 'signin'; kind: 'keyring' | 'github' | 'check'; account?: string; why?: string; force?: boolean; source?: 'ai' | 'automation' }
  | { op: 'sudo'; argv: string[]; why?: string; source?: 'ai' | 'automation' }
  | { op: 'phone'; ask: PhoneAsk }
  | { op: 'mesh'; req: MeshRequest };
export type BridgeAnswer = { ok: boolean; say: string };

export type TurnDeps = {
  /** Do one computer action here (computerControl.runComputerAction). */
  device: (a: ComputerAction) => Promise<Outcome>;
  /** The running agent on this computer, or null when it cannot be reached. */
  bridge: ((r: BridgeRequest) => Promise<BridgeAnswer>) | null;
};

export type TurnResult = { ok: boolean; say: string; kind: JarvisIntent['kind']; stop?: boolean };

const NO_AGENT = 'The Escanor agent on this computer is not running, or needs its update, so I can only do simple things like opening pages, music and volume.';
const PHONE_ONLY = 'That needs your fingerprint, so do it from your phone.';

const MAIL_REQUEST = (args: Record<string, unknown>): string =>
  'Escanor voice request from this computer: send an email in my name using my connected mail through the Escanor MCP (escanor_invoke; for Gmail google_workspace.gmail_users_messages_send, for Outlook msgraph.me_send_mail). ' +
  `Details: ${JSON.stringify(args)}. Write a short, plain email from these words. Never open a browser or click Send to do it. ` +
  'If no mail is connected, say so in one sentence and open a filled-in email with escanor_computer compose_mail instead. Answer in one short sentence.';

const CHAT_REQUEST = (text: string): string =>
  `Escanor voice request from the voice shortcut on this computer: ${text}\nAnswer in one or two short plain sentences that can be read aloud, in the language I used.`;

const TESTS_REQUEST =
  "Escanor voice request from this computer: run the current project's tests with the project's own test command. Answer in two short plain sentences: did they pass, and if not, which one failed first and why. Do not change any files, do not install anything and do not push anything.";
const FAILING_REQUEST =
  'Escanor voice request from this computer: use the Escanor tools (the Escanor MCP) to find the check or fix of mine that failed most recently, and tell me in two short plain sentences which one it is and what went wrong. Do not change anything.';
const PREVIEW_REQUEST =
  'Escanor voice request from this computer: use the Escanor tools (the Escanor MCP) to find the latest fix that has a preview, then open its preview address on this computer with escanor_computer open_url. If there is none, say so in one sentence. Do not change anything else.';

async function viaBridge(d: TurnDeps, r: BridgeRequest): Promise<BridgeAnswer> {
  if (!d.bridge) return { ok: false, say: NO_AGENT };
  try {
    return await d.bridge(r);
  } catch {
    return { ok: false, say: NO_AGENT };
  }
}

/** Do what one sentence asks. Never throws: every outcome is something to say. */
export async function answerSentence(text: string, d: TurnDeps): Promise<TurnResult> {
  // A sentence that names the owner's phone goes to the phone (or is turned away), never to this computer.
  const mesh = routeMesh(text);
  if (mesh?.kind === 'refuse') return { ok: false, say: mesh.say, kind: 'device' };
  if (mesh?.kind === 'phone') {
    const a = await viaBridge(d, { op: 'phone', ask: mesh.ask });
    return { ok: a.ok, say: a.ok && !a.say ? mesh.wording : a.say, kind: 'device' };
  }
  if (mesh?.kind === 'mesh') {
    const a = await viaBridge(d, { op: 'mesh', req: mesh.req });
    return { ok: a.ok, say: a.ok && !a.say ? mesh.wording : a.say, kind: 'device' };
  }
  const i = routeJarvis(text, { hasComputer: true });
  switch (i.kind) {
    case 'empty':
      return { ok: false, say: 'I did not catch that.', kind: 'empty' };
    case 'stop':
      return { ok: true, say: 'Okay.', kind: 'stop', stop: true };
    case 'device': {
      const kind = i.action === 'show' ? 'open_url' : i.action;
      if (kind === 'wake_screen') return { ...(await viaBridge(d, { op: 'wake' })), kind: 'device' };
      if (kind === 'keep_awake') return { ...(await viaBridge(d, { op: 'keep_awake', minutes: Number(i.args.minutes) || 30 })), kind: 'device' };
      if (kind === 'unlock_screen' || kind === 'screenshot') return { ok: false, say: PHONE_ONLY, kind: 'device' };
      const a = parseAction(kind, i.args);
      if ('error' in a) return { ok: false, say: a.error, kind: 'device' };
      const out = await d.device(a);
      return { ok: out.ok, say: out.say, kind: 'device' };
    }
    case 'send_mail':
      return { ...(await viaBridge(d, { op: 'chat', text: MAIL_REQUEST(i.args) })), kind: 'send_mail' };
    case 'sdlc': {
      switch (i.op) {
        case 'status':
          return { ...(await viaBridge(d, { op: 'status' })), kind: 'sdlc' };
        case 'run_tests':
          return { ...(await viaBridge(d, { op: 'chat', text: TESTS_REQUEST })), kind: 'sdlc' };
        case 'show_failing_check':
          return { ...(await viaBridge(d, { op: 'chat', text: FAILING_REQUEST })), kind: 'sdlc' };
        case 'open_preview':
          return { ...(await viaBridge(d, { op: 'chat', text: PREVIEW_REQUEST })), kind: 'sdlc' };
        case 'approve_plan':
          return { ok: false, say: 'Approving a plan needs your fingerprint, so approve it on your phone.', kind: 'sdlc' };
        case 'reject_plan':
          return { ok: false, say: 'Refuse a plan from the Changes page in the app or on your phone.', kind: 'sdlc' };
      }
      return { ok: false, say: 'I did not understand that.', kind: 'sdlc' };
    }
    case 'screen':
      return { ok: false, say: `The ${i.screen} screen is in the Escanor app, not here. Open the app and say it there.`, kind: 'screen' };
    case 'custom':
      return { ok: true, say: i.say, kind: 'custom' };
    case 'chat':
      return { ...(await viaBridge(d, { op: 'chat', text: CHAT_REQUEST(i.text) })), kind: 'chat' };
  }
}
