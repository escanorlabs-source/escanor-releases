// How this machine keeps its chats few and Claude's limits in mind (SessionManager applies these):
// - a request for a new chat continues the recent idle chat in the same folder instead (unless the person asks for a new one),
// - at most `maxOpen` chats are open and `maxLive` Claude processes run; the oldest idle one is put away to make room,
// - while Claude's usage limit is reached new work waits for the reset, and near it no new chats are started,
// - a long chat is compacted before it is continued, instead of a fresh one being started.
// Pure functions over registry entries, so each rule is tested on its own (test/chatPolicy.test.ts).
import type { RegistryEntry } from './registry.js';

export type ChatLimits = {
  /** A chat idle for less than this is continued instead of starting a new one. 0 = never (except near the usage limit). */
  reuseIdleHours: number;
  /** Chats this machine keeps open (not put away). */
  maxOpen: number;
  /** Claude processes running at once. */
  maxLive: number;
  /** Compact a chat before continuing it when its context is at least this full (percent)... */
  compactAtPercent: number;
  /** ...or when it has had this many turns since it was last compacted. */
  compactAfterTurns: number;
};

export const DEFAULT_CHAT_LIMITS: ChatLimits = { reuseIdleHours: 12, maxOpen: 5, maxLive: 3, compactAtPercent: 75, compactAfterTurns: 40 };

const num = (raw: string | undefined, fallback: number, min: number, max = Number.MAX_SAFE_INTEGER): number => {
  const v = raw?.trim() ? Number(raw) : NaN;
  return Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : fallback;
};

/** REUSE_IDLE_HOURS, MAX_OPEN_SESSIONS, MAX_LIVE_SESSIONS, COMPACT_AT_PERCENT, COMPACT_AFTER_TURNS. */
export function chatLimitsFrom(env: Record<string, string | undefined>): ChatLimits {
  const d = DEFAULT_CHAT_LIMITS;
  return {
    reuseIdleHours: num(env.REUSE_IDLE_HOURS, d.reuseIdleHours, 0),
    maxOpen: Math.round(num(env.MAX_OPEN_SESSIONS, d.maxOpen, 1)),
    maxLive: Math.round(num(env.MAX_LIVE_SESSIONS, d.maxLive, 1)),
    compactAtPercent: num(env.COMPACT_AT_PERCENT, d.compactAtPercent, 1, 100),
    compactAfterTurns: Math.round(num(env.COMPACT_AFTER_TURNS, d.compactAfterTurns, 1)),
  };
}

/** A first message that starts with "/new" asks for a separate chat; the marker itself is not sent to Claude. */
export function explicitNewChat(text: string): { fresh: boolean; text: string } {
  const m = /^\s*\/new(?:\s+|$)/i.exec(text);
  return m ? { fresh: true, text: text.slice(m[0].length) } : { fresh: false, text };
}

const activeAt = (e: RegistryEntry): number => Date.parse(e.lastActiveAt ?? e.createdAt) || 0;

/** A chat this agent started (a terminal one is the person's own) and has not put away. */
export const isOpen = (e: RegistryEntry): boolean => e.source !== 'terminal' && !e.archivedAt;

/**
 * The chat a request for a new one should continue: same folder, Claude account and isolation; not running; started by this
 * agent; last turn fine (or stopped by the usage limit); active within the window and not put away. `relaxed` (Claude's usage
 * nearly used up: reuse only) drops the last three conditions.
 */
export function pickReusable(
  entries: RegistryEntry[],
  want: { cwd: string; accountId: string; isolated: boolean },
  opts: { now: number; maxAgeMs: number; running: (sessionId: string) => boolean; relaxed?: boolean },
): RegistryEntry | undefined {
  const fits = entries.filter((e) => {
    if (e.source === 'terminal' || e.cwd !== want.cwd || e.accountId !== want.accountId) return false;
    if ((e.isolated === true) !== want.isolated || opts.running(e.sessionId)) return false;
    if (opts.relaxed) return true;
    if (e.archivedAt || (e.lastOutcome && e.lastOutcome !== 'ok' && e.lastOutcome !== 'rate_limited')) return false;
    return opts.maxAgeMs > 0 && opts.now - activeAt(e) <= opts.maxAgeMs;
  });
  return fits.sort((a, b) => activeAt(b) - activeAt(a))[0];
}

/** The least recently active entry that is not busy (and not `exclude`): the one to close or put away first. */
export function pickOldestIdle(entries: RegistryEntry[], busy: (sessionId: string) => boolean, exclude?: string): RegistryEntry | undefined {
  return entries.filter((e) => e.sessionId !== exclude && !busy(e.sessionId)).sort((a, b) => activeAt(a) - activeAt(b))[0];
}

export type UsageStatus = 'allowed' | 'allowed_warning' | 'rejected';
type LimitInfo = { status?: string; resetsAt?: number };

/** Held for this long when Claude says the limit is reached but not until when. */
const UNKNOWN_RESET_MS = 30 * 60_000;

/** resetsAt arrives in Unix seconds; accept milliseconds too. */
const toMs = (t: number | undefined): number | undefined => (typeof t === 'number' && t > 0 ? (t < 1e12 ? t * 1000 : t) : undefined);

/** Claude's last word on each account's usage (the SDK's rate_limit_event), until it changes or its window resets. */
export class UsageLimits {
  private byAccount = new Map<string, { status: Exclude<UsageStatus, 'allowed'>; resetsAt?: number }>();

  note(accountId: string, info: LimitInfo, now = Date.now()): void {
    if (info.status === 'allowed_warning' || info.status === 'rejected') {
      const resetsAt = toMs(info.resetsAt) ?? (info.status === 'rejected' ? now + UNKNOWN_RESET_MS : undefined);
      this.byAccount.set(accountId, { status: info.status, resetsAt });
    } else if (info.status === 'allowed') {
      this.byAccount.delete(accountId);
    }
  }

  state(accountId: string, now = Date.now()): { status: UsageStatus; resetsAt?: number } {
    const s = this.byAccount.get(accountId);
    if (!s) return { status: 'allowed' };
    if (s.resetsAt !== undefined && now >= s.resetsAt) {
      this.byAccount.delete(accountId);
      return { status: 'allowed' };
    }
    return s.resetsAt !== undefined ? { status: s.status, resetsAt: s.resetsAt } : { status: s.status };
  }

  /** The soonest time a held account frees up. */
  nextReset(now = Date.now()): number | undefined {
    const times = [...this.byAccount.keys()]
      .map((a) => this.state(a, now))
      .filter((s) => s.status === 'rejected' && s.resetsAt !== undefined)
      .map((s) => s.resetsAt!);
    return times.length ? Math.min(...times) : undefined;
  }
}

/** What the person is told while work waits for Claude's limit to reset (the machine's local time). */
export function limitNotice(resetsAt: number): string {
  const d = new Date(resetsAt);
  const hhmm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  const zone = new Intl.DateTimeFormat('en-GB', { timeZoneName: 'short' }).formatToParts(d).find((p) => p.type === 'timeZoneName')?.value;
  return `Claude's usage limit is reached; will resume at ${hhmm}${zone ? ` ${zone}` : ''}. This message waits on the machine and is sent then.`;
}

/** Compact a chat before continuing it: its context is nearly full, or it has had many turns since the last compaction. */
export function needsCompaction(e: Pick<RegistryEntry, 'contextPct' | 'turnsSinceCompact'> | undefined, limits: ChatLimits): boolean {
  if (!e) return false;
  return (e.contextPct ?? 0) >= limits.compactAtPercent || (e.turnsSinceCompact ?? 0) >= limits.compactAfterTurns;
}

export type ChatStats = {
  type: 'system';
  subtype: 'escanor_stats';
  session_id: string;
  /** How full the chat's context is (percent), when Claude Code said. */
  contextPct?: number;
  /** Turns since the chat was last compacted. */
  turns: number;
  /** The chat is compacted at this percent, or after `compactAfterTurns` turns. */
  compactAtPercent: number;
  compactAfterTurns: number;
  /** Claude's usage on this chat's account, only when it is nearly used up or reached; resetsAt in ms. */
  limit?: { status: 'allowed_warning' | 'rejected'; resetsAt?: number };
};

/**
 * What a chat's header shows ("context 62 %", "paused until 14:20"). Sent in the chat itself as a system message with an Escanor
 * subtype, which every hub stores and forwards as it does any message and which apps and hubs from before it ignore.
 */
export function chatStats(
  sessionId: string,
  entry: Pick<RegistryEntry, 'contextPct' | 'turnsSinceCompact'> | undefined,
  limits: ChatLimits,
  usage: { status: UsageStatus; resetsAt?: number },
): ChatStats {
  return {
    type: 'system',
    subtype: 'escanor_stats',
    session_id: sessionId,
    ...(typeof entry?.contextPct === 'number' ? { contextPct: entry.contextPct } : {}),
    turns: entry?.turnsSinceCompact ?? 0,
    compactAtPercent: limits.compactAtPercent,
    compactAfterTurns: limits.compactAfterTurns,
    ...(usage.status !== 'allowed' ? { limit: { status: usage.status, ...(usage.resetsAt !== undefined ? { resetsAt: usage.resetsAt } : {}) } } : {}),
  };
}
