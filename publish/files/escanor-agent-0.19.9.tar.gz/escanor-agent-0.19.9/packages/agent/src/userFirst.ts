import { execFile } from 'node:child_process';
import { existsSync, readFileSync, readdirSync, writeFileSync, renameSync, mkdirSync } from 'node:fs';
import { freemem, platform, setPriority, totalmem } from 'node:os';
import { dirname, basename } from 'node:path';

/**
 * The person comes first. When someone is using this computer (or other programs need its processor or memory), our Claude work
 * gives way, by itself and without being asked:
 *  - yield: the person is at the keyboard, or other programs are fairly busy. Work goes on (new work starts too), but our processes
 *    go to the lowest priority (nice 19, idle disk priority) so the person never feels them ("running gently").
 *  - pause: other programs need the processor or memory. Our running chat processes are stopped (SIGSTOP) so they use no processor;
 *    memory stays with them until it is critical for a while, then idle chats are put away (resumable) to give it back.
 *  - normal again once the person has been idle for a while (default 2 minutes) or the load has dropped, with margins so it never flaps.
 * A chat the person drives live in their own terminal is the person, not our work: never touched. Modes: 'on' (default), 'gentle'
 * (yield only, never pause), 'off'. Pure logic + injectable sources, so it is tested with fake idle readers and fake /proc.
 */

export type GiveWayMode = 'on' | 'gentle' | 'off';
export type UserFirstLevel = 'normal' | 'yield' | 'pause';
/** Why it gives way: the person is active ('using'), other programs are busy ('busy') or short of memory ('memory'). */
export type UserFirstWhy = 'using' | 'busy' | 'memory';

export type UserFirstState = {
  level: UserFirstLevel;
  why: UserFirstWhy | null;
  /** Memory has stayed critical for a while: idle chats should be put away to give it back. */
  memoryCritical: boolean;
  /** Input idle time when known. */
  idleMs: number | null;
  /** When this level began (ms). */
  since: number;
};

export const parseGiveWay = (v: unknown): GiveWayMode | null => (v === 'on' || v === 'gentle' || v === 'off' ? v : null);

/** What the phone shows. */
export function giveWayText(level: UserFirstLevel, why: UserFirstWhy | null): string | null {
  if (level === 'normal') return null;
  if (level === 'pause') return why === 'using' ? "Paused: you're using this computer" : why === 'memory' ? 'Paused: this computer is short of memory' : 'Paused: this computer is busy';
  return why === 'using' ? "Running gently: you're using this computer" : why === 'memory' ? 'Running gently: this computer is short of memory' : 'Running gently: computer busy';
}

/** The one-line notice for a message that waits because of it. */
export const waitingNotice = (why: UserFirstWhy | null): string =>
  `${why === 'using' ? "Waiting: you're using this computer" : why === 'memory' ? 'Waiting: this computer is short of memory' : 'Waiting: computer busy'}. It starts by itself when you are done; nothing is lost.`;

export type UserFirstLimits = {
  /** Other programs' share of the whole machine's processor: yield above yieldOn (until under yieldOff), pause above pauseOn (until under pauseOff). */
  yieldCpuOn: number;
  yieldCpuOff: number;
  pauseCpuOn: number;
  pauseCpuOff: number;
  /** Machine memory used (percent): pause at or above pauseMemOn (resume under pauseMemOff). 85 = less than 15% available. */
  pauseMemOn: number;
  pauseMemOff: number;
  /** Used memory at or above this for criticalSustain samples: idle chats are put away. */
  criticalMemOn: number;
  criticalMemOff: number;
  criticalSustain: number;
  /** Memory pressure (PSI "some" avg10) counts as short of memory above this. */
  psiMemOn: number;
  psiCpuOn: number;
  /** Samples in a row a reading must hold before it counts. */
  sustain: number;
  memSustain: number;
  /** Input within this long ago = the person is active. */
  activeWithinMs: number;
  /** Idle this long = the person is gone, work goes on. */
  idleResumeMs: number;
  intervalMs: number;
  enabled: boolean;
};

export const DEFAULT_USER_FIRST: UserFirstLimits = {
  yieldCpuOn: 40,
  yieldCpuOff: 25,
  pauseCpuOn: 70,
  pauseCpuOff: 45,
  pauseMemOn: 85,
  pauseMemOff: 78,
  criticalMemOn: 95,
  criticalMemOff: 90,
  criticalSustain: 12,
  psiMemOn: 25,
  psiCpuOn: 60,
  sustain: 3,
  memSustain: 2,
  activeWithinMs: 15_000,
  idleResumeMs: 2 * 60_000,
  intervalMs: 5_000,
  enabled: true,
};

const num = (raw: string | undefined, fallback: number, min: number, max = Number.MAX_SAFE_INTEGER): number => {
  if (raw === undefined || raw.trim() === '') return fallback;
  const n = Number(raw);
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
};

/** USER_FIRST=on|gentle|off (the starting mode; the phone's setting wins once set), USER_FIRST_IDLE_MIN=2, USER_FIRST_PAUSE_CPU=70, USER_FIRST_YIELD_CPU=40, USER_FIRST_PAUSE_FREE_MEM=15. */
export function userFirstLimitsFrom(env: Record<string, string | undefined>): { limits: UserFirstLimits; mode: GiveWayMode } {
  const d = DEFAULT_USER_FIRST;
  const pauseOn = num(env.USER_FIRST_PAUSE_CPU, d.pauseCpuOn, 20, 100);
  const yieldOn = Math.min(num(env.USER_FIRST_YIELD_CPU, d.yieldCpuOn, 10, 100), pauseOn);
  const freeMem = num(env.USER_FIRST_PAUSE_FREE_MEM, 100 - d.pauseMemOn, 3, 60);
  return {
    mode: parseGiveWay(env.USER_FIRST?.trim().toLowerCase()) ?? 'on',
    limits: {
      ...d,
      yieldCpuOn: yieldOn,
      yieldCpuOff: Math.round(yieldOn * 0.625),
      pauseCpuOn: pauseOn,
      pauseCpuOff: Math.round(pauseOn * 0.64),
      pauseMemOn: 100 - freeMem,
      pauseMemOff: 100 - freeMem - 7,
      idleResumeMs: num(env.USER_FIRST_IDLE_MIN, d.idleResumeMs / 60_000, 0.1, 240) * 60_000,
      intervalMs: Math.max(1, num(env.USER_FIRST_INTERVAL_SEC, d.intervalMs / 1000, 1)) * 1000,
    },
  };
}

// ---------- the machine, as one reading ----------

export type ProcEntry = {
  pid: number;
  ppid: number;
  /** Total processor time used (ms); null where unknown. */
  cpuMs: number | null;
  rss: number;
  argv: string[];
};

export type UfSample = {
  at: number;
  /** Time since the last keyboard / mouse input; null = cannot be told here (a server without a screen). */
  idleMs: number | null;
  /** Share of the whole machine's processor used by everything that is not ours (percent); null = unknown. */
  otherCpuPct: number | null;
  /** Memory in use, percent of the machine; null = unknown. */
  usedMemPct: number | null;
  /** Our share of the memory in use (0..1); null = unknown. */
  ourMemShare: number | null;
  /** Linux pressure-stall "some avg10" for memory and processor (percent); null = not there. */
  psiMem: number | null;
  psiCpu: number | null;
  /** Share of the machine's processor our own processes used (percent). */
  ourCpuPct: number | null;
  /** Every process (the controller picks ours from this). */
  procs: ProcEntry[];
};

/** A reading that must hold for `sustain` samples in a row to switch on, and stay under the off mark that long to switch off. */
export class Hyst {
  on = false;
  private up = 0;
  private down = 0;
  constructor(
    private onAt: number,
    private offAt: number,
    private sustainOn: number,
    private sustainOff: number = sustainOn,
  ) {}
  /** null = no reading: nothing changes. */
  update(v: number | null): boolean {
    if (v === null) return this.on;
    if (v >= this.onAt) {
      this.up++;
      this.down = 0;
      if (this.up >= this.sustainOn) this.on = true;
    } else if (v < this.offAt) {
      this.down++;
      this.up = 0;
      if (this.down >= this.sustainOff) this.on = false;
    } else {
      // in the margin: neither counts
      this.up = 0;
      this.down = 0;
    }
    return this.on;
  }
  reset(): void {
    this.on = false;
    this.up = 0;
    this.down = 0;
  }
}

/** Chat processes of ours: Claude (and the Codex / Gemini / Copilot engines). */
export function isChatProcess(argv: string[]): boolean {
  const name = (a: string | undefined) => basename(a ?? '').toLowerCase().replace(/\.(exe|js|mjs|cjs)$/, '');
  const chat = (n: string) => n === 'claude' || n === 'codex' || n === 'gemini' || n === 'copilot' || n === 'claude-code';
  if (argv.slice(0, 2).some((a) => chat(name(a)))) return true;
  // The wrapper that hands the MCP configuration over on a pipe: bash -c '<script>' claude <args> (chatUser.ts).
  if (/^(bash|sh)$/.test(name(argv[0])) && argv[1] === '-c' && chat(name(argv[3]))) return true;
  return argv.slice(0, 4).some((a) => /[\\/]@anthropic-ai[\\/]claude-code[\\/]/.test(a ?? ''));
}

/** `root` and everything below it, from all processes. */
export function treeOf(procs: ProcEntry[], root: number): ProcEntry[] {
  const byParent = new Map<number, ProcEntry[]>();
  for (const p of procs) byParent.set(p.ppid, [...(byParent.get(p.ppid) ?? []), p]);
  const out: ProcEntry[] = [];
  const seen = new Set<number>([root]);
  const stack = [root];
  while (stack.length) {
    for (const c of byParent.get(stack.pop()!) ?? []) {
      if (seen.has(c.pid)) continue;
      seen.add(c.pid);
      out.push(c);
      stack.push(c.pid);
    }
  }
  return out;
}

/**
 * The chat processes to hold: every chat process below the agent, and all that is below those, minus anything in `exempt` (a chat the
 * person drives from a terminal) and what is below an exempt process. The agent itself and its helpers are never in it.
 */
export function chatTrees(procs: ProcEntry[], agentPid: number, exempt: Set<number>): number[] {
  const mine = treeOf(procs, agentPid);
  const skip = new Set<number>();
  for (const e of exempt) {
    skip.add(e);
    for (const c of treeOf(procs, e)) skip.add(c.pid);
  }
  const out = new Set<number>();
  for (const p of mine) {
    if (skip.has(p.pid) || !isChatProcess(p.argv)) continue;
    out.add(p.pid);
    for (const c of treeOf(procs, p.pid)) if (!skip.has(c.pid)) out.add(c.pid);
  }
  return [...out];
}

// ---------- the controller ----------

export type Actions = {
  kill: (pid: number, signal: 'SIGSTOP' | 'SIGCONT') => void;
  /** Lowest priority for a process (all its threads where that matters). Cannot be undone without privileges; failures are ignored. */
  nice: (pid: number) => void;
  /** Idle disk priority on (true) or back to normal (false); best effort. */
  ioIdle: (pid: number, on: boolean) => void;
};

export type StoppedRecord = { pid: number; start: string | null };

export type UserFirstDeps = {
  sampler: () => Promise<UfSample> | UfSample;
  actions: Actions;
  /** Processes the person drives (terminal chats): never held. */
  exempt: () => Set<number>;
  /** The persisted list of what was stopped, so a crashed agent can start them again. */
  store?: { load: () => StoppedRecord[]; save: (r: StoppedRecord[]) => void };
  startOf?: (pid: number) => string | null;
  alive?: (pid: number) => boolean;
  now?: () => number;
  agentPid?: number;
};

export class UserFirst {
  private _state: UserFirstState;
  private mode: GiveWayMode;
  private cpuYield: Hyst;
  private cpuPause: Hyst;
  private mem: Hyst;
  private critical: Hyst;
  private activeLatched = false;
  private stopped = new Set<number>();
  private ioIdled = new Set<number>();
  private niced = new Set<number>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private running = false;
  private listeners: ((s: UserFirstState, prev: UserFirstState) => void)[] = [];
  private now: () => number;

  constructor(
    readonly limits: UserFirstLimits,
    private deps: UserFirstDeps,
    mode: GiveWayMode = 'on',
  ) {
    this.mode = mode;
    this.now = deps.now ?? Date.now;
    this.cpuYield = new Hyst(limits.yieldCpuOn, limits.yieldCpuOff, limits.sustain);
    this.cpuPause = new Hyst(limits.pauseCpuOn, limits.pauseCpuOff, limits.sustain);
    this.mem = new Hyst(limits.pauseMemOn, limits.pauseMemOff, limits.memSustain);
    this.critical = new Hyst(limits.criticalMemOn, limits.criticalMemOff, limits.criticalSustain, limits.memSustain);
    this._state = { level: 'normal', why: null, memoryCritical: false, idleMs: null, since: this.now() };
  }

  get state(): UserFirstState {
    return this._state;
  }
  get giveWay(): GiveWayMode {
    return this.mode;
  }
  /**
   * Is new work held back? Only while paused (other programs really need the processor or memory). While the person merely uses
   * the computer (yield), work goes on and new work starts, at the lowest priority (owner, 24 Oct: never stop for that, use less).
   */
  get holding(): boolean {
    return this._state.level === 'pause';
  }
  /** How many processes are stopped right now. */
  get stoppedCount(): number {
    return this.stopped.size;
  }

  onChange(fn: (s: UserFirstState, prev: UserFirstState) => void): void {
    this.listeners.push(fn);
  }

  /** The person's setting. Takes effect at once. */
  setMode(mode: GiveWayMode): void {
    if (mode === this.mode) return;
    this.mode = mode;
    if (mode === 'off') this.release(); // everything goes on right now; the next look tells the listeners
    void this.tick();
  }

  /** Start again what an agent that died while pausing left stopped (and is still the same process). */
  recover(): number {
    const store = this.deps.store;
    if (!store) return 0;
    let n = 0;
    for (const r of store.load()) {
      if (!this.sameProcess(r)) continue;
      try {
        this.deps.actions.kill(r.pid, 'SIGCONT');
        n++;
      } catch {
        // gone
      }
    }
    store.save([]);
    return n;
  }

  start(): void {
    if (this.timer || !this.limits.enabled) return;
    this.timer = setInterval(() => void this.tick(), this.limits.intervalMs);
    this.timer.unref?.();
    void this.tick();
  }

  /** The agent is going away: nothing of ours stays stopped. */
  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.release();
  }

  /** One look, decide, act, tell the listeners. Never twice at once. */
  async tick(): Promise<UserFirstState> {
    if (!this.limits.enabled || this.running) return this._state;
    this.running = true;
    try {
      let s: UfSample;
      try {
        s = await this.deps.sampler();
      } catch {
        return this._state; // cannot look: nothing changes
      }
      const prev = this._state;
      this._state = this.evaluate(s);
      this.apply(s, prev);
      if (prev.level !== this._state.level || prev.why !== this._state.why || prev.memoryCritical !== this._state.memoryCritical) {
        for (const fn of this.listeners) {
          try {
            fn(this._state, prev);
          } catch (err) {
            console.error('User-first listener failed', err);
          }
        }
      }
      return this._state;
    } finally {
      this.running = false;
    }
  }

  private evaluate(s: UfSample): UserFirstState {
    const l = this.limits;
    const prev = this._state;
    if (this.mode === 'off') {
      this.activeLatched = false;
      for (const h of [this.cpuYield, this.cpuPause, this.mem, this.critical]) h.reset();
      return { level: 'normal', why: null, memoryCritical: false, idleMs: s.idleMs, since: prev.level === 'normal' ? prev.since : s.at };
    }
    // Is the person there? Input within a few seconds latches "active"; it clears once they have been idle long enough.
    if (s.idleMs === null) this.activeLatched = false;
    else if (s.idleMs < l.activeWithinMs) this.activeLatched = true;
    else if (s.idleMs >= l.idleResumeMs) this.activeLatched = false;
    // Other programs' processor use (the pressure-stall figure counts only when none of ours is running: it includes us otherwise).
    let cpu = s.otherCpuPct;
    if (s.psiCpu !== null && s.psiCpu >= l.psiCpuOn && (s.ourCpuPct ?? 0) < 5) cpu = Math.max(cpu ?? 0, l.pauseCpuOn);
    this.cpuYield.update(cpu);
    this.cpuPause.update(cpu);
    // Memory: only when others hold a real share of what is in use (if we hold most of it, stopping us does not help the person).
    const othersHoldMem = s.ourMemShare === null || s.ourMemShare < 0.5;
    let mem = s.usedMemPct === null ? null : othersHoldMem ? s.usedMemPct : 0;
    if (s.psiMem !== null && s.psiMem >= l.psiMemOn && othersHoldMem) mem = 100;
    this.mem.update(mem);
    this.critical.update(s.usedMemPct !== null && othersHoldMem ? s.usedMemPct : s.usedMemPct === null ? null : 0);

    const pauseWanted = this.cpuPause.on || this.mem.on;
    const why = (fallback: UserFirstWhy): UserFirstWhy => (this.activeLatched ? 'using' : this.mem.on ? 'memory' : fallback);
    let level: UserFirstLevel = 'normal';
    let reason: UserFirstWhy | null = null;
    if (pauseWanted && this.mode === 'on') {
      level = 'pause';
      reason = why('busy');
    } else if (pauseWanted || this.activeLatched || this.cpuYield.on) {
      level = 'yield';
      reason = why('busy');
    }
    return { level, why: reason, memoryCritical: this.critical.on, idleMs: s.idleMs, since: level === prev.level ? prev.since : s.at };
  }

  private apply(s: UfSample, prev: UserFirstState): void {
    const level = this._state.level;
    const a = this.deps.actions;
    const agent = this.deps.agentPid ?? process.pid;
    const mine = level === 'normal' && this.stopped.size === 0 && this.ioIdled.size === 0 ? [] : chatTrees(s.procs, agent, this.deps.exempt());
    const live = new Set(mine);
    if (level !== 'normal') {
      for (const pid of mine) {
        if (!this.niced.has(pid)) {
          this.niced.add(pid);
          this.safely(() => a.nice(pid));
        }
        if (!this.ioIdled.has(pid)) {
          this.ioIdled.add(pid);
          this.safely(() => a.ioIdle(pid, true));
        }
      }
    }
    if (level === 'pause') {
      let changed = false;
      for (const pid of mine) {
        if (this.stopped.has(pid)) continue;
        this.stopped.add(pid);
        changed = true;
        this.safely(() => a.kill(pid, 'SIGSTOP'));
      }
      if (changed) this.persist();
    } else if (this.stopped.size > 0) {
      this.continueAll();
    }
    if (level === 'normal' && this.ioIdled.size > 0) {
      for (const pid of this.ioIdled) this.safely(() => a.ioIdle(pid, false));
      this.ioIdled.clear();
    }
    // Forget processes that are gone.
    for (const set of [this.stopped, this.ioIdled, this.niced]) for (const pid of set) if (!live.has(pid) && level !== 'normal') set.delete(pid);
    if (level === 'normal' && prev.level !== 'normal') this.niced.clear();
  }

  private continueAll(): void {
    for (const pid of this.stopped) this.safely(() => this.deps.actions.kill(pid, 'SIGCONT'));
    this.stopped.clear();
    this.deps.store?.save([]);
  }

  /** Everything goes on: nothing stopped, normal disk priority. */
  private release(): void {
    this.continueAll();
    for (const pid of this.ioIdled) this.safely(() => this.deps.actions.ioIdle(pid, false));
    this.ioIdled.clear();
    this.niced.clear();
  }

  private persist(): void {
    const store = this.deps.store;
    if (!store) return;
    const start = this.deps.startOf ?? (() => null);
    store.save([...this.stopped].map((pid) => ({ pid, start: start(pid) })));
  }

  private sameProcess(r: StoppedRecord): boolean {
    const alive = this.deps.alive ?? (() => true);
    if (!alive(r.pid)) return false;
    if (r.start === null) return false; // cannot tell it is the same process: never signal a pid that may be someone else's now
    return (this.deps.startOf?.(r.pid) ?? null) === r.start;
  }

  private safely(fn: () => void): void {
    try {
      fn();
    } catch {
      // not allowed, or already gone
    }
  }
}

// ---------- real sources ----------

type Exec = (cmd: string, args: string[], timeoutMs: number, env?: NodeJS.ProcessEnv) => Promise<string | null>;

export const execText: Exec = (cmd, args, timeoutMs, env) =>
  new Promise((resolve) => {
    try {
      execFile(cmd, args, { timeout: timeoutMs, encoding: 'utf8', env: env ?? process.env, windowsHide: true }, (err, stdout) => resolve(err ? null : stdout));
    } catch {
      resolve(null);
    }
  });

/** `(uint64 2212652,)` from Mutter's IdleMonitor (GNOME: X11 and Wayland). */
export const parseMutterIdle = (out: string): number | null => {
  const m = /uint64\s+(\d+)/.exec(out);
  return m ? Number(m[1]) : null;
};
/** `(uint32 1234,)` from org.freedesktop.ScreenSaver.GetSessionIdleTime (KDE; milliseconds). */
export const parseScreenSaverIdle = (out: string): number | null => {
  const m = /uint(?:32|64)?\s+(\d+)/.exec(out);
  return m ? Number(m[1]) : null;
};
/** xprintidle prints milliseconds. */
export const parseXprintidle = (out: string): number | null => (/^\s*(\d+)\s*$/.test(out) ? Number(out.trim()) : null);
/** macOS: `"HIDIdleTime" = 4294967` in nanoseconds. */
export const parseHidIdle = (out: string): number | null => {
  const m = /"HIDIdleTime"\s*=\s*(\d+)/.exec(out);
  return m ? Math.round(Number(m[1]) / 1e6) : null;
};
/** loginctl show-user: only "idle" is evidence (a desktop that never sets the hint says no all day). */
export const parseLoginctlIdle = (out: string, nowMs: number): number | null => {
  if (!/^IdleHint=yes$/m.test(out)) return null;
  const since = /^IdleSinceHint=(\d+)$/m.exec(out);
  const ms = since ? Number(since[1]) / 1000 : 0;
  return ms > 0 ? Math.max(0, nowMs - ms) : 3_600_000;
};

const WIN_IDLE_PS =
  "Add-Type -TypeDefinition 'using System;using System.Runtime.InteropServices;public static class EscIdle{[StructLayout(LayoutKind.Sequential)]struct L{public uint s;public uint t;}[DllImport(\"user32.dll\")]static extern bool GetLastInputInfo(ref L p);public static uint Ms(){var i=new L();i.s=(uint)Marshal.SizeOf(i);GetLastInputInfo(ref i);return (uint)Environment.TickCount-i.t;}}'; [EscIdle]::Ms()";

/** Input idle time from whatever this machine has; null on a machine with no screen or no way to ask. */
export function makeIdleReader(o: { exec?: Exec; plat?: NodeJS.Platform; now?: () => number; uid?: number } = {}): () => Promise<number | null> {
  const exec = o.exec ?? execText;
  const plat = o.plat ?? platform();
  const now = o.now ?? Date.now;
  const uid = o.uid ?? (typeof process.getuid === 'function' ? process.getuid() : 0);
  const busPath = `/run/user/${uid}/bus`;
  let good: number | null = null; // index of the source that worked last
  let lastAll = 0;
  let winAt = Number.NEGATIVE_INFINITY;
  let winLast: number | null = null;
  const dbusEnv = (): NodeJS.ProcessEnv => ({
    ...process.env,
    ...(process.env.DBUS_SESSION_BUS_ADDRESS || !existsSync(busPath) ? {} : { DBUS_SESSION_BUS_ADDRESS: `unix:path=${busPath}` }),
  });
  const linux: (() => Promise<number | null>)[] = [
    async () => {
      const r = await exec('gdbus', ['call', '--session', '--dest', 'org.gnome.Mutter.IdleMonitor', '--object-path', '/org/gnome/Mutter/IdleMonitor/Core', '--method', 'org.gnome.Mutter.IdleMonitor.GetIdletime'], 2000, dbusEnv());
      return r === null ? null : parseMutterIdle(r);
    },
    async () => {
      const r = await exec('gdbus', ['call', '--session', '--dest', 'org.freedesktop.ScreenSaver', '--object-path', '/org/freedesktop/ScreenSaver', '--method', 'org.freedesktop.ScreenSaver.GetSessionIdleTime'], 2000, dbusEnv());
      return r === null ? null : parseScreenSaverIdle(r);
    },
    async () => {
      const r = await exec('xprintidle', [], 2000);
      return r === null ? null : parseXprintidle(r);
    },
    async () => {
      const r = await exec('loginctl', ['show-user', String(uid), '-p', 'IdleHint', '-p', 'IdleSinceHint'], 2000);
      return r === null ? null : parseLoginctlIdle(r, now());
    },
  ];
  return async () => {
    if (plat === 'darwin') {
      const r = await exec('ioreg', ['-c', 'IOHIDSystem', '-d', '4'], 3000);
      return r === null ? null : parseHidIdle(r);
    }
    if (plat === 'win32') {
      // Starting PowerShell is slow: look every 15 s and carry the figure on in between.
      if (now() - winAt >= 15_000) {
        winAt = now();
        const r = await exec('powershell', ['-NoProfile', '-NonInteractive', '-Command', WIN_IDLE_PS], 8000);
        winLast = r !== null && /^\s*\d+\s*$/.test(r) ? Number(r.trim()) : null;
      }
      return winLast === null ? null : winLast + (now() - winAt);
    }
    if (plat !== 'linux') return null;
    if (good !== null) {
      const v = await linux[good]();
      if (v !== null) return v;
      good = null;
    }
    // Nothing worked last time: try them all again only now and then (a server without a screen has none).
    if (good === null && now() - lastAll < 5 * 60_000 && lastAll !== 0) return null;
    lastAll = now();
    for (let i = 0; i < linux.length; i++) {
      const v = await linux[i]();
      if (v !== null) {
        good = i;
        return v;
      }
    }
    return null;
  };
}

/** The first line of /proc/stat as [busy, total] ticks (iowait counts as idle; guest is already inside user). */
export function parseProcStatCpu(text: string): { busy: number; total: number } | null {
  const line = text.split('\n', 1)[0];
  if (!line.startsWith('cpu ')) return null;
  const f = line.trim().split(/\s+/).slice(1).map(Number);
  if (f.length < 4 || !f.every(Number.isFinite)) return null;
  const [user, nice, system, idle, iowait = 0, irq = 0, softirq = 0, steal = 0] = f;
  const total = user + nice + system + idle + iowait + irq + softirq + steal;
  return { busy: total - idle - iowait, total };
}

/** `some avg10=0.08 avg60=...` -> 0.08 (the "some" line). */
export function parsePsi(text: string): number | null {
  const m = /^some\s+avg10=([\d.]+)/m.exec(text);
  return m ? Number(m[1]) : null;
}

/** MemTotal and MemAvailable from /proc/meminfo, in bytes. */
export function parseMeminfo(text: string): { total: number; avail: number } | null {
  const t = /^MemTotal:\s+(\d+)\s+kB/m.exec(text);
  const a = /^MemAvailable:\s+(\d+)\s+kB/m.exec(text);
  return t && a ? { total: Number(t[1]) * 1024, avail: Number(a[1]) * 1024 } : null;
}

/** One /proc/<pid>/stat line: ppid, processor ticks, resident pages (the command may hold spaces and brackets). */
export function parseStatLine(stat: string): { ppid: number; ticks: number; rssPages: number } | null {
  const rest = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
  const ppid = Number(rest[1]);
  const ticks = Number(rest[11]) + Number(rest[12]);
  const rssPages = Number(rest[21]);
  return [ppid, ticks, rssPages].every(Number.isFinite) ? { ppid, ticks, rssPages: Math.max(0, rssPages) } : null;
}

export type ProcFs = {
  readFile: (path: string) => string;
  readdir: (path: string) => string[];
};
const realFs: ProcFs = { readFile: (p) => readFileSync(p, 'utf8'), readdir: (p) => readdirSync(p) };
const TICK_MS = 10; // USER_HZ is 100 on every Linux

/** Every process on Linux; argv only for the agent's own descendants (the only ones that matter). */
export function linuxProcs(agentPid: number, fs: ProcFs = realFs): ProcEntry[] {
  const rows: ProcEntry[] = [];
  let names: string[] = [];
  try {
    names = fs.readdir('/proc');
  } catch {
    return rows;
  }
  for (const name of names) {
    if (!/^\d+$/.test(name)) continue;
    try {
      const st = parseStatLine(fs.readFile(`/proc/${name}/stat`));
      if (st) rows.push({ pid: Number(name), ppid: st.ppid, cpuMs: st.ticks * TICK_MS, rss: st.rssPages * 4096, argv: [] });
    } catch {
      // ended while we looked
    }
  }
  for (const p of treeOf(rows, agentPid)) {
    try {
      p.argv = fs.readFile(`/proc/${p.pid}/cmdline`).split('\0').filter(Boolean);
    } catch {
      // gone
    }
  }
  return rows;
}

/** macOS: ps. No processor time per process, so our own share is not told there. */
async function macProcs(agentPid: number): Promise<ProcEntry[]> {
  const out = await execText('ps', ['-axo', 'pid=,ppid=,rss=,command='], 5000);
  if (!out) return [];
  const rows: ProcEntry[] = [];
  for (const line of out.split('\n')) {
    const m = /^\s*(\d+)\s+(\d+)\s+(\d+)\s+(.*)$/.exec(line);
    if (m) rows.push({ pid: Number(m[1]), ppid: Number(m[2]), cpuMs: null, rss: Number(m[3]) * 1024, argv: m[4].split(' ') });
  }
  void agentPid;
  return rows;
}

/**
 * The real sampler. Linux: /proc/stat, /proc/meminfo, the pressure files and every process. macOS: input idle time and processes
 * only. Windows: input idle time only (nothing is stopped there; see Actions). A machine without /proc gets what it has.
 */
export function makeSampler(o: { agentPid?: number; fs?: ProcFs; idle?: () => Promise<number | null>; now?: () => number; plat?: NodeJS.Platform } = {}): () => Promise<UfSample> {
  const agentPid = o.agentPid ?? process.pid;
  const fs = o.fs ?? realFs;
  const idle = o.idle ?? makeIdleReader();
  const now = o.now ?? Date.now;
  const plat = o.plat ?? platform();
  let prev: { busy: number; total: number; ours: number } | null = null;
  return async () => {
    const idleMs = await idle().catch(() => null);
    const at = now();
    let procs: ProcEntry[] = [];
    let otherCpuPct: number | null = null;
    let ourCpuPct: number | null = null;
    let usedMemPct: number | null = null;
    let ourMemShare: number | null = null;
    let psiMem: number | null = null;
    let psiCpu: number | null = null;
    if (plat === 'linux') {
      procs = linuxProcs(agentPid, fs);
      const ours = [{ cpuMs: procs.find((p) => p.pid === agentPid)?.cpuMs ?? 0, rss: procs.find((p) => p.pid === agentPid)?.rss ?? 0 }, ...treeOf(procs, agentPid)];
      const ourTicks = ours.reduce((n, p) => n + (p.cpuMs ?? 0) / TICK_MS, 0);
      const ourRss = ours.reduce((n, p) => n + p.rss, 0);
      let cur: { busy: number; total: number } | null = null;
      try {
        cur = parseProcStatCpu(fs.readFile('/proc/stat'));
      } catch {
        // no /proc/stat
      }
      if (cur) {
        if (prev && cur.total > prev.total) {
          const dTotal = cur.total - prev.total;
          const dOurs = Math.max(0, ourTicks - prev.ours);
          otherCpuPct = Math.max(0, Math.min(100, ((cur.busy - prev.busy - dOurs) / dTotal) * 100));
          ourCpuPct = Math.max(0, Math.min(100, (dOurs / dTotal) * 100));
        }
        prev = { ...cur, ours: ourTicks };
      }
      try {
        const m = parseMeminfo(fs.readFile('/proc/meminfo'));
        if (m && m.total > 0) {
          usedMemPct = ((m.total - m.avail) / m.total) * 100;
          ourMemShare = m.total - m.avail > 0 ? Math.min(1, ourRss / (m.total - m.avail)) : 0;
        }
      } catch {
        // no meminfo
      }
      try {
        psiMem = parsePsi(fs.readFile('/proc/pressure/memory'));
        psiCpu = parsePsi(fs.readFile('/proc/pressure/cpu'));
      } catch {
        // kernel without pressure files
      }
    } else if (plat === 'darwin') {
      procs = await macProcs(agentPid);
    } else if (plat === 'win32') {
      usedMemPct = (1 - freemem() / totalmem()) * 100;
    }
    return { at, idleMs, otherCpuPct, usedMemPct, ourMemShare, psiMem, psiCpu, ourCpuPct, procs };
  };
}

/** Lowest priority and idle disk priority; the signals. Windows: priority only (nothing is stopped there). */
export function realActions(plat: NodeJS.Platform = platform()): Actions {
  return {
    kill: (pid, signal) => {
      if (plat === 'win32') return; // no SIGSTOP on Windows
      process.kill(pid, signal);
    },
    nice: (pid) => {
      if (plat === 'linux') {
        let tids: number[] = [];
        try {
          tids = readdirSync(`/proc/${pid}/task`).map(Number).filter((n) => Number.isInteger(n) && n > 0);
        } catch {
          // gone
        }
        for (const tid of tids.length ? tids : [pid]) {
          try {
            setPriority(tid, 19);
          } catch {
            // one thread may have just ended
          }
        }
        return;
      }
      setPriority(pid, 19);
    },
    ioIdle: (pid, on) => {
      if (plat !== 'linux') return;
      void execText('ionice', on ? ['-c', '3', '-p', String(pid)] : ['-c', '2', '-n', '4', '-p', String(pid)], 2000);
    },
  };
}

// ---------- the setting, kept on this computer ----------

export function loadGiveWay(file: string): GiveWayMode | null {
  try {
    return parseGiveWay((JSON.parse(readFileSync(file, 'utf8')) as { giveWay?: unknown }).giveWay);
  } catch {
    return null;
  }
}

export function saveGiveWay(file: string, mode: GiveWayMode): void {
  mkdirSync(dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  writeFileSync(tmp, JSON.stringify({ giveWay: mode }), { mode: 0o600 });
  renameSync(tmp, file);
}

export function fileStore(file: string): { load: () => StoppedRecord[]; save: (r: StoppedRecord[]) => void } {
  return {
    load: () => {
      try {
        const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
        return Array.isArray(j) ? j.filter((r): r is StoppedRecord => !!r && typeof (r as StoppedRecord).pid === 'number') : [];
      } catch {
        return [];
      }
    },
    save: (r) => {
      try {
        mkdirSync(dirname(file), { recursive: true });
        const tmp = `${file}.tmp`;
        writeFileSync(tmp, JSON.stringify(r), { mode: 0o600 });
        renameSync(tmp, file);
      } catch {
        // best effort
      }
    },
  };
}

