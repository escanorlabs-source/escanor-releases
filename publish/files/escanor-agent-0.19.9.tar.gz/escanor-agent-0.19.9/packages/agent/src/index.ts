import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync, unlinkSync } from 'node:fs';
import { homedir, hostname } from 'node:os';
import { join } from 'node:path';
import type { AgentToHubMessage, HubToAgentMessage, LocalAiReport } from '@remote-harness/shared';
import { DEVICE_COMMAND_CAPABILITY, MACHINE_CHECKS_CAPABILITY, OWN_JOB_CAPABILITY, PHONE_COMMAND_CAPABILITY, SCREEN_STREAM_CAPABILITY } from '@remote-harness/shared';

import { ensurePrivate } from './envPerms.js';
import { childTmpDir } from './childEnv.js';
import { startChildTmpSweep } from './childTmpSweep.js';

// Embedded in Escanor Desktop (embed.ts) the settings come from the host; an .env that happens to sit in the working folder is not read.
if (process.env.ESCANOR_EMBEDDED !== '1' && existsSync('.env')) {
  ensurePrivate('.env');
  process.loadEnvFile('.env');
}

const { config } = await import('./config.js');
// A personal computer (Escanor Desktop's agent) always has the safety layer, the risky-command holds and the key protections on:
// nothing in the environment (or a setting) can turn them off there (personalGuard.ts).
if (config.machineKind === 'personal') {
  const { personalEnvOverrides } = await import('./personalGuard.js');
  Object.assign(process.env, personalEnvOverrides());
}
const { SessionManager } = await import('./sessionManager.js');
const { HubConnection } = await import('./wsClient.js');
const { discoverProfiles, providerForAccount, setDefaultLoginDir, toAccount } = await import('./profiles.js');
const { AccountWatch, WATCH_MS } = await import('./accountWatch.js');
const { legacyMachineIds, stableMachineId } = await import('./machineId.js');
// The older ids of this computer, worked out once: the name-based id agents gave before (only when this agent's id is the system one), and,
// for the background service, the Escanor Desktop install id found on disk. The hub merges rows under those ids into this one.
const helloLegacyIds = legacyMachineIds(process.env, {
  current: config.machineId,
  ...(config.machineId && config.machineId === stableMachineId() ? { machine: {} } : {}),
  desktop: config.embedded ? false : {},
});
const { AccountLogin, ACCOUNT_CAPABILITIES, accountLoginEnabled } = await import('./accountLogin.js');
const { listProjects } = await import('./projects.js');
const { isBroadRoot } = await import('./paths.js');
const { TerminalSessionSync } = await import('./terminalSessions.js');
const { readClaudeProcs } = await import('./claudeProcs.js');
const { TerminalInbox, installPhoneHooks } = await import('./terminalInbox.js');
const { SmallSessionCleaner } = await import('./smallSessions.js');
const { ResourceGuard, cleanOwnLeftovers } = await import('./resourceGuard.js');
const { UserFirst, makeSampler, realActions, fileStore, loadGiveWay, saveGiveWay, parseGiveWay, giveWayText } = await import('./userFirst.js');
const { fileLimitStore, limitStatusText } = await import('./aiLimits.js');
const { procStartOf, pidAlive } = await import('./claudeProcs.js');
const { helloCapabilities } = await import('./chatUser.js');
const { KeepAwake, systemPlatform } = await import('./keepAwake.js');
const { detectMachine, macAddresses, suspendCommand, magicPacket, broadcastAddresses } = await import('./machineInfo.js');
const { registerRuntime, publishLinkStatus, requestHostUpdate } = await import('./embedRuntime.js');
const { setHubToken } = await import('./config.js');
const { createSocket } = await import('node:dgram');
const { execFile: execDetached } = await import('node:child_process');
const { ResumeDetector } = await import('./resume.js');
const { computerControlOn } = await import('./computerControl.js');
const { Jarvis, RemoteSwitch, jarvisFiles, TYPE_ENV } = await import('./jarvis.js');
const { FocusHelper } = await import('./focusHelper.js');
const { BackendTrust } = await import('./accountTrust.js');
const { wakeRoutes, WakeSchedule, setWakeAlarm } = await import('./wakeRoutes.js');
const { QuietNotifications } = await import('./meetingPrep.js');
const { KeyStore } = await import('./jarvisKeys.js');
const { FilePolicy } = await import('./accessPolicy.js');
const { notice: screenNotice } = await import('./screenControl.js');
const { keyringCredential, vaultCredential, typeText, canType } = await import('./siteCredentials.js');
const { PresenceWatcher, meshCaps } = await import('./presence.js');
const { makeIdleReader } = await import('./userFirst.js');
const { screenLocked } = await import('./liveControl.js');
const { hasDesktop } = await import('./computerControl.js');
const { logSafety } = await import('./safetyLog.js');
const { defaultUndoRoot } = await import('./undo.js');
const { readHighlight, HIGHLIGHT_NAME } = await import('./screenHelp.js');
const { K8sSecrets, realExec: kubectlExec, fileDigestKey } = await import('./k8sSecrets.js');
const { deviceKey: vaultDeviceKey, resolveSecrets: vaultResolve } = await import('./machineApi.js');
const { machineSecretsEnabled } = await import('./machineSecrets.js');
const { SigninStore, SigninAudit, CredentialBroker } = await import('./signinBroker.js');
const { RealExec } = await import('./brokerExec.js');
const { LoginRecovery } = await import('./loginRecovery.js');
const { SigninControl } = await import('./signinControl.js');
const { SessionHelper } = await import('./sessionHelper.js');
const { WakeApprovals } = await import('./wakeApproval.js');
const { DeviceMcpClient, deviceMcpApiUrl, escanorApiUrl } = await import('./deviceMcp.js');
const { MachinePermissions, PERMISSION_MODES } = await import('./machinePermissions.js');
const { askResume } = await import('./resumeCheck.js');
const { ActivityReporter } = await import('./activity.js');
const { SubagentTracker } = await import('./subagents.js');
const { MachineStateReporter } = await import('./machineState.js');
const { AccountUsagePoller, accountUsageEnabled } = await import('./accountUsage.js');
const { WorkspaceAccounts, sharedApiUrl } = await import('./workspaceAccounts.js');
const { GhAccounts, ghAccountsApiUrl } = await import('./ghAccounts.js');
const { ClaudeSetupSync, claudeSetupApiUrl, extraProfiles } = await import('./claudeSetup.js');
const { FixTasks } = await import('./fixTests.js');
const { SeenInputs, routeHubInput } = await import('./seenInputs.js');
const { PreviewOpener, PREVIEW_CAPABILITY, PREVIEW_LINK_CAPABILITY, previewCard, reportPreviewOpen } = await import('./previewOpen.js');
const { PreviewRelay } = await import('./previewRelay.js');
const { switchOn } = await import('./switches.js');
const { riskHoldsOn } = await import('./riskHold.js');
const { verifyOn } = await import('./verifyDone.js');
const { startSafety } = await import('./safetyRuntime.js');
const { LocalAiReporter } = await import('./localAi/reporter.js');
const { ClaudeModels } = await import('./localAi/claudeModels.js');
const { OwnComputer, holdLine } = await import('./localAi/ownAi.js');
const { LocalAsker } = await import('./localAi/run.js');
const { SideAsk, parseAsk } = await import('./sideAsk.js');
const { CloudClient } = await import('./localAi/cloudClient.js');
const { discoverLocalAi, probeRuntimes, refreshLogins } = await import('./localAi/discover.js');
const { TerminalResume } = await import('./terminalResume.js');
const { TurnState } = await import('./turnState.js');
const { LeakReporter, scrubOn, scrubOutgoing } = await import('./keyLeaks.js');

// The version lives in package.json (0.3.0 is the first release that installs hub-managed MCP servers, see MIN_MCP_AGENT_VERSION;
// 0.4.0 the first that takes a per-machine MCP entry; 0.5.0 the first that honours `autoAllowTools`; 0.6.0 the first that honours
// `isolated`; 0.6.1 the first that runs chats as their own users and reports its boot; 0.6.2 the first whose chat users share
// nothing, load no filesystem settings, get the MCP configuration on a pipe, run with no_new_privs, and that sends the heartbeat
// the hosted hub checks, see MIN_ISOLATED_AGENT_VERSION; 0.7.0 the first that asks Escanor for its own MCP key, deviceMcp.ts; 0.8.0 the first that continues the open chat in a folder; 0.8.1 marks Queued/limit lines as notices and sends each chat a stats line (escanor_stats);
// 0.9.0 the first that sends session_activity steps, input_ack / permission_ack, hello.pending, machine_state, outbox ids (mid) from
// an outbox kept on disk, and its own escanor_tests rows for fixes on this computer; 0.9.1 the first that hands a message for a chat
// open in a terminal here to that terminal chat (terminalInbox.ts); 0.9.2 the first that deletes its used-up small chats
// (session_deleted, smallSessions.ts); 0.9.3 the first that runs a message the hub sends again (same inputId) only once and
// answers the repeat with the same input_ack (seenInputs.ts); 0.9.4 the first whose phone-inbox hook skips its own SDK chats
// (ESCANOR_AGENT_CHAT) and any stream-json or -p Claude, which it used to hold up at SessionStart (terminalInbox.ts)
// 0.9.5 the first that waits 20 s before picking a cut-off fix up after a restart and skips one stopped meanwhile (FLOW4)
// 0.9.6 the first that asks Escanor whether a cut-off fix or kept run is still wanted before picking it up, and says it waits when there is no answer (AGRESUME)
// 0.9.7 the first that keeps its queue on disk (data/queue.json), reports it (queue_state) and takes queue_cancel / queue_edit /
// queue_move / queue_start_now from the apps (QUEUEUI, MIN_QUEUE_AGENT_VERSION)
// 0.9.11 the first that carries a cut-off chat on by itself: after Claude's usage limit resets, and once the computer is back
// online after it was turned off, restarted, crashed or slept mid-turn (AUTORESUME, autoResume.ts; AUTO_RESUME=0 turns it off)
// 0.9.12 the same for chats open in a terminal here (terminalResume.ts: "continue" into that terminal after the limit resets or the
// AI service failed; a terminal chat busy when the computer went off goes on as an agent chat), and retries after the AI service
// failed (server error, overloaded) 1, 5 and 15 minutes later
// 0.9.14 the hello says what kind of machine this is (laptop, server, VM and which cloud: machineInfo.ts), and the hub can ask it to
// sleep or to send a wake-up to another machine on its network (power_command)
// 0.9.16: the push check also runs in every ChatGPT and Gemini mode (cliGuard.ts PUSH_SCAN_ENV); Django/Rails secret keys; jwt.io samples are not keys.
// 0.15.0 device mesh (presence.ts, handoffReceive.ts): machine_state carries presence (input idle time, lock) and deviceCaps; direct commands `receive` (a link, text or small file another device of the owner sent) and `presence`
// 0.13.0 Jarvis phase 2 (jarvis.ts): direct commands from the owner's phone with no AI turn (open, show full screen, wake and keep awake, unlock, sign in, live view); fingerprint yes for the ones that let someone in; per-computer Remote control switch; capability device_command; docs/JARVIS.md
// 0.14.0 Live control (liveControl.ts): the phone taps, scrolls and types on a live picture of the screen; the view's fingerprint unlocks a locked screen first; the AI gets screen_look/click/type/keys/scroll/drag tools while Remote control is on; docs/JARVIS.md
// 0.14.1 Unlock at the login screen after a restart says why and points to scripts/remote-unlock-setup.sh (sign in by itself, then lock); hook timeout covers held emails when only computer tools are on
// 0.16.0 Nothing unlocks, signs in, uses a saved secret or wakes a computer without a fingerprint on the phone for that very request (signinApproval.ts, signinBroker.ts proof, sessionHelper.ts login-screen sign-in through the root helper that Escanor installs, wakeApproval.ts, schedule_wake asks); status.unlock for the phone's Unlock / Turn on; docs/UNLOCK.md
// 0.15.0 Jarvis phase 3: GNOME focus helper extension (focusHelper.ts) for reliable focus and full screen; the account checks fingerprint yeses and holds the owner's access policy (accountTrust.ts, backend jarvis_policy.py); type_login into the approved browser window with a settings switch; wake routes and schedule_wake (wakeRoutes.ts); docs/JARVIS.md
// 0.19.5 accounts added, removed or signed in on this computer show in every app without a restart (accountWatch.ts: the profiles folder is looked at every 30 s, announced when changed and every 15 min), and the machine's own ~/.claude login is listed too when it is signed in; account usage is read one account at a time, waits out a 429, keeps the last good figure (marked stale, with its age) and flags in_use and outside_use
// 0.19.0 workspace AI accounts (workspaceAccounts.ts): sign in to an account once, every machine of the workspace uses it; the backend alone renews the login, the agent pulls a short-lived token with no refresh token and re-pulls before it ends; account_command share; capability account_workspace
// (next release) workspace GitHub accounts (ghAccounts.ts): gh signed in once is written into gh's hosts.yml on every machine of the workspace (default account active, git uses gh), a machine's own sign-ins are kept, removed ones stop being written
// (next release) Kubernetes Secrets (k8sSecrets.ts): list Secret names, set or remove one key, put the old one back, through this computer's own kubectl; the value comes from the Escanor vault and goes to kubectl on its standard input
// (next release) `clipboard {viewId, op: read|clear}` inside an approved live view (clipboardControl.ts): lets Escanor save a key it just had you create, without the key reaching a chat, a model or the safety log
// 0.12.9 "Send as priority" (user_input.priority): a message that has to wait goes to the front of the queue (behind earlier priority ones); queue items carry priority: true
// 0.12.8 /ask <question> in a chat: a quick side question, answered at once by this computer's quick AI, never queued and never waiting for the chat (sideAsk.ts)
// 0.12.9 the person comes first (userFirst.ts): while someone uses this computer (input idle time) or other programs are busy, our chats drop to the lowest priority, nothing new starts, and when other programs need the processor or memory our chat processes are paused and go on by themselves; setting "Give way to me" (on / gentle / off) from the phone. An AI account that hits its limit (or is at 98% of it) holds ALL its work until the reset time (aiLimits.ts), kept on disk, and starts again by itself then
// 0.18.0 GitHub Copilot (Copilot CLI) accounts and chats (cliEngine.ts CopilotTurn, accountLogin.ts device / token sign-in, the
// account_provider_copilot capability), its guard hook (cliGuard.ts installCopilotGuard) and its models in the local AI report
// 0.17.0 the router can use this computer's own AI (localAi/ownAi.ts): the report says, per tool, if it is allowed, its plan, its room left and whether
// the computer is idle, busy or locked; a job from the router (local_ask with fromRouter) runs on exactly the tool it names or is refused in one line
// (busy, locked, off, signed out, at its limit); one switch per tool (ESCANOR_OWN_AI_<TOOL>=0), ESCANOR_OWN_AI_JOBS=0 refuses all jobs from outside
// 0.12.10 an Autonomous (or Bypass) chat never waits for an Approve: a step that cannot be undone is not run, nobody is asked, the chat shows "Left for you: ..." and the AI carries on with the rest (riskHold.ts neverAsks)
// 0.12.7 the person wins over our work (resourceGuard.ts): our Claude processes run at low priority, over the memory/CPU limits new work waits in the queue (queue item `busy`) and idle chats are put away, then it goes on by itself; start now with no room puts the chat first in line; the agent clears its own stale temp files
// 0.12.6 the battery (macOS and Windows too, battery.ts) rides in machine_state.health; a plug-in or low-battery change is sent at once, so the phone can say "plug in"
// 0.12.4 permission requests carry a plain-words summary (shared/describe.ts); set_priority: a Priority chat's waiting work goes
// first and, when every slot is held by chats that are not Priority, it takes one slot above the cap (sessionManager.ts)
// 0.12.3 a command that runs a script which deletes (make clean, npm run, sh/python/node file) is held when it deletes outside the project or somewhere unclear (shared/scriptRisk.ts)
// 0.12.2 personal computers hold more (personalGuard.ts): credential stores, files outside home, folder deletes, system changes; always on there
// 0.12.1 a question may fall back to the cloud (cloud_ask / cloud_answer through the hub, the owner's own key), only when the request allows it
// 0.12.0 local_ask: the hub puts a question to this computer's own AI (localAi/run.ts; ESCANOR_LOCAL_ASK=0 turns it off)
// 0.11.1 session_activity may carry `background` (helpers, commands, wakeAt) with a step starting BACKGROUND_STEP; a chat with background work
// is never closed to make room; terminal chats left with background work send background_tasks_changed instead of ending (background.ts).
// 0.11.0 the hello (and a local_ai message every 10 minutes / on change) says what AI this computer can use: AI command-line tools and whether
// they are signed in, Ollama / LM Studio / llama.cpp, and the hardware (localAi/discover.ts; ESCANOR_LOCAL_AI=0 turns it off)
// 0.9.17: runs inside Escanor Desktop on a personal computer (embed.ts: settings and health over JSON lines, machine kind `personal`, machineId in the hello); Windows fixes (paths, PATHEXT, cmd.exe for test runs).
// 0.9.15 keys stay private (F2): a chat's git push that adds a key, or a gh pull request/comment whose words hold one, is refused
// (pushScan.ts); key-shaped strings are hidden in every chat message relayed off this machine (keyLeaks.ts, CHAT_KEY_SCRUB=0 off);
// fingerprints of what was found go to POST /machines/leak-report (never a key)
// 0.10.0 the safety layer (safetyRuntime.ts): undo copies before deletes, never-delete blocks, the guard in every Claude settings file,
// the tripwire, safety_get / safety_action / safety_alert and the `safety` hello capability; risky-command holds on by default
// 0.9.13 the first whose ChatGPT sign-in can switch to Codex's normal browser sign-in (account_chatgpt_browser), so nobody has to
// turn on "device code sign-in" in ChatGPT's settings first (accountLogin.ts)
// 0.9.10 the first that adds ChatGPT (Codex CLI) and Gemini (Gemini CLI) accounts and runs their chats (cliEngine.ts), with the
// Autonomous blocklist in those tools' own hooks and policy (cliGuard.ts); hello lists account_provider_chatgpt / _gemini
// when a new one is asked for, caps open and running chats, holds work at Claude's usage limit and compacts long chats,
// chatPolicy.ts), so it cannot drift from the release.
const AGENT_VERSION: string = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf-8')).version;

// AGENT-INDEP D (handover.ts): a new version started alongside the running one waits here until the old one is idle, then takes over the
// hub connection; the old one stops by itself. Nothing below this line starts until this process may serve.
const { Handover } = await import('./handover.js');
const handover = !config.embedded && !config.managed && switchOn(process.env.ESCANOR_HANDOVER, true)
  ? new Handover({ file: join(config.dataDir, 'agent-lease.json'), version: AGENT_VERSION, log: (line) => console.log(line) })
  : null;
const handoverTurn = handover ? await handover.waitForTurn() : 'free';

if (isBroadRoot(config.workspaceRoot, process.env.HOME || process.env.USERPROFILE || homedir())) {
  console.warn(
    `WARNING: WORKSPACE_ROOT is ${config.workspaceRoot}, which contains ~/.ssh, shell rc files and this agent's own .env. ` +
      'Point WORKSPACE_ROOT at a projects directory instead.',
  );
}

// Every Claude account signed in on this computer is listed: the profile folders, plus the machine's own login (~/.claude) when it is signed in (ESCANOR_SHOW_DEFAULT_LOGIN=0 turns that off).
if (process.env.ESCANOR_SHOW_DEFAULT_LOGIN !== '0') setDefaultLoginDir(process.env.CLAUDE_CONFIG_DIR || join(homedir(), '.claude'));
const profiles = discoverProfiles(config.profilesDir);
console.log(`Accounts: ${profiles.map((p) => p.id).join(', ')}`);

function readGuide(): string {
  if (!config.guideFile) return '';
  try {
    return readFileSync(config.guideFile, 'utf8').slice(0, 20_000);
  } catch {
    console.warn(`Could not read ESCANOR_GUIDE_FILE (${config.guideFile}); continuing without it.`);
    return '';
  }
}

// Everything the agent sends goes out here, and is also read for what it says about each chat (activity.ts), what runs on this
// machine (machineState.ts) and fixes on this computer (fixTests.ts).
const chatScrub = scrubOn(process.env);
let leakReporter: InstanceType<typeof LeakReporter> | null = null;
const leakSink = { report: (...a: Parameters<InstanceType<typeof LeakReporter>['report']>) => leakReporter?.report(...a) };
// F2 (keyLeaks.ts): a chat's words leave this machine with anything shaped like a key hidden; what was hidden is reported to
// Escanor as fingerprints (never the key), so the owner hears once when it is one of the workspace's stored keys.
const out = (raw: AgentToHubMessage, watch = true): void => {
  let msg = raw;
  if (chatScrub) {
    try {
      const r = scrubOutgoing(raw);
      msg = r.msg;
      if (r.found.length && raw.type !== 'sdk_partial') leakSink.report(r.found, () => `a chat on ${config.vmName}`, 'chat');
    } catch (err) {
      console.error('Chat key scrub failed', err instanceof Error ? err.message : 'error');
    }
  }
  connection.send(msg);
  if (!watch) return;
  for (const watcher of watchers) {
    try {
      watcher(msg);
    } catch (err) {
      console.error('Message watcher failed', err);
    }
  }
};
const watchers: Array<(msg: AgentToHubMessage) => void> = [];
// The safety layer (safetyRuntime.ts): undo copies before deletes, never-delete blocks, the guard in every Claude settings file
// on this computer, and the mass-delete tripwire. On unless ESCANOR_SAFETY=0.
const safety = startSafety({
  send: (msg) => out(msg),
  configDirs: () => profiles.map((p) => p.configDir).filter((d): d is string => !!d),
  managed: config.managed,
  chatUsers: !!config.chatUsers,
});
// The person using this computer wins over our work (resourceGuard.ts): limits from the environment, ESCANOR_RESOURCE_GUARD=0 turns it off.
const resourceGuard = new ResourceGuard(config.resourceGuard);
// JARVIS1 (computerControl.ts): chats can open pages and apps, play YouTube, press media keys, change the volume and lock the screen
// here. On where there is a desktop (never in an Escanor worker); ESCANOR_COMPUTER_CONTROL=0 turns it off.
const computerControl = computerControlOn(process.env, { managed: config.managed });
// The person comes first (userFirst.ts): their setting (kept here) wins over the environment's starting mode; a worker container has no person.
const settingsFile = join(config.dataDir, 'machine-settings.json');
const userFirst = new UserFirst(
  config.userFirst.limits,
  {
    sampler: makeSampler(),
    actions: realActions(),
    // A chat the person drives in a terminal of this computer is the person: never held (only chats this agent runs are ours).
    exempt: () => {
      const mine = manager.liveIds();
      const pids = new Set<number>();
      for (const [id, p] of readClaudeProcs()) if (!mine.has(id)) pids.add(p.pid);
      return pids;
    },
    store: fileStore(join(config.dataDir, 'userfirst-stopped.json')),
    startOf: (pid) => procStartOf(pid),
    alive: pidAlive,
  },
  loadGiveWay(settingsFile) ?? (config.managed ? 'off' : config.userFirst.mode),
);
const { profileConfigDir: profileConfigDirFn } = await import('./accountUsage.js');
// A chat never stops at "Please run /login" while another Claude account here is signed in (signedIn.ts).
const signIn = new (await import('./signedIn.js')).SignInState({ dirOf: (p) => profileConfigDirFn(p) });
const manager = new SessionManager(config.workspaceRoot, config.dataDir, profiles, out, { signIn, userFirst, limitStore: fileLimitStore(join(config.dataDir, 'ai-limits.json')), safety: safety?.agent, leaks: leakSink, managed: config.managed, defaultMode: config.defaultMode, guide: readGuide(), mcpOverride: config.mcpOverride, protectedPaths: config.protectedPaths, fetchAllow: config.fetchAllow, chatUsers: config.chatUsers, limits: config.chatLimits, guard: resourceGuard, autoResume: switchOn(process.env.AUTO_RESUME, true), riskHolds: riskHoldsOn(process.env), credentialGrant: () => signin.chatWindow.active(), personal: config.machineKind === 'personal', verifyDone: verifyOn(process.env), computerControl, meshTools: !config.managed && switchOn(process.env.ESCANOR_MESH, true) });

// AGIN: a message from the apps the hub sends again (its first copy never confirmed) runs once; the repeat is confirmed again.
// QUEUEUI: the messages still waiting in the saved queue count as seen (queued), so the hub's copy never runs them a second time.
const seenInputs = new SeenInputs({ file: join(config.dataDir, 'seen-inputs.json') });
seenInputs.keepQueued(manager.queuedInputs());
watchers.push((msg) => seenInputs.observe(msg));

// This machine's own Escanor MCP key, asked for on every hub connect (deviceMcp.ts): nobody copies a key anywhere.
const deviceApi = deviceMcpApiUrl(process.env, config.hubUrl, { managed: config.managed, override: config.mcpOverride !== null });
const deviceMcp = deviceApi
  ? new DeviceMcpClient({
      apiUrl: deviceApi,
      get hubToken() {
        return config.hubToken;
      },
      vmName: config.vmName,
      agentVersion: AGENT_VERSION,
      apply: (entry, block) => manager.setDeviceMcp(entry, block ? { block } : {}),
    })
  : null;

// Jarvis phase 4 (screenHelp.ts): a chat's screen_help tool asks the agent, over an owner-only socket, to put one picture of the screen
// to a vision model on Escanor's server. The hub token stays here; the chat never holds it.
const screenHelpServer = computerControl
  ? (await import('./screenHelp.js')).serveScreenHelp(join(config.dataDir, 'screen-help.sock'), async (ask) =>
      (await import('./screenHelp.js')).askBackend({ apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION }, ask),
    )
  : null;

// Jarvis phase 5 (phoneAsk.ts): a chat's `phone` tool asks the agent, over an owner-only socket, to put one request (ring, battery, a
// link) through the hub to the owner's phone. The hub token stays here, and the hub checks the action against a fixed list.
const { PhoneRequests, servePhoneAsk, PHONE_SOCKET_NAME } = await import('./phoneAsk.js');
const phoneRequests = new PhoneRequests((m) => connection.send(m), () => randomUUID());
// Mesh (meshAsk.ts): a chat's `devices` tool (a headless server's too) lists the owner's other devices and hands them work through the
// backend, signed in with this machine's hub token; the backend's safety check decides every change. ESCANOR_MESH=0 turns it off.
const { serveMeshAsk, meshRequest, MESH_SOCKET_NAME } = await import('./meshAsk.js');
const meshConn = { apiUrl: deviceApi ?? '', get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION };
const meshAsk = (req: Parameters<typeof meshRequest>[1], caller = ''): ReturnType<typeof meshRequest> => {
  // "Continue this chat on my laptop": the chat's own id is looked up here, now, by the key its tool sent (a new chat has no id until it starts).
  if (req.op === 'handoff' && req.kind === 'chat' && !req.payload.session_id) {
    const sid = manager.callerSessionId(caller);
    if (!sid) return Promise.resolve({ ok: false, say: 'I could not tell which chat this is yet. Send one more message in it and try again.' });
    req = { ...req, payload: { ...req.payload, session_id: sid } };
  }
  return meshAskBackend(req);
};
const meshAskBackend = (req: Parameters<typeof meshRequest>[1]) =>
  deviceApi ? meshRequest(meshConn, req) : Promise.resolve({ ok: false, say: 'This computer is not connected to Escanor, so it cannot reach your other devices.' });
const meshServer = deviceApi && !config.managed && switchOn(process.env.ESCANOR_MESH, true) ? serveMeshAsk(join(config.dataDir, MESH_SOCKET_NAME), meshAsk) : null;
const phoneServer = computerControl ? servePhoneAsk(join(config.dataDir, PHONE_SOCKET_NAME), (a) => phoneRequests.ask(a)) : null;

if (deviceApi) {
  leakReporter = new LeakReporter({
    conn: { apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION },
    log: (line) => console.warn(line),
  });
}

// Claude Code sessions run in a terminal here show up in the app too.
const terminalSync = config.syncTerminalSessions
  ? new TerminalSessionSync({
      workspaceRoot: config.terminalSyncRoot,
      registry: manager.sessionRegistry,
      // A terminal chat's transcript lines say what it is doing only while it is busy there: the backfill of a finished chat
      // is history (no step, no "last test"), and transcript lines carry no time to tell.
      send: (msg) => out(msg, msg.type !== 'sdk_message' || terminalSync!.isBusy(msg.sessionId)),
      isLive: (id) => manager.isLive(id),
      // Terminal chats are Claude Code's: tagged with the machine's first Claude account.
      accountId: () => profiles.find((p) => (p.provider ?? 'claude') === 'claude')?.id ?? 'default',
      isClaudeChat: (e) => providerForAccount(profiles, e.accountId) === 'claude',
      ...(config.cleanSmallSessions ? { smallKeepMs: config.smallSessionKeepMs } : {}),
    })
  : null;
// Small chats this machine opened for itself (automation runs nobody typed in, terminal sessions with no reply) are deleted
// from the app and from here once used up.
const smallChats = config.cleanSmallSessions
  ? new SmallSessionCleaner({
      registry: manager.sessionRegistry,
      send: out,
      isLive: (id) => manager.isLive(id),
      isOpen: (id) => readClaudeProcs().has(id),
      isClaudeChat: (e) => providerForAccount(profiles, e.accountId) === 'claude',
      keepMs: config.smallSessionKeepMs,
    })
  : null;
// A chat still open in a terminal here (Claude Code's own record of its process) is never resumed a second time by the agent.
manager.isOpenElsewhere = (id) => readClaudeProcs().has(id);
if (terminalSync) {
  manager.onTurnEnded = (id, cwd) => void terminalSync.markSynced(id, cwd);
  manager.isRunningElsewhere = (id) => terminalSync.isBusy(id);
}
// A message from the app for a chat open in a terminal here goes into that same terminal chat: phone and PC are one chat.
const phoneToTerminal = config.syncTerminalSessions && config.phoneToTerminal;
const inboxDir = join(config.dataDir, 'terminal-inbox');
try {
  // Embedded in Escanor Desktop: ~/.claude/settings.json is left alone unless the host asked for the phone-to-terminal hooks (an agent
  // installed the normal way on the same computer owns them, and removing them here would undo its work).
  if (config.embedded && !phoneToTerminal) console.log('Phone → terminal: off (embedded)');
  else console.log(`Phone → terminal: ${installPhoneHooks({ dataDir: config.dataDir, inboxDir, enabled: phoneToTerminal })}`);
} catch (err) {
  console.error(`Phone → terminal: could not set the hooks (${err instanceof Error ? err.message : err})`);
}
const terminalInbox = phoneToTerminal
  ? new TerminalInbox({ dir: inboxDir, send: (msg) => out(msg), procs: () => readClaudeProcs(), readmit: (input) => manager.handleUserInput(input) })
  : null;
if (terminalInbox) {
  terminalInbox.sweep();
  setInterval(() => terminalInbox.sweep(), 3_600_000).unref(); // every Claude here gets a small inbox folder; drop closed ones
  manager.deliverToTerminal = (input) => terminalInbox.deliver(input);
}

// AUTORESUME for chats open in a terminal here (terminalResume.ts); off with AUTO_RESUME=0 like the rest of it.
const terminalResume = switchOn(process.env.AUTO_RESUME, true)
  ? new TerminalResume({
      procs: () => readClaudeProcs(),
      isLive: (id) => manager.isLive(id),
      canReach: (id) => terminalInbox?.canReach(id) ?? false,
      deliver: (input) => terminalInbox?.deliver(input) ?? false,
      tail: (() => {
        const turns = new TurnState();
        return (id: string, cwd: string | undefined) => turns.tail(id, cwd);
      })(),
      isOnline: () => connection.connected,
      send: (msg) => out(msg),
      markOffline: (id) => manager.markOffline(id),
      file: join(config.dataDir, 'terminal-resume.json'),
    })
  : null;
const offlineTerminals = terminalResume?.atStart() ?? [];
if (offlineTerminals.length) console.log(`Auto-resume: ${offlineTerminals.length} terminal chat(s) were busy when this computer went off; they go on once connected.`);

// DEV5: each chat's current step, at most one update every 2 s per chat.
const activity = new ActivityReporter((msg) => out(msg, false));
watchers.push((msg) => activity.observe(msg));
// Background helpers (subagents) of each chat, read from Claude Code's transcript folders, sent as `subagents` (subagents.ts).
const subagents = new SubagentTracker((msg) => out(msg, false));
watchers.push((msg) => subagents.observe(msg));
// Chats open in a terminal here: their helpers are watched while the terminal is open, busy or not (subagents.ts follow).
const followTerminalHelpers = () => {
  try {
    const open = new Map<string, string | undefined>();
    for (const [id, p] of readClaudeProcs()) if (!manager.isLive(id)) open.set(id, p.cwd);
    subagents.follow(open);
  } catch (err) {
    console.error('Following terminal helpers failed', err);
  }
};
// First look once the hub connection exists (below): helpers found at start are sent through it.
setInterval(followTerminalHelpers, 15_000).unref();
// VAULT6: how much of each Claude account's usage is used (on unless ESCANOR_ACCOUNT_USAGE=0); rides in machine_state.
// A Claude account at 98% of its window or more is held before it hits the wall (the session manager decides; aiLimits.ts).
const accountUsage = accountUsageEnabled()
  ? new AccountUsagePoller(profiles, {
      activeAccounts: () => manager.summaries().filter((x) => x.status === 'active').map((x) => x.accountId),
      onChange: () => {
        for (const [id, u] of Object.entries(accountUsage?.snapshot() ?? {})) manager.noteAccountUsage(id, u);
      },
    })
  : null;
// Workspace AI accounts (workspaceAccounts.ts): an account signed in once is used on every machine of the workspace; only Escanor's
// backend renews it, this machine pulls the short-lived token (on unless ESCANOR_WORKSPACE_ACCOUNTS=0; never in a worker or with chat users).
const sharedApi = sharedApiUrl(process.env, config.hubUrl, { managed: config.managed });
const workspaceAccounts =
  sharedApi && !config.chatUsers
    ? new WorkspaceAccounts({
        apiUrl: sharedApi,
        hubToken: () => config.hubToken,
        vmName: config.vmName,
        agentVersion: AGENT_VERSION,
        profilesDir: config.profilesDir,
        profiles,
        busyAccounts: () => new Set(manager.summaries().filter((s) => s.status === 'active').map((s) => s.accountId)),
        usage: () => accountUsage?.snapshot(),
        // The accounts on this computer changed (pulled from the workspace, or a local sign-in copied in): the hub and every app hear
        // the new list now (a hello), not at the next account-watch look. Only called after the hub connection exists (below).
        onChange: () => {
          void accountUsage?.pollDue();
          announceAccounts();
        },
        // A Claude sign-in already on this computer is copied into an Escanor account and shared (on unless ESCANOR_IMPORT_EXISTING=0).
        ...(switchOn(process.env.ESCANOR_IMPORT_EXISTING, true) ? { existing: { ownDir: process.env.ESCANOR_SHOW_DEFAULT_LOGIN !== '0' ? process.env.CLAUDE_CONFIG_DIR || join(homedir(), '.claude') : null } } : {}),
      })
    : null;
// Workspace GitHub accounts (ghAccounts.ts): `gh` signed in once is used on every machine of the workspace (on unless
// ESCANOR_WORKSPACE_GH_ACCOUNTS=0; never in a worker or with chat users). Written into gh's own hosts.yml; a machine's own sign-ins are kept.
const ghApi = ghAccountsApiUrl(process.env, config.hubUrl, { managed: config.managed });
const ghAccounts =
  ghApi && !config.chatUsers
    ? new GhAccounts({ apiUrl: ghApi, hubToken: () => config.hubToken, vmName: config.vmName, agentVersion: AGENT_VERSION, stateFile: join(config.dataDir, 'gh-accounts.json') })
    : null;
// Claude set-up sync (claudeSetup.ts): skills, agents, CLAUDE.md, memory, the plugin list and a few settings follow the workspace to every
// machine (on unless ESCANOR_CLAUDE_SETUP=0; never in a worker or with chat users). Only workspace-marked account folders, plus the ones
// listed in ESCANOR_CLAUDE_SETUP_PROFILES.
const setupApi = claudeSetupApiUrl(process.env, config.hubUrl, { managed: config.managed });
const claudeSetup =
  setupApi && !config.chatUsers
    ? new ClaudeSetupSync({
        conn: { apiUrl: setupApi, hubToken: () => config.hubToken, vmName: config.vmName, agentVersion: AGENT_VERSION },
        profilesDir: config.profilesDir,
        extra: extraProfiles(process.env),
      })
    : null;
// Adding a Claude account from the phone, signed in with that account's own email or Google (on unless ESCANOR_ACCOUNT_LOGIN=0;
// never with chat users, whose chats use their own login folder).
const accountLogin =
  accountLoginEnabled() && !config.chatUsers
    ? new AccountLogin({
        profilesDir: config.profilesDir,
        profiles,
        busyAccounts: () => new Set(manager.summaries().filter((s) => s.status === 'active').map((s) => s.accountId)),
        ...(workspaceAccounts ? { workspace: { share: (id: string) => workspaceAccounts.share(id), isShared: (id: string) => workspaceAccounts.isShared(id), autoShare: switchOn(process.env.ESCANOR_WORKSPACE_ACCOUNTS_AUTOSHARE, true) } } : {}),
      })
    : null;
// Device mesh: is the person at this computer (input idle time and lock; nothing else leaves it).
const presenceWatcher = computerControl ? new PresenceWatcher({ idle: makeIdleReader(), locked: () => screenLocked({}).then((l) => l) }) : null;
// DEV7: what runs on this machine, every 60 s and on change.
const machineState = config.machineState
  ? new MachineStateReporter((msg) => out(msg, false), {
      workspaceRoot: config.workspaceRoot,
      activity: () => activity.snapshot(),
      liveSessions: () => manager.liveIds(),
      usage: () => accountUsage?.snapshot(),
      giveWay: () => {
        const st = userFirst.state;
        const text = giveWayText(st.level, st.why);
        return { mode: userFirst.giveWay, level: st.level, ...(st.why ? { why: st.why } : {}), ...(text ? { text } : {}), ...(userFirst.stoppedCount ? { stopped: userFirst.stoppedCount } : {}) };
      },
      // Device mesh (presence.ts): is the person at this computer, and what it can do for the mesh. Where there is a desktop only.
      ...(presenceWatcher ? { presence: () => presenceWatcher.current(), deviceCaps: () => meshCaps({ jarvis: !!jarvis, remoteOn: jarvis?.remoteEnabled ?? false, hasDesktop: computerControl && hasDesktop() }) } : {}),
      aiLimits: () => manager.heldAccounts().map((e) => ({ accountId: e.accountId, label: e.label, resetsAt: new Date(e.resetsAt).toISOString(), source: e.source, text: limitStatusText(e.label, e.resetsAt) })),
    })
  : null;
// A chat ended (its turn's `result`): that account has less room now, look again soon.
if (accountUsage) watchers.push((msg) => { if (msg.type === 'sdk_message' && (msg.message as { type?: string } | undefined)?.type === 'result') accountUsage.chatEnded(); });
if (machineState) watchers.push((msg) => machineState.observe(msg));
// FLOW3: a fix done on this computer is tested by the agent itself, and continued after a restart.
const fixTasks = config.fixTests
  ? new FixTasks({
      registry: manager.sessionRegistry,
      send: out,
      admit: (input) => manager.handleUserInput(input),
      workspaceRoot: config.workspaceRoot,
      dataDir: config.dataDir,
      runTimeoutMs: config.fixTestTimeoutMs,
      noteRun: (r) => machineState?.noteRun('test', r),
      // AGRESUME: cut-off work is picked up only when Escanor says the run still wants it; no answer (or no Escanor API) = it waits.
      askResume: (asks) => {
        const apiUrl = escanorApiUrl(process.env, config.hubUrl);
        return apiUrl ? askResume({ apiUrl, hubToken: config.hubToken, vmName: config.vmName, agentVersion: AGENT_VERSION, asks }) : Promise.resolve(null);
      },
    })
  : null;
if (fixTasks) watchers.push((msg) => fixTasks.observe(msg));
// PREVIEW1 fallback: "Open on my computer" (previewOpen.ts). Only where Escanor's API can be told how it went (hosted hub), never in a
// managed worker, and off with ESCANOR_PREVIEW_OPEN=0 (or false/off/no). Starting the project always asks first (approval card).
const previewApi = config.managed || !switchOn(process.env.ESCANOR_PREVIEW_OPEN, true) ? null : escanorApiUrl(process.env, config.hubUrl);
const previewOpener = previewApi
  ? new PreviewOpener({
      roots: [...new Set([config.workspaceRoot, config.projectsRoot, config.terminalSyncRoot])],
      report: (report) => void reportPreviewOpen({ apiUrl: previewApi, hubToken: config.hubToken, vmName: config.vmName, agentVersion: AGENT_VERSION, report }),
      // Its own card type (PreviewRun), never the shell-command card: the exact scripts, and what the pull request changed. It is
      // announced like any other ask of this computer (permission_request) and answered the same way, from the owner's paired
      // apps; no backend conversation owns it, so the backend can never answer it for anyone. Unanswered after 5 minutes = no.
      ask: async (req, d) => {
        const abort = new AbortController();
        let timedOut = false;
        const timer = setTimeout(() => ((timedOut = true), abort.abort()), 5 * 60_000);
        try {
          const card = previewCard(req, d);
          const allowed = await manager.askPermission(card.sessionId, card.toolName, card.input, abort.signal);
          return allowed ? 'allow' : timedOut ? 'timeout' : 'deny';
        } catch {
          return 'deny';
        } finally {
          clearTimeout(timer);
        }
      },
    })
  : null;
// SITEPREV3: the same preview, opened on the phone through a private hub link (previewRelay.ts). Only this run's own preview port is
// ever reached. Off with ESCANOR_PREVIEW_LINK=0 (or false/off/no, or with the open itself off).
const previewRelay =
  previewOpener && switchOn(process.env.ESCANOR_PREVIEW_LINK, true)
    ? new PreviewRelay({ target: (linkId) => previewOpener.target(linkId), send: (m) => connection.send(m) })
    : null;
let firstConnect = true;
// What AI this computer can use (CLIs, local model programs, hardware), found by looking: the hello and a local_ai message carry it. ESCANOR_LOCAL_AI=0 turns it off.
let localAi: InstanceType<typeof LocalAiReporter> | null = null;
// This computer as the router's resource (ownAi.ts): switches, plans, room left, busy / locked, and the refusal rules for jobs from outside.
let ownAi: InstanceType<typeof OwnComputer> | null = null;
// Questions the hub puts to this computer's own AI (local_ask): signed-in AI tools, then local models, then (only if allowed and present) a cloud model. ESCANOR_LOCAL_ASK=0 turns it off.
let localAsker: InstanceType<typeof LocalAsker> | null = null;
let cloudClient: InstanceType<typeof CloudClient> | null = null;
// /ask in a chat (sideAsk.ts): answered by the quick AI of this computer, outside the chat's queue and slots.
const sideAsk = new SideAsk({
  send: (m) => out(m),
  makeAsker: (onEvent) => {
    const reporter = localAi;
    if (!reporter) return null;
    return new LocalAsker({ ...(cloudClient ? { cloud: cloudClient.ask } : {}), report: () => reporter.current(), rescan: () => reporter.rescanNow(), send: onEvent });
  },
});

// What kind of machine this is (laptop, server, VM and which cloud), found once by looking; the hello carries it.
// A personal computer (embedded in Escanor Desktop) says so and never asks a cloud's metadata address who it is.
const machineSummary =
  config.machineKind === 'personal'
    ? { kind: 'personal' as const, os: process.platform, macs: macAddresses() }
    : await detectMachine().catch(() => null);

// JARVIS2 (jarvis.ts): the owner's phone sends a direct command (open, show, wake, unlock, see the screen) through the hub, with no AI
// turn. Only where there is a desktop; Remote control is on by default for the owner's own laptop or desktop and off for a server, VM
// or a computer marked shared (ESCANOR_SHARED_COMPUTER=1) until the owner turns it on. Unlock, sign-in and live view wait for a fingerprint.
const ownComputer = !['server', 'vm', 'device'].includes(machineSummary?.kind ?? 'unknown') && process.env.ESCANOR_SHARED_COMPUTER !== '1';
const jarvisPaths = jarvisFiles(config.dataDir);
// "Let Escanor sign in for me" (signinBroker.ts, signinApproval.ts, loginRecovery.ts): nothing here runs by itself. Each use of a saved secret
// (unlock the keyring, sign GitHub in, a listed sudo command) is a request that the owner approves on the phone with a fingerprint or face
// check, or that falls inside a time window they gave with one. The agent fetches the secret from the Escanor vault with its own device key,
// hands it straight to the program that needs it (standard input, a one-use pipe for sudo, a child's environment) and forgets it: never on
// disk, in a log, a chat or the AI's context. Off until the owner turns it on.
const signinStore = new SigninStore(join(config.dataDir, 'signin-broker.json'));
const signinAudit = new SigninAudit(join(config.dataDir, 'signin-audit.jsonl'));
const signinExec = new RealExec(process.env);
const signinBroker = new CredentialBroker({
  policy: () => signinStore.read(),
  audit: signinAudit,
  fetch: async (name) => {
    if (!deviceApi) return { ok: false, reason: 'No Escanor address for this computer.' };
    const conn = { apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION };
    const key = await vaultDeviceKey(conn);
    if (!key.ok) return { ok: false, reason: key.reason };
    for (const scope of ['workspace', ...(config.machineId ? [`machine:${config.machineId}`] : [])]) {
      const got = await vaultResolve(conn, key.value, scope, [name]);
      const value = got.ok ? got.value.values[name] : undefined;
      if (typeof value === 'string' && value) return { ok: true, value };
    }
    return { ok: false, reason: `There is no saved secret named ${name} in your vault (or it could not be reached).` };
  },
});
const loginRecovery = new LoginRecovery({
  broker: signinBroker,
  exec: signinExec,
  reportFile: join(config.dataDir, 'signin-report.json'),
  allowNames: () => signinStore.read().allow,
  fixed: (item) => logSafety(defaultUndoRoot(), { at: Date.now(), action: 'remote', source: 'agent', command: `signin_fixed ${item.id}`, why: item.say }),
});
const signin = new SigninControl({ store: signinStore, audit: signinAudit, broker: signinBroker, recovery: loginRecovery, exec: signinExec });
const wakeApprovals = new WakeApprovals({ keys: new KeyStore(jarvisPaths.keys), ...(deviceApi && config.machineId ? { account: new BackendTrust({ apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION }) } : {}) });
/**
 * Sends a Wake-on-LAN packet for another computer on this network, but only after the owner's fingerprint. The phone's signed yes came
 * with the wake-up; it is checked here (the phones paired with this machine, then the person's account), not trusted because the hub
 * passed it on. Without a good one nothing is sent and the refusal is in the safety log.
 */
async function wakeOn(mac: string, target: unknown, approval: unknown): Promise<void> {
  const packet = magicPacket(mac);
  if (!packet) return;
  const verdict = await wakeApprovals.check(target, approval);
  logSafety(defaultUndoRoot(), { at: Date.now(), action: 'remote', source: 'agent', command: 'wake_on_lan', why: verdict.ok ? `sent a wake-up for ${String(target).slice(0, 60)} after a fingerprint (${verdict.who})` : `refused: ${verdict.why}` });
  if (!verdict.ok) return;
  const sock = createSocket('udp4');
  sock.bind(() => {
    sock.setBroadcast(true);
    let left = 0;
    for (const addr of broadcastAddresses()) for (const port of [9, 7]) {
      left++;
      sock.send(packet, port, addr, () => {
        if (--left === 0) sock.close();
      });
    }
  });
  sock.on('error', () => sock.close());
}
const focusHelper = new FocusHelper();
const wakeSchedule = new WakeSchedule(`${config.dataDir}/wake-at.json`);
// Also where there is no desktop right now (a server, or a laptop at its login screen after a restart): it then takes only unlocking and
// signing things in (jarvis.ts `limited`), which is what a phone needs to turn a restarted computer back on.
const jarvis = computerControl || !config.managed
  ? new Jarvis({
      machine: config.machineId || config.vmName,
      name: config.vmName,
      limited: !computerControl,
      machineKind: machineSummary?.kind ?? 'unknown',
      requestUpdate: requestHostUpdate,
      signin,
      helper: new SessionHelper(),
      helperSyncFile: `${config.dataDir}/unlock-helper-phones.json`,
      keys: new KeyStore(jarvisPaths.keys),
      remote: new RemoteSwitch(jarvisPaths.remote, process.env, ownComputer),
      quiet: new QuietNotifications({}, `${config.dataDir}/quiet-notifications.json`),
      log: (e) => logSafety(defaultUndoRoot(), e),
      sendAsk: (ask) => connection.send({ type: 'device_ask', ask }),
      sendAskDone: (askId) => connection.send({ type: 'device_ask_done', askId }),
      // Remote desktop (remoteDesktop.ts): the live screen goes to the hub as binary pictures and small JSON notes; nothing is kept.
      sendScreenText: (viewId, viewer, msg) => connection.send({ type: 'screen_out', viewId, ...(viewer ? { viewer } : {}), msg }),
      sendFrame: (frame) => connection.sendBinary(frame),
      sendView: (viewId, expiresAt) => connection.send({ type: 'screen_view', viewId, expiresAt }),
      sendViewEnd: (viewId, why) => connection.send({ type: 'screen_view_end', viewId, why }),
      viewPolicy: new FilePolicy(`${config.dataDir}/access-policy.json`),
      showCode: (code) => void screenNotice('Escanor: pair your phone', `Code ${code}. Type it on your phone within 10 minutes. If this was not you, ignore it.`, 10 * 60_000, {}),
      presence: () => presenceWatcher?.current(),
      typing: new RemoteSwitch(jarvisPaths.typing, process.env, false, TYPE_ENV),
      focus: focusHelper,
      account: deviceApi && config.machineId ? new BackendTrust({ apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION }) : undefined,
      wakeRoutes: () => wakeRoutes(),
      wakeAt: { set: (e) => wakeSchedule.set(e), alarm: (e) => setWakeAlarm(e) },
      highlight: () => readHighlight(join(config.dataDir, HIGHLIGHT_NAME)),
      credentials: async (host) =>
        (deviceApi && config.machineId
          ? await vaultCredential({ apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION }, config.machineId, host)
          : null) ?? (await keyringCredential(host)),
      type: (text) => typeText(text, process.env),
      canType: () => canType(process.env),
      // Kubernetes Secrets (k8sSecrets.ts): this computer's own kubectl and kubeconfig; the new value is fetched from the Escanor vault here
      // (needs ESCANOR_MACHINE_SECRETS=1) and goes to kubectl on its standard input. ESCANOR_K8S_CONTEXTS limits the clusters.
      k8s: new K8sSecrets({
        exec: kubectlExec(process.env),
        digestKey: fileDigestKey(join(config.dataDir, 'k8s-digest.key')),
        allowedContexts: (process.env.ESCANOR_K8S_CONTEXTS ?? '').split(',').map((c) => c.trim()).filter(Boolean),
        log: (action, why, what) => logSafety(defaultUndoRoot(), { at: Date.now(), action: 'remote', source: 'app', command: what ? `${action} ${what}` : action, why }),
        vault: async (name, scope) => {
          if (!machineSecretsEnabled(process.env)) return { ok: false, reason: 'secrets from Escanor are off on this computer: set ESCANOR_MACHINE_SECRETS=1' };
          if (!deviceApi) return { ok: false, reason: 'no Escanor address for this computer' };
          const conn = { apiUrl: deviceApi, get hubToken() { return config.hubToken; }, vmName: config.vmName, agentVersion: AGENT_VERSION };
          const key = await vaultDeviceKey(conn);
          if (!key.ok) return { ok: false, reason: key.reason };
          const got = await vaultResolve(conn, key.value, scope, [name]);
          if (!got.ok) return { ok: false, reason: got.reason };
          const value = got.value.values[name];
          return typeof value === 'string' && value ? { ok: true, value } : { ok: false, reason: `no vault secret named ${name}` };
        },
      }),
    })
  : null;
// AGENT-INDEP (machinePermissions.ts): what this computer may do is set from the phone, the website or the desktop app and kept by
// Escanor's backend; this agent follows it by itself (no Desktop app needed). Narrows only: it never gives a computer a power it lacks.
const machinePerms = deviceApi && !config.managed
  ? new MachinePermissions({
      apiUrl: deviceApi,
      hubToken: () => config.hubToken,
      vmName: config.vmName,
      agentVersion: AGENT_VERSION,
      file: join(config.dataDir, 'machine-permissions.json'),
      log: (line) => console.log(line),
      apply: (p) => {
        manager.setPolicy({ computerControl: p.computer_control ?? true, meshTools: p.devices ?? true, defaultMode: p.default_mode });
        if (jarvis && p.remote_control !== null) void jarvis.setRemoteFromPermissions(p.remote_control, ownComputer).then(() => machineState?.sendNow());
        const now = manager.policy();
        return { remote_control: jarvis ? jarvis.remoteEnabled : null, computer_control: now.computerControl, devices: now.meshTools, default_mode: (PERMISSION_MODES as readonly string[]).includes(now.defaultMode) ? (now.defaultMode as (typeof PERMISSION_MODES)[number]) : null };
      },
    })
  : null;
machinePerms?.start();
if (jarvis) {
  void jarvis.quiet.sweep(); // notifications silenced before a restart are put back once their time is up
  setInterval(() => jarvis.sweep(), 30_000).unref();
  // The login screen's sign-in helper learns re-paired phones while the person is signed in here (jarvis.ts syncHelper).
  setTimeout(() => void jarvis.syncHelper().catch(() => 'failed'), 20_000).unref();
  setInterval(() => void jarvis.syncHelper().catch(() => 'failed'), 3 * 60_000).unref();
}
// The GNOME focus helper (focusHelper.ts) is put in the person's own folder once, on their own computer, when Remote control is on; it
// starts at their next sign-in. ESCANOR_FOCUS_HELPER=0 keeps the agent from installing it.
if (jarvis && computerControl && ownComputer && switchOn(process.env.ESCANOR_FOCUS_HELPER, true)) {
  void focusHelper.install().then((r) => {
    if (r.did === 'installed') logSafety(defaultUndoRoot(), { at: Date.now(), action: 'remote', source: 'app', command: 'focus_helper', why: `installed the Escanor focus helper for GNOME (${r.state === 'ready' ? 'running' : 'starts at the next sign-in'})` });
  }).catch(() => {});
}

// JARVIS voice (voiceBridge.ts): the voice shortcut (`escanor-agent voice`) reaches this running agent through a socket only this
// computer's user can open: "what is Escanor doing", the short chat a spoken request becomes (it shows in the phone's Machines like any
// chat, with the same safety rules and holds), and keeping the screen awake. Where there is a desktop; ESCANOR_VOICE=0 turns it off.
if ((computerControl || jarvis) && switchOn(process.env.ESCANOR_VOICE, true) && !config.managed) {
  const { VoiceChats, serveBridge, socketPath } = await import('./voiceBridge.js');
  const voiceChats = new VoiceChats({ admit: (input) => manager.handleUserInput(input) });
  watchers.push((msg) => voiceChats.observe(msg));
  serveBridge(
    socketPath(config.dataDir),
    {
      chat: (text) => voiceChats.start(text),
      status: () => {
        const titles = new Map(manager.summaries().map((s) => [s.sessionId, s.title]));
        return activity.snapshot().map((a) => `${titles.get(a.sessionId) || 'A chat'}: ${a.waiting ? 'waiting for your OK' : a.step || 'working'}`);
      },
      wake: async () => (jarvis ? (await jarvis.awake.start(5)).ok : false),
      keepAwake: async (minutes) => (jarvis ? (await jarvis.awake.start(minutes)).ok : false),
      signin: async (args, source) => (jarvis ? jarvis.requestUse(args, source) : { ok: false, say: 'This computer cannot sign in for you yet.' }),
      phone: (a) => phoneRequests.ask(a),
      mesh: (r) => meshAsk(r),
    },
    (line) => console.warn(line),
  );
}

const handoverBusy = (): boolean => manager.isWorking() || manager.queuedInputs().length > 0;
let handoverClaimed = false;
let retiring = false;
/** A newer agent of this computer took the hub connection: stop without reconnecting (the two must never take it from each other). */
function retireForNewer(): void {
  if (retiring) return;
  retiring = true;
  console.log('A newer agent took over this computer. This one finishes what it is doing and stops.');
  connection.close();
  const began = Date.now();
  const watch = setInterval(() => {
    if (handoverBusy() && Date.now() - began < 5 * 60_000) return;
    clearInterval(watch);
    stopEverything();
    process.exit(0);
  }, 1_000);
}
if (handover) handover.onSuperseded = () => retireForNewer();
const connection = new HubConnection(
  config.hubUrl,
  config.hubToken, // the socket takes its token from setToken() later
  (msg: HubToAgentMessage) => {
    switch (msg.type) {
      case 'user_input':
        // A newer agent asked to take over (handover.ts): new work is left unconfirmed, so the hub sends it to that agent when it connects.
        if (handover?.draining) break;
        routeHubInput(
          seenInputs,
          msg,
          (input) => {
            // /ask: only answered, by this computer's quick AI; it never queues, takes a slot or waits for the chat's running reply.
            const question = parseAsk(input.text);
            if (question !== null) {
              sideAsk.handle(input, question);
              return;
            }
            fixTasks?.noteInput(input);
            manager.handleUserInput(input);
          },
          (ack) => connection.send(ack),
        );
        break;
      case 'device_command':
        if (!jarvis) {
          connection.send({ type: 'device_result', requestId: msg.requestId, ok: false, say: 'This computer cannot take direct commands (there is no desktop here).', code: 'refused' });
          break;
        }
        void jarvis.command(msg).then((r) => connection.send(r));
        break;
      case 'phone_result':
        phoneRequests.result(msg);
        break;
      case 'screen_open':
      case 'screen_close':
      case 'screen_in':
        jarvis?.screenMessage(msg);
        break;
      case 'device_approval':
        if (!jarvis) {
          connection.send({ type: 'device_result', requestId: msg.requestId, ok: false, say: 'This computer cannot take direct commands (there is no desktop here).', code: 'refused' });
          break;
        }
        void jarvis.approve(msg).then((r) => connection.send(r));
        break;
      case 'power_command': {
        // The hub (the owner, through the app) asks this machine to sleep, or to wake another one on this network.
        if (msg.action === 'suspend') {
          const c = suspendCommand();
          // A wake time the person set is put in the clock chip again just before sleeping (it is kept across the sleep).
          const wakeAt = wakeSchedule.get();
          if (wakeAt) void setWakeAlarm(wakeAt);
          if (c) setTimeout(() => execDetached(c.cmd, c.args, { windowsHide: true }, () => {}), 2000); // after this answer has left
        } else if (msg.action === 'wol' && typeof msg.mac === 'string') {
          void wakeOn(msg.mac, msg.target, msg.approval);
        }
        break;
      }
      case 'interrupt':
        fixTasks?.noteInterrupt(msg.sessionId); // FLOW4: a stopped fix is never picked up again after a restart
        manager.interrupt(msg.sessionId);
        break;
      case 'set_permission_mode':
        manager.setPermissionMode(msg.sessionId, msg.mode);
        break;
      case 'set_model':
        manager.setModel(msg.sessionId, msg.model);
        break;
      case 'set_effort':
        manager.setEffort(msg.sessionId, msg.effort);
        break;
      case 'set_priority':
        if (typeof msg.priority === 'boolean') manager.setPriority(msg.sessionId, msg.priority);
        break;
      case 'set_machine_settings': {
        // "Give way to me when I'm using this computer": kept on this computer, reported back in the machine status.
        // The permissions page changed this computer's set (the backend nudged the hub): ask for it now.
        if (msg.permissionsChanged === true) void machinePerms?.refreshNow();
        const mode = parseGiveWay(msg.giveWay);
        if (mode) {
          try {
            saveGiveWay(settingsFile, mode);
          } catch (err) {
            console.error('Saving the machine setting failed', err);
          }
          userFirst.setMode(mode);
          machineState?.sendNow();
        }
        break;
      }
      case 'ai_limit': {
        // The Escanor plan's limit (the hub knows): all work on that account waits for the reset and starts again by itself.
        const at = typeof msg.resetsAt === 'string' ? Date.parse(msg.resetsAt) : NaN;
        if (Number.isFinite(at)) manager.noteAccountLimit(typeof msg.accountId === 'string' ? msg.accountId : undefined, at, 'plan');
        break;
      }
      case 'permission_response': {
        // DEV6: the phone shows the approval as done only once this machine says the waiting chat got it.
        const r = manager.resolvePermission(msg.requestId, msg.behavior, msg.message);
        out({ type: 'permission_ack', requestId: msg.requestId, delivered: r.delivered, ...(r.sessionId ? { sessionId: r.sessionId } : {}) });
        break;
      }
      case 'set_mcp_servers':
        void manager.setMcpServers(msg.servers);
        break;
      case 'queue_cancel':
      case 'queue_edit':
      case 'queue_move':
      case 'queue_start_now':
      case 'queue_get':
        manager.handleQueueCommand(msg);
        break;
      case 'subagent_steps':
        out(subagents.steps(msg), false);
        break;
      case 'account_command':
        if (!accountLogin) {
          connection.send({ type: 'account_result', requestId: msg.requestId, ok: false, error: 'Adding accounts from the phone is not turned on for this computer.' });
          break;
        }
        void accountLogin.handle(msg).then((r) => {
          connection.send(r);
          if (r.ok && r.accounts) {
            console.log(`Accounts: ${profiles.map((p) => p.id).join(', ')}`);
            void accountUsage?.pollDue();
          }
        });
        break;
      case 'preview_open':
        void previewOpener?.handle(msg);
        break;
      case 'preview_share':
        if (previewRelay) void previewOpener?.share(msg);
        break;
      case 'preview_unshare':
        previewOpener?.unshare(msg.linkId);
        break;
      case 'preview_http':
        if (previewRelay) previewRelay.handle(msg);
        else connection.send({ type: 'preview_http_wait', id: msg.id, state: 'stopped', message: 'Preview links are turned off on this computer.' });
        break;
      case 'preview_http_cancel':
        previewRelay?.cancel(msg.id);
        break;
      case 'safety_get':
      case 'safety_action':
        connection.send(
          safety?.handle(msg) ??
            (msg.type === 'safety_get'
              ? { type: 'safety_state', requestId: msg.requestId, state: { enabled: false, holds: riskHoldsOn(process.env), guard: { set: 0, files: 0 }, tripped: null, canPause: false, undo: [], events: [] } }
              : { type: 'safety_result', requestId: msg.requestId, ok: false, message: 'The safety layer is off on this computer.' }),
        );
        break;
      case 'local_ask':
        if (localAsker) localAsker.start(msg);
        else connection.send({ type: 'local_ask_event', requestId: msg.requestId, seq: 1, event: { kind: 'failed', message: 'Answering with this computer\'s own AI is turned off here.', tried: [] } });
        break;
      case 'local_ask_cancel':
        localAsker?.cancel(msg.requestId);
        break;
      case 'cloud_answer':
        cloudClient?.handle(msg);
        break;
      case 'local_pull_answer':
        localAsker?.answerPull(msg.requestId, msg.approve === true);
        break;
      // The hub: the workspace's AI accounts changed (added on another machine, signed in again, removed): pull them now.
      case 'workspace_accounts_changed':
        void workspaceAccounts?.syncNow();
        break;
      case 'list_projects':
        connection.send({ type: 'projects_list', requestId: msg.requestId, projects: listProjects(config.projectsRoot) });
        break;
    }
  },
  () => {
    manager.resetMcpReport();
    sendHello();
    if (handover && handoverTurn !== 'free' && !handoverClaimed) {
      handoverClaimed = true;
      handover.claim(handoverBusy); // the hub has replaced the old connection with this one: this agent holds the lease now
    }
    manager.resendPendingPermissions();
    console.log(`Connected to hub as "${config.vmName}"`);
    // Set up again on purpose (the one-time marker the installer writes): used once the hub has let this computer in.
    setTimeout(() => { try { unlinkSync(join(config.dataDir, 'repair-once')); } catch { /* none */ } }, 15_000).unref();
    void terminalSync?.syncOnce();
    void deviceMcp?.refreshNow();
    void machinePerms?.refreshNow();
    // A link that flaps (hundreds of reconnects a day were seen) must not use up Escanor's per-workspace limits: these two visit on a
    // connect only when their last good visit is old enough (workspaceAccounts.ts / claudeSetup.ts CONNECT_GAP_MS).
    void workspaceAccounts?.syncOnConnect();
    void ghAccounts?.syncNow();
    void claudeSetup?.syncOnConnect();
  },
  {
    // DEV8: what is not at the hub yet survives a restart (data/outbox.jsonl).
    outboxFile: join(config.dataDir, 'outbox.jsonl'),
    outboxKey: config.outboxKey,
    onStatus: (s) => {
      publishLinkStatus(s);
      if (!s.connected && s.reason === 'replaced' && handover?.replacedByNewer()) retireForNewer();
      if (!s.connected) {
        localAsker?.dropWaiting();
        cloudClient?.linkLost();
      } // nobody is left to answer a download question
    },
    onConfirmed: (mids) => fixTasks?.confirmed(mids),
    // After the queued events: the latest state of every running chat and of the machine.
    onFlushed: () => {
      activity.resendAll();
      for (const s of manager.summaries()) if (s.status === 'active') subagents.track(s.sessionId, s.cwd);
      subagents.resendAll();
      machineState?.sendNow();
      void localAi?.sendNow(); // the hub has nothing of this computer's AI after a (re)connect
      manager.resendQueueState(); // QUEUEUI: the apps see what waits here
      // AUTORESUME: chats cut off while this machine was away go on now. After a start, 20 s first, so a Stop the phone sent while
      // the computer was off (the hub sends it again now) lands before anything is picked up.
      manager.resumeCutOffSoon(firstConnect ? 20_000 : 3_000);
      if (firstConnect) {
        firstConnect = false;
        manager.restoreQueue(); // what waited when the agent last stopped is tried again
        // A failure here (a disk error writing sessions.json) must never take the agent down: nothing is picked up, it is logged.
        fixTasks?.resumeAfterRestart().catch((err) => console.error('Picking cut-off work up after the restart failed:', err instanceof Error ? err.message : err)); // FLOW3: a fix an agent restart cut off goes on, after what the last run left unsent
      }
    },
  },
);

// AUTORESUME: a chat cut off by the machine going away goes on only once the hub link is back (the model needs the network too).
manager.isOnline = () => connection.connected;
// The apps hear at once when an account is held for its limit, or when this computer gives way to the person.
manager.onLimitsChange = () => machineState?.sendNow();

// While anything runs or waits to run, this machine is kept from sleeping (a laptop that sleeps mid-task stops the work).
// Released the moment nothing runs, so a machine that is meant to sleep when idle still does.
const keepAwake = new KeepAwake(systemPlatform(), config.keepAwake);
manager.onWorkChange = (working) => {
  keepAwake.setBusy(working);
  console.log(working ? `Working: ${keepAwake.held ? 'keeping this machine awake' : `not holding a sleep lock (keep-awake ${config.keepAwake})`}` : 'Idle: sleep allowed again');
};
const keepAwakeTimer = setInterval(() => keepAwake.refresh(), 30_000); // the plug may have changed, or a lock failed earlier
keepAwakeTimer.unref();

// After the machine wakes: connect again at once (the old socket is dead but looks open), tell chats that were cut off.
const resumeDetector = new ResumeDetector({
  onResume: (asleepMs) => {
    console.log(`Machine woke after about ${Math.round(asleepMs / 1000)}s asleep: reconnecting`);
    manager.noteResume();
    connection.reconnectNow();
    keepAwake.refresh();
  },
});

followTerminalHelpers();
// The hello: who this machine is, its accounts and chats. Sent on every (re)connect, and again when the account list changes.
function sendHello(): void {
  terminalSync?.refreshProcs(); // so the hello lists terminal sessions that are busy right now as active
  connection.send({
    type: 'hello',
    agentVersion: AGENT_VERSION,
    ...(machineSummary ? { machine: machineSummary } : {}),
    ...(config.machineId ? { machineId: config.machineId } : {}),
    // The older ids of this computer (the Desktop install id) so the hub merges a duplicate row into this one; and: set up again on purpose.
    ...(helloLegacyIds.length ? { legacyMachineIds: helloLegacyIds } : {}),
    ...(process.env.ESCANOR_REPAIR === '1' || existsSync(join(config.dataDir, 'repair-once')) ? { repaired: true } : {}),
    // What this agent does for Escanor's checks: `chat_user` only when chats really run as their own users here.
    capabilities: [...helloCapabilities(config.chatUsers), ...(previewOpener ? [PREVIEW_CAPABILITY] : []), ...(previewRelay ? [PREVIEW_LINK_CAPABILITY] : []), ...(accountLogin ? ACCOUNT_CAPABILITIES : []), ...(workspaceAccounts ? ['account_workspace'] : []), ...(safety ? ['safety'] : []), ...(computerControl ? ['computer_control'] : []), ...(phoneServer ? [PHONE_COMMAND_CAPABILITY] : []), ...(jarvis ? [DEVICE_COMMAND_CAPABILITY, MACHINE_CHECKS_CAPABILITY] : []), ...(jarvis?.streams ? [SCREEN_STREAM_CAPABILITY] : []), ...(localAsker && ownAi && switchOn(process.env.ESCANOR_OWN_AI_JOBS, true) ? [OWN_JOB_CAPABILITY] : [])],
    ...(config.bootId ? { bootId: config.bootId } : {}),
    ...(localAi?.current() ? { localAi: localAi.current()! } : {}),
    vmName: config.vmName,
    hostname: hostname(),
    accounts: profiles.map(toAccount),
    sessions: manager.summaries(),
    // DEV6: prompts still waiting here; each is announced again right after (resent: true).
    pending: manager.pendingPermissions(),
  });
}

// Accounts added or removed on this computer show in every app without a restart: look again now and then, announce when they changed,
// and announce on a slow heartbeat too.
const accountWatch = new AccountWatch({
  profiles,
  profilesDir: config.profilesDir,
  announce: (changed) => {
    console.log(`Accounts: ${profiles.map((p) => p.id).join(', ')}`);
    sendHello();
    accountWatch.noteAnnounced();
    // A sign-in added on this computer goes to the workspace within seconds, not at the next visit (up to SYNC_MS, 20 min).
    if (changed) void workspaceAccounts?.syncNow();
  },
});
/** Sends the hello with the current account list (WorkspaceAccounts.onChange), so the account watch does not announce it again. */
function announceAccounts(): void {
  sendHello();
  accountWatch.noteAnnounced();
}
setInterval(() => accountWatch.tick(), WATCH_MS).unref();

connection.connect();
if (handover && handoverTurn === 'free') handover.start(handoverBusy);
terminalSync?.start();
terminalResume?.start();
smallChats?.start();
resourceGuard.start();
try {
  const back = userFirst.recover(); // a chat left stopped by an agent that died while paused goes on
  if (back) console.log(`Started ${back} paused process(es) again that an earlier run left stopped`);
} catch (err) {
  console.error('Recovering paused processes failed', err);
}
userFirst.start();
manager.startLimitClock();
// What the agent itself left behind (half-written state files, picture folders of finished turns), once at start and every hour.
const cleanLeftovers = () => {
  try {
    const gone = cleanOwnLeftovers(config.dataDir);
    if (gone.length) console.log(`Cleared ${gone.length} leftover temp item(s) the agent made earlier`);
  } catch (err) {
    console.error('Clearing leftovers failed', err);
  }
};
cleanLeftovers();
setInterval(cleanLeftovers, 3_600_000).unref();
startChildTmpSweep(childTmpDir(process.env)); // chats' temp files live on disk in one folder; drop week-old ones
presenceWatcher?.start();
machineState?.start();
accountUsage?.start();
workspaceAccounts?.start();
ghAccounts?.start();
claudeSetup?.start();
resumeDetector.start();
if (switchOn(process.env.ESCANOR_LOCAL_AI, true)) {
  const scanOpts = { profilesDir: config.profilesDir };
  ownAi = new OwnComputer({
    profilesDir: config.profilesDir,
    agentVersion: AGENT_VERSION,
    isLocked: () => screenLocked({}),
    // Our work gives way to the person: the same signals the chats use (resource guard, "give way to me").
    holdReason: () => {
      const g = resourceGuard.state;
      if (g.paused) return `Escanor's work is waiting because ${g.reason === 'memory' || g.reason === 'our-memory' ? 'this computer is short of memory' : 'this computer is busy'}`;
      const u = userFirst.state;
      return u.level === 'normal' ? null : holdLine(giveWayText(u.level, u.why));
    },
    activeChats: () => manager.workingCount(),
    usage: () => {
      const snap = accountUsage?.snapshot();
      return snap ? (snap.default ?? Object.values(snap)[0]) : undefined;
    },
  });
  const claudeModels = new ClaudeModels(undefined, undefined, (t) => console.warn(t));
  const withModels = (r: LocalAiReport): LocalAiReport => ({
    ...r,
    clis: r.clis.map((c) => (c.id === 'claude' && c.installed ? { ...c, models: claudeModels.current(c.version) } : c)),
  });
  localAi = new LocalAiReporter({ decorate: async (r) => withModels(await ownAi!.decorate(r)), scan: () => discoverLocalAi(scanOpts), scanRuntimes: () => probeRuntimes(scanOpts), refreshClis: (c) => refreshLogins(c, scanOpts), send: (m) => connection.send(m), log: (t) => console.warn(t) });
  localAi.start();
  if (switchOn(process.env.ESCANOR_LOCAL_ASK, true)) {
    const reporter = localAi;
    // The cloud step (only used when a request allows it): the hub answers with the owner's own key. ESCANOR_LOCAL_ASK_CLOUD=0 removes it.
    if (switchOn(process.env.ESCANOR_LOCAL_ASK_CLOUD, true)) cloudClient = new CloudClient({ send: (m) => out(m, false), connected: () => connection.connected });
    localAsker = new LocalAsker({
      ...(cloudClient ? { cloud: cloudClient.ask } : {}),
      report: () => reporter.current(),
      rescan: () => reporter.rescanNow(),
      // A job starting or ending changes the computer's state: the hub hears at once.
      send: (m) => {
        out(m, false);
        if (m.event.kind === 'engine' || m.event.kind === 'done' || m.event.kind === 'failed') void reporter.touch();
      },
      ...(ownAi && switchOn(process.env.ESCANOR_OWN_AI_JOBS, true) ? { own: ownAi, projectsRoot: config.projectsRoot } : {}),
    });
  }
}

// Stops everything the agent runs (chats first) and closes the hub link. Does not exit: signals exit after it, embedded mode reports first.
function stopEverything(): void {
  userFirst.stop(); // first: a paused chat cannot hear that it is being closed until it is started again
  previewRelay?.stopAll();
  previewOpener?.stopAll();
  fixTasks?.stop(); // chats closed now are not turns ending: a fix in progress continues on the next start
  presenceWatcher?.stop();
  machineState?.stop();
  localAsker?.cancelAll();
  localAi?.stop();
  accountUsage?.stop();
  workspaceAccounts?.stop();
  ghAccounts?.stop();
  claudeSetup?.stop();
  accountLogin?.stopAll();
  terminalSync?.stop();
  terminalInbox?.stop();
  terminalResume?.stop();
  smallChats?.stop();
  resourceGuard.stop();
  manager.stopLimitClock();
  resumeDetector.stop();
  keepAwake.stop();
  deviceMcp?.stop();
  machinePerms?.stop();
  handover?.stop();
  screenHelpServer?.close();
  phoneServer?.close();
  meshServer?.close();
  manager.shutdown();
  connection.close();
}

registerRuntime({
  agentVersion: AGENT_VERSION,
  connected: () => connection.connected,
  sessions: () => {
    const all = manager.summaries();
    return { total: all.length, active: all.filter((x) => x.status === 'active').length };
  },
  reconnect: () => connection.reconnectNow(),
  setToken: (t) => {
    setHubToken(t);
    connection.setToken(t);
  },
  stop: stopEverything,
});

process.on('exit', () => userFirst.stop()); // whatever way the agent ends, nothing of ours stays paused

// systemd and containers stop a process with SIGTERM, so handle it like Ctrl-C: stop the Claude processes first.
// Embedded in Escanor Desktop, embed.ts handles the signals (it reports the stop to the desktop first).
if (!config.embedded) {
  for (const signal of ['SIGINT', 'SIGTERM'] as const) {
    process.on(signal, () => {
      stopEverything();
      process.exit(0);
    });
  }
}

// A computer that started with no desktop (restarted, nobody signed in yet) gets one once the owner signs in with the phone. Screen control
// and the live view start with the agent, so when a desktop shows up the agent starts again by itself, but only when systemd runs it (it
// brings it back) and nothing is running or waiting. ESCANOR_RESTART_ON_DESKTOP=0 keeps it from doing that.
if (!computerControl && process.env.ESCANOR_COMPUTER_CONTROL === undefined && !config.managed && !config.embedded && process.env.INVOCATION_ID && switchOn(process.env.ESCANOR_RESTART_ON_DESKTOP, true)) {
  const watch = setInterval(() => {
    if (!hasDesktop() || manager.isWorking()) return;
    clearInterval(watch);
    logSafety(defaultUndoRoot(), { at: Date.now(), action: 'remote', source: 'agent', command: 'desktop_appeared', why: 'someone signed in on this computer: the agent starts again, idle, so screen control is there' });
    stopEverything();
    process.exit(0);
  }, 30_000);
  watch.unref?.();
}
