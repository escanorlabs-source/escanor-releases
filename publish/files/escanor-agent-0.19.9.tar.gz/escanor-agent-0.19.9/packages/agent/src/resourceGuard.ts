import { readFileSync, readdirSync, lstatSync, rmSync } from 'node:fs';
import { cpus, freemem, loadavg, setPriority, tmpdir, totalmem } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

/**
 * The person using the computer wins over our work. Every few seconds this looks at how busy the machine is and how much of it our
 * own Claude processes use; over a limit, the agent stops admitting new work (it waits in the queue, nothing is lost) and puts idle
 * chat processes away; back under the lower marks, the work goes on by itself. Our processes also always run at a lower priority.
 * Pure logic plus an injectable sampler, so it is tested without a loaded machine.
 */

export type GuardLimits = {
  /** Pause when the machine's available memory is under this percent; resume above it plus RESUME_MARGIN. */
  minFreeMemPercent: number;
  /** Memory is critically low under this percent: even a person's "Start now" waits. */
  criticalFreeMemPercent: number;
  /** Cap on all our processes' memory (RSS) in MB; 0 = half of the machine's memory (at least 1 GB). */
  maxMemoryMb: number;
  /** Pause when the machine's 1-minute load per core stays above this (resume under 70% of it). */
  maxLoadPerCore: number;
  /** Cap on the machine's CPU our processes use, in percent of the whole machine (resume under 70% of it). */
  maxCpuPercent: number;
  /** Our processes' nice value (0 = leave priority alone). */
  nice: number;
  /** Samples in a row a load or CPU reading must stay over before it counts. */
  sustain: number;
  intervalMs: number;
  /** Idle chat processes (nobody asked anything for this long) are put away; 0 = never. They stay resumable. */
  idleCloseMs: number;
  enabled: boolean;
};

export const DEFAULT_GUARD_LIMITS: GuardLimits = {
  minFreeMemPercent: 10,
  criticalFreeMemPercent: 3,
  maxMemoryMb: 0,
  maxLoadPerCore: 0.9,
  maxCpuPercent: 70,
  nice: 10,
  sustain: 3,
  intervalMs: 15_000,
  idleCloseMs: 30 * 60_000,
  enabled: true,
};

const RESUME_MARGIN = 5; // percentage points of memory above the pause mark
const RESUME_FRACTION = 0.7; // load / cpu resume below this share of the pause mark; memory cap resumes at 0.85

function num(raw: string | undefined, fallback: number, min: number, max = Number.MAX_SAFE_INTEGER): number {
  if (raw === undefined || raw.trim() === '') return fallback;
  const n = Number(raw);
  return Number.isFinite(n) && n >= min && n <= max ? n : fallback;
}

/**
 * ESCANOR_RESOURCE_GUARD=0 (off), ESCANOR_MIN_FREE_MEM_PERCENT=10, ESCANOR_CRITICAL_FREE_MEM_PERCENT=3, ESCANOR_MAX_MEMORY_MB=0 (auto),
 * ESCANOR_MAX_LOAD_PER_CORE=0.9, ESCANOR_MAX_CPU_PERCENT=70, ESCANOR_NICE=10 (0 = off), ESCANOR_GUARD_INTERVAL_SEC=15,
 * ESCANOR_IDLE_CLOSE_MIN=30 (0 = never).
 */
export function guardLimitsFrom(env: Record<string, string | undefined>): GuardLimits {
  const d = DEFAULT_GUARD_LIMITS;
  return {
    enabled: env.ESCANOR_RESOURCE_GUARD?.trim() !== '0',
    minFreeMemPercent: num(env.ESCANOR_MIN_FREE_MEM_PERCENT, d.minFreeMemPercent, 0, 90),
    criticalFreeMemPercent: num(env.ESCANOR_CRITICAL_FREE_MEM_PERCENT, d.criticalFreeMemPercent, 0, 90),
    maxMemoryMb: num(env.ESCANOR_MAX_MEMORY_MB, d.maxMemoryMb, 0),
    maxLoadPerCore: num(env.ESCANOR_MAX_LOAD_PER_CORE, d.maxLoadPerCore, 0.1),
    maxCpuPercent: num(env.ESCANOR_MAX_CPU_PERCENT, d.maxCpuPercent, 5, 100),
    nice: Math.round(num(env.ESCANOR_NICE, d.nice, 0, 19)),
    sustain: d.sustain,
    intervalMs: Math.max(1, num(env.ESCANOR_GUARD_INTERVAL_SEC, d.intervalMs / 1000, 1)) * 1000,
    idleCloseMs: num(env.ESCANOR_IDLE_CLOSE_MIN, d.idleCloseMs / 60_000, 0) * 60_000,
  };
}

/** One look at the machine. `childCpuMs` is the CPU time our processes have used in total (null where unknown). */
export type Sample = {
  at: number;
  totalMem: number;
  /** Memory a program can still get without swapping; null where the system does not say. */
  availMem: number | null;
  load1: number;
  cores: number;
  /** Everything started by this agent (its descendants): pids, total memory in bytes. */
  childPids: number[];
  childRss: number;
  childCpuMs: number | null;
};

export type GuardReason = 'memory' | 'our-memory' | 'load' | 'our-cpu';
export type GuardState = { paused: boolean; reason: GuardReason | null; critical: boolean };

/** The words the person sees for why work waits. */
export function reasonText(reason: GuardReason | null): string {
  return reason === 'memory' || reason === 'our-memory' ? 'this computer is short of memory' : 'this computer is busy';
}

export const BUSY_NOTICE = (reason: GuardReason | null): string =>
  `Waiting: ${reasonText(reason)}. It starts by itself when it has room; nothing is lost.`;

export class ResourceGuard {
  private _state: GuardState = { paused: false, reason: null, critical: false };
  private latched = new Set<GuardReason>();
  private over = { load: 0, cpu: 0 };
  private lastCpu: { at: number; ms: number } | null = null;
  private niced = new Set<number>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private listeners: ((state: GuardState, prev: GuardState) => void)[] = [];

  constructor(
    readonly limits: GuardLimits = DEFAULT_GUARD_LIMITS,
    private sampler: () => Sample = () => systemSample(),
    private renice: (pid: number, nice: number) => void = reniceProcess,
  ) {}

  get state(): GuardState {
    return this._state;
  }

  onChange(fn: (state: GuardState, prev: GuardState) => void): void {
    this.listeners.push(fn);
  }

  start(): void {
    if (this.timer || !this.limits.enabled) return;
    this.timer = setInterval(() => this.tick(), this.limits.intervalMs);
    this.timer.unref?.();
    this.tick();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /** Look once, decide, lower our processes' priority, tell the listeners (every time: they also do chores while paused). */
  tick(): GuardState {
    if (!this.limits.enabled) return this._state;
    let s: Sample;
    try {
      s = this.sampler();
    } catch {
      return this._state; // cannot look: nothing changes
    }
    const prev = this._state;
    this._state = this.evaluate(s);
    this.lowerPriority(s.childPids);
    for (const fn of this.listeners) {
      try {
        fn(this._state, prev);
      } catch (err) {
        console.error('Resource guard listener failed', err);
      }
    }
    return this._state;
  }

  private evaluate(s: Sample): GuardState {
    const l = this.limits;
    const set = (r: GuardReason, on: boolean) => (on ? this.latched.add(r) : this.latched.delete(r));
    // Memory the machine has left, in percent.
    const availPct = s.availMem !== null && s.totalMem > 0 ? (s.availMem / s.totalMem) * 100 : null;
    if (availPct !== null) {
      if (availPct < l.minFreeMemPercent) set('memory', true);
      else if (availPct >= l.minFreeMemPercent + RESUME_MARGIN) set('memory', false);
    }
    // Memory our own processes use.
    const cap = l.maxMemoryMb > 0 ? l.maxMemoryMb * 1024 * 1024 : Math.max(1024 * 1024 * 1024, s.totalMem * 0.5);
    if (s.childRss > cap) set('our-memory', true);
    else if (s.childRss < cap * 0.85) set('our-memory', false);
    // The machine's load, per core, sustained.
    const perCore = s.cores > 0 ? s.load1 / s.cores : 0;
    this.over.load = perCore > l.maxLoadPerCore ? this.over.load + 1 : perCore < l.maxLoadPerCore * RESUME_FRACTION ? 0 : this.over.load;
    if (this.over.load >= l.sustain) set('load', true);
    else if (perCore < l.maxLoadPerCore * RESUME_FRACTION) set('load', false);
    // The CPU our own processes use, as a share of the whole machine, between two looks.
    if (s.childCpuMs !== null && s.cores > 0) {
      if (this.lastCpu && s.at > this.lastCpu.at) {
        const pct = ((s.childCpuMs - this.lastCpu.ms) / ((s.at - this.lastCpu.at) * s.cores)) * 100;
        this.over.cpu = pct > l.maxCpuPercent ? this.over.cpu + 1 : pct < l.maxCpuPercent * RESUME_FRACTION ? 0 : this.over.cpu;
        if (this.over.cpu >= l.sustain) set('our-cpu', true);
        else if (pct < l.maxCpuPercent * RESUME_FRACTION) set('our-cpu', false);
      }
      this.lastCpu = { at: s.at, ms: s.childCpuMs };
    }
    const order: GuardReason[] = ['memory', 'our-memory', 'load', 'our-cpu'];
    const reason = order.find((r) => this.latched.has(r)) ?? null;
    return { paused: reason !== null, reason, critical: availPct !== null && availPct < l.criticalFreeMemPercent };
  }

  private lowerPriority(pids: number[]): void {
    if (this.limits.nice <= 0) return;
    const live = new Set(pids);
    for (const pid of this.niced) if (!live.has(pid)) this.niced.delete(pid);
    for (const pid of pids) {
      if (this.niced.has(pid)) continue;
      this.niced.add(pid); // once per process, whether or not it worked (another user's process cannot be changed)
      try {
        this.renice(pid, this.limits.nice);
      } catch {
        // not allowed, or already gone
      }
    }
  }
}

// ---------- looking at the real machine ----------

const PAGE = 4096;
const CLK_TCK = 100;

/** Lowers a process's priority, every thread of it on Linux (setpriority works per thread there). */
export function reniceProcess(pid: number, nice: number): void {
  if (process.platform === 'linux') {
    let tids: number[] = [];
    try {
      tids = readdirSync(`/proc/${pid}/task`).map(Number).filter((n) => Number.isInteger(n) && n > 0);
    } catch {
      // gone
    }
    for (const tid of tids.length ? tids : [pid]) {
      try {
        setPriority(tid, nice);
      } catch {
        // one thread may have just ended
      }
    }
    return;
  }
  setPriority(pid, nice);
}

type ProcRow = { pid: number; ppid: number; rss: number; cpuMs: number };

/** Parses one /proc/<pid>/stat line: the command (field 2) may hold spaces and brackets, so count after the last ')'. */
export function parseProcStat(pid: number, stat: string): ProcRow | null {
  const rest = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
  const ppid = Number(rest[1]);
  const utime = Number(rest[11]);
  const stime = Number(rest[12]);
  const rssPages = Number(rest[21]);
  if (![ppid, utime, stime, rssPages].every(Number.isFinite)) return null;
  return { pid, ppid, rss: Math.max(0, rssPages) * PAGE, cpuMs: ((utime + stime) / CLK_TCK) * 1000 };
}

/** Everything below `root` in the process tree (children, grandchildren...), from the rows of all processes. */
export function descendants(rows: ProcRow[], root: number): ProcRow[] {
  const byParent = new Map<number, ProcRow[]>();
  for (const r of rows) byParent.set(r.ppid, [...(byParent.get(r.ppid) ?? []), r]);
  const out: ProcRow[] = [];
  const seen = new Set<number>([root]);
  const stack = [root];
  while (stack.length) {
    for (const c of byParent.get(stack.pop()!) ?? []) {
      if (seen.has(c.pid)) continue;
      seen.add(c.pid);
      out.push(c);
      stack.push(c.pid);
    }
  }
  return out;
}

function procRows(): ProcRow[] {
  if (process.platform === 'linux') {
    const rows: ProcRow[] = [];
    for (const name of readdirSync('/proc')) {
      if (!/^\d+$/.test(name)) continue;
      try {
        const row = parseProcStat(Number(name), readFileSync(`/proc/${name}/stat`, 'utf8'));
        if (row) rows.push(row);
      } catch {
        // ended while we looked
      }
    }
    return rows;
  }
  if (process.platform === 'darwin') {
    const out = execFileSync('ps', ['-A', '-o', 'pid=,ppid=,rss='], { encoding: 'utf8', timeout: 5000 });
    return out
      .split('\n')
      .map((l) => l.trim().split(/\s+/).map(Number))
      .filter((p) => p.length === 3 && p.every(Number.isFinite))
      .map(([pid, ppid, kb]) => ({ pid, ppid, rss: kb * 1024, cpuMs: Number.NaN }));
  }
  return [];
}

/** MemAvailable from /proc/meminfo's text, in bytes; null when it is not there. */
export function memAvailableFrom(meminfo: string): number | null {
  const m = /^MemAvailable:\s+(\d+)\s+kB/m.exec(meminfo);
  return m ? Number(m[1]) * 1024 : null;
}

export function systemSample(root: number = process.pid, now: () => number = Date.now): Sample {
  let availMem: number | null = null;
  if (process.platform === 'linux') {
    try {
      availMem = memAvailableFrom(readFileSync('/proc/meminfo', 'utf8'));
    } catch {
      // no /proc
    }
  } else if (process.platform === 'win32') availMem = freemem();
  let kids: ProcRow[] = [];
  try {
    kids = descendants(procRows(), root);
  } catch {
    // ps missing: no reading of our own use
  }
  const cpu = kids.every((k) => Number.isFinite(k.cpuMs)) && process.platform === 'linux';
  return {
    at: now(),
    totalMem: totalmem(),
    availMem,
    load1: loadavg()[0] ?? 0,
    cores: cpus().length || 1,
    childPids: kids.map((k) => k.pid),
    childRss: kids.reduce((a, k) => a + k.rss, 0),
    childCpuMs: cpu ? kids.reduce((a, k) => a + k.cpuMs, 0) : null,
  };
}

// ---------- clearing what the agent itself left behind ----------

/** Files the agent writes whole through a temp name (then renames); one left over from a crash is never read again. */
const OWN_TEMP_FILES = /^(?:sessions|queue|seen-inputs|terminal-resume)\.json\.tmp$|^outbox\.jsonl\.tmp$/;
/** The folder the agent makes for the pictures of one turn (cliEngine.ts); named by the agent, in the system temp folder. */
const OWN_IMAGE_DIR = /^escanor-img-[A-Za-z0-9]{6}$/;

/**
 * Deletes only what this agent provably wrote and nothing reads any more: leftover `.tmp` files of its own state files in its data
 * folder (older than `maxAgeMs`), and its own picture folders in the system temp folder (older than a day, owned by this user, not
 * links). Never a chat's history, the registry, the queue, the outbox or anything the person made. Returns what it removed.
 */
export function cleanOwnLeftovers(
  dataDir: string,
  o: { now?: number; tmpRoot?: string; maxAgeMs?: number; imageMaxAgeMs?: number; uid?: number | null } = {},
): string[] {
  const now = o.now ?? Date.now();
  const removed: string[] = [];
  const old = (mtimeMs: number, age: number) => now - mtimeMs > age;
  try {
    for (const name of readdirSync(dataDir)) {
      if (!OWN_TEMP_FILES.test(name)) continue;
      const p = join(dataDir, name);
      try {
        const st = lstatSync(p);
        if (!st.isFile() || !old(st.mtimeMs, o.maxAgeMs ?? 3_600_000)) continue;
        rmSync(p, { force: true });
        removed.push(p);
      } catch {
        // busy or gone
      }
    }
  } catch {
    // no data folder yet
  }
  const uid = o.uid === undefined ? (typeof process.getuid === 'function' ? process.getuid() : null) : o.uid;
  const root = o.tmpRoot ?? tmpdir();
  try {
    for (const name of readdirSync(root)) {
      if (!OWN_IMAGE_DIR.test(name)) continue;
      const p = join(root, name);
      try {
        const st = lstatSync(p);
        if (!st.isDirectory() || (uid !== null && st.uid !== uid) || !old(st.mtimeMs, o.imageMaxAgeMs ?? 86_400_000)) continue;
        rmSync(p, { recursive: true, force: true });
        removed.push(p);
      } catch {
        // busy or gone
      }
    }
  } catch {
    // no temp folder
  }
  return removed;
}
