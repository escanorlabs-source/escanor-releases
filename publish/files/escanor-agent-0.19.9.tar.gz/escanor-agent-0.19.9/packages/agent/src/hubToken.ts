import { readFileSync } from 'node:fs';

/**
 * The hub token: from HUB_TOKEN_FILE when set (Escanor's company machines: a file only the agent's user can read, so no chat
 * can read it), else HUB_TOKEN.
 */
export function hubTokenFrom(env: NodeJS.ProcessEnv, read: (path: string) => string = (p) => readFileSync(p, 'utf8')): string {
  const file = env.HUB_TOKEN_FILE?.trim();
  const token = file ? read(file).trim() : env.HUB_TOKEN?.trim();
  if (!token) throw new Error('Missing required env var HUB_TOKEN (or HUB_TOKEN_FILE)');
  return token;
}
