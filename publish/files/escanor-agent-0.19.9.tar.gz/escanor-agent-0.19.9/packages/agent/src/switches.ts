/**
 * Feature switches in the agent's environment. A switch that is on by default is turned off only by an explicit "0", "false",
 * "off" or "no"; one that is off by default is turned on only by "1", "true", "on" or "yes". Anything else (unset, empty, a typo)
 * keeps the default, so nobody has to add a line to the agent's settings for a feature to work.
 */
const OFF = new Set(['0', 'false', 'off', 'no']);
const ON = new Set(['1', 'true', 'on', 'yes']);

export function switchOn(raw: string | undefined, defaultOn: boolean): boolean {
  const v = raw?.trim().toLowerCase() ?? '';
  if (OFF.has(v)) return false;
  if (ON.has(v)) return true;
  return defaultOn;
}

/** An Escanor worker container (ESCANOR_MANAGED=1): features that act on the person's own Claude logins stay off there by default. */
export const isManaged = (env: NodeJS.ProcessEnv): boolean => env.ESCANOR_MANAGED === '1';
