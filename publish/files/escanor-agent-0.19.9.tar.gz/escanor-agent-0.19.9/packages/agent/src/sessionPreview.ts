import { oneLine } from './redact.js';

export type SessionSource = 'terminal' | 'desktop' | 'agent';
export type SessionPreview = { role: 'prompt' | 'reply'; text: string };

export const PREVIEW_MAX = 160;

/** How a chat was found: imported from a terminal / Desktop Code, else one the agent started (unknown too). */
export function sessionSource(entry: { source?: string }): SessionSource {
  return entry.source === 'terminal' || entry.source === 'desktop' ? entry.source : 'agent';
}

function textOf(content: unknown): string {
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content
    .filter((b): b is { type: 'text'; text: string } => typeof b === 'object' && b !== null && (b as { type?: string }).type === 'text' && typeof (b as { text?: unknown }).text === 'string')
    .map((b) => b.text)
    .join(' ');
}

/** The last prompt / reply a message shows: one line, 160 characters, secrets hidden. null = not a prompt or a reply. */
export function messagePreview(message: unknown): SessionPreview | null {
  if (typeof message !== 'object' || message === null) return null;
  const m = message as { type?: string; message?: { content?: unknown } };
  if (m.type !== 'user' && m.type !== 'assistant') return null;
  const text = oneLine(textOf(m.message?.content), PREVIEW_MAX);
  return text ? { role: m.type === 'user' ? 'prompt' : 'reply', text } : null;
}
