import { readdirSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

/**
 * Claude Code keeps a small record per running process in ~/.claude/sessions/<pid>.json: which session it runs, in which
 * folder, and whether it is working right now (`status`: busy | idle | waiting). This is how the agent tells a terminal chat
 * that is still open (and maybe busy) from one whose terminal was closed, the same way Escanor Desktop does.
 */
export type ClaudeProc = { pid: number; sessionId: string; cwd?: string; status: string };

export function claudeSessionsDir(env: NodeJS.ProcessEnv = process.env): string {
  const config = env.CLAUDE_CONFIG_DIR?.trim();
  return join(config || join(homedir(), '.claude'), 'sessions');
}

export function pidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'EPERM'; // alive, owned by someone else
  }
}

/** The process's start time in clock ticks (field 22 of /proc/<pid>/stat), or null where there is no /proc. */
export function procStartOf(pid: number, read: (path: string) => string = (p) => readFileSync(p, 'utf8')): string | null {
  try {
    const stat = read(`/proc/${pid}/stat`);
    // The command name (field 2) is in brackets and may hold spaces or brackets itself: count fields after the last ')'.
    const rest = stat.slice(stat.lastIndexOf(')') + 2).split(' ');
    return rest[19] ?? null;
  } catch {
    return null;
  }
}

/** Sessions whose Claude process is alive, by session id. A pid reused by another process (other start time) is not one. */
export function readClaudeProcs(
  dir: string = claudeSessionsDir(),
  deps: { alive?: (pid: number) => boolean; startOf?: (pid: number) => string | null } = {},
): Map<string, ClaudeProc> {
  const alive = deps.alive ?? pidAlive;
  const startOf = deps.startOf ?? ((pid: number) => procStartOf(pid));
  const out = new Map<string, ClaudeProc>();
  let names: string[];
  try {
    names = readdirSync(dir);
  } catch {
    return out;
  }
  for (const name of names) {
    if (!/^\d+\.json$/.test(name)) continue;
    let rec: Record<string, unknown>;
    try {
      rec = JSON.parse(readFileSync(join(dir, name), 'utf8'));
    } catch {
      continue; // being rewritten right now, or not a record
    }
    const pid = Number(rec.pid);
    const sessionId = typeof rec.sessionId === 'string' ? rec.sessionId : '';
    if (!Number.isInteger(pid) || pid <= 0 || !sessionId || !alive(pid)) continue;
    if (typeof rec.procStart === 'string') {
      const start = startOf(pid);
      if (start !== null && start !== rec.procStart) continue;
    }
    out.set(sessionId, {
      pid,
      sessionId,
      ...(typeof rec.cwd === 'string' ? { cwd: rec.cwd } : {}),
      status: typeof rec.status === 'string' ? rec.status : 'idle',
    });
  }
  return out;
}
