import { accountsSignature, refreshProfiles, type ClaudeProfile } from './profiles.js';

/** How often the profiles folder is looked at again. */
export const WATCH_MS = 30_000;
/** The account list is announced again at least this often, whatever changed, so the workspace never keeps a stale one. */
export const HEARTBEAT_MS = 15 * 60_000;

export type AccountWatchDeps = {
  profiles: ClaudeProfile[];
  profilesDir: string;
  /** Tell the hub (and so every app) the machine's account list. `changed` is true when the list changed (false: the heartbeat). */
  announce: (changed: boolean) => void;
  now?: () => number;
};

/**
 * Keeps the machine's account list current without a restart: an account added or removed on this computer (a new folder in the
 * profiles folder, a sign-in on the machine itself) is picked up within WATCH_MS and announced; the list is also announced on a slow heartbeat.
 * The list is changed in place, so the session manager and the usage reader use it at once.
 */
export class AccountWatch {
  private announced: string;
  private lastAnnounceAt: number;
  constructor(private d: AccountWatchDeps) {
    this.announced = accountsSignature(d.profiles);
    this.lastAnnounceAt = (d.now ?? Date.now)();
  }

  /** The list was announced by someone else (a hello): remember it, so the next look does not announce it again. */
  noteAnnounced(): void {
    this.announced = accountsSignature(this.d.profiles);
    this.lastAnnounceAt = (this.d.now ?? Date.now)();
  }

  /** One look. Returns true when it announced. */
  tick(): boolean {
    const now = (this.d.now ?? Date.now)();
    try {
      refreshProfiles(this.d.profiles, this.d.profilesDir);
    } catch {
      return false; // the folder was unreadable for a moment: keep what we have
    }
    const sig = accountsSignature(this.d.profiles);
    if (sig === this.announced && now - this.lastAnnounceAt < HEARTBEAT_MS) return false;
    this.d.announce(sig !== this.announced); // announce() is expected to call noteAnnounced()
    this.announced = sig;
    this.lastAnnounceAt = now;
    return true;
  }
}
