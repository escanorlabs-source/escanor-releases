import { spawn } from 'node:child_process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Risk } from '@remote-harness/shared/risk';
import { commandOf } from '../../shared/src/safety.ts';
import { UndoStore } from './undo.ts';

/**
 * The safety layer for the agent's own chats (sessionManager's PreToolUse hook). The check and the copy run in a child process
 * (safetyHook.ts --agent-json), so a copy of a big folder never stalls the agent; holds are decided by the agent (phone Approve).
 */
export type AgentGate =
  | { kind: 'run'; undoId?: string; note?: string }
  | { kind: 'deny'; message: string }
  | { kind: 'hold'; why: string; risk: Risk };

export class SafetyAgent {
  readonly store: UndoStore;
  private readonly loader: string[];
  constructor(o: { store?: UndoStore; version?: string } = {}) {
    this.store = o.store ?? new UndoStore();
    const [maj, min] = (o.version ?? process.versions.node).split('.').map(Number);
    this.loader = maj > 22 || (maj === 22 && min >= 6) ? ['--experimental-strip-types', '--no-warnings'] : ['--import', fileURLToPath(import.meta.resolve('tsx'))];
    try {
      mkdirSync(this.store.root, { recursive: true, mode: 0o700 });
      // The machine-wide hook leaves this agent's own chats to it (safetyHook.ts whoRuns).
      writeFileSync(join(this.store.root, 'agent.pid'), String(process.pid), { mode: 0o600 });
    } catch {
      /* the hook then checks the agent's chats too: twice, never less */
    }
  }

  check(toolName: string, input: unknown, o: { cwd: string; session?: string; env?: NodeJS.ProcessEnv; timeoutMs?: number }): Promise<AgentGate> {
    // Only calls that run a command, or edit a settings file (the guard's own place), need the child.
    const file = String((input && typeof input === 'object' ? (input as Record<string, unknown>).file_path : '') ?? '');
    if (commandOf(input) === null && !/settings(?:\.local)?\.json$/.test(file)) return Promise.resolve({ kind: 'run' });
    const hook = fileURLToPath(new URL('./safetyHook.ts', import.meta.url));
    const fallback: Risk = { kind: 'unreadable', why: 'Escanor could not check this command in time, so a person should look at it first.' };
    return new Promise((resolve) => {
      const child = spawn(process.execPath, [...this.loader, hook, `--root=${this.store.root}`, '--agent-json'], { cwd: tmpdir(), env: o.env ?? process.env, stdio: ['pipe', 'pipe', 'ignore'], windowsHide: true });
      let out = '';
      const timer = setTimeout(() => child.kill('SIGKILL'), o.timeoutMs ?? 150_000);
      child.stdout.on('data', (d) => (out += d));
      child.on('error', () => {
        clearTimeout(timer);
        resolve({ kind: 'hold', why: fallback.why, risk: fallback });
      });
      child.on('close', () => {
        clearTimeout(timer);
        try {
          const r = JSON.parse(out) as { kind: string; why?: string; message?: string; undoId?: string; note?: string; verdict?: { risk?: Risk } };
          if (r.kind === 'run') return resolve({ kind: 'run', ...(r.undoId ? { undoId: r.undoId, note: r.note } : {}) });
          if (r.kind === 'deny') return resolve({ kind: 'deny', message: String(r.message) });
          const why = String(r.why ?? fallback.why);
          return resolve({ kind: 'hold', why, risk: r.verdict?.risk ? { ...r.verdict.risk, why } : { kind: 'delete-folder', why } });
        } catch {
          resolve({ kind: 'hold', why: fallback.why, risk: fallback });
        }
      });
      child.stdin.end(JSON.stringify({ hook_event_name: 'PreToolUse', tool_name: toolName, tool_input: input, cwd: o.cwd, session_id: o.session }));
    });
  }
}
