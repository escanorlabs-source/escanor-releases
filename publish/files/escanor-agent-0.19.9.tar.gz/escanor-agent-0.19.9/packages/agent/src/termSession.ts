import { spawn, type ChildProcess } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import type { Readable, Writable } from 'node:stream';

import { guardReason } from './cliGuard.js';

/**
 * The website's terminal: a shell on this computer that a person types into from the Machines page, through the hub. It only exists
 * after the owner's yes on the phone (jarvis.ts asks; nothing here opens without it). Everything typed is checked at Enter by the same
 * safety guard Autonomous chats use, every command that runs is written to the safety log, and a session ends by itself when nobody
 * types for a while or after a fixed time. The page polls for output (`read`), so the hub needs no new kind of socket.
 */

export type TermChild = { stdout: Readable | null; stderr: Readable | null; stdin: Writable | null; kill(signal?: NodeJS.Signals): boolean; once(event: 'exit' | 'error', cb: (...a: any[]) => void): unknown };
export type TermSpawn = (file: string, args: string[], env: NodeJS.ProcessEnv) => TermChild;

const realSpawn: TermSpawn = (file, args, env) => spawn(file, args, { env, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, cwd: env.HOME ?? env.USERPROFILE }) as ChildProcess;

export const TERM_IDLE_MS = 10 * 60_000;
export const TERM_MAX_MS = 60 * 60_000;
export const MAX_SESSIONS = 2;
const BUFFER_CHARS = 200_000;
const READ_CHARS = 32_000;
const MAX_INPUT = 4096;

/** The program that gives the shell a terminal: `script` (util-linux or BSD), else plain pipes. Windows uses PowerShell on pipes. */
export function shellLaunch(platform: NodeJS.Platform, shell: string): { file: string; args: string[]; pty: boolean } {
  if (platform === 'win32') return { file: 'powershell', args: ['-NoLogo', '-NoProfile'], pty: false };
  if (platform === 'darwin') return { file: 'script', args: ['-q', '/dev/null', shell, '-i'], pty: true };
  return { file: 'script', args: ['-qfc', `${shell} -i`, '/dev/null'], pty: true };
}

type Session = { id: string; child: TermChild; chunks: Array<{ seq: number; text: string }>; size: number; seq: number; line: string; started: number; lastInput: number; closed: boolean; why: string };

export type TermDeps = {
  platform?: NodeJS.Platform;
  shell?: string;
  env?: NodeJS.ProcessEnv;
  spawn?: TermSpawn;
  now?: () => number;
  /** Each command that is run (and each one the guard stopped) goes to the safety log. */
  log: (what: string, why: string) => void;
  idleMs?: number;
  maxMs?: number;
};

export class TermSessions {
  private sessions = new Map<string, Session>();
  constructor(private d: TermDeps) {}

  private now = () => (this.d.now ?? Date.now)();
  get count(): number {
    return [...this.sessions.values()].filter((s) => !s.closed).length;
  }

  /** Starts a shell. Only called after the owner's yes. */
  open(): { ok: true; termId: string; expiresAt: number } | { ok: false; say: string } {
    if (this.count >= MAX_SESSIONS) return { ok: false, say: 'Two terminals are already open on this computer. Close one first.' };
    const platform = this.d.platform ?? process.platform;
    const shell = this.d.shell ?? process.env.SHELL ?? '/bin/bash';
    const launch = shellLaunch(platform, shell);
    let child: TermChild;
    try {
      child = (this.d.spawn ?? realSpawn)(launch.file, launch.args, { ...(this.d.env ?? process.env), TERM: 'dumb', PS1: '\\u@\\h:\\w\\$ ' });
    } catch {
      return { ok: false, say: 'A shell could not be started on this computer.' };
    }
    // The id starts with `term-` so the apps can tell it from a screen view (it is announced to them the same way).
    const id = `term-${randomUUID().replace(/-/g, '').slice(0, 24)}`;
    const t = this.now();
    const s: Session = { id, child, chunks: [], size: 0, seq: 0, line: '', started: t, lastInput: t, closed: false, why: '' };
    this.sessions.set(id, s);
    const push = (text: string) => this.push(s, text);
    child.stdout?.on('data', (b: Buffer) => push(b.toString('utf8')));
    child.stderr?.on('data', (b: Buffer) => push(b.toString('utf8')));
    child.once('exit', () => this.end(id, s.why || 'The shell ended.'));
    child.once('error', () => this.end(id, 'The shell could not run.'));
    this.d.log('terminal', 'a terminal was opened from the website after the owner said yes');
    return { ok: true, termId: id, expiresAt: t + (this.d.maxMs ?? TERM_MAX_MS) };
  }

  private push(s: Session, text: string): void {
    s.seq += 1;
    s.chunks.push({ seq: s.seq, text });
    s.size += text.length;
    while (s.size > BUFFER_CHARS && s.chunks.length > 1) s.size -= s.chunks.shift()!.text.length;
  }

  /**
   * What the person typed. Characters go to the shell as typed (so the shell's own editing works); at Enter the line is checked by the
   * safety guard first. A line the guard stops is wiped from the shell's input and the person is told why; a line that runs is logged.
   */
  send(termId: string, data: unknown): { ok: true } | { ok: false; say: string } {
    const s = this.sessions.get(termId);
    if (!s || s.closed) return { ok: false, say: 'That terminal has ended. Open a new one.' };
    if (typeof data !== 'string' || data.length === 0 || data.length > MAX_INPUT) return { ok: false, say: 'Nothing to send.' };
    s.lastInput = this.now();
    for (const ch of data) {
      if (ch === '\r' || ch === '\n') {
        const line = s.line.trim();
        s.line = '';
        const why = line ? guardReason('Bash', { command: line }) : null;
        if (why) {
          s.child.stdin?.write('\x15'); // wipe what was typed
          this.push(s, `\r\n[Escanor stopped that command: ${why}]\r\n`);
          this.d.log('terminal', `stopped by the safety guard: ${why}`.slice(0, 200));
          continue;
        }
        if (line) this.d.log(`terminal ${line.slice(0, 300)}`, 'ran in the website terminal');
        s.child.stdin?.write('\r');
      } else if (ch === '\x7f' || ch === '\b') {
        s.line = s.line.slice(0, -1);
        s.child.stdin?.write(ch);
      } else if (ch === '\x15' || ch === '\x03') {
        s.line = '';
        s.child.stdin?.write(ch);
      } else {
        if (ch >= ' ') s.line += ch;
        s.child.stdin?.write(ch);
      }
    }
    return { ok: true };
  }

  /** Output after `after` (a sequence number the page got last, 0 at the start), at most 32,000 characters. */
  read(termId: string, after: number): { ok: true; out: string; seq: number; closed: boolean; why: string } | { ok: false; say: string } {
    const s = this.sessions.get(termId);
    if (!s) return { ok: false, say: 'That terminal has ended. Open a new one.' };
    let out = '';
    let seq = after;
    for (const c of s.chunks) {
      if (c.seq <= after) continue;
      if (out.length + c.text.length > READ_CHARS && out) break;
      out += c.text;
      seq = c.seq;
    }
    return { ok: true, out, seq, closed: s.closed && seq >= s.seq, why: s.why };
  }

  close(termId: string, why = 'The owner closed the terminal.'): boolean {
    const s = this.sessions.get(termId);
    if (!s || s.closed) return false;
    s.why = why;
    try {
      s.child.kill('SIGKILL');
    } catch {
      // already gone
    }
    this.end(termId, why);
    return true;
  }

  private end(termId: string, why: string): void {
    const s = this.sessions.get(termId);
    if (!s || s.closed) return;
    s.closed = true;
    s.why = why;
    this.push(s, `\r\n[${why}]\r\n`);
    this.d.log('terminal', `the terminal ended: ${why}`.slice(0, 200));
    // Kept a minute so the page can read the last lines, then forgotten.
    setTimeout(() => this.sessions.delete(termId), 60_000).unref?.();
  }

  /** Idle or too long: closed. Called now and then. */
  sweep(): void {
    const t = this.now();
    for (const s of [...this.sessions.values()]) {
      if (s.closed) continue;
      if (t - s.lastInput > (this.d.idleMs ?? TERM_IDLE_MS)) this.close(s.id, 'Closed: nobody typed for a while.');
      else if (t - s.started > (this.d.maxMs ?? TERM_MAX_MS)) this.close(s.id, 'Closed: the time for this terminal ran out.');
    }
  }

  closeAll(why: string): void {
    for (const s of [...this.sessions.values()]) this.close(s.id, why);
  }

  has(termId: string): boolean {
    const s = this.sessions.get(termId);
    return !!s && !s.closed;
  }
}
