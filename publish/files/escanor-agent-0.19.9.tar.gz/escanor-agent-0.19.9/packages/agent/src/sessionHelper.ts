import { connect, type Socket } from 'node:net';

/**
 * The agent's side of the small root program that signs the person in at the login screen after a restart (scripts/unlock/session-helper,
 * installed with Escanor by the installer's privileged step). The agent never gets root: it talks to the helper over a socket only this
 * computer's user can open, and the helper checks the PHONE'S signature itself, so nothing running as the user can make it sign anyone
 * in without a fresh fingerprint yes. Protocol: one JSON line out, one JSON line back (docs/UNLOCK.md).
 */

export const HELPER_SOCKET = '/run/escanor/session-helper.sock';

export type HelperSession = 'login_screen' | 'locked' | 'unlocked' | 'none' | 'unknown';
export type HelperStatus = { version: number; kind: string; dm: string; user: string; enrolled: number; session: HelperSession };
export type HelperKey = { publicKey: string; name: string };
export type HelperApproval = { purpose: string; subject: string; nonce: string; machine: string; keyId: string; signature: string };
export type HelperAnswer = { ok: boolean; say: string; code?: string };

export interface SessionHelperApi {
  /** Null when the helper is not installed or does not answer. */
  status(): Promise<HelperStatus | null>;
  enroll(keys: HelperKey[], approval?: HelperApproval): Promise<HelperAnswer>;
  login(approval: HelperApproval): Promise<HelperAnswer>;
  disable(): Promise<HelperAnswer>;
}

const MAX_REPLY = 16_000;
const SESSIONS: ReadonlySet<string> = new Set(['login_screen', 'locked', 'unlocked', 'none', 'unknown']);

export class SessionHelper implements SessionHelperApi {
  constructor(private o: { socket?: string; connectImpl?: (path: string) => Socket } = {}) {}

  private call(req: Record<string, unknown>, timeoutMs: number): Promise<Record<string, unknown> | null> {
    const path = this.o.socket ?? HELPER_SOCKET;
    return new Promise((resolve) => {
      let done = false;
      let buf = '';
      let sock: Socket;
      const finish = (v: Record<string, unknown> | null) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        try {
          sock?.destroy();
        } catch {
          /* closed already */
        }
        resolve(v);
      };
      const timer = setTimeout(() => finish(null), timeoutMs);
      timer.unref?.();
      try {
        sock = (this.o.connectImpl ?? connect)(path);
      } catch {
        return finish(null);
      }
      sock.setEncoding('utf8');
      sock.on('connect', () => sock.write(`${JSON.stringify(req)}\n`));
      sock.on('data', (c: string) => {
        buf += c;
        if (buf.length > MAX_REPLY) finish(null);
        const nl = buf.indexOf('\n');
        if (nl >= 0) {
          try {
            const j = JSON.parse(buf.slice(0, nl)) as unknown;
            finish(j && typeof j === 'object' && !Array.isArray(j) ? (j as Record<string, unknown>) : null);
          } catch {
            finish(null);
          }
        }
      });
      sock.on('error', () => finish(null));
      sock.on('close', () => finish(null));
    });
  }

  async status(): Promise<HelperStatus | null> {
    const r = await this.call({ op: 'status' }, 5_000);
    if (!r || r.ok !== true) return null;
    return {
      version: typeof r.version === 'number' ? r.version : 1,
      kind: typeof r.kind === 'string' ? r.kind.slice(0, 20) : 'unknown',
      dm: typeof r.dm === 'string' ? r.dm.slice(0, 20) : 'none',
      user: typeof r.user === 'string' ? r.user.slice(0, 64) : '',
      enrolled: typeof r.enrolled === 'number' && r.enrolled >= 0 ? Math.floor(r.enrolled) : 0,
      session: typeof r.session === 'string' && SESSIONS.has(r.session) ? (r.session as HelperSession) : 'unknown',
    };
  }

  private answer(r: Record<string, unknown> | null, whenDown: string): HelperAnswer {
    if (!r) return { ok: false, say: whenDown, code: 'no_helper' };
    const say = typeof r.say === 'string' ? r.say : typeof r.why === 'string' ? r.why : r.ok === true ? 'Done.' : 'The sign-in helper refused.';
    return { ok: r.ok === true, say: say.slice(0, 400), ...(typeof r.code === 'string' ? { code: r.code.slice(0, 40) } : {}) };
  }

  async enroll(keys: HelperKey[], approval?: HelperApproval): Promise<HelperAnswer> {
    return this.answer(await this.call({ op: 'enroll', keys, ...(approval ? { approval } : {}) }, 15_000), 'The sign-in helper is not running on this computer.');
  }

  async login(approval: HelperApproval): Promise<HelperAnswer> {
    // The helper waits up to 90 seconds for the desktop to come up.
    return this.answer(await this.call({ op: 'login', approval }, 120_000), 'The sign-in helper is not installed or not running on this computer. Update Escanor on it.');
  }

  async disable(): Promise<HelperAnswer> {
    return this.answer(await this.call({ op: 'disable' }, 10_000), 'The sign-in helper is not running on this computer.');
  }
}
