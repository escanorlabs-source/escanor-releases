import { randomUUID } from 'node:crypto';
import os from 'node:os';
import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { AgentDeviceResult, DeviceAsk, DeviceAskPurpose, HubDeviceApproval, HubDeviceCommand, HubScreenClose, HubScreenIn, HubScreenOpen } from '@remote-harness/shared';
import { parseAction, runComputerAction, safeUrl, type Deps } from './computerControl.js';
import { switchOn } from './switches.js';
import { checkYes, AskBook, ASK_TTL_MS, KeyStore, PairingCode } from './jarvisKeys.js';
import type { AccountTrust, Auth, Decision } from './accountTrust.js';
import { wakeEpoch } from './wakeRoutes.js';
import { isBrowser, type FocusHelper, type WinInfo } from './focusHelper.js';
import { AwakeLease, closeNotice, goFullscreen, notice, openPage, takeScreenshot, unlockScreen, type ScreenDeps } from './screenControl.js';
import { runCheck } from './machineChecks.js';
import { ALL_FEATURES, buildPlan, checkDeps, describePlan, detectHost, runPlan } from './firstRunDeps.js';
import { TermSessions } from './termSession.js';
import { LiveScreen, describeEvents, parseEvents, screenLocked } from './liveControl.js';
import type { SigninControl, SigninPatch } from './signinControl.js';
import { MAX_WINDOW_MINUTES, cleanSource, cleanWhy, describeUse, parseUse, subjectOfUse, type SigninUse, type UseSource } from './signinApproval.js';
import type { UseProof } from './signinBroker.js';
import type { HelperApproval, SessionHelperApi } from './sessionHelper.js';
import { screenState, unlockStatus, type UnlockStatus } from './unlockStatus.js';
import { createHash } from 'node:crypto';
import { DefaultPolicy, type AccessPolicy, type ViewDecision } from './accessPolicy.js';
import { ScreenStreams } from './remoteDesktop.js';
import { QuietNotifications, avData, avSay, checkAv, type PrepDeps } from './meetingPrep.js';
import type { SafetyEvent } from './safetyLog.js';
import { receiveHandoff, type ReceiveDeps } from './handoffReceive.js';
import type { PresenceReport } from './presence.js';
import { CLIP_MISSING_SAY, MAX_CLIP_READ, clearClipboard, readClipboard, type ClipDeps } from './clipboardControl.js';
import { isK8sAction, type K8sAction, type K8sResult } from './k8sSecrets.js';

/**
 * Jarvis phase 2: direct commands from the owner's phone, with no model turn. The hub hands this a `device_command` (an action and
 * its arguments); the answer is one `device_result` in plain words, normally well under a second.
 *
 * The rules this file keeps, in the order they are checked:
 *  1. Remote control must be ON for this computer (a per-computer switch: ON by default on the owner's own laptop or desktop, OFF
 *     on anything shared or managed until the owner turns it on, which itself needs a fingerprint yes).
 *  2. Only these actions exist; every argument is checked again here. Nothing is a shell command and nothing the phone sends is run as text.
 *  3. Things that let someone in (unlock the screen, sign in to a site, see the screen, turn Remote control on) are HELD until the
 *     phone answers with a fingerprint yes signed by a phone this computer trusted at pairing (jarvisKeys.ts). Each ask is one use
 *     and runs out in two minutes. Without a paired phone they are refused, not asked.
 *  4. Payments are never done here at all. Mail is only ever opened for the person to press Send (computerControl compose_mail);
 *     sending stays on the held mail route.
 *  5. Every command and every refusal is written to the safety log in plain words. A password never is.
 */

export const REMOTE_ENV = 'ESCANOR_REMOTE_CONTROL';
export const TYPE_ENV = 'ESCANOR_JARVIS_TYPE_SECRETS';
export const VIEW_MINUTES = 10;
const MAX_AWAKE_MINUTES = 240;

/** The per-computer Remote control switch: the environment wins, then what the owner set from the phone, then the default. */
export class RemoteSwitch {
  constructor(private file: string, private env: NodeJS.ProcessEnv, private ownComputer: boolean, private envName: string = REMOTE_ENV) {}

  enabled(): boolean {
    const raw = this.env[this.envName]?.trim().toLowerCase();
    if (raw && ['0', 'false', 'off', 'no', '1', 'true', 'on', 'yes'].includes(raw)) return switchOn(raw, false);
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as { enabled?: unknown };
      if (typeof j.enabled === 'boolean') return j.enabled;
    } catch {
      /* not set yet */
    }
    return this.ownComputer;
  }

  /** The environment decides when it says on or off: the phone cannot override what the owner set for this computer. */
  lockedByEnv(): boolean {
    const raw = this.env[this.envName]?.trim().toLowerCase();
    return !!raw && ['0', 'false', 'off', 'no', '1', 'true', 'on', 'yes'].includes(raw);
  }

  set(enabled: boolean): void {
    mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
    const tmp = `${this.file}.tmp`;
    writeFileSync(tmp, JSON.stringify({ enabled }), { mode: 0o600 });
    renameSync(tmp, this.file);
  }
}

type Pending = ({ kind: 'unlock'; login?: boolean } | { kind: 'unlock_setup'; keyIds: string[] } | { kind: 'enable_signin'; patch: SigninPatch } | { kind: 'signin_use'; use: SigninUse; why: string; source: UseSource } | { kind: 'signin_window'; minutes: number } | { kind: 'chat_signin_window'; minutes: number } | { kind: 'schedule_wake'; epoch: number } | { kind: 'signin'; url: string; host: string } | { kind: 'view' } | { kind: 'terminal' } | { kind: 'deps_install'; features?: string[] } | { kind: 'enable' } | { kind: 'enable_typing' } | { kind: 'type_login'; host: string; what: TypeWhat; windowId: number; wmClass: string }) & { also?: Auth[] };
type TypeWhat = 'both' | 'user' | 'password';
const TYPE_WHATS: ReadonlySet<string> = new Set(['both', 'user', 'password']);

export type JarvisDeps = {
  /** The id the signed yes names (the agent's machine id, else its name). */
  machine: string;
  /** What the computer is called, for the person's messages. */
  name: string;
  keys: KeyStore;
  remote: RemoteSwitch;
  screen?: ScreenDeps;
  computer?: Deps;
  /** The clipboard programs for `clipboard` (clipboardControl.ts); tests hand in their own runner. */
  clip?: ClipDeps;
  log: (e: SafetyEvent) => void;
  sendAsk: (ask: DeviceAsk) => void;
  sendAskDone: (askId: string) => void;
  /** Shows the pairing code on this computer's own screen. */
  showCode: (code: string) => void;
  /** The site's saved sign-in (Escanor's vault, else the OS keyring): fetched only after a yes, and only when typing is on. */
  credentials?: (host: string) => Promise<{ user: string; password: string } | null>;
  /** Types text into the focused window (xdotool/wtype/ydotool, SendKeys): only used when `typeSecrets` is on. Returns false if it cannot. */
  type?: (text: string) => Promise<boolean>;
  /** Is there any way to type here? Asked before the stored sign-in is fetched. */
  canType?: () => Promise<boolean>;
  /** The "type saved sign-ins" switch (ESCANOR_JARVIS_TYPE_SECRETS, else what the owner set from the phone). Off by default. */
  typing?: RemoteSwitch;
  /** Which window is in front, bring one forward, full screen (focusHelper.ts). */
  focus?: Pick<FocusHelper, 'status' | 'windows' | 'active' | 'focus' | 'fullscreen' | 'newestBrowser'>;
  /** "Let Escanor sign in for me" (signinControl.ts): the owner's allow list, usage log and the use of a saved secret. Every use needs a fingerprint yes. */
  signin?: SigninControl;
  /** The small root program that signs the person in at the login screen after a restart (sessionHelper.ts). Absent or not installed: "Not set up". */
  helper?: SessionHelperApi;
  /** Where this computer notes which phones it last handed the sign-in helper (key ids only, nothing secret). Absent: kept in memory. */
  helperSyncFile?: string;
  /** laptop, desktop, server, vm, personal, device, unknown (what this computer told the hub about itself). */
  machineKind?: string;
  /** No desktop here right now (a server, or a laptop at its login screen after a restart): only unlocking and signing in are taken. */
  limited?: boolean;
  /** The person's account: checks fingerprint yeses for phones not paired here, and holds the access policy. */
  account?: AccountTrust;
  /** The ways this computer can be woken (wakeRoutes.ts), for the phone to show. */
  wakeRoutes?: () => Promise<string[]>;
  /** Wake at a time (the clock chip's alarm), kept so it is set again just before the computer sleeps. */
  wakeAt?: { set(epoch: number | null): void; alarm(epoch: number): Promise<boolean> };
  /** Where the last screen help pointed (screenHelp.ts), drawn over the phone's live picture; null when nothing is pointed at. */
  highlight?: () => { x: number; y: number; w: number; h: number; label: string } | null;
  now?: () => number;
  awake?: AwakeLease;
  /** The live view and control session (tests hand in their own). */
  live?: LiveScreen;
  /** The owner's access policy (accessPolicy.ts): who may look, for how long, how strong the proof. Default: a fingerprint yes, 10 minutes, renewed while in use. */
  viewPolicy?: AccessPolicy;
  /** Remote desktop (remoteDesktop.ts): where text for a viewer and binary pictures go (the hub). Without them only the one-picture-at-a-time view exists. */
  sendScreenText?: (viewId: string, viewer: string | undefined, msg: Record<string, unknown>) => void;
  sendFrame?: (frame: Buffer) => boolean;
  /** A view was granted / ended: the hub tells the other apps. */
  sendView?: (viewId: string, expiresAt: number) => void;
  sendViewEnd?: (viewId: string, why: string) => void;
  /** Tests hand in their own. */
  streams?: ScreenStreams;
  /** The website terminal's shells (termSession.ts); tests hand in their own. */
  terms?: TermSessions;
  /** Device mesh: where received links, text and files go (handoffReceive.ts); tests hand in their own. */
  receive?: ReceiveDeps;
  /** Device mesh: the latest reading of whether the person is at this computer (presence.ts). */
  presence?: () => PresenceReport | undefined;
  /** Notifications silenced for a meeting (goal agent); kept in a small file so a restart still puts them back. */
  quiet?: QuietNotifications;
  /** How sound and camera are checked (tests hand in their own). */
  prep?: PrepDeps;
  /** Kubernetes Secrets through this computer's kubectl (k8sSecrets.ts): names, set or remove one key, put one back. No value passes through here. */
  k8s?: { handle(action: K8sAction, args: Record<string, unknown>): Promise<K8sResult> };
  /** Asks the Escanor app that started this agent to install its newest version (the Machines page's Update button). False or absent: no app did. */
  requestUpdate?: () => boolean;
};

type AskExtra = { what?: string; why?: string; source?: UseSource };

type ViewState = { until: number; hardEnd: number; decision: Extract<ViewDecision, { allow: true }> };

/** Feature names from the app; anything unknown is dropped, and none means all. */
const depsFeatures = (v: unknown): string[] | undefined => {
  const f = Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string' && ALL_FEATURES.includes(x)) : [];
  return f.length ? f : undefined;
};

const clampMinutes = (v: unknown, dflt: number): number => {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) && n >= 1 ? Math.min(Math.floor(n), MAX_AWAKE_MINUTES) : dflt;
};

const COMPUTER_ACTIONS = new Set(['open_url', 'open_app', 'play_youtube', 'media', 'volume', 'lock_screen', 'compose_mail']);
/** Allowed while Remote control is off: asking how things are, pairing a phone at the computer, and the switch itself. */
const WHEN_OFF = new Set(['status', 'pair_phone', 'set_remote_control', 'presence', 'signin_status', 'signin_check', 'set_signin', 'signin_use', 'set_signin_window', 'set_chat_signin_window']);
/** What a computer with no desktop (a server, or a laptop nobody is signed in on) still takes: it can be unlocked and sign things in. */
const LIMITED_OK = new Set(['status', 'pair_phone', 'set_remote_control', 'presence', 'unlock_computer', 'unlock_setup', 'signin_status', 'signin_check', 'signin_use', 'set_signin', 'set_signin_window', 'set_chat_signin_window', 'schedule_wake', 'check', 'deps_check', 'deps_install', 'term_open', 'term_send', 'term_read', 'term_close']);
/** Never held by the account's access policy and needing no fingerprint of their own: they only read, or make things safer. */
const NO_POLICY = ['status', 'update_app', 'lock_screen', 'release_awake', 'view_stop', 'input', 'clipboard', 'signin_status', 'check', 'deps_check', 'term_send', 'term_read', 'term_close'];

/** The most phones the sign-in helper keeps (scripts/unlock/session-helper MAX_KEYS). */
const HELPER_MAX_KEYS = 10;
export type HelperSync = 'synced' | 'same' | 'later' | 'failed' | 'no_helper' | 'no_screen' | 'no_phone';
/** Said when the login screen does not know this phone yet (its key changed after the helper was set up). */
export const notSetUpYet = (name: string): string =>
  `This phone is not set up to sign you in at ${name}'s login screen yet. It sets itself up the next time you are signed in on ${name} with the screen unlocked and Escanor running (within a few minutes, or at once when you open Unlock / Turn on for ${name} in the app). After that this works.`;

const hostOf = (url: string): string => {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return '';
  }
};

export class Jarvis {
  private asks = new AskBook<Pending>();
  /** AIs and automations waiting for the fingerprint on an ask they made (requestUse). */
  private waiters = new Map<string, (r: { ok: boolean; say: string }) => void>();
  private pairing = new PairingCode();
  private views = new Map<string, ViewState>();
  /** What the access policy wants shown besides the fingerprint, by command (read when the ask is made). */
  private policyAlso = new Map<string, Auth[]>();
  /** The last answer the account gave for each action (used for a day if the account cannot be reached). */
  private lastDecision = new Map<string, { at: number; d: Decision }>();
  /** The notice on the laptop's screen for each live view (its id, where the desktop gives one). */
  private notices = new Map<string, number | null>();
  readonly awake: AwakeLease;
  readonly live: LiveScreen;
  /** Remote desktop streams (null where the hub link for it was not given). */
  readonly streams: ScreenStreams | null;
  /** The website terminal: opened only after the owner's fingerprint yes. */
  readonly terms: TermSessions;
  private viewPolicy: AccessPolicy;
  readonly quiet: QuietNotifications;

  constructor(private d: JarvisDeps) {
    this.quiet = d.quiet ?? new QuietNotifications(this.prepDeps());
    this.awake = d.awake ?? new AwakeLease({ ...d.screen, ...(d.now ? { now: d.now } : {}) });
    // A live view only starts after the fingerprint yes, which also covers unlocking the screen for it.
    this.live = d.live ?? new LiveScreen({ ...d.screen, unlock: true });
    this.viewPolicy = d.viewPolicy ?? new DefaultPolicy();
    this.terms = d.terms ?? new TermSessions({ ...(d.now ? { now: d.now } : {}), log: (what, why) => this.record('terminal', why, what.replace(/^terminal\s*/, '') || undefined) });
    // The Stop button on the notice on this computer: every view ends at once.
    this.live.onEvent((o) => {
      if (o.event === 'kill') void this.killAll('The owner stopped it on the computer.');
    });
    const sendText = d.sendScreenText;
    const sendFrame = d.sendFrame;
    this.streams =
      d.streams ??
      (sendText && sendFrame
        ? new ScreenStreams({
            live: this.live,
            sendText,
            sendFrame,
            ...(d.now ? { now: d.now } : {}),
            host: {
              check: (viewId) => {
                const v = this.views.get(viewId);
                return v && v.until > this.now() ? { expiresAt: v.until, viewOnly: v.decision.viewOnly, clipboard: v.decision.clipboard } : null;
              },
              remoteOn: () => this.d.remote.enabled(),
              renew: (viewId) => this.renewView(viewId),
              end: (viewId, why) => this.endView(viewId, why),
              record: (action, why) => this.record(action, why),
              startLive: async () => {
                const r = await this.live.start();
                return r.ok ? { ok: true as const, unlocked: r.unlocked } : { ok: false as const, say: r.say };
              },
            },
          })
        : null);
  }

  /** The viewer is in use: add another stretch to the view (never past the policy's longest) and tell the hub. */
  private renewView(viewId: string): number | null {
    const v = this.views.get(viewId);
    if (!v || !v.decision.autoRenew || v.until <= this.now()) return null;
    const next = Math.min(this.now() + v.decision.minutes * 60_000, v.hardEnd);
    if (next <= v.until + 30_000) return null;
    v.until = next;
    this.record('view_renew', `the live view was renewed while it was in use, until ${new Date(next).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`);
    return next;
  }

  /** The hub passes on what a viewer did on its /screen socket. */
  screenMessage(msg: HubScreenOpen | HubScreenClose | HubScreenIn): void {
    const st = this.streams;
    if (!st) return;
    if (!this.d.remote.enabled()) {
      if (msg.type === 'screen_open') this.d.sendScreenText?.(msg.viewId, msg.viewer, { t: 'ended', why: `Remote control is off on ${this.d.name}.` });
      return;
    }
    if (msg.type === 'screen_open') void st.open(msg.viewId, msg.viewer, msg.client);
    else if (msg.type === 'screen_close') st.close(msg.viewId, msg.viewer);
    else void st.inbound(msg.viewId, msg.viewer, (msg.msg && typeof msg.msg === 'object' ? msg.msg : {}) as Record<string, unknown>);
  }

  /** Every way a view ends at once: the kill switch. */
  async killAll(why: string): Promise<void> {
    for (const id of [...this.views.keys()]) await this.endView(id, why);
    this.terms.closeAll(why);
  }

  /** Remote control is on for this computer now (the mesh tells the apps it can be controlled only when it is). */
  get remoteEnabled(): boolean {
    return this.d.remote.enabled();
  }

  /**
   * The owner changed Remote control from the permissions page of the phone, the website or the desktop app (machinePermissions.ts).
   * Off always takes effect (and ends views). On takes effect only where it is on by itself (the owner's own computer): turning it on
   * for anything else, or after the owner chose off at this computer, still needs the fingerprint on the phone (`set_remote_control`).
   * Returns whether the switch is on afterwards. Fixed by the environment: left alone.
   */
  async setRemoteFromPermissions(enabled: boolean, ownComputer: boolean): Promise<boolean> {
    if (this.d.remote.lockedByEnv()) return this.d.remote.enabled();
    if (!enabled) {
      if (this.d.remote.enabled()) {
        this.d.remote.set(false);
        this.awake.release();
        for (const v of [...this.views.keys()]) await this.endView(v, 'Remote control was turned off');
        this.record('set_remote_control', 'Remote control was turned off from the permissions page', 'off');
      }
    } else if (ownComputer && !this.d.remote.enabled()) {
      this.d.remote.set(true);
      this.record('set_remote_control', 'Remote control was turned on from the permissions page (this is the owner\'s own computer)', 'on');
    }
    return this.d.remote.enabled();
  }

  private now = () => (this.d.now ?? Date.now)();

  private prepDeps(): PrepDeps {
    return { ...(this.d.screen ?? {}), ...(this.d.prep ?? {}), ...(this.d.now ? { now: this.d.now } : {}) };
  }

  private ok(requestId: string, say: string, data?: Record<string, unknown>): AgentDeviceResult {
    return { type: 'device_result', requestId, ok: true, say, state: 'done', ...(data ? { data } : {}) };
  }

  private no(requestId: string, say: string, code: NonNullable<AgentDeviceResult['code']> = 'failed'): AgentDeviceResult {
    return { type: 'device_result', requestId, ok: false, say, code };
  }

  private record(action: string, why: string, what?: string): void {
    this.d.log({ at: this.now(), action: 'remote', source: 'app', command: what ? `${action} ${what}` : action, why });
  }

  /** Asks that ran out: the phone is told so its card closes. Called now and then. */
  sweep(): void {
    for (const id of this.asks.sweep(this.now())) this.d.sendAskDone(id);
    for (const [id, v] of this.views) if (v.until <= this.now()) void this.endView(id, 'The time ran out.');
    void this.quiet.sweep();
    this.terms.sweep();
  }

  /** A view ends (stopped, ran out, or Remote control went off): the laptop's notice is taken away and says it ended. */
  private async endView(viewId: string, why: string): Promise<void> {
    if (!this.views.delete(viewId)) return;
    const id = this.notices.get(viewId);
    this.notices.delete(viewId);
    this.record('view_stop', why);
    this.streams?.endView(viewId, why);
    this.d.sendViewEnd?.(viewId, why);
    if (this.views.size === 0) {
      this.live.stop();
      this.awake.release();
    }
    if (id) await closeNotice(id, this.d.screen ?? {});
    await notice('Escanor', 'Your screen is no longer being viewed.', 4000, this.d.screen ?? {}, 'normal');
  }

  /** The live views active now (not expired), for a job that needs the viewId after the phone's fingerprint yes. The id is already sent to every app of the account. */
  private liveViewList(): Array<{ viewId: string; expiresAt: number; viewOnly: boolean }> {
    const now = this.now();
    return [...this.views.entries()].filter(([, v]) => v.until > now).map(([viewId, v]) => ({ viewId, expiresAt: v.until, viewOnly: v.decision.viewOnly }));
  }

  /** Can the clipboard be captured here: the live session has its own clipboard route, or a fixed clipboard program is installed. */
  private async clipboardTool(): Promise<boolean> {
    if (this.live.hasClipboard) return true;
    // The text (if any) is dropped at once; only whether a program exists matters (an empty clipboard makes wl-paste exit 1).
    const r = await readClipboard(this.d.clip).catch(() => null);
    return r !== null && (r.ok || !r.missing);
  }

  private liveViews(): number {
    this.sweep();
    return this.views.size;
  }

  /** Is any phone able to say yes: one paired in front of this computer, or one on the person's account? */
  private async anyPhone(): Promise<{ paired: boolean; keyIds: string[]; account: boolean }> {
    const local = this.d.keys.list().map((k) => k.keyId);
    const acct = (await this.d.account?.phones().catch(() => null)) ?? null;
    const keyIds = [...new Set([...local, ...(acct?.keyIds ?? [])])];
    return { paired: keyIds.length > 0, keyIds, account: !!acct?.paired };
  }

  private async ask(requestId: string, purpose: DeviceAskPurpose, subject: string, what: Pending, say: string, extra: AskExtra = {}): Promise<AgentDeviceResult> {
    const made = await this.makeAsk(requestId, purpose, subject, what, extra);
    if (!made.ok) return this.no(requestId, made.say, 'not_paired');
    return { type: 'device_result', requestId, ok: false, state: 'needs_approval', say, ask: made.ask };
  }

  /** Puts one question to the phone: what happens, why, who asked. Refused when no phone could answer it. */
  private async makeAsk(requestId: string, purpose: DeviceAskPurpose, subject: string, what: Pending, extra: AskExtra = {}): Promise<{ ok: true; ask: DeviceAsk } | { ok: false; say: string }> {
    if (!(await this.anyPhone()).paired) {
      this.record(purpose, 'refused: no phone is set up for fingerprint approvals', subject);
      return { ok: false, say: 'No phone is set up for fingerprint approvals yet. On your phone: Machines, this computer, Remote control, Turn on fingerprint approvals.' };
    }
    const also = (this.policyAlso.get(requestId) ?? []).filter((a): a is 'password' | 'totp' => a !== 'fingerprint');
    this.policyAlso.delete(requestId);
    if (also.length) what = { ...what, also };
    const ask = this.asks.create(purpose, subject, this.d.machine, what, this.now());
    if (also.length) ask.also = also;
    if (extra.what) ask.what = extra.what.slice(0, 200);
    if (extra.why) ask.why = extra.why.slice(0, 200);
    if (extra.source) ask.source = extra.source;
    this.record(purpose, `waiting for the owner's fingerprint on the phone${extra.source ? ` (asked by ${extra.source === 'phone' ? 'the owner' : extra.source === 'ai' ? 'the AI' : 'an automation'})` : ''}`, subject);
    this.d.sendAsk(ask);
    return { ok: true, ask };
  }

  async command(msg: HubDeviceCommand): Promise<AgentDeviceResult> {
    const id = msg.requestId;
    const action = typeof msg.action === 'string' ? msg.action : '';
    const args = (msg.args && typeof msg.args === 'object' && !Array.isArray(msg.args) ? msg.args : {}) as Record<string, unknown>;
    try {
      if (!this.d.remote.enabled() && !WHEN_OFF.has(action)) {
        this.record(action, 'refused: Remote control is off on this computer');
        return this.no(id, `Remote control is off on ${this.d.name}. Turn it on from the phone (it asks for your fingerprint) or at the computer.`, 'remote_off');
      }
      if (this.d.limited && !LIMITED_OK.has(action)) {
        this.record(action.slice(0, 40) || 'unknown', 'refused: no desktop on this computer right now');
        return this.no(id, `${this.d.name} has no desktop right now (nobody is signed in on it, or it is a server), so it can only be unlocked or asked to sign things in.`, 'refused');
      }
      const liveShot = action === 'screenshot' && typeof args.viewId === 'string' && (this.views.get(args.viewId)?.until ?? 0) > this.now();
      if (!NO_POLICY.includes(action) && !liveShot) {
        const gate = await this.policy(id, action);
        if (gate) return gate;
      }
      if (COMPUTER_ACTIONS.has(action)) return await this.simple(id, action, args);
      switch (action) {
        case 'status':
          return this.ok(id, `Remote control is ${this.d.remote.enabled() ? 'on' : 'off'} on ${this.d.name}.`, {
            remoteControl: this.d.remote.enabled(),
            ...(await this.statusExtra()),
            views: this.liveViews(),
            liveViews: this.liveViewList(),
            clipboardTool: await this.clipboardTool(),
            locked: await screenLocked(this.d.screen ?? {}).catch(() => false),
            ...(this.awake.awakeUntil ? { awakeUntil: this.awake.awakeUntil } : {}),
          });
        case 'presence': {
          const p = this.d.presence?.();
          if (!p) return this.ok(id, `${this.d.name} cannot tell whether you are at it.`, {});
          const data: Record<string, unknown> = { ...(p.idleSeconds !== undefined ? { idleSeconds: p.idleSeconds } : {}), ...(p.active !== undefined ? { active: p.active } : {}), ...(p.locked !== undefined ? { locked: p.locked } : {}) };
          return this.ok(id, p.locked ? `The screen of ${this.d.name} is locked.` : p.active ? `You are using ${this.d.name} now.` : `${this.d.name} has been idle for ${Math.round((p.idleSeconds ?? 0) / 60)} minutes.`, data);
        }
        case 'receive': {
          const r = await receiveHandoff(args, { screen: this.d.screen, now: this.d.now, ...this.d.receive });
          // The safety log names the kind and where it came from, never the text, file or page address.
          this.record('receive', r.ok ? `took a ${String(args.kind)} from ${String(args.from ?? 'another device').slice(0, 40)}` : `could not: ${r.say}`);
          return r.ok ? this.ok(id, r.say, r.data) : this.no(id, r.say, 'refused');
        }
        case 'show':
          return await this.show(id, args);
        case 'av_check': {
          // Camera, microphone and volume before a meeting: reads state, unmutes and lifts a very low volume when asked. Never opens the camera or records.
          const r = await checkAv(args.fix !== false, this.prepDeps());
          this.record('av_check', r.fixed.length ? `checked sound and camera, ${r.fixed.join(' and ')}` : 'checked sound and camera');
          return this.ok(id, avSay(r), avData(r));
        }
        case 'quiet_notifications': {
          if (args.on === false) {
            const had = await this.quiet.stop();
            this.record('quiet_notifications', had ? 'notifications put back' : 'notifications were not silenced', 'off');
            return this.ok(id, had ? 'Notifications are back on.' : 'Notifications were not silenced.');
          }
          const r = await this.quiet.start(clampMinutes(args.minutes, 60));
          this.record('quiet_notifications', r.ok ? `silenced until ${new Date(r.until ?? 0).toISOString()}` : `could not: ${r.say}`, 'on');
          return r.ok ? this.ok(id, r.say, r.until ? { quietUntil: r.until } : undefined) : this.no(id, r.say);
        }
        case 'wake_screen': {
          const r = await this.awake.start(clampMinutes(args.minutes, 5));
          this.record('wake_screen', r.ok ? 'woke the screen' : 'could not hold the screen awake');
          return r.ok ? this.ok(id, 'The screen is awake.', this.awakeData()) : this.no(id, 'Could not wake the screen from here.');
        }
        case 'keep_awake': {
          const minutes = clampMinutes(args.minutes, 30);
          const r = await this.awake.start(minutes);
          this.record('keep_awake', r.ok ? `kept awake for ${minutes} minutes` : 'could not hold the screen awake');
          return r.ok ? this.ok(id, `Keeping the screen awake for ${minutes} minutes.`, this.awakeData()) : this.no(id, 'Could not keep the screen awake from here.');
        }
        case 'release_awake': {
          const had = this.awake.release();
          this.record('release_awake', had ? 'let the screen sleep again' : 'nothing was held');
          return this.ok(id, had ? 'The screen can sleep again.' : 'Nothing was keeping the screen awake.');
        }
        case 'unlock_screen':
          return await this.ask(id, 'unlock', 'screen', { kind: 'unlock' }, 'Waiting for your fingerprint on the phone to unlock the screen.', { what: `Unlock the screen of ${this.d.name}.`, source: 'phone' });
        case 'unlock_computer':
          return await this.unlockComputer(id, args);
        case 'unlock_setup':
          return await this.unlockSetup(id);
        case 'signin_status':
          return this.ok(id, this.d.signin?.enabled() ? `${this.d.name} may use the saved secrets you allowed, each time after your fingerprint.` : `Let Escanor sign in for me is off on ${this.d.name}.`, { signin: this.d.signin ? { available: true, ...this.d.signin.status() } : { available: false } });
        case 'set_signin': {
          const s = this.d.signin;
          if (!s) return this.no(id, 'This computer cannot sign in for you yet. Update the Escanor agent on it.', 'refused');
          if (s.lockedByEnv()) return this.no(id, `Let Escanor sign in for me on ${this.d.name} is fixed off by its own settings (ESCANOR_SIGNIN); change it there.`, 'refused');
          const patch = s.parse(args);
          if (!patch || Object.keys(patch).length === 0) return this.no(id, 'Say what to change: on or off, the saved secrets it may use, or the commands sudo may run.', 'refused');
          if (!s.loosens(patch)) {
            s.apply(patch);
            if (patch.enabled === false) s.window.end();
            this.record('set_signin', patch.enabled === false ? 'the owner turned Let Escanor sign in for me off' : 'the owner took something off what Escanor may sign in with', 'less');
            return this.ok(id, patch.enabled === false ? `Let Escanor sign in for me is off on ${this.d.name}.` : 'Saved.', { signin: { available: true, ...s.status() } });
          }
          return await this.ask(id, 'enable_signin', s.subjectOf(patch), { kind: 'enable_signin', patch }, `Waiting for your fingerprint on the phone to let ${this.d.name} use the saved secrets you chose.`, { what: `Let ${this.d.name} use ${patch.allow?.length ? `these saved secrets: ${patch.allow.filter((a) => !s.status().allow.includes(a)).slice(0, 8).join(', ')}` : 'the saved secrets you allowed'}${patch.sudo?.length ? ' and run the sudo commands you listed' : ''}. Using one still asks for your fingerprint each time (unless you allow a time window). Values are never shown.`, source: 'phone' });
        }
        case 'signin_use': {
          const use = parseUse(args);
          if (!use) return this.no(id, 'Say what to sign in: the keyring, GitHub, a listed sudo command, or a check of everything.', 'refused');
          const r = await this.startUse(id, use, cleanWhy(args.why), 'phone');
          return r;
        }
        case 'signin_check':
          return await this.startUse(id, { kind: 'check', ...(args.force === true ? { force: true } : {}) }, cleanWhy(args.why), 'phone');
        case 'set_signin_window': {
          const s = this.d.signin;
          if (!s) return this.no(id, 'This computer cannot sign in for you yet. Update the Escanor agent on it.', 'refused');
          const m = typeof args.minutes === 'number' ? Math.floor(args.minutes) : NaN;
          if (!Number.isFinite(m) || m < 0 || m > MAX_WINDOW_MINUTES) return this.no(id, `Say how many minutes, from 1 to ${MAX_WINDOW_MINUTES}, or 0 to stop.`, 'refused');
          if (m === 0) {
            const had = s.window.end();
            this.record('set_signin_window', had ? 'the owner ended the time window' : 'no time window was running', 'off');
            return this.ok(id, had ? 'Stopped. Every use asks for your fingerprint again.' : 'No time window was running.', { signin: { available: true, ...s.status() } });
          }
          if (s.lockedByEnv()) return this.no(id, `Let Escanor sign in for me on ${this.d.name} is fixed off by its own settings (ESCANOR_SIGNIN); change it there.`, 'refused');
          if (!s.enabled()) return this.no(id, 'Let Escanor sign in for me is off on this computer. Turn it on first (it asks for your fingerprint).', 'refused');
          return await this.ask(id, 'signin_window', `w:${m}`, { kind: 'signin_window', minutes: m }, `Waiting for your fingerprint on the phone to allow ${m} minutes without asking again.`, { what: `For the next ${m} minutes, ${this.d.name} may use the saved secrets you allowed (keyring, GitHub, listed sudo commands) without asking each time. Every use is still in the log. It never covers signing in at the login screen or waking the computer. You can stop it any time.`, source: 'phone' });
        }
        case 'set_chat_signin_window': {
          // "Let AI chats handle sign-ins": a fingerprint-confirmed, time-limited permission. It can only come from the app (this command),
          // never from words typed in a chat. While it runs, a chat that works on its own may open sign-in and key files (personalGuard
          // 'credentials'); every use is shown in that chat. Destructive things and sending secrets away stay blocked.
          const s = this.d.signin;
          if (!s) return this.no(id, 'This computer cannot do that yet. Update the Escanor agent on it.', 'refused');
          const m = typeof args.minutes === 'number' ? Math.floor(args.minutes) : NaN;
          if (!Number.isFinite(m) || m < 0 || m > MAX_WINDOW_MINUTES) return this.no(id, `Say how many minutes, from 1 to ${MAX_WINDOW_MINUTES}, or 0 to stop.`, 'refused');
          if (m === 0) {
            const had = s.chatWindow.end();
            this.record('set_chat_signin_window', had ? 'the owner ended the permission for AI chats to handle sign-ins' : 'no permission for AI chats was running', 'off');
            return this.ok(id, had ? 'Stopped. AI chats ask on your phone again before they touch sign-ins.' : 'No permission was running.', { signin: { available: true, ...s.status() } });
          }
          return await this.ask(id, 'signin_window', `c:${m}`, { kind: 'chat_signin_window', minutes: m }, `Waiting for your fingerprint on the phone to let AI chats handle sign-ins for ${m} minutes.`, { what: `For the next ${m} minutes, AI chats working on their own on ${this.d.name} may open saved sign-in and key files without asking each time. Each use is shown in that chat. Deleting data and sending secrets away stay blocked. You can stop it any time.`, source: 'phone' });
        }
        case 'sign_in': {
          const url = typeof args.url === 'string' ? safeUrl(args.url) : null;
          const host = url ? hostOf(url) : '';
          if (!url || !host || url.startsWith('mailto:') || !url.startsWith('https://')) return this.no(id, 'Sign-in works for an https web address, like https://github.com/login.', 'refused');
          return await this.ask(id, 'signin', host, { kind: 'signin', url, host }, `Waiting for your fingerprint on the phone to sign in to ${host}.`);
        }
        case 'screenshot': {
          const viewId = typeof args.viewId === 'string' ? args.viewId : '';
          const view = this.views.get(viewId);
          if (viewId && view && view.until > this.now()) return await this.shoot(id, viewId, view.until);
          if (viewId) this.views.delete(viewId);
          // The account decided what proof is needed (command()); the owner's file can still say no, shorten or limit a view.
          const policy = this.viewPolicy.forView({ machine: this.d.machine, now: this.now() });
          if (!policy.allow) {
            this.record('screenshot', `refused by the access policy: ${policy.reason}`);
            return this.no(id, policy.reason, 'refused');
          }
          return await this.ask(id, 'view', 'screen', { kind: 'view' }, `Waiting for your fingerprint on the phone to show the screen of ${this.d.name}.`);
        }
        case 'input': {
          const viewId = typeof args.viewId === 'string' ? args.viewId : '';
          const view = this.views.get(viewId);
          const until = view?.until ?? 0;
          if (!viewId || !view || until <= this.now()) {
            if (viewId) this.views.delete(viewId);
            return this.no(id, 'The live view has ended. Start it again (it asks for your fingerprint).', 'expired');
          }
          if (view.decision.viewOnly) return this.no(id, 'Your access policy lets you look at this computer but not use it.', 'refused');
          const parsed = parseEvents(args.events);
          if (!parsed.ok) return this.no(id, parsed.error, 'refused');
          const started = await this.live.start();
          if (!started.ok) {
            this.record('input', `could not: ${started.say}`, 'live control');
            return this.no(id, started.say);
          }
          const r = await this.live.send(parsed.events);
          this.record('input', r.ok ? `${describeEvents(parsed.events)} from the phone (live control)` : `could not: ${r.say}`, 'live control');
          if (!r.ok) return this.no(id, r.say);
          // The screen just after, so the phone shows what the tap did at once.
          return await this.shoot(id, viewId, until, 'Done.', Date.now());
        }
        case 'clipboard':
          return await this.clipboard(id, args);
        case 'update_app': {
          const asked = this.d.requestUpdate?.() === true;
          this.record('update_app', asked ? 'the owner asked the Escanor app to update' : 'update asked, but no Escanor app started this agent');
          return asked
            ? this.ok(id, `${this.d.name} is updating Escanor. It restarts by itself when the new version is ready.`, {})
            : this.no(id, `Escanor on ${this.d.name} was not started by the Escanor app, so it cannot update itself from here. Update it on that computer.`, 'refused');
        }
        case 'check': {
          const r = await runCheck(args.check, { top: typeof args.top === 'number' ? args.top : undefined });
          this.record('check', r.ok ? `read ${r.kind} for the website` : `could not: ${r.say}`);
          return r.ok ? this.ok(id, r.say, { kind: r.kind, rows: r.rows }) : this.no(id, r.say);
        }
        case 'deps_check': {
          const features = depsFeatures(args.features);
          const host = detectHost();
          const rows = await checkDeps({ host, features });
          const plan = buildPlan(rows, host, os.homedir());
          this.record('deps_check', `read what this computer is missing (${rows.filter((r) => !r.present).length})`);
          return this.ok(id, plan.nothingToDo ? 'Everything Escanor needs is already here.' : 'Some tools are missing.', { rows, plan: describePlan(plan), needsAdmin: plan.needsAdmin, packageManager: host.pm });
        }
        case 'deps_install': {
          const features = depsFeatures(args.features);
          const host = detectHost();
          const plan = buildPlan(await checkDeps({ host, features }), host, os.homedir());
          if (plan.nothingToDo) return this.ok(id, 'Everything Escanor needs is already here.');
          return await this.ask(id, 'deps', 'setup', { kind: 'deps_install', ...(features ? { features } : {}) }, `Waiting for your fingerprint on the phone to set up ${this.d.name}.`, {
            what: `Install missing tools on ${this.d.name}`.slice(0, 200),
            why: describePlan(plan).join(' ').slice(0, 200),
            source: 'phone',
          });
        }
        case 'term_open':
          return await this.ask(id, 'view', 'terminal', { kind: 'terminal' }, `Waiting for your fingerprint on the phone to open a terminal on ${this.d.name}.`, {
            what: `Open a terminal on ${this.d.name} from the website`.slice(0, 200),
            why: 'Whatever is typed runs on this computer. Each command is logged and checked by the safety guard.',
            source: 'phone',
          });
        case 'term_send': {
          const r = this.terms.send(String(args.termId ?? ''), args.data);
          return r.ok ? this.ok(id, 'Sent.') : this.no(id, r.say, 'expired');
        }
        case 'term_read': {
          const r = this.terms.read(String(args.termId ?? ''), typeof args.after === 'number' && args.after >= 0 ? Math.floor(args.after) : 0);
          return r.ok ? this.ok(id, r.closed ? 'The terminal has ended.' : 'Output.', { out: r.out, seq: r.seq, closed: r.closed }) : this.no(id, r.say, 'expired');
        }
        case 'term_close': {
          const had = this.terms.close(String(args.termId ?? ''));
          return this.ok(id, had ? 'The terminal is closed.' : 'That terminal had already ended.');
        }
        case 'view_stop': {
          const viewId = typeof args.viewId === 'string' ? args.viewId : '';
          const had = this.views.has(viewId);
          if (had) await this.endView(viewId, 'the owner stopped looking at the screen');
          return this.ok(id, had ? 'Stopped looking at the screen.' : 'That view had already ended.');
        }
        case 'set_remote_control': {
          if (typeof args.enabled !== 'boolean') return this.no(id, 'Say whether Remote control should be on or off.', 'refused');
          if (this.d.remote.lockedByEnv()) return this.no(id, `Remote control on ${this.d.name} is fixed by its own settings (${REMOTE_ENV}); change it there.`, 'refused');
          if (!args.enabled) {
            this.d.remote.set(false);
            this.awake.release();
            for (const v of [...this.views.keys()]) await this.endView(v, 'Remote control was turned off');
            this.record('set_remote_control', 'the owner turned Remote control off', 'off');
            return this.ok(id, `Remote control is off on ${this.d.name}.`, { remoteControl: false });
          }
          if (this.d.remote.enabled()) return this.ok(id, `Remote control is already on for ${this.d.name}.`, { remoteControl: true });
          return await this.ask(id, 'enable', 'on', { kind: 'enable' }, `Waiting for your fingerprint on the phone to turn Remote control on for ${this.d.name}.`);
        }
        case 'set_type_secrets': {
          if (typeof args.enabled !== 'boolean') return this.no(id, 'Say whether typing saved sign-ins should be on or off.', 'refused');
          const t = this.d.typing;
          if (!t) return this.no(id, 'This computer cannot type saved sign-ins.', 'refused');
          if (t.lockedByEnv()) return this.no(id, `Typing saved sign-ins on ${this.d.name} is fixed by its own settings (${TYPE_ENV}); change it there.`, 'refused');
          if (!args.enabled) {
            t.set(false);
            this.record('set_type_secrets', 'the owner turned typing saved sign-ins off', 'off');
            return this.ok(id, `Typing saved sign-ins is off on ${this.d.name}.`, { typeSecrets: false });
          }
          if (t.enabled()) return this.ok(id, `Typing saved sign-ins is already on for ${this.d.name}.`, { typeSecrets: true });
          return await this.ask(id, 'enable_typing', 'on', { kind: 'enable_typing' }, `Waiting for your fingerprint on the phone to let ${this.d.name} type saved sign-ins.`);
        }
        case 'schedule_wake': {
          const w = this.d.wakeAt;
          if (!w) return this.no(id, 'This computer cannot be set to wake at a time.', 'refused');
          if (args.at === null || args.cancel === true) {
            w.set(null);
            this.record('schedule_wake', 'cancelled the wake time');
            return this.ok(id, 'No wake time is set.');
          }
          const epoch = wakeEpoch(args.at, this.now());
          if (epoch === null) return this.no(id, 'Pick a time from a few minutes to two weeks from now.', 'refused');
          // A computer that wakes itself is a computer turned on: only after the owner's fingerprint.
          const when = new Date(epoch * 1000).toLocaleString();
          return await this.ask(id, 'wake', `at:${epoch}`, { kind: 'schedule_wake', epoch }, `Waiting for your fingerprint on the phone to let ${this.d.name} wake at ${when}.`, { what: `Set ${this.d.name} to wake from sleep at ${when}. After it wakes, signing in at the login screen still asks for your fingerprint.`, source: 'phone' });
        }
        case 'type_login':
          return await this.typeLoginAsk(id, args);
        case 'pair_phone':
          return this.pair(id, args);
        case 'k8s_names':
        case 'k8s_read':
        case 'k8s_set':
        case 'k8s_remove':
        case 'k8s_restore': {
          if (!this.d.k8s || !isK8sAction(action)) return this.no(id, `Kubernetes changes are not set up on ${this.d.name}.`, 'refused');
          const r = await this.d.k8s.handle(action, args);
          // The safety log says what was done to which Secret, written by k8sSecrets.ts; a refusal is logged here (never a value).
          if (!r.ok) this.record(action, `could not: ${r.say.slice(0, 160)}`);
          return r.ok ? this.ok(id, r.say, r.data) : this.no(id, r.say, r.code);
        }
        default:
          this.record(action.slice(0, 40) || 'unknown', 'refused: not an action this computer takes');
          return this.no(id, `This computer does not know how to "${action.slice(0, 40)}".`, 'refused');
      }
    } catch {
      return this.no(id, 'Something went wrong doing that on this computer.');
    }
  }

  /**
   * The person's access policy (the account holds it): a kill switch, allowed hours, actions never allowed, and what must be shown
   * with the fingerprint. Returns the refusal, or null to go on (what extra proof an ask needs is kept for `ask`). When the account
   * cannot be reached the last answer for that action is used for a day; with none, the built-in rules apply (fingerprint for
   * everything that lets someone in), and the person's switch on this computer still holds.
   */
  private async policy(requestId: string, action: string): Promise<AgentDeviceResult | null> {
    if (!this.d.account) return null;
    let d = await this.d.account.policy(this.d.machine, action).catch(() => null);
    // An account server that does not know this action yet (older than this computer) says "unknown": the built-in rules apply, which
    // are the strictest ones (a fingerprint for everything that lets someone in), never a looser answer.
    if (d && d.code === 'unknown') d = null;
    const cached = this.lastDecision.get(action);
    if (d) this.lastDecision.set(action, { at: this.now(), d });
    else if (cached && this.now() - cached.at < 24 * 3600_000) d = cached.d;
    if (!d) return null;
    if (!d.allow) {
      this.record(action, `refused by the access policy${d.code ? ` (${d.code})` : ''}`);
      return this.no(requestId, d.why || `${this.d.name} is not open to this right now.`, 'blocked');
    }
    if (d.auth.some((a) => a !== 'fingerprint')) this.policyAlso.set(requestId, d.auth);
    return null;
  }

  private async statusExtra(): Promise<Record<string, unknown>> {
    const p = await this.anyPhone();
    return {
      paired: p.paired,
      keyIds: p.keyIds.slice(0, 10),
      accountTrust: p.account,
      typeSecrets: this.d.typing?.enabled() ?? false,
      typeSecretsFixed: this.d.typing?.lockedByEnv() ?? false,
      focusHelper: this.d.focus ? await this.d.focus.status().catch(() => 'missing') : 'not_needed',
      ...(this.d.wakeRoutes ? { wakeRoutes: (await this.d.wakeRoutes().catch(() => [])).slice(0, 8) } : {}),
      unlock: await this.unlockData().catch(() => null),
    };
  }

  /**
   * A fingerprint yes for this ask: from a phone paired in front of this computer, else from the account. When the person's policy
   * wants a password or code too, only the account can check that, so the account does the whole check.
   */
  private async verifyYes(ask: DeviceAsk, msg: HubDeviceApproval, also: Auth[]): Promise<{ ok: true; who: string } | { ok: false; why: string }> {
    if (!also.length) {
      const local = checkYes(this.d.keys, ask, msg);
      if (local.ok) return { ok: true, who: local.key.name };
    }
    if (!this.d.account) {
      if (also.length) return { ok: false, why: 'recheck_needed' };
      const local = checkYes(this.d.keys, ask, msg);
      return local.ok ? { ok: true, who: local.key.name } : { ok: false, why: local.why };
    }
    const r = await this.d.account.verify({
      purpose: ask.purpose, subject: ask.subject, nonce: ask.nonce, machine: ask.machine,
      ...(typeof msg.keyId === 'string' ? { keyId: msg.keyId } : {}), ...(typeof msg.signature === 'string' ? { signature: msg.signature } : {}),
      need: ['fingerprint', ...also],
      ...(msg.recheck ? { recheck: { ...(typeof msg.recheck.password === 'string' ? { password: msg.recheck.password } : {}), ...(typeof msg.recheck.code === 'string' ? { code: msg.recheck.code } : {}) } } : {}),
    });
    if (!r) return { ok: false, why: 'bad_signature' };
    if (r.ok) return { ok: true, who: r.deviceName };
    // Not the account's phone either: say "unknown key" when this computer has no such phone, so the app tells the person what to do.
    return { ok: false, why: ['not_paired', 'unknown_key', 'recheck_needed', 'bad_recheck'].includes(r.why) ? r.why : 'bad_signature' };
  }

  // ---- unlock / turn on, and sign-in for me: every one of these waits for the owner's fingerprint ---------------------------------

  private machineKind(): string {
    return this.d.machineKind ?? 'unknown';
  }

  /** What the phone shows beside "Unlock / Turn on". Reads only (it may bring the sign-in helper's list of phones up to date first). */
  async unlockData(): Promise<UnlockStatus> {
    await this.syncHelper().catch(() => 'failed');
    const hs = (await this.d.helper?.status().catch(() => null)) ?? null;
    const w = this.d.signin?.window.active();
    const st = await unlockStatus({
      ...(this.d.screen ?? {}),
      helper: { status: async () => hs },
      machineKind: this.machineKind(),
      machine: this.d.machine,
      window: () => (w ? { until: w.until } : null),
      wakeRoutes: this.d.wakeRoutes ?? (async () => []),
      hasPhone: async () => (await this.phoneKeys()).length > 0 || (await this.anyPhone()).paired,
    });
    // Which phones can sign in at the login screen, as far as this computer knows (it handed them over itself). The phone shows
    // "this phone is not set up yet" when its own key is not in the list. Left out when unknown.
    const known = this.syncedKeyIds();
    return hs && known && hs.enrolled === known.length ? { ...st, phones: known } : st;
  }

  /** The phones this computer trusts, as public keys: the ones paired in front of it, and the person's account's. */
  private async phoneKeys(): Promise<{ keyId: string; publicKey: string; name: string }[]> {
    const out = new Map<string, { keyId: string; publicKey: string; name: string }>();
    for (const k of this.d.keys.list()) out.set(k.keyId, { keyId: k.keyId, publicKey: k.publicKey, name: k.name });
    const acct = await this.d.account?.phones().catch(() => null);
    for (const k of acct?.keys ?? []) if (!out.has(k.keyId)) out.set(k.keyId, k);
    return [...out.values()];
  }

  /**
   * The phones the sign-in helper should trust, at most HELPER_MAX_KEYS (its limit): the account's phones first (each device's current
   * key), then the ones paired in front of this computer, newest first and one key per named phone (a phone paired again keeps only its newest key). These are
   * the same phones whose fingerprint yes this computer already accepts. Null when the account has phones but cannot be read right now
   * (the list would come out short and drop a phone).
   */
  private async helperWanted(): Promise<{ keyId: string; publicKey: string; name: string }[] | null> {
    const out = new Map<string, { keyId: string; publicKey: string; name: string }>();
    if (this.d.account) {
      const acct = await this.d.account.phones().catch(() => null);
      if (!acct) return null;
      for (const k of acct.keys ?? []) out.set(k.keyId, { keyId: k.keyId, publicKey: k.publicKey, name: k.name });
    }
    // One key per named phone, its newest (as pairing again does now); rows from before that change still list a phone's older keys.
    const names = new Set<string>();
    const local = [...this.d.keys.list()].sort((a, b) => b.addedAt - a.addedAt);
    for (const k of local) {
      const name = k.name.toLowerCase();
      if (out.has(k.keyId) || (name !== 'phone' && names.has(name))) continue;
      names.add(name);
      out.set(k.keyId, { keyId: k.keyId, publicKey: k.publicKey, name: k.name });
    }
    return [...out.values()].slice(0, HELPER_MAX_KEYS);
  }

  private syncMemo: string[] | null | undefined;
  /** The key ids last handed to the sign-in helper (null: not known, e.g. never done by this agent). */
  private syncedKeyIds(): string[] | null {
    if (this.syncMemo !== undefined) return this.syncMemo;
    this.syncMemo = null;
    if (this.d.helperSyncFile) {
      try {
        const j = JSON.parse(readFileSync(this.d.helperSyncFile, 'utf8')) as { keyIds?: unknown };
        if (Array.isArray(j.keyIds) && j.keyIds.every((k) => typeof k === 'string' && /^[0-9a-f]{16}$/.test(k))) this.syncMemo = (j.keyIds as string[]).slice(0, HELPER_MAX_KEYS);
      } catch {
        /* not written yet */
      }
    }
    return this.syncMemo;
  }

  private noteSynced(keyIds: string[]): void {
    this.syncMemo = [...keyIds].sort();
    const f = this.d.helperSyncFile;
    if (!f) return;
    try {
      mkdirSync(dirname(f), { recursive: true });
      writeFileSync(`${f}.tmp`, JSON.stringify({ keyIds: this.syncMemo, at: this.now() }), { mode: 0o600 });
      renameSync(`${f}.tmp`, f);
    } catch {
      /* kept in memory; the next run hands the list over once more, which changes nothing */
    }
  }

  private syncing: Promise<HelperSync> | null = null;
  /**
   * Keeps the sign-in helper's list of phones the same as the phones this computer trusts. Without this a phone paired again (a new
   * install makes a new key) could never sign in at the login screen: the helper took keys only while its list was empty, or with a yes
   * from a phone it already trusted, which the old key's phone no longer has.
   * When the list is empty it is filled at once (as before). Otherwise it is renewed only while the person is signed in here with the
   * screen unlocked: the same trust the helper already gives this computer's own Escanor service (which may switch its list off and fill
   * it again), and never from the login screen or a locked screen. Nothing signs anyone in: a sign-in still needs a fresh fingerprint yes,
   * which the helper checks itself. Called by the status, after pairing a phone, and every few minutes.
   */
  syncHelper(): Promise<HelperSync> {
    if (!this.syncing) this.syncing = this.syncHelperOnce().finally(() => (this.syncing = null));
    return this.syncing;
  }

  private async syncHelperOnce(): Promise<HelperSync> {
    const h = this.d.helper;
    if (!h) return 'no_helper';
    const hs = await h.status().catch(() => null);
    if (!hs) return 'no_helper';
    if (hs.dm === 'none' || hs.kind === 'server' || hs.kind === 'vm') return 'no_screen';
    const want = await this.helperWanted();
    if (!want) return 'later';
    if (want.length === 0) return 'no_phone';
    const ids = want.map((k) => k.keyId).sort();
    const have = this.syncedKeyIds();
    if (have && hs.enrolled === have.length && have.join(',') === ids.join(',')) return 'same';
    const keys = want.map((k) => ({ publicKey: k.publicKey, name: k.name }));
    if (hs.enrolled > 0) {
      // Renewing a list that has phones: only with the person signed in here and the screen open (both the helper and this session say so).
      // The running agent is given no screen settings (this computer's own loginctl is used then), as unlockData does.
      const mine = await screenState(this.d.screen ?? {}).catch(() => 'unknown' as const);
      if (hs.session !== 'unlocked' || mine !== 'unlocked') return 'later';
      const off = await h.disable();
      if (!off.ok) return 'failed';
    }
    const r = await h.enroll(keys);
    if (!r.ok) {
      this.record('unlock_setup', `the sign-in helper did not take the phones: ${r.say.slice(0, 160)}`);
      return 'failed';
    }
    this.noteSynced(ids);
    this.record('unlock_setup', `the sign-in helper now trusts ${want.length} phone${want.length === 1 ? '' : 's'} for the login screen (each sign-in still needs a fingerprint)`);
    return 'synced';
  }

  /** "Unlock / Turn on" on a computer that is on: the screen is locked or at its login screen. Always a fingerprint ask, or a yes the phone signed beforehand. */
  private async unlockComputer(id: string, args: Record<string, unknown>): Promise<AgentDeviceResult> {
    const st = await this.unlockData();
    if (st.state === 'unsupported') return this.no(id, st.headline, 'refused');
    if (st.screen === 'unlocked') return this.ok(id, `${this.d.name} is already unlocked.`, { unlock: st });
    if (st.screen === 'locked') {
      if (this.signedBefore(args, 'screen') === 'bad') return this.no(id, 'That fingerprint approval is not good (it ran out, or is for another computer).', 'refused');
      return await this.ask(id, 'unlock', 'screen', { kind: 'unlock' }, 'Waiting for your fingerprint on the phone to unlock the screen.', { what: `Unlock the screen of ${this.d.name}.`, source: 'phone' });
    }
    if (st.screen !== 'login_screen') {
      if (st.state === 'no_screen') return this.no(id, `There is no screen to unlock on ${this.d.name}. Keyring and sudo only need your fingerprint when something asks for them.`, 'refused');
      return this.no(id, `Could not tell what ${this.d.name}'s screen is showing, so nothing was done.`);
    }
    // At the login screen (after a restart or a sign-out).
    if (st.state !== 'ready') {
      this.record('unlock_computer', `refused: ${st.headline}`);
      return this.no(id, st.state === 'needs_phone' ? `${st.headline}.` : `${st.headline}. It is the one thing that has to be done on the computer itself.`, 'refused');
    }
    const pre = this.signedBefore(args, 'login');
    if (pre === 'bad') return this.no(id, 'That fingerprint approval is not good (it ran out, or is for another computer).', 'refused');
    if (pre) {
      // The phone signed this sign-in in advance, with the same fingerprint check that woke the computer. The helper checks the signature itself.
      const yes = await this.verifyPre(pre);
      if (!yes.ok) return this.no(id, 'The fingerprint approval did not check out, so nothing was done.', 'refused');
      return await this.loginRun(id, pre, yes.who);
    }
    const exp = this.now() + ASK_TTL_MS;
    return await this.ask(id, 'unlock', `login:${exp}`, { kind: 'unlock', login: true }, `Waiting for your fingerprint on the phone to sign in on ${this.d.name}.`, {
      what: `Sign in on ${this.d.name} at its login screen, once. No password is typed and nothing stays set up: it signs you in only for this approval.`,
      source: 'phone',
    });
  }

  /** A sign-in the phone signed in advance (args.approval): its parts, null when absent, 'bad' when it cannot be right. */
  private signedBefore(args: Record<string, unknown>, what: 'screen' | 'login'): (HelperApproval & { expiresAt: number }) | 'bad' | null {
    const a = args.approval;
    if (a === undefined) return null;
    const o = (a && typeof a === 'object' && !Array.isArray(a) ? a : {}) as Record<string, unknown>;
    const exp = typeof o.expiresAt === 'number' ? o.expiresAt : NaN;
    if (typeof o.keyId !== 'string' || typeof o.signature !== 'string' || typeof o.nonce !== 'string' || !Number.isFinite(exp)) return 'bad';
    if (what === 'screen') return 'bad'; // only the login screen takes a yes signed in advance: a locked screen is asked afresh
    const now = this.now();
    if (exp <= now || exp > now + 5 * 60_000) return 'bad';
    return { purpose: 'unlock', subject: `login:${exp}`, nonce: o.nonce, machine: this.d.machine, keyId: o.keyId, signature: o.signature, expiresAt: exp };
  }

  private async verifyPre(a: HelperApproval & { expiresAt: number }): Promise<{ ok: true; who: string } | { ok: false }> {
    const ask: DeviceAsk = { askId: 'pre-signed', purpose: 'unlock', subject: a.subject, nonce: a.nonce, machine: a.machine, expiresAt: a.expiresAt };
    const r = await this.verifyYes(ask, { type: 'device_approval', requestId: 'pre', askId: 'pre-signed', approve: true, keyId: a.keyId, signature: a.signature }, []);
    return r.ok ? { ok: true, who: r.who } : { ok: false };
  }

  /** After the yes: the sign-in helper checks the signature itself and signs the person in once, then puts its settings back. */
  private async loginRun(id: string, a: HelperApproval, who: string): Promise<AgentDeviceResult> {
    if (!this.d.helper) return this.no(id, 'Not set up on this computer: update Escanor.', 'refused');
    await this.syncHelper().catch(() => 'failed'); // an empty list is filled at once
    const r = await this.d.helper.login({ purpose: a.purpose, subject: a.subject, nonce: a.nonce, machine: a.machine, keyId: a.keyId, signature: a.signature });
    this.record('unlock_computer', r.ok ? `signed in at the login screen with a fingerprint (${who})` : `could not: ${r.say.slice(0, 160)}`);
    if (r.ok) return this.ok(id, r.say, { unlock: await this.unlockData() });
    if (r.code === 'no_key' || r.code === 'not_enrolled') return this.no(id, notSetUpYet(this.d.name), 'refused');
    return this.no(id, r.say);
  }

  /**
   * "Set up this phone for the login screen". Signed in with the screen open: done at once (syncHelper). From the login screen or a
   * locked screen: a fingerprint ask, and the helper takes the new list only if the yes comes from a phone it already trusts.
   */
  private async unlockSetup(id: string): Promise<AgentDeviceResult> {
    if (!this.d.helper) return this.no(id, 'Not set up on this computer: update Escanor.', 'refused');
    const keys = await this.helperWanted();
    if (keys === null) return this.no(id, 'Could not reach your Escanor account to read your phones. Try again in a minute.');
    if (keys.length === 0) return this.no(id, 'Turn on fingerprint approvals on your phone first.', 'not_paired');
    const done = await this.syncHelper().catch(() => 'failed' as const);
    if (done === 'synced' || done === 'same') return this.ok(id, `Done. Your phone can now sign you in at ${this.d.name}'s login screen, each time with your fingerprint.`, { unlock: await this.unlockData() });
    if (done === 'failed') return this.no(id, 'The sign-in helper on this computer did not take your phone. Try again; if it keeps failing, update Escanor on this computer.');
    if (done !== 'later') return this.no(id, (await this.unlockData()).headline, 'refused');
    const keyIds = keys.map((k) => k.keyId).sort();
    const hash = createHash('sha256').update(keyIds.join(',')).digest('hex').slice(0, 16);
    const exp = this.now() + ASK_TTL_MS;
    return await this.ask(id, 'enable_signin', `keys:${hash}:${exp}`, { kind: 'unlock_setup', keyIds }, `Waiting for your fingerprint on the phone to add your phones to ${this.d.name}'s sign-in.`, { what: `Let ${this.d.name} know ${keys.length === 1 ? 'this phone' : `these ${keys.length} phones`}, so a fingerprint on ${keys.length === 1 ? 'it' : 'one of them'} can sign you in at the login screen. Nothing is signed in by this.`, source: 'phone' });
  }

  // ---- sign in for me: one use at a time -------------------------------------------------------------------------------------

  /** Runs a use now (inside the owner's window), asks the phone, or refuses. The same for the phone, the AI and an automation. */
  private async startUse(id: string, use: SigninUse, why: string, source: UseSource): Promise<AgentDeviceResult> {
    const s = this.d.signin;
    if (!s) return this.no(id, 'This computer cannot sign in for you yet. Update the Escanor agent on it.', 'refused');
    const refused = s.unavailable(use);
    if (refused) {
      this.record('signin_use', `refused: ${refused}`, use.kind);
      return this.no(id, refused, 'refused');
    }
    const w = s.window.active();
    if (w && !use.force) {
      const proof: UseProof = { via: 'window', who: w.by };
      const r = await s.run(use, proof);
      this.record('signin_use', `${r.ok ? 'done' : 'could not'} inside the time window the owner allowed with a fingerprint (${source})`, use.kind);
      return r.ok ? this.ok(id, r.say, { signin: { available: true, ...s.status() } }) : this.no(id, r.say);
    }
    const what = describeUse(use, this.d.name);
    return await this.ask(id, 'signin_use', subjectOfUse(use, why), { kind: 'signin_use', use, why, source }, `Waiting for your fingerprint on the phone: ${what}`, { what, why, source });
  }

  /** The AI or an automation on this computer asks to sign something in. Resolves with the answer after the owner's fingerprint, or with why not. */
  async requestUse(args: Record<string, unknown>, source: UseSource): Promise<{ ok: boolean; say: string }> {
    const use = parseUse(args);
    if (!use) return { ok: false, say: 'Say what to sign in: the keyring, GitHub, a listed sudo command, or a check of everything.' };
    const id = `ask-${randomUUID()}`;
    const r = await this.startUse(id, use, cleanWhy(args.why), source);
    if (r.state !== 'needs_approval' || !r.ask) return { ok: r.ok, say: r.say };
    const askId = r.ask.askId;
    return await new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.waiters.delete(askId);
        resolve({ ok: false, say: 'Nobody approved it on the phone in time, so nothing was done.' });
      }, Math.max(1000, r.ask!.expiresAt - this.now() + 1500));
      timer.unref?.();
      this.waiters.set(askId, (a) => {
        clearTimeout(timer);
        this.waiters.delete(askId);
        resolve(a);
      });
    });
  }

  /** Tells whoever waits for this ask (an AI or an automation) how it ended. */
  private settle(askId: string, r: { ok: boolean; say: string }): void {
    this.waiters.get(askId)?.(r);
  }

  /** The window in front and whether typing a saved sign-in may go into it (a web browser only: never a terminal or an editor). */
  private async typeLoginAsk(id: string, args: Record<string, unknown>): Promise<AgentDeviceResult> {
    if (!this.d.typing?.enabled()) {
      this.record('type_login', 'refused: typing saved sign-ins is off on this computer');
      return this.no(id, `Typing saved sign-ins is off on ${this.d.name}. Turn it on in Remote control, Type saved sign-ins (it asks for your fingerprint).`, 'refused');
    }
    const host = typeof args.host === 'string' ? args.host.trim().toLowerCase() : '';
    if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host) || host.length > 253) return this.no(id, 'Say the site, like github.com.', 'refused');
    const what = typeof args.what === 'string' ? args.what : 'both';
    if (!TYPE_WHATS.has(what)) return this.no(id, 'Type the username and password, the username only, or the password only.', 'refused');
    if (!this.d.focus || !this.d.type || !this.d.credentials) return this.no(id, 'This computer cannot tell which window is in front, so it will not type a sign-in.', 'refused');
    const win = await this.d.focus.active().catch(() => null);
    if (!win) {
      this.record('type_login', 'refused: could not tell which window is in front', host);
      const st = await this.d.focus.status().catch(() => 'missing');
      return this.no(id, st === 'restart_needed' ? 'The focus helper is installed but starts at your next sign-in on the computer, so it cannot yet tell which window is in front.' : 'Could not tell which window is in front on this computer, so nothing will be typed.', 'refused');
    }
    if (!isBrowser(win)) {
      this.record('type_login', `refused: the window in front is not a web browser (${win.wmClass.slice(0, 40)})`, host);
      return this.no(id, `The window in front is not a web browser, so nothing will be typed. Open the sign-in page first (Show, or the Screen tab), then try again.`, 'refused');
    }
    const title = win.title.replace(/[^\x20-\x7e]+/g, ' ').replace(/[|~]/g, ' ').replace(/[^A-Za-z0-9 ._:()',&+/-]/g, ' ').replace(/ +/g, ' ').trim().slice(0, 50);
    return await this.ask(id, 'type_login', `${host}~${what}~${win.id}~${title}`, { kind: 'type_login', host, what: what as TypeWhat, windowId: win.id, wmClass: win.wmClass }, `Waiting for your fingerprint on the phone to type the saved sign-in for ${host} into the browser window in front.`);
  }

  /** After the yes: the window the approval named is brought to the front, checked, and only then is the saved sign-in fetched and typed. */
  private async typeLoginRun(id: string, w: Extract<Pending, { kind: 'type_login' }>, who: string): Promise<AgentDeviceResult> {
    const t = this.d.type;
    const fh = this.d.focus;
    if (!this.d.typing?.enabled() || !t || !fh || !this.d.credentials) return this.no(id, 'Typing saved sign-ins is off, so nothing was typed.', 'refused');
    if (this.d.canType && !(await this.d.canType())) return this.no(id, 'This computer has no way to type into a window, so nothing was typed.', 'refused');
    if (!(await fh.focus(w.windowId).catch(() => false))) {
      this.record('type_login', 'refused: the window the approval named is gone or could not be brought forward', w.host);
      return this.no(id, 'The window you approved is no longer there or could not be brought to the front. Nothing was typed.', 'refused');
    }
    const now = await fh.active().catch(() => null);
    if (!now || now.id !== w.windowId || !isBrowser(now)) {
      this.record('type_login', 'refused: another window took the front', w.host);
      return this.no(id, 'Another window took the front, so nothing was typed.', 'refused');
    }
    const c = await this.d.credentials(w.host);
    if (!c || (w.what !== 'user' && !c.password) || (w.what !== 'password' && !c.user)) {
      this.record('type_login', 'no saved sign-in for that site', w.host);
      return this.no(id, `There is no saved sign-in for ${w.host} on this computer. Save it in the Escanor vault (SITE_<SITE>_USER and SITE_<SITE>_PASSWORD, in this computer's own scope) or in the computer's keyring.`, 'failed');
    }
    // The values stay inside this block: typed through the tool's standard input, never logged, returned or kept.
    let typed = true;
    if (w.what !== 'password') typed = await t(c.user);
    if (typed && w.what === 'both') typed = await t('\t');
    if (typed && w.what !== 'user') typed = (await t(c.password)) && (await t('\n'));
    this.record('type_login', typed ? `typed the saved ${w.what === 'both' ? 'username and password' : w.what === 'user' ? 'username' : 'password'} into the approved browser window, with a fingerprint (${who})` : 'could not type', w.host);
    return typed ? this.ok(id, `Typed the saved sign-in for ${w.host} into the browser window you approved.`, { typed: true }) : this.no(id, 'Could not type into that window.');
  }

  private awakeData(): Record<string, unknown> {
    return this.awake.awakeUntil ? { awakeUntil: this.awake.awakeUntil } : {};
  }

  private async simple(id: string, action: string, args: Record<string, unknown>): Promise<AgentDeviceResult> {
    const a = parseAction(action, args);
    if ('error' in a) {
      this.record(action, `refused: ${a.error}`);
      return this.no(id, a.error, 'refused');
    }
    const r = await runComputerAction(a, this.d.computer);
    const target = 'url' in a && typeof a.url === 'string' ? hostOf(a.url) : 'app' in a ? a.app : undefined;
    this.record(action, r.ok ? r.say : `could not: ${r.say}`, target);
    return r.ok ? this.ok(id, r.say) : this.no(id, r.say);
  }

  /**
   * Connect it for me: read the clipboard (a key the provider's Copy button just put there) or empty it again. Rides on a live view
   * the owner approved with a fingerprint, like `input`. The text is returned to the server only: it is never logged or put in `say`.
   */
  private async clipboard(id: string, args: Record<string, unknown>): Promise<AgentDeviceResult> {
    const viewId = typeof args.viewId === 'string' ? args.viewId : '';
    const view = this.views.get(viewId);
    if (!viewId || !view || view.until <= this.now()) {
      if (viewId) this.views.delete(viewId);
      return this.no(id, 'The live view has ended. Start it again (it asks for your fingerprint).', 'expired');
    }
    if (view.decision.viewOnly || !view.decision.clipboard) return this.no(id, 'Your access policy does not let Escanor use the clipboard of this computer.', 'refused');
    const op = args.op;
    if (op !== 'read' && op !== 'clear') return this.no(id, 'The clipboard can be read or cleared.', 'refused');
    // GNOME and the native modes keep the live session's own clipboard route; the fixed programs are the way for the rest.
    const live = (await this.live.start().catch(() => ({ ok: false }))).ok && this.live.hasClipboard ? this.live : null;
    if (op === 'read') {
      let text: string | null = null;
      if (live) text = (await live.clipGet().catch(() => null))?.trim() ?? null;
      let missing = false;
      if (text === null) {
        const r = await readClipboard(this.d.clip);
        if (r.ok) text = r.text;
        else missing = r.missing;
      }
      if (text === null) {
        this.record('clipboard', 'could not read the clipboard');
        return this.no(id, missing ? CLIP_MISSING_SAY : 'Could not read the clipboard on this computer.', missing ? 'refused' : 'failed');
      }
      const out = [...text].slice(0, MAX_CLIP_READ).join('');
      this.record('clipboard', `read the clipboard (${[...out].length} characters) for a key the owner asked Escanor to capture`);
      return this.ok(id, 'Read the clipboard.', { text: out });
    }
    const viaLive = live ? live.clipSet('') : false;
    const r = await clearClipboard(this.d.clip);
    if (!r.ok && !viaLive) {
      this.record('clipboard', 'could not clear the clipboard');
      return this.no(id, r.missing ? CLIP_MISSING_SAY : 'Could not clear the clipboard on this computer.', r.missing ? 'refused' : 'failed');
    }
    this.record('clipboard', 'cleared the clipboard');
    return this.ok(id, 'Cleared the clipboard.');
  }

  private async show(id: string, args: Record<string, unknown>): Promise<AgentDeviceResult> {
    const url = typeof args.url === 'string' ? safeUrl(args.url) : null;
    if (!url || url.startsWith('mailto:')) return this.no(id, 'Only web pages (http or https) can be shown.', 'refused');
    const minutes = clampMinutes(args.minutes, 30);
    const awake = await this.awake.start(minutes);
    const wantFull0 = args.fullscreen !== false;
    // Which windows exist now, so the browser window this page opens in can be told apart afterwards.
    const before = wantFull0 && this.d.focus && (await this.d.focus.status().catch(() => '')) === 'ready' ? await this.d.focus.windows().catch(() => null) : null;
    const opened = await openPage(url, this.d.screen);
    if (!opened.ok) {
      this.record('show', 'could not open the page', hostOf(url));
      return this.no(id, 'Could not open that page in a browser here.');
    }
    const wantFull = args.fullscreen !== false;
    const full = wantFull ? await goFullscreen(this.d.screen, this.d.focus, before) : { done: false, how: 'not asked' };
    this.record('show', `opened the page${full.done ? ' full screen' : ''}, screen kept awake ${awake.ok ? `${minutes} minutes` : '(could not hold it)'}`, hostOf(url));
    // A window tool changed that window itself (known); a key press only asked the browser (the phone's live view shows the result).
    const fullTxt = !wantFull ? '' : full.done ? (full.how === 'window' || full.how === 'shell' ? ' full screen' : full.how === 'key_restart' ? ' (asked the browser to go full screen; sign out and in once on the computer so the focus helper starts and makes it certain)' : ' (asked the browser to go full screen)') : ` (not full screen: ${full.how})`;
    const awakeTxt = awake.ok ? `The screen stays awake for ${minutes} minutes.` : 'The screen may go to sleep: nothing could hold it awake here.';
    return this.ok(id, `Showing ${hostOf(url)}${fullTxt}. ${awakeTxt}`, { fullscreen: full.done, awake: awake.ok, ...this.awakeData() });
  }

  /** A view is granted (by the fingerprint yes, or by the owner's policy): it lasts what the policy says, the other apps are told, and the first picture goes back. */
  private async grantView(id: string, decision: Extract<ViewDecision, { allow: true }>, how: string): Promise<AgentDeviceResult> {
    if (!decision.allowLocked && (await screenLocked(this.d.screen ?? {}).catch(() => false))) {
      this.record('screenshot', 'refused by the access policy: the screen is locked');
      return this.no(id, 'Your access policy does not allow viewing while the screen is locked.', 'refused');
    }
    const viewId = randomUUID();
    const start = this.now();
    const until = start + decision.minutes * 60_000;
    this.views.set(viewId, { until, hardEnd: start + decision.maxMinutes * 60_000, decision });
    this.record('screenshot', `live view${decision.viewOnly ? '' : ' and control'} started for ${decision.minutes} minutes with ${how}`);
    // Kept awake while the owner looks, so it does not blank or lock by itself in the middle.
    await this.awake.start(Math.max(1, Math.min(decision.maxMinutes, 240)));
    this.d.sendView?.(viewId, until);
    // The live session first (it unlocks the screen the fingerprint yes covers), so the notice can be the one with a Stop button.
    const started = await this.live.start();
    if (started.ok && started.unlocked) this.record('unlock_screen', 'unlocked the screen for the live view the owner approved with a fingerprint');
    const until12 = new Date(until).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    if (started.ok && this.live.kind === 'gnome') this.live.banner('Escanor: your screen is being viewed', `From your phone, until ${until12}. Press Stop to end it now.`);
    else this.notices.set(viewId, await notice('Escanor: your screen is being viewed', `From your phone, until ${until12}.`, decision.minutes * 60_000, this.d.screen ?? {}));
    return await this.shoot(id, viewId, until);
  }

  /**
   * The screen for a live view: the live session's newest picture (it is started again when it stopped, for example because the
   * screen locked by itself while nobody touched it: the fingerprint yes for this view covers unlocking it), else one picture.
   */
  private async shoot(id: string, viewId: string, until: number, say = 'Here is the screen.', since?: number): Promise<AgentDeviceResult> {
    let shot = null;
    if (!this.live.running) {
      const s = await this.live.start();
      if (s.ok && s.unlocked) this.record('unlock_screen', 'unlocked the screen for the live view the owner approved with a fingerprint');
    }
    if (this.live.running) shot = since === undefined ? await this.live.frame() : await this.live.frameAfter(since);
    if (!shot) {
      const r = await takeScreenshot(this.d.screen);
      if (!r.ok) {
        this.record('screenshot', 'could not take a picture', 'live view');
        return this.no(id, r.say);
      }
      shot = r.shot;
    }
    return this.ok(id, say, { viewId, expiresAt: until, imageB64: shot.b64, mime: shot.mime, width: shot.width, height: shot.height, ...(this.d.highlight?.() ? { highlight: this.d.highlight() } : {}) });
  }

  private pair(id: string, args: Record<string, unknown>): AgentDeviceResult {
    const publicKey = typeof args.publicKey === 'string' ? args.publicKey : '';
    const name = typeof args.name === 'string' ? args.name : 'Phone';
    if (!publicKey) return this.no(id, 'The phone did not send its key.', 'refused');
    if (typeof args.code !== 'string' || !args.code.trim()) {
      const code = this.pairing.begin(this.now());
      this.d.showCode(code);
      this.record('pair_phone', 'a phone asked to pair; a code was shown on this computer\'s screen');
      return { type: 'device_result', requestId: id, ok: true, state: 'code_needed', say: `A six-digit code is showing on the screen of ${this.d.name}. Type it here to pair this phone.` };
    }
    if (!this.pairing.check(args.code, this.now())) {
      this.record('pair_phone', 'refused: wrong or old pairing code');
      return this.no(id, 'That code is not right, or it is too old. Ask for a new code.', 'refused');
    }
    const row = this.d.keys.add(publicKey, name, this.now());
    if (!row) return this.no(id, 'That phone key could not be saved.', 'refused');
    this.record('pair_phone', `paired ${row.name} for fingerprint approvals`);
    void this.syncHelper().catch(() => 'failed'); // the login screen learns the new phone too (the person is at the computer now)
    return this.ok(id, `This phone is paired with ${this.d.name}. Fingerprint approvals work now.`, { keyId: row.keyId });
  }

  /** The phone's answer to an ask. */
  async approve(msg: HubDeviceApproval): Promise<AgentDeviceResult> {
    const id = msg.requestId;
    try {
      if (msg.approve !== true) {
        const had = this.asks.drop(msg.askId);
        if (had) this.record('ask', 'the owner said not now on the phone');
        this.d.sendAskDone(msg.askId);
        this.settle(msg.askId, { ok: false, say: 'You said not now on the phone, so nothing was done.' });
        return this.ok(id, 'Cancelled. Nothing was done.');
      }
      const p = this.asks.take(msg.askId, this.now());
      this.d.sendAskDone(msg.askId);
      if (!p) {
        this.settle(msg.askId, { ok: false, say: 'The request ran out, so nothing was done.' });
        return this.no(id, 'That request ran out or was already answered. Ask again.', 'expired');
      }
      const yes = await this.verifyYes(p.ask, msg, p.what.also ?? []);
      if (!yes.ok) {
        this.settle(p.ask.askId, { ok: false, say: 'The fingerprint answer did not check out, so nothing was done.' });
        if (yes.why === 'unknown_key') {
          this.record(p.ask.purpose, `refused: the phone signed with a key neither this computer nor the account trusts (phone key ${typeof msg.keyId === 'string' ? msg.keyId.slice(0, 16) : 'none'})`, p.ask.subject);
          return this.no(id, 'This phone is not set up for fingerprint approvals (its fingerprint key changed). Open Machines, this computer, Remote control, then Turn on fingerprint approvals, once.', 'not_paired');
        }
        if (yes.why === 'recheck_needed' || yes.why === 'bad_recheck') {
          this.record(p.ask.purpose, `refused: the ${(p.what.also ?? []).join(' and ')} you set as needed was ${yes.why === 'bad_recheck' ? 'wrong' : 'missing'}`, p.ask.subject);
          return this.no(id, yes.why === 'bad_recheck' ? 'The password or code was not right, so nothing was done.' : 'Your access settings also need your password or a code for this. Nothing was done.', 'refused');
        }
        this.record(p.ask.purpose, `refused: ${yes.why === 'not_paired' ? 'no phone is set up' : 'the fingerprint answer did not check out'}`, p.ask.subject);
        return this.no(id, yes.why === 'not_paired' ? 'No phone is set up for fingerprint approvals, so nothing was done.' : 'The fingerprint answer did not check out, so nothing was done.', yes.why === 'not_paired' ? 'not_paired' : 'refused');
      }
      const w = p.what;
      const remoteFree = w.kind === 'enable' || w.kind === 'enable_signin' || w.kind === 'signin_use' || w.kind === 'signin_window' || w.kind === 'chat_signin_window';
      if (!remoteFree && !this.d.remote.enabled()) return this.no(id, `Remote control is off on ${this.d.name}.`, 'remote_off');
      switch (w.kind) {
        case 'terminal': {
          const t = this.terms.open();
          if (!t.ok) return this.no(id, t.say, 'refused');
          this.record('terminal', `the owner said yes with a fingerprint (${yes.who}); a terminal was opened`);
          // Announced to every app of the account like a screen view (the website that asked is not the one that answered the phone's card).
          this.d.sendView?.(t.termId, t.expiresAt);
          return this.ok(id, 'The terminal is open.', { termId: t.termId, expiresAt: t.expiresAt });
        }
        case 'deps_install': {
          const host = detectHost();
          const plan = buildPlan(await checkDeps({ host, features: w.features }), host, os.homedir());
          const r = await runPlan(plan, { allowAdmin: true, features: w.features });
          this.record('deps_install', `the owner said yes with a fingerprint (${yes.who}); ${r.say}`);
          return this.ok(id, r.say, { results: r.results, stillMissing: r.stillMissing });
        }
        case 'enable':
          this.d.remote.set(true);
          this.record('set_remote_control', `the owner turned Remote control on with a fingerprint (${yes.who})`, 'on');
          return this.ok(id, `Remote control is on for ${this.d.name}.`, { remoteControl: true });
        case 'enable_typing':
          this.d.typing?.set(true);
          this.record('set_type_secrets', `the owner let this computer type saved sign-ins, with a fingerprint (${yes.who})`, 'on');
          return this.ok(id, `${this.d.name} can now type saved sign-ins, each time only after your fingerprint.`, { typeSecrets: true });
        case 'type_login':
          return await this.typeLoginRun(id, w, yes.who);
        case 'enable_signin': {
          const s = this.d.signin;
          if (!s || s.lockedByEnv()) return this.no(id, 'This computer cannot do that.', 'refused');
          s.apply(w.patch);
          this.record('set_signin', `the owner changed what Escanor may sign in with, with a fingerprint (${yes.who})`, w.patch.enabled === true ? 'on' : 'more');
          return this.ok(id, `${this.d.name} may use the saved secrets you chose. Every use asks for your fingerprint and is in the log.`, { signin: { available: true, ...s.status() } });
        }
        case 'chat_signin_window': {
          const s = this.d.signin;
          if (!s) return this.no(id, 'This computer cannot do that yet.', 'refused');
          const until = s.chatWindow.start(w.minutes, yes.who);
          this.record('set_chat_signin_window', `the owner allowed AI chats to handle sign-ins for ${w.minutes} minutes, with a fingerprint (${yes.who})`, 'on');
          return this.ok(id, `For ${w.minutes} minutes, AI chats on ${this.d.name} may handle sign-ins without asking each time. You can stop it any time.`, { signin: { available: true, ...s.status() }, expiresAt: until });
        }
        case 'signin_window': {
          const s = this.d.signin;
          if (!s || s.lockedByEnv() || !s.enabled()) return this.no(id, 'Let Escanor sign in for me is off on this computer.', 'refused');
          const until = s.window.start(w.minutes, yes.who);
          this.record('set_signin_window', `the owner allowed ${w.minutes} minutes without asking again, with a fingerprint (${yes.who})`, 'on');
          return this.ok(id, `For ${w.minutes} minutes, ${this.d.name} will not ask again for the saved secrets you allowed. You can stop it any time.`, { signin: { available: true, ...s.status() }, expiresAt: until });
        }
        case 'signin_use': {
          const s = this.d.signin;
          if (!s) {
            this.settle(p.ask.askId, { ok: false, say: 'This computer cannot sign in for you yet.' });
            return this.no(id, 'This computer cannot sign in for you yet. Update the Escanor agent on it.', 'refused');
          }
          const r = await s.run(w.use, { via: 'approval', who: yes.who });
          this.record('signin_use', `${r.ok ? 'done' : 'could not'} after a fingerprint (${yes.who}; asked by ${w.source === 'phone' ? 'the owner' : w.source === 'ai' ? 'the AI' : 'an automation'})`, w.use.kind);
          this.settle(p.ask.askId, r);
          return r.ok ? this.ok(id, r.say, { signin: { available: true, ...s.status() } }) : this.no(id, r.say);
        }
        case 'schedule_wake': {
          const wk = this.d.wakeAt;
          if (!wk) return this.no(id, 'This computer cannot be set to wake at a time.', 'refused');
          const set = await wk.alarm(w.epoch);
          if (set) wk.set(w.epoch);
          this.record('schedule_wake', set ? `set the computer to wake at the time asked, with a fingerprint (${yes.who})` : 'could not set the clock chip');
          return set ? this.ok(id, `${this.d.name} will wake at ${new Date(w.epoch * 1000).toLocaleString()} if it is asleep (not shut down).`, { wakeAt: w.epoch * 1000 }) : this.no(id, 'This computer would not let Escanor set a wake time. Allow it once with: sudo visudo -f /etc/sudoers.d/escanor-rtcwake (a line letting your user run rtcwake without a password).');
        }
        case 'unlock_setup': {
          const subject = p.ask.subject;
          const want = (await this.helperWanted()) ?? [];
          const same = want.map((k) => k.keyId).sort().join(',') === [...w.keyIds].sort().join(',');
          const r = same && this.d.helper ? await this.d.helper.enroll(want.map((k) => ({ publicKey: k.publicKey, name: k.name })), { purpose: p.ask.purpose, subject, nonce: p.ask.nonce, machine: p.ask.machine, keyId: String(msg.keyId ?? ''), signature: String(msg.signature ?? '') }) : null;
          if (r?.ok) this.noteSynced(w.keyIds);
          this.record('unlock_setup', r?.ok ? `added the phones to the sign-in helper, with a fingerprint (${yes.who})` : `the sign-in helper did not take the phones${r ? ` (${r.code ?? 'refused'})` : ''}`);
          if (r?.ok) return this.ok(id, 'Done. Your phones can now sign you in at the login screen, each time with a fingerprint.', { unlock: await this.unlockData() });
          if (r?.code === 'no_key') return this.no(id, notSetUpYet(this.d.name), 'refused');
          return this.no(id, 'The sign-in helper did not take it. Try again; if it keeps failing, update Escanor on this computer.');
        }
        case 'unlock': {
          if (w.login) {
            return await this.loginRun(id, { purpose: p.ask.purpose, subject: p.ask.subject, nonce: p.ask.nonce, machine: p.ask.machine, keyId: String(msg.keyId ?? ''), signature: String(msg.signature ?? '') }, yes.who);
          }
          const r = await unlockScreen(this.d.screen);
          this.record('unlock_screen', r.ok ? `unlocked with a fingerprint (${yes.who})` : `could not: ${r.say}`);
          return r.ok ? this.ok(id, r.say) : this.no(id, r.say);
        }
        case 'signin':
          return await this.signIn(id, w.url, w.host, yes.who);
        case 'view': {
          const decision = this.viewPolicy.forView({ machine: this.d.machine, now: this.now() });
          if (!decision.allow) {
            this.record('screenshot', `refused by the access policy: ${decision.reason}`);
            return this.no(id, decision.reason, 'refused');
          }
          return await this.grantView(id, decision, `a fingerprint (${yes.who})`);
        }
      }
    } catch {
      return this.no(id, 'Something went wrong doing that on this computer.');
    }
  }

  /**
   * Sign in to one site after the fingerprint yes for that exact site. The page is opened in the person's own browser, where its own
   * saved password or passkey fills it. Typing a stored sign-in is its own action (type_login), never part of this one.
   */
  private async signIn(id: string, url: string, host: string, who: string): Promise<AgentDeviceResult> {
    const opened = await openPage(url, this.d.screen);
    if (!opened.ok) {
      this.record('sign_in', 'could not open the page', host);
      return this.no(id, 'Could not open that page in a browser here.');
    }
    this.record('sign_in', `opened for the browser's own saved sign-in, with a fingerprint (${who})`, host);
    return this.ok(id, `Opened ${host}. Your browser's saved password or passkey fills the sign-in there. (To have Escanor type a saved sign-in, use Type a saved sign-in.)`, { typed: false });
  }
}

/** Where the trusted-phone list and the switch live, next to the agent's other settings. */
export const jarvisFiles = (dataDir: string) => ({ keys: `${dataDir}/jarvis-keys.json`, remote: `${dataDir}/remote-control.json`, typing: `${dataDir}/type-secrets.json` });
