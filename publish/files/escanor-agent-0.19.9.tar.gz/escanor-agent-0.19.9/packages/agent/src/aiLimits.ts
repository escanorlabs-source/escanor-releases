import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';

/**
 * When an AI account hits its limit (the Claude subscription's five-hour or weekly limit, an API key's rate or quota limit, or the
 * Escanor plan's limit), ALL work on that account waits for the reset, not just the chat that was refused. This keeps the list of
 * held accounts and when each resets, on disk (so an agent restart or a night's sleep does not lose it), and starts everything
 * again at that time by itself. The holding itself is done by the session manager (queue, idle processes); this is the clock.
 *
 * The timer looks again at least every minute and compares the real clock: a computer that slept through the reset starts the work
 * as soon as it wakes (a plain long timer does not count the time the computer was asleep).
 */

export type LimitSource = 'message' | 'usage' | 'plan';

export type LimitEntry = {
  accountId: string;
  /** When the limit resets (ms since 1970). */
  resetsAt: number;
  source: LimitSource;
  /** When it was first held. */
  since: number;
  /** Plain name of the account for the apps ("Work", "Personal"). */
  label?: string;
};

export type LimitStore = { load: () => LimitEntry[]; save: (e: LimitEntry[]) => void };

export function fileLimitStore(file: string): LimitStore {
  return {
    load: () => {
      try {
        const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
        if (!Array.isArray(j)) return [];
        return j.filter(
          (e): e is LimitEntry =>
            !!e && typeof (e as LimitEntry).accountId === 'string' && Number.isFinite((e as LimitEntry).resetsAt) && ['message', 'usage', 'plan'].includes((e as LimitEntry).source),
        );
      } catch {
        return [];
      }
    },
    save: (e) => {
      try {
        mkdirSync(dirname(file), { recursive: true });
        const tmp = `${file}.tmp`;
        writeFileSync(tmp, JSON.stringify(e), { mode: 0o600 });
        renameSync(tmp, file);
      } catch (err) {
        console.error('Saving the AI limit list failed', err);
      }
    },
  };
}

/** The most the timer sleeps between two looks at the clock. */
export const LOOK_EVERY_MS = 60_000;
/** Work starts this long after the reset (the reset is the provider's clock, not ours). */
export const RESET_MARGIN_MS = 5_000;
/** Claude's usage figure at or above this holds the account before it hits the wall. */
export const NEAR_LIMIT_PCT = 98;

export class AiLimitHolds {
  private entries = new Map<string, LimitEntry>();
  private timer: ReturnType<typeof setTimeout> | null = null;
  private stopped = false;
  private now: () => number;
  private margin: number;

  constructor(
    private o: {
      store?: LimitStore;
      now?: () => number;
      marginMs?: number;
      /** Accounts whose reset has come: start their work again. */
      onRelease: (accountIds: string[]) => void;
      /** The list changed (held, extended or released): tell the apps. */
      onChange?: () => void;
      /** Test hooks. */
      setTimer?: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
      clearTimer?: (t: ReturnType<typeof setTimeout>) => void;
    },
  ) {
    this.now = o.now ?? Date.now;
    this.margin = o.marginMs ?? RESET_MARGIN_MS;
    for (const e of o.store?.load() ?? []) this.entries.set(e.accountId, e);
  }

  /** What is still held (reset not yet passed). */
  all(): LimitEntry[] {
    return [...this.entries.values()].filter((e) => e.resetsAt + this.margin > this.now()).sort((a, b) => a.resetsAt - b.resetsAt);
  }

  get(accountId: string): LimitEntry | undefined {
    const e = this.entries.get(accountId);
    return e && e.resetsAt + this.margin > this.now() ? e : undefined;
  }

  /** The soonest reset among held accounts. */
  nextReset(): number | undefined {
    const a = this.all();
    return a.length ? a[0].resetsAt : undefined;
  }

  /**
   * Hold an account until `resetsAt`. A later time replaces an earlier one (the provider moved it); an earlier or equal one does not
   * shorten a hold the provider itself named (a 'usage' reading never overrides a 'message' one). True when something changed.
   */
  hold(accountId: string, resetsAt: number, source: LimitSource, label?: string): boolean {
    if (!accountId || !Number.isFinite(resetsAt)) return false;
    const prev = this.get(accountId);
    if (prev) {
      const later = resetsAt > prev.resetsAt;
      const better = prev.source === 'usage' && source !== 'usage';
      if (!later && !better) {
        if (label && !prev.label) this.entries.set(accountId, { ...prev, label });
        return false;
      }
      this.entries.set(accountId, { ...prev, resetsAt: better ? resetsAt : Math.max(resetsAt, prev.resetsAt), source: better ? source : prev.source, ...(label ? { label } : {}) });
    } else {
      this.entries.set(accountId, { accountId, resetsAt, source, since: this.now(), ...(label ? { label } : {}) });
    }
    this.save();
    this.arm();
    this.o.onChange?.();
    return true;
  }

  /** Lift a hold early (the usage figure fell, or the reset came sooner than said). Only a hold of that source. */
  lift(accountId: string, source: LimitSource): boolean {
    const e = this.entries.get(accountId);
    if (!e || e.source !== source) return false;
    this.entries.delete(accountId);
    this.save();
    this.arm();
    this.o.onChange?.();
    this.o.onRelease([accountId]);
    return true;
  }

  /** Release every account whose reset has passed (called by the timer, and when the computer wakes). Returns them. */
  check(): string[] {
    const due = [...this.entries.values()].filter((e) => e.resetsAt + this.margin <= this.now()).map((e) => e.accountId);
    if (due.length) {
      for (const id of due) this.entries.delete(id);
      this.save();
      this.o.onChange?.();
      this.o.onRelease(due);
    }
    this.arm();
    return due;
  }

  /** At start: what was held when the agent stopped is held again, and what reset meanwhile starts now. */
  start(): void {
    this.stopped = false;
    const had = this.entries.size > 0;
    this.check();
    if (had) this.o.onChange?.();
    this.arm();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) (this.o.clearTimer ?? clearTimeout)(this.timer);
    this.timer = null;
  }

  private arm(): void {
    if (this.timer) (this.o.clearTimer ?? clearTimeout)(this.timer);
    this.timer = null;
    if (this.stopped || this.entries.size === 0) return;
    const soon = Math.min(...[...this.entries.values()].map((e) => e.resetsAt + this.margin));
    const delay = Math.min(LOOK_EVERY_MS, Math.max(0, soon - this.now()) + 1);
    const t = (this.o.setTimer ?? setTimeout)(() => {
      this.timer = null;
      this.check();
    }, delay);
    (t as { unref?: () => void }).unref?.();
    this.timer = t;
  }

  private save(): void {
    this.o.store?.save([...this.entries.values()]);
  }
}

// ---------- what the limit message says ----------

export type LimitText = { kind: 'usage' | 'rate'; resetsAt?: number };

/** Held this long when the provider only says "too many requests" (a per-minute limit). */
export const RATE_WAIT_MS = 2 * 60_000;

/**
 * The limit and its reset time from the words a tool prints when an account has no room left:
 *  - `Claude AI usage limit reached|1760000000` (Unix seconds after the bar),
 *  - `... resets 3pm` / `resets at 3:40 pm` / `resets 15:40` (the next time that clock reads that, on this computer),
 *  - `retry after 30 seconds` / `try again in 5 minutes` / `retry-after: 120`.
 * Null when the text is not about a limit.
 */
export function parseLimitText(text: string, now: number): LimitText | null {
  if (!/usage limit|rate[ _-]?limit|\b429\b|quota|resource[_ ]exhausted|too many requests|hit your limit|limit reached/i.test(text)) return null;
  const kind: LimitText['kind'] = /usage limit|hit your limit|limit reached|quota|resets? /i.test(text) ? 'usage' : 'rate';
  const epoch = /limit reached\|(\d{10,13})/i.exec(text) ?? /\|(\d{10})\b/.exec(text);
  if (epoch) {
    const n = Number(epoch[1]);
    const ms = n < 1e12 ? n * 1000 : n;
    if (ms > now) return { kind, resetsAt: ms };
  }
  const clock = /resets?(?:\s+at)?\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/i.exec(text);
  if (clock) {
    let h = Number(clock[1]);
    const m = clock[2] ? Number(clock[2]) : 0;
    const ap = clock[3]?.toLowerCase();
    if (ap === 'pm' && h < 12) h += 12;
    if (ap === 'am' && h === 12) h = 0;
    if (h <= 23 && m <= 59) {
      const d = new Date(now);
      d.setHours(h, m, 0, 0);
      if (d.getTime() <= now) d.setDate(d.getDate() + 1);
      return { kind, resetsAt: d.getTime() };
    }
  }
  const wait = /(?:retry[- ]after:?|try again in|retry in)\s+(\d+(?:\.\d+)?)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|h)?/i.exec(text);
  if (wait) {
    const n = Number(wait[1]);
    const u = (wait[2] ?? 's').toLowerCase();
    const ms = u.startsWith('h') ? n * 3_600_000 : u.startsWith('m') ? n * 60_000 : n * 1000;
    return { kind, resetsAt: now + ms };
  }
  return { kind };
}

/** "AI limit reached on Work: starts again at 3:40 pm" (the machine's local time). */
export function limitStatusText(label: string | undefined, resetsAt: number, now = Date.now()): string {
  const d = new Date(resetsAt);
  const h = d.getHours();
  const time = `${h % 12 === 0 ? 12 : h % 12}:${String(d.getMinutes()).padStart(2, '0')} ${h < 12 ? 'am' : 'pm'}`;
  const sameDay = new Date(now).toDateString() === d.toDateString();
  const when = sameDay ? time : `${d.toLocaleDateString('en-GB', { weekday: 'short' })} ${time}`;
  return `AI limit reached${label ? ` on ${label}` : ''}: starts again at ${when}`;
}
