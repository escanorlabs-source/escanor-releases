import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { chmodSync, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, realpathSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { homedir, userInfo } from 'node:os';
import { join } from 'node:path';
import { ACCOUNT_META_FILE, PENDING_MARK, refreshProfiles, type ClaudeProfile } from './profiles.js';
import { escanorApiUrl } from './deviceMcp.js';
import { switchOn } from './switches.js';

/**
 * Workspace AI accounts: sign in to an account once, from any device, and every machine of the workspace can use it.
 *
 * The login lives in the workspace (Escanor's backend keeps it encrypted) and ONLY the backend renews it: Claude's sign-in rotates its
 * refresh token on every use, so two machines that each renewed it would sign each other out. This machine therefore never holds the
 * refresh token of a shared account. It asks the backend (POST /agent/device/ai-accounts, signed in with the hub agent token like
 * /agent/device/mcp) every SYNC_MS and on every hub connect, and writes the short-lived access token into that account's folder as
 * `.credentials.json` with NO refresh token. Claude Code then never tries to renew by itself (it answers "no_refresh_token" and
 * re-reads the file), so the agent's next visit replaces the token before the old one ends. A folder the backend no longer lists
 * (the account was removed from the workspace) loses its login here.
 *
 * Import: `share(accountId)` uploads this machine's own sign-in of an account to the workspace, then switches the folder to the
 * same pulled login (the refresh token leaves this machine for good, as it must). Tokens are never logged.
 *
 * One holder of a refresh token: a sign-in already on this computer (~/.claude, ~/.claude-*, or on a Mac the Keychain item
 * "Claude Code-credentials") is copied into an Escanor account folder and uploaded. Right after that upload succeeds, the ORIGINAL is
 * released too (releaseOrigin): its refresh token is dropped, exactly as writePulledLogin does for pulled logins, and the rest (access
 * token, end time, scopes) is kept, so `claude` in a terminal still works. The full original is first saved next to it as
 * `.credentials.json.escanor-backup` (0600), and the file is replaced atomically. Without this, ~/.claude and the backend would hold the
 * same refresh token and, since Claude rotates it on every renewal, each would sign the other out. While the original stays released
 * (no refresh token in it), every visit writes the workspace's fresh access token into it as well (mirrorOrigins), so the terminal login
 * keeps working with the backend's refresher owning rotation. When the person signs in again in the terminal (a new refresh token
 * appears in the original), the agent stops writing into it; if the workspace's copy of that email needs a new sign-in, that fresh
 * login repairs it (and is released in turn).
 */

/** In the profiles folder: which sign-ins already on this computer were copied into an Escanor account (key -> account folder), so each is copied once and one the person removed stays removed. */
export const IMPORTED_FILE = '.escanor-imported.json';

/** In an account folder that comes from the workspace: which account, and the end time (ms) of the token written. */
export const WORKSPACE_MARK = '.escanor-workspace.json';
export const SYNC_MS = 20 * 60_000;
export const RETRY_MS = 60_000;
export const MAX_RETRY_MS = 15 * 60_000;
const TIMEOUT_MS = 20_000;

export type WorkspaceMark = { id: string; expiresAt?: number; label?: string };

export function workspaceAccountsEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchOn(env.ESCANOR_WORKSPACE_ACCOUNTS, true);
}

type Json = Record<string, unknown>;
const isObj = (v: unknown): v is Json => !!v && typeof v === 'object' && !Array.isArray(v);
/** A login this machine could hand over: an access token and a refresh token. */
const usable = (l: Json | null): l is Json => !!l && typeof l.accessToken === 'string' && typeof l.refreshToken === 'string' && !!l.refreshToken;

/**
 * A profile entry that is a link to a folder elsewhere (e.g. `claude1` -> ~/.claude) is the person's own Claude folder: the terminal's
 * `claude` signs in there by itself. The workspace never writes a login into it, never drops it and never shares it, or every sync
 * would swap the terminal's account for the workspace's one.
 */
export function isLinkedFolder(dir: string): boolean {
  try {
    return lstatSync(dir).isSymbolicLink();
  } catch {
    return false;
  }
}

export function readMark(dir: string): WorkspaceMark | null {
  try {
    const j = JSON.parse(readFileSync(join(dir, WORKSPACE_MARK), 'utf8')) as unknown;
    return isObj(j) && typeof j.id === 'string' && j.id ? { id: j.id, ...(typeof j.expiresAt === 'number' ? { expiresAt: j.expiresAt } : {}), ...(typeof j.label === 'string' ? { label: j.label } : {}) } : null;
  } catch {
    return null;
  }
}

function writeAtomic(file: string, text: string): void {
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, text, { mode: 0o600 });
  renameSync(tmp, file);
  try {
    chmodSync(file, 0o600);
  } catch {
    // not supported on this file system (Windows)
  }
}

function readJson(file: string): Json | null {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
    return isObj(j) ? j : null;
  } catch {
    return null;
  }
}

/** The sign-in a folder holds (Claude's `.credentials.json` claudeAiOauth), or null. */
export function readLogin(dir: string): Json | null {
  const j = readJson(join(dir, '.credentials.json'));
  return j && isObj(j.claudeAiOauth) ? j.claudeAiOauth : null;
}

/** Writes a pulled login into a folder: the access token and its end time, never a refresh token. Other things in the file are kept. */
export function writePulledLogin(dir: string, oauth: Json): void {
  mkdirSync(dir, { recursive: true, mode: 0o700 });
  const file = join(dir, '.credentials.json');
  const prev = readJson(file) ?? {};
  const { refreshToken: _r, refreshTokenExpiresAt: _e, ...rest } = oauth;
  writeAtomic(file, JSON.stringify({ ...prev, claudeAiOauth: rest }));
}

export type AccountItem = {
  id: string;
  slug: string;
  provider?: string;
  label?: string;
  email?: string | null;
  status?: string;
  credentials?: { claudeAiOauth?: Json };
  profile?: Json;
};
export type SyncAnswer = { kind: 'ok'; accounts: AccountItem[]; removed: string[] } | { kind: 'off' } | { kind: 'retry'; reason: string; retryAfterMs?: number };
/** A hub (re)connect asks for a visit only when the last good one is older than this: a link that flaps must not use up Escanor's limit. */
export const CONNECT_GAP_MS = 60_000;

/** Retry-After (seconds, or an HTTP date) in ms, capped at an hour; undefined when absent or unreadable. */
export function retryAfterMs(v: string | null | undefined, now = Date.now()): number | undefined {
  if (!v) return undefined;
  const secs = Number(v);
  const ms = Number.isFinite(secs) ? secs * 1000 : Date.parse(v) - now;
  return Number.isFinite(ms) && ms > 0 ? Math.min(ms, 3_600_000) : undefined;
}

export type Opts = {
  apiUrl: string;
  hubToken: () => string;
  vmName: string;
  agentVersion: string;
  profilesDir: string;
  profiles: ClaudeProfile[];
  /** Accounts with a chat running now: their folder is never moved aside. */
  busyAccounts?: () => Set<string>;
  /** The usage figures this machine read per profile id (accountUsage.ts); shared with the workspace. */
  usage?: () => Record<string, unknown> | undefined;
  fetchImpl?: typeof fetch;
  log?: (line: string) => void;
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
  onChange?: () => void;
  /**
   * Claude sign-ins already on this computer outside the profiles folder (the machine's own ~/.claude, other ~/.claude-* folders): copied
   * into an Escanor account and shared with the workspace. Off when absent. The originals are only read, never changed.
   */
  existing?: {
    /** The machine's own login folder (normally ~/.claude). */
    ownDir: string | null;
    /** Where other Claude folders may sit (default: the home folder). */
    home?: string;
    /** Default process.platform. On darwin the own login is also looked for in the Keychain. */
    platform?: NodeJS.Platform;
    /** The Keychain (tests inject it; default: the `security` tool). Only used on darwin. */
    keychain?: { read: () => string | null; write: (text: string) => void };
  };
};

/** Where an imported sign-in came from: a folder's `.credentials.json`, or (Mac) the Keychain item Claude Code keeps it in. */
type Origin = { dir: string; keychain?: boolean; released?: boolean };
type ExistingLogin = { dir: string; login: Json; keychain: boolean; claudeJson: Json | null; email: string; uuid: string; key: string };
type ImportedState = { done: Record<string, string>; from: Record<string, Origin> };

/** The Keychain item Claude Code keeps the login of the default ~/.claude in, on a Mac. */
export const KEYCHAIN_SERVICE = 'Claude Code-credentials';
export const BACKUP_SUFFIX = '.escanor-backup';

/** Reads Claude Code's login from the macOS Keychain (`security find-generic-password -s ... -w`): the JSON text, or null. */
export function readKeychainLogin(): string | null {
  try {
    const out = execFileSync('security', ['find-generic-password', '-s', KEYCHAIN_SERVICE, '-w'], { encoding: 'utf8', timeout: 10_000, stdio: ['ignore', 'pipe', 'ignore'] });
    return out.trim() || null;
  } catch {
    return null;
  }
}

/** Replaces Claude Code's Keychain item (-U updates it). The value is passed hex-encoded (-X); it never holds a refresh token. */
export function writeKeychainLogin(text: string): void {
  execFileSync('security', ['add-generic-password', '-U', '-a', userInfo().username, '-s', KEYCHAIN_SERVICE, '-X', Buffer.from(text, 'utf8').toString('hex')], { timeout: 10_000, stdio: 'ignore' });
}

export class WorkspaceAccounts {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private inFlight: Promise<void> | null = null;
  private failures = 0;
  private stopped = false;
  private lastSay = '';

  constructor(private readonly o: Opts) {}

  private said = new Set<string>();
  /** Says a line once per key for the life of the agent (things retried every visit that would otherwise fill the log). */
  private sayOnce(key: string, line: string): void {
    if (this.said.has(key)) return;
    if (this.said.size > 200) this.said.clear();
    this.said.add(key);
    (this.o.log ?? console.log)(line);
  }

  private say(key: string, line: string): void {
    if (key === this.lastSay) return;
    this.lastSay = key;
    (this.o.log ?? console.log)(line);
  }

  start(): void {
    this.stopped = false;
    void this.syncNow();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  /** Folders this machine got from the workspace: profile id (folder name) to its mark. */
  managed(): Map<string, WorkspaceMark> {
    const out = new Map<string, WorkspaceMark>();
    if (!existsSync(this.o.profilesDir)) return out;
    for (const name of readdirSync(this.o.profilesDir)) {
      if (name.startsWith('.') || isLinkedFolder(join(this.o.profilesDir, name))) continue;
      const mark = readMark(join(this.o.profilesDir, name));
      if (mark) out.set(name, mark);
    }
    return out;
  }

  isShared(profileId: string): boolean {
    const dir = join(this.o.profilesDir, profileId);
    return !isLinkedFolder(dir) && readMark(dir) !== null;
  }

  private schedule(ms: number): void {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    const t = (this.o.setTimer ?? setTimeout)(() => void this.syncNow(), ms);
    (t as { unref?: () => void }).unref?.();
    this.timer = t;
  }

  private lastOkAt = 0;

  /** The hub (re)connected: a visit, unless a good one happened within CONNECT_GAP_MS (or one is already waiting out a failure). */
  syncOnConnect(): Promise<void> {
    const now = (this.o.now ?? Date.now)();
    if (this.lastOkAt && now - this.lastOkAt < CONNECT_GAP_MS) return Promise.resolve();
    if (this.failures > 0 && this.timer) return Promise.resolve(); // backing off (a 429): the scheduled retry comes
    return this.syncNow();
  }

  /** One visit now (an account was shared or changed). A visit already running is waited for, not doubled. */
  syncNow(): Promise<void> {
    if (this.stopped) return Promise.resolve();
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.run().finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  private async post(body: Json): Promise<{ status: number; body: Json | null; retryAfterMs?: number }> {
    const doFetch = this.o.fetchImpl ?? fetch;
    const res = await doFetch(`${this.o.apiUrl}/agent/device/ai-accounts`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.o.hubToken()}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${this.o.agentVersion}` },
      body: JSON.stringify({ vm_name: this.o.vmName, agent_version: this.o.agentVersion, ...body }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    let j: unknown = null;
    try {
      j = await res.json();
    } catch {
      j = null;
    }
    const ra = retryAfterMs((res as { headers?: { get?: (k: string) => string | null } }).headers?.get?.('retry-after'));
    return { status: res.status, body: isObj(j) ? j : null, ...(ra !== undefined ? { retryAfterMs: ra } : {}) };
  }

  /** What this machine holds per shared account (id -> token end time), so the backend hands over only what changed. */
  private have(): Record<string, number> {
    const out: Record<string, number> = {};
    for (const [name, mark] of this.managed()) {
      const login = readLogin(join(this.o.profilesDir, name));
      if (login && typeof login.accessToken === 'string' && typeof login.expiresAt === 'number' && login.expiresAt === mark.expiresAt) out[mark.id] = login.expiresAt;
    }
    return out;
  }

  async fetchAccounts(): Promise<SyncAnswer> {
    const usage: Json = {};
    const snap = this.o.usage?.() ?? {};
    for (const [name, mark] of this.managed()) if (snap[name]) usage[mark.id] = snap[name];
    let r: { status: number; body: Json | null; retryAfterMs?: number };
    try {
      r = await this.post({ op: 'sync', have: this.have(), ...(Object.keys(usage).length ? { usage } : {}) });
    } catch (err) {
      return { kind: 'retry', reason: err instanceof Error ? err.name : 'network' };
    }
    if (r.status === 200 && r.body?.ok === true && Array.isArray(r.body.accounts)) {
      return { kind: 'ok', accounts: r.body.accounts.filter(isObj) as unknown as AccountItem[], removed: Array.isArray(r.body.removed) ? r.body.removed.filter((x): x is string => typeof x === 'string') : [] };
    }
    if (r.status === 404 || r.status === 401 || r.status === 409) return { kind: 'off' };
    return { kind: 'retry', reason: `HTTP ${r.status}`, ...(r.retryAfterMs !== undefined ? { retryAfterMs: r.retryAfterMs } : {}) };
  }

  private async run(): Promise<void> {
    const a = await this.fetchAccounts();
    if (a.kind === 'ok') {
      this.failures = 0;
      this.lastOkAt = (this.o.now ?? Date.now)();
      const changed = this.apply(a.accounts, a.removed);
      if (changed) {
        refreshProfiles(this.o.profiles, this.o.profilesDir);
        this.o.onChange?.();
      }
      this.mirrorOrigins();
      const uploaded = await this.reconcileExisting(a.accounts).catch(() => false);
      if (uploaded) {
        // A local sign-in just repaired a workspace account: take the workspace's fresh copy now, not on the next visit.
        const again = await this.fetchAccounts();
        if (again.kind === 'ok' && this.apply(again.accounts, again.removed)) {
          refreshProfiles(this.o.profiles, this.o.profilesDir);
          this.o.onChange?.();
        }
      }
      this.say('ok', `Shared AI accounts: ${a.accounts.length} in this workspace.`);
      // Come back before the soonest token ends (never later than SYNC_MS).
      const soon = Math.min(...[...this.managed().values()].map((m) => (m.expiresAt ?? Infinity) - (this.o.now ?? Date.now)() - 50 * 60_000), SYNC_MS);
      this.schedule(Math.max(RETRY_MS, soon));
    } else if (a.kind === 'off') {
      this.schedule(SYNC_MS * 3);
    } else {
      this.failures += 1;
      this.say(`retry:${a.reason}`, `Shared AI accounts: could not reach Escanor (${a.reason}); keeping what this machine has and trying again.`);
      // Escanor said how long to wait (429 Retry-After): never sooner than that.
      this.schedule(Math.max(a.retryAfterMs ?? 0, Math.min(MAX_RETRY_MS, RETRY_MS * 2 ** Math.min(this.failures - 1, 6))));
    }
  }

  /**
   * Writes what the workspace has; drops what it removed. True when the account list on this machine changed.
   *
   * EVERY account the workspace lists gets a folder here, so every machine shows the same workspace list (the apps show each machine's
   * hello `accounts`, which are its folders): also one that needs a new sign-in or whose token is not handed over right now (listed,
   * without a login, until it has one). A workspace account is found here by the id in its mark, not by folder name: when this
   * computer already has its own sign-in in a folder of that name (two computers each called theirs "claude1"), the workspace's
   * goes into "<slug>-ws" instead of being left out.
   */
  apply(accounts: AccountItem[], removed: string[]): boolean {
    void removed; // a folder whose account is no longer listed is dropped below, whatever the reason
    let changed = false;
    const keep = new Set<string>();
    const byId = new Map<string, string>();
    for (const [name, mark] of this.managed()) if (!byId.has(mark.id)) byId.set(mark.id, name);
    for (const acct of accounts) {
      const slug = typeof acct.slug === 'string' ? acct.slug : '';
      if (!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,59}$/.test(slug) || acct.provider !== undefined && acct.provider !== 'claude') continue;
      if (typeof acct.id !== 'string' || !acct.id) continue;
      const name = byId.get(acct.id) ?? this.freeFolder(slug, acct.id, keep);
      if (!name) continue;
      keep.add(name);
      const dir = join(this.o.profilesDir, name);
      const mark = readMark(dir);
      const fresh = !existsSync(dir) || !mark;
      const oauth = acct.credentials?.claudeAiOauth;
      if (acct.status !== 'ok' || !oauth || typeof oauth.accessToken !== 'string') {
        // Needs a new sign-in (the old token is not kept), or no token handed over this time: listed here all the same.
        if (acct.status !== 'ok' && mark && readLogin(dir)) {
          rmSync(join(dir, '.credentials.json'), { force: true });
          changed = true;
        }
        if (fresh) {
          this.writeFolder(dir, name, acct, undefined);
          changed = true;
        } else changed = this.writeMeta(dir, name, acct) || changed;
        continue;
      }
      writePulledLogin(dir, oauth);
      this.writeFolder(dir, name, acct, typeof oauth.expiresAt === 'number' ? oauth.expiresAt : undefined);
      if (fresh) changed = true;
      else changed = changed || mark.label !== acct.label;
    }
    // Folders that came from the workspace and are no longer listed (or were removed): the login goes, the chats stay.
    for (const [name] of this.managed()) {
      if (keep.has(name)) continue;
      if (this.o.busyAccounts?.().has(name)) continue; // a chat is running: next visit
      this.dropFolder(name);
      changed = true;
    }
    return changed;
  }

  /** The folder a workspace account not yet on this computer goes into: its slug, or "<slug>-ws" (-ws2, ...) when that name is taken. */
  private freeFolder(slug: string, id: string, taken: Set<string>): string | null {
    for (let i = 0; i < 50; i++) {
      const name = i === 0 ? slug : i === 1 ? `${slug}-ws` : `${slug}-ws${i}`;
      if (taken.has(name)) continue;
      const dir = join(this.o.profilesDir, name);
      if (!existsSync(dir)) return name;
      if (isLinkedFolder(dir)) {
        // The person's own folder (a link to ~/.claude): never written into. A mark an older agent left there is cleared.
        if (readMark(dir)) rmSync(join(dir, WORKSPACE_MARK), { force: true });
        if (i === 0) this.sayOnce(`own:${slug}`, `Shared AI accounts: "${slug}" is your own Claude folder on this computer, so the workspace's account of that name is kept here as another folder.`);
        continue;
      }
      const mark = readMark(dir);
      if (mark?.id === id) return name;
      if (i === 0) this.sayOnce(`own:${slug}`, `Shared AI accounts: "${slug}" is already a different sign-in on this computer, so the workspace's account of that name is kept here as another folder.`);
    }
    return null;
  }

  /** The mark (which workspace account, the token's end time) and the account's name, written into a workspace folder. */
  private writeFolder(dir: string, name: string, acct: AccountItem, expiresAt: number | undefined): void {
    mkdirSync(dir, { recursive: true, mode: 0o700 });
    writeAtomic(join(dir, WORKSPACE_MARK), JSON.stringify({ id: acct.id, ...(expiresAt !== undefined ? { expiresAt } : {}), label: acct.label }));
    this.writeMeta(dir, name, acct);
    this.seedClaudeJson(dir, acct.profile);
  }

  /** True when the name or email shown for the account changed. */
  private writeMeta(dir: string, name: string, acct: AccountItem): boolean {
    const metaFile = join(dir, ACCOUNT_META_FILE);
    const meta = readJson(metaFile) ?? {};
    const label = typeof acct.label === 'string' && acct.label ? acct.label : name;
    if (meta.label === label && (!acct.email || meta.email === acct.email) && meta.provider === 'claude') return false;
    writeAtomic(metaFile, JSON.stringify({ ...meta, label, provider: 'claude', ...(acct.email ? { email: acct.email } : {}) }));
    return true;
  }

  /** The folder keeps its chats (moved aside); the login and the mark are removed. */
  private dropFolder(name: string): void {
    const dir = join(this.o.profilesDir, name);
    rmSync(join(dir, '.credentials.json'), { force: true });
    rmSync(join(dir, WORKSPACE_MARK), { force: true });
    const aside = join(this.o.profilesDir, '.removed');
    try {
      mkdirSync(aside, { recursive: true, mode: 0o700 });
      renameSync(dir, join(aside, `${name}-${(this.o.now ?? Date.now)()}`));
    } catch {
      // the folder stays (and stays listed without a login); the next visit tries again
    }
  }

  /** A first run in a new folder asks to sign in unless Claude's own file says the set-up is done: carry the part that says so. */
  private seedClaudeJson(dir: string, profile: Json | undefined): void {
    const file = join(dir, '.claude.json');
    if (existsSync(file) && statSync(file).size > 2) return;
    const seed: Json = { hasCompletedOnboarding: true };
    if (profile && isObj(profile.oauthAccount)) seed.oauthAccount = profile.oauthAccount;
    writeAtomic(file, JSON.stringify(seed));
  }

  // ---- Sign-ins already on this computer -------------------------------------------------------------------------------------

  private chain: Promise<unknown> = Promise.resolve();
  private serial<T>(fn: () => Promise<T>): Promise<T> {
    const next = this.chain.then(fn, fn);
    this.chain = next.catch(() => undefined);
    return next;
  }

  private importedState(): ImportedState {
    const j = readJson(join(this.o.profilesDir, IMPORTED_FILE));
    const done: Record<string, string> = {};
    const from: Record<string, Origin> = {};
    if (j && isObj(j.done)) for (const [k, v] of Object.entries(j.done)) if (typeof v === 'string') done[k] = v;
    if (j && isObj(j.from)) {
      for (const [k, v] of Object.entries(j.from)) {
        if (isObj(v) && typeof v.dir === 'string') from[k] = { dir: v.dir, ...(v.keychain === true ? { keychain: true } : {}), ...(v.released === true ? { released: true } : {}) };
      }
    }
    return { done, from };
  }

  private saveImported(state: ImportedState): void {
    mkdirSync(this.o.profilesDir, { recursive: true, mode: 0o700 });
    writeAtomic(join(this.o.profilesDir, IMPORTED_FILE), JSON.stringify(state));
  }

  /** Who a folder's sign-in is (never the token itself): email, account id, and a key that is the same for the same account anywhere. */
  private identify(dir: string, claudeJson: Json | null, login: Json): { email: string; uuid: string; key: string } {
    const acct = claudeJson && isObj(claudeJson.oauthAccount) ? claudeJson.oauthAccount : null;
    const email = acct && typeof acct.emailAddress === 'string' ? acct.emailAddress.trim().toLowerCase() : '';
    const uuid = acct && typeof acct.accountUuid === 'string' ? acct.accountUuid : '';
    const tok = typeof login.refreshToken === 'string' ? login.refreshToken : '';
    const key = email ? `email:${email}` : uuid ? `uuid:${uuid}` : `login:${createHash('sha256').update(`${dir}|${tok}`).digest('hex').slice(0, 16)}`;
    return { email, uuid, key };
  }

  /** Claude sign-ins on this computer that are not an Escanor account folder (read only). */
  existingLogins(): ExistingLogin[] {
    const ex = this.o.existing;
    if (!ex) return [];
    const home = ex.home ?? homedir();
    const profilesReal = (() => {
      try {
        return realpathSync(this.o.profilesDir);
      } catch {
        return this.o.profilesDir;
      }
    })();
    const inProfiles = new Set<string>();
    try {
      for (const name of readdirSync(this.o.profilesDir)) {
        try {
          inProfiles.add(realpathSync(join(this.o.profilesDir, name)));
        } catch {
          // dangling link
        }
      }
    } catch {
      // no profiles folder yet
    }
    const dirs: { dir: string; own: boolean }[] = [];
    if (ex.ownDir) dirs.push({ dir: ex.ownDir, own: true });
    try {
      for (const name of readdirSync(home)) {
        if (!/^\.claude-/.test(name) || /backup|unused|\.bak|\.tmp|profiles?$/i.test(name)) continue;
        dirs.push({ dir: join(home, name), own: false });
      }
    } catch {
      // home not readable
    }
    const out: ExistingLogin[] = [];
    const seen = new Set<string>();
    for (const { dir, own } of dirs) {
      let real = dir;
      try {
        real = realpathSync(dir);
        if (!statSync(real).isDirectory()) continue;
      } catch {
        continue;
      }
      if (real === profilesReal || inProfiles.has(real) || seen.has(real)) continue;
      seen.add(real);
      let login = readLogin(dir);
      let keychain = false;
      // On a Mac, Claude Code keeps the default folder's login in the Keychain, not in a file.
      if (own && !usable(login) && (ex.platform ?? process.platform) === 'darwin') {
        login = this.keychainLogin();
        keychain = login !== null;
      }
      if (!login || !usable(login)) continue;
      // Claude keeps its settings in <folder>/.claude.json, and for the machine's own folder in ~/.claude.json next to it.
      const claudeJson = readJson(join(dir, '.claude.json')) ?? (own ? readJson(join(home, '.claude.json')) : null);
      out.push({ dir, login, keychain, claudeJson, ...this.identify(dir, claudeJson, login) });
    }
    return out;
  }

  private keychain(): { read: () => string | null; write: (text: string) => void } {
    return this.o.existing?.keychain ?? { read: readKeychainLogin, write: writeKeychainLogin };
  }

  private keychainLogin(): Json | null {
    try {
      const text = this.keychain().read();
      const j = text ? (JSON.parse(text) as unknown) : null;
      return isObj(j) && isObj(j.claudeAiOauth) ? j.claudeAiOauth : null;
    } catch {
      return null;
    }
  }

  /** The whole credentials document an origin holds (file or Keychain), or null. */
  private readOrigin(o: Origin): Json | null {
    if (!o.keychain) return readJson(join(o.dir, '.credentials.json'));
    try {
      const text = this.keychain().read();
      const j = text ? (JSON.parse(text) as unknown) : null;
      return isObj(j) ? j : null;
    } catch {
      return null;
    }
  }

  private writeOrigin(o: Origin, doc: Json): void {
    if (o.keychain) this.keychain().write(JSON.stringify(doc));
    else writeAtomic(join(o.dir, '.credentials.json'), JSON.stringify(doc));
  }

  /**
   * After the workspace took a sign-in copied from [o]: the original keeps its access token but loses its refresh token, so only the
   * backend renews (see the note at the top). Only when the original still holds the very refresh token that was uploaded (a newer
   * sign-in there is left alone). The full original is kept first in <dir>/.credentials.json.escanor-backup (0600). True when released.
   */
  private releaseOrigin(o: Origin, uploadedRefresh: string): boolean {
    const doc = this.readOrigin(o);
    const login = doc && isObj(doc.claudeAiOauth) ? doc.claudeAiOauth : null;
    if (!doc || !login || login.refreshToken !== uploadedRefresh) return false;
    try {
      mkdirSync(o.dir, { recursive: true, mode: 0o700 });
      writeAtomic(join(o.dir, `.credentials.json${BACKUP_SUFFIX}`), JSON.stringify(doc));
      const { refreshToken: _r, refreshTokenExpiresAt: _e, ...rest } = login;
      this.writeOrigin(o, { ...doc, claudeAiOauth: rest });
      return true;
    } catch (err) {
      this.say(`release-failed:${o.dir}`, `Shared AI accounts: could not hand the renewal of the sign-in in ${o.keychain ? 'the Keychain' : o.dir} to the workspace (${err instanceof Error ? err.message : 'error'}).`);
      return false;
    }
  }

  /**
   * Keeps released originals usable: the workspace's fresh access token (no refresh token) is written into each, while it still holds
   * no refresh token. One that holds a refresh token again (the person signed in there anew) or was signed out is no longer written to.
   */
  private mirrorOrigins(): void {
    if (!this.o.existing) return;
    const state = this.importedState();
    let dirty = false;
    for (const [slug, o] of Object.entries(state.from)) {
      if (!o.released) continue;
      const pulled = readMark(join(this.o.profilesDir, slug)) ? readLogin(join(this.o.profilesDir, slug)) : null;
      if (!pulled || typeof pulled.accessToken !== 'string') continue;
      const doc = this.readOrigin(o);
      const login = doc && isObj(doc.claudeAiOauth) ? doc.claudeAiOauth : null;
      if (!doc || !login || (typeof login.refreshToken === 'string' && login.refreshToken)) {
        state.from[slug] = { ...o, released: false };
        dirty = true;
        continue;
      }
      if (login.accessToken === pulled.accessToken) continue;
      try {
        this.writeOrigin(o, { ...doc, claudeAiOauth: { ...login, ...pulled } });
      } catch {
        // next visit
      }
    }
    if (dirty) this.saveImported(state);
  }

  /** Emails of accounts already here as Escanor folders (the ones with a folder of their own). */
  private localEmails(): Set<string> {
    const set = new Set<string>();
    for (const p of this.o.profiles) {
      let email = p.email?.toLowerCase() ?? '';
      if (!email && p.configDir) {
        const cj = readJson(join(p.configDir, '.claude.json'));
        const acct = cj && isObj(cj.oauthAccount) ? cj.oauthAccount : null;
        if (acct && typeof acct.emailAddress === 'string') email = acct.emailAddress.toLowerCase();
      }
      if (email) set.add(email);
    }
    return set;
  }

  private slugFor(email: string, key: string): string {
    const local = (email.split('@')[0] || 'account').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24) || 'account';
    const tag = createHash('sha256').update(key).digest('hex').slice(0, 4);
    let slug = `claude-${local}-${tag}`;
    for (let i = 2; existsSync(join(this.o.profilesDir, slug)); i++) slug = `claude-${local}-${tag}-${i}`;
    return slug;
  }

  /** Copies one sign-in into a new Escanor account folder. The original is only read. Returns the account id. */
  private copyInto(l: ExistingLogin, state: ImportedState): string {
    const login = l.login;
    const slug = this.slugFor(l.email, l.key);
    state.from[slug] = { dir: l.dir, ...(l.keychain ? { keychain: true } : {}) };
    const dir = join(this.o.profilesDir, slug);
    mkdirSync(dir, { recursive: true, mode: 0o700 });
    writeAtomic(join(dir, '.credentials.json'), JSON.stringify({ claudeAiOauth: login }));
    const seed: Json = { hasCompletedOnboarding: true };
    if (l.claudeJson && isObj(l.claudeJson.oauthAccount)) seed.oauthAccount = l.claudeJson.oauthAccount;
    writeAtomic(join(dir, '.claude.json'), JSON.stringify(seed));
    writeAtomic(join(dir, ACCOUNT_META_FILE), JSON.stringify({ label: l.email || 'Claude account', provider: 'claude', ...(l.email ? { email: l.email } : {}) }));
    return slug;
  }

  /**
   * Every sign-in already on this computer becomes an Escanor account that the whole workspace can use, with no one pressing anything:
   * copied once (not again after the person removes it), never twice for one email (here, or already in the workspace), and an Escanor
   * account folder of this computer that is not in the workspace yet is shared too. `known` = the workspace's accounts (it knows who is
   * already there); skipped when this machine cannot reach it.
   *
   * A workspace account that needs a new sign-in (status needs_signin) does NOT count as "already there": a fresh sign-in on this
   * computer for the same email (one that holds a refresh token) is uploaded under that account's slug, which replaces its login
   * (the backend's import of the same slug), and the original is then released. True when such a repair was uploaded.
   */
  reconcileExisting(known: AccountItem[]): Promise<boolean> {
    if (!this.o.existing) return Promise.resolve(false);
    return this.serial(async () => {
      const state = this.importedState();
      const live = known.filter((a) => a.status !== 'removed' && typeof a.email === 'string' && a.email);
      const inWorkspace = new Set(live.filter((a) => a.status !== 'needs_signin').map((a) => (a.email as string).toLowerCase()));
      // Only a Claude account is repaired by a Claude sign-in (Codex/Gemini rows are left as they are).
      const isClaude = (a: AccountItem) => a.provider === undefined || a.provider === 'claude';
      const needsSignin = new Map(live.filter((a) => a.status === 'needs_signin' && isClaude(a) && !inWorkspace.has((a.email as string).toLowerCase())).map((a) => [(a.email as string).toLowerCase(), a]));
      const have = this.localEmails();
      let changed = false;
      let repaired = false;
      for (const l of this.existingLogins()) {
        const broken = l.email ? needsSignin.get(l.email) : undefined;
        if (broken) {
          if (await this.repair(broken, l, state)) {
            needsSignin.delete(l.email);
            repaired = true;
          }
          continue;
        }
        if (state.done[l.key]) continue;
        if (l.email && (have.has(l.email) || inWorkspace.has(l.email))) {
          state.done[l.key] = ''; // already an account here, or the workspace has it: no second copy
          continue;
        }
        const slug = this.copyInto(l, state);
        state.done[l.key] = slug;
        if (l.email) have.add(l.email);
        changed = true;
        this.say(`imported:${slug}`, `Shared AI accounts: the Claude sign-in already on this computer (${l.email || 'no email'}) was copied into the Escanor account "${slug}".`);
      }
      this.saveImported(state);
      if (changed) {
        refreshProfiles(this.o.profiles, this.o.profilesDir, {});
        this.o.onChange?.();
      }
      // Share the copies (retried each visit until it works) and the folders of this computer the workspace does not have yet.
      const seenEmail = new Set<string>();
      for (const p of [...this.o.profiles]) {
        if (!p.configDir || (p.provider && p.provider !== 'claude') || p.method === 'key' || this.isShared(p.id)) continue;
        const cj = readJson(join(p.configDir, '.claude.json'));
        const acct = cj && isObj(cj.oauthAccount) ? cj.oauthAccount : null;
        const email = (p.email ?? (acct && typeof acct.emailAddress === 'string' ? acct.emailAddress : '')).toLowerCase();
        if (email && (inWorkspace.has(email) || seenEmail.has(email))) continue;
        let isLink = false;
        try {
          isLink = lstatSync(p.configDir).isSymbolicLink();
        } catch {
          // gone
        }
        if (isLink) continue; // a link to a folder the person uses themselves: never taken over
        if (email) seenEmail.add(email);
        const res = await this.shareInner(p.id, false).catch((err: unknown) => ({ ok: false as const, error: err instanceof Error ? err.message : 'error' }));
        // Said once per account and reason (it is tried again every visit): a share that keeps failing is no longer silent.
        if (!res.ok) this.sayOnce(`share-failed:${p.id}:${res.error}`, `Shared AI accounts: "${p.id}" could not be added to the workspace yet (${res.error}).`);
      }
      return repaired;
    });
  }

  /** Uploads a fresh local sign-in in place of a workspace account that needs one (same slug, same email), then releases the original. */
  private async repair(acct: AccountItem, l: ExistingLogin, state: ImportedState): Promise<boolean> {
    if (typeof acct.slug !== 'string' || !acct.slug || typeof l.login.refreshToken !== 'string') return false;
    let r: { status: number; body: Json | null };
    try {
      r = await this.post({
        op: 'import',
        provider: 'claude',
        slug: acct.slug,
        label: typeof acct.label === 'string' && acct.label ? acct.label : l.email,
        email: l.email,
        credentials: { claudeAiOauth: l.login },
        ...(l.claudeJson && isObj(l.claudeJson.oauthAccount) ? { profile: { oauthAccount: l.claudeJson.oauthAccount } } : {}),
      });
    } catch {
      return false;
    }
    if (r.status !== 200 || r.body?.ok !== true) return false;
    const origin: Origin = { dir: l.dir, ...(l.keychain ? { keychain: true } : {}) };
    state.from[acct.slug] = { ...origin, released: this.releaseOrigin(origin, l.login.refreshToken) };
    state.done[l.key] = state.done[l.key] || acct.slug;
    this.saveImported(state);
    this.say(`repaired:${acct.slug}:${Date.now()}`, `Shared AI accounts: the new Claude sign-in on this computer (${l.email}) signed the workspace account "${acct.slug}" in again.`);
    return true;
  }

  /** The machine's own sign-in, on request ("Use the Claude account already on this computer"). */
  async importOwn(): Promise<{ ok: true } | { ok: false; error: string }> {
    const r = await this.serial(async () => {
      const state = this.importedState();
      const logins = this.existingLogins();
      if (!logins.length) return { ok: false as const, error: 'No Claude sign-in was found on this computer. Sign in to Claude here first.' };
      const known = await this.fetchAccounts();
      const inWorkspace = new Set(known.kind === 'ok' ? known.accounts.filter((a) => a.status !== 'removed' && a.email).map((a) => String(a.email).toLowerCase()) : []);
      let last: { ok: true } | { ok: false; error: string } = { ok: true };
      for (const l of logins) {
        if (l.email && inWorkspace.has(l.email)) continue; // the workspace has it already
        const have = this.localEmails();
        let slug = state.done[l.key];
        if (!slug || !existsSync(join(this.o.profilesDir, slug))) {
          if (l.email && have.has(l.email)) continue;
          slug = this.copyInto(l, state);
          state.done[l.key] = slug;
          this.saveImported(state);
          refreshProfiles(this.o.profiles, this.o.profilesDir, {});
          this.o.onChange?.();
        }
        last = await this.shareInner(slug, false);
      }
      return last;
    });
    if (r.ok) await this.syncNow();
    return r;
  }

  /** "Make available on all machines": upload this machine's own sign-in of one account, then use the workspace's copy here too. */
  async share(accountId: string): Promise<{ ok: true } | { ok: false; error: string }> {
    return this.shareInner(accountId, true);
  }

  /** `sync` false when called from a visit that is already running (it would wait for itself). */
  private async shareInner(accountId: string, sync: boolean): Promise<{ ok: true } | { ok: false; error: string }> {
    const p = this.o.profiles.find((x) => x.id === accountId);
    // The machine's own sign-in (listed as "default", no folder of its own): copied into an Escanor account, which is then shared.
    if (p && !p.configDir && this.o.existing?.ownDir) return this.importOwn();
    if (!p || !p.configDir) return { ok: false, error: 'That account is not on this computer.' };
    if (p.provider && p.provider !== 'claude') return { ok: false, error: 'Only Claude accounts can be shared with the workspace for now.' };
    if (p.method === 'key') return { ok: false, error: 'An account that runs on an API key stays on this computer.' };
    if (isLinkedFolder(join(this.o.profilesDir, p.id)) || isLinkedFolder(p.configDir)) return { ok: false, error: 'This is your own Claude folder on this computer, so it stays here. Add the account to Escanor separately to share it.' };
    if (this.isShared(p.id)) return { ok: true };
    if (existsSync(join(p.configDir, PENDING_MARK))) return { ok: false, error: 'Finish signing in to this account first.' };
    const file = join(p.configDir, '.credentials.json');
    const creds = readJson(file);
    const login = creds && isObj(creds.claudeAiOauth) ? creds.claudeAiOauth : null;
    if (!login || typeof login.refreshToken !== 'string' || !login.refreshToken) return { ok: false, error: 'This account is not signed in on this computer, so there is nothing to share.' };
    const cj = readJson(join(p.configDir, '.claude.json'));
    const oauthAccount = cj && isObj(cj.oauthAccount) ? cj.oauthAccount : null;
    const email = p.email ?? (oauthAccount && typeof oauthAccount.emailAddress === 'string' ? oauthAccount.emailAddress : '');
    // The folder name is the workspace name first. Another computer may already have shared a DIFFERENT account under that name (each
    // calls its first account "claude1"): the backend answers 409, and the account is shared under a name of its own instead
    // (claude1-<tag>), so it still reaches the workspace. This folder keeps its name; the mark ties it to the workspace account.
    const tag = createHash('sha256').update(`${email.toLowerCase()}|${this.o.vmName}|${p.id}`).digest('hex').slice(0, 6);
    let r: { status: number; body: Json | null } = { status: 0, body: null };
    for (const slug of [p.id, `${p.id.slice(0, 52)}-${tag}`]) {
      try {
        r = await this.post({
          op: 'import',
          provider: 'claude',
          slug,
          label: p.label,
          email,
          credentials: { claudeAiOauth: login },
          ...(oauthAccount ? { profile: { oauthAccount } } : {}),
        });
      } catch {
        return { ok: false, error: 'Escanor could not be reached. Try again in a moment.' };
      }
      if (r.status !== 409) break;
    }
    if (r.status !== 200 || r.body?.ok !== true) {
      const msg = typeof r.body?.message === 'string' ? r.body.message : '';
      return { ok: false, error: msg || 'Escanor could not keep this account for the workspace.' };
    }
    // From here the backend owns the renewal: this folder holds the same pulled login as every other machine, no refresh token.
    const acct = isObj(r.body.account) ? r.body.account : {};
    const id = typeof acct.id === 'string' ? acct.id : '';
    writePulledLogin(p.configDir, login);
    writeAtomic(join(p.configDir, WORKSPACE_MARK), JSON.stringify({ id, expiresAt: login.expiresAt, label: p.label }));
    // A copy of a sign-in from elsewhere on this computer (~/.claude, the Keychain): that original gives up its refresh token too.
    const state = this.importedState();
    const origin = state.from[p.id];
    if (origin && !origin.released) {
      state.from[p.id] = { ...origin, released: this.releaseOrigin(origin, login.refreshToken) };
      this.saveImported(state);
    }
    this.say(`shared:${p.id}`, `Shared AI accounts: "${p.id}" is now available on every machine of this workspace.`);
    if (sync) await this.syncNow();
    return { ok: true };
  }
}

export function sharedApiUrl(env: NodeJS.ProcessEnv, hubUrl: string, opts: { managed: boolean }): string | null {
  if (opts.managed || !workspaceAccountsEnabled(env)) return null;
  return escanorApiUrl(env, hubUrl);
}
