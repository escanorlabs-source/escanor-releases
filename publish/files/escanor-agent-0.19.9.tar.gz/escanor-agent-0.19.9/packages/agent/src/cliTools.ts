import { spawn } from 'node:child_process';
import { accessSync, constants, existsSync, readdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { delimiter, dirname, join } from 'node:path';
import type { AccountProvider } from '@remote-harness/shared';
import { childEnv } from './childEnv.js';

/**
 * The other AIs' own command-line tools, which run that account's sign-in and chats: ChatGPT = OpenAI's Codex CLI (`codex`),
 * Gemini = Google's Gemini CLI (`gemini`), GitHub Copilot = GitHub Copilot CLI (`copilot`). Found in this order:
 * ESCANOR_CODEX_BIN / ESCANOR_GEMINI_BIN / ESCANOR_COPILOT_BIN, the PATH, then the copy
 * the agent installed for itself (<PROFILES_DIR>/.tools). A machine without one gets it installed into .tools with npm when an
 * account for that AI is added (ESCANOR_CLI_INSTALL=0 turns that off).
 */

export type CliProvider = Exclude<AccountProvider, 'claude'>;

export const CLI_INFO: Record<CliProvider, { bin: string; pkg: string; version: string; envVar: string; name: string }> = {
  // The versions installed when a machine has none: the ones Escanor's reading of their output was checked against.
  chatgpt: { bin: 'codex', pkg: '@openai/codex', version: '0.160.0', envVar: 'ESCANOR_CODEX_BIN', name: 'ChatGPT' },
  gemini: { bin: 'gemini', pkg: '@google/gemini-cli', version: '0.64.0', envVar: 'ESCANOR_GEMINI_BIN', name: 'Gemini' },
  copilot: { bin: 'copilot', pkg: '@github/copilot', version: '1.0.109', envVar: 'ESCANOR_COPILOT_BIN', name: 'GitHub Copilot' },
};

/**
 * The models GitHub Copilot CLI offers (as its own ids), for the apps' model menus: `auto` lets Copilot pick from what the
 * person's plan has, and always works; the others need a plan that includes them (Copilot then says so, see failureText).
 */
export const COPILOT_MODELS: ReadonlyArray<{ value: string; label: string }> = [
  { value: 'auto', label: 'Auto (Copilot picks)' },
  { value: 'claude-opus-5.5', label: 'Claude Opus 5.5' },
  { value: 'claude-sonnet-5.5', label: 'Claude Sonnet 5.5' },
  { value: 'claude-haiku-4.5', label: 'Claude Haiku 4.5' },
  { value: 'gpt-6.1-sol', label: 'GPT-6.1 Sol' },
  { value: 'gpt-6-sol', label: 'GPT-6 Sol' },
  { value: 'gpt-6-luna', label: 'GPT-6 Luna' },
  { value: 'gpt-5.6-luna', label: 'GPT-5.6 Luna' },
  { value: 'gemini-4-argon', label: 'Gemini 4 Argon' },
  { value: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash' },
  { value: 'mai-code-1.1-flash', label: 'MAI-Code 1.1 Flash' },
];

/** Does Copilot's config.json (in its home folder) say a GitHub account is signed in? Only that; the token is never read. */
export function copilotSignedIn(configFile: string): boolean {
  try {
    // Copilot writes comment lines above the JSON.
    const j = JSON.parse(readFileSync(configFile, 'utf8').replace(/^\s*\/\/.*$/gm, '')) as { loggedInUsers?: unknown; lastLoggedInUser?: { login?: unknown } };
    return (Array.isArray(j.loggedInUsers) && j.loggedInUsers.length > 0) || typeof j.lastLoggedInUser?.login === 'string';
  } catch {
    return false;
  }
}

/** The npm package behind a command name, for finding its JavaScript entry (launchSpec). */
const PACKAGE_OF: Record<string, string> = { codex: '@openai/codex', gemini: '@google/gemini-cli', copilot: '@github/copilot', claude: '@anthropic-ai/claude-code' };

/**
 * How to start a command without a shell. On Windows an npm-installed tool is a `.cmd` wrapper, which Node can only run through
 * cmd.exe, where a prompt or key with `&` or `|` in it would run as commands: there the tool's own JavaScript entry is run with
 * this Node instead (npm: npm-cli.js beside Node). A plain executable, or anything on other systems, runs as it is.
 */
export function launchSpec(bin: string, platform: NodeJS.Platform = process.platform, nodePath = process.execPath): { command: string; args: string[] } {
  const isJs = /\.(?:c|m)?js$/i.test(bin);
  if (isJs) return { command: nodePath, args: [bin] };
  if (platform !== 'win32' || !/\.(?:cmd|bat|ps1)$|^[^.\\/]*$|[\\/][^.\\/]*$/i.test(bin)) return { command: bin, args: [] };
  const base = bin.replace(/^.*[\\/]/, '').replace(/\.(?:cmd|bat|ps1)$/i, '').toLowerCase();
  const dir = dirname(bin);
  if (base === 'npm' || base === 'npx') {
    for (const js of [join(dir, 'node_modules', 'npm', 'bin', `${base}-cli.js`), join(dirname(nodePath), 'node_modules', 'npm', 'bin', `${base}-cli.js`)]) {
      if (existsSync(js)) return { command: nodePath, args: [js] };
    }
  }
  const pkg = PACKAGE_OF[base];
  if (pkg) {
    // npm puts a global tool's wrapper beside node_modules, and a local one in node_modules/.bin.
    for (const pkgDir of [join(dir, 'node_modules', pkg), join(dir, '..', pkg)]) {
      try {
        const j = JSON.parse(readFileSync(join(pkgDir, 'package.json'), 'utf8')) as { bin?: string | Record<string, string> };
        const rel = typeof j.bin === 'string' ? j.bin : j.bin?.[base];
        if (rel && existsSync(join(pkgDir, rel))) return { command: nodePath, args: [join(pkgDir, rel)] };
      } catch {
        // not here
      }
    }
  }
  if (/\.(?:cmd|bat|ps1)$/i.test(bin)) throw new Error(`Escanor could not find the program behind ${bin}, so it was not started.`);
  return { command: bin, args: [] };
}

/** How long installing a missing tool may take. */
export const INSTALL_TIMEOUT_MS = 3 * 60_000;

export function toolsDir(profilesDir: string): string {
  return join(profilesDir, '.tools');
}

function isExecutable(file: string): boolean {
  try {
    if (!statSync(file).isFile()) return false;
    if (process.platform === 'win32') return true;
    accessSync(file, constants.X_OK);
    return true;
  } catch {
    return false;
  }
}

/** The value of PATH in [env], whatever the case of its name (a copied Windows environment keeps `Path`). */
export function pathOf(env: Record<string, string | undefined>): string {
  if (env.PATH !== undefined) return env.PATH;
  const key = Object.keys(env).find((k) => k.toUpperCase() === 'PATH');
  return key ? env[key] ?? '' : '';
}

/** The extensions Windows runs a bare command name with, in the order it tries them (PATHEXT), `.cmd` and `.exe` always included. */
export function windowsExts(env: Record<string, string | undefined>): string[] {
  const key = Object.keys(env).find((k) => k.toUpperCase() === 'PATHEXT');
  const listed = (key ? env[key] ?? '' : '').split(';').map((e) => e.trim().toLowerCase()).filter((e) => /^\.[a-z0-9]{1,5}$/.test(e));
  // .ps1 and .js/.vbs scripts are not started by name without a shell, so only programs and wrappers count.
  const runnable = listed.filter((e) => ['.exe', '.cmd', '.bat', '.com'].includes(e));
  return [...new Set([...runnable, '.cmd', '.exe', '.bat', ''])];
}

/** The first `name` on PATH (with the Windows extensions there), or null. */
export function findOnPath(name: string, env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform): string | null {
  const exts = platform === 'win32' ? windowsExts(env) : [''];
  for (const dir of pathOf(env).split(delimiter)) {
    if (!dir) continue;
    for (const ext of exts) {
      const file = join(dir.replace(/^"(.*)"$/, '$1'), name + ext);
      if (isExecutable(file)) return file;
    }
  }
  return null;
}

/**
 * VS Code puts a `copilot` command on the PATH (…/code/bin/copilot-shim/copilot, often linked from /usr/bin) that only says "GitHub
 * Copilot CLI was not found". It is not the tool: it is skipped, and the real one is looked for further on.
 */
export function isCopilotShim(file: string): boolean {
  let real = file;
  try {
    real = realpathSync(file);
  } catch {
    // keep the name as it is
  }
  return /[\\/]copilot-shim[\\/]/i.test(real) || /[\\/]copilot-shim[\\/]/i.test(file);
}

/** Every `name` on PATH, in order (findOnPath gives the first). */
export function allOnPath(name: string, env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform): string[] {
  const exts = platform === 'win32' ? windowsExts(env) : [''];
  const found: string[] = [];
  for (const dir of pathOf(env).split(delimiter)) {
    if (!dir) continue;
    for (const ext of exts) {
      const file = join(dir.replace(/^"(.*)"$/, '$1'), name + ext);
      if (isExecutable(file) && !found.includes(file)) found.push(file);
    }
  }
  return found;
}

/** The first `name` on PATH that is the real tool (for `copilot`: not VS Code's stand-in), or null. */
export function findCliOnPath(name: string, env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform): string | null {
  if (name !== 'copilot') return findOnPath(name, env, platform);
  return allOnPath(name, env, platform).find((f) => !isCopilotShim(f)) ?? null;
}

/** Where the tool for [provider] is on this machine, or null when it is not installed anywhere the agent looks. */
export function resolveCliBin(provider: CliProvider, env: NodeJS.ProcessEnv, profilesDir: string | undefined): string | null {
  const info = CLI_INFO[provider];
  const set = env[info.envVar]?.trim();
  if (set) return set;
  const onPath = findCliOnPath(info.bin, env);
  if (onPath) return onPath;
  if (profilesDir) {
    const ext = process.platform === 'win32' ? '.cmd' : '';
    const local = join(toolsDir(profilesDir), 'node_modules', '.bin', info.bin + ext);
    if (existsSync(local)) return local;
  }
  return null;
}

/** The folder of the Node.js running this agent: added at the end of a tool's PATH, so a `#!/usr/bin/env node` tool finds node. */
export function withNodeOnPath(env: Record<string, string | undefined>): Record<string, string | undefined> {
  const nodeDir = dirname(process.execPath);
  const key = process.platform !== 'win32' ? 'PATH' : Object.keys(env).find((k) => k.toUpperCase() === 'PATH') ?? 'Path';
  const cur = env[key] ?? '';
  if (cur.split(delimiter).includes(nodeDir)) return env;
  return { ...env, [key]: cur ? `${cur}${delimiter}${nodeDir}` : nodeDir };
}

export type RunResult = { code: number | null; out: string; err: string; missing?: boolean };
/** Runs a command to its end (stdin closed, or given [input]), with a time limit. Injectable in tests. */
export type RunFn = (bin: string, args: string[], opts: { env: Record<string, string | undefined>; cwd?: string; input?: string; timeoutMs: number }) => Promise<RunResult>;

export const realRun: RunFn = (bin, args, opts) =>
  new Promise((resolve) => {
    let out = '';
    let err = '';
    let done = false;
    const finish = (r: RunResult) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(r);
    };
    let child: ReturnType<typeof spawn>;
    try {
      const l = launchSpec(bin);
      child = spawn(l.command, [...l.args, ...args], { env: opts.env, cwd: opts.cwd, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    } catch {
      resolve({ code: -1, out: '', err: '', missing: true });
      return;
    }
    const timer = setTimeout(() => {
      try {
        child.kill('SIGTERM');
      } catch {
        // gone
      }
      finish({ code: -2, out, err });
    }, opts.timeoutMs);
    child.stdout?.on('data', (b: Buffer) => (out = (out + b.toString()).slice(-65_536)));
    child.stderr?.on('data', (b: Buffer) => (err = (err + b.toString()).slice(-65_536)));
    child.once('error', (e: NodeJS.ErrnoException) => finish({ code: -1, out, err, missing: e.code === 'ENOENT' }));
    child.once('exit', (code) => finish({ code, out, err }));
    child.stdin?.on('error', () => undefined);
    child.stdin?.end(opts.input ?? '');
  });

/** npm's own JavaScript next to the Node.js running this agent (run with that Node), else npm on the PATH. */
export function resolveNpm(env: NodeJS.ProcessEnv): string {
  const nodeDir = dirname(process.execPath);
  for (const js of [join(nodeDir, 'node_modules', 'npm', 'bin', 'npm-cli.js'), join(nodeDir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js')]) {
    if (existsSync(js)) return js;
  }
  const ext = process.platform === 'win32' ? '.cmd' : '';
  const beside = join(nodeDir, `npm${ext}`);
  if (existsSync(beside)) return beside;
  return findOnPath('npm', env) ?? `npm${ext}`;
}

export function cliInstallEnabled(env: NodeJS.ProcessEnv): boolean {
  const v = env.ESCANOR_CLI_INSTALL?.trim().toLowerCase();
  return !(v === '0' || v === 'false' || v === 'off' || v === 'no');
}

/**
 * The tool for [provider]: where it is, or installed into <profilesDir>/.tools first. Answers in plain words when it cannot be
 * had (npm missing, the install failed or took too long, installing turned off).
 */
export async function ensureCli(
  provider: CliProvider,
  o: { env: NodeJS.ProcessEnv; profilesDir: string; run?: RunFn; timeoutMs?: number },
): Promise<{ ok: true; bin: string } | { ok: false; error: string }> {
  const info = CLI_INFO[provider];
  const found = resolveCliBin(provider, o.env, o.profilesDir);
  if (found) return { ok: true, bin: found };
  if (!cliInstallEnabled(o.env)) {
    return { ok: false, error: `${info.name} needs its own tool on this computer, and installing it is turned off here. Install ${info.pkg} with npm, then try again.` };
  }
  const run = o.run ?? realRun;
  // Pinned, with no install scripts (both tools work without them), and never with the hub's credentials in reach.
  const r = await run(resolveNpm(o.env), ['install', '--prefix', toolsDir(o.profilesDir), '--no-audit', '--no-fund', '--loglevel=error', '--ignore-scripts', `${info.pkg}@${info.version}`], {
    env: withNodeOnPath(childEnv(o.env)),
    timeoutMs: o.timeoutMs ?? INSTALL_TIMEOUT_MS,
  });
  if (r.missing) return { ok: false, error: `Install Node.js on this computer, then try again. ${info.name} needs it.` };
  if (r.code === -2) return { ok: false, error: `Installing ${info.name}'s tool on this computer took too long. Check its internet connection, then try again.` };
  const bin = resolveCliBin(provider, o.env, o.profilesDir);
  if (r.code !== 0 || !bin) return { ok: false, error: `${info.name}'s tool could not be installed on this computer. Check its internet connection, then try again.` };
  return { ok: true, bin };
}

/** Removes the colour and cursor codes a terminal tool prints. */
export function stripAnsi(text: string): string {
  // eslint-disable-next-line no-control-regex
  return text.replace(/\u001b\[[0-?]*[ -/]*[@-~]|\u001b\][^\u0007\u001b]*(\u0007|\u001b\\)|\u001b[@-Z\\-_]/g, '');
}

/**
 * Gemini CLI's own Google sign-in client (an "installed app" client: its id and secret are public, shipped in the CLI). Read at
 * run time from the installed CLI, never kept in Escanor's code, so a new CLI version with a new client keeps working.
 */
export function geminiOAuthClient(bin: string): { clientId: string; clientSecret: string } | null {
  let pkgDir: string | null = null;
  try {
    let dir = dirname(realpathSync(bin));
    for (let i = 0; i < 8; i++) {
      const pj = join(dir, 'package.json');
      if (existsSync(pj)) {
        try {
          if ((JSON.parse(readFileSync(pj, 'utf8')) as { name?: string }).name === '@google/gemini-cli') {
            pkgDir = dir;
            break;
          }
        } catch {
          // not a package.json we can read
        }
      }
      const up = dirname(dir);
      if (up === dir) break;
      dir = up;
    }
  } catch {
    return null;
  }
  if (!pkgDir) {
    // A wrapper script (npm's .bin shim on Windows, a symlink farm): try the package next to it.
    const guess = join(dirname(bin), '..', '@google', 'gemini-cli');
    if (existsSync(join(guess, 'package.json'))) pkgDir = guess;
    else return null;
  }
  const files: string[] = [];
  for (const sub of ['bundle', 'dist']) {
    try {
      for (const f of readdirSync(join(pkgDir, sub))) if (f.endsWith('.js')) files.push(join(pkgDir, sub, f));
    } catch {
      // not in this layout
    }
  }
  files.push(join(pkgDir, 'node_modules', '@google', 'gemini-cli-core', 'dist', 'src', 'code_assist', 'oauth2.js'));
  const idRe = /OAUTH_CLIENT_ID\s*=\s*["']([^"']{10,200})["']/;
  const secretRe = /OAUTH_CLIENT_SECRET\s*=\s*["']([^"']{6,200})["']/;
  for (const f of files) {
    let text: string;
    try {
      text = readFileSync(f, 'utf8');
    } catch {
      continue;
    }
    if (!text.includes('OAUTH_CLIENT_ID')) continue;
    const id = idRe.exec(text)?.[1];
    const secret = secretRe.exec(text)?.[1];
    if (id && secret) return { clientId: id, clientSecret: secret };
  }
  return null;
}
