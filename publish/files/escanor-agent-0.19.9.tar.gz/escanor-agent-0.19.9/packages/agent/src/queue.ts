// A push-based async iterable used as streaming input into the Claude Agent
// SDK's `query()`. Lets us keep one session's turn open indefinitely and feed
// it new user messages (or an interrupt) as they arrive from the hub.
// `onTake` runs when the SDK takes the item from this queue to write it to Claude Code: the message was accepted by the SDK (DEV6).
// That is the best signal the SDK gives; it is not proof Claude Code has read it (an abort right after can still lose it).
export class AsyncMessageQueue<T> implements AsyncIterable<T> {
  private buffered: { item: T; onTake?: () => void }[] = [];
  private waiters: ((result: IteratorResult<T>) => void)[] = [];
  private closed = false;

  push(item: T, onTake?: () => void): void {
    if (this.closed) return;
    const waiter = this.waiters.shift();
    if (waiter) {
      waiter({ value: item, done: false });
      taken(onTake);
    } else this.buffered.push({ item, onTake });
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    while (this.waiters.length) {
      this.waiters.shift()!({ value: undefined as unknown as T, done: true });
    }
  }

  [Symbol.asyncIterator](): AsyncIterator<T> {
    return {
      next: (): Promise<IteratorResult<T>> => {
        if (this.buffered.length) {
          const { item, onTake } = this.buffered.shift()!;
          taken(onTake);
          return Promise.resolve({ value: item, done: false });
        }
        if (this.closed) {
          return Promise.resolve({ value: undefined as unknown as T, done: true });
        }
        return new Promise((resolve) => this.waiters.push(resolve));
      },
    };
  }
}

function taken(onTake: (() => void) | undefined): void {
  try {
    onTake?.();
  } catch (err) {
    console.error('Delivery listener failed', err);
  }
}
