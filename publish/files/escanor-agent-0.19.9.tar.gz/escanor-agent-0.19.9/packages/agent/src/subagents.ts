import { closeSync, existsSync, openSync, readFileSync, readSync, readdirSync, statSync, watch, type FSWatcher } from 'node:fs';
import { join } from 'node:path';
import type { AgentSubagentStepsResult, AgentSubagents, AgentToHubMessage, SubagentItem, SubagentStep } from '@remote-harness/shared';
import { describeTool } from './activity.js';
import { claudeSessionsDir } from './claudeProcs.js';
import { oneLine } from './redact.js';
import { projectDirName } from './turnState.js';

/**
 * Background helpers of a chat (Claude Code subagents), read from its transcript folder:
 *   <projects>/<project dir>/<sessionId>/subagents/agent-<id>.jsonl   (the helper's own lines, isSidechain: true)
 *   <projects>/<project dir>/<sessionId>/subagents/agent-<id>.meta.json  ({ description, model, toolUseId, parentAgentId?, finished? })
 * and, for how a helper ended, the `<task-notification>` line in the chat's own transcript. Sent to the hub as `subagents`
 * (on change, at most once a second per chat, a final send when one finishes, an empty list clears). `subagent_steps` is the
 * read-only drill-down. Everything is best effort: a missing folder, a half-written last line or a file that appears later
 * never throws.
 */

export const SUBAGENTS_MIN_GAP_MS = 1_000;
const POLL_MS = 3_000;
/** A chat whose run ended this long ago, with no helper still running, is no longer watched (it is watched again when it works). */
const IDLE_DROP_MS = 10 * 60_000;
const MAX_ITEMS = 50;
const MAX_DESC = 200;
const MAX_STEP = 120;
const MAX_SUMMARY = 300;
/** A helper silent this long, in a chat that is not busy, with no notice, is reported as stopped. */
export const STALE_MS = 30 * 60_000;
/** A chat with no running helper is looked at only every this many polls (fs.watch covers changes). */
const IDLE_POLL_EVERY = 5;
const TAIL_BYTES = 128 * 1024;
const HEAD_BYTES = 16 * 1024;
/** The main transcript's end is read for task notifications (they are small; tool output is what makes the file big). */
const NOTICE_CHUNK = 4 * 1024 * 1024;
const MAX_STEPS_FILE_BYTES = 8 * 1024 * 1024;
export const MAX_STEPS_PAGE = 50;
const MAX_STEP_TEXT = 400;

const SAFE_ID = /^[0-9A-Za-z_-]{1,80}$/;

type Meta = { description?: string; model?: string; toolUseId?: string; parentAgentId?: string; finished?: boolean };
type Notice = { status: string; summary?: string; at?: string };

type FileInfo = { mtimeMs: number; size: number; startedAt?: string; lastAt?: string; lastStep?: string };

type Tracked = {
  cwd: string | undefined;
  dir: string | null; // <session folder>/subagents once found
  mainFile: string | null;
  watcher: FSWatcher | null;
  files: Map<string, FileInfo>;
  mainSig: string;
  notices: Map<string, Notice>; // by task id (the helper's id) and by tool-use id
  lastSent: string | null;
  lastAt: number;
  timer: unknown;
  everHad: boolean;
  lastTrafficAt: number;
  polls: number;
  mainOffset: number;
  projDir: string | null;
  /** When the chat's run ended (helpers can outlive it); null while it is working. */
  endedAt: number | null;
  hasRunning: boolean;
};

type Timers = {
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => unknown;
  clearTimer?: (t: unknown) => void;
  minGapMs?: number;
  pollMs?: number;
  /** false = no fs.watch, the poll alone (tests). */
  watch?: boolean;
};

const blank = (cwd?: string): Tracked => ({
  cwd,
  dir: null,
  mainFile: null,
  watcher: null,
  files: new Map(),
  mainSig: '',
  notices: new Map(),
  lastSent: null,
  lastAt: -Infinity,
  timer: null,
  everHad: false,
  lastTrafficAt: 0,
  polls: 0,
  mainOffset: 0,
  projDir: null,
  endedAt: null,
  hasRunning: false,
});

/** Steps are shown on the phone, and a helper's output is not in the chat: key blocks and long key-like runs go, then the usual redaction. */
const safe = (text: string, max: number): string =>
  oneLine(
    text.replace(/-----BEGIN[\s\S]*?(?:-----END[^-]*-----|$)/g, '[key removed]').replace(/[A-Za-z0-9+=]{40,}/g, '***'),
    max,
  );

const sizeWords = (n: number): string => (n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(1)} KB` : `${(n / 1024 / 1024).toFixed(1)} MB`);

const readJson = (file: string): unknown => {
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
};

function readRange(file: string, from: number, len: number): string {
  const fd = openSync(file, 'r');
  try {
    const buf = Buffer.alloc(len);
    const n = readSync(fd, buf, 0, len, from);
    return buf.toString('utf8', 0, n);
  } finally {
    closeSync(fd);
  }
}

function tailLines(file: string, size: number, bytes: number): string[] {
  const len = Math.min(size, bytes);
  const lines = readRange(file, size - len, len).split('\n');
  return len < size ? lines.slice(1) : lines; // the first line of a cut tail is partial
}

function headLines(file: string, size: number): string[] {
  const lines = readRange(file, 0, Math.min(size, HEAD_BYTES)).split('\n');
  return size > HEAD_BYTES ? lines.slice(0, -1) : lines;
}

const parseLine = (l: string): Record<string, unknown> | null => {
  const t = l.trim();
  if (!t) return null;
  try {
    const d = JSON.parse(t);
    return d && typeof d === 'object' ? (d as Record<string, unknown>) : null;
  } catch {
    return null; // a line still being written
  }
};

const blocksOf = (d: Record<string, unknown>): Array<Record<string, unknown>> => {
  const c = (d.message as { content?: unknown } | undefined)?.content;
  return Array.isArray(c) ? (c as Array<Record<string, unknown>>) : [];
};

const textOfContent = (c: unknown): string =>
  typeof c === 'string'
    ? c
    : Array.isArray(c)
      ? c.map((b) => (b && typeof b === 'object' && typeof (b as { text?: unknown }).text === 'string' ? (b as { text: string }).text : '')).join(' ')
      : '';

/** The newest step in plain words, from a helper's last lines: its newest tool call, else it is writing or thinking. */
export function lastStepOf(lines: string[]): string | undefined {
  for (let i = lines.length - 1; i >= 0; i--) {
    const d = parseLine(lines[i]);
    if (!d || d.type !== 'assistant') continue;
    const blocks = blocksOf(d);
    const tool = [...blocks].reverse().find((b) => b.type === 'tool_use');
    if (tool) return describeTool(String(tool.name ?? ''), tool.input);
    if (blocks.some((b) => b.type === 'text')) return 'Writing a reply';
    if (blocks.some((b) => b.type === 'thinking')) return 'Thinking';
  }
  return undefined;
}

const tsOf = (lines: string[], fromEnd: boolean): string | undefined => {
  const order = fromEnd ? [...lines].reverse() : lines;
  for (const l of order) {
    const d = parseLine(l);
    if (d && typeof d.timestamp === 'string') return d.timestamp;
  }
  return undefined;
};

const tag = (text: string, name: string): string | undefined => {
  const m = new RegExp(`<${name}>([\\s\\S]*?)</${name}>`).exec(text);
  return m ? m[1].trim() : undefined;
};

/** Task notifications in the chat's own transcript lines: how background helpers ended (latest one per task wins). */
export function noticesOf(lines: string[]): Map<string, Notice> {
  const out = new Map<string, Notice>();
  for (const l of lines) {
    if (!l.includes('<task-notification>')) continue;
    const d = parseLine(l);
    if (!d || d.type !== 'user' || d.isSidechain) continue;
    const text = textOfContent((d.message as { content?: unknown } | undefined)?.content);
    const block = /<task-notification>([\s\S]*?)<\/task-notification>/.exec(text)?.[1];
    if (!block) continue;
    const status = tag(block, 'status') ?? 'completed';
    const result = tag(block, 'result') ?? tag(block, 'summary');
    const n: Notice = { status, ...(result ? { summary: safe(result, MAX_SUMMARY) } : {}), ...(typeof d.timestamp === 'string' ? { at: d.timestamp } : {}) };
    for (const key of [tag(block, 'task-id'), tag(block, 'tool-use-id')]) if (key) out.set(key, n);
  }
  return out;
}

/**
 * A helper's recent steps for the drill-down, from its transcript lines, oldest first within the page. `index` counts steps
 * from the start of the helper (stable while it grows); `before` pages to older ones. Tool results are cut short, secrets hidden.
 */
export function stepsOf(lines: string[], limit: number, before?: number): { steps: SubagentStep[]; nextBefore?: number } {
  const all: SubagentStep[] = [];
  for (const l of lines) {
    const d = parseLine(l);
    if (!d || d.isMeta) continue;
    const at = typeof d.timestamp === 'string' ? d.timestamp : undefined;
    const push = (role: SubagentStep['role'], text: string, max: number, raw = false) => {
      const t = raw ? text : safe(text, max);
      if (t) all.push({ index: all.length, role, text: t, ...(at ? { at } : {}) });
    };
    if (d.type === 'assistant') {
      for (const b of blocksOf(d)) {
        if (b.type === 'text' && typeof b.text === 'string') push('assistant', b.text, MAX_STEP_TEXT);
        else if (b.type === 'tool_use') push('tool', describeTool(String(b.name ?? ''), b.input), MAX_STEP);
      }
    } else if (d.type === 'user') {
      const content = (d.message as { content?: unknown } | undefined)?.content;
      // The helper's first prompt is not sent. A tool's output is never sent either: only how much came back.
      if (typeof content !== 'string')
        for (const b of blocksOf(d)) {
          if (b.type === 'tool_result') push('result', sizeWords(Buffer.byteLength(textOfContent(b.content))), 0, true);
        }
    }
  }
  const lim = Math.max(1, Math.min(MAX_STEPS_PAGE, Math.floor(limit) || MAX_STEPS_PAGE));
  const end = before === undefined ? all.length : Math.max(0, Math.min(all.length, Math.floor(before)));
  const start = Math.max(0, end - lim);
  return { steps: all.slice(start, end), ...(start > 0 ? { nextBefore: start } : {}) };
}

/**
 * Keeps each tracked chat's background helpers up to date and tells the hub. `track` a chat when it is seen, `untrack` it when
 * it is gone; the chat's folder is looked for again on every poll until it exists.
 */
export class SubagentTracker {
  private chats = new Map<string, Tracked>();
  /** Chats watched because they are open in a terminal (follow). */
  private followed = new Set<string>();
  private now: () => number;
  private setTimer: (fn: () => void, ms: number) => unknown;
  private clearTimer: (t: unknown) => void;
  private minGap: number;
  private useWatch: boolean;
  private poller: unknown = null;
  private pollMs: number;
  private projectsDir: string;

  constructor(
    private send: (msg: AgentSubagents) => void,
    t: Timers & { projectsDir?: string } = {},
  ) {
    this.now = t.now ?? Date.now;
    this.setTimer =
      t.setTimer ??
      ((fn, ms) => {
        const h = setTimeout(fn, ms);
        h.unref?.();
        return h;
      });
    this.clearTimer = t.clearTimer ?? ((h) => clearTimeout(h as NodeJS.Timeout));
    this.minGap = t.minGapMs ?? SUBAGENTS_MIN_GAP_MS;
    this.useWatch = t.watch !== false;
    this.pollMs = t.pollMs ?? POLL_MS;
    this.projectsDir = t.projectsDir ?? join(claudeSessionsDir(), '..', 'projects');
  }

  /** Every message the agent sends passes through here: a chat with any traffic is tracked, a gone one is not. */
  observe(msg: AgentToHubMessage): void {
    switch (msg.type) {
      case 'sdk_message':
      case 'session_activity':
      case 'permission_request':
        this.track(msg.sessionId);
        if (this.chats.has(msg.sessionId)) this.chats.get(msg.sessionId)!.lastTrafficAt = this.now();
        if (msg.type !== 'session_activity' || msg.activity === 'running') {
          const c = this.chats.get(msg.sessionId);
          if (c) c.endedAt = null;
        }
        return;
      case 'session_created':
        if (msg.tempId !== msg.sessionId) this.untrack(msg.tempId, false);
        this.track(msg.sessionId, msg.cwd);
        const c = this.chats.get(msg.sessionId);
        if (c) c.endedAt = null;
        return;
      case 'session_ended': {
        // The run is over, but its helpers may go on (or finish a moment later): keep watching until they are done.
        const c = this.chats.get(msg.sessionId);
        if (c) c.endedAt = this.now();
        return;
      }
      case 'session_deleted':
        this.untrack(msg.sessionId);
        return;
    }
  }

  track(sessionId: string, cwd?: string): void {
    if (!SAFE_ID.test(sessionId)) return;
    const have = this.chats.get(sessionId);
    if (have) {
      if (cwd && !have.cwd) have.cwd = cwd;
      return;
    }
    this.chats.set(sessionId, blank(cwd));
    this.ensurePoller();
    this.refresh(sessionId);
  }

  /**
   * Chats open in a terminal here (session id → folder), given every few seconds. Their helpers are watched while the terminal
   * is open, whether or not a turn runs: a terminal chat's helpers outlive its turn, and its transcript lines reach the hub (and
   * this tracker) only while a turn runs, so a chat that was idle when the agent started was never watched at all. A chat whose
   * terminal closed is watched on until its helpers are done, like a run that ended.
   */
  follow(open: Map<string, string | undefined>): void {
    for (const [id, cwd] of open) {
      if (!SAFE_ID.test(id)) continue;
      this.track(id, cwd);
      this.followed.add(id);
      const c = this.chats.get(id);
      if (c) c.endedAt = null;
    }
    for (const id of [...this.followed]) {
      if (open.has(id)) continue;
      this.followed.delete(id);
      const c = this.chats.get(id);
      if (c && c.endedAt === null) c.endedAt = this.now();
    }
  }

  /** Stop watching a chat. `final` = if it had helpers listed, tell the hub the list is empty (a clear). */
  untrack(sessionId: string, final = true): void {
    const c = this.chats.get(sessionId);
    if (!c) return;
    c.watcher?.close();
    if (c.timer) this.clearTimer(c.timer);
    this.chats.delete(sessionId);
    this.followed.delete(sessionId);
    if (final && c.lastSent && c.lastSent !== '[]') this.send({ type: 'subagents', sessionId, items: [] });
    if (this.chats.size === 0 && this.poller) {
      this.clearTimer(this.poller);
      this.poller = null;
    }
  }

  stop(): void {
    for (const id of [...this.chats.keys()]) {
      const c = this.chats.get(id)!;
      c.watcher?.close();
      if (c.timer) this.clearTimer(c.timer);
    }
    this.chats.clear();
    if (this.poller) this.clearTimer(this.poller);
    this.poller = null;
  }

  tracked(): string[] {
    return [...this.chats.keys()];
  }

  private ensurePoller(): void {
    if (this.poller) return;
    const tick = () => {
      for (const id of [...this.chats.keys()]) {
        const c0 = this.chats.get(id);
        if (c0 && (c0.hasRunning || !c0.dir || ++c0.polls % IDLE_POLL_EVERY === 0)) this.refresh(id);
        const c = this.chats.get(id);
        if (c && c.endedAt !== null && !c.hasRunning && this.now() - c.endedAt > IDLE_DROP_MS) this.untrack(id, false);
      }
      this.poller = this.chats.size ? this.setTimer(tick, this.pollMs) : null;
    };
    this.poller = this.setTimer(tick, this.pollMs);
  }

  /** The hub reconnected: every chat's list goes out again (the hub keeps nothing between connections). */
  resendAll(): void {
    for (const [id, c] of this.chats) {
      if (c.lastSent === '[]' || (!c.lastSent && c.everHad)) {
        // A clear is sent again too: a hub that keeps the latest list per chat must not keep an old one.
        c.lastSent = '[]';
        this.send({ type: 'subagents', sessionId: id, items: [] });
        continue;
      }
      if (!c.lastSent) continue;
      c.lastSent = null;
      c.lastAt = -Infinity;
      if (c.timer) this.clearTimer(c.timer);
      c.timer = null;
      this.refresh(id);
    }
  }

  private locate(sessionId: string, c: Tracked): void {
    if (c.dir && existsSync(c.dir)) return;
    if (c.dir) {
      // The folder was removed: stop watching it, so it is watched again when it comes back.
      c.watcher?.close();
      c.watcher = null;
    }
    c.dir = null;
    // Once the chat's own project folder is known, only its subagents folder is looked for (no scan of every project).
    const candidates: string[] = [];
    if (c.projDir) candidates.push(c.projDir);
    else {
      if (c.cwd) candidates.push(join(this.projectsDir, projectDirName(c.cwd)));
      try {
        for (const d of readdirSync(this.projectsDir)) candidates.push(join(this.projectsDir, d));
      } catch {
        return; // no projects folder yet
      }
    }
    for (const proj of candidates) {
      const main = join(proj, `${sessionId}.jsonl`);
      const sub = join(proj, sessionId, 'subagents');
      const hasMain = existsSync(main);
      if (hasMain) {
        c.mainFile = main;
        c.projDir = proj; // the chat is known; its helpers folder may appear later
      }
      if (existsSync(sub)) {
        c.dir = sub;
        c.projDir = proj;
        if (!hasMain) c.mainFile = null;
        this.watchDir(sessionId, c);
        return;
      }
      if (hasMain) return;
    }
  }

  private watchDir(sessionId: string, c: Tracked): void {
    if (!this.useWatch || !this.chats.has(sessionId) || c.watcher || !c.dir) return;
    try {
      c.watcher = watch(c.dir, { persistent: false }, () => this.refresh(sessionId));
      c.watcher.on('error', () => {
        c.watcher?.close();
        c.watcher = null;
      });
    } catch {
      // the poll covers it
    }
  }

  /** Reads the chat's helpers and sends the list when it changed (throttled). */
  refresh(sessionId: string): void {
    const c = this.chats.get(sessionId);
    if (!c) return;
    let items: SubagentItem[] = [];
    try {
      items = this.read(sessionId, c);
    } catch {
      return; // never let a bad file stop the agent
    }
    c.hasRunning = items.some((i) => i.state === 'running');
    const key = JSON.stringify(items);
    if (key === c.lastSent || (c.lastSent === null && items.length === 0)) {
      if (c.timer) this.clearTimer(c.timer);
      c.timer = null;
      return;
    }
    const wait = c.lastAt + this.minGap - this.now();
    if (wait > 0) {
      // A change that finishes a helper still goes out within the gap; the timer re-reads, so it sends the latest list.
      if (!c.timer)
        c.timer = this.setTimer(() => {
          c.timer = null;
          this.refresh(sessionId);
        }, wait);
      return;
    }
    c.lastSent = key;
    c.lastAt = this.now();
    c.everHad = true;
    this.send({ type: 'subagents', sessionId, items });
  }

  private read(sessionId: string, c: Tracked): SubagentItem[] {
    this.locate(sessionId, c);
    this.readNotices(c);
    if (!c.dir) return [];
    let names: string[] = [];
    try {
      names = readdirSync(c.dir);
    } catch {
      return [];
    }
    const ids = names.flatMap((n) => {
      const m = /^agent-([0-9A-Za-z_-]{1,80})\.(?:jsonl|meta\.json)$/.exec(n);
      return m ? [m[1]] : [];
    });
    const items: SubagentItem[] = [];
    for (const id of [...new Set(ids)]) {
      const item = this.itemOf(c, id);
      if (item) items.push(item);
    }
    items.sort((a, b) => (a.startedAt < b.startedAt ? -1 : a.startedAt > b.startedAt ? 1 : a.id < b.id ? -1 : 1));
    return items.slice(-MAX_ITEMS);
  }

  /** New lines of the chat's own transcript, from where the last read stopped (the first read goes through the whole file, in chunks).
   *  What was learned is kept: a notice that is long behind in a big transcript still counts. */
  private readNotices(c: Tracked): void {
    if (!c.mainFile) return;
    try {
      const st = statSync(c.mainFile);
      if (st.size < c.mainOffset) {
        c.mainOffset = 0; // rewritten or compacted: read again, what was learned stays
      }
      const fd = openSync(c.mainFile, 'r');
      try {
        let carry = Buffer.alloc(0);
        let pos = c.mainOffset;
        while (pos < st.size) {
          const buf = Buffer.alloc(Math.min(NOTICE_CHUNK, st.size - pos));
          const n = readSync(fd, buf, 0, buf.length, pos);
          if (n <= 0) break;
          pos += n;
          const all = Buffer.concat([carry, buf.subarray(0, n)]);
          const nl = all.lastIndexOf(0x0a);
          if (nl < 0) {
            carry = all;
            continue;
          }
          const lines = all.subarray(0, nl).toString('utf8').split('\n');
          for (const [k, v] of noticesOf(lines)) c.notices.set(k, v);
          carry = all.subarray(nl + 1);
        }
        c.mainOffset = pos - carry.length; // a half-written last line is read again next time
      } finally {
        closeSync(fd);
      }
    } catch {
      // keep what is known
    }
  }

  private itemOf(c: Tracked, id: string): SubagentItem | null {
    const dir = c.dir!;
    const meta = (readJson(join(dir, `agent-${id}.meta.json`)) ?? {}) as Meta;
    const file = join(dir, `agent-${id}.jsonl`);
    let info = c.files.get(id);
    try {
      const st = statSync(file);
      if (!info || info.mtimeMs !== st.mtimeMs || info.size !== st.size) {
        const tail = tailLines(file, st.size, TAIL_BYTES);
        info = {
          mtimeMs: st.mtimeMs,
          size: st.size,
          startedAt: info?.startedAt ?? tsOf(headLines(file, st.size), false),
          lastAt: tsOf(tail, true),
          lastStep: lastStepOf(tail) ?? info?.lastStep,
        };
        c.files.set(id, info);
      }
    } catch {
      info = info ?? undefined; // only the meta exists yet (or the lines are not readable yet)
    }
    const notice = c.notices.get(id) ?? (meta.toolUseId ? c.notices.get(meta.toolUseId) : undefined);
    const done = meta.finished === true || (notice !== undefined && notice.status !== 'running');
    // No notice and no word from the helper for a long time, in a chat that is not busy: its process is gone. Said as stopped.
    const lastMs = info?.mtimeMs ?? 0;
    const quiet = this.now() - Math.max(lastMs, c.lastTrafficAt);
    const stopped = !done && lastMs > 0 && quiet > STALE_MS && (c.endedAt !== null || c.lastTrafficAt === 0 || this.now() - c.lastTrafficAt > STALE_MS);
    const finished = done || stopped;
    const startedAt = info?.startedAt ?? (info ? new Date(info.mtimeMs).toISOString() : undefined) ?? new Date(this.now()).toISOString();
    const finishedAt = finished ? (notice?.at ?? info?.lastAt ?? (info ? new Date(info.mtimeMs).toISOString() : undefined)) : undefined;
    const item: SubagentItem = {
      id,
      description: oneLine(meta.description ?? 'Working in the background', MAX_DESC),
      state: finished ? 'finished' : 'running',
      startedAt,
    };
    if (typeof meta.model === 'string' && meta.model) item.model = oneLine(meta.model, 80);
    if (typeof meta.parentAgentId === 'string' && SAFE_ID.test(meta.parentAgentId)) item.parentId = meta.parentAgentId;
    if (finishedAt) item.finishedAt = finishedAt;
    if (info?.lastStep) item.lastStep = info.lastStep;
    if (stopped) item.stopped = true;
    if (finished && notice?.summary) item.summary = notice.summary;
    return item;
  }

  /** subagent_steps: the helper's newest steps, read-only, paged. Always answers (ok: false says why in plain words). */
  steps(cmd: { requestId: string; sessionId: string; id: string; limit?: number; before?: number }): AgentSubagentStepsResult {
    const fail = (error: string): AgentSubagentStepsResult => ({ type: 'subagent_steps_result', requestId: cmd.requestId, ok: false, error });
    if (!SAFE_ID.test(cmd.sessionId) || !SAFE_ID.test(cmd.id)) return fail('That helper was not found.');
    // A chat that is not tracked is looked up once, without starting to watch it.
    const c = this.chats.get(cmd.sessionId) ?? blank();
    try {
      this.locate(cmd.sessionId, c);
      const file = c.dir ? join(c.dir, `agent-${cmd.id}.jsonl`) : null;
      if (!file || !existsSync(file)) return fail('That helper was not found on this computer.');
      const st = statSync(file);
      // A very long helper: only the end is read, so the earliest steps are not reachable (indexes then start later).
      const lines = st.size > MAX_STEPS_FILE_BYTES ? tailLines(file, st.size, MAX_STEPS_FILE_BYTES) : readFileSync(file, 'utf8').split('\n');
      const { steps, nextBefore } = stepsOf(lines, cmd.limit ?? MAX_STEPS_PAGE, cmd.before);
      return { type: 'subagent_steps_result', requestId: cmd.requestId, ok: true, steps, ...(nextBefore !== undefined ? { nextBefore } : {}) };
    } catch {
      return fail('Could not read that helper.');
    } finally {
      if (!this.chats.has(cmd.sessionId)) c.watcher?.close();
    }
  }
}
