import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

/**
 * The machine-wide guard: puts the safety hook (safetyHook.ts) into the settings of every Claude Code on this computer: the default
 * one (~/.claude), each profile folder (~/.claude-profiles/*, CLAUDE_CONFIG_DIR) and the agent's own accounts. So a Claude that
 * Escanor did not start (a terminal chat, a `claude -p` from a timer, which is what wiped a laptop on 20 Oct 2026) still goes
 * through the same safety layer. The agent checks every minute that the hook is still there and puts it back if something took it
 * out. Turning safety off (ESCANOR_SAFETY=0 for the agent) takes it out of every file.
 */

export const SAFETY_HOOK_MARK = 'escanor-safety-hook';
/** Tools whose calls are checked: those that run commands, and file edits (only to keep the hook itself in place). */
export const SAFETY_MATCHER = 'Bash|PowerShell|Monitor|Write|Edit|MultiEdit|mcp__.*';
/** Seconds Claude Code waits for the hook: a copy may take up to a minute; a hook that times out lets the call run. */
export const SAFETY_HOOK_TIMEOUT = 180;

type HookGroup = { matcher?: string; hooks?: Array<Record<string, unknown>> };
type Settings = { hooks?: Record<string, HookGroup[]>; disableAllHooks?: unknown } & Record<string, unknown>;

const q = (s: string) => (process.platform === 'win32' ? `"${s}"` : `'${s.replace(/'/g, `'\\''`)}'`);

/**
 * The command Claude Code runs: this Node on the hook's TypeScript (Node's own type stripping where it has it, else tsx).
 * Inside Escanor Desktop "this Node" is the app's own program (Electron), which starts the whole app unless ELECTRON_RUN_AS_NODE
 * is set: without it every checked tool call opened another Escanor Desktop. Claude Code runs hooks in a POSIX shell (Git Bash on
 * Windows), so a variable prefix reaches the program.
 */
export function safetyHookCommand(root: string, nodePath = process.execPath, version = process.versions.node, electron = Boolean(process.versions.electron)): string {
  const hook = fileURLToPath(new URL('./safetyHook.ts', import.meta.url));
  const [maj, min] = version.split('.').map(Number);
  const strip = maj > 22 || (maj === 22 && min >= 6);
  const loader = strip ? '--experimental-strip-types --no-warnings' : `--import ${q(fileURLToPath(import.meta.resolve('tsx')))}`;
  return `${electron ? 'ELECTRON_RUN_AS_NODE=1 ' : ''}${q(nodePath)} ${loader} ${q(hook)} ${q(`--root=${root}`)} --${SAFETY_HOOK_MARK}`;
}

/** Every Claude Code settings file on this computer that should carry the hook (existing config folders only). */
export function claudeSettingsFiles(home = homedir(), env: NodeJS.ProcessEnv = process.env, extraDirs: string[] = []): string[] {
  const dirs = new Set<string>([join(home, '.claude')]);
  if (env.CLAUDE_CONFIG_DIR?.trim()) dirs.add(env.CLAUDE_CONFIG_DIR.trim());
  for (const parent of [join(home, '.claude-profiles')]) {
    try {
      for (const n of readdirSync(parent)) {
        const d = join(parent, n);
        if (statSync(d).isDirectory()) dirs.add(d);
      }
    } catch {
      /* none */
    }
  }
  for (const d of extraDirs) dirs.add(d);
  return [...dirs].filter((d) => existsSync(d)).map((d) => join(d, 'settings.json'));
}

/** Settings with the safety hook set (or taken out); everything else kept as it was. */
export function withSafetyHook(settings: Settings, command: string | null): Settings {
  const hooks: Record<string, HookGroup[]> = { ...(settings.hooks ?? {}) };
  const groups = (hooks.PreToolUse ?? [])
    .map((g) => ({ ...g, hooks: (g.hooks ?? []).filter((h) => !String(h.command ?? '').includes(SAFETY_HOOK_MARK)) }))
    .filter((g) => g.hooks.length > 0);
  // First, so it runs before anything else decides.
  if (command) groups.unshift({ matcher: SAFETY_MATCHER, hooks: [{ type: 'command', command, timeout: SAFETY_HOOK_TIMEOUT }] });
  if (groups.length) hooks.PreToolUse = groups;
  else delete hooks.PreToolUse;
  const out: Settings = { ...settings, hooks };
  if (!Object.keys(hooks).length) delete out.hooks;
  // A switch that turns every hook off would turn the guard off too.
  if (command && out.disableAllHooks) delete out.disableAllHooks;
  return out;
}

export type GuardStatus = { file: string; state: 'set' | 'already' | 'removed' | 'skipped'; note?: string };

export function installSafetyHook(o: { root: string; enabled: boolean; files?: string[]; command?: string }): GuardStatus[] {
  const command = o.enabled ? (o.command ?? safetyHookCommand(o.root)) : null;
  const out: GuardStatus[] = [];
  for (const file of o.files ?? claudeSettingsFiles()) {
    let before = '';
    let settings: Settings = {};
    try {
      if (existsSync(file)) {
        before = readFileSync(file, 'utf8');
        const parsed = before.trim() ? JSON.parse(before) : {};
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          out.push({ file, state: 'skipped', note: 'not a settings object' });
          continue;
        }
        settings = parsed;
      }
    } catch {
      out.push({ file, state: 'skipped', note: 'not valid JSON' });
      continue;
    }
    const next = withSafetyHook(settings, command);
    if (JSON.stringify(next) === JSON.stringify(settings)) {
      out.push({ file, state: 'already' });
      continue;
    }
    if (!before && !command) continue;
    try {
      mkdirSync(dirname(file), { recursive: true });
      const tmp = `${file}.escanor-safety-${process.pid}.tmp`;
      writeFileSync(tmp, `${JSON.stringify(next, null, 2)}\n`, { mode: existsSync(file) ? statSync(file).mode & 0o777 : 0o600 });
      renameSync(tmp, file);
      out.push({ file, state: command ? 'set' : 'removed' });
    } catch (err) {
      out.push({ file, state: 'skipped', note: err instanceof Error ? err.message : String(err) });
    }
  }
  return out;
}

/** Does a file edit take the safety hook out of a Claude settings file (or turn all hooks off)? Then it is refused. */
export function removesGuard(toolName: string, input: unknown, read: (p: string) => string = (p) => readFileSync(p, 'utf8')): boolean {
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const file = String(i.file_path ?? '');
  if (!/[\\/]settings(?:\.local)?\.json$/.test(file)) return false;
  const has = (t: string) => t.includes(SAFETY_HOOK_MARK);
  const disables = (t: string) => /"disableAllHooks"\s*:\s*true/.test(t);
  if (toolName === 'Write') {
    const content = String(i.content ?? '');
    let now = '';
    try {
      now = read(file);
    } catch {
      return disables(content);
    }
    return (has(now) && !has(content)) || disables(content);
  }
  const edits = toolName === 'MultiEdit' && Array.isArray(i.edits) ? (i.edits as Array<Record<string, unknown>>) : [i];
  return edits.some((e) => (has(String(e.old_string ?? '')) && !has(String(e.new_string ?? ''))) || disables(String(e.new_string ?? '')));
}
