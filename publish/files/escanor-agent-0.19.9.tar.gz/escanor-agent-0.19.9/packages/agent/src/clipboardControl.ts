import { spawn } from 'node:child_process';
import { desktopEnv } from './computerControl.js';

/**
 * The computer's clipboard, for "Connect it for me": the server asks the laptop to read a freshly made key off the clipboard (the
 * provider's Copy button put it there) and then to empty the clipboard again. The text goes straight back to the server: it is never
 * logged, never put in an answer's words, and never passed to a program as an argument. Only fixed programs with fixed arguments run,
 * and text goes to a program on its standard input (a write), never into a command.
 */

export const MAX_CLIP_READ = 4096;

export type ClipStep = { cmd: string; args: string[] };
/** Runs one fixed program. `input` goes to its standard input. Never throws. `missing` = the program is not installed. */
export type ClipRunner = (step: ClipStep, env: NodeJS.ProcessEnv, input?: string) => Promise<{ code: number | null; stdout: string; missing: boolean }>;

const isWayland = (env: NodeJS.ProcessEnv): boolean => Boolean(env.WAYLAND_DISPLAY) || env.XDG_SESSION_TYPE === 'wayland';

export function clipReadSteps(platform: NodeJS.Platform, env: NodeJS.ProcessEnv): ClipStep[] {
  if (platform === 'darwin') return [{ cmd: 'pbpaste', args: [] }];
  if (platform === 'win32') return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', '[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-Clipboard -Raw'] }];
  const wl = { cmd: 'wl-paste', args: ['--no-newline'] };
  const x = [{ cmd: 'xclip', args: ['-selection', 'clipboard', '-out'] }, { cmd: 'xsel', args: ['--clipboard', '--output'] }];
  return isWayland(env) ? [wl, ...x] : [...x, wl];
}

/** Empty the clipboard: standard input is empty text (macOS, X11, Windows) or the tool's own clear option. */
export function clipClearSteps(platform: NodeJS.Platform, env: NodeJS.ProcessEnv): ClipStep[] {
  if (platform === 'darwin') return [{ cmd: 'pbcopy', args: [] }];
  if (platform === 'win32') return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', 'Set-Clipboard -Value $null'] }];
  const wl = { cmd: 'wl-copy', args: ['--clear'] };
  const x = [{ cmd: 'xclip', args: ['-selection', 'clipboard', '-in'] }, { cmd: 'xsel', args: ['--clipboard', '--clear'] }];
  return isWayland(env) ? [wl, ...x] : [...x, wl];
}

export const CLIP_MISSING_SAY = 'Install wl-clipboard (Wayland) or xclip (X11) so Escanor can capture a key.';

const TIMEOUT_MS = 5000;

export const realClipRunner: ClipRunner = (step, env, input) =>
  new Promise((resolve) => {
    let out = '';
    let settled = false;
    const done = (r: { code: number | null; stdout: string; missing: boolean }) => {
      if (!settled) {
        settled = true;
        resolve(r);
      }
    };
    try {
      // Only a read keeps the program's output; a write's output is dropped (xclip keeps its output open while it holds the text).
      const reading = input === undefined;
      const child = spawn(step.cmd, step.args, { env, stdio: ['pipe', reading ? 'pipe' : 'ignore', 'ignore'], windowsHide: true });
      const timer = setTimeout(() => {
        child.kill();
        done({ code: null, stdout: '', missing: false });
      }, TIMEOUT_MS);
      timer.unref();
      child.stdout?.on('data', (d: Buffer) => {
        if (out.length < 200_000) out += d.toString('utf8');
      });
      child.once('error', (err: NodeJS.ErrnoException) => (clearTimeout(timer), done({ code: null, stdout: '', missing: err.code === 'ENOENT' })));
      child.once('close', (code) => (clearTimeout(timer), done({ code, stdout: out, missing: false })));
      child.stdin?.on('error', () => {});
      child.stdin?.end(input ?? '');
    } catch {
      done({ code: null, stdout: '', missing: true });
    }
  });

export type ClipDeps = { platform?: NodeJS.Platform; env?: NodeJS.ProcessEnv; run?: ClipRunner };

export type ClipOutcome = { ok: true; text: string } | { ok: false; missing: boolean };

async function firstOk(steps: ClipStep[], deps: ClipDeps, input?: string): Promise<ClipOutcome> {
  const platform = deps.platform ?? process.platform;
  const env = desktopEnv(deps.env ?? process.env, platform);
  const run = deps.run ?? realClipRunner;
  let missing = 0;
  for (const s of steps) {
    const r = await run(s, env, input).catch(() => ({ code: null as number | null, stdout: '', missing: false }));
    if (r.code === 0) return { ok: true, text: r.stdout };
    if (r.missing) missing++;
  }
  return { ok: false, missing: missing === steps.length };
}

/** The clipboard's text, trimmed and cut to MAX_CLIP_READ characters (empty when it holds no text). */
export async function readClipboard(deps: ClipDeps = {}): Promise<ClipOutcome> {
  const platform = deps.platform ?? process.platform;
  const env = desktopEnv(deps.env ?? process.env, platform);
  const r = await firstOk(clipReadSteps(platform, env), deps);
  return r.ok ? { ok: true, text: [...r.text.trim()].slice(0, MAX_CLIP_READ).join('') } : r;
}

/** Replace the clipboard with empty text. */
export async function clearClipboard(deps: ClipDeps = {}): Promise<ClipOutcome> {
  const platform = deps.platform ?? process.platform;
  const env = desktopEnv(deps.env ?? process.env, platform);
  // Empty text on standard input for the tools that take their text there.
  const r = await firstOk(clipClearSteps(platform, env), deps, '');
  return r.ok ? { ok: true, text: '' } : r;
}
