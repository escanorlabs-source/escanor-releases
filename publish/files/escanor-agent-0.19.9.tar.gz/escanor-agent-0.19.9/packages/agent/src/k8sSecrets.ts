import { createHash, createHmac, randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { childEnv } from './childEnv.js';

/**
 * Kubernetes Secrets through the person's own kubectl and kubeconfig (no cloud key): list names, set one key, remove one key, and put
 * an old value back. Escanor's API asks for these through the hub as direct commands (jarvis.ts `k8s_*`), after the person's fingerprint
 * yes to the plan. The rules this file keeps:
 *
 *  - A VALUE never appears in an argument, a log, a message or a result. A new value is fetched here from the Escanor vault by name
 *    (the machine's own key) and goes to kubectl on its standard input, inside the Secret's JSON. Listing uses a template that prints
 *    names only.
 *  - What the person's cluster holds is compared by a keyed digest (HMAC with a key that never leaves this computer), so the plan can
 *    see "changed since" without anyone holding a value or a hash of one that could be guessed at.
 *  - The old value is read just before a change and kept in this process's memory only (3 hours, 50 changes), so a change that turns
 *    bad can be put back. If this agent restarts first, the put-back says plainly that it cannot.
 *  - `kubectl replace` carries the Secret's resourceVersion: if someone else changed the Secret meanwhile, the cluster refuses and
 *    nothing is overwritten. Only the one key is touched; an immutable Secret is refused; a Secret that is not there is never made.
 *  - Every name is checked here again (no option can be smuggled in: each is passed as `--flag=value` after a pattern check), the
 *    contexts may be limited with ESCANOR_K8S_CONTEXTS, and nothing goes through a shell.
 */

export const K8S_ACTIONS = ['k8s_names', 'k8s_read', 'k8s_set', 'k8s_remove', 'k8s_restore'] as const;
export type K8sAction = (typeof K8S_ACTIONS)[number];
export const isK8sAction = (a: string): a is K8sAction => (K8S_ACTIONS as readonly string[]).includes(a);

export type Run = { code: number; stdout: string; stderr: string };
/** Runs kubectl with these arguments (never a shell) and this standard input. */
export type Exec = (args: string[], stdin?: string) => Promise<Run>;
export type VaultRead = (name: string, scope: string) => Promise<{ ok: true; value: string } | { ok: false; reason: string }>;

export type K8sResult = { ok: true; say: string; data?: Record<string, unknown> } | { ok: false; say: string; code: 'refused' | 'failed' };

export interface K8sDeps {
  exec: Exec;
  /** The Escanor vault, as this machine (machineApi.resolveSecrets). */
  vault: VaultRead;
  /** The key the digests are made with (kept in a 0600 file next to the agent's other data). */
  digestKey: () => Buffer;
  /** Contexts the person allows (ESCANOR_K8S_CONTEXTS, comma separated); empty or absent = every context in the kubeconfig. */
  allowedContexts?: string[];
  now?: () => number;
  /** Safety log line (no value in it). */
  log?: (action: string, why: string, what?: string) => void;
}

const CONTEXT = /^[A-Za-z0-9][A-Za-z0-9._:@/=,+-]{0,252}$/;
const NAMESPACE = /^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$/;
const SECRET = /^[a-z0-9]([-a-z0-9.]{0,251}[a-z0-9])?$/;
const KEY = /^[-._a-zA-Z0-9]{1,253}$/;
const VAULT_NAME = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;
const VAULT_SCOPE = /^(workspace|project:[A-Za-z0-9_-]{1,100})$/;
const DIGEST = /^[0-9a-f]{16}$/;
const WANT = /^[0-9a-f]{32}$/;
/** What the plan was made for: the first 32 hex characters of the value's SHA-256. Compared here only; never stored or logged. */
export const wantOf = (value: Buffer | string): string => createHash('sha256').update(value).digest('hex').slice(0, 32);
const MAX_VALUE_BYTES = 900_000; // a Secret is at most 1 MiB in all
export const SNAPSHOT_MS = 3 * 3600_000;
export const MAX_SNAPSHOTS = 50;
const TIMEOUT_MS = 20_000;
const MAX_OUT = 4_000_000;

type Place = { context: string; namespace: string };
type SecretObject = { metadata?: Record<string, unknown>; data?: Record<string, string>; type?: string; immutable?: boolean; [k: string]: unknown };
type Snapshot = Place & { secret: string; key: string; old: string | null; at: number };

const text = (v: unknown): string => (typeof v === 'string' ? v : '');

/** The real kubectl: the program named by ESCANOR_KUBECTL, else `kubectl` on the PATH. Output is bounded; it is killed after 20 s. */
export function realExec(env: NodeJS.ProcessEnv = process.env): Exec {
  return (args, stdin) =>
    new Promise((resolve) => {
      const child = spawn(env.ESCANOR_KUBECTL?.trim() || 'kubectl', args, { env: childEnv(env) as NodeJS.ProcessEnv, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
      let stdout = '';
      let stderr = '';
      let done = false;
      const finish = (r: Run) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(r);
      };
      const timer = setTimeout(() => {
        child.kill('SIGKILL');
        finish({ code: 124, stdout: '', stderr: 'kubectl took too long' });
      }, TIMEOUT_MS);
      child.stdout.on('data', (d: Buffer) => {
        if (stdout.length < MAX_OUT) stdout += d.toString('utf8');
      });
      child.stderr.on('data', (d: Buffer) => {
        if (stderr.length < 20_000) stderr += d.toString('utf8');
      });
      child.on('error', (e) => finish({ code: 127, stdout: '', stderr: (e as NodeJS.ErrnoException).code === 'ENOENT' ? 'kubectl is not installed on this computer' : `kubectl could not start (${(e as NodeJS.ErrnoException).code ?? 'error'})` }));
      child.on('close', (code) => finish({ code: code ?? 1, stdout, stderr }));
      child.stdin.on('error', () => {});
      child.stdin.end(stdin ?? '');
    });
}

/** The digest key: made once, in a file only this user can read. */
export function fileDigestKey(path: string): () => Buffer {
  let cached: Buffer | null = null;
  return () => {
    if (cached) return cached;
    if (existsSync(path)) {
      const b = Buffer.from(readFileSync(path, 'utf8').trim(), 'hex');
      if (b.length >= 32) return (cached = b);
    }
    const b = randomBytes(32);
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    writeFileSync(path, b.toString('hex'), { mode: 0o600 });
    try {
      chmodSync(path, 0o600);
    } catch {
      /* best effort on systems without modes */
    }
    return (cached = b);
  };
}

export class K8sSecrets {
  private snaps = new Map<string, Snapshot>();
  constructor(private d: K8sDeps) {}

  private now = () => (this.d.now ?? Date.now)();

  /** Keyed digest of a value (as stored: its raw bytes) tied to the place, so the same value elsewhere gives another digest. */
  digest(p: Place & { secret: string; key: string }, value: Buffer): string {
    return createHmac('sha256', this.d.digestKey()).update(`${p.context}\n${p.namespace}\n${p.secret}\n${p.key}\n`).update(value).digest('hex').slice(0, 16);
  }

  private fail(say: string, code: 'refused' | 'failed' = 'failed'): K8sResult {
    return { ok: false, say, code };
  }

  /** What kubectl said, shortened, with anything that looks like a value we hold taken out. */
  private said(r: Run, mask: string[] = []): string {
    let t = (r.stderr || r.stdout || `kubectl exited with ${r.code}`).replace(/\s+/g, ' ').trim();
    for (const m of mask) if (m.length >= 4) t = t.split(m).join('[value]');
    return t.slice(0, 220);
  }

  private place(args: Record<string, unknown>): Place | K8sResult {
    const context = text(args.context);
    const namespace = text(args.namespace);
    if (!CONTEXT.test(context)) return this.fail('Name the cluster context as it is in your kubeconfig.', 'refused');
    if (!NAMESPACE.test(namespace)) return this.fail('Name the namespace as Kubernetes does (lower-case letters, digits, dashes).', 'refused');
    const allow = (this.d.allowedContexts ?? []).filter(Boolean);
    if (allow.length && !allow.includes(context)) return this.fail(`This computer only lets Escanor use these cluster contexts: ${allow.join(', ')}.`, 'refused');
    return { context, namespace };
  }

  private base(p: Place): string[] {
    return [`--context=${p.context}`, `--namespace=${p.namespace}`, '--request-timeout=15s'];
  }

  private async contextKnown(context: string): Promise<K8sResult | null> {
    const r = await this.d.exec(['config', 'get-contexts', '-o', 'name']);
    if (r.code !== 0) return this.fail(`kubectl could not read the kubeconfig: ${this.said(r)}`);
    if (!r.stdout.split('\n').map((l) => l.trim()).includes(context)) return this.fail(`There is no cluster context named ${context} in this computer's kubeconfig.`, 'refused');
    return null;
  }

  /** The Secret as the cluster has it. `missing` when it is not there. Values stay in this function's callers' memory only. */
  private async fetch(p: Place, secret: string): Promise<{ obj: SecretObject } | { missing: true } | K8sResult> {
    const r = await this.d.exec([...this.base(p), 'get', 'secret', secret, '-o', 'json']);
    if (r.code !== 0) {
      if (/NotFound|not found/i.test(r.stderr)) return { missing: true };
      return this.fail(`The cluster did not show the Secret: ${this.said(r)}`);
    }
    try {
      const obj = JSON.parse(r.stdout) as SecretObject;
      if (!obj || typeof obj !== 'object') throw new Error('shape');
      return { obj };
    } catch {
      return this.fail('The cluster answered in a way this agent could not read.');
    }
  }

  private async write(p: Place, obj: SecretObject, mask: string[]): Promise<K8sResult | null> {
    const r = await this.d.exec([...this.base(p), 'replace', '-f', '-'], JSON.stringify(obj));
    if (r.code === 0) return null;
    if (/Conflict|the object has been modified/i.test(r.stderr)) return this.fail('The Secret was changed by someone else a moment ago, so nothing was written. Make a new plan.');
    return this.fail(`The cluster refused the change: ${this.said(r, mask)}`);
  }

  private keyOf(args: Record<string, unknown>): string | K8sResult {
    const key = text(args.key);
    return KEY.test(key) && key !== '.' && key !== '..' ? key : this.fail('A key is letters, digits, dots, dashes and underscores.', 'refused');
  }

  private secretOf(args: Record<string, unknown>): string | K8sResult {
    const s = text(args.secret);
    return SECRET.test(s) ? s : this.fail('Name the Secret as Kubernetes does (lower-case letters, digits, dashes, dots).', 'refused');
  }

  private rememberSnapshot(s: Snapshot): string {
    const t = this.now();
    for (const [id, v] of this.snaps) if (t - v.at > SNAPSHOT_MS) this.snaps.delete(id);
    while (this.snaps.size >= MAX_SNAPSHOTS) this.snaps.delete(this.snaps.keys().next().value as string);
    const id = randomBytes(12).toString('hex');
    this.snaps.set(id, s);
    return id;
  }

  async handle(action: K8sAction, args: Record<string, unknown>): Promise<K8sResult> {
    const p = this.place(args);
    if ('ok' in p) return p;
    const known = await this.contextKnown(p.context);
    if (known) return known;
    switch (action) {
      case 'k8s_names':
        return this.names(p, args);
      case 'k8s_read':
        return this.read(p, args);
      case 'k8s_set':
        return this.change(p, args, true);
      case 'k8s_remove':
        return this.change(p, args, false);
      case 'k8s_restore':
        return this.restore(p, args);
    }
  }

  /** Names of the Secrets in the namespace, or (with `secret`) the keys inside one. A template prints only names. */
  private async names(p: Place, args: Record<string, unknown>): Promise<K8sResult> {
    if (args.secret === undefined || args.secret === null || args.secret === '') {
      const r = await this.d.exec([...this.base(p), 'get', 'secrets', '-o', 'go-template={{range .items}}{{.metadata.name}}{{"\\n"}}{{end}}']);
      if (r.code !== 0) return this.fail(`The cluster did not list the Secrets: ${this.said(r)}`);
      const names = r.stdout.split('\n').map((l) => l.trim()).filter((l) => SECRET.test(l));
      this.d.log?.('k8s_names', `listed ${names.length} Secret name(s) in ${p.namespace}`, p.context);
      return { ok: true, say: `${names.length} Secret${names.length === 1 ? '' : 's'} in ${p.namespace}.`, data: { names: names.slice(0, 500) } };
    }
    const secret = this.secretOf(args);
    if (typeof secret !== 'string') return secret;
    const r = await this.d.exec([...this.base(p), 'get', 'secret', secret, '-o', 'go-template={{range $k, $v := .data}}{{$k}}{{"\\n"}}{{end}}']);
    if (r.code !== 0) return /NotFound|not found/i.test(r.stderr) ? this.fail(`There is no Secret ${secret} in ${p.namespace}.`) : this.fail(`The cluster did not list the keys: ${this.said(r)}`);
    const keys = r.stdout.split('\n').map((l) => l.trim()).filter((l) => KEY.test(l));
    this.d.log?.('k8s_names', `listed ${keys.length} key name(s) of ${secret}`, `${p.context}/${p.namespace}`);
    return { ok: true, say: `${keys.length} key${keys.length === 1 ? '' : 's'} in ${secret}.`, data: { keys: keys.slice(0, 500) } };
  }

  /** Whether the Secret and the key are there, and the key's digest. Never the value. */
  private async read(p: Place, args: Record<string, unknown>): Promise<K8sResult> {
    const secret = this.secretOf(args);
    if (typeof secret !== 'string') return secret;
    const key = this.keyOf(args);
    if (typeof key !== 'string') return key;
    const got = await this.fetch(p, secret);
    if ('ok' in got) return got;
    if ('missing' in got) return { ok: true, say: `There is no Secret ${secret} in ${p.namespace}.`, data: { present: false, keyPresent: false } };
    const raw = got.obj.data?.[key];
    const data: Record<string, unknown> = { present: true, keyPresent: typeof raw === 'string', immutable: got.obj.immutable === true, secretType: text(got.obj.type) || 'Opaque' };
    if (typeof raw === 'string') data.digest = this.digest({ ...p, secret, key }, Buffer.from(raw, 'base64'));
    return { ok: true, say: typeof raw === 'string' ? `${key} is in ${secret}.` : `${key} is not in ${secret}.`, data };
  }

  /** Set (`set`) or remove one key. */
  private async change(p: Place, args: Record<string, unknown>, set: boolean): Promise<K8sResult> {
    const action = set ? 'k8s_set' : 'k8s_remove';
    const secret = this.secretOf(args);
    if (typeof secret !== 'string') return secret;
    const key = this.keyOf(args);
    if (typeof key !== 'string') return key;
    const expect = args.expect === null || args.expect === undefined ? null : text(args.expect);
    if (expect !== null && !DIGEST.test(expect)) return this.fail('The expected digest is not one this agent made.', 'refused');
    let value: Buffer | null = null;
    if (set) {
      const name = text(args.vault_name);
      const scope = text(args.vault_scope) || 'workspace';
      if (!VAULT_NAME.test(name) || !VAULT_SCOPE.test(scope)) return this.fail('Name the vault secret the value comes from.', 'refused');
      const want = text(args.want);
      if (!WANT.test(want)) return this.fail('The plan did not say which value it was made for.', 'refused');
      const got = await this.d.vault(name, scope);
      if (!got.ok) return this.fail(`The value could not be fetched from the Escanor vault (${got.reason}).`);
      value = Buffer.from(got.value, 'utf8');
      if (!value.length || value.length > MAX_VALUE_BYTES) return this.fail('The vault value is empty or too big for a Secret.', 'refused');
      if (wantOf(value) !== want) {
        return this.fail(`The vault secret ${name} changed after the plan was made, so nothing was written. Make a new plan.`, 'refused');
      }
    }
    const mask = value ? [value.toString('utf8'), value.toString('base64')] : [];
    const got = await this.fetch(p, secret);
    if ('ok' in got) return got;
    if ('missing' in got) return this.fail(`There is no Secret ${secret} in ${p.namespace}. Escanor changes a key of a Secret that exists; it does not create Secrets.`, 'refused');
    const obj = got.obj;
    if (obj.immutable === true) return this.fail(`The Secret ${secret} is immutable, so Kubernetes does not allow a change.`, 'refused');
    const data: Record<string, string> = { ...(obj.data ?? {}) };
    const old = typeof data[key] === 'string' ? data[key] : null;
    const oldDigest = old === null ? null : this.digest({ ...p, secret, key }, Buffer.from(old, 'base64'));
    if (oldDigest !== expect) return this.fail(`${key} in ${secret} is not what it was when the plan was made, so nothing was changed. Make a new plan.`, 'refused');
    if (!set && old === null) return this.fail(`${key} is not in ${secret}.`, 'refused');
    if (set) data[key] = (value as Buffer).toString('base64');
    else delete data[key];
    const next: SecretObject = { ...obj, data };
    if (!Object.keys(data).length) delete next.data;
    const failed = await this.write(p, next, mask);
    if (failed) return failed;
    const snapshot = this.rememberSnapshot({ ...p, secret, key, old, at: this.now() });
    const after = await this.fetch(p, secret);
    const now = 'obj' in after ? after.obj.data?.[key] : undefined;
    const digest = typeof now === 'string' ? this.digest({ ...p, secret, key }, Buffer.from(now, 'base64')) : null;
    if (set && (digest === null || digest !== this.digest({ ...p, secret, key }, value as Buffer))) return this.fail(`The cluster took the change but ${key} does not read back as the new value.`);
    this.d.log?.(action, set ? `set the key ${key} of ${secret}${old === null ? ' (new key)' : ''}` : `removed the key ${key} of ${secret}`, `${p.context}/${p.namespace}`);
    return { ok: true, say: set ? `${key} is set in ${secret}.` : `${key} is removed from ${secret}.`, data: { changed: true, snapshot, ...(digest ? { digest } : {}), keyPresent: digest !== null } };
  }

  /** Put the key back as the snapshot kept it. Only what this agent kept in memory: after a restart it says so. */
  private async restore(p: Place, args: Record<string, unknown>): Promise<K8sResult> {
    const id = text(args.snapshot);
    const snap = /^[0-9a-f]{24}$/.test(id) ? this.snaps.get(id) : undefined;
    if (!snap || this.now() - snap.at > SNAPSHOT_MS) {
      return this.fail('The old value is not kept on this computer any more (the Escanor agent restarted, or too long has passed), so it cannot be put back from here.');
    }
    if (snap.context !== p.context || snap.namespace !== p.namespace || snap.secret !== text(args.secret) || snap.key !== text(args.key)) {
      return this.fail('That saved value belongs to a different Secret.', 'refused');
    }
    const got = await this.fetch(p, snap.secret);
    if ('ok' in got) return got;
    if ('missing' in got) return this.fail(`The Secret ${snap.secret} is not there any more.`);
    const data: Record<string, string> = { ...(got.obj.data ?? {}) };
    if (snap.old === null) delete data[snap.key];
    else data[snap.key] = snap.old;
    const next: SecretObject = { ...got.obj, data };
    if (!Object.keys(data).length) delete next.data;
    const failed = await this.write(p, next, snap.old ? [snap.old, Buffer.from(snap.old, 'base64').toString('utf8')] : []);
    if (failed) return failed;
    const after = await this.fetch(p, snap.secret);
    const now = 'obj' in after ? after.obj.data?.[snap.key] : undefined;
    const digest = typeof now === 'string' ? this.digest({ ...p, secret: snap.secret, key: snap.key }, Buffer.from(now, 'base64')) : null;
    this.snaps.delete(id);
    this.d.log?.('k8s_restore', `put the key ${snap.key} of ${snap.secret} back`, `${p.context}/${p.namespace}`);
    return { ok: true, say: `${snap.key} is back as it was in ${snap.secret}.`, data: { changed: true, keyPresent: digest !== null, ...(digest ? { digest } : {}) } };
  }
}
