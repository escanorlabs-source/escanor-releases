import { closeSync, existsSync, openSync, readSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { claudeSessionsDir } from './claudeProcs.js';
import { scanBackground, type BackgroundScan } from './background.js';

/**
 * Has the last turn of a terminal chat ended, going by its transcript?
 *
 * Claude Code's record of a running process (~/.claude/sessions/<pid>.json, claudeProcs.ts) can say `busy` for hours after the
 * reply is done: it is not rewritten at the end of a turn while background jobs it started (a shell left waiting, a subagent)
 * are still open. A chat like that is idle at its prompt and takes a phone message at once (terminalInbox.ts), but the phone
 * was told it was working and held the message back. The transcript is the truth: every finished turn ends with a
 * `system` / `turn_duration` line, an interrupted one with "[Request interrupted by user...]".
 */

/** How much of the end of a transcript is read (the last turn's closing lines are small; tool output is what makes it big). */
const TAIL_BYTES = 256 * 1024;
/** Background work can have started many turns ago: more of the end is read for it (only when the transcript changed). */
const BACKGROUND_BYTES = 8 * 1024 * 1024;

const IGNORED = new Set(['attachment', 'queue-operation', 'api-request', 'api-request-blob', 'last-prompt', 'ai-title', 'summary', 'mode', 'permission-mode', 'pr-link', 'file-history-snapshot', 'custom-title', 'atis-latch', 'tag']);

const textOf = (c: unknown): string =>
  typeof c === 'string' ? c : Array.isArray(c) ? c.map((b) => (b && typeof b === 'object' && 'text' in b ? String((b as { text: unknown }).text) : '')).join('') : '';

/**
 * From the last lines of a transcript (JSONL): true = the last turn ended, false = a turn is under way, null = cannot tell (no
 * conversation lines at all).
 */
export function lastTurnEnded(lines: string[]): boolean | null {
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    let d: { type?: string; subtype?: string; isMeta?: boolean; isSidechain?: boolean; message?: { content?: unknown } };
    try {
      d = JSON.parse(line);
    } catch {
      continue; // the cut first line of the tail, or a line being written
    }
    if (!d || typeof d !== 'object' || d.isSidechain) continue;
    const type = d.type ?? '';
    if (type === 'system') {
      if (d.subtype === 'turn_duration') return true;
      continue; // stop_hook_summary, api errors (retried), compaction notes: not a turn boundary by themselves
    }
    if (type === 'user') {
      if (d.isMeta) continue;
      if (/^\[Request interrupted by user/.test(textOf(d.message?.content).trim())) return true;
      return false;
    }
    if (type === 'assistant') return false;
    if (IGNORED.has(type)) continue;
  }
  return null;
}

/** The last bytes of a file, split into lines (the first one may be cut). */
function tailLines(file: string, bytes = TAIL_BYTES): string[] {
  const size = statSync(file).size;
  const len = Math.min(size, bytes);
  const buf = Buffer.alloc(len);
  const fd = openSync(file, 'r');
  try {
    readSync(fd, buf, 0, len, size - len);
  } finally {
    closeSync(fd);
  }
  return buf.toString('utf8').split('\n');
}

/** Claude Code's folder name for a project: every character that is not a letter or digit becomes '-'. */
export const projectDirName = (cwd: string) => cwd.replace(/[^a-zA-Z0-9]/g, '-');

/** Finds and reads terminal transcripts, re-reading one only when it changed. */
export class TurnState {
  private cache = new Map<string, { file: string; mtimeMs: number; size: number; ended: boolean | null }>();
  private bgCache = new Map<string, { file: string; mtimeMs: number; size: number; scan: BackgroundScan }>();

  constructor(private projectsDir: string = join(claudeSessionsDir(), '..', 'projects')) {}

  /** True only when the transcript shows the last turn finished; false when busy or unknown (then the process record decides). */
  ended(sessionId: string, cwd: string | undefined): boolean {
    const file = this.find(sessionId, cwd);
    if (!file) return false;
    try {
      const st = statSync(file);
      const hit = this.cache.get(sessionId);
      if (hit && hit.file === file && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit.ended === true;
      const ended = lastTurnEnded(tailLines(file));
      this.cache.set(sessionId, { file, mtimeMs: st.mtimeMs, size: st.size, ended });
      return ended === true;
    } catch {
      return false;
    }
  }

  /**
   * Work the chat left running (background helpers and commands, a scheduled wake-up), from the end of its transcript; null when
   * there is no transcript. Re-read only when the transcript changed.
   */
  background(sessionId: string, cwd: string | undefined): BackgroundScan | null {
    const file = this.find(sessionId, cwd);
    if (!file) return null;
    try {
      const st = statSync(file);
      const hit = this.bgCache.get(sessionId);
      if (hit && hit.file === file && hit.mtimeMs === st.mtimeMs && hit.size === st.size) return hit.scan;
      const scan = { ...scanBackground(tailLines(file, BACKGROUND_BYTES)), seenAt: st.mtimeMs };
      this.bgCache.set(sessionId, { file, mtimeMs: st.mtimeMs, size: st.size, scan });
      return scan;
    } catch {
      return null;
    }
  }

  /** The transcript's last lines and when it last changed (AUTORESUME, terminalResume.ts), or null when there is none. */
  tail(sessionId: string, cwd: string | undefined, bytes = 64 * 1024): { lines: string[]; mtimeMs: number } | null {
    const file = this.find(sessionId, cwd);
    if (!file) return null;
    try {
      const { mtimeMs } = statSync(file);
      return { lines: tailLines(file, bytes), mtimeMs };
    } catch {
      return null;
    }
  }

  forget(sessionId: string): void {
    this.cache.delete(sessionId);
    this.bgCache.delete(sessionId);
  }

  private find(sessionId: string, cwd: string | undefined): string | null {
    if (!/^[0-9A-Za-z_-]{1,80}$/.test(sessionId)) return null;
    const known = this.cache.get(sessionId)?.file ?? this.bgCache.get(sessionId)?.file;
    if (known && existsSync(known)) return known;
    const name = `${sessionId}.jsonl`;
    if (cwd) {
      const direct = join(this.projectsDir, projectDirName(cwd), name);
      if (existsSync(direct)) return direct;
    }
    // Long or unusual paths get another folder name: look in each project folder once.
    try {
      for (const dir of readdirSync(this.projectsDir)) {
        const f = join(this.projectsDir, dir, name);
        if (existsSync(f)) return f;
      }
    } catch {
      // no projects folder
    }
    return null;
  }
}
