import { execFile } from 'node:child_process';
import { isAbsolute, resolve as resolvePath } from 'node:path';
import { normalizeCommand } from '@remote-harness/shared/autonomy';
import { pushWords, scanText, type Finding } from './secretScan.js';

/**
 * F2: no key leaves this computer in a push the agent's AI makes (or in the words of a pull request or comment it writes with gh).
 *
 * Before a shell command runs in a chat (the PreToolUse hook in sessionManager.ts for Claude, cliGuard.ts's hook for ChatGPT and
 * Gemini chats that are checked), each `git push` in it is looked at: the commits it would send (those of the pushed branches, or
 * HEAD, that no remote-tracking branch has yet: `--not --remotes`, at most MAX_COMMITS) are read as a patch, and the lines they ADD
 * are scanned with secretScan.ts (deleted files, binary files and *.example / *.sample files are not). A push that adds a key is
 * refused with where each key is (file and line) and what kind, the key masked. `gh pr create|edit|comment` and `gh issue
 * create|edit|comment` are refused when their own words on the command line hold a key.
 *
 * A scan that cannot run (not a repository, git missing, an unknown branch, a timeout) never blocks: no refusal on no evidence.
 * The agent itself pushes nothing (its own code has no git push); `checkOutgoing` is the one helper any such path must use.
 * Default ON (safety only); SECRET_PUSH_SCAN=0 turns it off.
 */

export const MAX_COMMITS = 200;
const MAX_PATCH_BYTES = 16 * 1024 * 1024;
const GIT_TIMEOUT_MS = 20_000;
const MAX_CHECKED_CHARS = 100_000;

export function pushScanOn(env: NodeJS.ProcessEnv = process.env): boolean {
  return !['0', 'false', 'off', 'no'].includes(String(env.SECRET_PUSH_SCAN ?? '1').trim().toLowerCase());
}

/** Runs git with `args` in `cwd`; `out` is what it printed (even when cut short at the size limit), `ok` false when it failed. */
export type GitRun = (args: string[], cwd: string) => Promise<{ ok: boolean; out: string }>;

/** A GitRun for `env`, optionally run as another user (chatUser.ts asUser, which changes to the folder itself). */
export function gitRunner(env: NodeJS.ProcessEnv, wrap?: (command: string, args: string[], cwd: string) => { command: string; args: string[] }): GitRun {
  return (args, cwd) =>
    new Promise((done) => {
      const line = wrap ? wrap('git', args, cwd) : { command: 'git', args };
      execFile(
        line.command,
        line.args,
        { cwd: wrap ? '/' : cwd, timeout: GIT_TIMEOUT_MS, maxBuffer: MAX_PATCH_BYTES, env: { ...env, GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0' } },
        (err, stdout) => {
          const out = String(stdout ?? '');
          // Cut short at the size limit: what was read is still scanned (a huge push is not waved through unread).
          const capped = (err as { code?: unknown } | null)?.code === 'ERR_CHILD_PROCESS_STDIO_MAXBUFFER';
          done({ ok: !err || capped, out });
        },
      );
    });
}

export interface PushCall {
  /** The folder git runs in (`git -C`, a `cd` before it), relative to the command's own folder; null = that folder. */
  dir: string | null;
  remote: string | null;
  /** What is pushed: refs or commits (`HEAD` when the command names none); `--branches` for --all / --mirror. */
  sources: string[];
}

const SEGMENT = /&&|\|\||[;|\n&]/;
const WRAPPERS = new Set(['sudo', 'exec', 'env', 'nohup', 'time', 'nice', 'command', 'builtin', 'timeout', 'stdbuf']);
/** git push options that take the next word as their value. */
const PUSH_VALUE_OPTS = new Set(['-o', '--push-option', '--repo', '--receive-pack', '--exec']);

/** A redirection word (`2>`, `>/dev/null`, `&>log`, `<in`): never a branch name. Its target follows when it stands alone. */
const REDIRECT = /^(?:\d*|&)(?:>>?|<|>&|<&)(.*)$/;

function words(segment: string): string[] {
  const raw = segment.trim().split(/ +/).filter(Boolean).map((w) => w.replace(/^["']|["']$/g, ''));
  const out: string[] = [];
  for (let i = 0; i < raw.length; i++) {
    const r = REDIRECT.exec(raw[i]);
    if (!r) {
      out.push(raw[i]);
      continue;
    }
    if (r[1] === '' && i + 1 < raw.length) i++; // `> file`: the file is not a word of the command either
  }
  return out;
}

/** Each `git push` in a command line, with where it runs and what it sends. */
export function pushesIn(command: string): PushCall[] {
  const text = normalizeCommand(command.slice(0, MAX_CHECKED_CHARS));
  if (!/\bpush\b/.test(text)) return [];
  const out: PushCall[] = [];
  let dir: string | null = null;
  for (const segment of text.split(SEGMENT)) {
    const w = words(segment);
    let i = 0;
    while (i < w.length && (/^[A-Za-z_][A-Za-z0-9_]*=/.test(w[i]) || WRAPPERS.has(w[i].replace(/^.*\//, '')) || /^-/.test(w[i]) && i > 0 && WRAPPERS.has(w[i - 1]))) i++;
    if (w[i] === 'cd' && w[i + 1]) {
      dir = dir && !isAbsolute(w[i + 1]) ? `${dir}/${w[i + 1]}` : w[i + 1];
      continue;
    }
    if (w[i]?.replace(/^.*\//, '') !== 'git') continue;
    let gitDir = dir;
    i++;
    while (i < w.length && w[i].startsWith('-')) {
      if (w[i] === '-C' && w[i + 1]) {
        gitDir = gitDir && !isAbsolute(w[i + 1]) ? `${gitDir}/${w[i + 1]}` : w[i + 1];
        i += 2;
      } else if (w[i] === '-c') i += 2;
      else i++;
    }
    if (w[i] !== 'push') continue;
    const positional: string[] = [];
    let all = false;
    let tags = false;
    let deletes = false;
    for (let j = i + 1; j < w.length; j++) {
      const a = w[j];
      if (PUSH_VALUE_OPTS.has(a)) {
        j++;
        continue;
      }
      if (a === '--all' || a === '--mirror' || a === '--branches') all = true;
      if (a === '--tags') tags = true;
      if (a === '--delete' || a === '-d') deletes = true;
      if (a.startsWith('-')) continue;
      positional.push(a);
    }
    if (deletes) continue; // deleting a branch on the remote sends no content
    const [remote, ...specs] = positional;
    const named = specs.map((s) => s.replace(/^\+/, '').split(':')[0]).filter((s) => s !== '' && !s.startsWith('refs/tags/'));
    const sources = all ? ['--branches'] : named.length ? named : specs.length || tags ? (tags ? ['--tags'] : []) : ['HEAD'];
    if (tags && !all && named.length) sources.push('--tags');
    if (sources.length) out.push({ dir: gitDir, remote: remote ?? null, sources });
  }
  return out;
}

/** The words of a gh pull request / issue / comment written on the command line: each such segment, or none. */
export function ghWordsIn(command: string): string[] {
  const text = normalizeCommand(command.slice(0, MAX_CHECKED_CHARS));
  if (!/\bgh\b/.test(text)) return [];
  const out: string[] = [];
  for (const segment of command.split(/&&|\|\||[;\n]/)) {
    const w = words(normalizeCommand(segment));
    let i = 0;
    while (i < w.length && (/^[A-Za-z_][A-Za-z0-9_]*=/.test(w[i]) || WRAPPERS.has(w[i]))) i++;
    if (w[i] !== 'gh') continue;
    if (['pr', 'issue'].includes(w[i + 1]) && ['create', 'edit', 'comment', 'review'].includes(w[i + 2])) {
      // Only what follows the subcommand: a token in the command's own environment (GH_TOKEN=...) is not written anywhere.
      out.push(w.slice(i + 3).join(' '));
    }
  }
  return out;
}

export interface OutgoingResult {
  findings: Finding[];
  /** Why the scan could not run (it then blocks nothing). */
  error?: string;
}

/** The added lines of a `git log -p --unified=0` patch, per file: [path, text, line numbers of the text's lines]. */
export function addedLines(patch: string): Array<{ path: string; text: string; lines: number[]; commit: string }> {
  const files = new Map<string, { path: string; parts: string[]; lines: number[]; commit: string }>();
  let current: { path: string; parts: string[]; lines: number[]; commit: string } | null = null;
  let next = 0;
  let commit = '';
  let header = false;
  for (const raw of patch.split('\n')) {
    if (raw.startsWith('\u0000commit ')) {
      commit = raw.slice(8);
      current = null;
      continue;
    }
    if (raw.startsWith('diff --git ')) {
      current = null;
      header = true;
      continue;
    }
    // A file's `+++` line comes only in the header after `diff --git` (an added line that itself starts with "++ " is content).
    if (header && raw.startsWith('+++ ')) {
      header = false;
      const target = raw.slice(4);
      if (target === '/dev/null') {
        current = null;
        continue;
      }
      const path = target.replace(/^b\//, '').replace(/^"b\//, '').replace(/"$/, '');
      const key = `${commit}\u0000${path}`;
      current = files.get(key) ?? { path, parts: [], lines: [], commit };
      files.set(key, current);
      continue;
    }
    if (header && raw.startsWith('--- ')) continue;
    const hunk = /^@@ -\d+(?:,\d+)? \+(\d+)(?:,\d+)? @@/.exec(raw);
    if (hunk) {
      header = false;
      next = Number(hunk[1]);
      continue;
    }
    if (!current) continue;
    if (raw.startsWith('+')) {
      current.parts.push(raw.slice(1));
      current.lines.push(next);
      next++;
    }
  }
  return [...files.values()].filter((f) => f.parts.length).map((f) => ({ path: f.path, text: f.parts.join('\n'), lines: f.lines, commit: f.commit }));
}

/**
 * The keys `sources` (refs, commits or `--branches`) would add to a remote: the commits no remote-tracking branch has yet, at most
 * MAX_COMMITS, newest first. Each key once per file (the first commit that adds it). Never throws.
 */
export async function checkOutgoing(repoDir: string, sources: string[], run: GitRun): Promise<OutgoingResult> {
  try {
    const refs = sources.length ? sources : ['HEAD'];
    const got = await run(
      ['log', '-p', '--unified=0', '--no-color', '--no-ext-diff', '--no-textconv', '--diff-filter=d', `--max-count=${MAX_COMMITS}`,
        '--format=%x00commit %H', ...refs, '--not', '--remotes', '--'],
      repoDir,
    );
    if (!got.ok) return { findings: [], error: 'git could not list the commits being pushed' };
    const findings: Finding[] = [];
    const seen = new Set<string>();
    for (const file of addedLines(got.out)) {
      for (const f of scanText(file.text, file.path)) {
        const line = file.lines[f.line - 1] ?? f.line;
        const key = `${file.path}\u0000${f.value}`;
        if (seen.has(key)) continue;
        seen.add(key);
        findings.push({ ...f, line, commit: file.commit });
      }
    }
    return { findings: findings.filter((f) => f.blocksPush) };
  } catch (err) {
    return { findings: [], error: err instanceof Error ? err.message : String(err) };
  }
}

export interface PushScanVerdict {
  /** The words the AI is refused with, or null to let the command run. */
  why: string | null;
  findings: Finding[];
  /** Where each finding was, in words for a leak report: "<place>: <detail>" (the backend tells once per key and place), e.g.
   * "a push from laptop to origin branch fix-1: src/x.ts line 3". */
  where: (f: Finding, machine?: string) => string;
}

/**
 * The check for one tool call that runs a command (Bash and the other shell tools: any `command` / `cmd` / `script` string).
 * Never throws; a scan that cannot run lets the command through.
 */
export async function pushScanVerdict(input: unknown, o: { cwd: string; run: GitRun; env?: NodeJS.ProcessEnv; log?: (line: string) => void }): Promise<PushScanVerdict> {
  const none: PushScanVerdict = { why: null, findings: [], where: () => '' };
  if (!pushScanOn(o.env ?? process.env)) return none;
  const fields = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  const raw = fields.command ?? fields.cmd ?? fields.script;
  const command = Array.isArray(raw) ? raw.map(String).join(' ') : typeof raw === 'string' ? raw : '';
  if (!command) return none;
  try {
    for (const words of ghWordsIn(command)) {
      const found = scanText(words).filter((f) => f.blocksPush);
      if (found.length) {
        return { why: pushWords(found, 'pull request or comment'), findings: found, where: (_f, machine) => `a pull request or comment written${machine ? ` on ${machine}` : ''}` };
      }
    }
    const home = (o.env ?? process.env).HOME;
    for (const p of pushesIn(command)) {
      const asked = p.dir && home ? p.dir.replace(/^(?:~|\$HOME|\$\{HOME\})(?=\/|$)/, home) : p.dir;
      const dir = asked ? resolvePath(o.cwd, asked) : o.cwd;
      let r = await checkOutgoing(dir, p.sources, o.run);
      // A name git does not know (a word the parser could not tell from a branch): what is checked out is what goes.
      if (r.error && !(p.sources.length === 1 && p.sources[0] === 'HEAD')) r = await checkOutgoing(dir, ['HEAD'], o.run);
      if (r.error) o.log?.(`[push scan] skipped: ${r.error}`);
      if (r.findings.length) {
        const to = `${p.remote ? ` to ${p.remote}` : ''}${p.sources.length === 1 && !p.sources[0].startsWith('--') ? ` branch ${p.sources[0]}` : ''}`;
        return {
          why: pushWords(r.findings),
          findings: r.findings,
          where: (f, machine) => `a push${machine ? ` from ${machine}` : ''}${to}: ${f.path} line ${f.line}`,
        };
      }
    }
  } catch (err) {
    o.log?.(`[push scan] skipped: ${err instanceof Error ? err.message : String(err)}`);
  }
  return none;
}
