import type { AgentBackgroundWork, AgentSessionActivity, AgentTaskInfo, AgentToHubMessage } from '@remote-harness/shared';
import { BACKGROUND_STALE_MS, backgroundFresh, backgroundLine, WAKE_GRACE_MS, wakeCounts, WakeWatch } from './background.js';
import { oneLine } from './redact.js';

/** At most one session_activity per chat this often; the latest state always goes out once the gap has passed. */
export const ACTIVITY_MIN_GAP_MS = 2_000;
const MAX_STEP = 120;
const MAX_TASKS = 20;

const shortPath = (p: unknown): string => {
  const parts = String(p ?? '').split(/[\\/]+/).filter(Boolean);
  return parts.slice(-2).join('/') || '?';
};
const hostOf = (u: unknown): string => {
  try {
    return new URL(String(u)).host;
  } catch {
    return '?';
  }
};

/** A tool call in a few plain words, one line, no secrets: "Running: npm test", "Editing: src/x.ts". */
export function describeTool(name: string, input: unknown): string {
  const i = (input ?? {}) as Record<string, unknown>;
  const s = (() => {
    switch (name) {
      case 'Bash':
        return `Running: ${String(i.command ?? '').split('\n')[0]}`;
      case 'BashOutput':
        return 'Checking a running command';
      case 'Edit':
      case 'MultiEdit':
      case 'Write':
      case 'NotebookEdit':
        return `Editing: ${shortPath(i.file_path ?? i.notebook_path)}`;
      case 'Read':
        return `Reading: ${shortPath(i.file_path)}`;
      case 'Grep':
      case 'Glob':
        return `Searching: ${String(i.pattern ?? '')}`;
      case 'WebFetch':
        return `Fetching: ${hostOf(i.url)}`;
      case 'WebSearch':
        return `Searching the web: ${String(i.query ?? '')}`;
      case 'Task':
      case 'Agent':
        return `Subagent: ${String(i.description ?? i.subagent_type ?? 'working')}`;
      case 'TodoWrite':
        return 'Planning';
      case 'AskUserQuestion':
        return 'Asking you a question';
      default: {
        const mcp = /^mcp__([^_]+(?:_[^_]+)*?)__(.+)$/.exec(name);
        if (mcp) return `Using ${mcp[1]}: ${typeof i.tool_id === 'string' ? i.tool_id : mcp[2]}`;
        return `Using ${name}`;
      }
    }
  })();
  return oneLine(s, MAX_STEP);
}

/** The step shown while a prompt waits: the command itself for a shell command, else what the tool would do. */
function waitingStep(toolName: string, input: unknown): string {
  if (toolName === 'AskUserQuestion') return 'Waiting for your answer';
  const what = toolName === 'Bash' ? String(((input ?? {}) as { command?: unknown }).command ?? '').split('\n')[0] : describeTool(toolName, input);
  return oneLine(`Waiting for your OK: ${toolName === 'Bash' ? what : what.charAt(0).toLowerCase() + what.slice(1)}`, MAX_STEP);
}

type ChatState = {
  running: boolean;
  step: string | null;
  /** requestId -> the step to show while it waits. */
  waiting: Map<string, string>;
  tasks: Map<string, string>;
  /** Work left running after the turn (background helpers and commands; a scheduled wake-up, ms): the chat is not idle. */
  helpers: number;
  commands: number;
  wakeAt: number | null;
  wake: WakeWatch | null;
  wakeTimer: unknown;
  /** When the chat was last heard from (helpers and commands stop counting once it has been quiet BACKGROUND_STALE_MS). */
  heardAt: number;
  staleTimer: unknown;
  lastSent: string | null;
  lastAt: number;
  timer: unknown;
};

type BackgroundMessage = {
  tasks?: Array<{ task_type?: string; subagent_type?: string; ambient?: boolean } | null>;
  wake_at?: string;
  turn_over?: boolean;
};

type Timers = { now?: () => number; setTimer?: (fn: () => void, ms: number) => unknown; clearTimer?: (t: unknown) => void; minGapMs?: number };

/**
 * DEV5: what each chat is doing right now, worked out from the messages this agent sends anyway (its own chats and the terminal
 * chats it syncs), and sent to the hub as `session_activity`: on change, at most one every 2 s per chat, the latest state last.
 */
export class ActivityReporter {
  private chats = new Map<string, ChatState>();
  private now: () => number;
  private setTimer: (fn: () => void, ms: number) => unknown;
  private clearTimer: (t: unknown) => void;
  private minGap: number;

  constructor(
    private send: (msg: AgentSessionActivity) => void,
    t: Timers = {},
  ) {
    this.now = t.now ?? Date.now;
    this.setTimer =
      t.setTimer ??
      ((fn, ms) => {
        const h = setTimeout(fn, ms);
        h.unref?.();
        return h;
      });
    this.clearTimer = t.clearTimer ?? ((h) => clearTimeout(h as NodeJS.Timeout));
    this.minGap = t.minGapMs ?? ACTIVITY_MIN_GAP_MS;
  }

  private chat(id: string): ChatState {
    let c = this.chats.get(id);
    if (!c) {
      c = { running: false, step: null, waiting: new Map(), tasks: new Map(), helpers: 0, commands: 0, wakeAt: null, wake: null, wakeTimer: null, heardAt: this.now(), staleTimer: null, lastSent: null, lastAt: -Infinity, timer: null };
      this.chats.set(id, c);
    }
    return c;
  }

  /** Every message the agent sends to the hub passes through here (index.ts). */
  observe(msg: AgentToHubMessage): void {
    switch (msg.type) {
      case 'input_ack':
        if (msg.status !== 'delivered') return;
        this.change(msg.sessionId, (c) => {
          if (!c.running) c.step = 'Starting';
          c.running = true;
        });
        return;
      case 'sdk_message':
        this.onSdk(msg.sessionId, msg.message);
        return;
      case 'permission_request':
        this.change(msg.sessionId, (c) => {
          c.running = true;
          c.waiting.set(msg.requestId, waitingStep(msg.toolName, msg.input));
        });
        return;
      case 'permission_ack': {
        const id = msg.sessionId ?? [...this.chats.entries()].find(([, c]) => c.waiting.has(msg.requestId))?.[0];
        if (id) this.change(id, (c) => void c.waiting.delete(msg.requestId));
        return;
      }
      case 'session_created': {
        if (msg.tempId === msg.sessionId) return;
        const c = this.chats.get(msg.tempId);
        if (!c) return;
        this.chats.delete(msg.tempId);
        if (c.timer) this.clearTimer(c.timer);
        c.timer = null;
        c.lastSent = null; // the hub has not heard of this chat under its real id yet
        c.lastAt = -Infinity;
        this.chats.set(msg.sessionId, c);
        this.flush(msg.sessionId);
        return;
      }
      case 'session_ended':
        this.idle(msg.sessionId);
        return;
      case 'error':
        if (msg.kind === 'notice') return;
        if (msg.sessionId ?? msg.tempId) this.idle((msg.sessionId ?? msg.tempId)!);
        return;
    }
  }

  private onSdk(sessionId: string, message: unknown): void {
    const m = (message ?? {}) as { type?: string; subtype?: string; parent_tool_use_id?: string | null; message?: { content?: unknown } };
    // The turn is over; what it left running in the background goes on (Claude Code starts a new turn when it finishes).
    const known = this.chats.get(sessionId);
    if (known) known.heardAt = this.now();
    if (m.type === 'result') return this.turnOver(sessionId);
    if (m.type === 'system' && m.subtype === 'background_tasks_changed') return this.onBackground(sessionId, message as BackgroundMessage);
    const content = Array.isArray(m.message?.content) ? (m.message!.content as Array<Record<string, unknown>>) : [];
    // A wake-up the chat schedules (ScheduleWakeup): it is working in the background until then.
    if ((m.type === 'assistant' || m.type === 'user') && !m.parent_tool_use_id) {
      const c = this.chat(sessionId);
      if ((c.wake ??= new WakeWatch(this.now)).feed(message)) this.setWake(sessionId, c, c.wake.wakeAt);
    }
    if (m.type === 'assistant') {
      this.change(sessionId, (c) => {
        c.running = true;
        for (const b of content) {
          if (b.type === 'tool_use') {
            const name = String(b.name ?? '');
            // A subagent's own tool calls are its business: the chat's step stays on the subagent.
            if (!m.parent_tool_use_id) c.step = describeTool(name, b.input);
            if ((name === 'Task' || name === 'Agent') && typeof b.id === 'string' && c.tasks.size < MAX_TASKS) {
              c.tasks.set(b.id, oneLine(String((b.input as { description?: unknown })?.description ?? name), 80));
            }
          } else if (!m.parent_tool_use_id && b.type === 'text' && !content.some((x) => x.type === 'tool_use')) {
            c.step = 'Writing a reply';
          } else if (!m.parent_tool_use_id && b.type === 'thinking' && content.length === 1) {
            c.step = 'Thinking';
          }
        }
      });
      return;
    }
    if (m.type === 'user') {
      const done = content.filter((b) => b.type === 'tool_result' && typeof b.tool_use_id === 'string').map((b) => b.tool_use_id as string);
      if (done.some((id) => this.chats.get(sessionId)?.tasks.has(id))) this.change(sessionId, (c) => done.forEach((id) => c.tasks.delete(id)));
      return;
    }
    if (m.type === 'system' && m.subtype === 'init') this.change(sessionId, (c) => {
      if (!c.running) c.step = 'Starting';
      c.running = true;
    });
  }

  /**
   * The full set of what runs in the background (Claude Code's background_tasks_changed; the terminal sync writes the same for a
   * chat in a terminal, with `wake_at` for a scheduled wake-up and `turn_over` once its turn has ended).
   */
  private onBackground(sessionId: string, m: BackgroundMessage): void {
    const live = (Array.isArray(m.tasks) ? m.tasks : []).filter((t) => t && !t.ambient);
    const helpers = live.filter((t) => t!.task_type === 'local_agent' || Boolean(t!.subagent_type)).length;
    const commands = live.length - helpers;
    const wake = typeof m.wake_at === 'string' && m.wake_at ? Date.parse(m.wake_at) : NaN;
    if (!helpers && !commands && !Number.isFinite(wake) && !this.chats.has(sessionId)) return;
    const c = this.chat(sessionId);
    if (Number.isFinite(wake)) this.setWake(sessionId, c, wake);
    this.change(sessionId, (c) => {
      c.helpers = helpers;
      c.commands = commands;
      if (m.turn_over === true) this.endTurnState(c);
    });
    this.armStale(sessionId, c);
  }

  /** Shown again once its helpers and commands would go stale (nothing heard from the chat for BACKGROUND_STALE_MS). */
  private armStale(sessionId: string, c: ChatState): void {
    if (c.staleTimer) this.clearTimer(c.staleTimer);
    c.staleTimer = null;
    if (!c.helpers && !c.commands) return;
    c.staleTimer = this.setTimer(() => {
      c.staleTimer = null;
      if (this.chats.get(sessionId) !== c) return;
      if (backgroundFresh(c.heardAt, this.now())) return this.armStale(sessionId, c);
      this.flush(sessionId);
    }, Math.max(0, c.heardAt + BACKGROUND_STALE_MS - this.now()) + 1);
  }

  /** The chat wakes itself at `at`: shown until then, and looked at again once it has passed. */
  private setWake(sessionId: string, c: ChatState, at: number | null): void {
    c.wakeAt = at;
    if (c.wakeTimer) this.clearTimer(c.wakeTimer);
    c.wakeTimer = null;
    if (at === null) return;
    const left = at + WAKE_GRACE_MS - this.now();
    if (wakeCounts(at, this.now())) c.wakeTimer = this.setTimer(() => {
      c.wakeTimer = null;
      if (this.chats.get(sessionId) === c) this.flush(sessionId);
    }, left + 1);
  }

  private backgroundOf(c: ChatState): AgentBackgroundWork | null {
    const wake = wakeCounts(c.wakeAt, this.now()) ? c.wakeAt : null;
    const fresh = backgroundFresh(c.heardAt, this.now());
    const helpers = fresh ? c.helpers : 0;
    const commands = fresh ? c.commands : 0;
    if (!helpers && !commands && wake === null) return null;
    return { helpers, commands, ...(wake !== null ? { wakeAt: new Date(wake).toISOString() } : {}) };
  }

  private turnOver(sessionId: string): void {
    if (!this.chats.has(sessionId)) return;
    this.change(sessionId, (c) => this.endTurnState(c));
  }

  private endTurnState(c: ChatState): void {
    c.running = false;
    c.step = null;
    c.waiting.clear();
    c.tasks.clear();
  }

  private idle(sessionId: string): void {
    if (!this.chats.has(sessionId)) return; // never heard of as working: nothing to correct
    this.change(sessionId, (c) => {
      c.running = false;
      c.step = null;
      c.waiting.clear();
      c.tasks.clear();
      c.helpers = c.commands = 0;
      this.setWake(sessionId, c, null);
      if (c.staleTimer) this.clearTimer(c.staleTimer);
      c.staleTimer = null;
    });
  }

  private payload(sessionId: string, c: ChatState): AgentSessionActivity {
    const waiting = c.waiting.size > 0;
    const background = this.backgroundOf(c);
    const active = c.running || waiting || background !== null;
    const tasks: AgentTaskInfo[] = [...c.tasks].map(([id, description]) => ({ id, description }));
    const step = waiting ? [...c.waiting.values()].at(-1)! : c.running ? c.step : background ? backgroundLine(background) : null;
    return {
      type: 'session_activity',
      sessionId,
      activity: active ? 'running' : 'idle',
      waiting,
      tasks: active ? tasks : [],
      step,
      ...(background ? { background } : {}),
    };
  }

  private change(sessionId: string, f: (c: ChatState) => void): void {
    const c = this.chat(sessionId);
    f(c);
    this.flush(sessionId);
  }

  private flush(sessionId: string): void {
    const c = this.chats.get(sessionId);
    if (!c) return;
    const p = this.payload(sessionId, c);
    const key = JSON.stringify(p);
    if (key === c.lastSent) {
      if (c.timer) this.clearTimer(c.timer);
      c.timer = null;
      return;
    }
    const wait = c.lastAt + this.minGap - this.now();
    if (wait > 0) {
      if (!c.timer) c.timer = this.setTimer(() => {
        c.timer = null;
        this.flush(sessionId);
      }, wait);
      return;
    }
    c.lastSent = key;
    c.lastAt = this.now();
    this.send(p);
    // An idle chat with nothing left to send is forgotten (it comes back the moment it works again).
    if (p.activity === 'idle' && !c.timer) this.chats.delete(sessionId);
  }

  /** Chats doing something right now, with their step (machine_state). */
  snapshot(): Array<{ sessionId: string; waiting: boolean; step: string | null }> {
    const out: Array<{ sessionId: string; waiting: boolean; step: string | null }> = [];
    for (const [sessionId, c] of this.chats) {
      const p = this.payload(sessionId, c);
      if (p.activity === 'running') out.push({ sessionId, waiting: p.waiting, step: p.step });
    }
    return out;
  }

  /** The hub reconnected: it gets every running chat's state again (the hub forgets nothing else it needs). */
  resendAll(): void {
    for (const [sessionId, c] of this.chats) {
      c.lastSent = null;
      c.lastAt = -Infinity;
      if (c.timer) this.clearTimer(c.timer);
      c.timer = null;
      this.flush(sessionId);
    }
  }
}
