import { existsSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { homedir, platform } from 'node:os';
import { dirname, join } from 'node:path';
import { blockedForGoodMessage, decide, type SafetyCtx, type Verdict } from '../../shared/src/safety.ts';
import { MAX_SCRIPT_BYTES, SCRIPT_TOO_BIG } from '../../shared/src/scriptRisk.ts';
import { removesGuard } from './machineGuard.ts';
import { logSafety } from './safetyLog.ts';
import { expandGlob, UndoStore } from './undo.ts';

/**
 * One tool call through the safety layer (shared/safety.ts), with the copy made: the part shared by the agent's own chats
 * (sessionManager PreToolUse) and the machine-wide hook (safetyHook.ts) that guards every other Claude on this computer.
 *
 *   run   let it run (nothing risky, or a copy was kept first: `undoId`)
 *   deny  never (a block): `message` is what the AI is told
 *   hold  what no copy can undo, or a copy could not be made: the person decides (`why`)
 */
export type GateResult =
  | { kind: 'run'; undoId?: string; note?: string }
  | { kind: 'deny'; message: string }
  | { kind: 'hold'; why: string; verdict: Verdict & { action: 'hold' | 'backup' } };

/** The project a folder belongs to: the nearest folder above it (or itself) that has a .git; never the home folder or a drive root. */
export function projectRootOf(cwd: string, home: string): string {
  let dir = cwd;
  for (let i = 0; i < 40; i++) {
    if (dir === home || dirname(dir) === dir) break;
    try {
      if (existsSync(join(dir, '.git'))) return dir;
    } catch {
      break;
    }
    dir = dirname(dir);
  }
  return cwd;
}

/** A text file's contents for the script check (safety.ts): small, readable, not binary. */
export function readTextFile(p: string): string | null {
  try {
    const st = statSync(p);
    if (!st.isFile()) return null;
    if (st.size > MAX_SCRIPT_BYTES) return SCRIPT_TOO_BIG; // too big to check: held when it is a clean-up, never waved through
    const t = readFileSync(p, 'utf8');
    return t.includes('\0') ? null : t;
  } catch {
    return null;
  }
}

export function gate(
  toolName: string,
  toolInput: unknown,
  o: { cwd: string; store: UndoStore; source: 'agent' | 'machine'; session?: string; env?: NodeJS.ProcessEnv; protect?: string[] },
): GateResult {
  const cwd = o.cwd || process.cwd();
  const home = o.store.home || homedir();
  const ctx: SafetyCtx = {
    cwd,
    home,
    projectRoot: projectRootOf(cwd, home),
    // ESCANOR_SCRIPT_CHECK=0 turns the reading of scripts off (the rest of the safety layer is unchanged).
    ...(['0', 'false', 'off', 'no'].includes(String((o.env ?? process.env).ESCANOR_SCRIPT_CHECK ?? '1').trim().toLowerCase()) ? {} : { readFile: readTextFile }),
    env: o.env ?? process.env,
    platform: platform(),
    protect: [o.store.root, ...(o.protect ?? [])],
    // What is on disk now: patterns are checked against what they match, links against where they point.
    expand: (p) => expandGlob(p),
    realpath: (p) => {
      try {
        return realpathSync(p);
      } catch {
        return null;
      }
    },
  };
  if (removesGuard(toolName, toolInput)) {
    const why = "It would take Escanor's safety check out of a Claude settings file (or turn every hook off).";
    logSafety(o.store.root, { at: Date.now(), action: 'block', source: o.source, why, cwd: ctx.cwd, session: o.session });
    return { kind: 'deny', message: blockedForGoodMessage(why) };
  }
  const v = decide(toolName, toolInput, ctx);
  if (v.action === 'allow') return { kind: 'run' };
  if (v.action === 'block') {
    logSafety(o.store.root, { at: Date.now(), action: 'block', source: o.source, command: v.command, why: v.why, cwd: ctx.cwd, session: o.session, paths: [v.path] });
    return { kind: 'deny', message: blockedForGoodMessage(v.why) };
  }
  if (v.action === 'hold') return { kind: 'hold', why: v.risk.why, verdict: v };
  const r = o.store.backup(v.plan, { command: v.command, cwd: ctx.cwd, source: o.source, session: o.session });
  if (!r.ok) return { kind: 'hold', why: `${r.why} It deletes or throws away work, so a person should say yes first.`, verdict: v };
  if (!r.entry) return { kind: 'run' };
  logSafety(o.store.root, {
    at: Date.now(), action: 'backup', source: o.source, command: v.command, cwd: ctx.cwd, session: o.session, undoId: r.entry.id,
    paths: [...r.entry.items.map((i) => i.path), ...r.entry.git.map((g) => g.repo)].slice(0, 20),
  });
  return { kind: 'run', undoId: r.entry.id, note: `Escanor kept a copy first (undo ${r.entry.id}); it can be put back from the Escanor app for 7 days.` };
}
