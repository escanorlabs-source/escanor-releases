import { appendFileSync, mkdirSync, readFileSync, renameSync, statSync } from 'node:fs';
import { join } from 'node:path';

/**
 * What the safety layer did, one JSON line each, next to the undo copies (so the apps can show "Escanor kept a copy of src before
 * an AI deleted it" and "Escanor stopped: rm -rf ~"). Written by the agent and by the machine-wide hook alike.
 */
export type SafetyEvent = {
  at: number;
  /** backup: a copy was kept and it ran; block: never allowed; hold: waited for the person / refused; trip: mass deletes stopped; remote: something done (or refused) for the owner's phone by Jarvis. */
  action: 'backup' | 'block' | 'hold' | 'trip' | 'restore' | 'resume' | 'stop' | 'guard' | 'remote';
  source: 'agent' | 'machine' | 'tripwire' | 'app';
  command?: string;
  why?: string;
  cwd?: string;
  session?: string;
  undoId?: string;
  paths?: string[];
};

const MAX_BYTES = 1_000_000;

export const eventsFile = (root: string) => join(root, 'events.jsonl');

export function logSafety(root: string, e: SafetyEvent): void {
  try {
    mkdirSync(root, { recursive: true, mode: 0o700 });
    const file = eventsFile(root);
    try {
      if (statSync(file).size > MAX_BYTES) renameSync(file, `${file}.1`);
    } catch {
      /* first line */
    }
    appendFileSync(file, `${JSON.stringify({ ...e, command: e.command?.slice(0, 500) })}\n`, { mode: 0o600 });
  } catch {
    /* the log never stops the work */
  }
}

/** Newest first. */
export function readSafetyEvents(root: string, limit = 100): SafetyEvent[] {
  const out: SafetyEvent[] = [];
  for (const f of [eventsFile(root), `${eventsFile(root)}.1`]) {
    let text = '';
    try {
      text = readFileSync(f, 'utf8');
    } catch {
      continue;
    }
    for (const line of text.split('\n')) {
      if (!line.trim()) continue;
      try {
        out.push(JSON.parse(line) as SafetyEvent);
      } catch {
        /* a torn line */
      }
    }
  }
  return out.sort((a, b) => b.at - a.at).slice(0, limit);
}
