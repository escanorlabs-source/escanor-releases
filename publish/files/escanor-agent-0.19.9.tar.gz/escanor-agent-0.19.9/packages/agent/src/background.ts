import { BACKGROUND_STEP, type AgentBackgroundWork } from '@remote-harness/shared';

/**
 * Work a Claude Code chat left running after its turn ended, read from its transcript (JSONL):
 *   - helpers: subagents started in the background (Agent/Task tool; its result says "Async agent launched ... agentId: X"),
 *   - commands: shell commands started in the background (Bash run_in_background; "Command running in background with ID: X"),
 *   - a scheduled wake-up (ScheduleWakeup; its result carries `scheduledFor`).
 * Each helper or command is done once a `<task-notification>` with its task id and a final status arrives, or once it is stopped
 * with TaskStop / KillShell. Claude Code wakes the chat by itself when one finishes or the wake-up time comes, so a chat with
 * any of these is working in the background, not idle, and a message sent to it must not stop it.
 */

export type BackgroundTask = { id: string; description: string };
/** `seenAt`: when the transcript last changed (ms), if known: helpers and commands stop counting once it has been quiet too long. */
export type BackgroundScan = { helpers: BackgroundTask[]; commands: BackgroundTask[]; wakeAt: number | null; seenAt?: number };

/** A wake-up counts this long after its time (Claude takes a moment to start the turn it wakes up for). */
export const WAKE_GRACE_MS = 2 * 60_000;
/**
 * Helpers and commands keep a chat open (and the machine up) only while the chat has been heard from within this long. A helper
 * that crashed without a notification, or a command that never ends (a dev server started in the background), would otherwise hold
 * one of the few chat slots, and keep the machine awake, for ever.
 */
export const BACKGROUND_STALE_MS = 60 * 60_000;
/** A wake-up further ahead than this is not waited for (Claude Code's own limit is an hour). */
export const MAX_WAKE_AHEAD_MS = 90 * 60_000;

/** Does a wake-up at `wakeAt` keep the chat working at `now`? */
export const wakeCounts = (wakeAt: number | null | undefined, now: number): boolean =>
  wakeAt != null && wakeAt + WAKE_GRACE_MS > now && wakeAt - now <= MAX_WAKE_AHEAD_MS;
/** Do helpers and commands last heard of at `seenAt` still count at `now`? */
export const backgroundFresh = (seenAt: number | undefined, now: number): boolean => seenAt === undefined || now - seenAt < BACKGROUND_STALE_MS;
const FINAL = /^(completed|failed|stopped|killed|cancell?ed|error|timed?_?out)$/i;
const MAX_DESC = 80;

type Block = Record<string, unknown>;
type Line = { type?: string; isSidechain?: boolean; message?: { content?: unknown }; toolUseResult?: Record<string, unknown> };

const textOf = (c: unknown): string =>
  typeof c === 'string' ? c : Array.isArray(c) ? c.map((b) => (b && typeof b === 'object' && 'text' in b ? String((b as { text: unknown }).text) : '')).join('\n') : '';
const short = (s: string) => {
  const one = s.split('\n').map((l) => l.trim()).find(Boolean) ?? '';
  return one.length > MAX_DESC ? `${one.slice(0, MAX_DESC - 1)}…` : one;
};
const tag = (text: string, name: string) => new RegExp(`<${name}>([^<]*)</${name}>`).exec(text)?.[1]?.trim();

/** What is still running or scheduled, from a transcript's lines (oldest first; the first may be cut). */
export function scanBackground(lines: string[]): BackgroundScan {
  const uses = new Map<string, { name: string; input: Block }>();
  const helpers = new Map<string, string>();
  const commands = new Map<string, string>();
  let wakeAt: number | null = null;
  const done = (id: string | undefined) => {
    if (!id) return;
    helpers.delete(id);
    commands.delete(id);
  };

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    let d: Line;
    try {
      d = JSON.parse(line);
    } catch {
      continue;
    }
    if (!d || typeof d !== 'object' || d.isSidechain) continue;
    const content = d.message?.content;
    if (d.type === 'assistant' && Array.isArray(content)) {
      for (const b of content as Block[]) {
        if (b?.type !== 'tool_use' || typeof b.id !== 'string') continue;
        const name = String(b.name ?? '');
        const input = (b.input ?? {}) as Block;
        uses.set(b.id, { name, input });
        // Stopping one by hand: it may get no notification.
        if (name === 'TaskStop' || name === 'KillShell' || name === 'KillBash') done(String(input.task_id ?? input.shell_id ?? input.id ?? '') || undefined);
      }
      continue;
    }
    if (d.type !== 'user') continue;
    // A finished task: Claude Code tells the chat with a <task-notification> message (the person's own words never carry the tags).
    if (!Array.isArray(content) || !(content as Block[]).some((b) => b?.type === 'tool_result')) {
      const text = textOf(content);
      if (text.includes('<task-notification>')) {
        for (const part of text.split('<task-notification>').slice(1)) {
          const status = tag(part, 'status');
          if (!status || FINAL.test(status)) done(tag(part, 'task-id'));
        }
      }
      continue;
    }
    for (const b of content as Block[]) {
      if (b?.type !== 'tool_result' || typeof b.tool_use_id !== 'string') continue;
      const use = uses.get(b.tool_use_id);
      if (!use) continue;
      const text = textOf(b.content);
      const result = d.toolUseResult ?? {};
      if (use.name === 'Agent' || use.name === 'Task') {
        const id = /agentId:\s*([0-9A-Za-z_-]+)/.exec(text)?.[1] ?? (result.isAsync === true && typeof result.agentId === 'string' ? result.agentId : undefined);
        if (id && (result.isAsync === true || /Async agent launched/.test(text))) helpers.set(id, short(String(use.input.description ?? use.input.subagent_type ?? 'Helper')));
      } else if (use.name === 'Bash') {
        const id = (typeof result.backgroundTaskId === 'string' ? result.backgroundTaskId : undefined) ?? /running in background with ID:\s*([0-9A-Za-z_-]+)/.exec(text)?.[1];
        if (id) commands.set(id, short(String(use.input.description || use.input.command || 'Command')));
      } else if (use.name === 'ScheduleWakeup') {
        if (use.input.noop === true) continue;
        const at = Number(result.scheduledFor);
        if (Number.isFinite(at) && at > 0) wakeAt = at;
      }
    }
  }
  return {
    helpers: [...helpers].map(([id, description]) => ({ id, description })),
    commands: [...commands].map(([id, description]) => ({ id, description })),
    wakeAt,
  };
}

/** The scan as of `now`: null when nothing is running and no wake-up is due (the chat is idle). */
export function backgroundAt(scan: BackgroundScan | null, now: number): AgentBackgroundWork | null {
  if (!scan) return null;
  const wake = wakeCounts(scan.wakeAt, now) ? scan.wakeAt : null;
  const fresh = backgroundFresh(scan.seenAt, now);
  const helpers = fresh ? scan.helpers.length : 0;
  const commands = fresh ? scan.commands.length : 0;
  if (!helpers && !commands && wake === null) return null;
  return {
    helpers,
    commands,
    ...(wake !== null ? { wakeAt: new Date(wake).toISOString() } : {}),
  };
}

const hhmm = (iso: string) => {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
};

/** "Working in the background · 3 helpers running · wakes up at 14:05" (the phone shows it under the chat's title). */
export function backgroundLine(b: AgentBackgroundWork, time: (iso: string) => string = hhmm): string {
  const parts: string[] = [];
  const n = (k: number, one: string, many: string) => `${k} ${k === 1 ? one : many}`;
  if (b.helpers && b.commands) parts.push(`${n(b.helpers, 'helper', 'helpers')} and ${n(b.commands, 'command', 'commands')} running`);
  else if (b.helpers) parts.push(`${n(b.helpers, 'helper', 'helpers')} running`);
  else if (b.commands) parts.push(`${n(b.commands, 'command', 'commands')} running`);
  if (b.wakeAt) parts.push(`wakes up at ${time(b.wakeAt)}`);
  return [BACKGROUND_STEP, ...parts].join(' · ');
}

/**
 * Follows ScheduleWakeup in a live stream of SDK messages (a chat the agent runs): the wake-up time once its result arrives.
 * Feed every message; `wakeAt` is the latest scheduled time (ms), or null.
 */
export class WakeWatch {
  private asked = new Map<string, boolean>(); // tool-use id -> noop
  wakeAt: number | null = null;

  constructor(private now: () => number = Date.now) {}

  /** True when the wake-up time changed. */
  feed(message: unknown): boolean {
    const m = (message ?? {}) as { type?: string; message?: { content?: unknown }; tool_use_result?: unknown; toolUseResult?: unknown };
    const content = Array.isArray(m.message?.content) ? (m.message!.content as Array<Record<string, unknown>>) : [];
    if (m.type === 'assistant') {
      for (const b of content) if (b?.type === 'tool_use' && b.name === 'ScheduleWakeup' && typeof b.id === 'string') this.asked.set(b.id, (b.input as { noop?: unknown } | undefined)?.noop === true);
      return false;
    }
    if (m.type !== 'user') return false;
    for (const b of content) {
      if (b?.type !== 'tool_result' || typeof b.tool_use_id !== 'string' || !this.asked.has(b.tool_use_id)) continue;
      const noop = this.asked.get(b.tool_use_id);
      this.asked.delete(b.tool_use_id);
      if (noop) continue;
      const result = (m.tool_use_result ?? m.toolUseResult ?? {}) as { scheduledFor?: unknown };
      let at = Number(result.scheduledFor);
      if (!Number.isFinite(at) || at <= 0) {
        const secs = /\(in (\d+)s\)/.exec(textOf(b.content))?.[1];
        at = secs ? this.now() + Number(secs) * 1000 : NaN;
      }
      if (Number.isFinite(at) && at > 0 && at !== this.wakeAt) {
        this.wakeAt = at;
        return true;
      }
    }
    return false;
  }

  /** A wake-up is still to come (or has just come). */
  pending(now = this.now()): boolean {
    return wakeCounts(this.wakeAt, now);
  }
}
