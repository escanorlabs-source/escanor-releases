import { execFileSync } from 'node:child_process';

/**
 * The voice shortcut on GNOME (Ubuntu, Fedora, Mint's GNOME editions): one custom keyboard shortcut that runs `escanor-agent voice`.
 * Wayland does not let a program grab keys by itself, so the desktop's own settings hold the shortcut; this only adds (or removes)
 * that one entry, never touching the person's other shortcuts, and refuses when the keys are already taken.
 *
 * Press once to talk, press again to send (or stop talking). Other desktops: the text printed by `instructions`.
 */

export const SCHEMA = 'org.gnome.settings-daemon.plugins.media-keys';
export const LIST_KEY = 'custom-keybindings';
export const CHILD_SCHEMA = `${SCHEMA}.custom-keybinding`;
export const ENTRY_PATH = `/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/escanor-voice/`;
export const DEFAULT_BINDING = '<Super><Alt>space';
export const ENTRY_NAME = 'Talk to Escanor';

export type Gsettings = (args: string[]) => string;

/** ['/a/', '/b/'] or @as [] -> the paths. */
export function parseList(out: string): string[] {
  return [...out.matchAll(/'([^']*)'/g)].map((m) => m[1]!);
}

export function formatList(paths: string[]): string {
  return `[${paths.map((p) => `'${p}'`).join(', ')}]`;
}

/** The binding as gsettings prints it: 'x' -> x. */
export function unquote(out: string): string {
  const m = /^\s*'(.*)'\s*$/s.exec(out);
  return m ? m[1]! : out.trim();
}

/** The command GNOME runs through a shell: the path quoted, nothing else. */
export function commandFor(binPath: string): string {
  if (/[\u0000-\u001f]/.test(binPath)) throw new Error('The agent path has control characters.');
  return `'${binPath.replace(/'/g, `'\\''`)}' voice`;
}

/** A string as gsettings reads it (GVariant text): double quoted, with backslash and quote escaped. */
export const gvString = (s: string): string => `"${s.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;

/** A binding in GNOME's own spelling: <Super><Alt>space. */
export function validBinding(b: string): boolean {
  return /^(?:<(?:Super|Control|Primary|Alt|Shift)>){1,4}[A-Za-z0-9_]{1,20}$/.test(b);
}

export type HotkeyResult = { ok: boolean; say: string };

const real: Gsettings = (args) => execFileSync('gsettings', args, { encoding: 'utf8', timeout: 5000, stdio: ['ignore', 'pipe', 'pipe'] });

function gnomeAvailable(gs: Gsettings): boolean {
  try {
    gs(['list-keys', SCHEMA]);
    return true;
  } catch {
    return false;
  }
}


/** The bindings other custom shortcuts use, to refuse a clash. */
function othersUse(gs: Gsettings, list: string[], binding: string): string | null {
  for (const p of list) {
    if (p === ENTRY_PATH) continue;
    try {
      const b = unquote(gs(['get', `${CHILD_SCHEMA}:${p}`, 'binding']));
      if (b.toLowerCase() === binding.toLowerCase()) return unquote(gs(['get', `${CHILD_SCHEMA}:${p}`, 'name']));
    } catch {
      // unreadable entry: not a clash we can name
    }
  }
  return null;
}

export function status(gs: Gsettings = real): HotkeyResult & { installed: boolean; binding?: string } {
  if (!gnomeAvailable(gs)) return { ok: false, installed: false, say: instructions() };
  const list = parseList(gs(['get', SCHEMA, LIST_KEY]));
  if (!list.includes(ENTRY_PATH)) return { ok: true, installed: false, say: 'The voice shortcut is not installed. Run: escanor-agent voice-hotkey install' };
  const binding = unquote(gs(['get', `${CHILD_SCHEMA}:${ENTRY_PATH}`, 'binding']));
  return { ok: true, installed: true, binding, say: `The voice shortcut is installed: ${binding}. Press it to talk, and again to send.` };
}

export function install(binPath: string, binding: string = DEFAULT_BINDING, gs: Gsettings = real): HotkeyResult {
  if (!validBinding(binding)) return { ok: false, say: `"${binding}" is not a shortcut GNOME understands. Write it like <Super><Alt>space.` };
  if (!gnomeAvailable(gs)) return { ok: false, say: instructions() };
  const list = parseList(gs(['get', SCHEMA, LIST_KEY]));
  const taken = othersUse(gs, list, binding);
  if (taken) return { ok: false, say: `${binding} is already used by your shortcut "${taken}". Pick another with: escanor-agent voice-hotkey install '<Super><Alt>e'` };
  const at = `${CHILD_SCHEMA}:${ENTRY_PATH}`;
  gs(['set', at, 'name', gvString(ENTRY_NAME)]);
  gs(['set', at, 'command', gvString(commandFor(binPath))]);
  gs(['set', at, 'binding', gvString(binding)]);
  if (!list.includes(ENTRY_PATH)) gs(['set', SCHEMA, LIST_KEY, formatList([...list, ENTRY_PATH])]);
  return { ok: true, say: `Done. Press ${binding} to talk to Escanor, and press it again to send. Remove it any time with: escanor-agent voice-hotkey uninstall` };
}

export function uninstall(gs: Gsettings = real): HotkeyResult {
  if (!gnomeAvailable(gs)) return { ok: true, say: 'Nothing to remove: this desktop has no GNOME shortcut settings.' };
  const list = parseList(gs(['get', SCHEMA, LIST_KEY]));
  if (!list.includes(ENTRY_PATH)) return { ok: true, say: 'The voice shortcut was not installed.' };
  gs(['set', SCHEMA, LIST_KEY, formatList(list.filter((p) => p !== ENTRY_PATH))]);
  const at = `${CHILD_SCHEMA}:${ENTRY_PATH}`;
  for (const k of ['name', 'command', 'binding']) {
    try {
      gs(['reset', at, k]);
    } catch {
      // already gone
    }
  }
  return { ok: true, say: 'The voice shortcut is removed. Your other shortcuts were not touched.' };
}

export function instructions(): string {
  return [
    'This desktop has no GNOME shortcut settings, so add the shortcut by hand to your desktop or window manager:',
    '  command: escanor-agent voice',
    '  KDE: System Settings, Shortcuts, Custom Shortcuts, new Global Shortcut, Command.',
    '  macOS: Shortcuts app, new shortcut "Run Shell Script" with the command, then give it a keyboard shortcut.',
    '  Windows: a shortcut to the command with a Shortcut key, or an AutoHotkey line.',
    'Press once to talk, press again to send.',
  ].join('\n');
}
