import { AGENT_ONLY_ROW_TYPES, type AgentToHubMessage } from '@remote-harness/shared';

/**
 * FLOW3: some chat rows mean something only because this agent wrote them (the fix's own test report, `escanor_tests`, which the
 * backend reads as proof that tests went from red to green). Claude, a terminal transcript, or anything else the model can
 * influence must never be able to send one. The agent marks the rows it builds itself here (by object identity, which nothing
 * outside this process can forge), and the hub connection refuses every other row of those types.
 */
const sealed = new WeakSet<object>();

export function sealAgentRow<T extends object>(row: T): T {
  sealed.add(row);
  return row;
}

/** An sdk_message carrying an agent-only row that the agent did not make itself. */
export function isForgedRow(msg: AgentToHubMessage): boolean {
  if (msg.type !== 'sdk_message') return false;
  const m = msg.message;
  if (typeof m !== 'object' || m === null) return false;
  const type = (m as { type?: unknown }).type;
  return typeof type === 'string' && AGENT_ONLY_ROW_TYPES.has(type) && !sealed.has(m);
}
