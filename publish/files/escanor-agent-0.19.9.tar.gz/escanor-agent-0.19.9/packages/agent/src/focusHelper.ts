import { fileURLToPath } from 'node:url';
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { desktopEnv, realRunner, type Runner } from './computerControl.js';
import { isGnome } from './screenControl.js';

/**
 * Knowing which window is in front, bringing one to the front and making it full screen, on the person's own desktop.
 *
 * GNOME on Wayland lets no outside program focus a window or press a key in one chosen window, and F11 sent through the remote-desktop
 * service goes to whichever window happens to have the keyboard. The one dependable way is the shell itself, so the agent installs a
 * tiny GNOME Shell extension (gnome-extension/escanor-focus@escanor.in) for the person: it answers four calls on the session bus
 * (list windows, which is in front, bring one to the front, make one full screen) and reads nothing inside a window. A new extension is
 * only picked up when GNOME starts, so the first sign-in after the install is when it begins to work; until then `status()` says
 * "restart_needed" and the older best-effort routes are used. On X11 without GNOME, xdotool does the same job.
 */

export const EXTENSION_UUID = 'escanor-focus@escanor.in';
export const EXTENSION_SRC = fileURLToPath(new URL(`../gnome-extension/${EXTENSION_UUID}/`, import.meta.url));

export type WinInfo = { id: number; wmClass: string; title: string; pid: number; fullscreen: boolean; focused: boolean };
export type HelperState = 'ready' | 'restart_needed' | 'missing' | 'not_needed';

const BROWSER_CLASS = /chrom|firefox|brave|vivaldi|opera|edge|epiphany|librewolf|zen|waterfox|safari/i;
export const isBrowser = (w: Pick<WinInfo, 'wmClass'>): boolean => BROWSER_CLASS.test(w.wmClass);

/** Calls the extension over the session bus with python's GIO (already needed for the screen helpers) and prints the answer as JSON. */
export const BUS_PY = `
import sys, json
from gi.repository import Gio, GLib
method = sys.argv[1]
bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
args = None
sig = None
if method in ('Focus', 'Fullscreen'):
    args = GLib.Variant('(t)', (int(sys.argv[2]),))
elif method == 'Version':
    pass
if method == 'Version':
    r = bus.call_sync('org.gnome.Shell', '/in/escanor/Focus', 'org.freedesktop.DBus.Properties', 'Get',
        GLib.Variant('(ss)', ('in.escanor.Focus', 'Version')), None, Gio.DBusCallFlags.NONE, 4000, None)
    print(json.dumps(r.unpack()[0]))
else:
    r = bus.call_sync('org.gnome.Shell', '/in/escanor/Focus', 'in.escanor.Focus', method, args, None, Gio.DBusCallFlags.NONE, 4000, None)
    v = r.unpack()[0]
    print(v if isinstance(v, str) else json.dumps(v))
`;

export type FocusDeps = {
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  run?: Runner;
  home?: string;
  sleep?: (ms: number) => Promise<void>;
};

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function parseWin(v: unknown): WinInfo | null {
  const o = v as Record<string, unknown> | null;
  if (!o || typeof o !== 'object' || typeof o.id !== 'number') return null;
  return { id: o.id, wmClass: String(o.wmClass ?? ''), title: String(o.title ?? ''), pid: Number(o.pid ?? 0), fullscreen: o.fullscreen === true, focused: o.focused === true };
}

export class FocusHelper {
  constructor(private d: FocusDeps = {}) {}

  private get platform() {
    return this.d.platform ?? process.platform;
  }
  private get env() {
    return desktopEnv(this.d.env ?? process.env, this.platform);
  }
  private get run(): Runner {
    return this.d.run ?? realRunner;
  }

  private gnome(): boolean {
    return this.platform === 'linux' && isGnome(this.env);
  }

  private async bus(method: string, arg?: number): Promise<string | null> {
    const r = await this.run({ cmd: 'python3', args: ['-I', '-c', BUS_PY, method, ...(arg === undefined ? [] : [String(arg)])] }, this.env);
    return r.code === 0 ? r.stdout.trim() : null;
  }

  private extDir(): string {
    return join(this.d.home ?? homedir(), '.local', 'share', 'gnome-shell', 'extensions', EXTENSION_UUID);
  }

  /** ready: the extension answers now. restart_needed: installed, starts at the next sign-in. missing: not installed. not_needed: not GNOME. */
  async status(): Promise<HelperState> {
    if (this.platform !== 'linux') return 'not_needed';
    if (!this.gnome()) return 'not_needed';
    if ((await this.bus('Version')) !== null) return 'ready';
    return existsSync(join(this.extDir(), 'metadata.json')) ? 'restart_needed' : 'missing';
  }

  /**
   * Puts the extension in the person's own folder and switches it on for them (gnome-extensions enable, else the shell's own list
   * of switched-on extensions). Adds nothing else and touches no other extension. Returns what it did, in a few plain words.
   */
  async install(): Promise<{ state: HelperState; did: 'already' | 'installed' | 'failed' | 'not_gnome' }> {
    if (!this.gnome()) return { state: 'not_needed', did: 'not_gnome' };
    const before = await this.status();
    if (before === 'ready') return { state: 'ready', did: 'already' };
    try {
      const dir = this.extDir();
      mkdirSync(dir, { recursive: true });
      for (const f of ['metadata.json', 'extension.js']) {
        const src = join(EXTENSION_SRC, f);
        const same = existsSync(join(dir, f)) && readFileSync(join(dir, f), 'utf8') === readFileSync(src, 'utf8');
        if (!same) copyFileSync(src, join(dir, f));
      }
    } catch {
      return { state: before, did: 'failed' };
    }
    const en = await this.run({ cmd: 'gnome-extensions', args: ['enable', EXTENSION_UUID] }, this.env);
    if (en.code !== 0) {
      // The shell has not scanned the new folder yet: add it to the shell's list of switched-on extensions, which it reads at start.
      const cur = await this.run({ cmd: 'gsettings', args: ['get', 'org.gnome.shell', 'enabled-extensions'] }, this.env);
      const list = cur.code === 0 ? [...cur.stdout.matchAll(/'([^']+)'/g)].map((m) => m[1]!) : [];
      if (!list.includes(EXTENSION_UUID)) {
        const next = `[${[...list, EXTENSION_UUID].map((u) => `'${u}'`).join(', ')}]`;
        const set = await this.run({ cmd: 'gsettings', args: ['set', 'org.gnome.shell', 'enabled-extensions', next] }, this.env);
        if (set.code !== 0) return { state: 'restart_needed', did: 'failed' };
      }
    }
    return { state: await this.status(), did: 'installed' };
  }

  /** The open normal windows, most recently used first. Null when no tool here can say. */
  async windows(): Promise<WinInfo[] | null> {
    if (this.gnome()) {
      const out = await this.bus('Windows');
      if (out === null) return null;
      try {
        return (JSON.parse(out) as unknown[]).map(parseWin).filter((w): w is WinInfo => !!w);
      } catch {
        return null;
      }
    }
    return null;
  }

  /** The window in front, or null (nothing in front, or no way to tell). */
  async active(): Promise<WinInfo | null> {
    if (this.gnome()) {
      const out = await this.bus('Active');
      if (out === null) return null;
      try {
        return parseWin(JSON.parse(out));
      } catch {
        return null;
      }
    }
    if (this.platform === 'linux' && this.env.DISPLAY) {
      const id = await this.run({ cmd: 'xdotool', args: ['getactivewindow'] }, this.env);
      if (id.code !== 0 || !/^\d+$/.test(id.stdout.trim())) return null;
      const n = id.stdout.trim();
      const title = await this.run({ cmd: 'xdotool', args: ['getwindowname', n] }, this.env);
      const cls = await this.run({ cmd: 'xdotool', args: ['getwindowclassname', n] }, this.env);
      const pid = await this.run({ cmd: 'xdotool', args: ['getwindowpid', n] }, this.env);
      return { id: Number(n), wmClass: cls.stdout.trim(), title: title.stdout.trim(), pid: Number(pid.stdout.trim()) || 0, fullscreen: false, focused: true };
    }
    return null;
  }

  /** Brings the window to the front and checks that it is (GNOME may need a second try). */
  async focus(id: number): Promise<boolean> {
    for (let i = 0; i < 4; i++) {
      if (this.gnome()) await this.bus('Focus', id);
      else if (this.platform === 'linux') await this.run({ cmd: 'xdotool', args: ['windowactivate', String(id)] }, this.env);
      else return false;
      await (this.d.sleep ?? wait)(i === 0 ? 150 : 300);
      if ((await this.active())?.id === id) return true;
    }
    return false;
  }

  async fullscreen(id: number): Promise<boolean> {
    if (!this.gnome()) return false;
    return (await this.bus('Fullscreen', id)) === 'true';
  }

  /**
   * The browser window a page was just opened in: a window that was not there before, else the browser window used most recently
   * (a page opened as a new tab goes in the browser's current window). Waits a few seconds for the browser to show it.
   */
  async newestBrowser(before: WinInfo[] | null, waitMs = 3000): Promise<WinInfo | null> {
    const known = new Set((before ?? []).map((w) => w.id));
    const firstBefore = (before ?? []).find(isBrowser)?.id;
    const sleep = this.d.sleep ?? wait;
    const t0 = Date.now();
    let last: WinInfo[] | null = null;
    do {
      last = await this.windows();
      if (!last) return null;
      const fresh = last.find((w) => isBrowser(w) && !known.has(w.id));
      if (fresh) return fresh;
      const top = last.find(isBrowser);
      if (top && top.id !== firstBefore) return top;
      await sleep(400);
    } while (Date.now() - t0 < waitMs);
    return (last ?? []).find(isBrowser) ?? null;
  }
}
