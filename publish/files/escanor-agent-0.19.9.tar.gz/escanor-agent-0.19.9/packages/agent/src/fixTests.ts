import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, mkdtempSync, readdirSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { constants } from 'node:os';
import { join } from 'node:path';
import type { AgentToHubMessage, EscanorTestsRow, HubUserInput, MachineRunResult } from '@remote-harness/shared';
import { childEnv } from './childEnv.js';
import { procStartOf } from './claudeProcs.js';
import { findRepos } from './machineState.js';
import { redact } from './redact.js';
import type { FixRecord, SessionRegistry } from './registry.js';
import type { AskResume, ResumeAsk } from './resumeCheck.js';
import { sealAgentRow } from './trustedRows.js';

/**
 * FLOW3: a fix the backend's ladder runs on this computer ("code:computer" rung) is checked by this agent, not by the model's
 * word. When a turn of the fix chat ends, the agent finds the fix branch, runs the repository's own test command on the base
 * commit (before the fix) and on the pushed head of the branch (after it), each in a throwaway local clone (nothing registered in
 * the person's repository, its checkout never touched, no remote to push to), and sends one `escanor_tests` row (backend FX9 shape)
 * into the chat. Only rows built here are sealed (trustedRows.ts); the hub connection refuses any other.
 *
 * Fix round 1 (review DEV58):
 * - I1: the command is the BASE commit's (its .escanor/test-command, or its package.json test script, which is also pinned into the
 *   head's copy): the fix cannot choose or rewrite what proves it. A base with no test command gets no row.
 * - I3: the agent stopping kills the running test's process group and removes its copies; a run left by a crash (lock.json in
 *   data/fix-runs/run-*) is killed and removed on the next start, and no run starts while one is left.
 * - I4: a test run cut off by a restart is run again at most twice per fix (persisted), then the backend falls back.
 * - I5: tests run only when the task asks for verification (HubUserInput.fix.verify, or the backend's VERIFY_MARKER: the
 *   computer-route fix at control level "Fix & verify" or higher), with no ssh agent, credential helper, git prompt or token.
 *
 * The fix's progress lives in data/sessions.json (RegistryEntry.fix), so a fix whose turn an agent restart cut off is continued on
 * the next start, and a test run cut off is run again.
 */

/** The backend's delivery words (mongo-backend autopilot/ladder_run.py DELIVERY). */
const DELIVERY_BRANCH = /\bcreate a new branch named (escanor\/fix-[0-9a-z]{4,40})\b/;
const FIX_BRANCH = /^escanor\/fix-[0-9a-z][0-9a-z-]{3,39}$/;
/**
 * The line the backend starts the first message of a run's chat on a computer with (mongo-backend ai_service `_machine_tag`):
 * every task an Escanor run gives this computer, a fix ladder's rung or a kept run started from the phone, and never a person's
 * own chat. Its id is the first 8 characters of the backend conversation's id.
 */
const AUTOMATION_TAG = /^\/new Escanor automation ([0-9A-Za-z_-]{1,8})\./;
const TAIL = 2000;
const DEFAULT_RUN_TIMEOUT_MS = 15 * 60_000;
const GIT_TIMEOUT_MS = 30_000;
/** A fix older than this is not picked up again after a restart (the backend has moved on long since). */
const RESUME_MAX_AGE_MS = 12 * 3600_000;
const MAX_RESUMES = 3;
/** Dependency folders a test run needs and git does not have: linked from the person's checkout into the worktree. */
const DEP_DIRS = ['node_modules', '.venv', 'venv', 'vendor/bundle'];

/** Put by the backend into a computer-route fix task whose control level allows "Run your tests" (Fix & verify and up). */
export const VERIFY_MARKER = '[escanor:verify-tests]';
/** A test run cut off by a restart is run again at most this often per fix. */
const MAX_TEST_RERUNS = 2;
/** Environment a test run never gets: anything that could push, or reach the person's accounts. */
const TEST_ENV_DROP = ['SSH_AUTH_SOCK', 'SSH_AGENT_PID', 'GIT_ASKPASS', 'SSH_ASKPASS', 'GH_TOKEN', 'GITHUB_TOKEN', 'GH_ENTERPRISE_TOKEN', 'GITLAB_TOKEN', 'GIT_SSH', 'GIT_SSH_COMMAND', 'GIT_CONFIG_PARAMETERS'];

export const RESUME_NOTICE = 'This computer\'s Escanor agent restarted while it was working on this fix; it has picked the fix up again.';
/**
 * AGRESUME: Escanor could not say whether the work is still wanted, so it is not picked up; the run's supervisor reads this line and
 * sends "carry on" itself if it still wants it. It begins with RESUME_NOTICE's words, so a backend that only knows those (#179)
 * still reads it as a plain notice, never as "your computer is busy".
 */
export const WAIT_NOTICE = 'This computer\'s Escanor agent restarted while it was working on this fix; it is waiting for Escanor to say whether to carry on.';
const resumeText = (fix: FixRecord) =>
  fix.kind === 'run'
    ? 'This computer\'s Escanor agent restarted while you were working on this task, which stopped your run. Continue the same task ' +
      'from where you left off: look at what is already done (do not redo it), then finish and report as asked before.'
    : `This computer's Escanor agent restarted while you were working on this fix, which stopped your run. Continue the same fix from ` +
      `where you left off: check out the branch ${fix.branch} if it exists (do not create it again), look at what is already done, then ` +
      'finish, commit, push and open (or update) the pull request, and report as asked before.';

/** The backend conversation's id prefix of a run's chat, from its first message's tag, or null when it is not a run's chat. */
export function automationConvFrom(input: HubUserInput): string | null {
  return AUTOMATION_TAG.exec(input.text ?? '')?.[1] ?? null;
}

/** The fix branch a message is about, or null when it is not a fix task. */
export function fixBranchFrom(input: HubUserInput): string | null {
  if (input.fix && typeof input.fix.branch === 'string') return FIX_BRANCH.test(input.fix.branch) ? input.fix.branch : null;
  const m = DELIVERY_BRANCH.exec(input.text ?? '');
  return m && FIX_BRANCH.test(m[1]) ? m[1] : null;
}

/** Did the task ask for the agent to verify the fix with the repository's tests? (I5) */
export function wantsVerify(input: HubUserInput): boolean {
  return input.fix?.verify === true || (input.text ?? '').includes(VERIFY_MARKER);
}

/** owner/name from a git remote URL (https or ssh), without any credentials in it. */
export function repoSlug(url: string): string | null {
  const m = /^(?:[a-z+]+:\/\/(?:[^@/]+@)?[^/]+\/|[^@\s]+@[^:\s]+:)([\w.-]+)\/([\w.-]+?)(?:\.git)?\/?$/i.exec(url.trim());
  return m ? `${m[1]}/${m[2]}` : null;
}

/** The repository's own test command, or null when it has none the agent can tell. */
export function detectTestCommand(dir: string): string | null {
  const has = (f: string) => existsSync(join(dir, f));
  const read = (f: string) => {
    try {
      return readFileSync(join(dir, f), 'utf8');
    } catch {
      return '';
    }
  };
  const own = read('.escanor/test-command').split('\n')[0].trim();
  if (own) return own.slice(0, 300);
  if (has('package.json')) {
    try {
      const test = (JSON.parse(read('package.json')) as { scripts?: { test?: unknown } }).scripts?.test;
      if (typeof test === 'string' && test.trim() && !/no test specified/.test(test)) {
        if (has('pnpm-lock.yaml')) return 'pnpm test';
        if (has('yarn.lock')) return 'yarn test';
        if (has('bun.lockb') || has('bun.lock')) return 'bun run test';
        return 'npm test';
      }
    } catch {
      // not JSON: look further
    }
  }
  const pytest =
    has('pytest.ini') ||
    /\[tool\.pytest|pytest/.test(read('pyproject.toml')) ||
    /\[tool:pytest\]/.test(read('setup.cfg')) ||
    /pytest/.test(read('tox.ini')) ||
    (has('tests') && (has('pyproject.toml') || has('setup.py') || has('requirements.txt')));
  if (pytest) return has('.venv/bin/python') ? '.venv/bin/python -m pytest -q' : 'pytest -q';
  if (has('go.mod')) return 'go test ./...';
  if (has('Cargo.toml')) return 'cargo test';
  if (/^test:/m.test(read('Makefile'))) return 'make test';
  return null;
}

type Git = (dir: string, args: string[], timeoutMs?: number) => Promise<{ code: number; out: string }>;

const realGit: Git = (dir, args, timeoutMs = GIT_TIMEOUT_MS) =>
  new Promise((resolve) => {
    // No prompts (a missing credential fails at once instead of hanging), no hub credentials.
    const env = { ...childEnv(process.env), GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0', LC_ALL: 'C' };
    execFile('git', ['-C', dir, ...args], { timeout: timeoutMs, env, maxBuffer: 8 * 1024 * 1024 }, (err, stdout) => {
      resolve({ code: err ? (typeof (err as { code?: unknown }).code === 'number' ? (err as { code: number }).code : 1) : 0, out: String(stdout ?? '').trim() });
    });
  });

/** Run a test command; the exit code is always an integer (a timeout is 124, a signal 128 + its number). */
/** The environment of a test run: no hub credentials, no ssh agent, no credential helper, no git prompt, no tokens (I5). */
export function testEnv(base: NodeJS.ProcessEnv = process.env): Record<string, string | undefined> {
  const env = childEnv(base);
  for (const k of TEST_ENV_DROP) delete env[k];
  for (const k of Object.keys(env)) if (/^GIT_CONFIG_(COUNT|KEY_|VALUE_)/.test(k)) delete env[k];
  return {
    ...env,
    CI: '1',
    // npm reads this before any project .npmrc: scripts run in the plain shell.
    ...(process.platform === 'win32' ? {} : { npm_config_script_shell: '/bin/sh' }),
    GIT_TERMINAL_PROMPT: '0',
    // An empty helper clears every configured one; ssh gets no key and never asks.
    GIT_CONFIG_COUNT: '1',
    GIT_CONFIG_KEY_0: 'credential.helper',
    GIT_CONFIG_VALUE_0: '',
    GIT_SSH_COMMAND: `ssh -o BatchMode=yes -o IdentitiesOnly=yes -o IdentityFile=${process.platform === 'win32' ? 'NUL' : '/dev/null'}`,
  };
}

/** Run a test command; the exit code is always an integer (a timeout is 124, a signal 128 + its number). */
export function runTests(
  cmd: string,
  cwd: string,
  timeoutMs: number,
  o: { env?: Record<string, string | undefined>; onSpawn?: (child: ChildProcess) => void } = {},
): Promise<{ cmd: string; exit: number; tail: string }> {
  return new Promise((resolve) => {
    let buf = '';
    const keep = (d: Buffer) => {
      buf = (buf + d.toString('utf8')).slice(-64_000);
    };
    let timedOut = false;
    let child: ChildProcess;
    try {
      // Its own process group, so the whole run (npm's children too) is stopped at once.
      child = spawnShell(cmd, { cwd, env: o.env ?? testEnv() });
    } catch (err) {
      resolve({ cmd, exit: 127, tail: `Could not start: ${err instanceof Error ? err.message : err}` });
      return;
    }
    o.onSpawn?.(child);
    child.stdout?.on('data', keep);
    child.stderr?.on('data', keep);
    const timer = setTimeout(() => {
      timedOut = true;
      killGroup(child.pid);
    }, timeoutMs);
    child.on('error', (err) => {
      buf += `\n${err.message}`;
    });
    child.on('close', (code, signal) => {
      clearTimeout(timer);
      const exit = timedOut ? 124 : typeof code === 'number' ? code : signal ? 128 + (constants.signals[signal] ?? 0) : 1;
      if (timedOut) buf += `\n[Escanor: the test run was stopped after ${Math.round(timeoutMs / 1000)} s]`;
      resolve({ cmd, exit, tail: redact(buf).slice(-TAIL) });
    });
  });
}

/** How a test command is started: `/bin/sh -c` in its own process group, or `cmd.exe /d /s /c` (hidden window) on Windows. */
export function shellSpec(cmd: string, platform: NodeJS.Platform = process.platform, comspec = process.env.ComSpec): { file: string; args: string[]; windows: boolean } {
  if (platform === 'win32') return { file: comspec || 'cmd.exe', args: ['/d', '/s', '/c', `"${cmd}"`], windows: true };
  return { file: '/bin/sh', args: ['-c', cmd], windows: false };
}

function spawnShell(cmd: string, o: { cwd: string; env: Record<string, string | undefined> }): ChildProcess {
  const sh = shellSpec(cmd);
  // On Windows the command line goes to cmd.exe as it is (quoting is cmd's own), and there is no process group to lead.
  return spawn(sh.file, sh.args, { cwd: o.cwd, env: o.env, detached: !sh.windows, windowsHide: true, windowsVerbatimArguments: sh.windows, stdio: ['ignore', 'pipe', 'pipe'] });
}

function killGroup(pid: number | undefined): void {
  if (!pid) return;
  if (process.platform === 'win32') {
    try {
      spawn('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }).on('error', () => undefined);
    } catch {
      // already gone
    }
    return;
  }
  try {
    process.kill(-pid, 'SIGKILL');
  } catch {
    try {
      process.kill(pid, 'SIGKILL');
    } catch {
      // already gone
    }
  }
}

type Lock = { agentPid?: number; testPid?: number | null; testStart?: string | null; startedAt?: string };

export class FixTasks {
  /** Fix messages for new chats, by temp id, until Claude names the chat (session_created). */
  private pending = new Map<string, FixRecord>();
  private chain: Promise<void> = Promise.resolve();
  private stopping = false;
  private git: Git;
  /** The test run going on now, and its folder (stopped and removed when the agent stops). */
  private child: ChildProcess | null = null;
  private runDir: string | null = null;
  /** Rows this process sent and still holds in memory (re-testing the same head while they wait for the hub is pointless). */
  private sentHere = new Set<string>();
  /** Chats a stop (interrupt) came for since this process started: never picked up again by `resumeAfterRestart`. */
  private stoppedHere = new Set<string>();
  /** Chats a message came for while the resume question was out: that message already carries them on (never a second turn). */
  private heardSince = new Set<string>();

  constructor(
    private o: {
      registry: SessionRegistry;
      send: (msg: AgentToHubMessage) => void;
      /** Hand a message to the session manager as if it came from the hub (continuing a fix after a restart). */
      admit: (input: HubUserInput) => void;
      workspaceRoot: string;
      dataDir: string;
      /** Told each test result (machine_state's last test). */
      noteRun?: (r: MachineRunResult) => void;
      runTimeoutMs?: number;
      git?: Git;
      now?: () => number;
      /** Injectable for tests: a process's start time (null where it cannot be read). */
      procStart?: (pid: number) => string | null;
      /** Injectable for tests: remove a run folder, true when it is gone. */
      removeRun?: (dir: string) => boolean;
      /** AGRESUME: asks Escanor whether cut-off work is still wanted (resumeCheck.ts). Absent: no answer, so nothing is picked up. */
      askResume?: AskResume;
    },
  ) {
    this.git = o.git ?? realGit;
    this.cleanupLeftovers();
  }

  private now(): number {
    return this.o.now?.() ?? Date.now();
  }

  private get runsDir(): string {
    return join(this.o.dataDir, 'fix-runs');
  }

  private removeRun(dir: string): boolean {
    if (this.o.removeRun) return this.o.removeRun(dir);
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {
      // checked below
    }
    return !existsSync(dir);
  }

  /**
   * The agent is stopping: what happens to its chats now is not their turn ending (they continue on the next start), and a test
   * running now is killed and its copies removed (I3). The fix stays 'testing', so the next start runs it again (capped, I4).
   */
  stop(): void {
    this.stopping = true;
    killGroup(this.child?.pid);
    this.child = null;
    if (this.runDir) this.removeRun(this.runDir);
  }

  /** The pid of the test running now (tests). */
  runningTestPid(): number | undefined {
    return this.child?.pid;
  }

  /** Runs left by an agent that died (crash, SIGKILL): their test is killed, their copies removed (I3). */
  cleanupLeftovers(): void {
    let names: string[];
    try {
      names = readdirSync(this.runsDir);
    } catch {
      return;
    }
    for (const name of names) {
      const dir = join(this.runsDir, name);
      if (dir === this.runDir) continue; // this process's own run
      let lock: Lock = {};
      try {
        lock = JSON.parse(readFileSync(join(dir, 'lock.json'), 'utf8')) as Lock;
      } catch {
        // no lock: just the folder
      }
      const pid = typeof lock.testPid === 'number' ? lock.testPid : undefined;
      // Only the process that ran the test: its start time was recorded and is still the same (a reused pid has another one).
      // With no start time on either side (macOS, Windows, /proc unreadable) nothing is killed on a guess; the folder still goes.
      const recorded = typeof lock.testStart === 'string' && lock.testStart ? lock.testStart : null;
      const current = pid && recorded ? (this.o.procStart ?? procStartOf)(pid) : null;
      if (pid && pid !== process.pid && recorded !== null && current === recorded) killGroup(pid);
      if (this.removeRun(dir)) console.log(`Removed a test run left from before (${name}).`);
    }
  }

  /** Resolves once every test run asked for so far is done (tests). */
  idle(): Promise<void> {
    return this.chain;
  }

  private update(sessionId: string, patch: Partial<FixRecord>): void {
    const fix = this.o.registry.get(sessionId)?.fix;
    if (fix) this.o.registry.update(sessionId, { fix: { ...fix, ...patch } });
  }

  /** Every message from the hub, before the session manager takes it. */
  noteInput(input: HubUserInput): void {
    if (this.stopping) return;
    const branch = fixBranchFrom(input);
    const id = input.sessionId;
    this.heardSince.add(id);
    if (this.heardSince.size > 1000) this.heardSince.delete(this.heardSince.values().next().value!); // the oldest only
    const known = this.o.registry.get(id);
    const verify = wantsVerify(input);
    if (known?.fix) {
      // A follow-up in a fix chat (the backend's nudge, or the person): its turn is open again.
      this.update(id, {
        turnOpen: true,
        ...(verify ? { verify: true } : {}),
        ...(branch && branch !== known.fix.branch ? { branch, reportedHead: undefined, kind: undefined } : {}),
        ...(known.fix.state === 'reported' ? { state: 'working' } : {}),
      });
      return;
    }
    const conv = automationConvFrom(input);
    // FLOW4 minor 4: a run's chat with no fix branch (a kept run started from the phone) gets a record too, so it is picked up
    // after a restart by the same rules; it has nothing for the agent to test.
    if (!branch && !conv) return;
    const fix: FixRecord = branch
      ? { branch, startedAt: new Date(this.now()).toISOString(), state: 'working', turnOpen: true, resumes: 0, verify, ...(conv ? { conv } : {}) }
      : { kind: 'run', branch: '', startedAt: new Date(this.now()).toISOString(), state: 'working', turnOpen: true, resumes: 0, verify: false, conv: conv! };
    if (known) this.o.registry.update(id, { fix });
    else {
      this.pending.set(id, fix);
      if (this.pending.size > 100) this.pending.delete(this.pending.keys().next().value!);
    }
  }

  /** Every message to the hub. */
  observe(msg: AgentToHubMessage): void {
    if (this.stopping) return;
    if (msg.type === 'session_created') {
      const fix = this.pending.get(msg.tempId);
      if (!fix) return;
      this.pending.delete(msg.tempId);
      this.o.registry.update(msg.sessionId, { fix: { ...(this.o.registry.get(msg.sessionId)?.fix ?? {}), ...fix } });
      return;
    }
    const sessionId = msg.type === 'sdk_message' ? msg.sessionId : msg.type === 'error' && msg.kind !== 'notice' ? msg.sessionId : undefined;
    if (!sessionId || !this.o.registry.get(sessionId)?.fix) return;
    const ended = msg.type === 'error' || (msg.type === 'sdk_message' && (msg.message as { type?: string } | null)?.type === 'result');
    if (!ended) return;
    this.update(sessionId, { turnOpen: false });
    if (this.o.registry.get(sessionId)?.fix?.kind !== 'run') this.report(sessionId);
  }

  /** The hub has these outbox ids: a test row among them is reported for good (until then a restart tests again). */
  confirmed(mids: string[]): void {
    if (mids.length === 0) return;
    const set = new Set(mids);
    for (const e of this.o.registry.all()) {
      const fix = e.fix;
      if (!fix?.sentMid || !set.has(fix.sentMid)) continue;
      this.update(e.sessionId, { state: 'reported', reportedHead: fix.sentHead, sentMid: undefined, sentHead: undefined });
    }
  }

  /**
   * After the agent started (its first connection): re-run tests a restart cut off, and continue the fixes and runs a restart cut
   * off that Escanor says are still wanted (AGRESUME). Resolves once that is decided.
   */
  async resumeAfterRestart(): Promise<void> {
    this.cleanupLeftovers();
    const asks: ResumeAsk[] = [];
    for (const e of this.o.registry.all()) {
      const fix = e.fix;
      if (!fix) continue;
      if (this.now() - Date.parse(fix.startedAt) > RESUME_MAX_AGE_MS) continue;
      if (fix.state === 'testing') {
        const reruns = fix.testReruns ?? 0;
        if (reruns >= MAX_TEST_RERUNS) {
          console.log(`Fix ${fix.branch}: its test run was cut off ${reruns} times; no test report (the backend falls back).`);
          this.update(e.sessionId, { state: 'working', sentMid: undefined, sentHead: undefined });
          continue;
        }
        this.update(e.sessionId, { testReruns: reruns + 1 });
        this.report(e.sessionId);
        continue;
      }
      if (!fix.turnOpen || fix.resumes >= MAX_RESUMES || this.stoppedHere.has(e.sessionId)) continue;
      asks.push({ sessionId: e.sessionId, ...(fix.conv ? { conv: fix.conv } : {}) });
    }
    if (asks.length === 0) return;
    // One question for all of them. A stop that lands while it is out still wins (resume checks stoppedHere again).
    let answers: Awaited<ReturnType<AskResume>> = null;
    try {
      answers = this.o.askResume ? await this.o.askResume(asks) : null;
    } catch {
      answers = null;
    }
    for (const { sessionId } of asks) {
      if (this.stopping) return;
      if (this.heardSince.has(sessionId)) continue; // Escanor or the person wrote to it meanwhile: that message carries it on
      const verdict = answers ? (answers[sessionId] ?? 'stop') : null; // answered, but not for this chat: not wanted
      if (verdict === 'continue') this.resume(sessionId);
      else if (verdict === 'stop') {
        console.log(`Not picking ${sessionId} up again: Escanor no longer wants it.`);
        if (this.o.registry.get(sessionId)?.fix) this.update(sessionId, { turnOpen: false });
      } else if (!this.stoppedHere.has(sessionId)) {
        // No answer: not picked up. Still open on disk (the next start asks again); the run's supervisor says carry on if it wants.
        console.log(`Not picking ${sessionId} up again yet: Escanor could not say whether it is still wanted.`);
        this.o.send({ type: 'error', kind: 'notice', sessionId, message: WAIT_NOTICE });
      }
    }
  }

  /** A stop for this chat (the backend's or the person's): a fix it holds is not picked up again after a restart. */
  noteInterrupt(sessionId: string): void {
    this.stoppedHere.add(sessionId);
    if (this.o.registry.get(sessionId)?.fix) this.update(sessionId, { turnOpen: false });
  }

  private resume(sessionId: string): void {
    const fix = this.o.registry.get(sessionId)?.fix;
    if (this.stopping || !fix || !fix.turnOpen || fix.resumes >= MAX_RESUMES || this.stoppedHere.has(sessionId)) return;
    this.update(sessionId, { resumes: fix.resumes + 1 });
    this.o.send({ type: 'error', kind: 'notice', sessionId, message: RESUME_NOTICE });
    // inputId 'agent:...': the agent's own message, never acked to the hub as a phone message (sessionManager.ack).
    this.o.admit({ type: 'user_input', sessionId, text: resumeText(fix), inputId: `agent:resume:${randomUUID()}` });
  }

  /** Test the fix of this chat (one run at a time on this machine). */
  report(sessionId: string): void {
    this.chain = this.chain.then(() => this.testAndSend(sessionId)).catch((err) => {
      console.error(`Fix tests for ${sessionId} failed:`, err instanceof Error ? err.message : err);
      this.update(sessionId, { state: 'working' });
    });
  }

  private async findRepo(cwd: string, branch: string): Promise<string | null> {
    const dirs = [cwd, ...findRepos(cwd, { maxDepth: 2, maxRepos: 20 }).filter((r) => r !== '.').map((r) => join(cwd, r))];
    if (cwd !== this.o.workspaceRoot) dirs.push(...findRepos(this.o.workspaceRoot).map((r) => join(this.o.workspaceRoot, r)));
    for (const dir of [...new Set(dirs)]) {
      const local = await this.git(dir, ['rev-parse', '--verify', '-q', `refs/heads/${branch}`]);
      const remote = local.code === 0 ? local : await this.git(dir, ['rev-parse', '--verify', '-q', `refs/remotes/origin/${branch}`]);
      if (remote.code === 0) return dir;
    }
    return null;
  }

  /** The head of the branch as pushed (the remote's own word; the remote-tracking ref when the remote cannot be asked). */
  private async pushedHead(dir: string, branch: string): Promise<string | null> {
    const ls = await this.git(dir, ['ls-remote', 'origin', `refs/heads/${branch}`]);
    const sha = ls.code === 0 ? /^([0-9a-f]{40})\s/.exec(ls.out)?.[1] : undefined;
    if (sha) {
      if ((await this.git(dir, ['cat-file', '-e', `${sha}^{commit}`])).code !== 0) await this.git(dir, ['fetch', '-q', 'origin', branch]);
      return sha;
    }
    if (ls.code === 0) return null; // the remote answered: the branch is not there
    const tracking = await this.git(dir, ['rev-parse', '--verify', '-q', `refs/remotes/origin/${branch}`]);
    return tracking.code === 0 && /^[0-9a-f]{40}$/.test(tracking.out) ? tracking.out : null;
  }

  private async defaultRef(dir: string): Promise<string | null> {
    const head = await this.git(dir, ['symbolic-ref', '-q', 'refs/remotes/origin/HEAD']);
    const candidates = [...(head.code === 0 && head.out ? [head.out] : []), 'refs/remotes/origin/main', 'refs/remotes/origin/master'];
    for (const ref of candidates) if ((await this.git(dir, ['rev-parse', '--verify', '-q', ref])).code === 0) return ref;
    return null;
  }

  private writeLock(lock: Lock): void {
    if (!this.runDir) return;
    try {
      writeFileSync(join(this.runDir, 'lock.json'), JSON.stringify(lock), { mode: 0o600 });
    } catch {
      // the run folder was removed (the agent is stopping)
    }
  }

  /** A throwaway copy of `sha`: a local clone (objects hard-linked), checked out with no hooks, with its remote removed. */
  private async copyAt(repo: string, name: string, sha: string): Promise<string | null> {
    const path = join(this.runDir!, name);
    if ((await this.git(repo, ['clone', '-q', '--no-checkout', repo, path], 120_000)).code !== 0) return null;
    if ((await this.git(path, ['-c', 'core.hooksPath=/dev/null', '-c', 'advice.detachedHead=false', 'checkout', '-q', '--detach', sha], 120_000)).code !== 0) return null;
    if ((await this.git(path, ['remote', 'remove', 'origin'])).code !== 0) return null;
    for (const d of DEP_DIRS) {
      if (existsSync(join(repo, d)) && !existsSync(join(path, d))) {
        try {
          mkdirSync(join(path, d, '..'), { recursive: true });
          symlinkSync(join(repo, d), join(path, d));
        } catch {
          // the run goes on without it
        }
      }
    }
    return path;
  }

  /** I1: the head's copy runs the base's npm scripts (the whole block) and npm settings, whatever the fix changed in them. */
  private pinScripts(before: string, after: string): boolean {
    try {
      const baseScripts = (JSON.parse(readFileSync(join(before, 'package.json'), 'utf8')) as { scripts?: Record<string, unknown> }).scripts ?? {};
      let pkg: Record<string, unknown>;
      try {
        pkg = JSON.parse(readFileSync(join(after, 'package.json'), 'utf8')) as Record<string, unknown>;
      } catch {
        pkg = JSON.parse(readFileSync(join(before, 'package.json'), 'utf8')) as Record<string, unknown>;
      }
      writeFileSync(join(after, 'package.json'), JSON.stringify({ ...pkg, scripts: baseScripts }, null, 2));
      // A script-shell (or anything else) the fix put into .npmrc does not apply either: the base's .npmrc, or none.
      rmSync(join(after, '.npmrc'), { force: true });
      if (existsSync(join(before, '.npmrc'))) writeFileSync(join(after, '.npmrc'), readFileSync(join(before, '.npmrc')));
      return true;
    } catch {
      return false;
    }
  }

  private async testAndSend(sessionId: string): Promise<void> {
    const entry = this.o.registry.get(sessionId);
    const fix = entry?.fix;
    if (!entry || !fix || this.stopping) return;
    const nothing = (why: string) => {
      console.log(`Fix ${fix.branch}: no test report (${why}).`);
      const now = this.o.registry.get(sessionId)?.fix;
      this.update(sessionId, { state: now?.reportedHead ? 'reported' : 'working', sentMid: undefined, sentHead: undefined });
    };
    if (!fix.verify) return nothing('the task did not ask for its tests to be run');
    this.cleanupLeftovers();
    if (existsSync(this.runsDir) && readdirSync(this.runsDir).length > 0) return nothing('a test run from before is still being removed');
    this.update(sessionId, { state: 'testing' });
    const repo = await this.findRepo(entry.cwd, fix.branch);
    if (!repo) return nothing('the branch is not in any repository here');
    const head = await this.pushedHead(repo, fix.branch);
    if (!head) return nothing('the branch was not pushed');
    if (head === fix.reportedHead) return this.update(sessionId, { state: 'reported' });
    if (head === fix.sentHead && fix.sentMid && this.sentHere.has(fix.sentMid)) return; // already sent from here, waiting for the hub
    const ref = await this.defaultRef(repo);
    if (!ref) return nothing('no default branch on origin');
    const mb = await this.git(repo, ['merge-base', head, ref]);
    const base = mb.code === 0 ? mb.out : '';
    if (!/^[0-9a-f]{40}$/.test(base)) return nothing('no common commit with the default branch');
    const url = await this.git(repo, ['config', '--get', 'remote.origin.url']);
    const slug = url.code === 0 ? repoSlug(url.out) : null;
    if (!slug) return nothing('origin is not a known kind of remote');

    mkdirSync(this.runsDir, { recursive: true, mode: 0o700 });
    this.runDir = mkdtempSync(join(this.runsDir, 'run-'));
    this.writeLock({ agentPid: process.pid, testPid: null, startedAt: new Date(this.now()).toISOString() });
    try {
      const before = await this.copyAt(repo, 'before', base);
      const after = before && !this.stopping ? await this.copyAt(repo, 'after', head) : null;
      if (this.stopping) return;
      if (!before || !after) return nothing('could not check the commits out');
      // I1: what proves the fix is the base's own test command, never one the fix wrote.
      const cmd = detectTestCommand(before);
      if (!cmd) return nothing('the base commit has no test command');
      if (existsSync(join(before, 'package.json')) && /^(npm|pnpm|yarn|bun)\b/.test(cmd) && !this.pinScripts(before, after)) return nothing('could not keep the base\'s test script');
      const timeout = this.o.runTimeoutMs ?? DEFAULT_RUN_TIMEOUT_MS;
      const run = (dir: string) =>
        runTests(cmd, dir, timeout, {
          onSpawn: (child) => {
            this.child = child;
            this.writeLock({ agentPid: process.pid, testPid: child.pid ?? null, testStart: child.pid ? procStartOf(child.pid) : null });
          },
        });
      const testsBefore = await run(before);
      this.child = null;
      if (this.stopping) return;
      const testsAfter = await run(after);
      this.child = null;
      if (this.stopping) return;
      const row: EscanorTestsRow = sealAgentRow({ type: 'escanor_tests', repo: slug, branch: fix.branch, base, head, tests_before: testsBefore, tests_after: testsAfter });
      const mid = randomUUID();
      this.sentHere.add(mid);
      // Still 'testing' until the hub has it (confirmed): a restart before then tests again, as the row is never replayed from disk.
      this.update(sessionId, { state: 'testing', sentMid: mid, sentHead: head });
      this.o.send({ type: 'sdk_message', sessionId, mid, message: row });
      this.o.noteRun?.({ cmd, ok: testsAfter.exit === 0, exit: testsAfter.exit, at: new Date(this.now()).toISOString(), sessionId, by: 'agent' });
    } finally {
      this.child = null;
      const dir = this.runDir;
      this.runDir = null;
      if (dir) this.removeRun(dir);
    }
  }
}
