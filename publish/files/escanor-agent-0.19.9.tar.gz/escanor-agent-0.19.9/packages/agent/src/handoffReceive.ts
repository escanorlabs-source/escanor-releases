import { spawn } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { safeUrl } from './computerControl.js';
import { desktopEnv } from './computerControl.js';
import { notice, openPage, type ScreenDeps } from './screenControl.js';

/**
 * Device mesh handoff, the computer's side: the owner sent something from another of their devices ("send this to my laptop"). It
 * arrives as one `receive` command through the hub (or as `open_url` for a plain link) and is dealt with here, in the open:
 *  - a link: opened in the person's own browser (http or https only, like every other page this agent opens);
 *  - text: saved to a note file in the Escanor folder under Downloads and copied to the clipboard, so it can be pasted;
 *  - a small file: saved there under a safe name (never overwriting, never opened, never run).
 * A notice on the screen says what arrived and from where. Nothing is sent anywhere and nothing is read from this computer.
 */

export const MAX_TEXT_CHARS = 100_000;
export const MAX_FILE_B64 = 330_000; // about 240 KB of file

export type ReceiveFs = { mkdir(dir: string): void; write(path: string, data: Buffer | string): void; exists(path: string): boolean };
export type ReceiveDeps = {
  /** Where received text and files are kept. */
  dir?: string;
  fs?: ReceiveFs;
  screen?: ScreenDeps;
  /** Puts text on the clipboard. False when no tool can. */
  clip?: (text: string) => Promise<boolean>;
  now?: () => number;
  platform?: NodeJS.Platform;
};
export type ReceiveResult = { ok: boolean; say: string; data?: { saved?: boolean; opened?: boolean; copied?: boolean } };

export const defaultDir = (home: string = homedir()): string => join(home, 'Downloads', 'Escanor');

const realFs: ReceiveFs = {
  mkdir: (dir) => void mkdirSync(dir, { recursive: true, mode: 0o700 }),
  write: (path, data) => writeFileSync(path, data, { mode: 0o600, flag: 'wx' }),
  exists: (path) => existsSync(path),
};

/** A file name that cannot leave the folder or hide: the last part only, plain characters, no leading dot, not too long. */
export function safeFileName(raw: unknown): string {
  const last = String(raw ?? '').replace(/\\/g, '/').split('/').pop() ?? '';
  const clean = last
    .replace(/[^\p{L}\p{N} ._+()-]+/gu, '_')
    .replace(/^[.\s]+/, '')
    .replace(/[\s.]+$/, '')
    .slice(0, 100);
  return clean || 'file';
}

/** `name`, or `name (2)`, `name (3)` ... until nothing is there already. */
export function uniqueName(dir: string, name: string, exists: (p: string) => boolean): string {
  if (!exists(join(dir, name))) return name;
  const dot = name.lastIndexOf('.');
  const [stem, ext] = dot > 0 ? [name.slice(0, dot), name.slice(dot)] : [name, ''];
  for (let i = 2; i < 1000; i++) {
    const n = `${stem} (${i})${ext}`;
    if (!exists(join(dir, n))) return n;
  }
  return `${stem}-${Date.now()}${ext}`;
}

export function clipboardSteps(platform: NodeJS.Platform, env: NodeJS.ProcessEnv): Array<{ cmd: string; args: string[] }> {
  if (platform === 'darwin') return [{ cmd: 'pbcopy', args: [] }];
  if (platform === 'win32') return [{ cmd: 'clip', args: [] }];
  const wayland = Boolean(env.WAYLAND_DISPLAY) || env.XDG_SESSION_TYPE === 'wayland';
  const wl = { cmd: 'wl-copy', args: [] as string[] };
  const x = [{ cmd: 'xclip', args: ['-selection', 'clipboard'] }, { cmd: 'xsel', args: ['--clipboard', '--input'] }];
  return wayland ? [wl, ...x] : [...x, wl];
}

/** The real clipboard: the text goes to the tool on its standard input (never in arguments or a log). */
export function realClip(platform: NodeJS.Platform = process.platform, base: NodeJS.ProcessEnv = process.env): (text: string) => Promise<boolean> {
  return async (text) => {
    const env = desktopEnv(base, platform);
    for (const s of clipboardSteps(platform, env)) {
      const ok = await new Promise<boolean>((resolve) => {
        try {
          const p = spawn(s.cmd, s.args, { env, stdio: ['pipe', 'ignore', 'ignore'], windowsHide: true });
          const timer = setTimeout(() => (p.kill(), resolve(false)), 4000);
          p.on('error', () => (clearTimeout(timer), resolve(false)));
          p.on('close', (code) => (clearTimeout(timer), resolve(code === 0)));
          p.stdin?.on('error', () => {});
          p.stdin?.end(text);
        } catch {
          resolve(false);
        }
      });
      if (ok) return true;
    }
    return false;
  };
}

const who = (raw: unknown): string => String(raw ?? '').replace(/[^\p{L}\p{N} ._'()-]+/gu, ' ').trim().slice(0, 60) || 'your other device';
const hostOf = (url: string): string => {
  try {
    return new URL(url).hostname;
  } catch {
    return 'a page';
  }
};

/** Take what another of the owner's devices handed over. The arguments are checked here again, whatever the hub passed. */
export async function receiveHandoff(args: Record<string, unknown>, d: ReceiveDeps = {}): Promise<ReceiveResult> {
  const kind = args.kind;
  const from = who(args.from);
  const fs = d.fs ?? realFs;
  const dir = d.dir ?? defaultDir();
  const stamp = new Date((d.now ?? Date.now)()).toISOString().replace(/[:T]/g, '-').slice(0, 19);
  const tell = (title: string, body: string) => notice(title, body, 8000, d.screen ?? {}, 'normal').catch(() => null);
  if (kind === 'link') {
    const url = typeof args.url === 'string' ? safeUrl(args.url) : null;
    if (!url || url.startsWith('mailto:')) return { ok: false, say: 'Only web pages (http or https) can be handed over.' };
    const r = await openPage(url, d.screen);
    if (!r.ok) return { ok: false, say: 'Could not open that page in a browser here.' };
    await tell('Escanor', `Opened ${hostOf(url)}, sent from ${from}.`);
    return { ok: true, say: `Opened ${hostOf(url)}, sent from ${from}.`, data: { opened: true } };
  }
  if (kind === 'text') {
    const text = typeof args.text === 'string' ? args.text.replace(/\0/g, '') : '';
    if (!text.trim()) return { ok: false, say: 'There was no text to receive.' };
    if (text.length > MAX_TEXT_CHARS) return { ok: false, say: 'That text is too long to receive.' };
    let saved = false;
    let name = '';
    try {
      fs.mkdir(dir);
      name = uniqueName(dir, `note-${stamp}.txt`, fs.exists.bind(fs) as (p: string) => boolean);
      fs.write(join(dir, name), text);
      saved = true;
    } catch {
      saved = false;
    }
    const copied = await (d.clip ?? realClip(d.platform))(text).catch(() => false);
    if (!saved && !copied) return { ok: false, say: 'Could not save or copy the text on this computer.' };
    const where = saved ? `saved as ${name} in ${dir}` : 'not saved';
    const say = `Text from ${from}: ${copied ? 'copied, ready to paste' : 'not copied'}, ${where}.`;
    await tell(`Text from ${from}`, copied ? 'It is copied: paste it where you want it.' : `Saved in ${dir}.`);
    return { ok: true, say, data: { saved, copied } };
  }
  if (kind === 'file') {
    const b64 = typeof args.dataB64 === 'string' ? args.dataB64 : '';
    if (!b64 || b64.length > MAX_FILE_B64 || !/^[A-Za-z0-9+/=]+$/.test(b64)) return { ok: false, say: 'The file did not arrive in a form this computer can take.' };
    const bytes = Buffer.from(b64, 'base64');
    if (bytes.length === 0) return { ok: false, say: 'The file was empty.' };
    try {
      fs.mkdir(dir);
      const name = uniqueName(dir, safeFileName(args.name), fs.exists.bind(fs) as (p: string) => boolean);
      fs.write(join(dir, name), bytes);
      await tell(`File from ${from}`, `Saved as ${name} in ${dir}.`);
      return { ok: true, say: `Saved ${name} from ${from} in ${dir}.`, data: { saved: true } };
    } catch {
      return { ok: false, say: 'Could not save the file on this computer.' };
    }
  }
  return { ok: false, say: 'This computer does not know how to take that.' };
}
