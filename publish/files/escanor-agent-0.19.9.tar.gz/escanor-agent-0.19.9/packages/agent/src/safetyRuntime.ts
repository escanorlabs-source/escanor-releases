import { execFile, spawn } from 'node:child_process';
import { homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import type { AgentSafetyAlert, AgentSafetyResult, AgentSafetyState, HubSafetyAction, HubSafetyGet, SafetyState } from '@remote-harness/shared';
import { riskHoldsOn } from './riskHold.js';
import { claudeSettingsFiles, installSafetyHook, type GuardStatus } from './machineGuard.ts';
import { SafetyAgent } from './safetyAgent.ts';
import { logSafety, readSafetyEvents } from './safetyLog.ts';
import { safetyEnabled } from './safetySwitch.ts';
import { Tripwire } from './tripwire.ts';
import { snapshotDirs, UndoStore } from './undo.ts';

/**
 * Everything the safety layer runs inside the agent: the check for its own chats (SafetyAgent), the machine-wide guard in every
 * Claude settings file (kept in place every minute), the undo copies (pruned hourly, a daily safety snapshot), the tripwire, and
 * the apps' requests (safety_get / safety_action).
 */
export class SafetyRuntime {
  readonly agent: SafetyAgent;
  readonly store: UndoStore;
  private guard: GuardStatus[] = [];
  private tripwire: Tripwire | null = null;
  private timers: NodeJS.Timeout[] = [];
  private expectedAt = 0;
  private expectedPaths: string[] = [];

  constructor(private readonly o: { send: (msg: AgentSafetyAlert) => void; configDirs: () => string[]; env?: NodeJS.ProcessEnv; home?: string }) {
    this.store = new UndoStore({ home: o.home });
    this.agent = new SafetyAgent({ store: this.store });
  }

  start(): void {
    this.keepGuard();
    this.timers.push(setInterval(() => this.keepGuard(), 60_000));
    const housekeeping = () => {
      try {
        this.store.prune();
      } catch {
        /* next hour */
      }
      this.snapshotSoon();
    };
    this.timers.push(setTimeout(housekeeping, 5 * 60_000), setInterval(housekeeping, 3_600_000));
    for (const t of this.timers) t.unref();
    this.tripwire = new Tripwire({
      home: this.o.home ?? homedir(),
      ignore: [this.store.root],
      // What the gate just kept a copy of before letting it be deleted (any Claude here logs it): an expected delete, not counted.
      expected: () => {
        const now = Date.now();
        if (now - this.expectedAt > 2000) {
          this.expectedAt = now;
          this.expectedPaths = readSafetyEvents(this.store.root, 300).filter((e) => e.action === 'backup' && now - e.at < 60_000).flatMap((e) => e.paths ?? []);
        }
        return this.expectedPaths;
      },
      onTrip: (t) => {
        logSafety(this.store.root, { at: t.at, action: 'trip', source: 'tripwire', why: t.reason, paths: t.deleted.slice(0, 20) });
        this.o.send({ type: 'safety_alert', trip: { at: t.at, reason: t.reason, deleted: t.deleted.slice(0, 30), paused: t.paused.length } });
        notifyHere('Escanor paused every AI on this computer', `${t.reason} Open Escanor to Resume or Stop.`);
        console.warn(`Safety tripwire: ${t.reason} Paused ${t.paused.length} AI processes.`);
      },
    });
    this.tripwire.start();
    console.log(`Safety: undo copies in ${this.store.root}; guard in ${this.guard.filter((g) => g.state === 'set' || g.state === 'already').length}/${this.guard.length} Claude settings files; tripwire on`);
  }

  stop(): void {
    for (const t of this.timers) clearInterval(t);
    this.tripwire?.stop();
  }

  private keepGuard(): void {
    try {
      this.guard = installSafetyHook({ root: this.store.root, enabled: true, files: claudeSettingsFiles(this.o.home ?? homedir(), this.o.env ?? process.env, this.o.configDirs()) });
      const put = this.guard.filter((g) => g.state === 'set');
      if (put.length) logSafety(this.store.root, { at: Date.now(), action: 'guard', source: 'agent', why: `safety check put in ${put.map((g) => g.file).join(', ')}` });
    } catch (err) {
      console.error('Safety guard:', err instanceof Error ? err.message : err);
    }
  }

  /** The daily snapshot runs in its own low-priority process (it may walk many files). */
  private snapshotSoon(): void {
    const hook = fileURLToPath(new URL('./safetyHook.ts', import.meta.url));
    const [maj, min] = process.versions.node.split('.').map(Number);
    const loader = maj > 22 || (maj === 22 && min >= 6) ? ['--experimental-strip-types', '--no-warnings'] : ['--import', fileURLToPath(import.meta.resolve('tsx'))];
    const args = [...loader, hook, `--root=${this.store.root}`, '--snapshot', ...snapshotDirs(this.store.home)];
    const child = process.platform === 'win32' ? spawn(process.execPath, args, { stdio: 'ignore', windowsHide: true }) : spawn('nice', ['-n', '19', process.execPath, ...args], { stdio: 'ignore' });
    child.on('error', () => {});
    child.unref();
  }

  state(): SafetyState {
    const t = this.tripwire?.state ?? null;
    return {
      enabled: true,
      holds: riskHoldsOn(this.o.env ?? process.env),
      guard: { set: this.guard.filter((g) => g.state === 'set' || g.state === 'already').length, files: this.guard.length },
      tripped: t ? { at: t.at, reason: t.reason, deleted: t.deleted.slice(0, 30), paused: t.paused.length } : null,
      canPause: process.platform !== 'win32',
      undo: this.store.list(100),
      events: readSafetyEvents(this.store.root, 100).map(({ session: _s, ...e }) => e),
    };
  }

  handle(msg: HubSafetyGet | HubSafetyAction): AgentSafetyState | AgentSafetyResult {
    if (msg.type === 'safety_get') return { type: 'safety_state', requestId: msg.requestId, state: this.state() };
    const result = (ok: boolean, message: string): AgentSafetyResult => ({ type: 'safety_result', requestId: msg.requestId, ok, message, state: this.state() });
    if (msg.action === 'restore') {
      if (!msg.undoId) return result(false, 'Which copy?');
      const r = this.store.restore(msg.undoId);
      if (r.ok) logSafety(this.store.root, { at: Date.now(), action: 'restore', source: 'app', undoId: msg.undoId, why: `${r.restored} back, ${r.kept} already there` });
      const words = r.ok ? `Put back ${r.restored} file${r.restored === 1 ? '' : 's'}${r.kept ? ` (${r.kept} already there were left as they are)` : ''}.${r.notes.length ? ` ${r.notes.join('. ')}.` : ''}` : r.notes.join(' ');
      return result(r.ok, words);
    }
    if (msg.action === 'resume' || msg.action === 'stop') {
      const done = msg.action === 'resume' ? this.tripwire?.resume() : this.tripwire?.end();
      if (!done) return result(false, 'Nothing is paused right now.');
      logSafety(this.store.root, { at: Date.now(), action: msg.action, source: 'app' });
      return result(true, msg.action === 'resume' ? 'The AIs on this computer carry on.' : 'The paused AI programs were stopped.');
    }
    return result(false, 'Unknown action.');
  }
}

/** Starts the safety layer, unless it is off or this machine runs chats isolated (a worker container, chat users). */
export function startSafety(o: { send: (msg: AgentSafetyAlert) => void; configDirs: () => string[]; managed: boolean; chatUsers: boolean; env?: NodeJS.ProcessEnv }): SafetyRuntime | null {
  const env = o.env ?? process.env;
  if (!safetyEnabled(env)) {
    // Off: the guard is taken out of every Claude settings file again.
    try {
      installSafetyHook({ root: new UndoStore().root, enabled: false, files: claudeSettingsFiles(homedir(), env, o.configDirs()) });
    } catch {
      /* nothing there */
    }
    console.log('Safety: off (ESCANOR_SAFETY=0)');
    return null;
  }
  if (o.managed || o.chatUsers) return null;
  const rt = new SafetyRuntime({ send: o.send, configDirs: o.configDirs, env });
  rt.start();
  return rt;
}

function notifyHere(title: string, body: string): void {
  const done = () => {};
  if (process.platform === 'linux') execFile('notify-send', ['-u', 'critical', '-a', 'Escanor', title, body], done);
  else if (process.platform === 'darwin') execFile('osascript', ['-e', `display notification ${JSON.stringify(body)} with title ${JSON.stringify(title)}`], done);
}
