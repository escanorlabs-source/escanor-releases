import { createServer, connect, type Server, type Socket } from 'node:net';
import { chmodSync, existsSync, unlinkSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { AgentToHubMessage, HubUserInput } from '@remote-harness/shared';
import { parseMeshRequest, type MeshReply } from './meshAsk.js';
import { parsePhoneAsk, type PhoneReply } from './phoneAsk.js';
import type { BridgeAnswer, BridgeRequest } from './voiceAssistant.js';

/**
 * The running agent's side of push-to-talk. `escanor-agent voice` is a separate short program (a keyboard shortcut starts it); it
 * reaches the agent through a socket in the agent's data folder that only this computer's user can open (mode 0600). Through it the
 * agent answers "what is Escanor doing", starts the short chat turn a spoken request becomes (a chat like any other: it shows in
 * the phone's Machines, its safety rules and holds apply) and waits for its answer, and keeps the screen awake.
 */

export function socketPath(dataDir: string, platform: NodeJS.Platform = process.platform): string {
  if (platform === 'win32') return `\\\\.\\pipe\\escanor-agent-voice-${createHash('sha256').update(dataDir).digest('hex').slice(0, 16)}`;
  return join(dataDir, 'voice.sock');
}

const MAX_LINE = 20_000;
const CHAT_WAIT_MS = 120_000;

// ---------------------------------------------------------------------------------------------- one voice chat

type Waiting = { tempId: string; sessionId?: string; done: (a: BridgeAnswer) => void; timer: ReturnType<typeof setTimeout> };

/** The short chats voice starts here, and what each one answered. Fed every message the agent sends (observe). */
export class VoiceChats {
  private waiting = new Map<string, Waiting>();

  constructor(
    private readonly d: {
      admit: (input: HubUserInput) => void;
      waitMs?: number;
    },
  ) {}

  /** Start a chat with [text] and wait for its answer (or say it is still working). */
  start(text: string): Promise<BridgeAnswer> {
    const tempId = `voice-${randomUUID()}`;
    return new Promise((resolve) => {
      const done = (a: BridgeAnswer) => {
        const w = this.waiting.get(tempId);
        if (!w) return;
        clearTimeout(w.timer);
        this.waiting.delete(tempId);
        resolve(a);
      };
      const timer = setTimeout(() => done({ ok: true, say: 'It is still working. The answer will be in your Machines chats.' }), this.d.waitMs ?? CHAT_WAIT_MS);
      timer.unref?.();
      this.waiting.set(tempId, { tempId, done, timer });
      try {
        this.d.admit({ type: 'user_input', sessionId: tempId, tempId, text, fresh: true });
      } catch {
        done({ ok: false, say: 'I could not start that on this computer.' });
      }
    });
  }

  observe(msg: AgentToHubMessage): void {
    if (this.waiting.size === 0) return;
    if (msg.type === 'session_created') {
      const w = this.waiting.get(msg.tempId);
      if (w) w.sessionId = msg.sessionId;
      return;
    }
    const mine = (id: string | undefined, temp: string | undefined): Waiting | undefined => {
      if (temp && this.waiting.has(temp)) return this.waiting.get(temp);
      if (!id) return undefined;
      for (const w of this.waiting.values()) if (w.sessionId === id || w.tempId === id) return w;
      return undefined;
    };
    if (msg.type === 'sdk_message') {
      const w = mine(msg.sessionId, msg.tempId);
      const m = msg.message as { type?: string; result?: unknown; is_error?: boolean; subtype?: string } | undefined;
      if (w && m?.type === 'result') {
        const text = typeof m.result === 'string' ? m.result.trim() : '';
        if (m.is_error || (m.subtype && m.subtype !== 'success')) w.done({ ok: false, say: text || 'That did not work.' });
        else w.done({ ok: true, say: text || 'Done.' });
      }
    } else if (msg.type === 'permission_request') {
      const w = mine(msg.sessionId, undefined);
      if (w) w.done({ ok: true, say: 'It needs your OK before it goes on. Answer on your phone.' });
    } else if (msg.type === 'session_ended' || msg.type === 'session_deleted') {
      const w = mine(msg.sessionId, undefined);
      if (w) w.done({ ok: false, say: 'That chat ended without an answer.' });
    }
  }
}

// ---------------------------------------------------------------------------------------------- the server

export type BridgeHandlers = {
  chat: (text: string) => Promise<BridgeAnswer>;
  status: () => string[];
  wake: () => Promise<boolean>;
  keepAwake: (minutes: number) => Promise<boolean>;
  /**
   * A program on this computer (an automation, or the AI in a chat) asks to sign something in or run sudo with a saved secret. It waits
   * for the owner's fingerprint on the phone (signinApproval.ts); the answer is plain words and never holds a value. Absent: not offered.
   */
  signin?: (args: Record<string, unknown>, source: 'ai' | 'automation') => Promise<BridgeAnswer>;
  /** One request to the owner's phone through the hub (phoneAsk.ts). Absent where this agent cannot ask the phone. */
  phone?: (ask: import('./phoneAsk.js').PhoneAsk) => Promise<PhoneReply>;
  /** One request about the owner's other devices through the backend (meshAsk.ts): list, command, handoff, ask. */
  mesh?: (req: import('./meshAsk.js').MeshRequest) => Promise<MeshReply>;
};

/** What the agent says about itself: the chats working, in plain words. */
export function statusSay(lines: string[]): string {
  if (lines.length === 0) return 'Nothing is running on this computer right now.';
  const head = lines.length === 1 ? 'One thing is running on this computer.' : `${lines.length} things are running on this computer.`;
  return `${head} ${lines.slice(0, 3).join('. ')}.`.replace(/\.\.$/, '.');
}

export async function handle(req: unknown, h: BridgeHandlers): Promise<BridgeAnswer> {
  const r = (req && typeof req === 'object' ? req : {}) as Record<string, unknown>;
  switch (r.op) {
    case 'chat': {
      const text = typeof r.text === 'string' ? r.text.trim().slice(0, 4000) : '';
      if (!text) return { ok: false, say: 'There was nothing to ask.' };
      return h.chat(text);
    }
    case 'status':
      return { ok: true, say: statusSay(h.status()) };
    case 'wake':
      return (await h.wake()) ? { ok: true, say: 'The screen is awake.' } : { ok: false, say: 'Could not wake the screen from here.' };
    case 'keep_awake': {
      const n = Math.min(240, Math.max(1, Math.floor(Number(r.minutes) || 30)));
      return (await h.keepAwake(n)) ? { ok: true, say: `Keeping the screen awake for ${n} minutes.` } : { ok: false, say: 'Could not keep the screen awake from here.' };
    }
    case 'signin':
    case 'sudo': {
      if (!h.signin) return { ok: false, say: 'Signing in with a saved secret is not available here.' };
      const source = r.source === 'ai' ? 'ai' : 'automation';
      const args = r.op === 'sudo' ? { kind: 'sudo', argv: r.argv, why: r.why } : { kind: r.kind, account: r.account, argv: r.argv, why: r.why, force: r.force };
      for (const k of Object.keys(args) as (keyof typeof args)[]) if (args[k] === undefined) delete args[k];
      return h.signin(args as Record<string, unknown>, source);
    }
    case 'phone': {
      if (!h.phone) return { ok: false, say: 'This computer is not set up to ask your phone yet.' };
      const raw = (r.ask && typeof r.ask === 'object' ? r.ask : {}) as { action?: unknown; args?: unknown };
      const p = parsePhoneAsk({ ...(raw.args && typeof raw.args === 'object' ? raw.args : {}), action: raw.action });
      if (!p.ok) return { ok: false, say: p.error };
      const a = await h.phone(p.ask);
      return { ok: a.ok, say: a.say };
    }
    case 'mesh': {
      if (!h.mesh) return { ok: false, say: 'This computer is not set up to reach your other devices yet.' };
      const p = parseMeshRequest((r as { req?: unknown }).req);
      if (!p.ok) return { ok: false, say: p.error };
      const a = await h.mesh(p.req);
      return { ok: a.ok, say: a.say };
    }
    default:
      return { ok: false, say: 'The agent does not know that request.' };
  }
}

/** Listen on the agent's socket. Only this computer's user can open it. Returns null when it could not (the agent carries on without voice). */
export function serveBridge(path: string, h: BridgeHandlers, log: (s: string) => void = () => undefined): Server | null {
  try {
    if (!path.startsWith('\\\\') && existsSync(path)) unlinkSync(path); // a leftover from an agent that was killed
    const server = createServer((sock: Socket) => {
      let buf = '';
      sock.setEncoding('utf8');
      sock.on('error', () => undefined);
      sock.on('data', (chunk: string) => {
        buf += chunk;
        if (buf.length > MAX_LINE) return void sock.destroy();
        const nl = buf.indexOf('\n');
        if (nl < 0) return;
        const line = buf.slice(0, nl);
        buf = '';
        let req: unknown = null;
        try {
          req = JSON.parse(line);
        } catch {
          req = null;
        }
        void handle(req, h).then((a) => sock.end(`${JSON.stringify(a)}\n`), () => sock.end(`${JSON.stringify({ ok: false, say: 'Something went wrong.' })}\n`));
      });
    });
    server.on('error', (e) => log(`voice socket: ${e.message}`));
    server.listen(path, () => {
      if (!path.startsWith('\\\\')) {
        try {
          chmodSync(path, 0o600);
        } catch {
          // best effort: the folder is the person's own
        }
      }
    });
    return server;
  } catch (e) {
    log(`voice socket not started: ${e instanceof Error ? e.message : e}`);
    return null;
  }
}

// ---------------------------------------------------------------------------------------------- the client

/** Ask the running agent. Rejects when nobody listens. */
export function askBridge(path: string, req: BridgeRequest, timeoutMs = CHAT_WAIT_MS + 5000): Promise<BridgeAnswer> {
  return new Promise((resolve, reject) => {
    const sock = connect(path);
    let buf = '';
    const timer = setTimeout(() => {
      sock.destroy();
      reject(new Error('no answer'));
    }, timeoutMs);
    timer.unref?.();
    sock.setEncoding('utf8');
    sock.on('connect', () => sock.write(`${JSON.stringify(req)}\n`));
    sock.on('data', (c: string) => (buf += c));
    sock.on('error', (e) => {
      clearTimeout(timer);
      reject(e);
    });
    sock.on('close', () => {
      clearTimeout(timer);
      try {
        const a = JSON.parse(buf.trim()) as BridgeAnswer;
        if (typeof a.say === 'string') return resolve({ ok: a.ok === true, say: a.say });
      } catch {
        // fall through
      }
      reject(new Error('unreadable answer'));
    });
  });
}
