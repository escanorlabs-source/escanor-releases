/**
 * Hides secrets in a line that leaves this machine (a chat's step, a test command, the tail of a test run): tokens with a
 * known shape, `KEY=value` / `token: value` pairs whose name says secret, bearer headers and credentials inside URLs.
 * Best effort on purpose: what is shown is a short line or a tail, never an environment or a full process command line.
 */
const PATTERNS: Array<[RegExp, string]> = [
  [/(\b[a-z][a-z0-9+.-]*:\/\/)[^\s/@:]+:[^\s/@]+@/gi, '$1***@'],
  [/\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{4,}/gi, '$1 ***'],
  [/\b(gh[pousr]_[A-Za-z0-9]{8,}|github_pat_[A-Za-z0-9_]{8,}|glpat-[A-Za-z0-9_-]{8,})/g, '***'],
  [/\b(sk|rk|pk)-(?:[a-z]+-)?[A-Za-z0-9_-]{12,}/g, '***'],
  [/\bxox[abposr]-[A-Za-z0-9-]+/g, '***'],
  [/\bescanor_[A-Za-z0-9_-]{6,}/g, '***'],
  [/\b(AKIA|ASIA)[0-9A-Z]{16}\b/g, '***'],
  [/\bAIza[0-9A-Za-z_-]{20,}/g, '***'],
  [/\bAQ\.[0-9A-Za-z_.-]{20,}/g, '***'], // Google AI Studio's newer key shape
  [/\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]*/g, '***'],
  [/([A-Za-z0-9_-]*(?:token|secret|passw(?:or)?d|pwd|api[_-]?key|auth|credential|private[_-]?key)[A-Za-z0-9_-]*["']?\s*[=:]\s*)("[^"]*"|'[^']*'|[^\s"',;&|]+)/gi, '$1***'],
];

export function redact(text: string): string {
  let out = text;
  for (const [re, to] of PATTERNS) out = out.replace(re, to);
  return out;
}

/** One line, at most `max` characters, secrets hidden. */
export function oneLine(text: string, max: number): string {
  const line = redact(String(text)).replace(/\s+/g, ' ').trim();
  return line.length > max ? `${line.slice(0, max - 1)}…` : line;
}
