/**
 * Embedded mode: the agent started by Escanor Desktop as a child process (spec: agent-embed-spec.md).
 *
 * stdin  = a config line, then commands, one JSON object per line
 * stdout = events only, one JSON object per line (everything the agent prints goes to stderr instead)
 * stderr = human log
 *
 * This file holds the parts that can be tested without starting the agent: reading and checking the settings, the
 * one-agent-per-folder lock, and the control channel. embed.ts wires them to the real process and to index.ts.
 */
import { closeSync, mkdirSync, openSync, readFileSync, renameSync, rmSync, statSync, utimesSync, writeFileSync, constants } from 'node:fs';
import { homedir } from 'node:os';
import { isAbsolute, join, parse, resolve, sep } from 'node:path';
import type { HubLinkStatus } from './wsClient.js';

export const EMBED_PROTOCOL = 1;
export const HEARTBEAT_MS = 15_000;
export const CONFIG_WAIT_MS = 30_000;
/** A lock not touched for this long is dead even if its pid answers (the pid was reused). */
export const LOCK_STALE_MS = 60_000;
export const MAX_LINE = 1_000_000;

/** Exit codes the host can act on. */
export const EXIT = { ok: 0, crash: 1, badConfig: 2, configTimeout: 3, alreadyRunning: 4, dataDir: 5 } as const;

/** Agent switches the host may set (anything else is ignored with a warning). */
export const ENV_ALLOW = [
  'AUTO_RESUME', 'KEEP_AWAKE_WHILE_WORKING', 'MACHINE_STATE', 'CLEAN_SMALL_SESSIONS', 'SYNC_TERMINAL_SESSIONS', 'PHONE_TO_TERMINAL',
  'ESCANOR_LEGACY_MACHINE_IDS', 'ESCANOR_REPAIR', 'MAX_OPEN_SESSIONS', 'MAX_LIVE_SESSIONS', 'ESCANOR_PREVIEW_OPEN', 'ESCANOR_PREVIEW_LINK', 'FIX_TESTS', 'DEFAULT_PERMISSION_MODE',
] as const;

export type EmbedConfig = {
  hubUrl: string;
  token: string;
  machineId: string;
  dataDir: string;
  name?: string;
  kind: 'personal';
  workspaceRoot: string;
  projectsRoot?: string;
  profilesDir?: string;
  env: Record<string, string>;
  ignoredEnv: string[];
};

export type ConfigResult = { ok: true; config: EmbedConfig } | { ok: false; field: string; message: string };

const bad = (field: string, message: string): ConfigResult => ({ ok: false, field, message });
const str = (v: unknown): string => (typeof v === 'string' ? v.trim() : '');

const isLoopback = (host: string) => host === 'localhost' || host === '127.0.0.1' || host === '[::1]' || host === '::1';

/**
 * Checks the settings the host sent (or the environment gave). Pure: no files are touched. `home` is the person's home folder, which a
 * workspace must not be (it holds ~/.ssh and the shell's rc files).
 */
export function parseEmbedConfig(raw: unknown, home: string = homedir()): ConfigResult {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return bad('config', 'The settings are not a JSON object.');
  const o = raw as Record<string, unknown>;
  if (o.v !== undefined && o.v !== EMBED_PROTOCOL) return bad('v', `Protocol version ${String(o.v)} is not supported (this agent speaks ${EMBED_PROTOCOL}).`);

  const hubUrl = str(o.hubUrl);
  let url: URL;
  try {
    url = new URL(hubUrl);
  } catch {
    return bad('hubUrl', 'hubUrl is missing or not a web address.');
  }
  if (url.protocol !== 'wss:' && !(url.protocol === 'ws:' && isLoopback(url.hostname))) return bad('hubUrl', 'hubUrl must be wss:// (ws:// only for this computer).');

  const token = str(o.token);
  if (!token) return bad('token', 'token is missing.');
  if (/[\r\n\0]/.test(token) || token.length > 4096) return bad('token', 'token is not valid.');

  const machineId = str(o.machineId);
  if (!/^[A-Za-z0-9._:-]{8,128}$/.test(machineId)) return bad('machineId', 'machineId must be 8-128 letters, digits or . _ : -');

  const dataDir = str(o.dataDir);
  if (!dataDir || !isAbsolute(dataDir)) return bad('dataDir', 'dataDir must be an absolute folder.');

  const kind = o.kind === undefined ? 'personal' : o.kind;
  if (kind !== 'personal') return bad('kind', 'Only kind "personal" is accepted when the agent runs inside Escanor Desktop.');

  const workspaceRoot = str(o.workspaceRoot) || join(home, 'Escanor');
  if (!isAbsolute(workspaceRoot)) return bad('workspaceRoot', 'workspaceRoot must be an absolute folder.');
  const same = (a: string, b: string) => (process.platform === 'win32' ? a.toLowerCase() === b.toLowerCase() : a === b);
  const tooBroad = (p: string) => {
    const r = resolve(p);
    const h = resolve(home);
    // A drive or filesystem root, the home folder, or any folder that holds the home folder (/home, C:\\Users).
    return parse(r).root === r || same(r, h) || (process.platform === 'win32' ? h.toLowerCase() : h).startsWith((process.platform === 'win32' ? r.toLowerCase() : r) + sep);
  };
  const wsResolved = resolve(workspaceRoot);
  if (tooBroad(wsResolved)) return bad('workspaceRoot', 'workspaceRoot must be a folder of its own, not the home folder, a folder holding it, or a whole drive.');
  for (const f of ['projectsRoot', 'profilesDir'] as const) {
    if (o[f] !== undefined && (!str(o[f]) || !isAbsolute(str(o[f])))) return bad(f, `${f} must be an absolute folder.`);
  }
  if (str(o.projectsRoot) && tooBroad(str(o.projectsRoot))) return bad('projectsRoot', 'projectsRoot must not be the home folder, a folder holding it, or a whole drive.');

  const env: Record<string, string> = {};
  const ignoredEnv: string[] = [];
  if (o.env !== undefined) {
    if (!o.env || typeof o.env !== 'object' || Array.isArray(o.env)) return bad('env', 'env must be an object.');
    for (const [k, v] of Object.entries(o.env as Record<string, unknown>)) {
      if ((ENV_ALLOW as readonly string[]).includes(k) && (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean')) env[k] = String(v);
      else ignoredEnv.push(k);
    }
  }

  const name = str(o.name).replace(/[\r\n\0]/g, ' ').slice(0, 80);
  return {
    ok: true,
    config: {
      hubUrl: url.toString(),
      token,
      machineId,
      dataDir: resolve(dataDir),
      ...(name ? { name } : {}),
      kind: 'personal',
      workspaceRoot: wsResolved,
      ...(str(o.projectsRoot) ? { projectsRoot: resolve(str(o.projectsRoot)) } : {}),
      ...(str(o.profilesDir) ? { profilesDir: resolve(str(o.profilesDir)) } : {}),
      env,
      ignoredEnv,
    },
  };
}

/** The settings as the environment variables of the other entry point (HUB_URL, HUB_TOKEN, ...), when those are already set. */
export function configFromEnv(env: NodeJS.ProcessEnv): Record<string, unknown> | null {
  const token = env.HUB_TOKEN?.trim() || (env.HUB_TOKEN_FILE?.trim() ? readFileSync(env.HUB_TOKEN_FILE.trim(), 'utf8').trim() : '');
  if (!env.HUB_URL?.trim() || !token) return null;
  const out: Record<string, unknown> = { v: EMBED_PROTOCOL, hubUrl: env.HUB_URL.trim(), token, machineId: env.ESCANOR_MACHINE_ID, dataDir: env.DATA_DIR };
  if (env.VM_NAME) out.name = env.VM_NAME;
  if (env.ESCANOR_MACHINE_KIND) out.kind = env.ESCANOR_MACHINE_KIND;
  if (env.WORKSPACE_ROOT) out.workspaceRoot = env.WORKSPACE_ROOT;
  if (env.PROJECTS_ROOT) out.projectsRoot = env.PROJECTS_ROOT;
  if (env.PROFILES_DIR) out.profilesDir = env.PROFILES_DIR;
  return out;
}

/** Puts the settings where the agent reads them (process.env, before index.ts is loaded). */
export function applyConfigToEnv(c: EmbedConfig, env: NodeJS.ProcessEnv): void {
  env.ESCANOR_EMBEDDED = '1';
  env.HUB_URL = c.hubUrl;
  env.HUB_TOKEN = c.token;
  delete env.HUB_TOKEN_FILE;
  env.ESCANOR_MACHINE_ID = c.machineId;
  env.ESCANOR_MACHINE_KIND = c.kind;
  env.DATA_DIR = c.dataDir;
  env.WORKSPACE_ROOT = c.workspaceRoot;
  env.PROJECTS_ROOT = c.projectsRoot ?? c.workspaceRoot;
  if (c.profilesDir) env.PROFILES_DIR = c.profilesDir;
  if (c.name) env.VM_NAME = c.name;
  else delete env.VM_NAME;
  // The agent does not edit the person's Claude Code settings unless the host asks.
  env.PHONE_TO_TERMINAL = '0';
  for (const [k, v] of Object.entries(c.env)) env[k] = v;
}

/** Replaces every occurrence of a secret in text (an error message must never carry the token). */
export function scrub(text: string, secrets: string[]): string {
  let out = text;
  for (const s of secrets) {
    if (s.length < 6) continue;
    out = out.split(s).join('[hidden]');
    const encoded = JSON.stringify(s).slice(1, -1); // the form it takes inside a JSON line
    if (encoded !== s) out = out.split(encoded).join('[hidden]');
  }
  return out;
}

// ---- one agent per data folder ------------------------------------------------------------------------------------------------

export type LockDeps = { pid?: number; now?: () => number; alive?: (pid: number) => boolean };

const defaultAlive = (pid: number): boolean => {
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'EPERM';
  }
};

export type AgentLock = { path: string; touch: () => void; release: () => void; owned: () => boolean };

/**
 * <dataDir>/agent.lock holds the pid of the agent using that folder. Another start finds it and gives way only if that pid is gone or
 * the file has not been touched for LOCK_STALE_MS (the agent touches it with every heartbeat, so a reused pid is not mistaken for it).
 * Throws {code:'already_running'} or {code:'data_dir'}.
 */
export function acquireLock(dataDir: string, deps: LockDeps = {}): AgentLock {
  const pid = deps.pid ?? process.pid;
  const now = deps.now ?? Date.now;
  const alive = deps.alive ?? defaultAlive;
  const path = join(dataDir, 'agent.lock');
  try {
    mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  } catch (err) {
    throw Object.assign(new Error(`The data folder cannot be created: ${(err as Error).message}`), { code: 'data_dir' });
  }
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = openSync(path, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY, 0o600);
      try {
        writeFileSync(fd, JSON.stringify({ pid, startedAt: new Date(now()).toISOString() }));
      } finally {
        closeSync(fd);
      }
      return {
        path,
        owned: () => {
          try {
            return (JSON.parse(readFileSync(path, 'utf8')) as { pid?: number }).pid === pid;
          } catch {
            return false;
          }
        },
        touch: () => {
          try {
            const t = new Date(now());
            utimesSync(path, t, t);
          } catch {
            // the folder went away; the next start sorts it out
          }
        },
        release: () => {
          try {
            const held = JSON.parse(readFileSync(path, 'utf8')) as { pid?: number };
            if (held.pid === pid) rmSync(path, { force: true });
          } catch {
            // not ours or already gone
          }
        },
      };
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (code !== 'EEXIST') throw Object.assign(new Error(`The data folder is not writable: ${(err as Error).message}`), { code: 'data_dir' });
    }
    // Someone has it: live, or left behind?
    let holder = 0;
    let age = Infinity;
    let seen = '';
    try {
      seen = readFileSync(path, 'utf8');
      holder = Number((JSON.parse(seen) as { pid?: number }).pid) || 0;
      age = now() - statSync(path).mtimeMs;
    } catch {
      // unreadable lock = not a live agent's
    }
    if (holder && holder !== pid && alive(holder) && age < LOCK_STALE_MS) {
      throw Object.assign(new Error(`Another Escanor agent (process ${holder}) is already using this data folder.`), { code: 'already_running' });
    }
    // Stale: move it aside with a name of our own (atomic: of two agents racing for the same stale lock only one rename succeeds),
    // then try once more. A lock another agent made in the meantime is not ours to take, and the create above refuses it.
    const aside = `${path}.stale-${pid}-${now()}`;
    try {
      if (readFileSync(path, 'utf8') !== seen) continue; // it changed since we looked: someone just took it
      renameSync(path, aside);
      rmSync(aside, { force: true });
    } catch {
      // someone else took it first: the next round sees theirs
    }
  }
  throw Object.assign(new Error('Could not take the data folder lock.'), { code: 'already_running' });
}

// ---- the control channel ------------------------------------------------------------------------------------------------------

export type HealthState = 'starting' | 'connecting' | 'online' | 'offline' | 'stopping';

export type ControlIo = {
  /** One finished line (with its \n) to stdout. */
  write: (line: string) => void;
  now?: () => Date;
};

export type ControlRuntime = {
  agentVersion: string;
  connected: () => boolean;
  sessions: () => { total: number; active: number };
  reconnect: () => void;
  setToken: (token: string) => void;
  stop: () => void;
};

/**
 * Events out, commands in. The agent's state is told to it by `link()` (hub socket changes) and `setRuntime()` (once the agent is built).
 * Nothing here exits the process: `onStop` is called when the host asked for a stop, and embed.ts does the rest.
 */
export class EmbedControl {
  private state: HealthState = 'starting';
  private hub: { connected: boolean; since?: string; lastError?: string; reason?: string } = { connected: false };
  private everOnline = false;
  private authTold = false;
  private lastKey = '';
  private runtime: ControlRuntime | null = null;
  private timer: NodeJS.Timeout | null = null;
  private startedAt: number;
  private secrets: string[] = [];
  private id = { machineId: '', kind: 'personal' as string, agentVersion: '' };

  constructor(
    private io: ControlIo,
    private onStop: (reason: string) => void,
    private onBeat: () => void = () => undefined,
  ) {
    this.startedAt = (io.now ?? (() => new Date()))().getTime();
  }

  private ts(): string {
    return (this.io.now ?? (() => new Date()))().toISOString();
  }

  /** Words that must never appear in any event (the token). */
  hide(secret: string): void {
    if (secret) this.secrets.push(secret);
  }

  emit(type: string, fields: Record<string, unknown> = {}): void {
    const line = scrub(JSON.stringify({ v: EMBED_PROTOCOL, type, ts: this.ts(), ...fields }), this.secrets);
    this.io.write(`${line}\n`);
  }

  warning(code: string, message: string): void {
    this.emit('warning', { code, message });
  }

  error(code: string, message: string, fatal: boolean): void {
    this.emit('error', { code, message: scrub(message, this.secrets), fatal });
  }

  identify(machineId: string, kind: string): void {
    this.id.machineId = machineId;
    this.id.kind = kind;
  }

  setRuntime(r: ControlRuntime): void {
    this.runtime = r;
    this.id.agentVersion = r.agentVersion;
    if (this.state === 'starting') this.setState('connecting');
    this.health(false);
  }

  setState(state: HealthState): void {
    this.state = state;
    this.health(false);
  }

  /** The hub socket went up or down. */
  link(s: HubLinkStatus): void {
    if (this.state === 'stopping') return;
    if (s.connected) {
      this.authTold = false;
      this.everOnline = true;
      this.hub = { connected: true, since: this.ts() };
      this.state = 'online';
    } else {
      this.hub = { connected: false, ...(s.reason ? { reason: s.reason, lastError: s.reason } : {}) };
      this.state = this.everOnline ? 'offline' : 'connecting';
      // Told once per refusal, not at every retry.
      if (s.reason === 'auth' && !this.authTold) this.error('hub_auth', 'The hub refused the agent token. Fetch a new one and send update_token.', false);
      this.authTold = s.reason === 'auth';
    }
    this.health(false);
  }

  /** Emits when something changed or when forced (a command or the heartbeat). */
  health(force: boolean): void {
    const body = {
      state: this.state,
      hub: this.hub,
      machineId: this.id.machineId,
      kind: this.id.kind,
      agentVersion: this.id.agentVersion,
      sessions: this.runtime?.sessions() ?? { total: 0, active: 0 },
    };
    const key = JSON.stringify({ s: body.state, h: body.hub, n: body.sessions });
    if (!force && key === this.lastKey) return;
    this.lastKey = key;
    this.emit('health', { ...body, uptimeSec: Math.round(((this.io.now ?? (() => new Date()))().getTime() - this.startedAt) / 1000) });
  }

  startHeartbeat(ms = HEARTBEAT_MS): void {
    this.timer = setInterval(() => {
      try {
        this.onBeat();
      } catch {
        // a lock that cannot be touched must not stop the heartbeat
      }
      this.health(true);
    }, ms);
    this.timer.unref();
  }

  stopHeartbeat(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  /** One line from stdin after the config. Never throws. */
  command(line: string): void {
    let msg: Record<string, unknown>;
    try {
      const j = JSON.parse(line) as unknown;
      if (!j || typeof j !== 'object' || Array.isArray(j)) throw new Error('not an object');
      msg = j as Record<string, unknown>;
    } catch {
      this.error('protocol', 'A command line was not valid JSON.', false);
      return;
    }
    const id = typeof msg.id === 'string' ? msg.id.slice(0, 64) : undefined;
    const ack = (ok: boolean, error?: string) => {
      if (id !== undefined) this.emit('ack', { id, ok, ...(error ? { error } : {}) });
    };
    try {
      switch (msg.type) {
        case 'health':
          this.health(true);
          ack(true);
          return;
        case 'ping':
          ack(true);
          return;
        case 'reconnect':
          if (!this.runtime) return ack(false, 'The agent is not running yet.');
          this.runtime.reconnect();
          return ack(true);
        case 'update_token': {
          const t = typeof msg.token === 'string' ? msg.token.trim() : '';
          if (!t || /[\r\n\0]/.test(t) || t.length > 4096) return ack(false, 'token is not valid.');
          if (!this.runtime) return ack(false, 'The agent is not running yet.');
          this.hide(t);
          this.runtime.setToken(t);
          this.runtime.reconnect();
          return ack(true);
        }
        case 'stop':
          ack(true);
          this.setState('stopping');
          this.onStop(typeof msg.reason === 'string' ? msg.reason.slice(0, 80) : 'requested');
          return;
        default:
          this.error('protocol', `Unknown command "${String(msg.type).slice(0, 40)}".`, false);
          ack(false, 'unknown command');
      }
    } catch (err) {
      ack(false, err instanceof Error ? err.message : 'failed');
    }
  }
}

/** Splits a byte stream into lines, dropping (and reporting) any line longer than MAX_LINE. */
export class LineReader {
  private buf = '';
  private skipping = false;
  constructor(private onLine: (line: string) => void, private onTooLong: () => void = () => undefined) {}
  push(chunk: string): void {
    this.buf += chunk;
    let i: number;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).replace(/\r$/, '');
      this.buf = this.buf.slice(i + 1);
      if (this.skipping) {
        this.skipping = false;
        continue;
      }
      if (Buffer.byteLength(line) > MAX_LINE) this.onTooLong();
      else if (line.trim()) this.onLine(line);
    }
    if (this.buf.length > MAX_LINE) {
      this.buf = '';
      this.skipping = true;
      this.onTooLong();
    }
  }
}
