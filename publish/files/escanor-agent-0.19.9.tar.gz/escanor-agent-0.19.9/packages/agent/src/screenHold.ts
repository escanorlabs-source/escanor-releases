import { RISK_WHY, type Risk } from '../../shared/src/risk.ts';
import { parseMcpToolName } from './mcpApproval.js';
import { COMPUTER_MCP_NAME } from './computerMcp.js';

/**
 * Screen help's yeses (Jarvis phase 4), read by the chat's PreToolUse hook (sessionManager.ts) like mailHold.ts:
 *  - screen_help the first time on a computer: a held card, "take a picture of your screen when asked, send it to an AI model,
 *    keep nothing". Their Approve is the one-time consent (written by the hook); Autonomous chats count as the person's yes.
 *  - screen_do (a click, or a click and typing): held every time, in plain words naming the thing and what is typed. In an
 *    Autonomous chat it is allowed only with `app`, the one app the person named (the tool checks the screen shows that app).
 */

const str = (v: unknown): string => (typeof v === 'string' ? v : '');
const cut = (s: string, n: number): string => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

export type ScreenVerdict =
  | { kind: 'none' }
  | { kind: 'hold'; risk: Risk; grantsConsent: boolean }
  | { kind: 'allow'; grantsConsent: boolean }
  | { kind: 'deny'; message: string };

export function screenVerdict(toolName: string, input: unknown, o: { consented: boolean; autonomous: boolean }): ScreenVerdict {
  const p = parseMcpToolName(toolName);
  if (!p || p.server !== COMPUTER_MCP_NAME) return { kind: 'none' };
  const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  if (p.tool === 'screen_help') {
    if (o.consented) return { kind: 'none' };
    if (o.autonomous) return { kind: 'allow', grantsConsent: true };
    return { kind: 'hold', grantsConsent: true, risk: { kind: 'screen-act', why: RISK_WHY['screen-act'] + ' This is the first time: it takes one picture of your screen when you ask a question about it, sends it to an AI model on Escanor\'s server, and keeps nothing but a short text note.' } };
  }
  if (p.tool === 'screen_do') {
    if (o.autonomous) {
      return str(i.app).trim()
        ? { kind: 'allow', grantsConsent: false }
        : { kind: 'deny', message: 'In an Autonomous chat, clicking or typing on the screen is only done inside the one app the person named. Pass `app` with that app\'s name, or ask the person.' };
    }
    const what = i.kind === 'fill' ? `type “${cut(str(i.text), 60)}” into “${cut(str(i.label), 60)}”` : `click “${cut(str(i.label), 60)}”`;
    return { kind: 'hold', grantsConsent: false, risk: { kind: 'screen-act', why: `${RISK_WHY['screen-act']} (It will ${what}.)` } };
  }
  return { kind: 'none' };
}
