import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { homedir, hostname as osHostname } from 'node:os';
import { join } from 'node:path';

type IdOptions = { platform?: NodeJS.Platform; read?: (file: string) => string; run?: (cmd: string, args: string[]) => string; hostname?: string };

/** The operating system's own machine id (Linux /etc/machine-id, Windows MachineGuid, macOS hardware UUID), lower case; '' when none. */
function systemMachineRaw(o: IdOptions): string {
  const platform = o.platform ?? process.platform;
  const read = o.read ?? ((f: string) => readFileSync(f, 'utf8'));
  const run = o.run ?? ((c: string, a: string[]) => execFileSync(c, a, { encoding: 'utf8', timeout: 5000, windowsHide: true }));
  let raw = '';
  try {
    if (platform === 'linux') {
      for (const f of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
        try {
          raw = read(f).trim();
        } catch {
          // try the next
        }
        if (raw) break;
      }
    } else if (platform === 'win32') {
      const out = run('reg', ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid']);
      raw = /MachineGuid\s+REG_SZ\s+([0-9A-Fa-f-]{8,})/.exec(out)?.[1] ?? '';
    } else if (platform === 'darwin') {
      const out = run('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice']);
      raw = /"IOPlatformUUID"\s*=\s*"([0-9A-Fa-f-]{8,})"/.exec(out)?.[1] ?? '';
    }
  } catch {
    raw = '';
  }
  return raw.toLowerCase();
}

/**
 * One id for one computer, the same for every Escanor agent on it (the background service and the Desktop app's own agent), so the hub keeps
 * one record per computer. It comes from the operating system's own machine id only, hashed: the system id itself is never sent or stored.
 * It does NOT depend on the computer's name: a name that changes (macOS "-2.local", DHCP names) used to give a new id, so the hub made a
 * new machine and the chats of the old one read "not found". The older name-based id is sent as a legacy id (legacyMachineIds) so the hub
 * merges the old row into this one. Same shape as before (m- and 32 hex), which the hub's cleanMachineId accepts. null when the system gives none.
 */
export function stableMachineId(o: IdOptions = {}): string | null {
  const raw = systemMachineRaw(o);
  if (!raw) return null;
  return `m-${createHash('sha256').update(`escanor-machine-v2:${raw}`).digest('hex').slice(0, 32)}`;
}

/** The id agents up to this release gave: the system id plus the computer's (current) name. Only sent as a legacy id now. */
export function hostnameMachineId(o: IdOptions = {}): string | null {
  const raw = systemMachineRaw(o);
  if (!raw) return null;
  const name = (o.hostname ?? osHostname()).trim().toLowerCase();
  return `m-${createHash('sha256').update(`escanor-machine-v1:${raw}|${name}`).digest('hex').slice(0, 32)}`;
}

/**
 * The id this agent says hello with. ESCANOR_MACHINE_ID (the Desktop app sets it for its own agent) wins, except when it is the old
 * name-based id of this very computer (a Desktop app with the older copy of this file): then the new id is used, so the app's agent and
 * the background service still give the hub the same id.
 */
export function resolveMachineId(env: NodeJS.ProcessEnv = process.env, o: IdOptions = {}): string {
  const given = env.ESCANOR_MACHINE_ID?.trim() ?? '';
  const stable = stableMachineId(o);
  if (given && !(stable && given === hostnameMachineId(o))) return given;
  return stable ?? given;
}

const ID_RE = /^[A-Za-z0-9._:-]{8,128}$/;

/** Where Escanor Desktop keeps its data folder (Electron's userData: <appData>/<app name>), most likely first. */
export function desktopUserDataDirs(o: { platform?: NodeJS.Platform; home?: string; env?: NodeJS.ProcessEnv } = {}): string[] {
  const platform = o.platform ?? process.platform;
  const home = o.home ?? homedir();
  const env = o.env ?? process.env;
  const appData =
    platform === 'darwin' ? join(home, 'Library', 'Application Support') : platform === 'win32' ? env.APPDATA || join(home, 'AppData', 'Roaming') : env.XDG_CONFIG_HOME || join(home, '.config');
  // The installed app's userData is "@escanor/desktop" (its package name); "Escanor" is its product name, used by some builds.
  return ['@escanor/desktop', 'Escanor'].map((n) => join(appData, n));
}

/** Escanor Desktop's install id (<userData>/device-id, a random id it makes once), or null when the app is not installed for this user. */
export function desktopInstallId(o: { platform?: NodeJS.Platform; home?: string; env?: NodeJS.ProcessEnv; read?: (file: string) => string } = {}): string | null {
  const read = o.read ?? ((f: string) => readFileSync(f, 'utf8'));
  for (const dir of desktopUserDataDirs(o)) {
    try {
      const v = read(join(dir, 'device-id')).trim();
      if (/^[A-Za-z0-9_-]{8,64}$/.test(v)) return v; // the Desktop's own rule for that file
    } catch {
      // not there
    }
  }
  return null;
}

/**
 * The ids this computer was known by before, so the hub merges an older row into the current one (its cleanLegacyIds keeps up to 5 ids of
 * the cleanMachineId shape): ESCANOR_LEGACY_MACHINE_IDS (comma separated, set by the Desktop app for its agent), the older name-based id of
 * this computer, and the Desktop install id when it is found on disk. Never the current id itself.
 */
export function legacyMachineIds(
  env: NodeJS.ProcessEnv = process.env,
  o: { current?: string; machine?: IdOptions; desktop?: Parameters<typeof desktopInstallId>[0] | false } = {},
): string[] {
  const fromEnv = (env.ESCANOR_LEGACY_MACHINE_IDS ?? '').split(',').map((s) => s.trim());
  const fromHost = o.machine ? hostnameMachineId(o.machine) : null;
  const fromDesktop = o.desktop === false || o.desktop === undefined ? null : desktopInstallId(o.desktop);
  const out: string[] = [];
  for (const id of [...fromEnv, fromHost, fromDesktop]) {
    if (!id || !ID_RE.test(id) || id === o.current || out.includes(id)) continue;
    out.push(id);
  }
  return out.slice(0, 5);
}
