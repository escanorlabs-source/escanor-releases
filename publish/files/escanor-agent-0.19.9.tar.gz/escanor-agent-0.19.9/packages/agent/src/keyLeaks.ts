import type { AgentToHubMessage } from '@remote-harness/shared';
import { deviceKey, leakReport, type Conn } from './machineApi.js';
import { fingerprint, scrubDeep, type Finding } from './secretScan.js';

/**
 * F2: keys never reach a chat transcript, and a key that showed up where it should not is reported once.
 *
 * `scrubOutgoing`: every chat message this agent relays off the machine (to the hub, and from there to the phone, the web app and
 * the desktop, which also keep it) has anything shaped like a key replaced by `[hidden: <kind>]` (secretScan.ts). Only the copy
 * that leaves: the Claude session here keeps what it saw and runs what it was going to run. Ids, types, roles, tool names, folders
 * and base64 photos are left as they are (secretScan.FIXED_KEYS). Messages that are not chat (hello, preview pages, sign-in steps,
 * acknowledgements) are not touched.
 *
 * `LeakReporter`: sends only SHA-256 fingerprints and where each key was found to Escanor (POST /machines/leak-report, signed with
 * this machine's own device key), which tells the owner once when one is a stored key of the workspace. Fire and forget; each
 * fingerprint + place is sent once per run of the agent. No key is ever sent or logged.
 */

/** The messages that carry a chat's words (or a tool call shown for approval, a status line, a chat's title). */
const CHAT_TYPES = new Set([
  'sdk_message', 'sdk_partial', 'session_created', 'permission_request', 'error', 'session_activity', 'machine_state', 'queue_state',
  'local_ask_event', 'cloud_ask', 'queue_result', 'subagents', 'subagent_steps_result',
]);

export function scrubOn(env: NodeJS.ProcessEnv = process.env): boolean {
  return !['0', 'false', 'off', 'no'].includes(String(env.CHAT_KEY_SCRUB ?? '1').trim().toLowerCase());
}

/**
 * The start of a well-known key at the very end of a reply still being written (`sdk_partial` carries the text so far): too short
 * yet for its rule, so it is cut off until the rest arrives (the finished message is scrubbed whole). Prefixes only, so ordinary
 * words at the end of a line are never cut.
 */
const KEY_START_AT_END =
  /(?:(?<![A-Za-z0-9_])(?:gh[pousr]_|github_pat_|glpat-|sk_live_|sk_test_|rk_live_|rk_test_|whsec_|sk-ant-|sk-proj-|sk-svcacct-|sk-admin-|gsk_|xox[abposr]-|npm_|SG\.|AKIA|ASIA|AIza|AQ\.|escanor_|esc_llm_)[A-Za-z0-9_.+/=-]*|-----BEGIN [A-Z ]*PRIVATE KEY[\s\S]*)$/;

export function trimKeyStart(text: string): string {
  return text.replace(KEY_START_AT_END, '[hidden: key being written]');
}

/** The message as it may leave this machine, and what was hidden in it. The message given is never changed. */
export function scrubOutgoing(msg: AgentToHubMessage): { msg: AgentToHubMessage; found: Finding[] } {
  if (!CHAT_TYPES.has(msg.type)) return { msg, found: [] };
  const r = scrubDeep(msg);
  if (msg.type === 'sdk_partial') {
    // A key split across two updates: the part already here is not shown before the whole key can be recognised.
    const partial = r.value as Extract<AgentToHubMessage, { type: 'sdk_partial' }>;
    const text = typeof partial.text === 'string' ? trimKeyStart(partial.text) : partial.text;
    if (text !== partial.text) return { msg: { ...partial, text }, found: r.found };
  }
  if (msg.type === 'local_ask_event') {
    // The answer so far, whole: a key still being written at its end is held back until the finished answer is scrubbed.
    const v = r.value as Extract<AgentToHubMessage, { type: 'local_ask_event' }>;
    if (v.event.kind === 'text' && typeof v.event.text === 'string') {
      const text = trimKeyStart(v.event.text);
      if (text !== v.event.text) return { msg: { ...v, event: { ...v.event, text } }, found: r.found };
    }
  }
  return { msg: r.value, found: r.found };
}

const MAX_REPORT = 50;
const KEY_TTL_MS = 10 * 60_000;
const MAX_SEEN = 5_000;

export interface LeakSink {
  report(findings: Finding[], where: (f: Finding, machine?: string) => string, source: 'push' | 'chat'): void;
}

export class LeakReporter implements LeakSink {
  private seen = new Set<string>();
  private key: { value: string; until: number } | null = null;

  constructor(private o: { conn: Conn; now?: () => number; log?: (line: string) => void; send?: typeof leakReport; getKey?: typeof deviceKey }) {}

  report(findings: Finding[], where: (f: Finding, machine?: string) => string, source: 'push' | 'chat'): void {
    if (!findings.length) return;
    void this.send(findings, where, source).catch((err) => this.o.log?.(`[key leaks] report failed: ${err instanceof Error ? err.name : 'error'}`));
  }

  /** Awaitable for tests: how many findings were sent (0 when all were sent before). */
  async send(findings: Finding[], where: (f: Finding, machine?: string) => string, source: 'push' | 'chat'): Promise<number> {
    const items: Array<{ fingerprint: string; where: string }> = [];
    for (const f of findings.slice(0, MAX_REPORT)) {
      const fp = await fingerprint(f.value);
      const place = where(f, this.o.conn.vmName).slice(0, 300);
      const id = `${fp}\u0000${place}`;
      if (this.seen.has(id)) continue;
      if (this.seen.size >= MAX_SEEN) this.seen.clear();
      this.seen.add(id);
      items.push({ fingerprint: fp, where: place });
    }
    if (!items.length) return 0;
    const now = (this.o.now ?? Date.now)();
    if (!this.key || this.key.until <= now) {
      const k = await (this.o.getKey ?? deviceKey)(this.o.conn);
      if (!k.ok || !k.value) {
        this.o.log?.(`[key leaks] not reported: ${k.ok ? 'no key' : k.reason}`);
        for (const i of items) this.seen.delete(`${i.fingerprint}\u0000${i.where}`);
        return 0;
      }
      this.key = { value: k.value, until: now + KEY_TTL_MS };
    }
    const r = await (this.o.send ?? leakReport)(this.o.conn, this.key.value, { findings: items, source });
    if (!r.ok) {
      this.o.log?.(`[key leaks] not reported: ${r.reason}`);
      if (/HTTP 401/.test(r.reason)) this.key = null;
      for (const i of items) this.seen.delete(`${i.fingerprint}\u0000${i.where}`);
      return 0;
    }
    return items.length;
  }
}
