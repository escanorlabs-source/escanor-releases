/**
 * The safety layer's switch (undo copies, never-delete blocks, the machine-wide guard, the mass-delete tripwire): ON unless
 * ESCANOR_SAFETY is explicitly 0/false/off/no. Kept dependency-free: the machine-wide hook loads it on every command.
 */
export const SAFETY_ENV = 'ESCANOR_SAFETY';
export function safetyEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  const v = env[SAFETY_ENV]?.trim().toLowerCase() ?? '';
  return !['0', 'false', 'off', 'no'].includes(v);
}
