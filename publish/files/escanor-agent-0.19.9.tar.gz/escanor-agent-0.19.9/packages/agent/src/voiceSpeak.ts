import { spawn, type ChildProcess } from 'node:child_process';

/**
 * Spoken replies on this computer (`escanor-agent voice`): the computer's own text-to-speech, whichever it has. The text goes to
 * the program on its standard input where the program allows it (never through a shell), so what Escanor says can never become a
 * command. Only the first sentences are spoken; the rest is left to the screen.
 */

export type SpeakStep = { name: string; cmd: string; args: string[]; stdin?: string };

const MAX_SPOKEN_CHARS = 280;
const MAX_SPOKEN_SENTENCES = 2;

/** What is worth saying out loud: plain, short, no links or markup, at most two sentences. */
export function forSpeech(text: string): string {
  const t = text
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
    .replace(/https?:\/\/\S+/g, ' a link ')
    .replace(/[*_#>~|]+/g, ' ')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^[-\s]+/, '');
  const sentences = t.match(/[^.!?]+[.!?]+(?:\s|$)|[^.!?]+$/g) ?? [t];
  let out = '';
  for (const s of sentences.slice(0, MAX_SPOKEN_SENTENCES)) {
    if ((out + s).length > MAX_SPOKEN_CHARS) break;
    out += s;
  }
  return (out || t.slice(0, MAX_SPOKEN_CHARS)).trim();
}

/** The programs to try, best first. */
export function speakCandidates(text: string, platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = process.env): SpeakStep[] {
  const rate = (env.ESCANOR_VOICE_RATE ?? '').trim();
  if (platform === 'linux') {
    return [
      { name: 'spd-say', cmd: 'spd-say', args: ['--wait', '--', text] },
      { name: 'espeak-ng', cmd: 'espeak-ng', args: ['-s', rate || '165', '--stdin'], stdin: text },
      { name: 'espeak', cmd: 'espeak', args: ['-s', rate || '165', '--stdin'], stdin: text },
      { name: 'festival', cmd: 'festival', args: ['--tts'], stdin: text },
    ];
  }
  if (platform === 'darwin') return [{ name: 'say', cmd: 'say', args: rate ? ['-r', rate] : [], stdin: text }];
  if (platform === 'win32') {
    return [
      {
        name: 'powershell',
        cmd: 'powershell',
        args: ['-NoProfile', '-NonInteractive', '-Command', 'Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak([Console]::In.ReadToEnd())'],
        stdin: text,
      },
    ];
  }
  return [];
}

export type SpeakDeps = {
  spawnImpl?: (step: SpeakStep, env: NodeJS.ProcessEnv) => ChildProcess;
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  /** Abort to stop talking at once. */
  signal?: AbortSignal;
};

const realSpawn = (step: SpeakStep, env: NodeJS.ProcessEnv): ChildProcess =>
  spawn(step.cmd, step.args, { stdio: [step.stdin !== undefined ? 'pipe' : 'ignore', 'ignore', 'ignore'], env, windowsHide: true });

/** Say it. Resolves with the program that spoke, or null when no speech program is installed (the reply stays on the screen). */
export async function speak(text: string, d: SpeakDeps = {}): Promise<string | null> {
  const say = forSpeech(text);
  if (!say) return null;
  const env = d.env ?? process.env;
  for (const step of speakCandidates(say, d.platform ?? process.platform, env)) {
    const ok = await run(step, d, env);
    if (ok) return step.name;
  }
  return null;
}

function run(step: SpeakStep, d: SpeakDeps, env: NodeJS.ProcessEnv): Promise<boolean> {
  return new Promise((resolve) => {
    let child: ChildProcess;
    try {
      child = (d.spawnImpl ?? realSpawn)(step, env);
    } catch {
      return resolve(false);
    }
    let missing = false;
    const onAbort = () => {
      try {
        child.kill('SIGTERM');
      } catch {
        // gone
      }
    };
    d.signal?.addEventListener('abort', onAbort, { once: true });
    if (d.signal?.aborted) onAbort();
    child.on('error', () => {
      missing = true;
      resolve(false);
    });
    child.on('close', (code) => {
      d.signal?.removeEventListener('abort', onAbort);
      // Stopped on purpose counts as spoken (do not read it again with the next program).
      resolve(!missing && (code === 0 || d.signal?.aborted === true));
    });
    if (step.stdin !== undefined && child.stdin) {
      child.stdin.on('error', () => undefined);
      child.stdin.end(step.stdin);
    }
  });
}
