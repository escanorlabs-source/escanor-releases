import { execFile } from 'node:child_process';
import { isAbsolute, resolve as resolvePath } from 'node:path';
import type { HubUserInput } from '@remote-harness/shared';

/**
 * WATCHLIST (the agent's side): an auto-fix run Escanor sends to this computer may change only the repositories the person picked
 * for fixes. The backend puts the list on the run (mongo-backend autopilot/supervisor.py `extra.write_repos`) and into the task's
 * words (autopilot/watchlist.py `computer_words`, the only part of it that reaches this agent today: the backend posts the words
 * alone). HubUserInput.writeRepos carries the same list for a backend and hub that pass it on.
 *
 * In a chat that has the list, a command that changes a remote repository (git push in any form, gh pr create/merge/close/...,
 * a gh api write, gh repo/release/run/workflow/secret/variable/label writes) is checked before it runs: the repository it
 * changes is worked out (the push URLs of the named or default remote in the command's folder, `-R/--repo`, a pull request URL,
 * the API path) and the command is refused unless that repository is on the list (owner/name, any case, https or ssh remote).
 * A write whose repository cannot be worked out is refused too (fail closed); a command that changes nothing remote is never
 * looked at more closely. A chat without the list runs exactly as before.
 *
 * MAINWRITE (16 Oct): on a picked repository, a write never lands on the default branch or a protected one (main, master, trunk,
 * develop, development, prod, production, release, release/*, stable, or the remote's HEAD): a push to one by any refspec
 * (`HEAD:main`, `:main`, `+x:master`, a plain `git push` from main or following main upstream), `--all`/`--mirror`, gh pr merge,
 * gh repo sync, and gh api writes to contents (naming no branch = the default), refs and merges. A fix reaches main only when
 * Escanor merges its verified pull request.
 *
 * Strict on purpose: a write is checked only where Escanor can see what runs before it. One inside a subshell, a pipe into
 * it, `bash -c`, `xargs`, `sudo`, a command substitution, or behind commands that could change the folder's remotes is refused
 * with a word to run it on its own. What this cannot see: a script file or program that pushes by itself (`./release.sh`,
 * `npm run deploy`), or git hooks. The backend's prompt and its Guardian are the other two layers.
 *
 * Everything here is linear in the command's length (one pass to read it, no backtracking patterns over it).
 */

/** The line the backend appends to the task (mongo-backend autopilot/watchlist.py `computer_words`). */
const BACKEND_WORDS = /Change only these repositories, the ones the person chose for fixes: ([^\n]*?)\. Never push, open a pull request/g;
const REPO_NAME = /^[a-z0-9_.-]+\/[a-z0-9_.-]+$/;
const MAX_CHECKED_CHARS = 100_000;
const GITHUB_HOSTS = new Set(['github.com', 'www.github.com', 'ssh.github.com']);
const GIT_TIMEOUT_MS = 5_000;

/** `owner/name`, lower case, or null when it is not one (an extra account's id prefix `github:work:` is dropped, as the backend does). */
export function repoName(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const name = value.slice(value.lastIndexOf(':') + 1).trim().replace(/^\/+|\/+$/g, '').toLowerCase();
  return REPO_NAME.test(name) && !name.split('/').some((p) => p === '.' || p === '..') ? name : null;
}

/** A list from HubUserInput.writeRepos; undefined when the message carries none (an empty list still restricts: nothing allowed). */
export function reposFromField(value: unknown): string[] | undefined {
  if (!Array.isArray(value)) return undefined;
  return [...new Set(value.map(repoName).filter((r): r is string => r !== null))].sort();
}

/**
 * The list from the backend's words in a message, or undefined when they are not there. Each time they appear narrows the list
 * (words quoted from a log or an issue can take repositories away, never add one).
 */
export function reposFromText(text: string | undefined): string[] | undefined {
  if (!text || !text.includes('Change only these repositories')) return undefined;
  let out: string[] | undefined;
  for (const m of text.slice(0, 2 * MAX_CHECKED_CHARS).matchAll(BACKEND_WORDS)) {
    const listed = reposFromField(m[1].split(','));
    out = narrowRepos(out, listed);
  }
  return out;
}

/** Both lists: only what is on both (a chat's list never widens). Either alone: that one. */
export function narrowRepos(a: string[] | undefined, b: string[] | undefined): string[] | undefined {
  if (!a) return b ? [...b] : undefined;
  if (!b) return [...a];
  const keep = new Set(b);
  return a.filter((r) => keep.has(r));
}

/** The list a message from the hub carries (its field and its words, narrowed together), or undefined. */
export function reposOf(input: Pick<HubUserInput, 'text'> & { writeRepos?: unknown }): string[] | undefined {
  return narrowRepos(reposFromField(input.writeRepos), reposFromText(input.text));
}

// ---------------------------------------------------------------------------------------------------- reading a command

type Word = { text: string; quoted: boolean; dynamic: boolean; subs: string[] };
type Heredoc = { body: string; quoted: boolean };
type Simple = { words: Word[]; redirects: Word[]; heredocs: Heredoc[]; prev: string; next: string; stdin?: boolean };
type Parsed = { commands: Simple[]; grouped: boolean };

class Unreadable extends Error {}

/** The end of `$(...)` whose `(` is at `open`: the index of its `)`. Quotes, backticks, nested parentheses and here-documents. */
function scanSubst(src: string, open: number): number {
  let depth = 1;
  let i = open + 1;
  const pending: Array<{ delim: string; strip: boolean }> = [];
  while (i < src.length) {
    const c = src[i];
    if (c === '\\') i += 2;
    else if (c === "'") {
      const j = src.indexOf("'", i + 1);
      if (j < 0) throw new Unreadable();
      i = j + 1;
    } else if (c === '"') i = skipDouble(src, i);
    else if (c === '`') i = skipBacktick(src, i);
    else if (c === '(') {
      depth++;
      i++;
    } else if (c === ')') {
      if (--depth === 0) return i;
      i++;
    } else if (c === '<' && src[i + 1] === '<' && src[i + 2] !== '<') {
      const h = readDelimiter(src, i + 2);
      pending.push({ delim: h.delim, strip: h.strip });
      i = h.end;
    } else if (c === '\n' && pending.length) {
      i = i + 1;
      for (const h of pending.splice(0)) i = skipHeredoc(src, i, h.delim, h.strip).end;
    } else i++;
  }
  throw new Unreadable();
}

function skipDouble(src: string, at: number): number {
  let j = at + 1;
  while (j < src.length) {
    const c = src[j];
    if (c === '\\') j += 2;
    else if (c === '"') return j + 1;
    else if (c === '$' && src[j + 1] === '(') j = scanSubst(src, j + 1) + 1;
    else if (c === '`') j = skipBacktick(src, j);
    else j++;
  }
  throw new Unreadable();
}

function skipBacktick(src: string, at: number): number {
  let j = at + 1;
  while (j < src.length) {
    if (src[j] === '\\') j += 2;
    else if (src[j] === '`') return j + 1;
    else j++;
  }
  throw new Unreadable();
}

/** After `<<`: `-`, blanks, then the delimiter word (quoted or not). */
function readDelimiter(src: string, at: number): { delim: string; strip: boolean; quoted: boolean; end: number } {
  let i = at;
  const strip = src[i] === '-';
  if (strip) i++;
  while (src[i] === ' ' || src[i] === '\t') i++;
  let delim = '';
  let quoted = false;
  while (i < src.length && !' \t\n;&|()<>'.includes(src[i])) {
    const c = src[i];
    if (c === "'" || c === '"') {
      const j = src.indexOf(c, i + 1);
      if (j < 0) throw new Unreadable();
      delim += src.slice(i + 1, j);
      quoted = true;
      i = j + 1;
    } else if (c === '\\') {
      delim += src[i + 1] ?? '';
      quoted = true;
      i += 2;
    } else {
      delim += c;
      i++;
    }
  }
  if (!delim) throw new Unreadable();
  return { delim, strip, quoted, end: i };
}

/** The body of a here-document starting at `from` (the line after its command): up to the line that is its delimiter. */
function skipHeredoc(src: string, from: number, delim: string, strip: boolean): { body: string; end: number } {
  let i = from;
  const lines: string[] = [];
  while (i < src.length) {
    let j = src.indexOf('\n', i);
    if (j < 0) j = src.length;
    const line = src.slice(i, j);
    if ((strip ? line.replace(/^\t+/, '') : line) === delim) return { body: lines.join('\n'), end: Math.min(j + 1, src.length) };
    lines.push(line);
    i = j + 1;
  }
  return { body: lines.join('\n'), end: src.length };
}

/** `$'...'`: its escapes (\xHH, octal, \n...) decoded, so `$'\x67it'` reads as git. */
function ansiC(src: string, at: number): { text: string; end: number } {
  let i = at + 2;
  let out = '';
  while (i < src.length) {
    const c = src[i];
    if (c === "'") return { text: out, end: i + 1 };
    if (c !== '\\') {
      out += c;
      i++;
      continue;
    }
    const e = src[i + 1] ?? '';
    const simple: Record<string, string> = { n: '\n', t: '\t', r: '\r', a: '\x07', b: '\b', e: '\x1b', E: '\x1b', f: '\f', v: '\v', '\\': '\\', "'": "'", '"': '"', '?': '?' };
    if (e in simple) {
      out += simple[e];
      i += 2;
    } else if (e === 'x') {
      const m = /^[0-9a-fA-F]{1,2}/.exec(src.slice(i + 2, i + 4));
      out += m ? String.fromCharCode(parseInt(m[0], 16)) : '\\x';
      i += 2 + (m ? m[0].length : 0);
    } else if (e >= '0' && e <= '7') {
      const m = /^[0-7]{1,3}/.exec(src.slice(i + 1, i + 4))!;
      out += String.fromCharCode(parseInt(m[0], 8));
      i += 1 + m[0].length;
    } else {
      out += '\\' + e;
      i += 2;
    }
  }
  throw new Unreadable();
}

/** The `$(...)` and backtick commands inside text the shell expands (a double-quoted string, an unquoted here-document). */
function substitutionsIn(text: string): string[] {
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '\\') i += 2;
    else if (c === '$' && text[i + 1] === '(') {
      const end = scanSubst(text, i + 1);
      out.push(text.slice(i + 2, end));
      i = end + 1;
    } else if (c === '`') {
      const end = skipBacktick(text, i);
      out.push(text.slice(i + 1, end - 1));
      i = end;
    } else i++;
  }
  return out;
}

const VAR_START = /[A-Za-z_{0-9@*#?$!-]/;

/** A command line read as bash would split it: simple commands with the operator before and after each. */
function parse(src: string): Parsed {
  const commands: Simple[] = [];
  let grouped = false;
  const fresh = (prev: string): Simple => ({ words: [], redirects: [], heredocs: [], prev, next: '' });
  let cur = fresh('');
  let word: Word | null = null;
  let redirectNext = false;
  const pending: Array<{ delim: string; strip: boolean; quoted: boolean; target: Simple }> = [];
  const startWord = (): Word => (word ??= { text: '', quoted: false, dynamic: false, subs: [] });
  const endWord = () => {
    if (!word) return;
    if (redirectNext) cur.redirects.push(word);
    else cur.words.push(word);
    redirectNext = false;
    word = null;
  };
  const endCommand = (op: string) => {
    endWord();
    if (cur.words.length || cur.redirects.length || cur.heredocs.length || pending.some((p) => p.target === cur)) {
      cur.next = op;
      commands.push(cur);
      cur = fresh(op);
    } else if (op) {
      cur.prev = op; // `(`, `)` or a leading operator: the next command follows it
    }
  };
  let i = 0;
  const n = src.length;
  while (i < n) {
    const c = src[i];
    if (c === '\\') {
      if (src[i + 1] === '\n') {
        i += 2;
        continue;
      }
      const w = startWord();
      w.text += src[i + 1] ?? '';
      w.quoted = true;
      i += 2;
    } else if (c === "'") {
      const j = src.indexOf("'", i + 1);
      if (j < 0) throw new Unreadable();
      const w = startWord();
      w.text += src.slice(i + 1, j);
      w.quoted = true;
      i = j + 1;
    } else if (c === '$' && src[i + 1] === "'") {
      const a = ansiC(src, i);
      const w = startWord();
      w.text += a.text;
      w.quoted = true;
      i = a.end;
    } else if (c === '"') {
      const w = startWord();
      w.quoted = true;
      i++;
      for (;;) {
        if (i >= n) throw new Unreadable();
        const ch = src[i];
        if (ch === '"') {
          i++;
          break;
        }
        if (ch === '\\' && '$`"\\\n'.includes(src[i + 1] ?? '')) {
          if (src[i + 1] !== '\n') w.text += src[i + 1];
          i += 2;
        } else if (ch === '$' && src[i + 1] === '(') {
          const end = scanSubst(src, i + 1);
          w.subs.push(src.slice(i + 2, end));
          w.dynamic = true;
          w.text += '$(…)';
          i = end + 1;
        } else if (ch === '`') {
          const end = skipBacktick(src, i);
          w.subs.push(src.slice(i + 1, end - 1));
          w.dynamic = true;
          w.text += '$(…)';
          i = end;
        } else {
          if (ch === '$' && VAR_START.test(src[i + 1] ?? '')) w.dynamic = true;
          w.text += ch;
          i++;
        }
      }
    } else if (c === '`') {
      const end = skipBacktick(src, i);
      const w = startWord();
      w.subs.push(src.slice(i + 1, end - 1));
      w.dynamic = true;
      w.text += '$(…)';
      i = end;
    } else if (c === '$' && src[i + 1] === '(') {
      const end = scanSubst(src, i + 1);
      const w = startWord();
      w.subs.push(src.slice(i + 2, end));
      w.dynamic = true;
      w.text += '$(…)';
      i = end + 1;
    } else if (c === '$' && VAR_START.test(src[i + 1] ?? '')) {
      const w = startWord();
      w.dynamic = true;
      w.text += c;
      i++;
    } else if ((c === '<' || c === '>') && src[i + 1] === '(') {
      const end = scanSubst(src, i + 1); // process substitution
      const w = startWord();
      w.subs.push(src.slice(i + 2, end));
      w.dynamic = true;
      i = end + 1;
    } else if (c === ' ' || c === '\t' || c === '\r') {
      endWord();
      i++;
    } else if (c === '\n') {
      endCommand('\n');
      i++;
      for (const h of pending.splice(0)) {
        const doc = skipHeredoc(src, i, h.delim, h.strip);
        h.target.heredocs.push({ body: doc.body, quoted: h.quoted });
        i = doc.end;
      }
    } else if (c === '#' && !word) {
      const j = src.indexOf('\n', i);
      i = j < 0 ? n : j;
    } else if (c === ';') {
      const two = src[i + 1] === ';';
      endCommand(two ? ';;' : ';');
      i += two ? 2 : 1;
    } else if (c === '&') {
      if (src[i + 1] === '&') {
        endCommand('&&');
        i += 2;
      } else if (src[i + 1] === '>') {
        endWord();
        i += src[i + 2] === '>' ? 3 : 2;
        redirectNext = true;
      } else {
        endCommand('&');
        i++;
      }
    } else if (c === '|') {
      if (src[i + 1] === '|') {
        endCommand('||');
        i += 2;
      } else {
        endCommand('|');
        i += src[i + 1] === '&' ? 2 : 1;
      }
    } else if (c === '(' || c === ')') {
      grouped = true;
      endCommand(c);
      i++;
    } else if (c === '<' || c === '>') {
      // A number glued to the front (`2>`) is the file descriptor, not a word.
      const fd = word as Word | null;
      if (fd && !fd.quoted && !fd.dynamic && /^\d+$/.test(fd.text)) word = null;
      else endWord();
      if (c === '<') cur.stdin = true; // input from a file, a here-document or a here-string
      if (src.startsWith('<<<', i)) {
        i += 3;
        redirectNext = true;
      } else if (src.startsWith('<<', i)) {
        const h = readDelimiter(src, i + 2);
        pending.push({ delim: h.delim, strip: h.strip, quoted: h.quoted, target: cur });
        i = h.end;
      } else {
        i++;
        if (src[i] === '>' || src[i] === '&' || src[i] === '|' || (c === '<' && src[i] === '>')) i++;
        redirectNext = true;
      }
    } else {
      const w = startWord();
      if ((c === '{' || c === '}') && w.text === '' && !w.quoted && (src[i + 1] === undefined || ' \t\n;'.includes(src[i + 1])) && cur.words.length === 0) {
        grouped = true; // a { ...; } group
        word = null;
        i++;
        continue;
      }
      w.text += c;
      i++;
    }
  }
  endCommand('');
  return { commands, grouped };
}

// ---------------------------------------------------------------------------------------------------- what a command does

/** The program a word runs: `/usr/bin/git` and `git` are both git. */
const programOf = (w: Word | undefined): string => (w ? w.text.slice(w.text.lastIndexOf('/') + 1) : '');
const ASSIGNMENT = /^[A-Za-z_][A-Za-z0-9_]*=/;
const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh', 'fish', 'ash', 'busybox', 'ssh']);
const INTERPRETERS = new Set(['python', 'python3', 'node', 'perl', 'ruby', 'php', 'deno', 'bun', 'tsx', 'ts-node', 'pwsh', 'powershell']);
/** HTTP clients: a write verb to GitHub's API with one of them is refused in a limited chat (MAINWRITE review I3). */
const HTTP_PROGRAMS = new Set(['curl', 'wget', 'http', 'https', 'xh', 'xhs']);
const WRITE_PROGRAMS = new Set(['git', 'gh', 'hub', 'git-push', 'git-send-pack', ...HTTP_PROGRAMS, 'curlie', 'lwp-request', 'GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'PATCH',
  'openssl', 'nc', 'ncat', 'netcat', 'socat', 'telnet', 'aria2c']);
/** Something in a string that still looks like a push or a gh write after it was not readable as a command (a Python -c, say). */
/** Text that sends a write to GitHub's API (code, a here-document for a socket client). */
const API_WRITE = /(?:api|uploads)\.github\.com[\s\S]{0,400}?\b(?:put|post|patch|delete)\b|\b(?:put|post|patch|delete)\b[\s\S]{0,400}?(?:api|uploads)\.github\.com/i;
const LOOKS_LIKE_WRITE = [
  /\bgit\b[^\n]{0,60}?\b(?:push|send-pack)\b/,
  /\bgh\b[^\n]{0,40}?\b(?:pr|repo|release|api|issue|workflow|run|secret|variable|label)\b[^\n]{0,40}?\b(?:create|merge|close|reopen|edit|delete|comment|review|ready|rerun|cancel|upload|set|sync|rename|archive|fork|enable|disable|run|POST|PUT|PATCH|DELETE)\b/i,
  // code (python -c, node -e, a heredoc) that writes to GitHub's API (MAINWRITE review I3)
  API_WRITE,
];
const looksLikeWrite = (s: string) => LOOKS_LIKE_WRITE.some((re) => re.test(s));

/** Where a git command works: its folder (null when it cannot be known) and the --git-dir / --work-tree it was given. */
type GitCtx = { cwd: string | null; args: string[]; run: Runner };
type Target =
  | { t: 'push'; ctx: GitCtx; remote: string | null } // the push URLs of this remote (or URL), or of the default one (null)
  | { t: 'repo'; name: string }
  | { t: 'folder'; ctx: GitCtx } // gh with no repository named: the GitHub remotes of the folder
  | { t: 'unknown'; why: string };
/**
 * MAINWRITE: where a write lands. A push: its refspecs (or the checked-out branch and push.default when it names none); a gh api
 * write: the branches it names; or a write refused whatever the branch (a merge, every branch, a file write naming no branch).
 */
type BranchCheck =
  | { k: 'push'; ctx: GitCtx; remote: string | null; refspecs: Word[]; all: boolean }
  | { k: 'names'; names: string[] }
  | { k: 'refuse'; why: string };
type Write = { what: string; targets: Target[]; needsBranch?: boolean; branch?: BranchCheck };

const unknown = (why: string): Target => ({ t: 'unknown', why });

export type WriteCheckOptions = {
  /** The repositories this chat may change (owner/name, lower case). */
  allowed: string[];
  /**
   * The repository's default branch (lower case), or null when it cannot be found: a write to any branch that is not escanor/*
   * is refused when it is that branch, or when it cannot be found (MAINWRITE2 N3). By default `defaultBranchOf`.
   */
  defaultBranch?: (repos: string[], where: { cwd: string | null; remote: string | null; run: Runner }) => Promise<string | null>;
  /** The folder the command runs in. */
  cwd?: string;
  /** What `~` and a bare `cd` mean; unknown when not given. */
  home?: string;
  /** The real host name of an ssh host alias (`git@github-work:o/r`), or null; by default `ssh -G`, run as the chat runs. */
  sshHostname?: (alias: string) => Promise<string | null>;
  /**
   * How the git and ssh that work out a command's repository are run: as the chat's commands run (its user, HOME and
   * environment), so the chat's own git settings (a global pushInsteadOf, remote.pushDefault) are the ones read. By default
   * as this agent, with its environment.
   */
  run?: Runner;
  /** The chat's environment: its git settings from the environment name Escanor's git proxy (managed machines). */
  env?: NodeJS.ProcessEnv;
};

/** Runs a program in a folder and gives its output, or null when it failed. */
export type Runner = (command: string, args: string[], cwd: string) => Promise<string | null>;

/**
 * A Runner for `env`, optionally wrapped (`wrap` turns a command into one run as another user, chatUser.ts asUser; it changes
 * to the folder itself).
 */
export function commandRunner(env: NodeJS.ProcessEnv, wrap?: (command: string, args: string[], cwd: string) => { command: string; args: string[] }): Runner {
  return (command, args, cwd) =>
    new Promise((done) => {
      const line = wrap ? wrap(command, args, cwd) : { command, args };
      execFile(
        line.command,
        line.args,
        { cwd: wrap ? '/' : cwd, timeout: GIT_TIMEOUT_MS, maxBuffer: 1024 * 1024, env: { ...env, GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0' } },
        (err, stdout) => done(err ? null : String(stdout).trim()),
      );
    });
}

const agentRunner = commandRunner(process.env);

type Ctx = { opts: WriteCheckOptions; depth: number; run: Runner };

function resolveDir(base: string | null, path: Word, home: string | undefined): string | null {
  if (path.dynamic) return null;
  let p = path.text;
  if (!path.quoted && (p === '~' || p.startsWith('~/'))) {
    if (!home) return null;
    p = home + p.slice(1);
  }
  if (isAbsolute(p)) return resolvePath(p);
  return base ? resolvePath(base, p) : null;
}

/** The words after the wrappers that only start a program (`env X=1`, `timeout 60`, `nice`, `command`...), and the assignments. */
function unwrap(words: Word[]): { start: number; env: Map<string, Word>; opaque: boolean } {
  const env = new Map<string, Word>();
  let i = 0;
  let opaque = false;
  const take = (w: Word) => {
    const eq = w.text.indexOf('=');
    env.set(w.text.slice(0, eq), { ...w, text: w.text.slice(eq + 1) });
  };
  for (;;) {
    while (i < words.length && ASSIGNMENT.test(words[i].text) && !words[i].text.slice(0, words[i].text.indexOf('=')).includes('$')) take(words[i++]);
    const p = programOf(words[i]);
    if (p === 'command' || p === 'exec' || p === 'nohup' || p === 'builtin') {
      i++;
      while (words[i]?.text.startsWith('-')) i++;
    } else if (p === 'time') {
      i++;
      while (words[i]?.text.startsWith('-')) i++;
    } else if (p === 'nice' || p === 'ionice' || p === 'stdbuf') {
      i++;
      while (words[i]?.text.startsWith('-')) {
        const w = words[i++].text;
        if ((w === '-n' || w === '-c' || w === '-p' || w === '--adjustment') && words[i]) i++;
      }
    } else if (p === 'timeout') {
      i++;
      while (words[i]?.text.startsWith('-')) {
        const w = words[i++].text;
        if ((w === '-s' || w === '-k' || w === '--signal' || w === '--kill-after') && words[i]) i++;
      }
      i++; // the duration
    } else if (p === 'env') {
      i++;
      while (i < words.length && (words[i].text.startsWith('-') || ASSIGNMENT.test(words[i].text))) {
        const w = words[i].text;
        if (ASSIGNMENT.test(w)) take(words[i]);
        else if (w === '-C' || w.startsWith('--chdir') || w === '-S' || w.startsWith('--split-string')) opaque = true;
        else if ((w === '-u' || w === '--unset') && words[i + 1]) i++;
        i++;
      }
    } else break;
  }
  return { start: i, env, opaque };
}

const GIT_BUILTINS = new Set(
  ('add am annotate apply archive bisect blame branch bundle cat-file check-attr check-ignore check-mailmap check-ref-format checkout ' +
    'checkout-index cherry cherry-pick citool clean clone column commit commit-graph commit-tree config count-objects credential ' +
    'describe diff diff-files diff-index diff-tree difftool fast-export fast-import fetch fetch-pack filter-branch fmt-merge-msg ' +
    'for-each-ref for-each-repo format-patch fsck gc get-tar-commit-id grep gui hash-object help hook index-pack init instaweb ' +
    'interpret-trailers log ls-files ls-remote ls-tree mailinfo mailsplit maintenance merge merge-base merge-file merge-index ' +
    'merge-tree mergetool mktag mktree multi-pack-index mv name-rev notes pack-objects pack-refs patch-id prune prune-packed pull ' +
    'push range-diff read-tree rebase reflog remote repack replace request-pull rerere reset restore rev-list rev-parse revert rm ' +
    'send-email send-pack shortlog show show-branch show-index show-ref sparse-checkout stash status stripspace submodule switch ' +
    'symbolic-ref tag unpack-file unpack-objects update-index update-ref update-server-info var verify-commit verify-pack ' +
    'verify-tag version whatchanged worktree write-tree subtree lfs').split(' '),
);
/** git subcommands that cannot change where a later push goes (they never touch remotes or the config). */
const SAFE_GIT = new Set(['status', 'add', 'commit', 'diff', 'log', 'show', 'rev-parse', 'fetch', 'ls-files', 'ls-remote', 'describe', 'shortlog', 'blame', 'grep', 'stash', 'restore', 'rm', 'mv', 'tag', 'version', 'help', 'cat-file', 'rev-list', 'show-ref', 'for-each-ref', 'merge-base', 'diff-tree', 'diff-index', 'diff-files', 'name-rev', 'reflog', 'cherry-pick', 'revert', 'merge', 'pull', 'rebase']);
/** These change the current branch, and so the default remote of a push that names none. */
const BRANCH_GIT = new Set(['checkout', 'switch', 'branch', 'reset']);
const SAFE_PROGRAMS = new Set(['echo', 'printf', 'true', 'false', 'pwd', 'ls', 'cat', 'head', 'tail', 'wc', 'grep', 'test', '[', 'sleep', 'date', 'which', 'type', 'whoami', ':']);
/** What a write's output may be piped into. Only after the write (tee/sed/awk could write files, but nothing runs after them that
 * the files could redirect): before a write, a pipe or redirect into a file is never allowed (safeBefore). */
const PIPE_READERS = new Set(['head', 'tail', 'cat', 'grep', 'egrep', 'fgrep', 'wc', 'sort', 'uniq', 'cut', 'tr', 'tee', 'less', 'more', 'jq', 'awk', 'sed']);

/** git's options before the subcommand, the subcommand's index, and whether settings were given inline (`-c`). */
function gitGlobals(words: Word[], at: number, cwd: string | null, env: Map<string, Word>, home: string | undefined, run: Runner) {
  const ctx: GitCtx = { cwd, args: [], run };
  let inline: string | null = null;
  for (const [k, v] of env) {
    if (k === 'GIT_DIR' || k === 'GIT_WORK_TREE') {
      const dir = resolveDir(ctx.cwd, v, home);
      if (dir === null) ctx.cwd = null;
      else ctx.args.push(`--${k === 'GIT_DIR' ? 'git-dir' : 'work-tree'}=${dir}`);
    } else if (k.startsWith('GIT_CONFIG') || k === 'GIT_NAMESPACE') inline = `it sets ${k}`;
  }
  let i = at + 1;
  while (i < words.length && words[i].text.startsWith('-') && !words[i].dynamic) {
    const w = words[i].text;
    if (w === '-C') {
      const p = words[i + 1];
      ctx.cwd = p ? resolveDir(ctx.cwd, p, home) : null;
      i += 2;
    } else if (w === '-c' || w === '--config-env') {
      inline = 'it gives git settings inline (-c)';
      i += 2;
    } else if (w.startsWith('--config-env=')) {
      inline = 'it gives git settings inline';
      i++;
    } else if (w === '--git-dir' || w === '--work-tree' || w.startsWith('--git-dir=') || w.startsWith('--work-tree=')) {
      const eq = w.indexOf('=');
      const name = eq >= 0 ? w.slice(2, eq) : w.slice(2);
      const value: Word | undefined = eq >= 0 ? { ...words[i], text: w.slice(eq + 1) } : words[i + 1];
      const dir = value ? resolveDir(ctx.cwd, value, home) : null;
      if (dir === null) ctx.cwd = null;
      else ctx.args.push(`--${name}=${dir}`);
      i += eq >= 0 ? 1 : 2;
    } else if (w === '--namespace' || w === '--exec-path' || w === '--super-prefix' || w === '--list-cmds' || w === '--attr-source') {
      i += 2;
    } else i++;
  }
  return { ctx, sub: i, inline };
}

function gitRemoteTarget(ctx: GitCtx, remote: Word | undefined, inline: string | null): Target {
  if (inline) return unknown(inline);
  if (remote?.dynamic) return unknown('the repository is a value Escanor cannot see');
  if (!ctx.cwd) return unknown('Escanor cannot tell which folder it runs in');
  return { t: 'push', ctx, remote: remote ? remote.text : null };
}

/** `git push` and its relatives: the repository they push to. */
function classifyPush(words: Word[], from: number, ctx: GitCtx, inline: string | null): Write {
  let repo: Word | undefined;
  let repoOption: Word | undefined;
  let submodules = false;
  let all = false;
  let options = true;
  const refspecs: Word[] = [];
  for (let i = from; i < words.length; i++) {
    const w = words[i].text;
    if (options && w === '--') {
      options = false;
      continue;
    }
    if (options && w.startsWith('-') && w.length > 1) {
      if (w === '--repo') repoOption = words[++i];
      else if (w.startsWith('--repo=')) repoOption = { ...words[i], text: w.slice(7) };
      else if (w === '-o' || w === '--push-option' || w === '--receive-pack' || w === '--exec') i++;
      else if (/^--recurse-submodules=(?:on-demand|only)$/.test(w)) submodules = true;
      else if (w === '--all' || w === '--mirror' || w === '--branches') all = true;
      else if (/^-[A-Za-z]+$/.test(w) && w.endsWith('o')) i++; // -fo VALUE
      continue;
    }
    if (!repo) repo = words[i];
    else refspecs.push(words[i]);
  }
  const remote = repo ?? repoOption;
  if (submodules) return { what: 'git push', targets: [unknown('it pushes submodules too')] };
  return {
    what: 'git push', targets: [gitRemoteTarget(ctx, remote, inline)], needsBranch: !remote,
    branch: { k: 'push', ctx, remote: remote && !remote.dynamic ? remote.text : null, refspecs, all },
  };
}

const SEND_PACK: BranchCheck = { k: 'refuse', why: '' }; // filled below (the words are defined with the check)

async function classifyGit(words: Word[], at: number, cwd: string | null, env: Map<string, Word>, c: Ctx, aliasDepth = 0): Promise<Write | null> {
  const prog = programOf(words[at]);
  const { ctx, sub, inline } = gitGlobals(words, at, cwd, env, c.opts.home, c.run);
  if (prog === 'git-push') return classifyPush(words, at + 1, ctx, inline);
  if (prog === 'git-send-pack') return { what: 'git send-pack', targets: [gitRemoteTarget(ctx, words.slice(at + 1).find((w) => !w.text.startsWith('-')), inline)], branch: SEND_PACK };
  const s = words[sub];
  if (!s) return null;
  if (s.dynamic) return { what: 'git', targets: [unknown('it runs a git command Escanor cannot see')] };
  const name = s.text;
  if (name === 'push') return classifyPush(words, sub + 1, ctx, inline);
  if (name === 'send-pack') return { what: 'git send-pack', targets: [gitRemoteTarget(ctx, words.slice(sub + 1).find((w) => !w.text.startsWith('-')), inline)], branch: SEND_PACK };
  if ((name === 'subtree' || name === 'lfs') && words[sub + 1]?.text === 'push') {
    let repo: Word | undefined;
    for (let i = sub + 2; i < words.length; i++) {
      const w = words[i].text;
      if (w === '-P' || w === '--prefix' || w === '-m' || w === '--message') i++;
      else if (!w.startsWith('-')) {
        repo = words[i];
        break;
      }
    }
    return {
      what: `git ${name} push`, targets: [repo ? gitRemoteTarget(ctx, repo, inline) : unknown('it names no repository')],
      ...(name === 'subtree' ? { branch: { k: 'refuse', why: branchUnknown('git subtree push') } as BranchCheck } : {}),
    };
  }
  if (prog === 'hub' && ['pull-request', 'fork', 'create', 'delete', 'release', 'api', 'issue', 'sync', 'merge'].includes(name)) {
    return { what: `hub ${name}`, targets: [unknown('Escanor does not check hub; use git or gh')] };
  }
  if (GIT_BUILTINS.has(name) || aliasDepth > 2) return null;
  // Not a git command: maybe one of the folder's aliases (`git p` for push). Read it, and check what it stands for.
  if (!ctx.cwd) return looksLikeWrite(`git ${words.slice(sub).map((w) => w.text).join(' ')}`) ? { what: 'git', targets: [unknown('Escanor cannot tell which folder it runs in')] } : null;
  const alias = await gitOut(ctx, ['config', '--get', `alias.${name}`]);
  if (!alias) return null;
  if (alias.startsWith('!')) return /\b(?:push|send-pack|gh)\b/.test(alias) ? { what: `git ${name}`, targets: [unknown('it is a git alias that runs a shell command')] } : null;
  let expanded: Parsed;
  try {
    expanded = parse(alias);
  } catch {
    return { what: `git ${name}`, targets: [unknown('Escanor could not read its git alias')] };
  }
  const first = expanded.commands[0]?.words ?? [];
  const spliced = [...words.slice(0, sub), ...first, ...words.slice(sub + 1)];
  return classifyGit(spliced, at, cwd, env, c, aliasDepth + 1);
}

// gh: which command groups write, and with which verbs.
const GH_WRITES = new Map<string, Set<string>>(Object.entries({
  pr: new Set(['create', 'merge', 'close', 'reopen', 'edit', 'ready', 'review', 'comment', 'lock', 'unlock', 'update-branch', 'revert']),
  issue: new Set(['create', 'close', 'reopen', 'edit', 'comment', 'delete', 'lock', 'unlock', 'transfer', 'pin', 'unpin', 'develop']),
  repo: new Set(['create', 'delete', 'edit', 'rename', 'archive', 'unarchive', 'sync', 'fork', 'deploy-key', 'autolink']),
  release: new Set(['create', 'delete', 'edit', 'upload', 'delete-asset']),
  run: new Set(['rerun', 'cancel', 'delete']),
  workflow: new Set(['run', 'enable', 'disable']),
  secret: new Set(['set', 'delete', 'remove']),
  variable: new Set(['set', 'delete']),
  label: new Set(['create', 'edit', 'delete', 'clone']),
  cache: new Set(['delete']),
}));
/** gh options whose value is words for people (a title, a body): never read as a repository or a URL. */
const GH_MESSAGE_OPTS = new Set(['-t', '--title', '-b', '--body', '--subject', '-n', '--notes', '--message']);
/** gh options that take a value (so the value is not a positional). */
const GH_VALUE_OPTS = new Set([
  '-R', '--repo', '-t', '--title', '-b', '--body', '-F', '--body-file', '-B', '--base', '-H', '--head', '-a', '--assignee', '-l', '--label',
  '--milestone', '-p', '--project', '--reviewer', '-T', '--template', '--subject', '--match-head-commit', '-A', '--author-email',
  '--recover', '-q', '--jq', '--json', '--add-label', '--remove-label', '--add-assignee', '--remove-assignee', '--add-reviewer',
  '--remove-reviewer', '--add-project', '--remove-project', '--ref', '-f', '--raw-field', '--field', '-X', '--method', '--header',
  '--input', '--hostname', '--preview', '--cache', '-n', '--notes', '--notes-file', '--target', '--discussion-category', '--name',
  '-d', '--description', '-h', '--homepage', '--visibility', '-g', '--gitignore', '--license', '--team', '-s', '--source', '--remote',
  '-o', '--org', '-e', '--env', '-u', '--user', '--body-text', '-c', '--comment', '-r', '--reason', '--branch', '--fork-name',
]);
const GH_PR_URL = /^https?:\/\/(?:www\.)?github\.com\/([^/\s]+)\/([^/\s#?]+)(?:[/#?]|$)/i;

/** A `-R` value: OWNER/REPO, HOST/OWNER/REPO or a URL. */
function ghRepoArg(w: Word): Target {
  if (w.dynamic) return unknown('the repository is a value Escanor cannot see');
  const url = GH_PR_URL.exec(w.text);
  if (url) return repoTarget(`${url[1]}/${url[2].replace(/\.git$/i, '')}`);
  const parts = w.text.split('/');
  if (parts.length === 3 && GITHUB_HOSTS.has(parts[0].toLowerCase())) return repoTarget(`${parts[1]}/${parts[2]}`);
  if (parts.length === 2) return repoTarget(w.text);
  return unknown(`Escanor cannot read the repository "${w.text}"`);
}

function repoTarget(raw: string): Target {
  const name = repoName(raw.replace(/\.git$/i, ''));
  return name ? { t: 'repo', name } : unknown(`Escanor cannot read the repository "${raw}"`);
}

/** gh's own commands that change no repository's code, pull requests or settings (or not at all). */
const GH_READ_GROUPS = new Set([
  'auth', 'browse', 'codespace', 'cs', 'gist', 'org', 'project', 'search', 'status', 'ssh-key', 'gpg-key', 'ruleset', 'rs',
  'attestation', 'completion', 'config', 'extension', 'ext', 'extensions', 'alias', 'help', 'version', 'copilot', 'preview',
  'accessibility', 'a11y', 'agent-task', 'licenses', '--version', '--help', '-h', '-v',
]);

function classifyGh(words: Word[], at: number, cwd: string | null, env: Map<string, Word>, c: Ctx, stdin = false): Write | null {
  const group = words[at + 1];
  const verb = words[at + 2];
  if (!group) return null;
  if (group.dynamic || (GH_WRITES.has(group.text) && verb?.dynamic)) return { what: 'gh', targets: [unknown('it runs a gh command Escanor cannot see')] };
  const ctx: GitCtx = { cwd, args: [], run: c.run };
  if (group.text === 'api') return classifyGhApi(words, at + 2, ctx, env, stdin);
  // Not one of gh's own commands: an alias (`gh m 3` for pr merge -R ...) or an extension, which could do anything.
  if (!GH_WRITES.has(group.text) && !GH_READ_GROUPS.has(group.text)) {
    return { what: `gh ${group.text}`, targets: [unknown('it is a gh alias or extension Escanor cannot check; use the gh command itself')] };
  }
  const verbs = GH_WRITES.get(group.text);
  if (!verbs || !verb || !verbs.has(verb.text)) return null;
  let rest = at + 3;
  if (group.text === 'repo' && (verb.text === 'deploy-key' || verb.text === 'autolink')) {
    if (!['add', 'delete', 'create'].includes(words[at + 3]?.text ?? '')) return null;
    rest = at + 4;
  }
  const what = `gh ${group.text} ${verb.text}`;
  if (group.text === 'repo' && verb.text === 'fork') return { what, targets: [unknown('a fork is a new repository')] };
  let branch: BranchCheck | undefined = group.text === 'pr' && verb.text === 'merge' ? { k: 'refuse', why: MERGE_BLOCKED }
    : group.text === 'repo' && verb.text === 'sync' ? { k: 'refuse', why: protectedPush('the default branch') } : undefined;
  const heads: Word[] = [];
  const targets: Target[] = [];
  const positionals: Word[] = [];
  for (let i = rest; i < words.length; i++) {
    const w = words[i];
    const t = w.text;
    if (t === '--') {
      positionals.push(...words.slice(i + 1));
      break;
    }
    if (t.startsWith('-') && t.length > 1) {
      const eq = t.indexOf('=');
      const name = eq >= 0 ? t.slice(0, eq) : t;
      const value: Word | undefined = eq >= 0 ? { ...w, text: t.slice(eq + 1) } : GH_VALUE_OPTS.has(name) ? words[++i] : undefined;
      if ((name === '-R' || name === '--repo') && value) targets.push(ghRepoArg(value));
      else if (group.text === 'pr' && verb.text === 'create' && (name === '-H' || name === '--head') && value) heads.push(value);
      else if ((group.text === 'secret' || group.text === 'variable') && ['-o', '--org', '-u', '--user'].includes(name)) {
        targets.push(unknown('it changes an organisation or user setting, not one repository'));
      } else if (value && !GH_MESSAGE_OPTS.has(name) && name !== '-s' && name !== '--source' && GH_PR_URL.test(value.text)) {
        targets.push(ghRepoArg(value));
      }
      continue;
    }
    positionals.push(w);
  }
  for (const p of positionals) {
    if (p.dynamic && group.text === 'repo') targets.push(unknown('the repository is a value Escanor cannot see'));
    else if (GH_PR_URL.test(p.text)) targets.push(ghRepoArg(p));
    else if (group.text === 'repo' && p.text.includes('/')) targets.push(ghRepoArg(p));
    else if (group.text === 'repo' && verb.text === 'create') targets.push(unknown('it makes a new repository'));
  }
  if (group.text === 'pr' && verb.text === 'create' && heads.length) {
    // A pull request whose head is main: GitHub's "update branch" would then merge into main (re-review I4)
    branch = heads.some((h) => h.dynamic) ? { k: 'refuse', why: branchUnknown('the branch is a value Escanor cannot see') }
      : { k: 'names', names: heads.map((h) => prHead(h.text)) };
  }
  if (group.text === 'pr' && verb.text === 'update-branch') {
    // It merges the base into the pull request's head: only a fix branch of Escanor's own, named as the selector (re-review I4)
    const sel = positionals.filter((p) => !GH_PR_URL.test(p.text));
    const mine = positionals.length === 1 && sel.length === 1 && !sel[0].dynamic && ((n) => !n.odd && n.name.startsWith(OURS))(normaliseBranch(sel[0].text));
    if (!mine) branch = { k: 'refuse', why: UPDATE_BRANCH_BLOCKED };
  }
  if (targets.length === 0) {
    const fromEnv = env.get('GH_REPO');
    targets.push(fromEnv ? ghRepoArg(fromEnv) : ctx.cwd ? { t: 'folder', ctx } : unknown('Escanor cannot tell which folder it runs in'));
  }
  return { what, targets, ...(branch ? { branch } : {}) };
}

function classifyGhApi(words: Word[], from: number, ctx: GitCtx, env: Map<string, Word>, stdin: boolean): Write | null {
  let method: Word | undefined;
  let fields = false;
  let input = false;
  const fieldValues: Word[] = [];
  let endpoint: Word | undefined;
  for (let i = from; i < words.length; i++) {
    const w = words[i];
    const t = w.text;
    if (t.startsWith('-') && t.length > 1) {
      const eq = t.indexOf('=');
      const name = eq >= 0 ? t.slice(0, eq) : t;
      const value: Word | undefined = eq >= 0 ? { ...w, text: t.slice(eq + 1) } : GH_VALUE_OPTS.has(name) ? words[++i] : undefined;
      if (name === '-X' || name === '--method') method = value;
      else if (/^-X./.test(t)) method = { ...w, text: t.slice(2) };
      else if (['-f', '-F', '--field', '--raw-field'].includes(name) || /^-[fF]./.test(t)) {
        fields = true;
        const v = value ?? (/^-[fF]./.test(t) ? { ...w, text: t.slice(2) } : undefined);
        if (v) fieldValues.push(v);
      }
      else if (name === '--input') input = true;
      continue;
    }
    endpoint ??= w;
  }
  if (method?.dynamic) return { what: 'gh api', targets: [unknown('its method is a value Escanor cannot see')] };
  if (endpoint && !endpoint.dynamic && endpoint.text.replace(/^https?:\/\/api\.github\.com\//i, '').replace(/^\/+/, '') === 'graphql') {
    // A read only when its query is right there and is plainly one; a query from a file or stdin, or with a mutation, is a write.
    const query = fieldValues.find((v) => v.text.startsWith('query='));
    const q = query?.text.slice(6) ?? '';
    const plainRead = query && !query.dynamic && !input && !stdin && !q.startsWith('@') && /^\s*(?:query\b|\{)/.test(q) &&
      !fieldValues.some((v) => v.dynamic || /^[^=]*=@/.test(v.text)) && !words.slice(from).some((w) => /\bmutation\b/i.test(w.text));
    return plainRead ? null : { what: 'gh api graphql', targets: [unknown('a GraphQL call that is not plainly a read does not name one repository')] };
  }
  const verb = (method?.text ?? (fields || input ? 'POST' : 'GET')).toUpperCase();
  if (verb === 'GET' || verb === 'HEAD') return null;
  if (!endpoint) return null;
  if (endpoint.dynamic) return { what: 'gh api', targets: [unknown('its address is a value Escanor cannot see')] };
  const path = endpoint.text.replace(/^https?:\/\/api\.github\.com\//i, '').replace(/^\/+/, '');
  const segs = path.split(/[/?#]/);
  if (segs[0] !== 'repos' || !segs[1] || !segs[2]) return { what: `gh api ${verb}`, targets: [unknown('that API address does not name one repository')] };
  const branch = apiBranch(verb, path.split(/[?#]/)[0].split('/').slice(3).join('/'), fieldValues, input || stdin, path.split(/[?#]/)[0]);
  if (segs[1] === '{owner}' && segs[2] === '{repo}') {
    const fromEnv = env.get('GH_REPO');
    return { what: `gh api ${verb}`, targets: [fromEnv ? ghRepoArg(fromEnv) : ctx.cwd ? { t: 'folder', ctx } : unknown('Escanor cannot tell which folder it runs in')], ...(branch ? { branch } : {}) };
  }
  return { what: `gh api ${verb}`, targets: [repoTarget(`${segs[1]}/${segs[2]}`)], ...(branch ? { branch } : {}) };
}

/** MAINWRITE: the branch a gh api write to a repository's files, refs or merges lands on (`rest`: the path after repos/o/r/). */
function apiBranch(verb: string, rest: string, fieldValues: Word[], fromInput: boolean, whole = rest): BranchCheck | undefined {
  const field = (key: string): Word | undefined => {
    const hit = [...fieldValues].reverse().find((v) => v.text.startsWith(`${key}=`));
    return hit ? { ...hit, text: hit.text.slice(key.length + 1) } : undefined;
  };
  const named = (key: string, unnamed: string): BranchCheck => {
    const v = field(key);
    if (!v) return { k: 'refuse', why: fromInput ? branchUnknown('its body comes from a file or stdin') : unnamed };
    if (v.dynamic || v.text.startsWith('@')) return { k: 'refuse', why: branchUnknown('the branch is a value Escanor cannot see') };
    return { k: 'names', names: [stripHeads(v.text)] };
  };
  // GitHub reads fixed path words in any case: matched without case. A ref is read by normaliseBranch (heads%2Fmain, main/).
  const ref = /^git\/refs\/(.+)$/i.exec(rest);
  if (ref && (verb === 'PATCH' || verb === 'DELETE')) return { k: 'names', names: [stripHeads(ref[1])] };
  // `//`, a dot segment or a `%` may still reach a merge or a file on main: not read, refused (re-review I5)
  if (/\/\/|%/.test(whole) || whole.split('/').some((seg) => seg === '.' || seg === '..')) return { k: 'refuse', why: branchUnknown('its address is not a plain one') };
  if (/^pulls\/[^/]+\/merge\/?$/i.test(rest)) return { k: 'refuse', why: MERGE_BLOCKED };
  if (/^pulls\/[^/]+\/update-branch\/?$/i.test(rest)) return { k: 'refuse', why: UPDATE_BRANCH_BLOCKED };
  if (/^pulls\/?$/i.test(rest) && verb === 'POST') {
    const head = field('head');
    if (!head) return fromInput ? { k: 'refuse', why: branchUnknown('its body comes from a file or stdin') } : undefined;
    if (head.dynamic || head.text.startsWith('@')) return { k: 'refuse', why: branchUnknown('the branch is a value Escanor cannot see') };
    return { k: 'names', names: [prHead(head.text)] };
  }
  if (/^contents\//i.test(rest) && (verb === 'PUT' || verb === 'DELETE')) return named('branch', NO_BRANCH_NAMED);
  if (/^git\/refs\/?$/i.test(rest) && verb === 'POST') return named('ref', branchUnknown('it names no ref'));
  if (/^merges\/?$/i.test(rest) && verb === 'POST') return named('base', branchUnknown('it names no base branch'));
  if (/^merge-upstream\/?$/i.test(rest) && verb === 'POST') return named('branch', branchUnknown('it names no branch'));
  return undefined;
}

const RUNNERS = new Set(['xargs', 'sudo', 'su', 'doas', 'watch', 'parallel', 'script', 'flock', 'chroot', 'setsid', 'unbuffer']);
/** A program that runs words it is given as a command, given one Escanor cannot see (a variable or a substitution). */
function runsItsArgs(words: Word[], start: number): boolean {
  const p = programOf(words[start]);
  const args = words.slice(start + 1);
  if (p === 'eval' || p === 'source' || p === '.') return args.some((w) => w.dynamic);
  if (SHELLS.has(p) && p !== 'ssh') {
    const c = args.findIndex((w) => /^-[A-Za-z]*c[A-Za-z]*$/.test(w.text));
    return c >= 0 && args.slice(c + 1).some((w) => w.dynamic);
  }
  if (RUNNERS.has(p) || p === 'find') return args.some((w) => w.dynamic && !w.subs.length && /^\$/.test(w.text)) || args.some((w) => w.dynamic && w.text.startsWith('$(…)'));
  return false;
}

/** The write a simple command does when it starts with git/gh/hub at `at`, or null. */
async function classifyAt(words: Word[], at: number, cwd: string | null, env: Map<string, Word>, c: Ctx, stdin = true): Promise<Write | null> {
  const p = programOf(words[at]);
  if (!WRITE_PROGRAMS.has(p)) return null;
  if (HTTP_PROGRAMS.has(p) || OTHER_HTTP.has(p)) return classifyHttp(words, at, env, stdin);
  return p === 'gh' ? classifyGh(words, at, cwd, env, c, stdin) : classifyGit(words, at, cwd, env, c);
}

/**
 * HTTP clients to GitHub (MAINWRITE2, re-review 1). Not every curl spelling is parsed for a write: it is turned round. In a limited
 * chat a call that may reach GitHub (any word naming github, a URL Escanor cannot see, a curl URL glob, a `%` host) is a WRITE
 * unless it is provably a plain read: one URL, GET (or HEAD by -I/--head with no -X), no body, upload or form, no config file
 * (-K, wget -i/-e, CURL_HOME/WGETRC/HOME), no option Escanor does not know, no stdin body (httpie). The words are the shell's
 * words (quotes and backslashes already gone), so `"-XPUT"`, `-\XPUT` and `$'-XPUT'` are the option they are to curl.
 * A header, a user or an output file is never what makes it a write (`-H "Authorization: token $T"` is a read).
 */
const GITHUB_WORD = /github/i;
/** Settings files a client reads by itself: naming one (writing it) in a limited chat is not checked, so refused. */
const CLIENT_RC = /(?:curlrc|wgetrc)\b/i;
const CLIENT_ENV = new Set(['CURL_HOME', 'WGETRC', 'HOME', 'XDG_CONFIG_HOME', 'SYSTEM_WGETRC']);
/** Other HTTP and socket clients: never checked closely; refused when they name GitHub (re-review M2). */
const OTHER_HTTP = new Set(['curlie', 'lwp-request', 'GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'PATCH', 'openssl', 'nc', 'ncat', 'netcat', 'socat', 'telnet', 'aria2c']);
// curl: short options that take a value (the rest of a cluster, or the next word), and flags that take none.
const CURL_SHORT_VALUE = new Set('XdFTHouAebcmwxKrUEYyzCtQ'.split(''));
const CURL_SHORT_FLAG = new Set('sSfLivkqNGIgn0OJRlZjp123V46#'.split(''));
const CURL_LONG_FLAG = new Set(['--silent', '--show-error', '--fail', '--fail-with-body', '--fail-early', '--location', '--include', '--verbose', '--insecure',
  '--compressed', '--no-progress-meter', '--http1.0', '--http1.1', '--http2', '--get', '--head', '--globoff', '--netrc', '--remote-name', '--remote-header-name',
  '--no-buffer', '--location-trusted', '--retry-connrefused', '--retry-all-errors', '--ipv4', '--ipv6', '--disable']);
const CURL_LONG_VALUE = new Set(['--header', '--output', '--user', '--user-agent', '--referer', '--cookie', '--cookie-jar', '--max-time', '--connect-timeout',
  '--write-out', '--proxy', '--retry', '--retry-delay', '--retry-max-time', '--cacert', '--cert', '--key', '--range', '--proxy-user', '--resolve', '--connect-to',
  '--limit-rate', '--oauth2-bearer', '--max-redirs', '--output-dir', '--netrc-file', '--dump-header', '--trace', '--trace-ascii', '--stderr']);
const WGET_SHORT_VALUE = new Set('oaeiBtOTwQPUlARDIX'.split(''));
const WGET_LONG_VALUE = new Set(['--header', '--output-document', '--output-file', '--append-output', '--user-agent', '--user', '--password', '--http-user',
  '--http-password', '--timeout', '--tries', '--load-cookies', '--save-cookies', '--directory-prefix', '--referer', '--wait', '--quota', '--level',
  '--accept', '--reject', '--domains', '--include-directories', '--exclude-directories', '--ca-certificate', '--certificate', '--private-key',
  '--dns-timeout', '--connect-timeout', '--read-timeout', '--limit-rate', '--progress', '--bind-address']);
const HTTPIE_VALUE = new Set(['-a', '--auth', '-A', '--auth-type', '-o', '--output', '--session', '--session-read-only', '--verify', '--cert', '--cert-key',
  '--cert-key-pass', '--timeout', '--proxy', '-p', '--print', '-P', '--history-print', '--pretty', '-s', '--style', '--format-options', '--default-scheme',
  '--max-redirects', '--max-headers', '--ssl', '--ciphers', '--response-charset', '--response-mime', '--boundary']);
const HTTPIE_FLAG = new Set(['-j', '--json', '-v', '--verbose', '-h', '--headers', '-b', '--body', '-q', '--quiet', '--check-status', '--follow', '-F', '-d',
  '--download', '-c', '--continue', '--offline', '-x', '--compress', '--chunked', '--all', '--path-as-is', '--sorted', '--unsorted', '-S', '--stream',
  '--ignore-netrc', '--meta', '--debug', '--traceback', '-m', '--multipart']);

/** The host of a URL word (userinfo and port dropped), lower case; '' when it has none. */
function hostOf(url: string): string {
  const m = /^(?:[a-z][a-z0-9+.-]*:\/\/)?([^/?#]*)/i.exec(url);
  const authority = m ? m[1] : '';
  return authority.slice(authority.lastIndexOf('@') + 1).replace(/:[^:\]]*$/, '').toLowerCase();
}

/** curl / wget / httpie (and other clients) that may reach GitHub: refused unless plainly a read (it skips every branch check). */
function classifyHttp(words: Word[], at: number, env: Map<string, Word>, stdin: boolean): Write | null {
  const p = programOf(words[at]);
  const rest = words.slice(at + 1);
  const refuse: Write = { what: `${p} to GitHub`, targets: [], branch: { k: 'refuse', why: HTTP_BLOCKED } };
  const mentions = rest.some((w) => GITHUB_WORD.test(w.text));
  if (OTHER_HTTP.has(p)) return mentions ? refuse : null;
  let explicit: Word | null = null; // -X / --request / --method: the last one wins
  let head = false;
  let body = false;
  let unsure = false;
  let config = [...env.keys()].some((k) => CLIENT_ENV.has(k));
  let globoff = false;
  const urls: Word[] = [];
  const positional = (w: Word) => {
    if (w.dynamic && w.text.startsWith('$')) unsure = true; // "$X" may be an option once expanded
    urls.push(w);
  };
  if (p === 'curl') {
    for (let i = 0; i < rest.length; i++) {
      const w = rest[i];
      const t = w.text;
      if (!t.startsWith('-') || t === '-') {
        if (t === '-') unsure = true;
        else positional(w);
        continue;
      }
      if (t === '--') {
        unsure = true;
        continue;
      }
      if (t.startsWith('--')) {
        const eq = t.indexOf('=');
        const name = eq > 0 ? t.slice(0, eq) : t;
        const valueWord: Word | undefined = eq > 0 ? { ...w, text: t.slice(eq + 1) } : rest[i + 1];
        const took = eq > 0 ? 0 : 1;
        if (name === '--request') {
          explicit = valueWord ?? { ...w, text: '?' };
          i += took;
        } else if (/^--(?:data|json|form|upload-file)/.test(name)) {
          body = true;
          i += took;
        } else if (name === '--url') {
          if (valueWord) positional(valueWord);
          i += took;
        } else if (name === '--config' || name === '--next') config = true;
        else if (CURL_LONG_VALUE.has(name)) i += took;
        else if (!CURL_LONG_FLAG.has(name)) unsure = true;
        if (name === '--head') head = true;
        if (name === '--globoff') globoff = true;
        if (name === '--get') continue;
        continue;
      }
      for (let j = 1; j < t.length; j++) {
        const ch = t[j];
        if (CURL_SHORT_VALUE.has(ch)) {
          let value: Word | undefined = j + 1 < t.length ? { ...w, text: t.slice(j + 1) } : undefined;
          if (!value) value = rest[++i];
          if (ch === 'X') explicit = value ?? { ...w, text: '?' };
          else if (ch === 'd' || ch === 'F' || ch === 'T') body = true;
          else if (ch === 'K') config = true;
          else if (ch === 'Q') unsure = true; // commands sent to the server
          break;
        }
        if (ch === 'I') head = true;
        else if (ch === 'g') globoff = true;
        else if (!CURL_SHORT_FLAG.has(ch)) unsure = true; // `-:` (--next) too
      }
    }
  } else if (p === 'wget') {
    for (let i = 0; i < rest.length; i++) {
      const w = rest[i];
      const t = w.text;
      if (!t.startsWith('-') || t === '-') {
        positional(w);
        continue;
      }
      if (t.startsWith('--')) {
        const eq = t.indexOf('=');
        const name = eq > 0 ? t.slice(0, eq) : t;
        const valueWord: Word | undefined = eq > 0 ? { ...w, text: t.slice(eq + 1) } : rest[i + 1];
        const took = eq > 0 ? 0 : 1;
        if (name === '--method') {
          explicit = valueWord ?? { ...w, text: '?' };
          i += took;
        } else if (/^--(?:post|body)-/.test(name)) {
          body = true;
          i += took;
        } else if (name === '--input-file' || name === '--execute' || name === '--config') config = true;
        else if (WGET_LONG_VALUE.has(name)) i += took;
        continue;
      }
      for (let j = 1; j < t.length; j++) {
        const ch = t[j];
        if (ch === 'n') {
          j++; // -nv, -nc, -nd, -nH
          continue;
        }
        if (ch === 'e' || ch === 'i') config = true; // wgetrc commands (method=PUT), or a list of URLs from a file
        if (WGET_SHORT_VALUE.has(ch)) {
          if (j + 1 >= t.length) i++;
          break;
        }
      }
    }
  } else {
    // httpie / xh: [METHOD] URL [items]; a body from items, --raw, or stdin
    const pos: Word[] = [];
    let ignoreStdin = false;
    for (let i = 0; i < rest.length; i++) {
      const w = rest[i];
      const t = w.text;
      if (t.startsWith('-') && t.length > 1) {
        const eq = t.indexOf('=');
        const name = eq > 0 ? t.slice(0, eq) : t;
        if (name === '--raw') {
          body = true;
          if (eq < 0) i++;
        } else if (name === '-f' || name === '--form') body = true;
        else if (name === '-I' || name === '--ignore-stdin') ignoreStdin = true;
        else if (HTTPIE_VALUE.has(name)) {
          if (eq < 0) i++;
        } else if (!HTTPIE_FLAG.has(name)) unsure = true;
        continue;
      }
      if (w.dynamic && t.startsWith('$')) unsure = true;
      pos.push(w);
    }
    let k = 0;
    if (pos[k] && /^[A-Za-z]+$/.test(pos[k].text) && pos[k + 1]) explicit = pos[k++];
    if (pos[k]) urls.push(pos[k++]);
    for (const item of pos.slice(k)) if (/^[^=:@]*(?:=|:=|@)/.test(item.text) && !/^[^=]*==/.test(item.text)) body = true;
    if (stdin && !ignoreStdin) body = true; // httpie sends what is piped into it
  }
  if (config) return refuse; // the URL or the method comes from a file Escanor cannot see (re-review I2)
  if (explicit?.dynamic) unsure = true;
  const verb = explicit ? explicit.text.toUpperCase() : head ? 'HEAD' : body ? 'POST' : 'GET';
  const safeVerbs = explicit ? ['GET'] : ['GET', 'HEAD']; // -I never makes an explicit -X PUT a read (re-review C2)
  const globbed = p === 'curl' && !globoff && urls.some((u) => /[[{]/.test(u.text));
  const read = !unsure && !body && safeVerbs.includes(verb) && urls.length === 1 && !globbed;
  const odd = urls.some((u) => {
    const host = hostOf(u.text);
    return u.dynamic || /[%[{]/.test(host) || host.endsWith('.');
  });
  if (read && !(mentions && odd)) return null;
  if (mentions) return refuse;
  // Not plainly a read, to an address Escanor cannot read as a plain host that is not GitHub's
  if (globbed || urls.some((u) => u.dynamic || /[%]/.test(hostOf(u.text)))) return refuse;
  return null;
}

/** Words of a git/gh command that are only words for people (a commit message, a PR body): not read as commands. */
function messageWords(words: Word[], start: number): Set<number> {
  const out = new Set<number>();
  const p = programOf(words[start]);
  if (p !== 'git' && p !== 'gh' && p !== 'hub') return out;
  for (let i = start + 1; i < words.length; i++) {
    const t = words[i].text;
    const gitMsg = p !== 'gh' && (t === '-m' || t === '--message' || t === '-F' || /^-[A-Za-z]*m$/.test(t));
    if (gitMsg || (p === 'gh' && GH_MESSAGE_OPTS.has(t))) out.add(i + 1);
    else if (/^--(?:message|title|body|subject|notes)=/.test(t) || (p !== 'gh' && /^-m./.test(t))) out.add(i);
  }
  return out;
}

type Found = { simple: Simple; index: number; write: Write; top: boolean };

/** Every write in a command line, at the top level or hidden inside it (a substitution, `bash -c`, `xargs`...). */
async function findWrites(parsed: Parsed, c: Ctx, cwdOf: (k: number) => string | null, top: boolean): Promise<{ found: Found[]; hidden: boolean }> {
  const found: Found[] = [];
  let hidden = false;
  const inner = async (text: string) => {
    if (c.depth >= 4) {
      hidden ||= looksLikeWrite(text);
      return;
    }
    let p: Parsed;
    try {
      p = parse(text);
    } catch {
      hidden ||= looksLikeWrite(text);
      return;
    }
    const r = await findWrites(p, { ...c, depth: c.depth + 1 }, () => null, false);
    hidden ||= r.hidden || r.found.length > 0;
  };
  for (let k = 0; k < parsed.commands.length; k++) {
    const s = parsed.commands[k];
    const { start, env, opaque } = unwrap(s.words);
    const cwd = cwdOf(k);
    const prog = s.words[start];
    if (prog && !prog.dynamic && WRITE_PROGRAMS.has(programOf(prog))) {
      const w = await classifyAt(s.words, start, cwd, env, c, Boolean(s.stdin) || s.heredocs.length > 0 || s.prev === '|');
      if (w) found.push({ simple: s, index: k, write: opaque ? { ...w, targets: [unknown('it changes folder through env')] } : w, top });
    } else if (prog?.dynamic) {
      hidden = true; // `$G $P url`, `"$(which git)" push`: a program Escanor cannot see may be git or gh
    } else if (runsItsArgs(s.words, start)) {
      hidden = true; // `eval "$X"`, `bash -c "$CMD"`, `xargs $G`, `sudo "$G"`: a command Escanor cannot see
    }
    const skip = messageWords(s.words, start);
    // git/gh further along (`xargs git push`, `sudo git push`, `find -exec gh pr merge`): a write Escanor cannot place.
    for (let i = start + 1; i < s.words.length; i++) {
      // (`GET`/`PUT` as a later word is an HTTP verb, as in `http GET <url>`; as a program it is lwp-request's)
      if (!skip.has(i) && !s.words[i].dynamic && !/^[A-Z]+$/.test(s.words[i].text) && WRITE_PROGRAMS.has(programOf(s.words[i])) &&
        (await classifyAt(s.words, i, null, new Map(), c))) {
        hidden = true;
        break;
      }
    }
    const shell = SHELLS.has(programOf(prog));
    const interpreter = INTERPRETERS.has(programOf(prog)) || /^python\d/.test(programOf(prog));
    for (let i = 0; i < s.words.length; i++) {
      const w = s.words[i];
      for (const sub of w.subs) await inner(sub);
      if (skip.has(i) || i <= start) continue;
      // Code for another language (python -c, node -e): not read as shell, only looked at for a push or gh write.
      if (interpreter) hidden ||= looksLikeWrite(w.text);
      else if (/[\s;&|]/.test(w.text) && /git|gh|hub|push/.test(w.text)) await inner(w.text);
    }
    for (const r of s.redirects) for (const sub of r.subs) await inner(sub);
    // A client's own settings file (~/.curlrc: `request = PUT`) written or named: what it sets is not seen later (re-review I2)
    if ([...s.words, ...s.redirects].some((w) => CLIENT_RC.test(w.text))) hidden = true;
    // Words, here-strings and here-documents of any other program that write to GitHub's API (re-review M2)
    if (!WRITE_PROGRAMS.has(programOf(prog)) && !interpreter) {
      hidden ||= s.words.some((w, i) => i > start && !skip.has(i) && API_WRITE.test(w.text)) || s.redirects.some((r) => API_WRITE.test(r.text)) ||
        s.heredocs.some((h) => API_WRITE.test(h.body));
    }
    for (const h of s.heredocs) {
      if (!h.quoted) for (const sub of substitutionsIn(h.body)) await inner(sub);
      if (shell) await inner(h.body);
      else if (interpreter) hidden ||= looksLikeWrite(h.body);
    }
  }
  return { found, hidden };
}

// ---------------------------------------------------------------------------------------------------- where it goes

/** git as the chat runs it, reading only (safe.directory: a folder the chat user owns is still read when this runs as another). */
function gitOut(ctx: GitCtx, args: string[]): Promise<string | null> {
  return ctx.cwd ? ctx.run('git', ['-c', 'safe.directory=*', ...ctx.args, ...args], ctx.cwd) : Promise.resolve(null);
}

async function sshHostnameVia(run: Runner, alias: string): Promise<string | null> {
  if (!/^[A-Za-z0-9._-]+$/.test(alias)) return null;
  const out = await run('ssh', ['-G', '--', alias], '/');
  const m = out ? /^hostname (\S+)$/m.exec(out) : null;
  return m ? m[1].toLowerCase() : null;
}

/**
 * Hosts of Escanor's git proxy: escanor.in and its subdomains, and the proxy a managed machine's environment points github.com at
 * (mongo-backend workers.cloud_worker_env: GIT_CONFIG_KEY_n = url.<root>/git/github.com/.insteadOf). Any other host with a
 * `/git/github.com/` path is not trusted to be GitHub.
 */
export function proxyHosts(env: NodeJS.ProcessEnv | undefined): Set<string> {
  const out = new Set<string>();
  for (const [k, v] of Object.entries(env ?? {})) {
    if (!/^GIT_CONFIG_KEY_\d+$/.test(k) || typeof v !== 'string') continue;
    const m = /^url\.(https?:\/\/[^/]+)(?:\/[^\n]*)?\/git\/github\.com\/?\.insteadof$/i.exec(v);
    if (m) {
      try {
        out.add(new URL(m[1]).hostname.toLowerCase());
      } catch {
        // not a URL
      }
    }
  }
  return out;
}
const isEscanorHost = (host: string) => host === 'escanor.in' || host.endsWith('.escanor.in');

/** owner/name of a GitHub remote URL (https, ssh, scp-like `git@github.com:o/r.git`, an ssh host alias, Escanor's git proxy), or null. */
export async function repoOfUrl(
  url: string,
  sshHostname: (alias: string) => Promise<string | null> = (a) => sshHostnameVia(agentRunner, a),
  proxies: Set<string> = proxyHosts(process.env),
): Promise<string | null> {
  const u = url.trim();
  let host: string;
  let path: string;
  let ssh: boolean;
  const full = /^([a-z][a-z0-9+.-]*):\/\/([^/?#]*)(\/[^?#]*)?/i.exec(u);
  if (full) {
    const scheme = full[1].toLowerCase();
    if (!['https', 'http', 'ssh', 'git', 'git+ssh', 'ssh+git'].includes(scheme)) return null;
    const authority = full[2];
    host = authority.slice(authority.lastIndexOf('@') + 1).replace(/:\d*$/, '');
    path = full[3] ?? '';
    ssh = scheme.includes('ssh');
  } else {
    const scp = /^(?:[^@/:]+@)?([^/:]+):(.*)$/.exec(u);
    if (!scp || scp[1].length < 2) return null; // C:\path is a folder
    host = scp[1];
    path = scp[2];
    ssh = true;
  }
  host = host.toLowerCase().replace(/^\[|\]$/g, '');
  if (ssh && !GITHUB_HOSTS.has(host)) host = (await sshHostname(host))?.toLowerCase() ?? host;
  const segs = path.split('/').filter(Boolean);
  if (GITHUB_HOSTS.has(host)) return segs.length === 2 ? repoName(`${segs[0]}/${segs[1].replace(/\.git$/i, '')}`) : null;
  // Escanor's git proxy on a managed machine: <root>/git/github.com/<owner>/<repo>, on a host known to be the proxy.
  const k = segs.length - 3;
  if (!ssh && (isEscanorHost(host) || proxies.has(host)) && k >= 1 && segs[k] === 'github.com' && segs[k - 1] === 'git') return repoName(`${segs[k + 1]}/${segs[k + 2].replace(/\.git$/i, '')}`);
  return null;
}

/** Every repository a target names (null for one that cannot be worked out), with why. */
async function reposOfTarget(t: Target, opts: WriteCheckOptions): Promise<{ repos: string[] } | { why: string }> {
  const run = opts.run ?? agentRunner;
  const sshFn = opts.sshHostname ?? ((a: string) => sshHostnameVia(run, a));
  const proxies = proxyHosts(opts.env ?? process.env);
  const ssh = (u: string) => repoOfUrl(u, sshFn, proxies);
  if (t.t === 'unknown') return { why: t.why };
  if (t.t === 'repo') return { repos: [t.name] };
  if (t.t === 'folder') {
    const names = (await gitOut(t.ctx, ['remote']))?.split('\n').filter(Boolean);
    if (!names) return { why: 'the folder is not a git repository' };
    const repos = new Set<string>();
    for (const name of names) {
      const urls = [...((await gitOut(t.ctx, ['remote', 'get-url', '--all', name])) ?? '').split('\n'), ...((await gitOut(t.ctx, ['remote', 'get-url', '--push', '--all', name])) ?? '').split('\n')];
      for (const url of urls.filter(Boolean)) {
        const repo = await ssh(url);
        if (repo) repos.add(repo);
      }
    }
    return repos.size ? { repos: [...repos] } : { why: 'the folder has no GitHub remote' };
  }
  // git push: the remote it names (or the default one), and every URL it pushes to.
  let remote = t.remote;
  if (remote === null) {
    const branch = await gitOut(t.ctx, ['symbolic-ref', '-q', '--short', 'HEAD']);
    const cfg = (key: string) => gitOut(t.ctx, ['config', '--get', key]);
    remote = (branch && (await cfg(`branch.${branch}.pushRemote`))) || (await cfg('remote.pushDefault')) || (branch && (await cfg(`branch.${branch}.remote`))) || 'origin';
  }
  let urls = (await gitOut(t.ctx, ['remote', 'get-url', '--push', '--all', '--', remote]))?.split('\n').filter(Boolean);
  if (!urls) {
    const names = await gitOut(t.ctx, ['remote']);
    if (names === null) return { why: 'the folder is not a git repository' };
    if (names.split('\n').includes(remote)) return { why: `Escanor could not read the remote "${remote}"` };
    const expanded = await gitOut(t.ctx, ['ls-remote', '--get-url', '--', remote]);
    urls = [expanded || remote];
  }
  const repos: string[] = [];
  for (const url of urls) {
    const repo = await ssh(url);
    if (!repo) return { why: `"${url.replace(/\/\/[^@/]*@/, '//')}" is not a GitHub repository Escanor can read` };
    repos.push(repo);
  }
  return { repos };
}

// ---------------------------------------------------------------------------------------------------- the check

const listOf = (allowed: string[]) => (allowed.length ? allowed.join(', ') : 'none');
const lead = (allowed: string[]) => `Escanor may only change the repos you picked: ${listOf(allowed)}.`;

export const offList = (allowed: string[], repo: string) =>
  `${lead(allowed)} This command would change ${repo}, which is not one of them. Do not try another way: if the fix belongs in ${repo}, stop and say so.`;
export const cannotTell = (allowed: string[], why: string) =>
  `${lead(allowed)} Escanor could not tell which repository this command changes (${why}), so it was blocked. Run it on its own from the ` +
  'repository\'s folder, naming the remote (git push origin <branch>) or the repository (gh ... -R owner/repo).';
export const notAlone = (allowed: string[]) =>
  `${lead(allowed)} A command that pushes or changes a pull request is checked only when it runs on its own (after nothing but cd <folder> &&, ` +
  'git add or git commit), so this one was blocked. Run the push or gh command by itself, e.g. git -C <folder> push origin <branch>.';

// ---------------------------------------------------------------------------------------------------- MAINWRITE: never main

/** Always protected, whatever the repository says (mongo-backend autopilot/main_guard.py PROTECTED: the same names). */
const PROTECTED = new Set(['main', 'master', 'trunk', 'develop', 'development', 'prod', 'production', 'release', 'stable']);
export const isProtectedBranch = (branch: string) => PROTECTED.has(branch.toLowerCase()) || branch.toLowerCase().startsWith('release/');
const OURS = 'escanor/';
/** A pull request's head as a branch name: `owner:branch` -> branch. */
const prHead = (head: string) => (head.includes(':') ? head.slice(head.indexOf(':') + 1) : head);
const stripHeads = (ref: string) => ref.replace(/^\+/, '').replace(/^(refs\/)?heads\//, '');
/** A branch name as compared: percent-decoded, `refs/heads/` dropped, no trailing `/`, lower case; odd when GitHub may read it as
 * another branch (HEAD, @, `%`, `..`, spaces, a trailing `/`). MAINWRITE review I1/I3. */
export function normaliseBranch(raw: string): { name: string; odd: boolean } {
  let odd = raw !== raw.trim() || /%|\.\.|\/$|\s/.test(raw);
  let name = raw;
  for (let k = 0; k < 3; k++) {
    let decoded: string;
    try {
      decoded = decodeURIComponent(name);
    } catch {
      odd = true;
      break;
    }
    if (decoded === name) break;
    name = decoded;
    odd = true;
  }
  name = name.trim().replace(/^\+/, '').replace(/^(refs\/)?heads\//i, '').trim().replace(/\/+$/, '').toLowerCase();
  odd ||= name === '' || name === 'head' || name === '@' || name.includes('..') || name.includes('%') || /\s/.test(name);
  return { name, odd };
}
const STEER = 'Push the fix to its own branch (git push origin HEAD:refs/heads/<the fix branch>) and open a pull request instead; ' +
  'Escanor merges it only after its checks pass.';
export const protectedPush = (branch: string) =>
  `Escanor does not change ${branch} directly during an automatic fix: it is the main or a protected branch, so this was blocked and nothing changed. ${STEER}`;
export const MERGE_BLOCKED = 'Escanor merges a fix by itself only after its checks pass, so this merge was blocked during the automatic fix. ' +
  'Leave the pull request open instead.';
export const EVERY_BRANCH = `This pushes every branch, the main one too, so it was blocked during the automatic fix. ${STEER}`;
export const NO_BRANCH_NAMED = `This change names no branch, so it would land straight on the main branch. It was blocked during the automatic fix. ${STEER}`;
export const HTTP_BLOCKED = 'Escanor does not let an automatic fix change GitHub through direct API calls (curl, wget, a script), so this ' +
  `was blocked and nothing changed. ${STEER} Use git push and gh pr create for that.`;
export const UPDATE_BRANCH_BLOCKED = 'Updating a pull request\'s branch merges into its head branch, and Escanor could not see that the head is the ' +
  `fix branch, so it was blocked during the automatic fix. Merge the base into the fix branch and push that instead (gh pr update-branch escanor/<the fix branch> also works). ${STEER}`;
export const branchUnknown = (why: string) => `Escanor could not tell which branch this changes (${why}), so it was blocked during the automatic fix. ${STEER}`;
SEND_PACK.why = branchUnknown('git send-pack');

/** Why a write must not run because of the branch it lands on, or null. Only reached for a write to a picked repository. */
async function branchReason(b: BranchCheck, repos: string[], opts: WriteCheckOptions): Promise<string | null> {
  if (b.k === 'refuse') return b.why;
  const run = opts.run ?? agentRunner;
  const lookup = opts.defaultBranch ?? defaultBranchOf;
  const where = b.k === 'push' ? { cwd: b.ctx.cwd, remote: b.remote && !b.remote.includes('/') && !b.remote.includes(':') ? b.remote : 'origin', run: b.ctx.run }
    : { cwd: opts.cwd ?? null, remote: null, run };
  let dflt: string | null | undefined;
  const verdict = async (names: string[]): Promise<string | null> => {
    for (const raw of names) {
      const { name, odd } = normaliseBranch(raw);
      if (isProtectedBranch(name)) return protectedPush(name);
      if (odd) return branchUnknown(`"${raw}" is not a plain branch name`);
      if (name.startsWith(OURS)) continue; // the fix branches: never the default, no lookup
      if (dflt === undefined) dflt = await lookup(repos, where);
      if (dflt === null) return branchUnknown(`Escanor could not find the repository's default branch to make sure ${name} is not it`);
      if (name === dflt.toLowerCase()) return protectedPush(name);
    }
    return null;
  };
  if (b.k === 'names') return verdict(b.names);
  if (b.all) return EVERY_BRANCH;
  const ctx = b.ctx;
  let current: string | null | undefined;
  const checkedOut = async () => (current === undefined ? (current = await gitOut(ctx, ['symbolic-ref', '-q', '--short', 'HEAD'])) : current);
  const dests: string[] = [];
  let specs = b.refspecs;
  if (specs.length === 0 && b.remote && !b.remote.includes('/') && !b.remote.includes(':')) {
    // `remote.<name>.push` refspecs are what a push naming none sends
    const configured = (await gitOut(ctx, ['config', '--get-all', `remote.${b.remote}.push`]))?.split('\n').filter(Boolean) ?? [];
    specs = configured.map((text) => ({ text, quoted: false, dynamic: false, subs: [] }));
  }
  if (specs.length === 0) {
    const cur = await checkedOut();
    if (!cur) return branchUnknown('no branch is checked out');
    const mode = ((await gitOut(ctx, ['config', '--get', 'push.default'])) || 'simple').toLowerCase();
    if (mode === 'matching') return EVERY_BRANCH;
    if (mode === 'upstream' || mode === 'tracking') {
      const merge = await gitOut(ctx, ['config', '--get', `branch.${cur}.merge`]);
      if (merge) dests.push(stripHeads(merge));
    }
    dests.push(cur);
  }
  for (let i = 0; i < specs.length; i++) {
    const w = specs[i];
    if (w.dynamic) return branchUnknown('the branch is a value Escanor cannot see');
    if (w.text === 'tag') {
      i++; // `git push origin tag v1`
      continue;
    }
    const text = w.text.replace(/^\+/, '');
    const colon = text.indexOf(':');
    const src = colon >= 0 ? text.slice(0, colon) : text;
    let dst = colon >= 0 ? text.slice(colon + 1) || src : text;
    if (/^(refs\/)?tags\//.test(dst)) continue;
    if (dst === 'HEAD' || dst === '@') {
      const cur = await checkedOut();
      if (!cur) return branchUnknown('no branch is checked out');
      dst = cur;
    }
    if (dst.includes('*')) return EVERY_BRANCH;
    dests.push(dst);
  }
  return verdict(dests);
}

const DEFAULT_TTL_MS = 10 * 60_000;
const defaults = new Map<string, { at: number; value: string }>();

/**
 * The default branch of the repositories a write goes to (lower case), or null. Asked of the push target itself
 * (`git ls-remote --symref <remote> HEAD`, a remote name or URL), else of GitHub (`gh api repos/o/r`, every repository agreeing),
 * each with the short git timeout; the answer is kept ten minutes. The folder's own refs/remotes/<remote>/HEAD is only a second
 * signal: it can be set by hand (`git remote set-head`) or be stale, so when it disagrees with the answer, or nothing answers, the
 * result is null and a write to a branch other than escanor/* is refused (MAINWRITE2 N3, final review).
 */
export async function defaultBranchOf(repos: string[], where: { cwd: string | null; remote: string | null; run: Runner }): Promise<string | null> {
  const key = `${[...repos].sort().join(',')}|${where.cwd ?? ''}|${where.remote ?? ''}`;
  const remoteOk = Boolean(where.cwd && where.remote && /^[^\s-][^\s]*$/.test(where.remote));
  const ctx: GitCtx = { cwd: where.cwd, args: [], run: where.run };
  let value: string | null = null;
  const kept = defaults.get(key);
  if (kept && Date.now() - kept.at < DEFAULT_TTL_MS) value = kept.value;
  if (!value && remoteOk) {
    const out = await gitOut(ctx, ['ls-remote', '--symref', '--', where.remote!, 'HEAD']);
    const m = out ? /^ref: refs\/heads\/(\S+)\s+HEAD$/m.exec(out) : null;
    if (m) value = m[1].toLowerCase();
  }
  if (!value && repos.length) {
    const found = new Set<string>();
    for (const repo of repos) {
      if (!REPO_NAME.test(repo)) return null;
      const out = await where.run('gh', ['api', `repos/${repo}`, '--jq', '.default_branch'], where.cwd ?? '/');
      if (!out || !/^\S+$/.test(out.trim())) return null;
      found.add(out.trim().toLowerCase());
    }
    value = found.size === 1 ? [...found][0] : null;
  }
  if (!value) return null;
  if (defaults.size > 1000) defaults.clear();
  defaults.set(key, { at: kept?.value === value ? kept.at : Date.now(), value });
  // The folder's own idea of it, read every time: one that disagrees means someone or something moved it (or it is stale)
  if (remoteOk && /^[A-Za-z0-9._-]+$/.test(where.remote!)) {
    const head = await gitOut(ctx, ['symbolic-ref', '-q', '--short', `refs/remotes/${where.remote}/HEAD`]);
    if (head && head.toLowerCase() !== `${where.remote!.toLowerCase()}/${value}`) return null;
  }
  return value;
}

/** Why this command line must not run in a chat limited to `opts.allowed`, or null when it may (it writes only there, or writes nothing). */
export async function remoteWriteReason(command: string, opts: WriteCheckOptions): Promise<string | null> {
  // No look at the raw text first: `g''it p''ush` is git push to the shell. Reading the line is linear, so every one is read.
  // The text without quotes and backslashes, for the coarse look at what cannot be read.
  const bare = command.replace(/['"\\]/g, '');
  if (command.length > MAX_CHECKED_CHARS) return looksLikeWrite(bare) || /\bgh\b|\bgit\b|\$/.test(bare) ? cannotTell(opts.allowed, 'it is too long to check') : null;
  let parsed: Parsed;
  try {
    parsed = parse(command);
  } catch {
    return looksLikeWrite(bare) || /\bgh\s+(?:pr|api|repo|release)\b|\bgit\b[^\n]{0,80}\bpush\b/.test(bare) ? cannotTell(opts.allowed, 'Escanor could not read it') : null;
  }
  const c: Ctx = { opts, depth: 0, run: opts.run ?? agentRunner };
  // The folder each top-level command runs in: `cd <folder> &&` moves the ones after it.
  const cwds: Array<string | null> = [];
  let cwd: string | null = opts.cwd ?? null;
  for (const s of parsed.commands) {
    cwds.push(cwd);
    const { start } = unwrap(s.words);
    const p = programOf(s.words[start]);
    if (p === 'cd' || p === 'pushd') {
      const args = s.words.slice(start + 1).filter((w) => !(w.text.startsWith('-') && w.text.length > 1 && !w.quoted));
      cwd = args.length === 0 ? (opts.home ?? null) : args[0].text === '-' ? null : resolveDir(cwd, args[0], opts.home);
    } else if (p === 'popd') cwd = null;
  }
  const { found, hidden } = await findWrites(parsed, c, (k) => cwds[k], true);
  if (found.length === 0 && !hidden) return null;
  if (hidden || parsed.grouped) return notAlone(opts.allowed);
  // Only what Escanor can see runs before the last write, and nothing can skip a `cd` and still reach a write.
  const cmds = parsed.commands;
  const writeAt = new Set(found.map((f) => f.index));
  const last = Math.max(...writeAt);
  let sinceCd: boolean | null = null; // inside a `cd x && ... &&` run: every operator from it to the write must be && (or a pipe)
  for (let k = 0; k <= last; k++) {
    const s = cmds[k];
    if (s.next === '&' || s.prev === '&') return notAlone(opts.allowed);
    const { start } = unwrap(s.words);
    const p = programOf(s.words[start]);
    if (writeAt.has(k)) {
      if (s.prev === '|' || s.prev === '||' || sinceCd === false) return notAlone(opts.allowed);
      // Its output may go through readers (`git push 2>&1 | tail -5`); nothing else may follow in that pipe.
      for (let j = k; cmds[j]?.next === '|'; j++) {
        const reader = cmds[j + 1];
        if (!reader || !PIPE_READERS.has(programOf(reader.words[unwrap(reader.words).start])) || reader.words.some((w) => w.subs.length || w.text === '-i' || w.text.startsWith('--in-place'))) {
          return notAlone(opts.allowed);
        }
      }
    } else if (p === 'cd' || p === 'pushd') {
      if (s.next !== '&&' || !['', ';', '&&', '\n'].includes(s.prev)) return notAlone(opts.allowed);
      sinceCd = true;
      continue;
    } else if (!safeBefore(s, start, found.filter((f) => f.index > k))) {
      return notAlone(opts.allowed);
    }
    if (sinceCd !== null && k < last && s.next !== '&&' && s.next !== '|') sinceCd = false;
    if (s.words.some((w) => w.subs.length > 0 && !w.subs.every(safeSubstitution))) return notAlone(opts.allowed);
  }
  // Each write: the repositories it changes, all on the list.
  for (const f of found) {
    const repos: string[] = [];
    for (const t of f.write.targets) {
      const r = await reposOfTarget(t, opts);
      if ('why' in r) return cannotTell(opts.allowed, r.why);
      const off = r.repos.find((repo) => !opts.allowed.includes(repo));
      if (off) return offList(opts.allowed, off);
      repos.push(...r.repos);
    }
    // MAINWRITE: on a picked repository, never the main, a protected or its own default branch
    if (f.write.branch) {
      const why = await branchReason(f.write.branch, [...new Set(repos)], opts);
      if (why) return why;
    }
  }
  return null;
}

/** `$(cat <<'EOF' ... EOF)`: words handed to a command as they are (the usual way a PR body is written). */
function safeSubstitution(text: string): boolean {
  try {
    const p = parse(text);
    return p.commands.length === 1 && !p.grouped && p.commands[0].words.length === 1 && p.commands[0].words[0].text === 'cat' &&
      p.commands[0].heredocs.length === 1 && p.commands[0].heredocs[0].quoted && p.commands[0].redirects.length === 0;
  } catch {
    return false;
  }
}

/** A command that may run before a write in the same line: it cannot change where the write goes. */
function safeBefore(s: Simple, start: number, laterWrites: Found[]): boolean {
  const w = s.words;
  const p = programOf(w[start]);
  if (w[start]?.dynamic) return false;
  // Writing a file (`echo ... >> .git/config`) could change where the write goes.
  if (s.redirects.some((r) => r.dynamic || !/^(?:\d+|-|\/dev\/(?:null|stdout|stderr))$/.test(r.text))) return false;
  if (s.words.length === 0) return true;
  if (SAFE_PROGRAMS.has(p)) return true;
  if (p === 'git') {
    let i = start + 1;
    while (w[i] && w[i].text.startsWith('-')) i += w[i].text === '-C' || w[i].text === '-c' ? 2 : 1;
    const sub = w[i]?.text ?? '';
    if (w[i]?.dynamic) return false;
    if (SAFE_GIT.has(sub)) return true;
    if (sub === 'remote') return !w[i + 1] || ['-v', '--verbose', 'show', 'get-url'].includes(w[i + 1].text);
    if (BRANCH_GIT.has(sub)) return !laterWrites.some((f) => f.write.needsBranch);
    return false;
  }
  if (p === 'gh') {
    const group = w[start + 1]?.text ?? '';
    const verb = w[start + 2]?.text ?? '';
    if (['auth', 'config', 'alias', 'extension', 'ext'].includes(group)) return false;
    if (group === 'repo' && (verb === 'set-default' || verb === 'clone')) return false;
    if (group === 'pr' && verb === 'checkout') return !laterWrites.some((f) => f.write.needsBranch);
    return true; // its writes are checked as writes
  }
  return false;
}

/** The repositories-only check for any tool input that runs a command (Bash, Monitor, an MCP shell tool...), or null. */
export async function remoteWriteBlockReason(_toolName: string, input: unknown, opts: WriteCheckOptions): Promise<string | null> {
  const fields = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  for (const key of ['command', 'cmd', 'script']) {
    const value = fields[key];
    if (typeof value !== 'string') continue;
    const why = await remoteWriteReason(value, opts);
    if (why) return why;
  }
  return null;
}
