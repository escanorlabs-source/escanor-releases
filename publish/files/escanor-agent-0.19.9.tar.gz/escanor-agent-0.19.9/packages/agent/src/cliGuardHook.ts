// The Autonomous blocklist as a Codex PreToolUse / Gemini BeforeTool / Copilot PreToolUse hook (cliGuard.ts): reads the tool call
// on stdin, exits 0 to let it run, or 2 with the reason on stderr to refuse it. With --copilot it always exits 0 and refuses with
// a JSON answer on stdout instead (Copilot passes that reason on to the AI; an exit code 2 reaches it without the reason). Run by
// those tools, never by the agent itself.
import { readFileSync } from 'node:fs';
import { copilotHookOutput, hookVerdict } from './cliGuard.js';

let stdin = '';
try {
  stdin = readFileSync(0, 'utf8');
} catch {
  stdin = '';
}
const copilot = process.argv.includes('--copilot');
const v = await hookVerdict(stdin, process.env, { copilot });
if (copilot) {
  const out = copilotHookOutput(v);
  if (out) process.stdout.write(out);
  process.exit(0);
}
if (v.stderr) process.stderr.write(v.stderr);
process.exit(v.code);
