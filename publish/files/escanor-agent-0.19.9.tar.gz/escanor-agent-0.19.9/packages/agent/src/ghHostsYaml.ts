/**
 * A small, lossless reader/writer for the GitHub CLI's `hosts.yml` (nested `key: value` maps, 4-space indent, no lists).
 * Scalars are kept as the raw text they had (quotes included), so a file that is read and written back is unchanged except for what was
 * edited. Anything it does not understand (lists, block text, anchors) throws {@link UnsupportedYaml}: the caller then leaves the file alone.
 */
export type YNode = string | null | YMap;
export type YMap = Map<string, YNode>;

export class UnsupportedYaml extends Error {}

const unquote = (s: string): string => {
  const t = s.trim();
  if (t.length >= 2 && ((t.startsWith('"') && t.endsWith('"')) || (t.startsWith("'") && t.endsWith("'")))) return t.slice(1, -1);
  return t;
};

function splitKey(line: string): { key: string; rest: string } {
  const m = /^((?:"[^"]*"|'[^']*'|[^\s:#"'][^:#]*?)):(?:\s+(.*))?$/.exec(line);
  if (!m) throw new UnsupportedYaml(`line not understood: ${line.slice(0, 20)}`);
  return { key: unquote(m[1]!), rest: (m[2] ?? '').trim() };
}

export function parseYaml(text: string): YMap {
  const root: YMap = new Map();
  const stack: { indent: number; map: YMap }[] = [{ indent: -1, map: root }];
  let pending: { map: YMap; key: string; indent: number } | null = null; // `key:` with nothing after it: a nested map if the next line is deeper
  for (const raw of text.replace(/\r\n/g, '\n').split('\n')) {
    if (!raw.trim() || raw.trim().startsWith('#')) continue;
    if (raw.includes('\t')) throw new UnsupportedYaml('tab');
    const indent = raw.length - raw.trimStart().length;
    const line = raw.trim();
    if (line.startsWith('- ') || line === '-') throw new UnsupportedYaml('list');
    if (pending && indent > pending.indent) {
      const child: YMap = new Map();
      pending.map.set(pending.key, child);
      stack.push({ indent, map: child });
    }
    pending = null;
    while (stack.length > 1 && indent < stack[stack.length - 1]!.indent) stack.pop();
    const top = stack[stack.length - 1]!;
    if (indent !== top.indent && stack.length > 1) throw new UnsupportedYaml('indent');
    if (stack.length === 1 && indent !== 0) throw new UnsupportedYaml('indent');
    const { key, rest } = splitKey(line);
    if (/^[|>&*!{[]/.test(rest) && rest !== '{}') throw new UnsupportedYaml('value kind');
    if (rest === '') {
      top.map.set(key, null);
      pending = { map: top.map, key, indent };
    } else if (rest === '{}') {
      top.map.set(key, new Map());
    } else {
      top.map.set(key, rest);
    }
  }
  return root;
}

/** A value to write: quoted only when plain text would be read differently. */
export function scalar(value: string): string {
  return value === '' || /^[\s>|&*!%@`'"#[\]{},-]|: | #|\s$/.test(value) ? JSON.stringify(value) : value;
}

export function readScalar(node: YNode | undefined): string | null {
  return typeof node === 'string' ? unquote(node) : null;
}

export function stringifyYaml(map: YMap, depth = 0): string {
  const pad = '    '.repeat(depth);
  let out = '';
  for (const [k, v] of map) {
    const key = /^[A-Za-z0-9_.@-]+$/.test(k) ? k : JSON.stringify(k);
    if (v instanceof Map) out += v.size === 0 ? `${pad}${key}: {}\n` : `${pad}${key}:\n${stringifyYaml(v, depth + 1)}`;
    else if (v === null) out += `${pad}${key}:\n`;
    else out += `${pad}${key}: ${v}\n`;
  }
  return out;
}
