import { isValidMcpServerName, type ManagedMcpServer } from '@remote-harness/shared';
import { switchOn } from './switches.js';

/**
 * This machine's own Escanor MCP key (Escanor 17e). On every hub connect, and every half hour, the agent asks Escanor's API for
 * a key made for this machine alone, signing in with the hub agent token it already has (POST /agent/device/mcp). The key
 * replaces the hub's workspace-wide Escanor entry on this machine only, so nobody copies a key anywhere, each machine's key
 * shows on the keys page as "device: <name>", and revoking one cuts that machine off.
 *
 * Only for Escanor's hosted hub (or an API named explicitly with ESCANOR_API_URL): a self-hosted hub's token is never sent to
 * Escanor. Never in a managed worker (the assistant's and company machines: they have their own key and builder chats there
 * must get none) or a machine started with an incident's ESCANOR_MCP_OVERRIDE. The key is held in memory only and never logged.
 */

export type DeviceEntry = Omit<ManagedMcpServer, 'updatedAt'>;

export type DeviceMcpResult =
  | { kind: 'ok'; server: DeviceEntry; refreshMs: number; expiresAtMs?: number }
  /** Stop using a key: `revoked` also drops the hub's entry of that name (blocked until re-paired); `disconnected` does not. */
  | { kind: 'drop'; reason: 'revoked' | 'disconnected' }
  /** The workspace is at its limit of device keys: told plainly, retried slowly (never as if it were a network blip). */
  | { kind: 'limit'; message: string }
  /** Anything else (offline, the hub or API busy, not a hosted-hub machine): keep what there is and ask again later. */
  | { kind: 'retry'; reason: string };

/**
 * Said plainly, in the machine's status and in its chats, when this machine's key was revoked: the Escanor tools are gone from its
 * chats and nothing else tells the person why. Re-pairing is what brings them back (the next key request sees the new pairing).
 */
export const REVOKED_STATUS = 'Escanor tools are off on this computer: its Escanor key was revoked. Pair this computer again to turn them back on (Escanor app, Machines, this computer, then pair it again).';
export const REVOKED_NOTICE = `${REVOKED_STATUS} Chats here cannot use Escanor's own tools until then; nothing else is affected.`;
/** Added to a chat's instructions while the key is revoked, so it tells the person instead of looking for tools that are not there. */
export const REVOKED_GUIDE = 'Escanor\'s own tools (the "escanor" MCP server) are switched off on this computer because its Escanor key was revoked. If the person wants something that needs them, tell them plainly that it is off here and that they bring it back by pairing this computer again (Escanor app, Machines, this computer, pair it again). Do not try to work around it.';

const HOSTED_HUB_HOSTS = new Set(['hub.escanor.in']);
const DEFAULT_API = 'https://api.escanor.in/api/v1';
export const MIN_REFRESH_MS = 5 * 60_000;
export const MAX_REFRESH_MS = 24 * 60 * 60_000;
export const RETRY_BASE_MS = 60_000;
export const RETRY_MAX_MS = 30 * 60_000;
const TIMEOUT_MS = 15_000;

/** Where to ask, or null when this machine must not ask at all. */
export function deviceMcpApiUrl(env: NodeJS.ProcessEnv, hubUrl: string, opts: { managed: boolean; override: boolean }): string | null {
  if (!switchOn(env.ESCANOR_DEVICE_MCP, true) || opts.managed || opts.override) return null;
  return escanorApiUrl(env, hubUrl);
}

/** Escanor's API for a machine on Escanor's hosted hub (or one named with ESCANOR_API_URL); null for a self-hosted hub. */
export function escanorApiUrl(env: NodeJS.ProcessEnv, hubUrl: string): string | null {
  const explicit = env.ESCANOR_API_URL?.trim();
  if (explicit) {
    try {
      const u = new URL(explicit);
      const local = u.hostname === 'localhost' || u.hostname === '127.0.0.1';
      if (u.protocol === 'https:' || (u.protocol === 'http:' && local)) return explicit.replace(/\/+$/, '');
    } catch {
      // fall through: an unreadable value is ignored
    }
    console.warn('ESCANOR_API_URL must be an https:// address; not asking Escanor for this machine\'s key.');
    return null;
  }
  try {
    return HOSTED_HUB_HOSTS.has(new URL(hubUrl).hostname) ? DEFAULT_API : null;
  } catch {
    return null;
  }
}

function entryFrom(body: unknown): { server: DeviceEntry; refreshMs: number; expiresAtMs?: number } | null {
  if (!body || typeof body !== 'object') return null;
  const b = body as Record<string, unknown>;
  const s = b.server as Record<string, unknown> | null | undefined;
  if (!s || typeof s !== 'object') return null;
  const name = typeof s.name === 'string' ? s.name : '';
  const url = typeof s.url === 'string' ? s.url : '';
  const token = typeof s.token === 'string' ? s.token : '';
  if (!isValidMcpServerName(name) || !/^https?:\/\//.test(url) || !token || /\s/.test(token)) return null;
  const seconds = typeof b.refresh_seconds === 'number' && Number.isFinite(b.refresh_seconds) ? b.refresh_seconds : 1800;
  const ends = typeof b.expires_at === 'string' ? Date.parse(b.expires_at) : NaN;
  return {
    ...(Number.isFinite(ends) ? { expiresAtMs: ends } : {}),
    server: {
      name,
      url,
      headers: { Authorization: `Bearer ${token}` },
      autoAllow: s.autoAllow === true,
      autoAllowReads: s.autoAllowReads !== false,
      alwaysLoad: true,
      managedBy: 'device',
    },
    refreshMs: Math.min(MAX_REFRESH_MS, Math.max(MIN_REFRESH_MS, seconds * 1000)),
  };
}

/** One request for this machine's key. Never throws. */
export async function fetchDeviceMcp(opts: {
  apiUrl: string;
  hubToken: string;
  vmName: string;
  agentVersion: string;
  fetchImpl?: typeof fetch;
}): Promise<DeviceMcpResult> {
  const doFetch = opts.fetchImpl ?? fetch;
  let res: Response;
  try {
    res = await doFetch(`${opts.apiUrl}/agent/device/mcp`, {
      method: 'POST',
      // Named, so an edge filter that turns away anonymous scripts never mistakes the agent for one.
      headers: { Authorization: `Bearer ${opts.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${opts.agentVersion}` },
      body: JSON.stringify({ vm_name: opts.vmName, agent_version: opts.agentVersion }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (err) {
    return { kind: 'retry', reason: err instanceof Error ? err.name : 'network' };
  }
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    body = null;
  }
  if (res.ok) {
    const parsed = entryFrom(body);
    return parsed ? { kind: 'ok', ...parsed } : { kind: 'retry', reason: 'malformed answer' };
  }
  const reason = body && typeof body === 'object' && typeof (body as { reason?: unknown }).reason === 'string' ? (body as { reason: string }).reason : '';
  if (res.status === 403 && reason === 'revoked') return { kind: 'drop', reason: 'revoked' };
  if (res.status === 409 && reason === 'disconnected') return { kind: 'drop', reason: 'disconnected' };
  if (res.status === 429 && reason === 'too_many') {
    const say = body && typeof (body as { message?: unknown }).message === 'string' ? (body as { message: string }).message : 'This workspace already has the most devices with Escanor keys.';
    return { kind: 'limit', message: say };
  }
  return { kind: 'retry', reason: `HTTP ${res.status}${reason ? ` ${reason}` : ''}` };
}

type Timer = ReturnType<typeof setTimeout>;

/** Asks on every hub connect (refreshNow) and again when the key says to, with backoff while Escanor cannot be reached. */
export class DeviceMcpClient {
  private timer: Timer | null = null;
  private inFlight = false;
  private failures = 0;
  private stopped = false;
  private lastState = '';
  /** When the key this machine is using ends (ms), if the API said. A key past that is never kept. */
  private expiresAtMs: number | null = null;
  private haveKey = false;

  constructor(
    private readonly opts: {
      apiUrl: string;
      hubToken: string;
      vmName: string;
      agentVersion: string;
      apply: (entry: DeviceEntry | null, block?: string) => Promise<void> | void;
      fetchImpl?: typeof fetch;
      setTimer?: (fn: () => void, ms: number) => Timer;
      clearTimer?: (t: Timer) => void;
      log?: (line: string) => void;
      now?: () => number;
    },
  ) {}

  /** Ask now (the hub just (re)connected). A request already running is not doubled. */
  refreshNow(): Promise<void> {
    if (this.stopped || this.inFlight) return Promise.resolve();
    return this.run();
  }

  stop(): void {
    this.stopped = true;
    if (this.timer) (this.opts.clearTimer ?? clearTimeout)(this.timer);
    this.timer = null;
  }

  private schedule(ms: number): void {
    if (this.stopped) return;
    if (this.timer) (this.opts.clearTimer ?? clearTimeout)(this.timer);
    const t = (this.opts.setTimer ?? setTimeout)(() => void this.run(), ms);
    (t as { unref?: () => void }).unref?.();
    this.timer = t;
  }

  private say(state: string, line: string): void {
    if (state === this.lastState) return;
    this.lastState = state;
    (this.opts.log ?? console.log)(line);
  }

  private async run(): Promise<void> {
    if (this.stopped || this.inFlight) return;
    this.inFlight = true;
    try {
      const r = await fetchDeviceMcp(this.opts);
      const now = (this.opts.now ?? Date.now)();
      if (r.kind === 'ok') {
        this.failures = 0;
        this.expiresAtMs = r.expiresAtMs ?? null;
        this.haveKey = true;
        await this.opts.apply(r.server);
        this.say('ok', 'Escanor MCP: this machine has its own key.');
        // Ask again before the key ends, whatever the usual rhythm.
        this.schedule(r.expiresAtMs ? Math.max(MIN_REFRESH_MS / 5, Math.min(r.refreshMs, r.expiresAtMs - now - 60_000)) : r.refreshMs);
      } else if (r.kind === 'drop') {
        this.failures = 0;
        await this.opts.apply(null, r.reason === 'revoked' ? 'escanor' : undefined);
        this.expiresAtMs = null;
        this.haveKey = false;
        this.say(r.reason, r.reason === 'revoked'
          ? 'Escanor MCP: this machine\'s key was revoked; Escanor is off here until the machine is paired again.'
          : 'Escanor MCP: Escanor is disconnected from this workspace\'s machines.');
        this.schedule(RETRY_MAX_MS);
      } else {
        this.failures++;
        // Trouble reaching Escanor (a busy server, a full limit, no network): the old key is kept only while it has not expired.
        if (this.haveKey && this.expiresAtMs !== null && this.expiresAtMs <= now) {
          this.haveKey = false;
          this.expiresAtMs = null;
          await this.opts.apply(null);
          this.say('expired', 'Escanor MCP: this machine\'s key has expired and a new one could not be fetched yet; Escanor is off here until it can.');
        }
        if (r.kind === 'limit') {
          this.say('limit', `Escanor MCP: ${r.message}`);
          this.schedule(RETRY_MAX_MS);
          return;
        }
        this.say(`retry:${r.reason}`, `Escanor MCP: could not get this machine's key (${r.reason}); keeping what it has and trying again.`);
        this.schedule(Math.min(RETRY_MAX_MS, RETRY_BASE_MS * 2 ** Math.min(this.failures - 1, 10)));
      }
    } finally {
      this.inFlight = false;
    }
  }
}
