/**
 * AGRESUME (FLOW4 minor 3): before this agent picks up, after a restart, a fix or a kept run the backend gave this computer, it asks
 * Escanor whether that work is still wanted (POST /agent/device/resume, signed in with the hub agent token it already has, like
 * deviceMcp.ts). The backend answers for each chat from the run itself: "continue" only while the run is still active on this
 * computer's chat and its task was not stopped. That closes the race a fixed wait could not: a stop the hub took into a dead
 * socket, a stop still on its way, a stop given up after 7 days, or a run ended without any stop.
 *
 * No answer (Escanor unreachable, a timeout, a self-hosted hub with no Escanor API, a refusal) is never "continue": the agent does
 * not resume, and says in the chat that it is waiting (WAIT_NOTICE), so the run's supervisor sends "carry on" itself.
 */

export type ResumeAsk = {
  sessionId: string;
  /** The first 8 characters of the backend conversation's id, from the "/new Escanor automation <id8>." its first message began with. */
  conv?: string;
};
export type ResumeVerdict = 'continue' | 'stop';
export type ResumeAnswers = Record<string, ResumeVerdict>;
export type AskResume = (asks: ResumeAsk[]) => Promise<ResumeAnswers | null>;

export const RESUME_CHECK_TIMEOUT_MS = 10_000;
/** The backend refuses more in one question (mongo-backend main.DeviceResumeRequest). */
const MAX_ASKS = 20;

/** One question for every chat in `asks`. Null when there is no answer to go by. Never throws. */
export async function askResume(opts: {
  apiUrl: string;
  hubToken: string;
  vmName: string;
  agentVersion: string;
  asks: ResumeAsk[];
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}): Promise<ResumeAnswers | null> {
  const asks = opts.asks.slice(0, MAX_ASKS);
  if (asks.length === 0) return {};
  let res: Response;
  try {
    res = await (opts.fetchImpl ?? fetch)(`${opts.apiUrl}/agent/device/resume`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${opts.hubToken}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${opts.agentVersion}` },
      body: JSON.stringify({ vm_name: opts.vmName, sessions: asks.map((a) => ({ id: a.sessionId, ...(a.conv ? { conv: a.conv } : {}) })) }),
      signal: AbortSignal.timeout(opts.timeoutMs ?? RESUME_CHECK_TIMEOUT_MS),
    });
  } catch {
    return null;
  }
  if (!res.ok) return null;
  let body: unknown;
  try {
    body = await res.json();
  } catch {
    return null;
  }
  const given = body && typeof body === 'object' ? (body as { sessions?: unknown }).sessions : undefined;
  if (!given || typeof given !== 'object' || Array.isArray(given)) return null;
  const out: ResumeAnswers = {};
  // Only an explicit "continue" goes on: a chat the answer leaves out, or says anything else about, is not picked up.
  for (const a of asks) out[a.sessionId] = (given as Record<string, unknown>)[a.sessionId] === 'continue' ? 'continue' : 'stop';
  return out;
}
