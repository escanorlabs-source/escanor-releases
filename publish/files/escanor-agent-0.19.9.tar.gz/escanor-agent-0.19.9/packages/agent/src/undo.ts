import { execFileSync } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import {
  copyFileSync, existsSync, linkSync, lstatSync, mkdirSync, readdirSync, readFileSync, readlinkSync, renameSync, rmSync, statfsSync, statSync,
  symlinkSync, writeFileSync,
} from 'node:fs';
import { homedir, platform as osPlatform } from 'node:os';
import { dirname, join } from 'node:path';
import { BUILD_DIRS } from '../../shared/src/risk.ts';
import type { BackupDelete, BackupGit, BackupPlan } from '../../shared/src/safety.ts';

/**
 * Escanor's undo copies (shared/safety.ts "backup"): before an AI deletes files or throws git work away, a copy is kept here, so it
 * can run without anyone approving it and still be put back from the phone, the desktop app or the website.
 *
 * Files are kept as hard links where they can be (instant, and no extra disk space until the original is deleted), copied where
 * they cannot (another drive, a file owned by someone else) up to a size limit. Git work is kept as refs under refs/escanor/undo/
 * in the repository itself (a stash commit, a branch's commit, a deleted remote branch's commit). Copies are kept for a week.
 *
 * The store sits outside the home folder where it can (/var/tmp/escanor-safety-<uid> on the home's own drive), so even a delete of
 * the whole home folder does not take the copies with it; and no AI may delete it (safety.ts protect).
 */

export type UndoItem = {
  /** Where it was. */
  path: string;
  kind: 'tree' | 'file' | 'link';
  /** Where the copy is (inside the entry's folder). */
  stored: string;
  files: number;
  bytes: number;
  /** Rebuildable folders (node_modules, dist...) inside it that were not kept. */
  skipped?: number;
};
export type UndoGitRef = { ref: string; sha: string; what: 'work' | 'head' | 'stash' | 'branch' | 'remote-branch'; name?: string };
export type UndoGit = { op: BackupGit['op']; repo: string; refs: UndoGitRef[]; remote?: string };
export type UndoEntry = {
  id: string;
  at: number;
  /** agent: a chat run by Escanor; machine: any other Claude on this computer; snapshot: the daily copy of your own folders. */
  source: 'agent' | 'machine' | 'snapshot';
  command: string;
  cwd: string;
  session?: string;
  items: UndoItem[];
  git: UndoGit[];
  /** It is incomplete (too many files): what is here is real, the rest was not kept. */
  partial?: boolean;
  restoredAt?: number;
};
/** What the apps list (no store paths). */
export type UndoSummary = { id: string; at: number; source: UndoEntry['source']; command: string; cwd: string; paths: string[]; files: number; bytes: number; git: string[]; partial?: boolean; restoredAt?: number };

export type UndoOptions = {
  /** Where copies go (tests); else chosen as described above. */
  root?: string;
  home?: string;
  retentionDays?: number;
  /** More files than this in one call: no copy is made (the call is then treated as the risk it is). */
  maxFiles?: number;
  /** Bytes that may be copied (not linked) for one call. */
  maxCopyBytes?: number;
  /** Time a copy may take (ms). */
  budgetMs?: number;
  now?: () => number;
  git?: (args: string[], cwd: string) => string;
};

const DAY = 86_400_000;
/** Folder names inside a kept tree that are caches: not worth a copy (they come back by themselves). */
const CACHE_NAME = /^(?:cache|caches|code cache|gpucache|shadercache|grshadercache|dawncache|cachestorage|service worker|crashpad|\.cache)$/i;

class TooBig extends Error {}
type Budget = { files: number; copied: number; until: number; maxFiles: number; partial: boolean; linkOnly?: boolean; copyOnly?: boolean; copyBelow?: number };

export function defaultUndoRoot(home = homedir(), plat = osPlatform()): string {
  const uid = typeof process.getuid === 'function' ? process.getuid() : 0;
  const candidates =
    plat === 'win32'
      ? [join(process.env.ProgramData || 'C:\\ProgramData', 'Escanor', `undo-${(process.env.USERNAME || 'user').replace(/[^\w.-]/g, '_')}`)]
      : [plat === 'darwin' ? `/private/var/tmp/escanor-safety-${uid}` : `/var/tmp/escanor-safety-${uid}`];
  let homeDev: number | null = null;
  try {
    homeDev = statSync(home).dev;
  } catch {
    /* no home */
  }
  for (const c of candidates) {
    try {
      mkdirSync(c, { recursive: true, mode: 0o700 });
      const st = statSync(c);
      if (plat !== 'win32' && (st.uid !== uid || (st.mode & 0o077) !== 0)) continue; // someone else's, or open to others
      if (homeDev !== null && st.dev !== homeDev) continue; // another drive: links would not work
      return c;
    } catch {
      /* not writable here */
    }
  }
  return join(home, '.escanor', 'undo');
}

const newId = (now: number) => `${now.toString(36)}-${randomBytes(3).toString('hex')}`;

/** A pattern's matches on disk (`*`, `?`, `[...]` in any part; dot files only when the part starts with a dot). */
export function expandGlob(pattern: string): string[] {
  const abs = pattern.replace(/\\/g, '/');
  const drive = /^[A-Za-z]:/.exec(abs)?.[0] ?? '';
  const parts = abs.slice(drive.length).split('/').filter(Boolean);
  let found = [drive ? `${drive}/` : '/'];
  for (const part of parts) {
    const next: string[] = [];
    if (!/[*?[]/.test(part)) {
      for (const f of found) next.push(join(f, part));
    } else {
      const re = new RegExp(
        `^${part.replace(/[.+^${}()|\\]/g, '\\$&').replace(/\*/g, '[^/]*').replace(/\?/g, '[^/]').replace(/\[!/g, '[^')}$`,
      );
      for (const f of found) {
        let names: string[] = [];
        try {
          names = readdirSync(f);
        } catch {
          continue;
        }
        for (const n of names) if (re.test(n) && (part.startsWith('.') || !n.startsWith('.'))) next.push(join(f, n));
      }
    }
    found = next;
    if (found.length > 100_000) break;
  }
  return found.filter((f) => {
    try {
      lstatSync(f);
      return true;
    } catch {
      return false;
    }
  });
}

export class UndoStore {
  readonly root: string;
  readonly home: string;
  private readonly retentionMs: number;
  private readonly maxFiles: number;
  private readonly maxCopyBytes: number;
  private readonly budgetMs: number;
  private readonly now: () => number;
  private readonly git: (args: string[], cwd: string) => string;

  constructor(o: UndoOptions = {}) {
    this.home = o.home ?? homedir();
    this.root = o.root ?? defaultUndoRoot(this.home);
    this.retentionMs = (o.retentionDays ?? 7) * DAY;
    this.maxFiles = o.maxFiles ?? 300_000;
    this.maxCopyBytes = o.maxCopyBytes ?? 2 * 1024 ** 3;
    this.budgetMs = o.budgetMs ?? 60_000;
    this.now = o.now ?? Date.now;
    this.git = o.git ?? ((args, cwd) => execFileSync('git', args, { cwd, encoding: 'utf8', timeout: 30_000, stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true }));
  }

  /**
   * Keeps a copy of what a call is about to delete or discard. ok:false when it could not (too big, another drive past the copy
   * limit, a git command failed): the caller then treats the call as the risk it would otherwise be.
   */
  backup(plan: BackupPlan, meta: { command: string; cwd: string; source: UndoEntry['source']; session?: string; maxFiles?: number }): { ok: true; entry: UndoEntry | null } | { ok: false; why: string } {
    const at = this.now();
    const id = newId(at);
    const dir = join(this.root, id);
    const entry: UndoEntry = { id, at, source: meta.source, command: meta.command.slice(0, 2000), cwd: meta.cwd, ...(meta.session ? { session: meta.session } : {}), items: [], git: [] };
    const budget: Budget = { files: 0, copied: 0, until: Date.now() + this.budgetMs, maxFiles: meta.maxFiles ?? this.maxFiles, partial: false };
    try {
      mkdirSync(join(dir, 'files'), { recursive: true, mode: 0o700 });
      const targets: BackupDelete[] = [];
      for (const d of plan.deletes) {
        if (d.glob) for (const p of expandGlob(d.path)) targets.push({ ...d, path: p, glob: false });
        else targets.push(d);
      }
      for (const g of plan.git) {
        const r = this.backupGit(g, id);
        if (r.git) entry.git.push(r.git);
        targets.push(...r.deletes);
      }
      for (const t of targets) {
        // A file about to be written over in place keeps a real copy (a link would change with it).
        budget.copyOnly = t.overwrite === true;
        const item = this.keep(t.path, join(dir, 'files', String(entry.items.length)), budget);
        if (item) entry.items.push(item);
      }
    } catch (err) {
      this.dropDir(dir);
      for (const g of entry.git) for (const r of g.refs) this.tryGit(['update-ref', '-d', r.ref], g.repo);
      if (err instanceof TooBig) return { ok: false, why: err.message };
      return { ok: false, why: `Escanor could not keep a copy first (${err instanceof Error ? err.message : String(err)}).` };
    }
    if (budget.partial) entry.partial = true;
    if (!entry.items.length && !entry.git.length) {
      this.dropDir(dir);
      return { ok: true, entry: null }; // nothing there to lose
    }
    writeFileSync(join(dir, 'entry.json'), JSON.stringify(entry), { mode: 0o600 });
    return { ok: true, entry };
  }

  /** A path kept under `to`: links where possible, copies otherwise. null when there is nothing at that path. */
  private keep(path: string, to: string, budget: Budget, partialOk = false): UndoItem | null {
    let st;
    try {
      st = lstatSync(path);
    } catch {
      return null;
    }
    const item: UndoItem = { path, kind: st.isSymbolicLink() ? 'link' : st.isDirectory() ? 'tree' : 'file', stored: to, files: 0, bytes: 0 };
    const one = (src: string, dst: string, size: number) => {
      if (++budget.files > budget.maxFiles) {
        if (partialOk) {
          budget.partial = true;
          return false;
        }
        throw new TooBig(`It deletes more than ${budget.maxFiles.toLocaleString('en')} files, too many for Escanor to keep a copy of first.`);
      }
      if (Date.now() > budget.until) {
        if (partialOk) {
          budget.partial = true;
          return false;
        }
        throw new TooBig('Keeping a copy of what it deletes took too long.');
      }
      try {
        if (budget.copyOnly || (budget.copyBelow !== undefined && size < budget.copyBelow)) throw new Error('copy');
        linkSync(src, dst);
      } catch {
        if (budget.linkOnly) return true; // the daily snapshot only links: a file it cannot link is left out
        // Another drive, or a file this user may not link (owned by someone else): a real copy, within the limit.
        if (budget.copied + size > this.maxCopyBytes) {
          if (partialOk) {
            budget.partial = true;
            return false;
          }
          throw new TooBig('What it deletes is on another drive and too big to copy first.');
        }
        copyFileSync(src, dst);
        budget.copied += size;
      }
      item.files++;
      item.bytes += size;
      return true;
    };
    if (item.kind === 'link') {
      symlinkSync(readlinkSync(path), to);
      item.files = 1;
      return item;
    }
    if (item.kind === 'file') {
      one(path, to, st.size);
      return item;
    }
    const walk = (src: string, dst: string): boolean => {
      mkdirSync(dst, { recursive: true });
      let names: string[];
      try {
        names = readdirSync(src);
      } catch {
        // A folder this user cannot read cannot be kept: the delete waits for a person instead (a snapshot just skips it).
        if (partialOk) return true;
        throw new TooBig(`Escanor cannot read ${src}, so it cannot keep a copy of it first.`);
      }
      for (const n of names) {
        const s = join(src, n);
        const d = join(dst, n);
        let e;
        try {
          e = lstatSync(s);
        } catch {
          continue;
        }
        if (!e.isSymbolicLink() && !e.isDirectory() && !e.isFile()) continue;
        if (e.isSymbolicLink()) {
          try {
            symlinkSync(readlinkSync(s), d);
          } catch {
            /* a link that cannot be made here */
          }
        } else if (e.isDirectory()) {
          if (BUILD_DIRS.has(n) || CACHE_NAME.test(n)) {
            item.skipped = (item.skipped ?? 0) + 1;
            continue;
          }
          if (!walk(s, d)) return false;
        } else if (e.isFile()) {
          if (!one(s, d, e.size)) return false;
        }
      }
      return true;
    };
    walk(path, to);
    return item;
  }

  private tryGit(args: string[], cwd: string): string | null {
    try {
      return this.git(args, cwd).trim();
    } catch {
      return null;
    }
  }

  /** Git work kept as refs, plus the files `git clean` would remove (kept like any delete). */
  private backupGit(g: BackupGit, id: string): { git: UndoGit | null; deletes: BackupDelete[] } {
    const repo = this.tryGit(['rev-parse', '--show-toplevel'], g.cwd);
    if (!repo) return { git: null, deletes: [] }; // not a repository: the command will fail by itself
    const refs: UndoGitRef[] = [];
    const save = (name: string, sha: string, what: UndoGitRef['what'], label?: string) => {
      const ref = `refs/escanor/undo/${id}/${name}`;
      this.git(['update-ref', ref, sha], repo);
      refs.push({ ref, sha, what, ...(label ? { name: label } : {}) });
    };
    const args = g.args.slice(1);
    if (g.op === 'discard') {
      const work = this.tryGit(['stash', 'create', 'Escanor undo'], g.cwd);
      if (work) save('work', work, 'work');
      const head = this.tryGit(['rev-parse', '--verify', 'HEAD'], g.cwd);
      if (head) save('head', head, 'head');
      return { git: refs.length ? { op: g.op, repo, refs } : null, deletes: [] };
    }
    if (g.op === 'clean') {
      const flags = args.filter((a) => /^-/.test(a) && !/^--?(?:f|force|i|interactive)$/.test(a)).map((a) => (/^-[A-Za-z]+$/.test(a) ? a.replace(/[fi]/g, '') : a)).filter((a) => a !== '-');
      const paths = args.filter((a) => !a.startsWith('-'));
      const out = this.git(['clean', '-n', ...flags, ...(paths.length ? ['--', ...paths] : [])], g.cwd);
      const deletes: BackupDelete[] = [];
      for (const line of out.split('\n')) {
        const m = /^Would remove (.+?)\/?$/.exec(line.trim());
        // Rebuildable folders it lists (node_modules/, .venv/, target/) come back by themselves: not kept.
        if (m && !m[1].split('/').some((seg) => BUILD_DIRS.has(seg) || CACHE_NAME.test(seg))) deletes.push({ path: join(g.cwd, m[1]), glob: false, recursive: true, via: 'git clean' });
      }
      return { git: null, deletes };
    }
    if (g.op === 'stash') {
      const list = (this.tryGit(['stash', 'list', '--format=%H'], g.cwd) ?? '').split('\n').filter(Boolean);
      const which = args[0] === 'clear' ? list.map((_, k) => k) : [Number(/stash@\{(\d+)\}/.exec(args[1] ?? '')?.[1] ?? /^\d+$/.exec(args[1] ?? '')?.[0] ?? 0)];
      for (const k of which) if (list[k]) save(`stash-${k}`, list[k], 'stash');
      return { git: refs.length ? { op: g.op, repo, refs } : null, deletes: [] };
    }
    if (g.op === 'branch-delete') {
      for (const name of args.filter((a) => !a.startsWith('-'))) {
        const sha = this.tryGit(['rev-parse', '--verify', `refs/heads/${name}`], g.cwd);
        if (sha) save(`branch-${name.replace(/[^\w.-]/g, '_')}`, sha, 'branch', name);
      }
      return { git: refs.length ? { op: g.op, repo, refs } : null, deletes: [] };
    }
    // push-delete: `git push <remote> --delete a b` / `git push <remote> :a`
    const pos: string[] = [];
    for (let k = 0; k < args.length; k++) {
      if (['-o', '--push-option', '--repo', '--receive-pack', '--exec'].includes(args[k])) k++;
      else if (!args[k].startsWith('-')) pos.push(args[k]);
    }
    const remote = pos[0] ?? 'origin';
    const names = pos.slice(1).map((r) => r.replace(/^:/, '').replace(/^refs\/heads\//, '')).filter(Boolean);
    for (const name of names) {
      let sha = this.tryGit(['rev-parse', '--verify', `refs/remotes/${remote}/${name}`], g.cwd);
      const ref = `refs/escanor/undo/${id}/remote-${name.replace(/[^\w.-]/g, '_')}`;
      if (!sha) {
        // Not fetched here yet: fetch it into the undo ref itself (its commits then stay in this repository).
        if (this.tryGit(['fetch', '--no-tags', remote, `+refs/heads/${name}:${ref}`], g.cwd) === null) throw new Error(`could not fetch ${remote}/${name}`);
        sha = this.tryGit(['rev-parse', '--verify', ref], g.cwd);
        if (sha) {
          refs.push({ ref, sha, what: 'remote-branch', name });
          continue;
        }
      }
      if (sha) save(`remote-${name.replace(/[^\w.-]/g, '_')}`, sha, 'remote-branch', name);
    }
    return { git: refs.length ? { op: g.op, repo, refs, remote } : null, deletes: [] };
  }

  private entryDirs(): string[] {
    try {
      return readdirSync(this.root).filter((n) => /^[a-z0-9]+-[0-9a-f]{6}$/.test(n));
    } catch {
      return [];
    }
  }

  get(id: string): UndoEntry | null {
    if (!/^[a-z0-9]+-[0-9a-f]{6}$/.test(id)) return null;
    try {
      return JSON.parse(readFileSync(join(this.root, id, 'entry.json'), 'utf8')) as UndoEntry;
    } catch {
      return null;
    }
  }

  /** Newest first. */
  list(limit = 200): UndoSummary[] {
    const out: UndoSummary[] = [];
    for (const id of this.entryDirs()) {
      const e = this.get(id);
      if (!e) continue;
      out.push({
        id: e.id, at: e.at, source: e.source, command: e.command, cwd: e.cwd,
        paths: e.items.map((i) => i.path).slice(0, 20),
        files: e.items.reduce((n, i) => n + i.files, 0),
        bytes: e.items.reduce((n, i) => n + i.bytes, 0),
        git: e.git.flatMap((g) => g.refs.map((r) => `${r.what}${r.name ? ` ${r.name}` : ''} (${g.repo})`)),
        ...(e.partial ? { partial: true } : {}),
        ...(e.restoredAt ? { restoredAt: e.restoredAt } : {}),
      });
    }
    return out.sort((a, b) => b.at - a.at).slice(0, limit);
  }

  /**
   * Puts a copy back. Nothing that is there now is overwritten: a missing file comes back, a file that exists again stays as it is
   * (counted in `kept`). Git work comes back as a stash entry / branch, never by resetting anything.
   */
  restore(id: string): { ok: boolean; restored: number; kept: number; notes: string[] } {
    const e = this.get(id);
    if (!e) return { ok: false, restored: 0, kept: 0, notes: ['That copy is not here any more (copies are kept for a week).'] };
    let restored = 0;
    let kept = 0;
    const notes: string[] = [];
    const put = (src: string, dst: string) => {
      let s;
      try {
        s = lstatSync(src);
      } catch {
        return;
      }
      if (s.isDirectory()) {
        mkdirSync(dst, { recursive: true });
        for (const n of readdirSync(src)) put(join(src, n), join(dst, n));
        return;
      }
      if (existsSync(dst) || (() => { try { lstatSync(dst); return true; } catch { return false; } })()) {
        kept++;
        return;
      }
      mkdirSync(dirname(dst), { recursive: true });
      if (s.isSymbolicLink()) symlinkSync(readlinkSync(src), dst);
      else {
        try {
          linkSync(src, dst);
        } catch {
          copyFileSync(src, dst);
        }
      }
      restored++;
    };
    for (const item of e.items) put(item.stored, item.path);
    for (const g of e.git) {
      for (const r of g.refs) {
        if (r.what === 'work' || r.what === 'stash') {
          if (this.tryGit(['stash', 'store', '-m', `Escanor undo ${e.id}`, r.sha], g.repo) !== null) notes.push(`Your thrown-away changes in ${g.repo} are back as a stash entry: git stash apply`);
        } else if (r.what === 'head') {
          const now = this.tryGit(['rev-parse', 'HEAD'], g.repo);
          if (now && now !== r.sha && this.tryGit(['branch', `escanor-undo-${e.id}`, r.sha], g.repo) !== null) notes.push(`Where ${g.repo} was before is on branch escanor-undo-${e.id}`);
        } else if (r.what === 'branch' && r.name) {
          if (this.tryGit(['rev-parse', '--verify', `refs/heads/${r.name}`], g.repo) === null && this.tryGit(['branch', r.name, r.sha], g.repo) !== null) notes.push(`Branch ${r.name} is back in ${g.repo}`);
        } else if (r.what === 'remote-branch' && r.name && g.remote) {
          if (this.tryGit(['push', g.remote, `${r.sha}:refs/heads/${r.name}`], g.repo) !== null) notes.push(`Branch ${r.name} is back on ${g.remote}`);
          else notes.push(`Branch ${r.name} could not be pushed back to ${g.remote}; it is kept here as ${r.ref}`);
        }
      }
    }
    e.restoredAt = this.now();
    try {
      writeFileSync(join(this.root, e.id, 'entry.json.tmp'), JSON.stringify(e), { mode: 0o600 });
      renameSync(join(this.root, e.id, 'entry.json.tmp'), join(this.root, e.id, 'entry.json'));
    } catch {
      /* the restore itself happened */
    }
    return { ok: true, restored, kept, notes };
  }

  private dropDir(dir: string) {
    try {
      rmSync(dir, { recursive: true, force: true });
    } catch {
      /* best effort */
    }
  }

  /** Drops copies older than the retention, and the oldest while the drive is nearly full (under 3% free). Returns how many went. */
  prune(): number {
    const entries = this.entryDirs().map((id) => this.get(id) ?? ({ id, at: 0, git: [] } as unknown as UndoEntry)).sort((a, b) => a.at - b.at);
    let dropped = 0;
    const drop = (e: UndoEntry) => {
      for (const g of e.git ?? []) for (const r of g.refs) this.tryGit(['update-ref', '-d', r.ref], g.repo);
      this.dropDir(join(this.root, e.id));
      dropped++;
    };
    const left: UndoEntry[] = [];
    for (const e of entries) {
      if (this.now() - e.at > this.retentionMs) drop(e);
      else left.push(e);
    }
    const nearlyFull = () => {
      try {
        const s = statfsSync(this.root);
        return s.bavail / s.blocks < 0.03;
      } catch {
        return false;
      }
    };
    while (left.length > 1 && nearlyFull()) drop(left.shift()!);
    // Snapshots: only the newest two are kept.
    const snaps = left.filter((e) => e.source === 'snapshot').sort((a, b) => b.at - a.at);
    for (const e of snaps.slice(2)) drop(e);
    return dropped;
  }

  /**
   * The daily safety snapshot: a linked copy of the person's own folders (keys, settings, Desktop, Documents), so even a delete that
   * slipped past every check can be undone. Partial when there are too many files. Skips rebuildable and cache folders.
   */
  snapshot(dirs: string[], maxFiles = 500_000): UndoEntry | null {
    const last = this.list(1000).find((e) => e.source === 'snapshot');
    if (last && this.now() - last.at < DAY - 3_600_000) return null;
    const at = this.now();
    const id = newId(at);
    const dir = join(this.root, id);
    const entry: UndoEntry = { id, at, source: 'snapshot', command: 'Daily safety copy', cwd: this.home, items: [], git: [] };
    const budget: Budget = { files: 0, copied: 0, until: Date.now() + 10 * 60_000, maxFiles, partial: false, linkOnly: true };
    mkdirSync(join(dir, 'files'), { recursive: true, mode: 0o700 });
    for (const d of dirs) {
      if (budget.partial) break;
      // Keys and cloud logins are small: real copies, so even a key written over in place can be brought back.
      budget.copyBelow = /[\\/]\.(?:ssh|gnupg|aws|kube|azure|docker)$/.test(d) ? 1_000_000 : undefined;
      budget.linkOnly = budget.copyBelow === undefined;
      try {
        const item = this.keep(d, join(dir, 'files', String(entry.items.length)), budget, true);
        if (item) entry.items.push(item);
      } catch {
        /* that folder could not be read */
      }
    }
    if (budget.partial) entry.partial = true;
    if (!entry.items.length) {
      this.dropDir(dir);
      return null;
    }
    writeFileSync(join(dir, 'entry.json'), JSON.stringify(entry), { mode: 0o600 });
    return entry;
  }
}

/** The folders the daily snapshot keeps, those that exist. */
export function snapshotDirs(home = homedir(), extra: string[] = []): string[] {
  const names = ['.ssh', '.gnupg', '.config', 'Desktop', 'Documents', '.aws', '.kube', '.claude-profiles'];
  return [...names.map((n) => join(home, n)), ...extra].filter((p) => {
    try {
      return statSync(p).isDirectory();
    } catch {
      return false;
    }
  });
}
