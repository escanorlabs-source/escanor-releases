import { chmodSync, statSync } from 'node:fs';

/**
 * The agent's .env holds the hub token, so other users on the machine must not be able to read it. If the file is open to
 * group/other (any 0o077 bit), tighten it to 0600 and say so in one line (never the contents). Does nothing on Windows or
 * when the file is missing, and never throws: a file we cannot change is logged and left as it is.
 */
export function ensurePrivate(path: string): void {
  if (process.platform === 'win32') return;
  try {
    const st = statSync(path);
    if (!st.isFile() || (st.mode & 0o077) === 0) return;
    chmodSync(path, 0o600);
    console.warn(`Tightened permissions on ${path} to 0600 (it was readable by other users).`);
  } catch (e) {
    if ((e as NodeJS.ErrnoException)?.code === 'ENOENT') return;
    console.warn(`Could not tighten permissions on ${path}: ${(e as NodeJS.ErrnoException)?.code ?? 'error'}`);
  }
}
