import { accessSync, constants, existsSync, readdirSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { realRunner, type Runner } from './computerControl.js';

/**
 * How this computer can be woken from afar, so the phone can say which routes are ready and what to set up for the rest.
 *   wake_on_lan     the wired network card is set to wake on a magic packet; any always-on Escanor machine on the same network can send it
 *                   (the hub tells one: the helper the person chose, else any other machine of theirs that is online)
 *   scheduled_wake  the clock chip (RTC) can be told to wake the computer at a time, set before it sleeps (`schedule_wake`)
 * Neither can power a computer on that is fully shut down: that needs the BIOS setting "power on after AC loss" with a smart plug, which
 * the app explains. Sleeping (suspend) is therefore preferred to shutting down, and the agent only ever suspends.
 */

export type WakeDeps = { run?: Runner; env?: NodeJS.ProcessEnv; platform?: NodeJS.Platform; sysnet?: string; rtcAlarm?: string; exists?: (p: string) => boolean; canWrite?: (p: string) => boolean };

const canWriteReal = (p: string): boolean => {
  try {
    accessSync(p, constants.W_OK);
    return true;
  } catch {
    return false;
  }
};

/** Wired interfaces (a Wi-Fi card cannot normally wake a computer). */
export function wiredInterfaces(sysnet = '/sys/class/net', exists: (p: string) => boolean = existsSync): string[] {
  try {
    return readdirSync(sysnet).filter((n) => n !== 'lo' && exists(`${sysnet}/${n}/device`) && !exists(`${sysnet}/${n}/wireless`) && !exists(`${sysnet}/${n}/phy80211`) && !/^(docker|veth|br-|virbr|tun|tap|wg)/.test(n));
  } catch {
    return [];
  }
}

/** True when `ethtool <nic>` says Wake-on includes g (magic packet). */
export const wolOn = (ethtoolOut: string): boolean => /Wake-on:\s*\S*g/.test(ethtoolOut);

export async function wakeRoutes(d: WakeDeps = {}): Promise<string[]> {
  const platform = d.platform ?? process.platform;
  const out: string[] = [];
  if (platform === 'darwin') return ['wake_on_lan']; // macOS "Wake for network access" is the default on power
  if (platform !== 'linux') return out;
  const run = d.run ?? realRunner;
  const env = d.env ?? process.env;
  for (const nic of wiredInterfaces(d.sysnet)) {
    const r = await run({ cmd: 'ethtool', args: [nic] }, env);
    if (r.code === 0 && wolOn(r.stdout)) {
      out.push('wake_on_lan');
      break;
    }
  }
  const alarm = d.rtcAlarm ?? '/sys/class/rtc/rtc0/wakealarm';
  if ((d.exists ?? existsSync)(alarm)) {
    if ((d.canWrite ?? canWriteReal)(alarm)) out.push('scheduled_wake');
    else {
      const sudo = await run({ cmd: 'sudo', args: ['-n', '-l', 'rtcwake'] }, env);
      if (sudo.code === 0) out.push('scheduled_wake');
    }
  }
  return out;
}

export const MAX_WAKE_DAYS = 14;

/** The wake time, in seconds since 1970, if it is sensible (in the future, within two weeks). */
export function wakeEpoch(atMs: unknown, now: number): number | null {
  const n = typeof atMs === 'number' ? atMs : Number(atMs);
  if (!Number.isFinite(n) || n <= now + 60_000 || n > now + MAX_WAKE_DAYS * 86_400_000) return null;
  return Math.floor(n / 1000);
}

/** Sets the clock chip's alarm (`rtcwake -m no`, which wakes nothing now). Direct write when allowed, else through sudo without a password. */
export async function setWakeAlarm(epoch: number, d: WakeDeps = {}): Promise<boolean> {
  if ((d.platform ?? process.platform) !== 'linux') return false;
  const run = d.run ?? realRunner;
  const env = d.env ?? process.env;
  const a = await run({ cmd: 'rtcwake', args: ['-m', 'no', '-t', String(epoch)] }, env);
  if (a.code === 0) return true;
  const b = await run({ cmd: 'sudo', args: ['-n', 'rtcwake', '-m', 'no', '-t', String(epoch)] }, env);
  return b.code === 0;
}

/** The wake time the person asked for, kept so it is set again right before the computer sleeps. */
export class WakeSchedule {
  constructor(private file: string) {}
  get(): number | null {
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as { at?: unknown };
      return typeof j.at === 'number' && j.at * 1000 > Date.now() ? j.at : null;
    } catch {
      return null;
    }
  }
  set(epoch: number | null): void {
    mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
    writeFileSync(this.file, JSON.stringify({ at: epoch }), { mode: 0o600 });
  }
}
