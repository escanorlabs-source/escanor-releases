import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { childEnv } from './childEnv.js';
import { detectTestCommand, runTests } from './fixTests.js';
import { isManaged, switchOn } from './switches.js';

/**
 * L1-VERIFY: the computer's AI checks its own work before saying done. After a chat turn that changed files in a git repository
 * that has a test command, the agent runs the project's own checks (fixTests.ts); a red result goes back into the same chat as a
 * follow-up message, up to MAX_ROUNDS times, and a chat still red then ends with a plain note. Never a read-only turn, never
 * without a test command, never beyond TOTAL_CAP_MS for the whole job.
 *
 * Off unless ESCANOR_VERIFY_DONE=1: it runs a repo's test command on the person's own computer after every code-changing turn
 * (a slow suite, or one that touches live services through a .env file, would be a surprise), and every failed round spends the
 * person's AI usage. The owner's computer turns it on; it is a one-line setting, and `.escanor/no-verify` in a project opts it out.
 */
export const VERIFY_SWITCH = 'ESCANOR_VERIFY_DONE';
export const MAX_ROUNDS = 3;
/** One run of the checks. */
export const RUN_TIMEOUT_MS = 8 * 60_000;
/** The checks and the follow-ups of one job, together. */
export const TOTAL_CAP_MS = 25 * 60_000;
const GIT_TIMEOUT_MS = 30_000;
const MAX_STAT_FILES = 500;

export const verifyOn = (env: NodeJS.ProcessEnv): boolean => !isManaged(env) && switchOn(env[VERIFY_SWITCH], false);

export type VerifyGit = (cwd: string, args: string[]) => Promise<{ code: number; out: string }>;

export const realVerifyGit: VerifyGit = (cwd, args) =>
  new Promise((resolve) => {
    const env = { ...childEnv(process.env), GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0', LC_ALL: 'C' };
    execFile('git', ['-C', cwd, ...args], { timeout: GIT_TIMEOUT_MS, env, maxBuffer: 16 * 1024 * 1024 }, (err, stdout) => {
      resolve({ code: err ? 1 : 0, out: String(stdout ?? '') });
    });
  });

/** The repository's root, or null when the folder is not inside a git work tree. */
export async function repoRoot(cwd: string, git: VerifyGit = realVerifyGit): Promise<string | null> {
  const r = await git(cwd, ['rev-parse', '--show-toplevel']);
  return r.code === 0 && r.out.trim() ? r.out.trim() : null;
}

/** A fingerprint of the working tree (changed, added and removed files, and what is in them); null when it cannot be read. */
export async function snapshot(cwd: string, git: VerifyGit = realVerifyGit): Promise<string | null> {
  const root = await repoRoot(cwd, git);
  if (!root) return null;
  const status = await git(root, ['status', '--porcelain=v1', '-uall', '-z']);
  if (status.code !== 0) return null;
  const diff = await git(root, ['diff', 'HEAD']);
  const h = createHash('sha1').update(status.out).update('\0').update(diff.code === 0 ? diff.out : '');
  // Untracked files are not in the diff, and a file edited twice keeps its status letter: size and time tell.
  let n = 0;
  for (const entry of status.out.split('\0')) {
    if (entry.length < 4 || n++ >= MAX_STAT_FILES) continue;
    try {
      const s = statSync(join(root, entry.slice(3)));
      h.update(`${entry}:${s.size}:${Math.round(s.mtimeMs)}\0`);
    } catch {
      // removed: the status line says so
    }
  }
  return h.digest('hex');
}

/** The project's own check, from the folder the chat is in or the repository's root; null = none known, or the person opted out. */
export async function checkFor(cwd: string, git: VerifyGit = realVerifyGit): Promise<{ root: string; cmd: string } | null> {
  const root = await repoRoot(cwd, git);
  if (!root) return null;
  for (const dir of cwd === root ? [root] : [cwd, root]) {
    if (existsSync(join(dir, '.escanor', 'no-verify'))) return null;
    const cmd = detectTestCommand(dir);
    if (cmd) return { root: dir, cmd };
  }
  return null;
}

export const followUpText = (cmd: string, tail: string, round: number): string =>
  `Your checks fail: \`${cmd}\` did not pass (check ${round} of ${MAX_ROUNDS}). Fix them before saying you're done. The end of its output:\n\n${tail.trim().slice(-1800)}`;

export const giveUpNotice = (cmd: string): string => `Escanor couldn't verify this: \`${cmd}\` still fails.`;

export type VerifyOutcome = { kind: 'none' } | { kind: 'followup'; text: string } | { kind: 'giveup'; notice: string };
const NONE: VerifyOutcome = { kind: 'none' };

type Job = { before: Promise<string | null>; round: number; startedAt: number; running: boolean };

export type VerifyDeps = {
  git?: VerifyGit;
  now?: () => number;
  run?: typeof runTests;
};

/** One job per chat: starts with the person's message (the tree before), is judged when the chat has gone idle. */
export class Verifier<K extends object> {
  private jobs = new Map<K, Job>();
  private git: VerifyGit;
  private now: () => number;
  private run: typeof runTests;

  constructor(deps: VerifyDeps = {}) {
    this.git = deps.git ?? realVerifyGit;
    this.now = deps.now ?? Date.now;
    this.run = deps.run ?? runTests;
  }

  /** The person's message starts (or restarts) the job: the tree as it is now, and no rounds used. */
  userTurn(key: K, cwd: string): void {
    const job = this.jobs.get(key);
    if (job) {
      job.round = 0;
      job.startedAt = this.now();
      return;
    }
    this.jobs.set(key, { before: snapshot(cwd, this.git).catch(() => null), round: 0, startedAt: this.now(), running: false });
  }

  /** The chat ended in a way that needs no check (stopped, failed, closed). */
  drop(key: K): void {
    this.jobs.delete(key);
  }

  /** Resolves once the tree before the turn has been read (tests wait for it before editing). */
  async ready(key: K): Promise<void> {
    await this.jobs.get(key)?.before;
  }

  has(key: K): boolean {
    return this.jobs.has(key);
  }

  /** The chat is idle after a good result. `idle()` is asked again after the checks: a new message of the person wins. */
  async finish(key: K, cwd: string, idle: () => boolean): Promise<VerifyOutcome> {
    const job = this.jobs.get(key);
    if (!job || job.running) return NONE;
    job.running = true;
    try {
      if (job.round === 0) {
        const [before, after] = await Promise.all([job.before, snapshot(cwd, this.git)]);
        if (before === null || after === null || before === after) return this.end(key);
      }
      const check = await checkFor(cwd, this.git);
      if (!check) return this.end(key);
      const left = job.startedAt + TOTAL_CAP_MS - this.now();
      if (left <= 0) return this.over(key, check.cmd);
      const r = await this.run(check.cmd, check.root, Math.min(RUN_TIMEOUT_MS, left));
      if (!idle() || this.jobs.get(key) !== job) return NONE; // the person wrote again, or the chat is gone: not ours to say
      if (r.exit === 0) return this.end(key);
      if (job.round >= MAX_ROUNDS || this.now() >= job.startedAt + TOTAL_CAP_MS) return this.over(key, check.cmd);
      job.round++;
      return { kind: 'followup', text: followUpText(check.cmd, r.tail, job.round) };
    } catch {
      return this.end(key);
    } finally {
      job.running = false;
    }
  }

  private end(key: K): VerifyOutcome {
    this.jobs.delete(key);
    return NONE;
  }

  private over(key: K, cmd: string): VerifyOutcome {
    this.jobs.delete(key);
    return { kind: 'giveup', notice: giveUpNotice(cmd) };
  }
}
