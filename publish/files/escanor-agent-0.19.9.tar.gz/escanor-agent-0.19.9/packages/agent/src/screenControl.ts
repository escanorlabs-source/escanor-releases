import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { desktopEnv, firstThatWorks, install, openSteps, realRunner, type Runner, type Step } from './computerControl.js';

/**
 * Jarvis phase 2, the screen: wake it and keep it awake while something is shown, put a page full screen, unlock it after the
 * fingerprint yes, and take a picture of it for the phone. Linux first (GNOME on Wayland and X11), with macOS and Windows paths.
 * Everything here is one small known program with fixed arguments (never a shell, never text from the phone as a command), run in
 * the real desktop session's environment (computerControl.desktopEnv). A browser is only ever started by the desktop's own opener
 * (xdg-open, open, rundll32) and never stopped from here: the picture, the lock and the awake lock use no browser process.
 */

export type Platform = NodeJS.Platform;

// ------------------------------------------------------------------------------------------------- python helpers (GNOME)

/** Holds GNOME's own "do not blank the screen or suspend" lock (org.gnome.SessionManager.Inhibit, flags idle + suspend) for N seconds. */
export const GNOME_INHIBIT_PY = `
import sys, time
from gi.repository import Gio, GLib
secs = int(sys.argv[1])
bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
bus.call_sync('org.gnome.SessionManager', '/org/gnome/SessionManager', 'org.gnome.SessionManager', 'Inhibit',
  GLib.Variant('(susu)', ('Escanor', 0, 'Showing something for you', 12)), None, Gio.DBusCallFlags.NONE, 5000, None)
time.sleep(secs)
`;

/**
 * One picture of the whole screen, from GNOME's own screen-cast service (org.gnome.Mutter.ScreenCast) and one frame of its
 * PipeWire stream (GStreamer). It needs no pop-up the owner would have to click, which a remote picture cannot wait for (the
 * portal's Screenshot asks every time for a program without an app id), and GNOME shows its screen-sharing indicator while it runs.
 * argv: output file, width. Prints nothing; exit 0 and the file exist when it worked.
 */
export const GNOME_SHOT_PY = `
import sys, subprocess, time
from gi.repository import Gio, GLib
out, width = sys.argv[1], int(sys.argv[2])
bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
RD, SC = 'org.gnome.Mutter.RemoteDesktop', 'org.gnome.Mutter.ScreenCast'
def call(dest, path, iface, method, args=None, sig=None):
    return bus.call_sync(dest, path, iface, method, GLib.Variant(sig, args) if sig else None, None, Gio.DBusCallFlags.NONE, 10000, None)
rd = call(RD, '/org/gnome/Mutter/RemoteDesktop', RD, 'CreateSession').unpack()[0]
S = RD + '.Session'
rdid = bus.call_sync(RD, rd, 'org.freedesktop.DBus.Properties', 'Get', GLib.Variant('(ss)', (S, 'SessionId')), None, Gio.DBusCallFlags.NONE, 5000, None).unpack()[0]
sc = call(SC, '/org/gnome/Mutter/ScreenCast', SC, 'CreateSession', ({'remote-desktop-session-id': GLib.Variant('s', rdid)},), '(a{sv})').unpack()[0]
node = {}
loop = GLib.MainLoop()
def on_sig(conn, snd, p, iface, sig, params, *a):
    node['id'] = params.unpack()[0]; loop.quit()
try:
    stream = call(SC, sc, SC + '.Session', 'RecordMonitor', ('', {'cursor-mode': GLib.Variant('u', 1)}), '(sa{sv})').unpack()[0]
    bus.signal_subscribe(SC, SC + '.Stream', 'PipeWireStreamAdded', stream, None, Gio.DBusSignalFlags.NONE, on_sig)
    call(RD, rd, S, 'Start')
    GLib.timeout_add_seconds(5, loop.quit); loop.run()
    if 'id' not in node: sys.exit(2)
    p = subprocess.Popen(['gst-launch-1.0', '-q', 'pipewiresrc', 'path=%d' % node['id'], 'num-buffers=1', '!', 'videoconvert', '!', 'videoscale', '!',
        'video/x-raw,width=%d' % width, '!', 'jpegenc', 'quality=60', '!', 'filesink', 'location=' + out])
    # A still screen sends no frame. A one-pixel move out and straight back makes one, and the pointer ends where it began.
    def nudge():
        for dx in (1.0, -1.0):
            try: call(RD, rd, S, 'NotifyPointerMotionRelative', (dx, 0.0), '(dd)')
            except Exception: pass
            time.sleep(0.1)
    for _ in range(3):
        nudge()
        try: p.wait(timeout=1.0); break
        except subprocess.TimeoutExpired: pass
    try: p.wait(timeout=10)
    except subprocess.TimeoutExpired:
        p.kill(); sys.exit(1)
    sys.exit(p.returncode)
finally:
    try: call(RD, rd, S, 'Stop')
    except Exception: pass
`;

/**
 * Presses keys in the focused window through GNOME's own remote-desktop service (org.gnome.Mutter.RemoteDesktop), which asks for no
 * permission on the person's own session and works on Wayland where xdotool and wtype cannot. Keysyms as hex words, from the
 * arguments, or from standard input when the first argument is "-" (so typed text never appears in a program's arguments).
 */
export const GNOME_KEYS_PY = `
import sys, time
from gi.repository import Gio, GLib
words = sys.stdin.read().split() if sys.argv[1:2] == ['-'] else sys.argv[1:]
RD = 'org.gnome.Mutter.RemoteDesktop'
bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
def call(path, iface, method, args=None, sig=None):
    return bus.call_sync(RD, path, iface, method, GLib.Variant(sig, args) if sig else None, None, Gio.DBusCallFlags.NONE, 10000, None)
sess = call('/org/gnome/Mutter/RemoteDesktop', RD, 'CreateSession').unpack()[0]
try:
    call(sess, RD + '.Session', 'Start')
    for w in words:
        k = int(w, 16)
        call(sess, RD + '.Session', 'NotifyKeyboardKeysym', (k, True), '(ub)')
        call(sess, RD + '.Session', 'NotifyKeyboardKeysym', (k, False), '(ub)')
        time.sleep(0.02)
    time.sleep(0.15)
finally:
    try: call(sess, RD + '.Session', 'Stop')
    except Exception: pass
`;

export const isGnome = (env: NodeJS.ProcessEnv): boolean => /gnome|ubuntu/i.test(env.XDG_CURRENT_DESKTOP ?? '');

// ------------------------------------------------------------------------------------------------- the steps, per platform

/** The programs that wake a blanked screen (any one that works is enough; all are tried). */
export function wakeSteps(platform: Platform): Step[] {
  if (platform === 'darwin') return [{ cmd: 'caffeinate', args: ['-u', '-t', '5'] }];
  if (platform === 'win32') {
    return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -MemberDefinition '[DllImport(\"kernel32.dll\")] public static extern uint SetThreadExecutionState(uint f);' -Name W -Namespace E; [E.W]::SetThreadExecutionState(0x80000002) | Out-Null"] }];
  }
  const gdbus = (dest: string, path: string, method: string, ...a: string[]): Step => ({ cmd: 'gdbus', args: ['call', '--session', '--dest', dest, '--object-path', path, '--method', method, ...a] });
  return [
    gdbus('org.gnome.ScreenSaver', '/org/gnome/ScreenSaver', 'org.gnome.ScreenSaver.SimulateUserActivity'),
    gdbus('org.freedesktop.ScreenSaver', '/org/freedesktop/ScreenSaver', 'org.freedesktop.ScreenSaver.SimulateUserActivity'),
    gdbus('org.gnome.ScreenSaver', '/org/gnome/ScreenSaver', 'org.gnome.ScreenSaver.SetActive', 'false'),
    { cmd: 'xset', args: ['dpms', 'force', 'on'] },
  ];
}

/** Hold the screen and the computer awake for `seconds`. Each step is a program that ends by itself, so nothing stays held if this agent dies. */
export function awakeSteps(seconds: number, platform: Platform): Step[] {
  const s = Math.max(1, Math.floor(seconds));
  if (platform === 'darwin') return [{ cmd: 'caffeinate', args: ['-d', '-i', '-s', '-t', String(s)], detach: true }];
  if (platform === 'win32') {
    const script = `Add-Type -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);' -Name W -Namespace E; $end=(Get-Date).AddSeconds(${s}); while((Get-Date) -lt $end){ [E.W]::SetThreadExecutionState(0x80000003) | Out-Null; Start-Sleep -Seconds 20 }; [E.W]::SetThreadExecutionState(0x80000000) | Out-Null`;
    return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-WindowStyle', 'Hidden', '-Command', script], detach: true }];
  }
  return [
    // GNOME's own idle and suspend lock (stops the screen blanking and the computer suspending by itself), and logind's idle lock (a user cannot take logind's sleep lock without administrator rights, so only idle is asked).
    { cmd: 'python3', args: ['-I', '-c', GNOME_INHIBIT_PY, String(s)], detach: true },
    { cmd: 'systemd-inhibit', args: ['--what=idle', '--who=Escanor', '--why=Showing something for you', '--mode=block', 'sleep', String(s)], detach: true },
  ];
}

const BROWSER_CLASS = /chrom|firefox|brave|vivaldi|opera|edge|epiphany|librewolf|zen|waterfox|safari/i;

/** The newest browser window in `wmctrl -l -x` output (X11 and XWayland windows; the list is oldest first). */
export function lastBrowserWindow(wmctrlList: string): string | null {
  const ids = wmctrlList
    .split('\n')
    .map((l) => l.trim().split(/\s+/))
    .filter((p) => p.length >= 3 && /^0x[0-9a-f]+$/i.test(p[0]) && BROWSER_CLASS.test(p[2]))
    .map((p) => p[0]);
  return ids.length ? ids[ids.length - 1] : null;
}

/** Keys that toggle full screen in a browser, for the tools that can press one (none of these is installed everywhere). */
export function fullscreenKeySteps(platform: Platform, env: NodeJS.ProcessEnv = {}): Step[] {
  if (platform === 'darwin') return [{ cmd: 'osascript', args: ['-e', 'tell application "System Events" to keystroke "f" using {control down, command down}'] }];
  if (platform === 'win32') return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', "(New-Object -ComObject WScript.Shell).SendKeys('{F11}')"] }];
  return [
    ...(isGnome(env) ? [{ cmd: 'python3', args: ['-I', '-c', GNOME_KEYS_PY, 'ffc8'] }] : []),
    { cmd: 'xdotool', args: ['key', 'F11'] },
    { cmd: 'wtype', args: ['-k', 'F11'] },
    { cmd: 'ydotool', args: ['key', '87:1', '87:0'] },
  ];
}

/** The screen picture programs, best first. Each writes a JPEG to `file`, at most `width` wide. */
export function captureSteps(file: string, width: number, platform: Platform, env: NodeJS.ProcessEnv): Step[] {
  if (platform === 'darwin') return [{ cmd: 'screencapture', args: ['-x', '-t', 'jpg', file] }];
  if (platform === 'win32') {
    const script = `Add-Type -AssemblyName System.Windows.Forms,System.Drawing; $b=[System.Windows.Forms.SystemInformation]::VirtualScreen; $bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height; $g=[System.Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size); $w=${width}; $h=[int]($b.Height*$w/$b.Width); if($b.Width -gt $w){ $s=New-Object System.Drawing.Bitmap $w,$h; $gs=[System.Drawing.Graphics]::FromImage($s); $gs.DrawImage($bmp,0,0,$w,$h); $s.Save('${file.replace(/'/g, "''")}',[System.Drawing.Imaging.ImageFormat]::Jpeg) } else { $bmp.Save('${file.replace(/'/g, "''")}',[System.Drawing.Imaging.ImageFormat]::Jpeg) }`;
    return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', script] }];
  }
  const wayland = !!env.WAYLAND_DISPLAY;
  const gnome = /gnome|ubuntu/i.test(env.XDG_CURRENT_DESKTOP ?? '');
  const steps: Step[] = [];
  if (gnome) steps.push({ cmd: 'python3', args: ['-I', '-c', GNOME_SHOT_PY, file, String(width)] });
  if (wayland) steps.push({ cmd: 'grim', args: ['-t', 'jpeg', '-q', '60', '-s', '0.5', file] }, { cmd: 'spectacle', args: ['-b', '-n', '-f', '-o', file] });
  steps.push({ cmd: 'maim', args: ['-f', 'jpg', '-m', '6', file] }, { cmd: 'scrot', args: ['-q', '60', '-o', file] }, { cmd: 'import', args: ['-window', 'root', '-resize', `${width}x>`, '-quality', '60', file] });
  return steps;
}

/** The session to unlock: the one the desktop is in (XDG_SESSION_ID), else the first graphical one of this user in `loginctl list-sessions`. */
export function pickSession(env: NodeJS.ProcessEnv, listing: string, uid: number | null): string | null {
  if (env.XDG_SESSION_ID && /^[A-Za-z0-9_-]{1,32}$/.test(env.XDG_SESSION_ID)) return env.XDG_SESSION_ID;
  for (const line of listing.split('\n')) {
    const p = line.trim().split(/\s+/);
    if (p.length >= 3 && /^[A-Za-z0-9_-]{1,32}$/.test(p[0]) && (uid === null || p[1] === String(uid)) && (p[3] ?? '').startsWith('seat')) return p[0];
  }
  return null;
}

const SESSION_ID = /^[A-Za-z0-9_-]{1,32}$/;

/** Every session of this user that sits on a seat (a screen), in `loginctl list-sessions --no-legend` output. SSH and other seatless sessions are not screens. */
export function seatSessions(listing: string, uid: number | null): string[] {
  const out: string[] = [];
  for (const line of listing.split('\n')) {
    const p = line.trim().split(/\s+/);
    if (p.length >= 4 && SESSION_ID.test(p[0]!) && (uid === null || p[1] === String(uid)) && p[3]!.startsWith('seat')) out.push(p[0]!);
  }
  return out;
}

/**
 * The session whose screen is locked. Under a system or user service XDG_SESSION_ID is usually unset, and when the agent was started
 * from a terminal or SSH it names THAT session, not the desktop. So ask logind: of this user's sessions on a seat, take the active
 * graphical one (wayland, x11 or mir), then one the environment names, then the first. With no usable list the environment's id is
 * the last resort.
 */
export async function findSession(run: Runner, env: NodeJS.ProcessEnv, uid: number | null): Promise<string | null> {
  const list = await run({ cmd: 'loginctl', args: ['list-sessions', '--no-legend'] }, env);
  const cands = seatSessions(list.code === 0 ? list.stdout : '', uid);
  if (cands.length === 0) return pickSession(env, '', uid);
  if (cands.length === 1) return cands[0]!;
  const envId = env.XDG_SESSION_ID && SESSION_ID.test(env.XDG_SESSION_ID) ? env.XDG_SESSION_ID : null;
  const info: { id: string; graphical: boolean; active: boolean }[] = [];
  for (const id of cands) {
    const r = await run({ cmd: 'loginctl', args: ['show-session', id, '-p', 'Type', '-p', 'Class', '-p', 'Active'] }, env);
    const kv = (k: string) => new RegExp(`^${k}=(.*)$`, 'm').exec(r.stdout)?.[1]?.trim() ?? '';
    info.push({ id, graphical: r.code === 0 && /^(wayland|x11|mir)$/.test(kv('Type')) && (kv('Class') === 'user' || kv('Class') === ''), active: kv('Active') === 'yes' });
  }
  return (
    info.find((i) => i.graphical && i.active)?.id ??
    info.find((i) => i.graphical && i.id === envId)?.id ??
    info.find((i) => i.graphical)?.id ??
    (envId && cands.includes(envId) ? envId : cands[0]!)
  );
}

/**
 * Nobody is signed in on the screen: the login screen after a restart or a sign-out. The app's "Unlock / Turn on" signs the person in
 * there once, only after their fingerprint on the phone (sessionHelper.ts); nothing types a password and nothing signs in by itself.
 */
export const SIGNED_OUT_SAY =
  'This computer is at its login screen (it was restarted or signed out). Tap "Unlock / Turn on" in the app: it asks for your fingerprint on the phone, then signs you in once. ' +
  'It can still run commands, code, tests and builds for you now. If the app says this computer is not set up for that, update Escanor on it.';

/** A login-screen session (gdm, sddm, lightdm) in `loginctl list-sessions`, with none of the person's own on a seat. */
export function atLoginScreen(listing: string): boolean {
  return listing.split('\n').some((line) => /^(gdm|gdm3|Debian-gdm|sddm|lightdm)$/.test(line.trim().split(/\s+/)[2] ?? ''));
}

export function unlockSteps(session: string, platform: Platform): Step[] | null {
  // macOS and Windows cannot be unlocked without typing the account password into the login screen, which this agent never does.
  if (platform !== 'linux') return null;
  // --no-ask-password: if logind would need a password it must fail here, never pop a dialog on the owner's screen.
  return [{ cmd: 'loginctl', args: ['unlock-session', '--no-ask-password', session] }];
}

/** The on-screen notice that someone is looking (and when it stops). `ms` is how long it stays; a critical one stays until closed. `-p` prints its id. */
export function noticeSteps(title: string, body: string, ms: number, platform: Platform, urgency: 'critical' | 'normal' = 'critical'): Step[] {
  if (platform === 'darwin') return [{ cmd: 'osascript', args: ['-e', `display notification ${JSON.stringify(body)} with title ${JSON.stringify(title)}`] }];
  if (platform === 'win32') {
    const q = (t: string) => t.replace(/'/g, "''");
    return [{ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', `Add-Type -AssemblyName System.Windows.Forms; $n=New-Object System.Windows.Forms.NotifyIcon; $n.Icon=[System.Drawing.SystemIcons]::Information; $n.Visible=$true; $n.ShowBalloonTip(${Math.min(ms, 30000)},'${q(title)}','${q(body)}',[System.Windows.Forms.ToolTipIcon]::Warning); Start-Sleep -Seconds 6; $n.Dispose()`] }];
  }
  return [{ cmd: 'notify-send', args: ['-p', '-u', urgency, '-a', 'Escanor', '-i', 'video-display', '-t', String(Math.max(1000, ms)), title, body] }];
}

/** Takes a notice away again (a critical one never goes by itself). Linux: the notification service's own CloseNotification. */
export function closeNoticeSteps(id: number, platform: Platform): Step[] {
  if (platform !== 'linux' || !Number.isInteger(id) || id <= 0) return [];
  return [{ cmd: 'gdbus', args: ['call', '--session', '--dest', 'org.freedesktop.Notifications', '--object-path', '/org/freedesktop/Notifications', '--method', 'org.freedesktop.Notifications.CloseNotification', String(id)] }];
}

// ------------------------------------------------------------------------------------------------- running them

export type Held = { pid: number | undefined; stop(): void };
/** Starts a program that is left running (the awake lock). Replaceable in tests. */
export type Holder = (step: Step, env: NodeJS.ProcessEnv) => Held | null;

export const realHolder: Holder = (step, env) => {
  let child: ChildProcess;
  try {
    child = spawn(step.cmd, step.args, { env, stdio: 'ignore', detached: true, windowsHide: true });
  } catch {
    return null;
  }
  child.on('error', () => {});
  child.unref();
  return {
    pid: child.pid,
    stop() {
      // Only the helper this agent started itself (a sleep, a lock holder): never a browser or anything of the person's.
      try {
        if (child.pid) process.kill(-child.pid, 'SIGTERM');
      } catch {
        try {
          child.kill('SIGTERM');
        } catch {
          /* already gone */
        }
      }
    },
  };
};

export type ScreenDeps = { platform?: Platform; env?: NodeJS.ProcessEnv; run?: Runner; hold?: Holder; now?: () => number; sleep?: (ms: number) => Promise<void>; uid?: number | null; tmp?: string };

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** The awake lock: one at a time, for a while, let go on request or when its time is up. */
export class AwakeLease {
  private held: Held[] = [];
  private until = 0;
  private timer: NodeJS.Timeout | null = null;

  constructor(private d: ScreenDeps = {}) {}

  get awakeUntil(): number | null {
    return this.until > (this.d.now ?? Date.now)() ? this.until : null;
  }

  /** Wake the screen and keep it awake `minutes` minutes. Returns false when nothing could hold it. */
  async start(minutes: number): Promise<{ ok: boolean; missing: string[] }> {
    const platform = this.d.platform ?? process.platform;
    const env = desktopEnv(this.d.env ?? process.env, platform);
    const run = this.d.run ?? realRunner;
    this.release();
    for (const s of wakeSteps(platform)) await run(s, env);
    const hold = this.d.hold ?? realHolder;
    const missing: string[] = [];
    for (const s of awakeSteps(minutes * 60, platform)) {
      const h = hold(s, env);
      if (h) this.held.push(h);
      else missing.push(s.cmd);
    }
    if (!this.held.length) return { ok: false, missing };
    this.until = (this.d.now ?? Date.now)() + minutes * 60_000;
    this.timer = setTimeout(() => this.release(), minutes * 60_000 + 2000);
    this.timer.unref();
    return { ok: true, missing };
  }

  release(): boolean {
    const had = this.held.length > 0;
    for (const h of this.held) h.stop();
    this.held = [];
    this.until = 0;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    return had;
  }
}

/** Put the page that was just opened full screen, as far as this computer lets a program do it. Says what it did. */
export type FullscreenHelper = { newestBrowser(before: unknown[] | null): Promise<{ id: number } | null>; focus(id: number): Promise<boolean>; fullscreen(id: number): Promise<boolean>; status(): Promise<string> };

export async function goFullscreen(d: ScreenDeps = {}, helper?: FullscreenHelper, before: unknown[] | null = null): Promise<{ done: boolean; how: string }> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  // The shell's own focus helper (GNOME): the one dependable way. It finds the browser window itself, so no fixed wait is needed.
  if (helper && (await helper.status()) === 'ready') {
    const w = await helper.newestBrowser(before);
    if (w && (await helper.focus(w.id).catch(() => false)) && (await helper.fullscreen(w.id).catch(() => false))) return { done: true, how: 'shell' };
    return { done: false, how: 'the browser window could not be found or brought to the front' };
  }
  await (d.sleep ?? wait)(1800); // the browser window needs a moment to exist
  if (platform === 'linux') {
    const list = await run({ cmd: 'wmctrl', args: ['-l', '-x'] }, env);
    const id = list.code === 0 ? lastBrowserWindow(list.stdout) : null;
    if (id) {
      const r = await run({ cmd: 'wmctrl', args: ['-i', '-r', id, '-b', 'add,fullscreen'] }, env);
      if (r.code === 0) return { done: true, how: 'window' };
    }
  }
  const keys = await firstThatWorks(fullscreenKeySteps(platform, env), run, env);
  if (keys.ok) return { done: true, how: helper && (await helper.status()) === 'restart_needed' ? 'key_restart' : 'key' };
  return { done: false, how: keys.missing.length ? `needs ${[...new Set(keys.missing)].join(' or ')}` : 'no way' };
}

export type Shot = { b64: string; mime: 'image/jpeg'; width: number; height: number; bytes: number };

/** Width and height from a JPEG's start-of-frame marker. */
export function jpegSize(buf: Buffer): { width: number; height: number } | null {
  if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8) return null;
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) {
      i++;
      continue;
    }
    const m = buf[i + 1];
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
    i += 2 + buf.readUInt16BE(i + 2);
  }
  return null;
}

const MAX_SHOT_BYTES = 700_000;

export const SIGNED_OUT_SHOT_SAY =
  'This computer is at its login screen (it was restarted or signed out), so there is no desktop to show yet. Tap "Unlock / Turn on" in the app (it asks for your fingerprint) and try again. ' +
  'It can still run commands, code, tests and builds for you now.';

/** One picture of the screen, or why not. The file lives only in a private temporary folder and is removed at once. */
export async function takeScreenshot(d: ScreenDeps = {}): Promise<{ ok: true; shot: Shot } | { ok: false; say: string }> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  const dir = mkdtempSync(join(d.tmp ?? tmpdir(), 'escanor-shot-'));
  const file = join(dir, 'screen.jpg');
  try {
    const missing: string[] = [];
    for (const s of captureSteps(file, 1280, platform, env)) {
      const r = await run(s, env);
      if (r.missing) {
        missing.push(s.cmd);
        continue;
      }
      let size = 0;
      try {
        size = statSync(file).size;
      } catch {
        size = 0;
      }
      if (r.code !== 0 || size === 0) continue;
      const buf = readFileSync(file);
      const dim = jpegSize(buf);
      if (!dim) continue; // not a JPEG (a tool that wrote PNG): not small enough to send, try the next one
      if (buf.length > MAX_SHOT_BYTES) return { ok: false, say: 'The screen picture came out too big to send. Try again.' };
      return { ok: true, shot: { b64: buf.toString('base64'), mime: 'image/jpeg', width: dim.width, height: dim.height, bytes: buf.length } };
    }
    if (platform === 'linux') {
      // After a restart nobody is signed in yet: there is no desktop to take a picture of, and no program would fix that.
      const list = await run({ cmd: 'loginctl', args: ['list-sessions', '--no-legend'] }, env);
      const uid = d.uid === undefined ? (typeof process.getuid === 'function' ? process.getuid() : null) : d.uid;
      if (!pickSession({}, list.stdout, uid) && atLoginScreen(list.stdout)) return { ok: false, say: SIGNED_OUT_SHOT_SAY };
    }
    const hint = platform === 'linux' ? ` This computer needs python3 with GObject and GStreamer's PipeWire plugin (GNOME), grim (Sway/Hyprland), or scrot/maim (X11).${install(missing, platform)}` : '';
    return { ok: false, say: `Could not take a picture of the screen here.${hint}` };
  } finally {
    try {
      rmSync(dir, { recursive: true, force: true }); // the private temp folder this call made, nothing else
    } catch {
      /* temp is cleaned anyway */
    }
  }
}

/** Unlock the screen of the person's own session (Linux: logind). Never types a password. */
export async function unlockScreen(d: ScreenDeps = {}): Promise<{ ok: boolean; say: string }> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  if (platform === 'darwin') return { ok: false, say: 'A Mac cannot be unlocked from here: macOS only accepts the account password or an Apple Watch at its login screen. The screen is awake and waiting.' };
  if (platform === 'win32') return { ok: false, say: 'Windows cannot be unlocked from here: Windows only accepts the account sign-in at its lock screen. The screen is awake and waiting.' };
  const uid = d.uid === undefined ? (typeof process.getuid === 'function' ? process.getuid() : null) : d.uid;
  const session = await findSession(run, env, uid);
  if (!session) {
    const list = await run({ cmd: 'loginctl', args: ['list-sessions', '--no-legend'] }, env);
    return { ok: false, say: atLoginScreen(list.stdout) ? SIGNED_OUT_SAY : 'Could not find this computer\'s desktop session to unlock.' };
  }
  const r = await firstThatWorks(unlockSteps(session, platform)!, run, env);
  if (!r.ok) {
    return { ok: false, say: r.missing.length ? `Could not unlock the screen.${install(r.missing, platform)}` : 'Linux refused to unlock the screen from here. It only lets this person\'s own signed-in session do that, so check that the Escanor agent runs as the same user that is signed in on the screen.' };
  }
  // Prove it: logind's LockedHint must say "no" before anything else (the remote screen) starts.
  const sleep = d.sleep ?? wait;
  let unknown = true;
  for (let i = 0; i < 12; i++) {
    const h = await run({ cmd: 'loginctl', args: ['show-session', session, '-p', 'LockedHint'] }, env);
    const m = h.code === 0 ? /LockedHint=(yes|no)/.exec(h.stdout) : null;
    if (m) {
      unknown = false;
      if (m[1] === 'no') return { ok: true, say: 'Unlocked the screen.' };
    }
    await sleep(250);
  }
  if (unknown) return { ok: true, say: 'Unlocked the screen.' }; // logind would not say; the caller checks the lock itself
  return { ok: false, say: 'Asked the screen to unlock, but the computer still reports it as locked. Try once more; if it stays locked, unlock it at the keyboard.' };
}

/** Shows a notice; returns its id where the desktop gives one (Linux), so it can be closed. */
export async function notice(title: string, body: string, ms: number, d: ScreenDeps = {}, urgency: 'critical' | 'normal' = 'critical'): Promise<number | null> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  for (const s of noticeSteps(title, body, ms, platform, urgency)) {
    const r = await run(s, env);
    if (r.code === 0) {
      const id = Number(r.stdout.trim());
      return Number.isInteger(id) && id > 0 ? id : null;
    }
  }
  return null;
}

export async function closeNotice(id: number, d: ScreenDeps = {}): Promise<void> {
  const platform = d.platform ?? process.platform;
  await firstThatWorks(closeNoticeSteps(id, platform), d.run ?? realRunner, desktopEnv(d.env ?? process.env, platform));
}

/** Open a page the way the person would: the desktop's own opener. */
export async function openPage(url: string, d: ScreenDeps = {}): Promise<{ ok: boolean; missing: string[] }> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const r = await firstThatWorks(openSteps(url, platform), d.run ?? realRunner, env);
  return { ok: r.ok, missing: r.missing };
}
