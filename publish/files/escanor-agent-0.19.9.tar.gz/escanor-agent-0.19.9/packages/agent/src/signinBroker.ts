import { appendFileSync, chmodSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { MIN_SCRUB_LENGTH } from './machineSecrets.js';

/**
 * "Let Escanor sign in for me": the credential broker. Nothing here happens by itself. A use needs a PROOF: the owner's fingerprint (or
 * face) on the phone for that very request, or the "allow for N minutes" window the owner gave with one (signinApproval.ts). Without a
 * proof the broker fetches nothing, and says why. With one, the agent fetches a named secret from the Escanor vault (over its own
 * device channel) and hands it straight to the one program that needs it: a standard input, a one-use pipe for sudo's askpass, or a
 * child process's own environment. The value is held in memory for that one use and is never written to disk, never logged, never
 * returned to a chat or the AI, and never put in a program's arguments.
 *
 *  - Off by default. The owner turns it on (fingerprint on the phone, or by editing `signin-broker.json` at the computer). A broken or
 *    missing file means off, never a looser setting. ESCANOR_SIGNIN=0 keeps it off whatever the file says.
 *  - Only secrets on the owner's allow list can be used (exact names, or a name ending in `*`). The phone can only add names with a
 *    fingerprint yes; removing names or switching off is immediate.
 *  - sudo goes only for command lines on the owner's own list (exact match).
 *  - Every use (and every refusal) is one line in `signin-audit.jsonl` with the secret's NAME, what for and the outcome. Never a value.
 */

/** The proof a use carries: a fingerprint yes for this very request, or the window the owner granted with one. Only jarvis.ts makes one. */
export type UseProof = { readonly via: 'approval' | 'window'; readonly who: string };

export const SECRET_NAME = /^[A-Za-z_][A-Za-z0-9_.-]{0,127}$/;
const ALLOW_ENTRY = /^[A-Za-z_][A-Za-z0-9_.-]{0,126}\*?$/;
export const MAX_ALLOW = 50;
export const MAX_SUDO = 30;
export const SIGNIN_ENV = 'ESCANOR_SIGNIN';

export type BrokerPolicy = {
  enabled: boolean;
  /** Secret names the broker may use. An entry ending in `*` allows every name starting with the rest. */
  allow: string[];
  /** Whole command lines (single-spaced) sudo may run with the saved password. Exact match only. */
  sudo: string[];
};

export const OFF_POLICY: BrokerPolicy = { enabled: false, allow: [], sudo: [] };

const cleanList = (v: unknown, ok: (s: string) => boolean, max: number): string[] => {
  if (!Array.isArray(v)) return [];
  const out: string[] = [];
  for (const x of v) if (typeof x === 'string' && ok(x.trim()) && !out.includes(x.trim())) out.push(x.trim());
  return out.slice(0, max);
};

export const cleanAllow = (v: unknown): string[] => cleanList(v, (s) => ALLOW_ENTRY.test(s), MAX_ALLOW);
export const cleanSudo = (v: unknown): string[] => cleanList(v, (s) => s.length > 0 && s.length <= 300 && !/[\r\n\0]/.test(s) && !/\s{2,}/.test(s), MAX_SUDO);

/** Does this allow list cover `name`? */
export function allowCovers(allow: string[], name: string): boolean {
  if (!SECRET_NAME.test(name)) return false;
  return allow.some((a) => ALLOW_ENTRY.test(a) && (a.endsWith('*') ? name.startsWith(a.slice(0, -1)) : a === name));
}

/** The command line sudo was asked to run, in one canonical form ("systemctl restart x"). */
export const commandLine = (argv: string[]): string => argv.join(' ');

/** The owner's settings, read at every request so an edit applies at once. Written only by the agent (atomic, mode 0600). */
export class SigninStore {
  constructor(private file: string, private env: NodeJS.ProcessEnv = process.env) {}

  /** The computer's own settings force it off (the phone cannot change that). */
  lockedByEnv(): boolean {
    const raw = this.env[SIGNIN_ENV]?.trim().toLowerCase();
    return !!raw && ['0', 'false', 'off', 'no'].includes(raw);
  }

  read(): BrokerPolicy {
    let p: BrokerPolicy;
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as Record<string, unknown>;
      p = { enabled: j.enabled === true, allow: cleanAllow(j.allow), sudo: cleanSudo(j.sudo) };
    } catch {
      p = { ...OFF_POLICY };
    }
    return this.lockedByEnv() ? { ...p, enabled: false } : p;
  }

  write(patch: Partial<BrokerPolicy>): BrokerPolicy {
    const cur = this.read();
    const next: BrokerPolicy = {
      enabled: patch.enabled ?? cur.enabled,
      allow: patch.allow ? cleanAllow(patch.allow) : cur.allow,
      sudo: patch.sudo ? cleanSudo(patch.sudo) : cur.sudo,
    };
    mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
    const tmp = `${this.file}.tmp-${process.pid}`;
    writeFileSync(tmp, JSON.stringify(next), { mode: 0o600 });
    chmodSync(tmp, 0o600);
    renameSync(tmp, this.file);
    return next;
  }
}

// ---- the usage log ----------------------------------------------------------------------------------------------------------

export type AuditOutcome = 'used' | 'refused' | 'failed' | 'fixed';
export type AuditEntry = { at: number; name: string; purpose: string; outcome: AuditOutcome; why: string };

const MAX_AUDIT_BYTES = 500_000;

export class SigninAudit {
  constructor(private file: string, private now: () => number = Date.now) {}

  add(e: Omit<AuditEntry, 'at'>): void {
    try {
      mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
      try {
        if (statSync(this.file).size > MAX_AUDIT_BYTES) renameSync(this.file, `${this.file}.1`);
      } catch {
        /* first line */
      }
      const line: AuditEntry = { at: this.now(), name: e.name.slice(0, 128), purpose: e.purpose.slice(0, 200), outcome: e.outcome, why: e.why.slice(0, 300) };
      appendFileSync(this.file, `${JSON.stringify(line)}\n`, { mode: 0o600 });
    } catch {
      /* the log never stops the work */
    }
  }

  /** Newest first. */
  recent(limit = 30): AuditEntry[] {
    let text = '';
    try {
      text = readFileSync(this.file, 'utf8');
    } catch {
      return [];
    }
    const out: AuditEntry[] = [];
    for (const line of text.split('\n').reverse()) {
      if (!line.trim()) continue;
      try {
        const j = JSON.parse(line) as AuditEntry;
        if (typeof j.at === 'number' && typeof j.name === 'string' && typeof j.outcome === 'string') out.push({ at: j.at, name: j.name, purpose: String(j.purpose ?? ''), outcome: j.outcome, why: String(j.why ?? '') });
      } catch {
        /* skip a damaged line */
      }
      if (out.length >= limit) break;
    }
    return out;
  }
}

// ---- the broker -------------------------------------------------------------------------------------------------------------

export type VaultFetch = (name: string) => Promise<{ ok: true; value: string } | { ok: false; reason: string }>;
export type Use<T> = { ok: true; value: T } | { ok: false; reason: string };

/** Takes a secret value out of any text that is about to leave this module. Short values are not scrubbed (they would match everything). */
export function scrubValue(text: string, value: string): string {
  return value.length >= MIN_SCRUB_LENGTH ? text.split(value).join('[secret]') : text;
}

export class CredentialBroker {
  constructor(private d: { policy: () => BrokerPolicy; fetch: VaultFetch; audit: SigninAudit }) {}

  enabled(): boolean {
    return this.d.policy().enabled;
  }

  /** May the broker use this secret right now? (Does not fetch it.) */
  allowed(name: string): boolean {
    const p = this.d.policy();
    return p.enabled && allowCovers(p.allow, name);
  }

  sudoAllowed(argv: string[]): boolean {
    const p = this.d.policy();
    return p.enabled && argv.length > 0 && argv.every((a) => a !== '' && !/[\r\n\0]/.test(a)) && p.sudo.includes(commandLine(argv));
  }

  /**
   * Fetch `name`, give it to `consume` (which delivers it to a program and answers with an outcome that must not hold it) and forget it.
   * Every call is one line in the usage log. The answer never carries the value: a reason is scrubbed of it, and so is a string result.
   */
  async use<T>(name: string, purpose: string, proof: UseProof | null | undefined, consume: (value: string) => Promise<T>): Promise<Use<T>> {
    const p = this.d.policy();
    if (!p.enabled) return this.refuse(name, purpose, 'Let Escanor sign in for me is off on this computer.');
    if (!proof || (proof.via !== 'approval' && proof.via !== 'window')) return this.refuse(name, purpose, 'Nothing is signed in without your fingerprint on the phone, and there was none for this.');
    if (!SECRET_NAME.test(name) || !allowCovers(p.allow, name)) return this.refuse(name, purpose, `${name} is not on the list of saved secrets this computer may use.`);
    let value = '';
    try {
      const got = await this.d.fetch(name);
      if (!got.ok) {
        this.d.audit.add({ name, purpose, outcome: 'failed', why: got.reason });
        return { ok: false, reason: got.reason };
      }
      value = got.value;
      const result = await consume(value);
      this.d.audit.add({ name, purpose, outcome: 'used', why: `handed to the program that needed it; never shown. ${proof.via === 'window' ? 'Inside the time window you allowed with your fingerprint' : 'Approved with your fingerprint'}${proof.who ? ` (${proof.who.slice(0, 40)})` : ''}.` });
      return { ok: true, value: typeof result === 'string' ? (scrubValue(result, value) as T) : result };
    } catch (e) {
      const why = scrubValue(e instanceof Error ? e.message : 'failed', value).slice(0, 200);
      this.d.audit.add({ name, purpose, outcome: 'failed', why });
      return { ok: false, reason: why };
    } finally {
      value = '';
    }
  }

  private refuse(name: string, purpose: string, why: string): Use<never> {
    this.d.audit.add({ name, purpose, outcome: 'refused', why });
    return { ok: false, reason: why };
  }
}
