import { execFile } from 'node:child_process';
import { createHash } from 'node:crypto';
import { chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { escanorApiUrl } from './deviceMcp.js';
import { type YMap, UnsupportedYaml, parseYaml, readScalar, scalar, stringifyYaml } from './ghHostsYaml.js';
import { switchOn } from './switches.js';

/**
 * Workspace GitHub accounts: sign in to `gh` once, from any machine, and every machine of the workspace can use `gh` and `git`.
 *
 * Escanor's backend keeps each sign-in encrypted (POST /agent/device/gh-accounts, signed in with the hub agent token like
 * /agent/device/ai-accounts). This machine asks every SYNC_MS and on every hub connect, and writes what it gets into `gh`'s own
 * `hosts.yml` (Linux/macOS `~/.config/gh/hosts.yml`, Windows `%APPDATA%\GitHub CLI\hosts.yml`) as plain-file tokens, with the workspace's
 * default account active, then makes git use `gh` as its credential helper (what `gh auth setup-git` does).
 *
 * A machine's own sign-ins are never touched: a user that is already signed in here (in the file or in the keyring) keeps its login,
 * unless the workspace's copy is newer than the file. A removed account stops being written, and is taken out of the file only when the
 * file still holds exactly the token this agent wrote (never one the person made). `gh` OAuth tokens do not expire, so there is no renewal.
 * Tokens are never logged.
 */

export const SYNC_MS = 20 * 60_000;
export const RETRY_MS = 60_000;
export const MAX_RETRY_MS = 15 * 60_000;
const TIMEOUT_MS = 20_000;

type Json = Record<string, unknown>;
const isObj = (v: unknown): v is Json => !!v && typeof v === 'object' && !Array.isArray(v);
const sha = (t: string): string => createHash('sha256').update(t).digest('hex');

export function ghAccountsEnabled(env: NodeJS.ProcessEnv = process.env): boolean {
  return switchOn(env.ESCANOR_WORKSPACE_GH_ACCOUNTS, true);
}

export function ghAccountsApiUrl(env: NodeJS.ProcessEnv, hubUrl: string, opts: { managed: boolean }): string | null {
  if (opts.managed || !ghAccountsEnabled(env)) return null;
  return escanorApiUrl(env, hubUrl);
}

/** Where `gh` keeps hosts.yml on this machine. */
export function ghHostsPath(env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform, home: string = homedir()): string {
  if (env.GH_CONFIG_DIR) return join(env.GH_CONFIG_DIR, 'hosts.yml');
  if (platform === 'win32') return join(env.APPDATA || join(home, 'AppData', 'Roaming'), 'GitHub CLI', 'hosts.yml');
  return join(env.XDG_CONFIG_HOME || join(home, '.config'), 'gh', 'hosts.yml');
}

export type GhItem = {
  id: string;
  host: string;
  login: string;
  label?: string;
  version: number;
  is_default?: boolean;
  updated_at?: string | null;
  token?: string;
};
export type SyncAnswer = { kind: 'ok'; accounts: GhItem[]; removed: string[] } | { kind: 'off' } | { kind: 'retry'; reason: string };
type State = { accounts: Record<string, { host: string; login: string; version: number; sha: string }>; gitHosts: string[] };
type Run = (cmd: string, args: string[]) => Promise<{ code: number; stdout: string }>;

export const runCommand: Run = (cmd, args) =>
  new Promise((resolve) => {
    try {
      execFile(cmd, args, { timeout: 15_000, windowsHide: true, maxBuffer: 1_000_000 }, (err, stdout) => {
        const code = err ? (typeof (err as { code?: unknown }).code === 'number' ? ((err as { code: number }).code) : 1) : 0;
        resolve({ code, stdout: String(stdout ?? '') });
      });
    } catch {
      resolve({ code: 1, stdout: '' });
    }
  });

export type Opts = {
  apiUrl: string;
  hubToken: () => string;
  vmName: string;
  agentVersion: string;
  /** Where this agent remembers what it wrote (a file in its data folder). */
  stateFile: string;
  hostsFile?: string;
  fetchImpl?: typeof fetch;
  run?: Run;
  log?: (line: string) => void;
  now?: () => number;
  setTimer?: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
};

function writeAtomic(file: string, text: string): void {
  mkdirSync(dirname(file), { recursive: true, mode: 0o700 });
  const tmp = `${file}.${process.pid}.tmp`;
  writeFileSync(tmp, text, { mode: 0o600 });
  renameSync(tmp, file);
  try {
    chmodSync(file, 0o600);
  } catch {
    // not supported on this file system (Windows)
  }
}

export class GhAccounts {
  private timer: ReturnType<typeof setTimeout> | null = null;
  private inFlight: Promise<void> | null = null;
  private failures = 0;
  private stopped = false;
  private lastSay = '';

  constructor(private readonly o: Opts) {}

  private get hosts(): string {
    return this.o.hostsFile ?? ghHostsPath();
  }
  private get exec(): Run {
    return this.o.run ?? runCommand;
  }
  private say(key: string, line: string): void {
    if (key === this.lastSay) return;
    this.lastSay = key;
    (this.o.log ?? console.log)(line);
  }

  start(): void {
    this.stopped = false;
    void this.syncNow();
  }
  stop(): void {
    this.stopped = true;
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }
  private schedule(ms: number): void {
    if (this.stopped) return;
    if (this.timer) clearTimeout(this.timer);
    const t = (this.o.setTimer ?? setTimeout)(() => void this.syncNow(), ms);
    (t as { unref?: () => void }).unref?.();
    this.timer = t;
  }
  syncNow(): Promise<void> {
    if (this.stopped) return Promise.resolve();
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.run().finally(() => {
      this.inFlight = null;
    });
    return this.inFlight;
  }

  private async post(body: Json): Promise<{ status: number; body: Json | null }> {
    const res = await (this.o.fetchImpl ?? fetch)(`${this.o.apiUrl}/agent/device/gh-accounts`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.o.hubToken()}`, 'Content-Type': 'application/json', 'User-Agent': `escanor-agent/${this.o.agentVersion}` },
      body: JSON.stringify({ vm_name: this.o.vmName, agent_version: this.o.agentVersion, ...body }),
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
    let j: unknown = null;
    try {
      j = await res.json();
    } catch {
      j = null;
    }
    return { status: res.status, body: isObj(j) ? j : null };
  }

  private readState(): State {
    try {
      const j = JSON.parse(readFileSync(this.o.stateFile, 'utf8')) as unknown;
      if (isObj(j) && isObj(j.accounts)) return { accounts: j.accounts as State['accounts'], gitHosts: Array.isArray(j.gitHosts) ? j.gitHosts.filter((x): x is string => typeof x === 'string') : [] };
    } catch {
      // first run
    }
    return { accounts: {}, gitHosts: [] };
  }

  async fetchAccounts(): Promise<SyncAnswer> {
    const have: Record<string, number> = {};
    for (const [id, a] of Object.entries(this.readState().accounts)) have[id] = a.version;
    let r: { status: number; body: Json | null };
    try {
      r = await this.post({ op: 'sync', have });
    } catch (err) {
      return { kind: 'retry', reason: err instanceof Error ? err.name : 'network' };
    }
    if (r.status === 200 && r.body?.ok === true && Array.isArray(r.body.accounts)) {
      return { kind: 'ok', accounts: r.body.accounts.filter(isObj) as unknown as GhItem[], removed: Array.isArray(r.body.removed) ? r.body.removed.filter((x): x is string => typeof x === 'string') : [] };
    }
    if (r.status === 404 || r.status === 401 || r.status === 409) return { kind: 'off' };
    return { kind: 'retry', reason: `HTTP ${r.status}` };
  }

  private async run(): Promise<void> {
    const a = await this.fetchAccounts();
    if (a.kind === 'ok') {
      this.failures = 0;
      try {
        const wrote = await this.apply(a.accounts, a.removed);
        this.say('ok', `Shared GitHub accounts: ${a.accounts.length} in this workspace${wrote ? ', written for gh and git on this computer' : ''}.`);
      } catch (err) {
        this.say('apply-failed', `Shared GitHub accounts: could not write gh's hosts file (${err instanceof Error ? err.message : 'error'}); trying again later.`);
      }
      this.schedule(SYNC_MS);
    } else if (a.kind === 'off') {
      this.schedule(SYNC_MS * 3);
    } else {
      this.failures += 1;
      this.say(`retry:${a.reason}`, `Shared GitHub accounts: could not reach Escanor (${a.reason}); keeping what this machine has and trying again.`);
      this.schedule(Math.min(MAX_RETRY_MS, RETRY_MS * 2 ** Math.min(this.failures - 1, 6)));
    }
  }

  /** Writes what the workspace has into gh's hosts file. True when the file changed. */
  async apply(items: GhItem[], removed: string[]): Promise<boolean> {
    const file = this.hosts;
    const state = this.readState();
    let text = '';
    let mtime = 0;
    if (existsSync(file)) {
      text = readFileSync(file, 'utf8');
      mtime = statSync(file).mtimeMs;
    }
    let root: YMap;
    try {
      root = parseYaml(text);
    } catch (err) {
      if (err instanceof UnsupportedYaml) {
        this.say('yaml', "Shared GitHub accounts: gh's hosts file has a shape this agent does not edit, so it was left alone.");
        return false;
      }
      throw err;
    }
    const hostMap = (host: string): YMap => {
      const cur = root.get(host);
      if (cur instanceof Map) return cur;
      const m: YMap = new Map();
      root.set(host, m);
      return m;
    };
    const usersOf = (h: YMap): YMap => {
      const cur = h.get('users');
      if (cur instanceof Map) return cur;
      const m: YMap = new Map();
      h.set('users', m);
      return m;
    };
    let changed = false;
    const ours = (host: string, login: string): boolean => {
      const rec = Object.values(state.accounts).find((x) => x.host === host && x.login.toLowerCase() === login.toLowerCase());
      const entry = (root.get(host) instanceof Map ? ((root.get(host) as YMap).get('users') as YMap | undefined)?.get(login) : null) ?? null;
      const tok = entry instanceof Map ? readScalar(entry.get('oauth_token')) : null;
      return !!rec && !!tok && sha(tok) === rec.sha;
    };

    // 1. what the workspace dropped: stop writing it; take it out of the file only if the file still holds exactly what we wrote
    const gone = new Set(removed);
    for (const [id, rec] of Object.entries(state.accounts)) {
      if (!gone.has(id)) continue; // only what the workspace says it removed; merely not listed (another workspace answered?) stays as it is
      if (ours(rec.host, rec.login)) {
        const h = root.get(rec.host);
        if (h instanceof Map) {
          const users = h.get('users');
          if (users instanceof Map) users.delete(rec.login);
          if (readScalar(h.get('user')) === rec.login) {
            h.delete('user');
            h.delete('oauth_token');
          }
          changed = true;
        }
      }
      delete state.accounts[id];
    }

    // 2. what the workspace has
    const defaults: Record<string, GhItem> = {};
    for (const it of items) {
      if (typeof it.host !== 'string' || typeof it.login !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9.-]*$/.test(it.host) || !/^[A-Za-z0-9][A-Za-z0-9-]*$/.test(it.login)) continue;
      if (it.is_default) defaults[it.host] = it;
      if (typeof it.token !== 'string' || !it.token) continue; // nothing new for this one
      const users = usersOf(hostMap(it.host));
      const entry = users.get(it.login);
      const own = entry !== undefined; // the user is already signed in here (file or keyring)
      const fileToken = entry instanceof Map ? readScalar(entry.get('oauth_token')) : null;
      if (own && fileToken === it.token) {
        continue; // already the same sign-in
      }
      if (own && !ours(it.host, it.login)) {
        const stamp = it.updated_at ? Date.parse(it.updated_at) : 0;
        if (!fileToken || !(stamp > mtime)) {
          this.say(`own:${it.host}/${it.login}`, `Shared GitHub accounts: "${it.login}" is already signed in on this computer, so that sign-in is kept.`);
          continue;
        }
      }
      users.set(it.login, new Map([['oauth_token', scalar(it.token)]]));
      state.accounts[it.id] = { host: it.host, login: it.login, version: it.version, sha: sha(it.token) };
      changed = true;
    }

    // 3. the active user of each host: the workspace's default, unless this machine's own active sign-in is one it made itself
    for (const [host, d] of Object.entries(defaults)) {
      const h = root.get(host);
      if (!(h instanceof Map)) continue;
      const users = h.get('users');
      const entry = users instanceof Map ? users.get(d.login) : undefined;
      if (!(entry instanceof Map)) continue; // not written here (kept as the machine's own, or not pulled yet)
      const tok = readScalar(entry.get('oauth_token'));
      if (!tok) continue;
      const active = readScalar(h.get('user'));
      const activeIsOwn = active !== null && (ours(host, active) || active.toLowerCase() === d.login.toLowerCase());
      if (active === null || activeIsOwn) {
        if (active !== d.login) {
          h.set('user', scalar(d.login));
          changed = true;
        }
        if (readScalar(h.get('oauth_token')) !== tok) {
          h.set('oauth_token', scalar(tok));
          changed = true;
        }
      }
    }
    for (const [host, h] of root) {
      if (h instanceof Map && h.get('users') instanceof Map && (h.get('users') as YMap).size && h.get('git_protocol') === undefined && Object.values(state.accounts).some((a) => a.host === host)) {
        h.set('git_protocol', 'https');
        changed = true;
      }
    }

    if (changed) {
      if (existsSync(file) && !existsSync(`${file}.escanor-bak`)) {
        copyFileSync(file, `${file}.escanor-bak`);
        try {
          chmodSync(`${file}.escanor-bak`, 0o600);
        } catch {
          // Windows
        }
      }
      writeAtomic(file, stringifyYaml(root));
    }
    await this.setupGit(state);
    mkdirSync(dirname(this.o.stateFile), { recursive: true, mode: 0o700 });
    writeAtomic(this.o.stateFile, JSON.stringify(state));
    return changed;
  }

  /** What `gh auth setup-git` does: git asks gh for the password of each GitHub host it has an account for. */
  private async setupGit(state: State): Promise<void> {
    const hosts = [...new Set(Object.values(state.accounts).map((a) => a.host))].filter((h) => !state.gitHosts.includes(h));
    for (const host of hosts) {
      const urls = host === 'github.com' ? ['https://github.com', 'https://gist.github.com'] : [`https://${host}`];
      let all = true;
      for (const url of urls) {
        const key = `credential.${url}.helper`;
        const cur = await this.exec('git', ['config', '--global', '--get-all', key]);
        if (/gh auth git-credential/.test(cur.stdout)) continue;
        const a = await this.exec('git', ['config', '--global', '--replace-all', key, '']);
        const b = a.code === 0 ? await this.exec('git', ['config', '--global', '--add', key, '!gh auth git-credential']) : a;
        if (b.code !== 0) all = false;
      }
      if (all) state.gitHosts.push(host);
    }
  }

  /** Every account `gh` is signed in to on this machine: host, user name, whether it is the active one. Never reads a token. */
  listLocal(): { host: string; login: string; active: boolean }[] {
    if (!existsSync(this.hosts)) return [];
    let root: YMap;
    try {
      root = parseYaml(readFileSync(this.hosts, 'utf8'));
    } catch {
      return [];
    }
    const out: { host: string; login: string; active: boolean }[] = [];
    for (const [host, h] of root) {
      if (!(h instanceof Map)) continue;
      const active = readScalar(h.get('user'));
      const users = h.get('users');
      const names = users instanceof Map ? [...users.keys()] : [];
      if (active && !names.includes(active)) names.push(active);
      for (const login of names) out.push({ host, login, active: login === active });
    }
    return out;
  }

  /** "Make available on all machines": upload this machine's own gh sign-ins (read with `gh auth token`) to the workspace. */
  async share(): Promise<{ ok: true; shared: string[]; failed: string[] } | { ok: false; error: string }> {
    const local = this.listLocal();
    if (!local.length) return { ok: false, error: 'gh is not signed in on this computer, so there is nothing to share.' };
    const shared: string[] = [];
    const failed: string[] = [];
    for (const acct of local) {
      const got = await this.exec('gh', ['auth', 'token', '--hostname', acct.host, '--user', acct.login]);
      const token = got.code === 0 ? got.stdout.trim() : '';
      if (!token) {
        failed.push(acct.login);
        continue;
      }
      let r: { status: number; body: Json | null };
      try {
        r = await this.post({ op: 'import', host: acct.host, login: acct.login, label: acct.login, token, is_default: acct.active });
      } catch {
        return { ok: false, error: 'Escanor could not be reached. Try again in a moment.' };
      }
      if (r.status === 200 && r.body?.ok === true) shared.push(acct.login);
      else failed.push(acct.login);
    }
    if (shared.length) {
      this.say(`shared:${shared.join(',')}`, `Shared GitHub accounts: ${shared.length} account(s) are now available on every machine of this workspace.`);
      await this.syncNow();
    }
    return shared.length ? { ok: true, shared, failed } : { ok: false, error: 'No GitHub account could be shared.' };
  }
}
