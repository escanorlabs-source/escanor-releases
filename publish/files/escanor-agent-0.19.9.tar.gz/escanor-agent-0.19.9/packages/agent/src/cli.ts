import { spawn, spawnSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { hostname } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseEnv } from 'node:util';
import { childEnv } from './childEnv.js';
import { escanorApiUrl } from './deviceMcp.js';
import { hubTokenFrom } from './hubToken.js';
import { DEFAULT_BINDING, install as hotkeyInstall, status as hotkeyStatus, uninstall as hotkeyUninstall } from './voiceHotkey.js';
import { runCommand as runClaudeSetup, type Mode as SetupMode } from './claudeSetup.js';
import { GhAccounts, ghHostsPath } from './ghAccounts.js';
import { runVoice } from './voiceTurn.js';
import { askBridge, socketPath } from './voiceBridge.js';
import type { BridgeRequest } from './voiceAssistant.js';
import { deviceKey, ensureSshKey, gitCredential, resolveSecrets, sshPrivateKey, type Conn } from './machineApi.js';
import {
  SSH_AGENT_LIFETIME,
  credentialQuestion,
  formatCredential,
  machineSecretsEnabled,
  parseCredentialInput,
  parseEnvRunArgs,
  runScrubbed,
  setupGitHelpers,
} from './machineSecrets.js';

/**
 * `escanor-agent <command>` (bin/escanor-agent): the machine's git login, SSH key and env secrets from Escanor (VAULT3).
 *   git-credential get|store|erase    git's credential helper (git calls it; `store` and `erase` do nothing)
 *   git setup [--force]               points git at it for github.com and gitlab.com only, never over an existing helper
 *   env run [--scope S] [--names A,B] -- cmd...   runs cmd with the workspace's secrets as env vars, its output scrubbed
 *   ssh-key load                      puts this machine's SSH key into ssh-agent (memory only, 12 hours)
 * Off unless ESCANOR_MACHINE_SECRETS=1 (in the environment or the agent's .env).
 */

const agentDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const AGENT_VERSION: string = JSON.parse(readFileSync(join(agentDir, 'package.json'), 'utf8')).version;

/** The environment, plus the agent's own .env for what the environment lacks. Read into a local object: nothing is put in process.env, so no command inherits the hub token. */
function settings(): NodeJS.ProcessEnv {
  const file = process.env.ESCANOR_AGENT_ENV || join(agentDir, '.env');
  let fromFile: NodeJS.Dict<string> = {};
  try {
    if (existsSync(file)) fromFile = parseEnv(readFileSync(file, 'utf8'));
  } catch {
    fromFile = {};
  }
  return { ...fromFile, ...process.env };
}

function connection(env: NodeJS.ProcessEnv): Conn | string {
  let hubToken: string;
  try {
    hubToken = hubTokenFrom(env);
  } catch {
    return 'this machine has no hub token (HUB_TOKEN)';
  }
  const apiUrl = escanorApiUrl(env, env.HUB_URL ?? '');
  if (!apiUrl) return 'this machine is not on Escanor\'s hosted hub (set ESCANOR_API_URL to use another Escanor API)';
  return { apiUrl, hubToken, vmName: env.VM_NAME?.trim() || hostname(), agentVersion: AGENT_VERSION };
}

function readStdin(): Promise<string> {
  return new Promise((res) => {
    let s = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (d) => (s += d));
    process.stdin.on('end', () => res(s));
    process.stdin.on('error', () => res(s));
  });
}

const say = (s: string) => process.stderr.write(`escanor-agent: ${s}\n`);

async function gitCredentialCmd(action: string | undefined, env: NodeJS.ProcessEnv): Promise<number> {
  // A credential helper that cannot help stays quiet and succeeds, so git moves on to its next helper or asks the person.
  if (action !== 'get' || !machineSecretsEnabled(env)) return 0;
  const question = credentialQuestion(parseCredentialInput(await readStdin()));
  if (!question) return 0;
  const conn = connection(env);
  if (typeof conn === 'string') return say(conn), 0;
  const key = await deviceKey(conn);
  if (!key.ok) return say(key.reason), 0;
  const got = await gitCredential(conn, key.value, question);
  if (!got.ok) return say(`no git login from Escanor for ${question.host} (${got.reason})`), 0;
  process.stdout.write(formatCredential(got.value));
  return 0;
}

function gitSetupCmd(args: string[], env: NodeJS.ProcessEnv): number {
  if (!machineSecretsEnabled(env)) return say('machine secrets are off (set ESCANOR_MACHINE_SECRETS=1)'), 1;
  const binPath = join(agentDir, 'bin', 'escanor-agent');
  const results = setupGitHelpers({
    binPath,
    force: args.includes('--force'),
    git: (a) => {
      const r = spawnSync('git', a, { encoding: 'utf8' });
      return { status: r.status ?? 1, stdout: r.stdout ?? '' };
    },
  });
  for (const r of results) {
    console.log(r.action === 'set' ? `${r.host}: git now asks Escanor for the login` : `${r.host}: already has a git helper, left as is (use --force to replace it)`);
    if (r.note) console.log(`  ${r.note}`);
  }
  return 0;
}

async function envRunCmd(args: string[], env: NodeJS.ProcessEnv): Promise<number> {
  if (!machineSecretsEnabled(env)) return say('machine secrets are off (set ESCANOR_MACHINE_SECRETS=1)'), 1;
  const parsed = parseEnvRunArgs(args);
  if (!parsed) return say('usage: escanor-agent env run [--scope project:<id>] [--names A,B] -- <command...>'), 2;
  const conn = connection(env);
  if (typeof conn === 'string') return say(conn), 1;
  const key = await deviceKey(conn);
  if (!key.ok) return say(key.reason), 1;
  const got = await resolveSecrets(conn, key.value, parsed.scope, parsed.names);
  if (!got.ok) return say(`could not get the secrets (${got.reason})`), 1;
  if (got.value.missing.length) say(`not found: ${got.value.missing.join(', ')}`);
  // The command gets this process's own environment, not the agent's .env, less the hub's own variables (envWith/childEnv).
  const run = runScrubbed({
    cmd: parsed.cmd,
    secrets: got.value.values,
    baseEnv: process.env,
    out: (s) => process.stdout.write(s),
    err: (s) => process.stderr.write(s),
    onChild: (child) => {
      for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP'] as const) process.on(sig, () => child.kill(sig));
    },
  });
  return (await run).code;
}

async function sshKeyLoadCmd(env: NodeJS.ProcessEnv): Promise<number> {
  if (!machineSecretsEnabled(env)) return say('machine secrets are off (set ESCANOR_MACHINE_SECRETS=1)'), 1;
  if (!process.env.SSH_AUTH_SOCK) return say('no ssh-agent is running here (SSH_AUTH_SOCK is not set); start one with: eval "$(ssh-agent -s)"'), 1;
  const conn = connection(env);
  if (typeof conn === 'string') return say(conn), 1;
  const key = await deviceKey(conn);
  if (!key.ok) return say(key.reason), 1;
  const info = await ensureSshKey(conn, key.value);
  if (!info.ok) return say(`could not get this machine's SSH key (${info.reason})`), 1;
  const priv = await sshPrivateKey(conn, key.value);
  if (!priv.ok) return say(`could not get this machine's SSH key (${priv.reason})`), 1;
  const code = await new Promise<number>((res) => {
    const p = spawn('ssh-add', ['-t', SSH_AGENT_LIFETIME, '-'], { stdio: ['pipe', 'ignore', 'inherit'], env: childEnv(process.env) });
    p.on('error', () => (say('ssh-add is not installed'), res(127)));
    p.on('close', (c) => res(c ?? 1));
    p.stdin.on('error', () => undefined);
    p.stdin.end(priv.value.endsWith('\n') ? priv.value : `${priv.value}\n`);
  });
  if (code !== 0) return say('ssh-add did not take the key'), code;
  console.log(`SSH key ${info.value.fingerprint} loaded into ssh-agent for ${SSH_AGENT_LIFETIME} (memory only).`);
  console.log(info.value.added_to_github ? 'It is on your connected GitHub account.' : (info.value.message ?? `Public key to add where needed: ${info.value.public_key}`));
  return 0;
}

/** Where the running agent keeps its files (DATA_DIR, as the agent reads it: ./data in its own folder by default). */
function dataDirOf(env: NodeJS.ProcessEnv): string {
  return resolve(env.DATA_DIR || join(agentDir, 'data'));
}

/** `escanor-agent voice [--text "..."] [--quiet]`: one push-to-talk turn (a keyboard shortcut runs it; see voice-hotkey). */
async function voiceCmd(args: string[], env: NodeJS.ProcessEnv): Promise<number> {
  const at = args.indexOf('--text');
  const text = at >= 0 ? args.slice(at + 1).join(' ').trim() : undefined;
  if (at >= 0 && !text) return say('usage: escanor-agent voice --text "run the tests"'), 2;
  const quiet = args.includes('--quiet') || /^(0|false|off|no)$/i.test(env.ESCANOR_VOICE_SPEAK ?? '');
  return runVoice({ dataDir: dataDirOf(env), conn: connection(env), env, ...(text ? { text } : {}), speakReplies: !quiet });
}

/**
 * `escanor-agent sudo [--why "..."] -- <command...>` and `escanor-agent signin keyring|github [account]|check [--why "..."]`: ask the running
 * agent to use a saved secret. Nothing happens by itself: the owner is asked on the phone (which computer, what will happen, why) and the
 * program waits up to two minutes for their fingerprint. Nothing here ever sees a password or token; the answer is plain words or the
 * command's own output. `--from-ai` labels the request as coming from the AI in a chat, so the phone says so.
 */
async function signinCmd(cmd: 'sudo' | 'signin', args: string[], env: NodeJS.ProcessEnv): Promise<number> {
  const at = args.indexOf('--');
  const head = at >= 0 ? args.slice(0, at) : args;
  const tail = at >= 0 ? args.slice(at + 1) : [];
  let why: string | undefined;
  let source: 'ai' | 'automation' = 'automation';
  let force = false;
  const words: string[] = [];
  for (let i = 0; i < head.length; i++) {
    if (head[i] === '--why') why = head[++i];
    else if (head[i] === '--from-ai') source = 'ai';
    else if (head[i] === '--again') force = true;
    else words.push(head[i]!);
  }
  let req: BridgeRequest;
  if (cmd === 'sudo') {
    const argv = at >= 0 ? tail : words;
    if (!argv.length) return say('usage: escanor-agent sudo [--why "reason"] -- <command...>'), 2;
    req = { op: 'sudo', argv, ...(why ? { why } : {}), source };
  } else {
    const kind = words[0];
    if (kind !== 'keyring' && kind !== 'github' && kind !== 'check') return say('usage: escanor-agent signin keyring|github [account]|check [--why "reason"] [--again]'), 2;
    req = { op: 'signin', kind, ...(kind === 'github' && words[1] ? { account: words[1] } : {}), ...(why ? { why } : {}), ...(force ? { force: true } : {}), source };
  }
  try {
    const a = await askBridge(socketPath(dataDirOf(env)), req, 150_000);
    (a.ok ? console.log : (s: string) => say(s))(a.say);
    return a.ok ? 0 : 1;
  } catch {
    return say('the Escanor agent is not running on this computer, or needs its update'), 1;
  }
}

/** `escanor-agent voice-hotkey install [<Super><Alt>space] | uninstall | status`: the GNOME shortcut that runs `voice`. */
function voiceHotkeyCmd(sub: string | undefined, rest: string[], _env: NodeJS.ProcessEnv): number {
  const binPath = join(agentDir, 'bin', 'escanor-agent');
  let r: { ok: boolean; say: string };
  try {
    if (sub === 'install') r = hotkeyInstall(binPath, rest[0] ?? DEFAULT_BINDING);
    else if (sub === 'uninstall') r = hotkeyUninstall();
    else if (sub === 'status') r = hotkeyStatus();
    else return say('usage: escanor-agent voice-hotkey install [<Super><Alt>space] | uninstall | status'), 2;
  } catch (e) {
    return say(`could not change the shortcut settings (${e instanceof Error ? e.message.split('\n')[0] : 'failed'})`), 1;
  }
  console.log(r.say);
  return r.ok ? 0 : 1;
}

/** `escanor-agent claude-setup push|pull <profileDir> [--force]`: share this Claude folder's set-up with the workspace, or take the workspace's set-up into it. */
async function claudeSetupCmd(sub: string | undefined, rest: string[], env: NodeJS.ProcessEnv): Promise<number> {
  const force = rest.includes('--force');
  const dir = rest.find((r) => !r.startsWith('--'));
  if ((sub !== 'push' && sub !== 'pull') || !dir) return say('usage: escanor-agent claude-setup push|pull <profileDir> [--force]'), 2;
  const c = connection(env);
  if (typeof c === 'string') return say(c), 1;
  try {
    const r = await runClaudeSetup({ apiUrl: c.apiUrl, hubToken: () => c.hubToken, vmName: c.vmName, agentVersion: c.agentVersion }, dir, sub as SetupMode, { force });
    console.log(`${sub === 'push' ? 'Shared' : 'Pulled'}: ${(sub === 'push' ? r.pushed : r.pulled).length} file(s), ${r.removed.length} removed here, ${r.conflicts.length} in conflict (kept as they are${force ? '' : '; --force settles them'}), ${r.refused.length} not shared.`);
    for (const x of r.refused) console.log(`  not shared: ${x.path} (${x.reason})`);
    for (const x of r.conflicts) console.log(`  conflict: ${x}`);
    return r.conflicts.length && !force ? 3 : 0;
  } catch (e) {
    return say(`could not reach Escanor (${e instanceof Error ? e.message : 'failed'})`), 1;
  }
}

/** `escanor-agent gh-share`: upload this machine's `gh` sign-ins (every account, the active one as default) to the workspace, so every machine gets them. */
async function ghShareCmd(env: NodeJS.ProcessEnv): Promise<number> {
  const c = connection(env);
  if (typeof c === 'string') return say(c), 1;
  const g = new GhAccounts({ apiUrl: c.apiUrl, hubToken: () => c.hubToken, vmName: c.vmName, agentVersion: c.agentVersion, stateFile: join(resolve(env.DATA_DIR || join(agentDir, 'data')), 'gh-accounts.json'), hostsFile: ghHostsPath(env), log: () => undefined });
  const r = await g.share();
  if (!r.ok) return say(r.error), 1;
  console.log(`Shared ${r.shared.length} GitHub account(s) with the workspace: ${r.shared.join(', ')}.${r.failed.length ? ` Not shared: ${r.failed.join(', ')}.` : ''}`);
  return 0;
}

export async function main(argv: string[]): Promise<number> {
  const [cmd, sub, ...rest] = argv;
  const env = settings();
  if (cmd === 'git-credential') return gitCredentialCmd(sub, env);
  if (cmd === 'git' && sub === 'setup') return gitSetupCmd(rest, env);
  if (cmd === 'env' && sub === 'run') return envRunCmd(rest, env);
  if (cmd === 'ssh-key' && sub === 'load') return sshKeyLoadCmd(env);
  if (cmd === 'claude-setup') return claudeSetupCmd(sub, rest, env);
  if (cmd === 'gh-share') return ghShareCmd(env);
  if (cmd === 'voice') return voiceCmd([...(sub !== undefined ? [sub] : []), ...rest], env);
  if (cmd === 'voice-hotkey') return voiceHotkeyCmd(sub, rest, env);
  if (cmd === 'sudo' || cmd === 'signin') return signinCmd(cmd, [...(sub !== undefined ? [sub] : []), ...rest], env);
  say('usage: escanor-agent git-credential get | git setup [--force] | env run [--scope S] -- <cmd...> | ssh-key load | voice [--text "..."] [--quiet] | voice-hotkey install|uninstall|status | sudo [--why "..."] -- <command...> | signin keyring|github|check | claude-setup push|pull <profileDir> [--force] | gh-share');
  return 2;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).then((code) => process.exit(code), (e) => (say(e instanceof Error ? e.name : 'failed'), process.exit(1)));
}
