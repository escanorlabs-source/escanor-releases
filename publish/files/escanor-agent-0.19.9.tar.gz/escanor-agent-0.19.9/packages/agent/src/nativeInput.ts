import type { Step } from './computerControl.js';
import { keysymOfKey, parseKeys, type LiveEvent } from './liveControl.js';

/**
 * Mouse, keyboard and clipboard for remote desktop on macOS and Windows. WRITTEN AND UNIT-TESTED FOR THE COMMANDS IT BUILDS, NEVER RUN
 * ON A REAL MAC OR WINDOWS COMPUTER (none here). Linux is the tested platform (liveControl.ts).
 *
 *  - macOS: JavaScript for Automation (`osascript -l JavaScript`) calling CoreGraphics (CGEventPost). Needs the Accessibility permission
 *    for the program that runs it (System Settings, Privacy and Security, Accessibility); macOS asks once.
 *  - Windows: PowerShell calling user32 (`SetCursorPos`, `mouse_event`, `keybd_event`). Cannot reach a UAC prompt or the sign-in screen
 *    (Windows blocks input into those from a normal program).
 *
 * Typed text and the clipboard travel as base64 inside the command (base64 has no characters a shell or script could act on) and are
 * decoded by the script; they are never part of a program name or an option.
 */

export type Size = { w: number; h: number };

const b64 = (s: string) => Buffer.from(s, 'utf8').toString('base64');
const px = (v: number, max: number) => Math.round(Math.max(0, Math.min(1, v)) * Math.max(0, max - 1));

// ------------------------------------------------------------------------------------------------- macOS

/** macOS virtual key codes for the names a viewer sends (ANSI layout). */
const MAC_KEYS: Record<number, number> = {
  0xff0d: 36, 0xff09: 48, 0x20: 49, 0xff08: 51, 0xff1b: 53, 0xffff: 117, 0xff51: 123, 0xff53: 124, 0xff54: 125, 0xff52: 126, 0xff50: 115, 0xff57: 119, 0xff55: 116, 0xff56: 121,
  0xffbe: 122, 0xffbf: 120, 0xffc0: 99, 0xffc1: 118, 0xffc2: 96, 0xffc3: 97, 0xffc4: 98, 0xffc5: 100, 0xffc6: 101, 0xffc7: 109, 0xffc8: 103, 0xffc9: 111,
};
const MAC_LETTERS = 'a s d f h g z x c v _ b q w e r y t 1 2 3 4 6 5 = 9 7 - 8 0 ] o u [ i p _ l j \' k ; \\ , / n m .'.split(' ');
const MAC_MODS: Record<number, number> = { 0xffe3: 0x40000, 0xffe1: 0x20000, 0xffe9: 0x80000, 0xffeb: 0x100000 };

/** The JXA program: `run(argv)` with argv[0] = what to do, the rest numbers (or base64 text). */
export const MAC_JXA = `
ObjC.import('CoreGraphics'); ObjC.import('Foundation');
function post(e) { $.CGEventPost($.kCGHIDEventTap, e); }
function mouse(type, x, y, button) { post($.CGEventCreateMouseEvent(null, type, {x: x, y: y}, button)); }
function run(a) {
  var op = a[0], n = a.slice(1).map(Number);
  if (op === 'move') mouse($.kCGEventMouseMoved, n[0], n[1], 0);
  else if (op === 'click') { var b = n[2]; var d = [$.kCGEventLeftMouseDown, $.kCGEventRightMouseDown, $.kCGEventOtherMouseDown][b], u = [$.kCGEventLeftMouseUp, $.kCGEventRightMouseUp, $.kCGEventOtherMouseUp][b]; for (var i = 0; i < n[3]; i++) { mouse(d, n[0], n[1], b); mouse(u, n[0], n[1], b); } }
  else if (op === 'button') { var b2 = n[3]; var t = n[2] ? [$.kCGEventLeftMouseDown, $.kCGEventRightMouseDown, $.kCGEventOtherMouseDown][b2] : [$.kCGEventLeftMouseUp, $.kCGEventRightMouseUp, $.kCGEventOtherMouseUp][b2]; mouse(t, n[0], n[1], b2); }
  else if (op === 'scroll') post($.CGEventCreateScrollWheelEvent(null, 0, 2, n[0], n[1]));
  else if (op === 'key') { var e = $.CGEventCreateKeyboardEvent(null, n[0], n[1] === 1); if (n[2]) $.CGEventSetFlags(e, n[2]); post(e); }
  else if (op === 'text') { var s = ObjC.unwrap($.NSString.alloc.initWithDataEncoding($.NSData.alloc.initWithBase64EncodedStringOptions(a[1], 0), 4)); for (var k = 0; k < s.length; k++) { var ch = s.charCodeAt(k); [true, false].forEach(function (down) { var ev = $.CGEventCreateKeyboardEvent(null, 0, down); $.CGEventKeyboardSetUnicodeString(ev, 1, [ch]); post(ev); }); } }
}`;

const macRun = (...a: Array<string | number>): Step => ({ cmd: 'osascript', args: ['-l', 'JavaScript', '-e', MAC_JXA, ...a.map(String)] });

function macKey(sym: number): number | null {
  if (MAC_KEYS[sym] !== undefined) return MAC_KEYS[sym]!;
  if (sym >= 0x61 && sym <= 0x7a || sym >= 0x30 && sym <= 0x39 || sym < 0x7f) {
    const i = MAC_LETTERS.indexOf(String.fromCharCode(sym).toLowerCase());
    return i >= 0 && MAC_LETTERS[i] !== '_' ? i : null;
  }
  return null;
}

// ------------------------------------------------------------------------------------------------- Windows

const WIN_VK: Record<number, number> = {
  0xff0d: 0x0d, 0xff09: 0x09, 0x20: 0x20, 0xff08: 0x08, 0xff1b: 0x1b, 0xffff: 0x2e, 0xff63: 0x2d, 0xff51: 0x25, 0xff52: 0x26, 0xff53: 0x27, 0xff54: 0x28,
  0xff50: 0x24, 0xff57: 0x23, 0xff55: 0x21, 0xff56: 0x22, 0xffe3: 0x11, 0xffe1: 0x10, 0xffe9: 0x12, 0xffeb: 0x5b, 0xff67: 0x5d,
};
for (let i = 0; i < 12; i++) WIN_VK[0xffbe + i] = 0x70 + i;

const WIN_HEAD =
  "Add-Type -AssemblyName System.Windows.Forms; Add-Type -Namespace E -Name U -MemberDefinition '[DllImport(\"user32.dll\")] public static extern bool SetCursorPos(int x,int y); [DllImport(\"user32.dll\")] public static extern void mouse_event(uint f,uint dx,uint dy,int d,UIntPtr e); [DllImport(\"user32.dll\")] public static extern void keybd_event(byte v,byte s,uint f,UIntPtr e);'; ";
const winRun = (body: string): Step => ({ cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', WIN_HEAD + body] });
/** mouse_event flags: left down/up 2/4, right 8/16, middle 32/64, wheel 0x800, hwheel 0x1000. */
const WIN_BTN = { left: [2, 4], right: [8, 16], middle: [32, 64] } as const;

// ------------------------------------------------------------------------------------------------- one event

/** The programs that do one event on this platform; null for something it cannot do. `size` is the screen in points (macOS) or pixels (Windows). */
export function nativeSteps(platform: NodeJS.Platform, e: LiveEvent, size: Size): Step[] | null {
  if (platform === 'darwin') return macSteps(e, size);
  if (platform === 'win32') return winSteps(e, size);
  return null;
}

function macSteps(e: LiveEvent, s: Size): Step[] | null {
  const at = (x: number, y: number): [number, number] => [px(x, s.w), px(y, s.h)];
  switch (e.t) {
    case 'move': return [macRun('move', ...at(e.x, e.y))];
    case 'tap': return [macRun('click', ...at(e.x, e.y), 0, 1)];
    case 'double': return [macRun('click', ...at(e.x, e.y), 0, 2)];
    case 'right': return [macRun('click', ...at(e.x, e.y), 1, 1)];
    case 'middle': return [macRun('click', ...at(e.x, e.y), 2, 1)];
    case 'btn': return [macRun('button', ...(e.x !== undefined && e.y !== undefined ? at(e.x, e.y) : [0, 0]), e.down ? 1 : 0, e.b === 'left' ? 0 : e.b === 'right' ? 1 : 2)];
    case 'drag': {
      const [a, b] = [at(e.x, e.y), at(e.x2, e.y2)];
      return [macRun('button', a[0], a[1], 1, 0), macRun('move', b[0], b[1]), macRun('button', b[0], b[1], 0, 0)];
    }
    case 'scroll': return [macRun('scroll', -(e.dy ?? 0), -(e.dx ?? 0))];
    case 'text': return [macRun('text', b64(e.text))];
    case 'key': {
      const sym = keysymOfKey(e.key);
      if (sym === null) return null;
      if (MAC_MODS[sym] !== undefined) return null; // modifiers go with the key they modify (keys event)
      const code = macKey(sym);
      return code === null ? null : [macRun('key', code, e.down ? 1 : 0, 0)];
    }
    case 'keys': {
      const syms = parseKeys(e.keys);
      if (!syms) return null;
      let flags = 0;
      let code: number | null = null;
      for (const k of syms) {
        if (MAC_MODS[k] !== undefined) flags |= MAC_MODS[k]!;
        else code = macKey(k);
      }
      return code === null ? null : [macRun('key', code, 1, flags), macRun('key', code, 0, flags)];
    }
  }
}

function winSteps(e: LiveEvent, s: Size): Step[] | null {
  const at = (x: number, y: number) => `[E.U]::SetCursorPos(${px(x, s.w)},${px(y, s.h)}); `;
  const click = (b: 'left' | 'right' | 'middle', n: number) => `${`[E.U]::mouse_event(${WIN_BTN[b][0]},0,0,0,[UIntPtr]::Zero); [E.U]::mouse_event(${WIN_BTN[b][1]},0,0,0,[UIntPtr]::Zero); `.repeat(n)}`;
  switch (e.t) {
    case 'move': return [winRun(at(e.x, e.y))];
    case 'tap': return [winRun(at(e.x, e.y) + click('left', 1))];
    case 'double': return [winRun(at(e.x, e.y) + click('left', 2))];
    case 'right': return [winRun(at(e.x, e.y) + click('right', 1))];
    case 'middle': return [winRun(at(e.x, e.y) + click('middle', 1))];
    case 'btn': return [winRun((e.x !== undefined && e.y !== undefined ? at(e.x, e.y) : '') + `[E.U]::mouse_event(${WIN_BTN[e.b][e.down ? 0 : 1]},0,0,0,[UIntPtr]::Zero)`)];
    case 'drag': return [winRun(at(e.x, e.y) + `[E.U]::mouse_event(2,0,0,0,[UIntPtr]::Zero); ` + at(e.x2, e.y2) + `[E.U]::mouse_event(4,0,0,0,[UIntPtr]::Zero)`)];
    case 'scroll': {
      const parts: string[] = [];
      if (e.x !== undefined && e.y !== undefined) parts.push(at(e.x, e.y));
      if (e.dy) parts.push(`[E.U]::mouse_event(0x800,0,0,${Math.trunc(-e.dy) * 120},[UIntPtr]::Zero); `);
      if (e.dx) parts.push(`[E.U]::mouse_event(0x1000,0,0,${Math.trunc(e.dx) * 120},[UIntPtr]::Zero); `);
      return [winRun(parts.join(''))];
    }
    case 'text': {
      // SendKeys with every special character escaped, from text that arrives as base64.
      const body = `$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64(e.text)}')); [System.Windows.Forms.SendKeys]::SendWait(($t -replace '([{}()+^%~\\[\\]])','{$1}'))`;
      return [winRun(body)];
    }
    case 'key': {
      const sym = keysymOfKey(e.key);
      const vk = sym === null ? undefined : WIN_VK[sym] ?? (sym >= 0x61 && sym <= 0x7a ? sym - 0x20 : sym >= 0x30 && sym <= 0x39 ? sym : sym >= 0x41 && sym <= 0x5a ? sym : undefined);
      return vk === undefined ? null : [winRun(`[E.U]::keybd_event(${vk},0,${e.down ? 0 : 2},[UIntPtr]::Zero)`)];
    }
    case 'keys': {
      const syms = parseKeys(e.keys);
      if (!syms) return null;
      const vks = syms.map((k) => WIN_VK[k] ?? (k >= 0x61 && k <= 0x7a ? k - 0x20 : k >= 0x30 && k <= 0x39 ? k : k >= 0x41 && k <= 0x5a ? k : -1));
      if (vks.includes(-1)) return null;
      return [winRun(vks.map((v) => `[E.U]::keybd_event(${v},0,0,[UIntPtr]::Zero); `).join('') + [...vks].reverse().map((v) => `[E.U]::keybd_event(${v},0,2,[UIntPtr]::Zero); `).join(''))];
    }
  }
}

// ------------------------------------------------------------------------------------------------- the screen size and the clipboard

/** The screen size in the units input uses (macOS points; Windows pixels). */
export function sizeStep(platform: NodeJS.Platform): Step | null {
  if (platform === 'darwin') return { cmd: 'osascript', args: ['-e', 'tell application "Finder" to get bounds of window of desktop'] };
  if (platform === 'win32') return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', 'Add-Type -AssemblyName System.Windows.Forms; $b=[System.Windows.Forms.SystemInformation]::VirtualScreen; "$($b.Width) $($b.Height)"'] };
  return null;
}

export function parseSize(platform: NodeJS.Platform, out: string): Size | null {
  const nums = out.match(/-?\d+/g)?.map(Number) ?? [];
  if (platform === 'darwin' && nums.length >= 4) return { w: nums[2]! - nums[0]!, h: nums[3]! - nums[1]! };
  if (platform === 'win32' && nums.length >= 2) return { w: nums[0]!, h: nums[1]! };
  return null;
}

export function clipboardReadStep(platform: NodeJS.Platform): Step | null {
  if (platform === 'darwin') return { cmd: 'pbpaste', args: [] };
  if (platform === 'win32') return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', '[Console]::OutputEncoding=[Text.Encoding]::UTF8; Get-Clipboard -Raw'] };
  return null;
}

/** Text goes in as base64 inside the script, never in an option. macOS: a short JXA that sets the pasteboard. */
export function clipboardWriteStep(platform: NodeJS.Platform, text: string): Step | null {
  if (platform === 'win32') return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', `Set-Clipboard -Value ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('${b64(text)}')))`] };
  if (platform === 'darwin') {
    const js = `ObjC.import('AppKit'); function run(a) { var s = ObjC.unwrap($.NSString.alloc.initWithDataEncoding($.NSData.alloc.initWithBase64EncodedStringOptions(a[0], 0), 4)); var p = $.NSPasteboard.generalPasteboard; p.clearContents; p.setStringForType(s, $.NSPasteboardTypeString); }`;
    return { cmd: 'osascript', args: ['-l', 'JavaScript', '-e', js, b64(text)] };
  }
  return null;
}
