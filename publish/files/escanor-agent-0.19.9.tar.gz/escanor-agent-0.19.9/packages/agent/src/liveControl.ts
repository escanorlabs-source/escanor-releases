import { spawn, type ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { desktopEnv, realRunner, type Runner } from './computerControl.js';
import { atLoginScreen, isGnome, jpegSize, takeScreenshot, unlockScreen, findSession, type ScreenDeps, type Shot } from './screenControl.js';
import { keysymsOf } from './siteCredentials.js';
import { GNOME_LIVE_PY } from './liveHelper.js';
import { clipboardReadStep, clipboardWriteStep, nativeSteps, parseSize, sizeStep } from './nativeInput.js';

/**
 * Live control of the screen from the owner's phone (and the screen tools a chat's AI uses): a picture of the screen a few times a
 * second, and taps, scrolls, keys and typing sent back into the desktop.
 *
 * On GNOME (Wayland or X11) one small helper (GNOME_LIVE_PY) holds GNOME's own remote-desktop session with a screen-cast linked to
 * it: no pop-up, nothing to install, GNOME shows its screen-sharing indicator while it runs. Frames are written as one JPEG in a
 * private temporary folder (replaced in one step, so a reader never sees half a picture); input is JSON lines on the helper's
 * standard input, so typed text never appears in a program's arguments. On X11 without GNOME, xdotool does the input and the
 * usual screenshot programs the pictures.
 *
 * GNOME refuses a remote-desktop session while the screen is locked ("Session creation inhibited"), so start() unlocks the
 * person's own session first (logind) — the caller decides whether that is allowed (the phone's fingerprint yes, or the AI on a
 * computer whose Remote control is on).
 */

export { GNOME_LIVE_PY };

// ------------------------------------------------------------------------------------------------- what the phone (or the AI) may send

/** One thing to do on the screen. x and y are fractions (0..1) of the picture, so the phone never needs the real screen size. */
export type LiveEvent =
  | { t: 'tap' | 'double' | 'right' | 'middle' | 'move'; x: number; y: number }
  | { t: 'drag'; x: number; y: number; x2: number; y2: number }
  | { t: 'scroll'; x?: number; y?: number; dy?: number; dx?: number }
  | { t: 'keys'; keys: string }
  | { t: 'text'; text: string }
  /** Press or release one button (so the viewer can drag and hold like a real mouse). */
  | { t: 'btn'; b: 'left' | 'right' | 'middle'; down: boolean; x?: number; y?: number }
  /** Press or release one key (the browser's key names, or one character). */
  | { t: 'key'; key: string; down: boolean };

export const MAX_EVENTS = 20;
export const MAX_TEXT = 500;

const frac = (v: unknown): number | null => (typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= 1 ? v : null);
const steps = (v: unknown): number => (typeof v === 'number' && Number.isFinite(v) ? Math.max(-15, Math.min(15, Math.trunc(v))) : 0);

/** The events as sent, every field checked again here; an error in plain words when anything is off. */
export function parseEvents(raw: unknown): { ok: true; events: LiveEvent[] } | { ok: false; error: string } {
  if (!Array.isArray(raw) || raw.length === 0) return { ok: false, error: 'Nothing to do on the screen.' };
  if (raw.length > MAX_EVENTS) return { ok: false, error: `At most ${MAX_EVENTS} things at a time.` };
  const out: LiveEvent[] = [];
  for (const e of raw) {
    const o = (e && typeof e === 'object' ? e : {}) as Record<string, unknown>;
    switch (o.t) {
      case 'tap':
      case 'double':
      case 'right':
      case 'middle':
      case 'move': {
        const x = frac(o.x);
        const y = frac(o.y);
        if (x === null || y === null) return { ok: false, error: 'A tap needs a place on the screen.' };
        out.push({ t: o.t, x, y });
        break;
      }
      case 'drag': {
        const [x, y, x2, y2] = [frac(o.x), frac(o.y), frac(o.x2), frac(o.y2)];
        if (x === null || y === null || x2 === null || y2 === null) return { ok: false, error: 'A drag needs where it starts and ends.' };
        out.push({ t: 'drag', x, y, x2, y2 });
        break;
      }
      case 'scroll': {
        const dy = steps(o.dy);
        const dx = steps(o.dx);
        if (!dy && !dx) return { ok: false, error: 'A scroll needs a direction.' };
        const x = frac(o.x);
        const y = frac(o.y);
        out.push({ t: 'scroll', dy, dx, ...(x !== null && y !== null ? { x, y } : {}) });
        break;
      }
      case 'keys': {
        if (typeof o.keys !== 'string' || !parseKeys(o.keys)) return { ok: false, error: `Unknown keys "${String(o.keys).slice(0, 30)}".` };
        out.push({ t: 'keys', keys: o.keys });
        break;
      }
      case 'text': {
        if (typeof o.text !== 'string' || !o.text) return { ok: false, error: 'Nothing to type.' };
        if (o.text.length > MAX_TEXT) return { ok: false, error: `At most ${MAX_TEXT} letters at a time.` };
        out.push({ t: 'text', text: o.text });
        break;
      }
      case 'btn': {
        if (o.b !== 'left' && o.b !== 'right' && o.b !== 'middle') return { ok: false, error: 'Unknown mouse button.' };
        if (typeof o.down !== 'boolean') return { ok: false, error: 'A button is pressed or let go.' };
        const x = frac(o.x);
        const y = frac(o.y);
        out.push({ t: 'btn', b: o.b, down: o.down, ...(x !== null && y !== null ? { x, y } : {}) });
        break;
      }
      case 'key': {
        if (typeof o.down !== 'boolean') return { ok: false, error: 'A key is pressed or let go.' };
        if (typeof o.key !== 'string' || keysymOfKey(o.key) === null) return { ok: false, error: 'Unknown key.' };
        out.push({ t: 'key', key: o.key, down: o.down });
        break;
      }
      default:
        return { ok: false, error: 'That is not something the screen can be told to do.' };
    }
  }
  return { ok: true, events: out };
}

/** X keysyms by the names the app and the AI use. */
const NAMED: Record<string, number> = {
  ctrl: 0xffe3, control: 0xffe3, alt: 0xffe9, shift: 0xffe1, super: 0xffeb, win: 0xffeb, meta: 0xffeb, cmd: 0xffeb,
  enter: 0xff0d, return: 0xff0d, esc: 0xff1b, escape: 0xff1b, tab: 0xff09, backspace: 0xff08, delete: 0xffff, del: 0xffff, insert: 0xff63,
  up: 0xff52, down: 0xff54, left: 0xff51, right: 0xff53, home: 0xff50, end: 0xff57, pageup: 0xff55, pagedown: 0xff56, space: 0x20,
  printscreen: 0xff61, menu: 0xff67,
  volumeup: 0x1008ff13, volumedown: 0x1008ff11, mute: 0x1008ff12, playpause: 0x1008ff14, next: 0x1008ff17, previous: 0x1008ff16,
  plus: 0x2b, minus: 0x2d,
};
for (let i = 1; i <= 12; i++) NAMED[`f${i}`] = 0xffbe + i - 1;

/** xdotool's names for the same keys (X11 without GNOME). */
const XDO: Record<number, string> = {
  0xffe3: 'ctrl', 0xffe9: 'alt', 0xffe1: 'shift', 0xffeb: 'super', 0xff0d: 'Return', 0xff1b: 'Escape', 0xff09: 'Tab', 0xff08: 'BackSpace',
  0xffff: 'Delete', 0xff63: 'Insert', 0xff52: 'Up', 0xff54: 'Down', 0xff51: 'Left', 0xff53: 'Right', 0xff50: 'Home', 0xff57: 'End',
  0xff55: 'Prior', 0xff56: 'Next', 0x20: 'space', 0xff61: 'Print', 0xff67: 'Menu', 0x1008ff13: 'XF86AudioRaiseVolume',
  0x1008ff11: 'XF86AudioLowerVolume', 0x1008ff12: 'XF86AudioMute', 0x1008ff14: 'XF86AudioPlay', 0x1008ff17: 'XF86AudioNext',
  0x1008ff16: 'XF86AudioPrev', 0x2b: 'plus', 0x2d: 'minus',
};

/** The browser's `KeyboardEvent.key` names for the same keys. */
const BROWSER_KEYS: Record<string, number> = {
  arrowup: 0xff52, arrowdown: 0xff54, arrowleft: 0xff51, arrowright: 0xff53, ' ': 0x20, os: 0xffeb, capslock: 0xffe5, altgraph: 0xfe03,
  numlock: 0xff7f, scrolllock: 0xff14, pause: 0xff13, contextmenu: 0xff67, clear: 0xff0b,
};

/** The keysym for one key as a browser or phone names it ("ArrowUp", "Enter", "a", "é"); null for a name this does not know. */
export function keysymOfKey(key: string): number | null {
  const lower = key.toLowerCase();
  if (BROWSER_KEYS[lower] !== undefined) return BROWSER_KEYS[lower]!;
  if (key.length > 1 && NAMED[lower] !== undefined) return NAMED[lower]!;
  const chars = [...key];
  if (chars.length !== 1) return null;
  const cp = chars[0]!.codePointAt(0)!;
  if (cp < 0x20 || cp === 0x7f || (cp >= 0x80 && cp < 0xa0)) return null;
  if (cp <= 0xff) return cp;
  return cp <= 0x10ffff ? 0x01000000 + cp : null;
}

/** "ctrl+shift+t" → keysyms pressed together, or null for a name this does not know. At most 5 keys. */
export function parseKeys(s: string): number[] | null {
  const parts = s.trim().toLowerCase().split('+').map((p) => p.trim());
  if (!parts.length || parts.length > 5 || parts.some((p) => !p)) return s.trim() === '+' ? [0x2b] : null;
  const out: number[] = [];
  for (const p of parts) {
    if (NAMED[p] !== undefined) out.push(NAMED[p]);
    else if (p.length === 1 && p >= ' ' && p <= '~') out.push(p.codePointAt(0)!);
    else return null;
  }
  return out;
}

const xdoKey = (syms: number[]): string => syms.map((k) => XDO[k] ?? (k >= 0xffbe && k <= 0xffc9 ? `F${k - 0xffbe + 1}` : String.fromCodePoint(k))).join('+');

/** What the safety log says about a batch: never the typed text itself. */
export function describeEvents(events: LiveEvent[]): string {
  const parts = events.map((e) => (e.t === 'text' ? `typed ${[...e.text].length} characters` : e.t === 'keys' ? `pressed ${e.keys.slice(0, 30)}` : e.t === 'key' ? 'used the keyboard' : e.t === 'btn' ? (e.down ? 'pressed a mouse button' : 'let go of a mouse button') : e.t === 'scroll' ? 'scrolled' : e.t === 'move' ? 'moved the pointer' : e.t === 'drag' ? 'dragged' : e.t === 'right' ? 'right-clicked' : e.t === 'double' ? 'double-clicked' : e.t === 'middle' ? 'middle-clicked' : 'clicked'));
  return [...new Set(parts)].join(', ');
}

// ------------------------------------------------------------------------------------------------- is the screen locked

/** True when the person's desktop is locked (GNOME's screen shield, else logind's LockedHint), or nobody is signed in (the login screen). */
export async function screenLocked(d: ScreenDeps = {}): Promise<boolean> {
  const platform = d.platform ?? process.platform;
  if (platform !== 'linux') return false;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  const g = await run({ cmd: 'gdbus', args: ['call', '--session', '--dest', 'org.gnome.ScreenSaver', '--object-path', '/org/gnome/ScreenSaver', '--method', 'org.gnome.ScreenSaver.GetActive'] }, env);
  if (g.code === 0 && /\((true|false),?\)/.test(g.stdout)) return g.stdout.includes('true');
  const session = await findSession(run, env, d.uid === undefined ? (typeof process.getuid === 'function' ? process.getuid() : null) : d.uid);
  if (!session) {
    // No desktop session: the login screen after a restart is locked too, not "Unlocked".
    const list = await run({ cmd: 'loginctl', args: ['list-sessions', '--no-legend'] }, env);
    return atLoginScreen(list.stdout);
  }
  const r = await run({ cmd: 'loginctl', args: ['show-session', session, '-p', 'LockedHint'] }, env);
  return r.code === 0 && /LockedHint=yes/.test(r.stdout);
}

/** Unlock when locked, and wait until the desktop really is (GNOME needs a moment). Says whether it had to. */
export async function ensureUnlocked(d: ScreenDeps = {}): Promise<{ ok: boolean; unlocked: boolean; say?: string }> {
  if (!(await screenLocked(d))) return { ok: true, unlocked: false };
  const r = await unlockScreen(d);
  if (!r.ok) return { ok: false, unlocked: false, say: r.say };
  const sleep = d.sleep ?? ((ms: number) => new Promise<void>((res) => setTimeout(res, ms)));
  for (let i = 0; i < 20; i++) {
    await sleep(250);
    if (!(await screenLocked(d))) return { ok: true, unlocked: true };
  }
  return { ok: false, unlocked: false, say: 'Asked the screen to unlock, but it is still locked.' };
}

// ------------------------------------------------------------------------------------------------- the helper

/** One monitor as GNOME lists it. */
export type MonitorInfo = { id: string; name: string; w: number; h: number; primary: boolean };

/** The helper's monitor list with every field checked (it is passed on to the viewer). */
export function cleanMonitors(v: unknown): MonitorInfo[] {
  if (!Array.isArray(v)) return [];
  const out: MonitorInfo[] = [];
  for (const m of v.slice(0, 8)) {
    const o = (m && typeof m === 'object' ? m : {}) as Record<string, unknown>;
    if (typeof o.id !== 'string' || !/^[A-Za-z0-9._:-]{1,40}$/.test(o.id)) continue;
    out.push({
      id: o.id,
      name: typeof o.name === 'string' ? o.name.replace(/[\u0000-\u001f]/g, ' ').slice(0, 60) : o.id,
      w: Number.isFinite(o.w) ? Number(o.w) : 0,
      h: Number.isFinite(o.h) ? Number(o.h) : 0,
      primary: o.primary === true,
    });
  }
  return out;
}

/** The running helper, as LiveScreen sees it (replaceable in tests). */
export type HelperProc = {
  /** One JSON line to the helper. */
  write(line: string): void;
  /** Each JSON line the helper prints. */
  onLine(cb: (o: Record<string, unknown>) => void): void;
  onExit(cb: () => void): void;
  /** Each picture the helper sends on its private pipe (a JPEG, and whether it is the sharp one sent when the screen is still). */
  onFrame?(cb: (jpeg: Buffer, sharp: boolean) => void): void;
  kill(): void;
};
export type HelperOptions = { /** Which monitor (its connector name, like "eDP-1"); empty = the main one. */ monitor?: string };
export type HelperSpawner = (dir: string, width: number, gapSeconds: number, env: NodeJS.ProcessEnv, opts?: HelperOptions) => HelperProc | null;

/** The pictures on the helper's private pipe: 4 bytes length (big endian), 1 byte flags (1 = sharp), the JPEG. Exported for tests. */
export class FrameReader {
  private buf: Buffer = Buffer.alloc(0);
  constructor(private cb: (jpeg: Buffer, sharp: boolean) => void, private max = 4_000_000) {}
  push(chunk: Buffer): void {
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    for (;;) {
      if (this.buf.length < 5) return;
      const n = this.buf.readUInt32BE(0);
      if (n === 0 || n > this.max) {
        // Not a picture length: the pipe is out of step. Start over rather than guess.
        this.buf = Buffer.alloc(0);
        return;
      }
      if (this.buf.length < 5 + n) return;
      const sharp = this.buf[4] === 1;
      const jpeg = this.buf.subarray(5, 5 + n);
      this.buf = this.buf.subarray(5 + n);
      if (jpeg[0] === 0xff && jpeg[1] === 0xd8) this.cb(Buffer.from(jpeg), sharp);
    }
  }
}

export const realHelper: HelperSpawner = (dir, width, gap, env, opts) => {
  let child: ChildProcess;
  try {
    child = spawn('python3', ['-I', '-c', GNOME_LIVE_PY, dir, String(width), String(gap), opts?.monitor ?? '', 'pipe'], { env, stdio: ['pipe', 'pipe', 'ignore', 'pipe'], windowsHide: true });
  } catch {
    return null;
  }
  const frames: Array<(jpeg: Buffer, sharp: boolean) => void> = [];
  const reader = new FrameReader((j, sh) => {
    for (const cb of frames) cb(j, sh);
  });
  (child.stdio[3] as NodeJS.ReadableStream | null)?.on('data', (c: Buffer) => reader.push(c));
  (child.stdio[3] as NodeJS.ReadableStream | null)?.on('error', () => {});
  const lines: Array<(o: Record<string, unknown>) => void> = [];
  const exits: Array<() => void> = [];
  let buf = '';
  child.stdout?.setEncoding('utf8');
  child.stdout?.on('data', (s: string) => {
    buf += s;
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i);
      buf = buf.slice(i + 1);
      try {
        const o = JSON.parse(line) as Record<string, unknown>;
        for (const cb of lines) cb(o);
      } catch {
        /* not ours */
      }
    }
  });
  child.stdin?.on('error', () => {});
  child.on('error', () => {});
  child.once('exit', () => {
    for (const cb of exits) cb();
  });
  return {
    write: (line) => {
      try {
        child.stdin?.write(`${line}\n`);
      } catch {
        /* gone */
      }
    },
    onLine: (cb) => void lines.push(cb),
    onExit: (cb) => void exits.push(cb),
    onFrame: (cb) => void frames.push(cb),
    kill: () => {
      try {
        child.stdin?.end(`${JSON.stringify({ t: 'stop' })}\n`);
      } catch {
        /* gone */
      }
      const t = setTimeout(() => {
        try {
          child.kill('SIGTERM');
        } catch {
          /* gone */
        }
      }, 1500);
      t.unref();
    },
  };
};

export type LiveDeps = ScreenDeps & {
  helper?: HelperSpawner;
  /** Picture width sent to the phone. */
  width?: number;
  /** Seconds between pictures at most. */
  gap?: number;
  /** May start() unlock a locked screen? (true after a fingerprint yes, or for the AI where Remote control is on). */
  unlock?: boolean;
};

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** One live session on the screen: start, pictures, input, stop. */
export class LiveScreen {
  private proc: HelperProc | null = null;
  private dir: string | null = null;
  private size: { w: number; h: number } | null = null;
  private acks: Array<() => void> = [];
  private mode: 'gnome' | 'x11' | 'native' | null = null;
  private monitorWanted = '';
  private monitorList: MonitorInfo[] = [];
  private monitorNow = '';
  private clipboardOk = false;
  private frameCbs = new Set<(jpeg: Buffer, sharp: boolean) => void>();
  private eventCbs = new Set<(o: Record<string, unknown>) => void>();
  private clipWaiting = new Map<string, (text: string | null) => void>();
  private clipSeq = 0;

  constructor(private d: LiveDeps = {}) {}

  /** Pictures from the helper's pipe as they come (GNOME only). Returns how to stop listening. */
  onFrame(cb: (jpeg: Buffer, sharp: boolean) => void): () => void {
    this.frameCbs.add(cb);
    return () => void this.frameCbs.delete(cb);
  }

  /** What the helper says about the session: `monitors`, `locked`, `kill` (the Stop button on the notice), `closed`. */
  onEvent(cb: (o: Record<string, unknown>) => void): () => void {
    this.eventCbs.add(cb);
    return () => void this.eventCbs.delete(cb);
  }

  get monitors(): MonitorInfo[] {
    return this.monitorList;
  }
  get monitor(): string {
    return this.monitorNow;
  }
  get hasClipboard(): boolean {
    return this.clipboardOk || this.mode === 'native';
  }

  private async clipNative(): Promise<string | null> {
    const step = clipboardReadStep(this.d.platform ?? process.platform);
    if (!step) return null;
    const r = await (this.d.run ?? realRunner)(step, this.env());
    return r.code === 0 ? r.stdout.slice(0, 100_000) : null;
  }
  get kind(): 'gnome' | 'x11' | 'native' | null {
    return this.mode;
  }

  /** Change the picture size and quality (GNOME): width, JPEG quality, minimum seconds between pictures, and the sharp picture's size and quality. */
  setQuality(p: { width?: number; q?: number; gap?: number; refW?: number; refQ?: number; refine?: boolean }): void {
    this.proc?.write(JSON.stringify({ t: 'quality', nr: 1, ...p }));
  }

  /** The computer's clipboard text (null when it has none or cannot be read). */
  clipGet(waitMs = 4000): Promise<string | null> {
    if (this.mode === 'native') return this.clipNative();
    const p = this.proc;
    if (!p || !this.clipboardOk) return Promise.resolve(null);
    const id = `c${++this.clipSeq}`;
    return new Promise((resolve) => {
      const t = setTimeout(() => {
        this.clipWaiting.delete(id);
        resolve(null);
      }, waitMs);
      this.clipWaiting.set(id, (text) => {
        clearTimeout(t);
        resolve(text);
      });
      p.write(JSON.stringify({ t: 'clip_get', id }));
    });
  }

  /** Put text on the computer's clipboard. */
  clipSet(text: string): boolean {
    if (this.mode === 'native') {
      const step = clipboardWriteStep(this.d.platform ?? process.platform, text);
      if (step) void (this.d.run ?? realRunner)(step, this.env());
      return step !== null;
    }
    if (!this.proc || !this.clipboardOk) return false;
    this.proc.write(JSON.stringify({ t: 'clip_set', nr: 1, text }));
    return true;
  }

  /** The "being viewed" notice on the computer, with a Stop button (GNOME). */
  banner(title: string, body: string): void {
    this.proc?.write(JSON.stringify({ t: 'banner', nr: 1, title, body }));
  }

  /** Show another monitor: the session restarts on it. */
  async switchMonitor(id: string): Promise<{ ok: boolean; say: string }> {
    if (this.mode !== 'gnome') return { ok: false, say: 'This computer can only show its whole screen.' };
    if (this.monitorList.length && !this.monitorList.some((m) => m.id === id)) return { ok: false, say: 'That monitor is not connected.' };
    const old = this.proc;
    this.monitorWanted = id;
    if (old) {
      this.proc = null;
      this.size = null;
      old.kill();
      await (this.d.sleep ?? wait)(500);
    }
    const r = await this.start();
    return r.ok ? { ok: true, say: 'Showing that monitor.' } : { ok: false, say: r.say };
  }

  get running(): boolean {
    return this.mode === 'x11' || this.mode === 'native' || (this.proc !== null && this.size !== null);
  }

  private env() {
    const platform = this.d.platform ?? process.platform;
    return desktopEnv(this.d.env ?? process.env, platform);
  }

  /** Starts the session (unlocking first when allowed). Already running: nothing to do. */
  async start(): Promise<{ ok: true; unlocked: boolean } | { ok: false; say: string; code?: 'locked' }> {
    if (this.running) return { ok: true, unlocked: false };
    const platform = this.d.platform ?? process.platform;
    if (platform === 'darwin' || platform === 'win32') {
      // macOS and Windows: pictures by the screenshot program, input by nativeInput.ts (written, never run on a real Mac or Windows PC).
      const step = sizeStep(platform);
      const r = step ? await (this.d.run ?? realRunner)(step, this.env()) : null;
      const size = r && r.code === 0 ? parseSize(platform, r.stdout) : null;
      if (!size) return { ok: false, say: 'Could not read this screen\'s size, so live control cannot start here.' };
      this.size = size;
      this.mode = 'native';
      return { ok: true, unlocked: false };
    }
    if (platform !== 'linux') return { ok: false, say: 'Live control works on Linux, macOS and Windows. Pictures of the screen still work here.' };
    let unlocked = false;
    if (this.d.unlock !== false) {
      const u = await ensureUnlocked(this.d);
      if (!u.ok) return { ok: false, say: u.say ?? 'The screen is locked and could not be unlocked.' };
      unlocked = u.unlocked;
    } else if (await screenLocked(this.d)) {
      return { ok: false, say: 'The screen is locked.', code: 'locked' };
    }
    const env = this.env();
    if (!isGnome(env)) {
      // X11 without GNOME: xdotool for input, the usual programs for pictures.
      if (!env.DISPLAY) return { ok: false, say: 'Live control here needs GNOME, or X11 with xdotool.' };
      const r = await (this.d.run ?? realRunner)({ cmd: 'xdotool', args: ['getdisplaygeometry'] }, env);
      const m = r.stdout.trim().match(/^(\d+)\s+(\d+)/);
      if (r.code !== 0 || !m) return { ok: false, say: 'Live control here needs xdotool (sudo apt install xdotool).' };
      this.size = { w: Number(m[1]), h: Number(m[2]) };
      this.mode = 'x11';
      return { ok: true, unlocked };
    }
    // GNOME may still refuse for a moment right after an unlock: try a few times.
    for (let attempt = 0; attempt < 4; attempt++) {
      const r = await this.spawnGnome(env);
      if (r === 'ready') return { ok: true, unlocked };
      if (r === 'missing') return { ok: false, say: 'Live control needs python3 with GObject and GStreamer\'s PipeWire plugin (installed with Ubuntu\'s desktop).' };
      await (this.d.sleep ?? wait)(700);
    }
    return { ok: false, say: 'The screen would not start sharing. If it is locked, unlock it and try again.' };
  }

  private spawnGnome(env: NodeJS.ProcessEnv): Promise<'ready' | 'refused' | 'missing'> {
    this.dir ??= mkdtempSync(join(this.d.tmp ?? tmpdir(), 'escanor-live-'));
    const p = (this.d.helper ?? realHelper)(this.dir, this.d.width ?? 1280, this.d.gap ?? 0.3, env, { monitor: this.monitorWanted });
    if (!p) return Promise.resolve('missing');
    p.onFrame?.((j, sharp) => {
      if (this.proc === p) for (const cb of this.frameCbs) cb(j, sharp);
    });
    return new Promise((resolve) => {
      let settled = false;
      const done = (v: 'ready' | 'refused' | 'missing') => {
        if (settled) return;
        settled = true;
        clearTimeout(t);
        resolve(v);
      };
      const t = setTimeout(() => {
        p.kill();
        done('refused');
      }, 8000);
      p.onLine((o) => {
        if (o.event === 'ready') {
          this.proc = p;
          this.size = { w: Number(o.width) || 0, h: Number(o.height) || 0 };
          this.mode = 'gnome';
          this.monitorNow = typeof o.monitor === 'string' ? o.monitor : '';
          this.clipboardOk = o.clipboard === true;
          done('ready');
        } else if (o.event === 'error') done('refused');
        else if (o.event === 'done') this.acks.shift()?.();
        else if (o.event === 'closed') this.drop(p);
        else if (o.event === 'clip') {
          const id = typeof o.id === 'string' ? o.id : '';
          const w = this.clipWaiting.get(id);
          this.clipWaiting.delete(id);
          w?.(typeof o.text === 'string' ? o.text : null);
          return;
        } else if (o.event === 'monitors') this.monitorList = cleanMonitors(o.list);
        if (this.proc === p || o.event === 'ready') for (const cb of this.eventCbs) cb(o);
      });
      p.onExit(() => {
        this.drop(p);
        done('refused');
      });
    });
  }

  private drop(p: HelperProc) {
    if (this.proc !== p) return;
    this.proc = null;
    this.size = null;
    for (const a of this.acks.splice(0)) a();
    for (const [, w] of this.clipWaiting) w(null);
    this.clipWaiting.clear();
    for (const cb of this.eventCbs) cb({ event: 'closed' });
  }

  /** The newest picture, waiting up to `waitMs` for the first one. */
  async frame(waitMs = 3000): Promise<Shot | null> {
    if (this.mode === 'x11' || this.mode === 'native') {
      const r = await takeScreenshot(this.d);
      return r.ok ? r.shot : null;
    }
    const end = Date.now() + waitMs;
    for (;;) {
      const s = this.readFrame();
      if (s || Date.now() >= end || !this.proc) return s;
      await wait(100);
    }
  }

  /**
   * The first picture taken at least `afterMs` after `since` (so it shows what a tap or a key just did), waiting up to `waitMs`;
   * the newest one when none comes (nothing on the screen changed).
   */
  async frameAfter(since: number, afterMs = 250, waitMs = 1500): Promise<Shot | null> {
    if (this.mode === 'x11' || this.mode === 'native' || !this.dir) return this.frame();
    const file = join(this.dir, 'frame.jpg');
    const end = Date.now() + waitMs;
    while (Date.now() < end && this.proc) {
      try {
        if (statSync(file).mtimeMs >= since + afterMs) break;
      } catch {
        /* not yet */
      }
      await wait(60);
    }
    return this.frame();
  }

  private readFrame(): Shot | null {
    if (!this.dir) return null;
    try {
      const buf = readFileSync(join(this.dir, 'frame.jpg'));
      const dim = jpegSize(buf);
      return dim ? { b64: buf.toString('base64'), mime: 'image/jpeg', width: dim.width, height: dim.height, bytes: buf.length } : null;
    } catch {
      return null;
    }
  }

  /** The real screen size (pixels), once started. */
  get screenSize(): { w: number; h: number } | null {
    return this.size;
  }

  /** Do the events in order. Resolves when the desktop has taken them (or after a few seconds at most). */
  async send(events: LiveEvent[], opts: { fast?: boolean } = {}): Promise<{ ok: boolean; say: string }> {
    if (this.mode === 'x11') return this.sendX11(events);
    if (this.mode === 'native') return this.sendNative(events);
    const p = this.proc;
    if (!p) return { ok: false, say: 'The live view is not running.' };
    if (opts.fast) {
      // Live control from a viewer: the events go straight on, nothing waits for them.
      for (const e of events) {
        const line = toHelper(e);
        if (line) p.write(JSON.stringify({ ...line, nr: 1 }));
      }
      return { ok: true, say: describeEvents(events) };
    }
    const pending: Promise<void>[] = [];
    for (const e of events) {
      const line = toHelper(e);
      if (!line) continue;
      pending.push(new Promise<void>((res) => this.acks.push(res)));
      p.write(JSON.stringify(line));
    }
    await Promise.race([Promise.all(pending), wait(3000 + events.length * 500)]);
    return { ok: true, say: describeEvents(events) };
  }

  private async sendNative(events: LiveEvent[]): Promise<{ ok: boolean; say: string }> {
    const platform = this.d.platform ?? process.platform;
    const run = this.d.run ?? realRunner;
    for (const e of events) {
      const steps = nativeSteps(platform, e, this.size!);
      if (!steps) continue;
      for (const st of steps) {
        const r = await run(st, this.env());
        if (r.code !== 0) return { ok: false, say: platform === 'darwin' ? 'Could not do that. macOS needs the Accessibility permission for Escanor (System Settings, Privacy and Security).' : 'Could not do that on this Windows computer.' };
      }
    }
    return { ok: true, say: describeEvents(events) };
  }

  private async sendX11(events: LiveEvent[]): Promise<{ ok: boolean; say: string }> {
    const run = this.d.run ?? realRunner;
    const env = this.env();
    const s = this.size!;
    const px = (x: number, y: number) => [String(Math.round(x * (s.w - 1))), String(Math.round(y * (s.h - 1)))];
    for (const e of events) {
      let args: string[] | null = null;
      if (e.t === 'move') args = ['mousemove', ...px(e.x, e.y)];
      else if (e.t === 'tap' || e.t === 'double' || e.t === 'right' || e.t === 'middle') args = ['mousemove', ...px(e.x, e.y), 'click', ...(e.t === 'double' ? ['--repeat', '2'] : []), e.t === 'right' ? '3' : e.t === 'middle' ? '2' : '1'];
      else if (e.t === 'drag') args = ['mousemove', ...px(e.x, e.y), 'mousedown', '1', 'mousemove', ...px(e.x2, e.y2), 'mouseup', '1'];
      else if (e.t === 'scroll') args = [...(e.x !== undefined && e.y !== undefined ? ['mousemove', ...px(e.x, e.y)] : []), 'click', '--repeat', String(Math.abs(e.dy || e.dx || 1)), e.dy ? (e.dy > 0 ? '5' : '4') : (e.dx ?? 0) > 0 ? '7' : '6'];
      else if (e.t === 'keys') args = ['key', '--clearmodifiers', xdoKey(parseKeys(e.keys) ?? [])];
      else if (e.t === 'text') {
        // Text goes on standard input, never in the arguments.
        const ok = await new Promise<boolean>((res) => {
          try {
            const c = spawn('xdotool', ['type', '--clearmodifiers', '--file', '-'], { env, stdio: ['pipe', 'ignore', 'ignore'] });
            c.on('error', () => res(false));
            c.on('close', (code) => res(code === 0));
            c.stdin?.end(e.text);
          } catch {
            res(false);
          }
        });
        if (!ok) return { ok: false, say: 'Could not type here (xdotool).' };
        continue;
      }
      if (args) {
        const r = await run({ cmd: 'xdotool', args }, env);
        if (r.code !== 0) return { ok: false, say: 'Could not do that here (xdotool).' };
      }
    }
    return { ok: true, say: describeEvents(events) };
  }

  stop(): void {
    const p = this.proc;
    this.proc = null;
    this.size = null;
    this.mode = null;
    this.monitorWanted = '';
    this.monitorList = [];
    this.clipboardOk = false;
    for (const a of this.acks.splice(0)) a();
    for (const [, w] of this.clipWaiting) w(null);
    this.clipWaiting.clear();
    p?.kill();
    if (this.dir) {
      const dir = this.dir;
      this.dir = null;
      // The private temporary folder this session made, after the helper has let go of it.
      setTimeout(() => {
        try {
          rmSync(dir, { recursive: true, force: true });
        } catch {
          /* temp is cleaned anyway */
        }
      }, 2000).unref();
    }
  }
}

/** What the GNOME helper is sent for one event (text and keys as keysyms). */
export function toHelper(e: LiveEvent): Record<string, unknown> | null {
  switch (e.t) {
    case 'keys': {
      const syms = parseKeys(e.keys);
      return syms ? { t: 'combo', syms } : null;
    }
    case 'text': {
      const syms = [...e.text].length <= MAX_TEXT ? keysymsAll(e.text) : [];
      return syms.length ? { t: 'type', syms } : null;
    }
    case 'key': {
      const sym = keysymOfKey(e.key);
      return sym === null ? null : { t: 'key', sym, down: e.down };
    }
    default:
      return { ...e };
  }
}

/** keysymsOf works on 256 characters at a time; typed text can be longer. */
function keysymsAll(text: string): number[] {
  const out: number[] = [];
  const chars = [...text];
  for (let i = 0; i < chars.length; i += 200) out.push(...keysymsOf(chars.slice(i, i + 200).join('')));
  return out;
}
