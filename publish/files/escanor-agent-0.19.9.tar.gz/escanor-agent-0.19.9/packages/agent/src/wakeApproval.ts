import { verifySignature, type KeyStore } from './jarvisKeys.js';
import type { AccountTrust } from './accountTrust.js';

/**
 * Waking another computer on this network (Wake-on-LAN) only after the owner's fingerprint. The hub passes the phone's signed yes along
 * with the wake-up; this machine (the one that sends the magic packet) checks it itself, with the phones paired here or with the
 * person's account, and sends nothing when it is missing, wrong, old or used before. The hub cannot make this machine wake anything.
 *
 * The phone signs `escanor-jarvis-v1|wake|<target>:<expiresAt>|<nonce>|<target>` after a fresh fingerprint or face check; `target` is the
 * machine being woken (its id on the hub). The yes is good for two minutes at most and once.
 */

export const WAKE_MAX_MS = 2 * 60_000;
const NONCE = /^[A-Za-z0-9_-]{8,64}$/;
const TARGET = /^[A-Za-z0-9_-]{1,100}$/;
const KEY_ID = /^[0-9a-f]{16}$/;

export type WakeOk = { ok: true; who: string };
export type WakeNo = { ok: false; why: string };

export class WakeApprovals {
  private used = new Map<string, number>();

  constructor(private d: { keys: KeyStore; account?: AccountTrust; now?: () => number }) {}

  private now = () => (this.d.now ?? Date.now)();

  async check(target: unknown, approval: unknown): Promise<WakeOk | WakeNo> {
    const o = (approval && typeof approval === 'object' && !Array.isArray(approval) ? approval : null) as Record<string, unknown> | null;
    if (!o) return { ok: false, why: 'No fingerprint approval came with the wake-up.' };
    const { keyId, signature, nonce, expiresAt } = o;
    if (typeof target !== 'string' || !TARGET.test(target) || typeof keyId !== 'string' || !KEY_ID.test(keyId) || typeof signature !== 'string' || typeof nonce !== 'string' || !NONCE.test(nonce) || typeof expiresAt !== 'number' || !Number.isFinite(expiresAt)) {
      return { ok: false, why: 'The approval that came with the wake-up was not in the right form.' };
    }
    const now = this.now();
    if (expiresAt <= now) return { ok: false, why: 'The fingerprint approval for this wake-up had run out.' };
    if (expiresAt > now + WAKE_MAX_MS) return { ok: false, why: 'The fingerprint approval was good for too long to be trusted.' };
    for (const [n, at] of this.used) if (at <= now) this.used.delete(n);
    if (this.used.has(nonce)) return { ok: false, why: 'That fingerprint approval was already used.' };
    const subject = `${target}:${expiresAt}`;
    const message = `escanor-jarvis-v1|wake|${subject}|${nonce}|${target}`;
    const local = this.d.keys.get(keyId);
    if (local && verifySignature(local.publicKey, message, signature)) {
      this.used.set(nonce, expiresAt);
      return { ok: true, who: local.name };
    }
    const r = await this.d.account?.verify({ purpose: 'wake', subject, nonce, machine: target, keyId, signature, need: ['fingerprint'] }).catch(() => null);
    if (r?.ok) {
      this.used.set(nonce, expiresAt);
      return { ok: true, who: r.deviceName };
    }
    return { ok: false, why: 'The fingerprint approval did not check out.' };
  }
}
