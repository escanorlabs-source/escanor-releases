/** Why an engine did not answer. Only these move the router on to the next engine; being slow never does. */
export type FailureReason = 'unavailable' | 'auth' | 'limit' | 'model_missing' | 'error' | 'empty' | 'cancelled' | 'declined';

export class EngineFailure extends Error {
  constructor(
    readonly reason: FailureReason,
    message: string,
  ) {
    super(message);
  }
}
