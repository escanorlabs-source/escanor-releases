/**
 * Which engine answers a question (PB4), decided from what the machine has (the PB3 report) and what the question is. Pure: no
 * network, no files, so the whole decision table is tested. The runner (run.ts) walks the list this makes, moving on only when an
 * engine FAILS; being slow never moves it on.
 *
 * Engine ids: `cli:claude` `cli:codex` `cli:gemini` `cli:copilot` (a signed-in AI tool), `runtime:<ollama|lmstudio|llamacpp>:<model>` (a model
 * running on this computer), `pull:ollama` (download a model first, after the person says yes), `cloud` (the last resort).
 */
import type { LocalAiReport, LocalAskTask, LocalCliId, LocalRuntime, LocalRuntimeId } from '@remote-harness/shared';

/** The AI tools the router runs for an answer: the ones whose answer-only mode is known to work (cliEngine.ts). */
export const RUNNABLE_CLIS: readonly LocalCliId[] = ['claude', 'codex', 'gemini', 'copilot'];
const CLI_NAMES: Record<string, string> = { claude: 'Claude Code', codex: 'Codex (ChatGPT)', gemini: 'Gemini CLI', copilot: 'GitHub Copilot CLI' };
const RUNTIME_NAMES: Record<LocalRuntimeId, string> = { ollama: 'Ollama', lmstudio: 'LM Studio', llamacpp: 'llama.cpp server' };

export type Candidate =
  | { kind: 'cli'; engine: string; label: string; cli: LocalCliId }
  | { kind: 'runtime'; engine: string; label: string; runtime: LocalRuntimeId; port: number; model: string }
  | { kind: 'pull'; engine: string; label: string; model: string; sizeBytes: number; port: number }
  | { kind: 'cloud'; engine: string; label: string };

export type Plan = {
  candidates: Candidate[];
  /** Why an option that would otherwise have been there is not (shown when nothing at all can answer). */
  notes: { engine: string; label: string; why: string }[];
};

export type PlanOptions = {
  prefer?: string;
  allowCloud?: boolean;
  allowPull?: boolean;
  /** Whether the cloud step exists on this agent at all. */
  cloudAvailable?: boolean;
};

// ---------------------------------------------------------------------------- models

/** Models to download when the computer has none, smallest first. Sizes are the download sizes shown to the person. */
export const PULL_CATALOG: readonly { model: string; sizeBytes: number }[] = [
  { model: 'qwen2.5-coder:1.5b', sizeBytes: 990_000_000 },
  { model: 'qwen2.5-coder:3b', sizeBytes: 1_900_000_000 },
  { model: 'qwen2.5-coder:7b', sizeBytes: 4_700_000_000 },
  { model: 'qwen2.5-coder:14b', sizeBytes: 9_000_000_000 },
];

/** Room a model needs on top of its file: the working memory of a chat. */
export const MEMORY_HEADROOM = 1.25;
/** Room a download needs on disk beyond its size. */
export const DISK_HEADROOM_BYTES = 1_000_000_000;

const NOT_FOR_CHAT = /embed|rerank|bge-|nomic|e5-|minilm|whisper|tts|stable-?diffusion|clip/i;

/** Billions of parameters from a model's name (`qwen2.5-coder:7b`, `llama-3.2-3b-instruct`), or null. */
export function paramsB(name: string): number | null {
  const m = /(?:^|[^0-9a-z.])(\d+(?:\.\d+)?)\s*b(?![a-z])/i.exec(name.replace(/[_-]/g, ' '));
  return m ? Number(m[1]) : null;
}

export function fitsMemory(sizeBytes: number | undefined, budget: number): boolean {
  if (sizeBytes === undefined) return true; // size unknown: let it try
  return sizeBytes * MEMORY_HEADROOM <= budget;
}

/** The model of a runtime to use for a task, or null when it has none fit for chat. */
export function pickModel(rt: LocalRuntime, task: LocalAskTask, budget: number): { name: string; sizeBytes?: number } | null {
  const usable = rt.models.filter((m) => !NOT_FOR_CHAT.test(m.name) && fitsMemory(m.sizeBytes, budget));
  if (usable.length === 0) return null;
  const size = (m: { name: string; sizeBytes?: number }): number => m.sizeBytes ?? (paramsB(m.name) ?? 3) * 0.6e9;
  const small = task === 'quick' || task === 'summarize';
  const ranked = [...usable].sort((a, b) => {
    // Already in memory answers first. Then: a short job takes the smaller one, anything else the bigger.
    if (Boolean(a.loaded) !== Boolean(b.loaded)) return a.loaded ? -1 : 1;
    return small ? size(a) - size(b) : size(b) - size(a);
  });
  return ranked[0]!;
}

/** The model to download for this computer, or why none can be. */
export function pickPullModel(report: LocalAiReport): { model: string; sizeBytes: number } | { why: string } {
  const budget = report.hardware.modelBudgetBytes;
  const disk = report.hardware.diskFreeBytes;
  let best: { model: string; sizeBytes: number } | null = null;
  let tooBigForDisk = false;
  for (const c of PULL_CATALOG) {
    if (c.sizeBytes * MEMORY_HEADROOM > budget) continue;
    if (disk !== undefined && disk < c.sizeBytes + DISK_HEADROOM_BYTES) {
      tooBigForDisk = true;
      continue;
    }
    best = c;
  }
  if (best) return best;
  if (tooBigForDisk) return { why: 'There is not enough free disk space to download even the smallest model.' };
  return { why: 'This computer does not have enough memory to run a local model.' };
}

// ---------------------------------------------------------------------------- the plan

const label = (c: Candidate): string => c.label;

export function planEngines(report: LocalAiReport | null, task: LocalAskTask, o: PlanOptions = {}): Plan {
  const notes: Plan['notes'] = [];
  const clis: Candidate[] = [];
  const runtimes: Candidate[] = [];
  const budget = report?.hardware.modelBudgetBytes ?? 0;

  for (const id of RUNNABLE_CLIS) {
    const c = report?.clis.find((x) => x.id === id);
    const name = CLI_NAMES[id]!;
    if (!c || !c.installed) continue; // not there: nothing to say
    if (c.allowed === false) {
      notes.push({ engine: `cli:${id}`, label: name, why: `${name} is turned off for Escanor on this computer.` });
      continue;
    }
    if (!c.usable) {
      notes.push({ engine: `cli:${id}`, label: name, why: `${name} is installed but not signed in on this computer.` });
      continue;
    }
    clis.push({ kind: 'cli', engine: `cli:${id}`, label: name, cli: id });
  }

  for (const rt of report?.runtimes ?? []) {
    const name = RUNTIME_NAMES[rt.id];
    if (!rt.running) continue;
    if (rt.allowed === false) {
      notes.push({ engine: `runtime:${rt.id}`, label: name, why: `${name} is turned off for Escanor on this computer.` });
      continue;
    }
    const m = pickModel(rt, task, budget);
    if (!m) {
      notes.push({
        engine: `runtime:${rt.id}`,
        label: name,
        why: rt.models.length === 0 ? `${name} is running but has no model.` : `${name} has models, but none fits this computer's memory.`,
      });
      continue;
    }
    runtimes.push({ kind: 'runtime', engine: `runtime:${rt.id}:${m.name}`, label: `${name} (${m.name})`, runtime: rt.id, port: rt.port, model: m.name });
  }

  const small = task === 'quick' || task === 'summarize';
  const ordered: Candidate[] = small ? [...runtimes, ...clis] : [...clis, ...runtimes];

  // Nothing local fits: a model can be downloaded into Ollama, after the person says yes.
  if (ordered.length === 0 && o.allowPull !== false && report) {
    const ollama = report.runtimes.find((r) => r.id === 'ollama');
    const pick = pickPullModel(report);
    if (!ollama || (!ollama.running && !ollama.installed)) {
      notes.push({ engine: 'pull:ollama', label: 'Ollama', why: 'No AI is set up on this computer. Install Ollama (ollama.com) to let it answer without the internet.' });
    } else if (!ollama.running) {
      notes.push({ engine: 'pull:ollama', label: 'Ollama', why: 'Ollama is installed but not running. Start it and ask again.' });
    } else if ('why' in pick) {
      notes.push({ engine: 'pull:ollama', label: 'Ollama', why: pick.why });
    } else {
      ordered.push({ kind: 'pull', engine: 'pull:ollama', label: `Ollama (download ${pick.model})`, model: pick.model, sizeBytes: pick.sizeBytes, port: ollama.port });
    }
  }

  if (o.allowCloud && o.cloudAvailable) ordered.push({ kind: 'cloud', engine: 'cloud', label: 'Escanor cloud model' });

  if (o.prefer) {
    const i = ordered.findIndex((c) => c.engine === o.prefer || c.engine.startsWith(`${o.prefer}:`));
    if (i > 0) ordered.unshift(...ordered.splice(i, 1));
  }
  return { candidates: ordered, notes };
}

export const labelOf = label;

/** The one engine a job from the router names (`cli:claude`, `runtime:ollama:<model>`), or null when this computer has not got it. */
export function exactCandidate(resource: string, report: LocalAiReport | null): Candidate | null {
  const parts = resource.split(':');
  if (parts[0] === 'cli' && parts[1] && (RUNNABLE_CLIS as readonly string[]).includes(parts[1])) {
    const id = parts[1] as LocalCliId;
    return report?.clis.some((c) => c.id === id && c.installed) ? { kind: 'cli', engine: `cli:${id}`, label: CLI_NAMES[id]!, cli: id } : null;
  }
  if (parts[0] === 'runtime' && parts[1] && parts[1] in RUNTIME_NAMES) {
    const id = parts[1] as LocalRuntimeId;
    const rt = report?.runtimes.find((r) => r.id === id && r.running);
    if (!rt) return null;
    const model = parts.slice(2).join(':') || pickModel(rt, 'chat', report?.hardware.modelBudgetBytes ?? 0)?.name;
    return model ? { kind: 'runtime', engine: `runtime:${id}:${model}`, label: `${RUNTIME_NAMES[id]} (${model})`, runtime: id, port: rt.port, model } : null;
  }
  return null;
}
