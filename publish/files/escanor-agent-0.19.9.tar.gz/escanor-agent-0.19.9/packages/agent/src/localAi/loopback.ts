import { request, type IncomingMessage } from 'node:http';

/**
 * Plain HTTP to a program on THIS computer, with no time limit of any kind: a local model that is still loading or thinking is not
 * a failure (Node's own fetch gives up after five quiet minutes, which a big model loading from disk can take). Only the caller's
 * AbortSignal ends it. Always 127.0.0.1.
 */
export type LoopbackResponse = { status: number; body: AsyncIterable<Buffer>; text: () => Promise<string> };

export class LoopbackError extends Error {
  constructor(
    message: string,
    readonly code: 'unavailable' | 'cancelled' | 'broken',
  ) {
    super(message);
  }
}

export function loopbackRequest(o: { port: number; method?: 'GET' | 'POST'; path: string; json?: unknown; signal?: AbortSignal; host?: '127.0.0.1' }): Promise<LoopbackResponse> {
  return new Promise((resolve, reject) => {
    if (o.signal?.aborted) {
      reject(new LoopbackError('cancelled', 'cancelled'));
      return;
    }
    const payload = o.json === undefined ? undefined : Buffer.from(JSON.stringify(o.json));
    const req = request(
      { host: '127.0.0.1', port: o.port, path: o.path, method: o.method ?? (payload ? 'POST' : 'GET'), headers: { accept: '*/*', ...(payload ? { 'content-type': 'application/json', 'content-length': String(payload.length) } : {}) } },
      (res: IncomingMessage) => {
        const body = (async function* () {
          try {
            for await (const chunk of res) yield chunk as Buffer;
          } catch (err) {
            throw new LoopbackError(o.signal?.aborted ? 'cancelled' : `The connection to the local AI broke (${err instanceof Error ? err.message : String(err)}).`, o.signal?.aborted ? 'cancelled' : 'broken');
          }
          if (!res.complete && !o.signal?.aborted) throw new LoopbackError('The local AI stopped answering in the middle of its answer.', 'broken');
        })();
        resolve({
          status: res.statusCode ?? 0,
          body,
          text: async () => {
            const parts: Buffer[] = [];
            let n = 0;
            for await (const c of body) {
              n += c.length;
              if (n > 1_000_000) break;
              parts.push(c);
            }
            return Buffer.concat(parts).toString('utf8');
          },
        });
      },
    );
    const onAbort = () => req.destroy(new LoopbackError('cancelled', 'cancelled'));
    o.signal?.addEventListener('abort', onAbort, { once: true });
    req.on('close', () => o.signal?.removeEventListener('abort', onAbort));
    req.on('error', (err) => {
      if (o.signal?.aborted) reject(new LoopbackError('cancelled', 'cancelled'));
      else reject(new LoopbackError(`Nothing is answering on this computer at port ${o.port} (${(err as NodeJS.ErrnoException).code ?? err.message}).`, 'unavailable'));
    });
    if (payload) req.write(payload);
    req.end();
  });
}

/** Lines of a streamed body, whole ones only (a line may arrive in pieces). */
export async function* lines(body: AsyncIterable<Buffer>): AsyncGenerator<string> {
  let buf = '';
  for await (const chunk of body) {
    buf += chunk.toString('utf8');
    let i: number;
    while ((i = buf.indexOf('\n')) >= 0) {
      yield buf.slice(0, i).replace(/\r$/, '');
      buf = buf.slice(i + 1);
    }
  }
  if (buf.trim()) yield buf;
}
