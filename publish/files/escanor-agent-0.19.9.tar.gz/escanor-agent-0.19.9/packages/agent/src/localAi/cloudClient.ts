/**
 * The cloud as the last resort (PB5): asks the hub, which uses the OWNER's own cloud AI key (never one on this computer) and picks
 * the smallest model that is good enough. One question, one answer message back (`cloud_answer`). No key ever passes here.
 * There is no timeout of its own: the hub bounds the call; a lost link ends the wait with a readable failure.
 */
import type { AgentToHubMessage, HubCloudAnswer } from '@remote-harness/shared';
import { EngineFailure } from './engineError.js';
import type { CloudAsk } from './run.js';

export class CloudClient {
  private waiting = new Map<string, { resolve: (a: HubCloudAnswer) => void; reject: (e: EngineFailure) => void }>();
  private n = 0;
  constructor(private readonly d: { send: (m: AgentToHubMessage) => void; connected: () => boolean }) {}

  /** The hub's answer arrived. */
  handle(msg: HubCloudAnswer): void {
    const w = this.waiting.get(msg.requestId);
    if (!w) return;
    this.waiting.delete(msg.requestId);
    w.resolve(msg);
  }

  /** The link dropped: every waiting question ends (its answer cannot come back). */
  linkLost(): void {
    for (const [id, w] of [...this.waiting]) {
      this.waiting.delete(id);
      w.reject(new EngineFailure('unavailable', 'The connection to Escanor was lost while the cloud model was asked.'));
    }
  }

  ask = async (a: CloudAsk): Promise<string> => {
    if (!this.d.connected()) throw new EngineFailure('unavailable', 'This computer is not connected to Escanor, so the cloud model cannot be asked.');
    if (a.signal.aborted) throw new EngineFailure('cancelled', 'Cancelled.');
    const requestId = `cloud-${Date.now().toString(36)}-${++this.n}`;
    const answer = await new Promise<HubCloudAnswer>((resolve, reject) => {
      const onAbort = () => {
        this.waiting.delete(requestId);
        reject(new EngineFailure('cancelled', 'Cancelled.'));
      };
      a.signal.addEventListener('abort', onAbort, { once: true });
      this.waiting.set(requestId, {
        resolve: (m) => {
          a.signal.removeEventListener('abort', onAbort);
          resolve(m);
        },
        reject: (e) => {
          a.signal.removeEventListener('abort', onAbort);
          reject(e);
        },
      });
      try {
        this.d.send({ type: 'cloud_ask', requestId, task: a.task, messages: a.messages.map((m) => ({ role: m.role, content: m.content })), tried: a.tried.map((t) => ({ engine: t.engine, why: t.why.slice(0, 300) })) });
      } catch (err) {
        this.waiting.delete(requestId);
        a.signal.removeEventListener('abort', onAbort);
        reject(new EngineFailure('unavailable', `The cloud model could not be asked: ${err instanceof Error ? err.message : String(err)}`));
      }
    });
    if (!answer.ok || !answer.text) throw new EngineFailure(answer.ok ? 'empty' : 'error', answer.error || 'The cloud model sent no answer.');
    a.onText(answer.text);
    return answer.text;
  };
}
