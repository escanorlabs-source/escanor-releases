/**
 * This computer as one of the person's AI resources for the backend router: what it may be asked to run (one switch per tool),
 * what plan each tool is on, how much room is left, and whether the computer is free right now. Also the up-front checks for a job
 * from outside: a job is refused, in one plain line, when the tool is off, signed out, at its limit, or the computer is locked
 * or busy with the person's own work.
 *
 * Rules: the person's own computer comes first and their work comes before ours; nothing here touches the keyring (a sign-in is
 * seen by its file or environment variable only, and only a plan word is read out of it, never a name, an email or a key).
 * Pure logic with injectable sources, so every case is tested with fakes.
 */
import { readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import type { AccountUsage, LocalAiReport, LocalCli, LocalCliId, LocalRuntime, OwnFailureCode, OwnMachineState } from '@remote-harness/shared';
import { parseLimitText } from '../aiLimits.js';
import { switchOn } from '../switches.js';
import { copilotSignedIn } from '../cliTools.js';
import { fileHoldsLogin } from './discover.js';

export const OWN_RESOURCE_IDS = ['claude', 'codex', 'gemini', 'copilot', 'opencode', 'aider', 'qwen', 'ollama', 'lmstudio', 'llamacpp'] as const;
export type OwnResourceId = (typeof OWN_RESOURCE_IDS)[number];

type Env = Record<string, string | undefined>;

/** The person's switch for one tool or runtime. On unless it is explicitly turned off (a resource that is not there is simply absent). */
export function resourceAllowed(id: string, env: Env = process.env): boolean {
  return switchOn(env[`ESCANOR_OWN_AI_${id.toUpperCase()}`], true);
}

/** The master switch for jobs from outside (the router). Off = every job is refused; /ask on this computer is not affected. */
export function jobsAllowed(env: Env = process.env): boolean {
  return switchOn(env.ESCANOR_OWN_AI_JOBS, true);
}

export const MAX_OWN_JOBS = 2;
/** A limit whose reset time cannot be read is held this long. */
export const LIMIT_HOLD_MS = 30 * 60_000;

/** `cli:claude` / `runtime:ollama:qwen3:8b` -> the resource id (`claude` / `ollama`), or null when it is not one. */
export function resourceOfEngine(engine: string): OwnResourceId | null {
  const parts = engine.split(':');
  const id = parts[1];
  if (parts[0] === 'cli' && id && (OWN_RESOURCE_IDS as readonly string[]).includes(id)) return id as OwnResourceId;
  if (parts[0] === 'runtime' && id && (OWN_RESOURCE_IDS as readonly string[]).includes(id)) return id as OwnResourceId;
  return null;
}

// ---------------------------------------------------------------------------- the plan, from the tool's own sign-in file

type PlanCtx = { env: Env; home: string; profilesDir?: string };

const lower = (v: unknown): string | undefined => (typeof v === 'string' && /^[A-Za-z0-9_ -]{1,40}$/.test(v) ? v.trim().toLowerCase().replace(/^chatgpt[_ ]?/, '').replace(/\s+/g, '-') : undefined);

function readJson(file: string): Record<string, unknown> | null {
  try {
    const j = JSON.parse(readFileSync(file, 'utf8')) as unknown;
    return j && typeof j === 'object' && !Array.isArray(j) ? (j as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** The payload of a JWT (the middle part). Only used to read one plan word; the token is never kept or sent. */
function jwtPayload(token: unknown): Record<string, unknown> | null {
  if (typeof token !== 'string') return null;
  const mid = token.split('.')[1];
  if (!mid) return null;
  try {
    const j = JSON.parse(Buffer.from(mid.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')) as unknown;
    return j && typeof j === 'object' && !Array.isArray(j) ? (j as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** The plan word visible for a tool, or undefined. Files only: the keyring is never asked. */
export function readPlan(id: LocalCliId, c: PlanCtx): string | undefined {
  if (id === 'claude') {
    const files = [join(c.env.CLAUDE_CONFIG_DIR?.trim() || join(c.home, '.claude'), '.credentials.json')];
    for (const f of files) {
      const oauth = readJson(f)?.claudeAiOauth;
      const plan = oauth && typeof oauth === 'object' ? lower((oauth as Record<string, unknown>).subscriptionType) : undefined;
      if (plan) return plan;
    }
    return (c.env.ANTHROPIC_API_KEY ?? '').trim().length > 8 ? 'api-key' : undefined;
  }
  if (id === 'codex') {
    const j = readJson(join(c.env.CODEX_HOME?.trim() || join(c.home, '.codex'), 'auth.json'));
    const tokens = j?.tokens && typeof j.tokens === 'object' ? (j.tokens as Record<string, unknown>) : null;
    const auth = jwtPayload(tokens?.id_token)?.['https://api.openai.com/auth'];
    const plan = auth && typeof auth === 'object' ? lower((auth as Record<string, unknown>).chatgpt_plan_type) : undefined;
    if (plan) return plan;
    if (typeof j?.OPENAI_API_KEY === 'string' && j.OPENAI_API_KEY.length > 8) return 'api-key';
    return (c.env.OPENAI_API_KEY ?? c.env.CODEX_API_KEY ?? '').trim().length > 8 ? 'api-key' : undefined;
  }
  if (id === 'gemini') {
    if (fileHoldsLogin(join(c.home, '.gemini', 'oauth_creds.json'))) return 'google-account';
    return (c.env.GEMINI_API_KEY ?? c.env.GOOGLE_API_KEY ?? '').trim().length > 8 ? 'api-key' : undefined;
  }
  if (id === 'copilot') {
    // Copilot keeps the token in the system's credential store; its config.json says a GitHub account is signed in.
    if (copilotSignedIn(join(c.env.COPILOT_HOME?.trim() || join(c.home, '.copilot'), 'config.json'))) return 'github-account';
    return (c.env.COPILOT_GITHUB_TOKEN ?? '').trim().length > 8 ? 'api-key' : undefined;
  }
  return undefined;
}

// ---------------------------------------------------------------------------- the computer

export type OwnDeps = {
  env?: Env;
  home?: string;
  profilesDir?: string;
  now?: () => number;
  agentVersion: string;
  /** True when the screen is locked or nobody is signed in. */
  isLocked: () => Promise<boolean>;
  /** One plain line when our work is being held for the person (they are using the computer, or it is short of memory/CPU); null when free. */
  holdReason: () => string | null;
  /** Chats running here now. */
  activeChats: () => number;
  /** Claude's usage figures (the default sign-in), when they could be read. */
  usage?: () => AccountUsage | undefined;
  maxJobs?: number;
};

export type Gate = { ok: true } | { ok: false; code: OwnFailureCode; message: string };

const LOCK_CACHE_MS = 15_000;

export class OwnComputer {
  private running = new Map<string, number>();
  private limited = new Map<string, number>();
  private lockedAt = 0;
  private lockedVal = false;
  constructor(private readonly d: OwnDeps) {}

  private get env(): Env {
    return this.d.env ?? process.env;
  }
  private now(): number {
    return (this.d.now ?? Date.now)();
  }

  get activeJobs(): number {
    let n = 0;
    for (const v of this.running.values()) n += v;
    return n;
  }

  /** A job is starting on [id]: false when the computer cannot take it (the caller checked the gate first; this is the race guard). */
  begin(id: string): (() => void) | null {
    if (this.activeJobs >= (this.d.maxJobs ?? MAX_OWN_JOBS) || (this.running.get(id) ?? 0) > 0) return null;
    this.running.set(id, 1);
    let done = false;
    return () => {
      if (done) return;
      done = true;
      this.running.delete(id);
    };
  }

  /** A tool said it has reached its limit: it is held until the reset time in its words, or for a while. */
  markLimited(id: string, text: string): void {
    const t = parseLimitText(text, this.now());
    this.limited.set(id, t?.resetsAt && t.resetsAt > this.now() ? t.resetsAt : this.now() + LIMIT_HOLD_MS);
  }

  limitedUntil(id: string): number | null {
    const until = this.limited.get(id);
    if (until === undefined) return null;
    if (until <= this.now()) {
      this.limited.delete(id);
      return null;
    }
    return until;
  }

  private async locked(): Promise<boolean> {
    const t = this.now();
    if (t - this.lockedAt < LOCK_CACHE_MS) return this.lockedVal;
    try {
      this.lockedVal = await this.d.isLocked();
    } catch {
      this.lockedVal = false;
    }
    this.lockedAt = t;
    return this.lockedVal;
  }

  /** How the computer is now. */
  async machine(): Promise<OwnMachineState> {
    const locked = await this.locked();
    const hold = this.d.holdReason();
    const jobs = this.activeJobs;
    const atLimit = jobs >= (this.d.maxJobs ?? MAX_OWN_JOBS);
    const base = { activeJobs: jobs, activeChats: this.d.activeChats(), locked, checkedAt: new Date(this.now()).toISOString() };
    if (locked) return { state: 'locked', ...base, why: 'The screen is locked.' };
    if (hold) return { state: 'busy', ...base, why: hold };
    if (atLimit) return { state: 'busy', ...base, why: 'Two jobs are already running on this computer.' };
    return { state: 'idle', ...base };
  }

  /** The report with the switches, plan, room left, state, and how the computer is now. */
  async decorate(r: LocalAiReport): Promise<LocalAiReport> {
    const machine = await this.machine();
    const ctx = { env: this.env, home: this.d.home ?? homedir(), profilesDir: this.d.profilesDir };
    const usage = this.d.usage?.();
    const clis = r.clis.map((c): LocalCli => {
      const allowed = resourceAllowed(c.id, this.env);
      const until = this.limitedUntil(c.id);
      const plan = c.installed && c.login !== 'no' ? readPlan(c.id, ctx) : undefined;
      const claudeLimit = c.id === 'claude' && usage ? { usedPct: usage.five_hour_pct, ...(usage.resets_at ? { resetsAt: usage.resets_at } : {}) } : null;
      const limited = until !== null;
      const limit = limited || claudeLimit ? { ...(claudeLimit ?? {}), ...(limited ? { resetsAt: new Date(until).toISOString() } : {}), limited } : undefined;
      const state: LocalCli['state'] = !c.installed ? 'not_installed' : !allowed ? 'off' : !c.usable ? 'signed_out' : limited ? 'limited' : this.running.has(c.id) ? 'busy' : 'ready';
      const { plan: _p, limit: _l, ...rest } = c;
      return { ...rest, allowed, ...(plan ? { plan } : {}), ...(limit ? { limit } : {}), state };
    });
    const runtimes = r.runtimes.map((x): LocalRuntime => {
      const allowed = resourceAllowed(x.id, this.env);
      const state: LocalRuntime['state'] = !x.running ? 'not_running' : !allowed ? 'off' : this.running.has(x.id) ? 'busy' : 'ready';
      return { ...x, allowed, state };
    });
    // Only what the person allows counts as something this computer can use.
    const usableClis = clis.filter((c) => c.installed && c.usable && c.allowed !== false).length;
    const running = runtimes.filter((x) => x.running && x.allowed !== false);
    const localModels = running.reduce((s, x) => s + x.models.length, 0);
    return {
      ...r,
      clis,
      runtimes,
      summary: { usableClis, runningRuntimes: running.length, localModels, best: usableClis > 0 ? 'cli' : localModels > 0 ? 'runtime' : 'none' },
      machine,
      health: { ok: true, agentVersion: this.d.agentVersion, checkedAt: machine.checkedAt },
    };
  }

  /** May a job from the router run on [resource] now? One plain line when not. Nothing is started here. */
  async gate(resource: string | undefined, mode: 'answer' | 'task', report: LocalAiReport | null): Promise<Gate> {
    if (!jobsAllowed(this.env)) return { ok: false, code: 'off', message: 'Work from Escanor is turned off on this computer (Settings, own computer).' };
    if (resource) {
      const id = resourceOfEngine(resource);
      if (!id) return { ok: false, code: 'not_installed', message: `This computer has no resource called ${resource}.` };
      const name = report?.clis.find((c) => c.id === id)?.name ?? report?.runtimes.find((x) => x.id === id)?.name ?? id;
      if (!resourceAllowed(id, this.env)) return { ok: false, code: 'not_allowed', message: `${name} is turned off for Escanor on this computer.` };
      const cli = report?.clis.find((c) => c.id === id);
      const rt = report?.runtimes.find((x) => x.id === id);
      if (resource.startsWith('cli:')) {
        if (!cli?.installed) return { ok: false, code: 'not_installed', message: `${name} is not installed on this computer.` };
        if (!cli.usable) return { ok: false, code: 'signed_out', message: `${name} is not signed in on this computer.` };
        const until = this.limitedUntil(id);
        if (until !== null) return { ok: false, code: 'limited', message: `${name} has reached its usage limit; it resets about ${new Date(until).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}.` };
      } else {
        if (!rt?.running) return { ok: false, code: 'not_running', message: `${name} is not running on this computer.` };
        const model = resource.split(':').slice(2).join(':');
        if (model && !rt.models.some((m) => m.name === model)) return { ok: false, code: 'model_missing', message: `${name} does not have the model ${model}.` };
        if (mode === 'task') return { ok: false, code: 'not_supported', message: 'Local models answer questions only. Work with files needs Claude Code, Codex, Gemini CLI or GitHub Copilot CLI.' };
      }
    }
    const m = await this.machine();
    if (m.locked && !switchOn(this.env.ESCANOR_OWN_AI_WHEN_LOCKED, false)) return { ok: false, code: 'locked', message: 'This computer is locked, so it is not used for AI work now.' };
    if (m.state === 'busy') return { ok: false, code: 'busy', message: `This computer is busy: ${(m.why ?? 'it has other work').replace(/\.$/, '')}.` };
    if (resource) {
      const id = resourceOfEngine(resource);
      if (id && this.running.has(id)) return { ok: false, code: 'busy', message: `${report?.clis.find((c) => c.id === id)?.name ?? id} is already running a job for Escanor.` };
    }
    return { ok: true };
  }
}

/** The word shown for [why] the person is being given way to, as one sentence for the report. */
export const holdLine = (text: string | null): string | null => (text ? text.replace(/^(Paused|Running gently): /, '') : null);
