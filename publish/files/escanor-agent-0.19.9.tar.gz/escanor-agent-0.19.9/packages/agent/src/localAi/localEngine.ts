/**
 * An engine that talks to a model running on this computer through the common OpenAI-style chat API (Ollama, LM Studio and the
 * llama.cpp server all serve it). Streams the answer. No time limit: a quiet stretch is only reported (`onSilence`), never ended.
 */
import { EngineFailure } from './engineError.js';
import { lines, loopbackRequest, LoopbackError } from './loopback.js';

export type ChatMessage = { role: 'system' | 'user' | 'assistant'; content: string };

export type RuntimeAsk = {
  port: number;
  model: string;
  messages: ChatMessage[];
  signal?: AbortSignal;
  onText: (delta: string) => void;
  /** Called every [silenceMs] while nothing arrives (seconds since the last byte). Never ends the run. */
  onSilence?: (seconds: number) => void;
  silenceMs?: number;
};

export const DEFAULT_SILENCE_MS = 60_000;

/** The answer text, or throws EngineFailure. */
export async function askRuntime(a: RuntimeAsk): Promise<string> {
  let last = Date.now();
  const every = a.silenceMs ?? DEFAULT_SILENCE_MS;
  // Reports each full quiet stretch of [every] ms once; any byte from the model starts the count again.
  let reported = 0;
  const timer = a.onSilence
    ? setInterval(() => {
        const quiet = Date.now() - last;
        const step = Math.floor(quiet / every);
        if (step > reported) {
          reported = step;
          a.onSilence?.(Math.round(quiet / 1000));
        }
      }, Math.max(5, Math.min(every / 2, 5_000)))
    : null;
  timer?.unref?.();
  try {
    let res;
    try {
      res = await loopbackRequest({ port: a.port, path: '/v1/chat/completions', json: { model: a.model, messages: a.messages, stream: true }, signal: a.signal });
    } catch (err) {
      if (err instanceof LoopbackError) throw new EngineFailure(err.code === 'cancelled' ? 'cancelled' : 'unavailable', err.message);
      throw err;
    }
    if (res.status !== 200) {
      const body = (await res.text().catch(() => '')).slice(0, 400);
      if (res.status === 404 || /model.*(not found|does not exist|not loaded|missing)|no such model|try pulling/i.test(body)) {
        throw new EngineFailure('model_missing', `The model ${a.model} is not available there. ${body}`.trim());
      }
      throw new EngineFailure('error', `The local AI answered with an error (${res.status}). ${body}`.trim());
    }
    let text = '';
    try {
      for await (const raw of lines(res.body)) {
        last = Date.now();
        reported = 0;
        if (!raw.startsWith('data:')) continue;
        const data = raw.slice(5).trim();
        if (!data || data === '[DONE]') continue;
        let j: { choices?: { delta?: { content?: unknown }; message?: { content?: unknown }; finish_reason?: unknown }[]; error?: { message?: unknown } | string };
        try {
          j = JSON.parse(data);
        } catch {
          continue;
        }
        if (j.error) {
          const msg = typeof j.error === 'string' ? j.error : String(j.error.message ?? 'error');
          throw new EngineFailure(/not found|no such model/i.test(msg) ? 'model_missing' : 'error', `The local AI reported an error: ${msg.slice(0, 400)}`);
        }
        const delta = j.choices?.[0]?.delta?.content ?? j.choices?.[0]?.message?.content;
        if (typeof delta === 'string' && delta) {
          text += delta;
          a.onText(delta);
        }
      }
    } catch (err) {
      if (err instanceof EngineFailure) throw err;
      if (err instanceof LoopbackError) throw new EngineFailure(err.code === 'cancelled' ? 'cancelled' : 'error', err.message);
      throw err;
    }
    if (a.signal?.aborted) throw new EngineFailure('cancelled', 'Cancelled.');
    if (!text.trim()) throw new EngineFailure('empty', `${a.model} sent an empty answer.`);
    return text;
  } finally {
    if (timer) clearInterval(timer);
  }
}
