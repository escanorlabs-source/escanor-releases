/**
 * The models this computer's Claude Code offers, read from Claude Code itself (`supportedModels()`), so the apps' model menus
 * follow whatever Claude Code knows (a new Fable or Opus shows up the day Claude Code ships it) instead of a list typed into
 * each app. Asked at most every 6 hours (it starts a Claude Code process that never runs a turn), and again when the Claude
 * Code version changes. Never throws: a failure keeps the last list (or none, and the apps keep their own fallback list).
 */
import type { ClaudeModelOption } from '@remote-harness/shared';

const EVERY_MS = 6 * 60 * 60 * 1000;
const TIMEOUT_MS = 45_000;

type Fetch = () => Promise<ClaudeModelOption[]>;

/** The SDK call: a query whose prompt never yields, asked for its model list, then closed. */
export const fetchFromSdk: Fetch = async () => {
  const { query } = await import('@anthropic-ai/claude-agent-sdk');
  async function* never(): AsyncGenerator<never> {
    await new Promise<never>(() => {});
  }
  const q = query({ prompt: never(), options: { cwd: process.cwd() } });
  let timer: NodeJS.Timeout | undefined;
  try {
    const rows = await Promise.race([
      q.supportedModels(),
      new Promise<never>((_, reject) => {
        timer = setTimeout(() => reject(new Error('Claude Code did not list its models in time')), TIMEOUT_MS);
      }),
    ]);
    return cleanModels(rows);
  } finally {
    if (timer) clearTimeout(timer);
    try {
      q.close();
    } catch {
      /* already closed */
    }
  }
};

/** Keeps what the apps need, short and safe: at most 40 rows, ids of letters, digits and -._[] only. */
export function cleanModels(rows: unknown): ClaudeModelOption[] {
  if (!Array.isArray(rows)) return [];
  const out: ClaudeModelOption[] = [];
  const seen = new Set<string>();
  for (const r of rows.slice(0, 40)) {
    if (!r || typeof r !== 'object') continue;
    const o = r as Record<string, unknown>;
    const value = typeof o.value === 'string' ? o.value.trim() : '';
    if (!/^[A-Za-z0-9._\-[\]]{1,80}$/.test(value) || seen.has(value)) continue;
    seen.add(value);
    const label = typeof o.displayName === 'string' && o.displayName.trim() ? o.displayName.trim().slice(0, 60) : value;
    const description = typeof o.description === 'string' ? o.description.trim().slice(0, 140) : '';
    const resolved = typeof o.resolvedModel === 'string' && /^[A-Za-z0-9._\-[\]]{1,80}$/.test(o.resolvedModel) ? o.resolvedModel : undefined;
    out.push({ value, label, ...(description ? { description } : {}), ...(resolved ? { resolved } : {}) });
  }
  return out;
}

export class ClaudeModels {
  private list: ClaudeModelOption[] = [];
  private at = 0;
  private version = '';
  private inFlight: Promise<void> | null = null;

  constructor(private readonly fetch: Fetch = fetchFromSdk, private readonly now: () => number = Date.now, private readonly log?: (t: string) => void) {}

  /** The last list; starts a refresh in the background when it is old or Claude Code's version changed. */
  current(claudeVersion?: string): ClaudeModelOption[] {
    const stale = this.now() - this.at > EVERY_MS || (claudeVersion !== undefined && claudeVersion !== this.version);
    if (stale && !this.inFlight) {
      this.inFlight = this.fetch()
        .then((rows) => {
          if (rows.length) this.list = rows;
          this.at = this.now();
          if (claudeVersion !== undefined) this.version = claudeVersion;
        })
        .catch((err) => {
          this.at = this.now(); // do not ask again on every scan after a failure
          this.log?.(`Reading Claude Code's models failed: ${err instanceof Error ? err.message : String(err)}`);
        })
        .finally(() => {
          this.inFlight = null;
        });
    }
    return this.list;
  }

  /** For tests and the first report: wait for a refresh that is running. */
  async settled(): Promise<void> {
    await this.inFlight;
  }
}
