/** Downloading a model into Ollama, with progress. No time limit (a big model on a slow line takes a long time); the caller's signal cancels. */
import { EngineFailure } from './engineError.js';
import { lines, loopbackRequest, LoopbackError } from './loopback.js';

export type PullProgress = { model: string; completedBytes: number; totalBytes: number; status: string };

export async function pullModel(o: { port: number; model: string; signal?: AbortSignal; onProgress: (p: PullProgress) => void }): Promise<void> {
  let res;
  try {
    res = await loopbackRequest({ port: o.port, path: '/api/pull', json: { model: o.model, stream: true }, signal: o.signal });
  } catch (err) {
    if (err instanceof LoopbackError) throw new EngineFailure(err.code === 'cancelled' ? 'cancelled' : 'unavailable', err.message);
    throw err;
  }
  if (res.status !== 200) {
    const body = (await res.text().catch(() => '')).slice(0, 300);
    throw new EngineFailure('error', `Ollama refused to download ${o.model} (${res.status}). ${body}`.trim());
  }
  // Ollama reports each layer on its own: the total is the sum of every layer seen.
  const layers = new Map<string, { total: number; completed: number }>();
  let status = 'starting';
  let ok = false;
  try {
    for await (const line of lines(res.body)) {
      let j: { status?: unknown; digest?: unknown; total?: unknown; completed?: unknown; error?: unknown };
      try {
        j = JSON.parse(line);
      } catch {
        continue;
      }
      if (j.error) throw new EngineFailure('error', `Downloading ${o.model} failed: ${String(j.error).slice(0, 300)}`);
      if (typeof j.status === 'string') status = j.status;
      if (typeof j.digest === 'string' && typeof j.total === 'number') layers.set(j.digest, { total: j.total, completed: typeof j.completed === 'number' ? j.completed : 0 });
      if (status === 'success') ok = true;
      let total = 0;
      let completed = 0;
      for (const l of layers.values()) {
        total += l.total;
        completed += Math.min(l.completed, l.total);
      }
      o.onProgress({ model: o.model, completedBytes: completed, totalBytes: total, status });
    }
  } catch (err) {
    if (err instanceof EngineFailure) throw err;
    if (err instanceof LoopbackError) throw new EngineFailure(err.code === 'cancelled' ? 'cancelled' : 'error', err.message);
    throw err;
  }
  if (o.signal?.aborted) throw new EngineFailure('cancelled', 'Cancelled.');
  if (!ok) throw new EngineFailure('error', `Downloading ${o.model} stopped before it finished.`);
}
