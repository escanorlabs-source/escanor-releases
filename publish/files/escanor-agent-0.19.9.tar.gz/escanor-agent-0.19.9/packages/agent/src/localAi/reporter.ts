import type { AgentLocalAi, LocalAiReport, LocalRuntime } from '@remote-harness/shared';
import { reportFingerprint, summarize } from './discover.js';

export type ReporterDeps = {
  scan: () => Promise<LocalAiReport>;
  /** Only the programs that run models here (cheap), for the in-between checks. */
  scanRuntimes: () => Promise<LocalRuntime[]>;
  /** Re-read which tools are signed in (cheap). Optional. */
  refreshClis?: (clis: LocalAiReport['clis']) => LocalAiReport['clis'];
  /** Adds the switches, plans, room left and how the computer is now (ownAi.ts). Applied to every report before it is kept or sent. */
  decorate?: (r: LocalAiReport) => Promise<LocalAiReport>;
  /** Even when nothing changed the hub hears again this often, so it knows the report is fresh (default 5 minutes). */
  heartbeatMs?: number;
  now?: () => number;
  send: (m: AgentLocalAi) => void;
  fullEveryMs?: number;
  lightEveryMs?: number;
  log?: (text: string) => void;
};

/**
 * Keeps the hub's picture of this computer's AI current: a full scan on start and every 10 minutes, a cheap look at the model
 * programs every minute, and a message only when something changed (or when asked, e.g. after reconnecting).
 */
export class LocalAiReporter {
  private last: LocalAiReport | null = null;
  private lastSent = '';
  private lastSentAt = 0;
  private timers: NodeJS.Timeout[] = [];
  private busy = false;
  /** A send asked for while a scan was running: done when that scan ends. */
  private forceAfter = false;
  private stopped = false;
  constructor(private readonly d: ReporterDeps) {}

  /** The latest report, or null before the first scan finished. */
  current(): LocalAiReport | null {
    return this.last;
  }

  start(): void {
    this.stopped = false;
    void this.full(false);
    const t1 = setInterval(() => void this.full(false), this.d.fullEveryMs ?? 10 * 60_000);
    const t2 = setInterval(() => void this.light(), this.d.lightEveryMs ?? 60_000);
    t1.unref();
    t2.unref();
    this.timers.push(t1, t2);
  }

  stop(): void {
    this.stopped = true;
    for (const t of this.timers) clearInterval(t);
    this.timers = [];
  }

  /** After (re)connecting the hub has nothing: send what is known, scanning first when nothing is. */
  async sendNow(): Promise<void> {
    if (this.last) this.emit(true);
    else if (this.busy) this.forceAfter = true; // the scan running now sends as soon as it ends
    else await this.full(true);
  }

  /** A fresh full scan now, sent to the hub if anything changed (after a model download). */
  async rescanNow(): Promise<void> {
    await this.full(false);
  }

  /** The report as it is for the router. A failing decoration never costs the report. */
  private async dress(r: LocalAiReport): Promise<LocalAiReport> {
    if (!this.d.decorate) return r;
    try {
      return await this.d.decorate(r);
    } catch (err) {
      this.d.log?.(`Adding the own-computer state failed: ${err instanceof Error ? err.message : String(err)}`);
      return r;
    }
  }

  /** A job started or ended, or a switch changed: look again at once (cheap) and tell the hub if the state changed. */
  async touch(): Promise<void> {
    await this.light();
  }

  private emit(force: boolean): void {
    if (this.stopped || !this.last) return;
    const fp = reportFingerprint(this.last);
    if (!force && fp === this.lastSent) return;
    this.lastSent = fp;
    this.lastSentAt = (this.d.now ?? Date.now)();
    try {
      this.d.send({ type: 'local_ai', report: this.last });
    } catch {
      this.lastSent = ''; // not sent: try again next time
    }
  }

  private async full(force: boolean): Promise<void> {
    if (this.busy) return;
    this.busy = true;
    try {
      this.last = await this.dress(await this.d.scan());
      const f = force || this.forceAfter;
      this.forceAfter = false;
      this.emit(f);
    } catch (err) {
      this.d.log?.(`Looking at the local AI failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      this.busy = false;
    }
  }

  private async light(): Promise<void> {
    if (this.busy || !this.last) return;
    this.busy = true;
    try {
      const runtimes = await this.d.scanRuntimes();
      const clis = this.d.refreshClis ? this.d.refreshClis(this.last.clis) : this.last.clis;
      this.last = await this.dress({ ...this.last, scannedAt: new Date().toISOString(), clis, runtimes, summary: summarize(clis, runtimes) });
      this.emit((this.d.now ?? Date.now)() - this.lastSentAt >= (this.d.heartbeatMs ?? 5 * 60_000));
    } catch (err) {
      this.d.log?.(`Looking at the local AI failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      this.busy = false;
    }
  }
}
