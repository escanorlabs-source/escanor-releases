/**
 * What AI this computer can use, found by looking (PB3): the AI command-line tools that are installed and signed in, the programs
 * that run models on the computer itself (Ollama, LM Studio, a llama.cpp server), and what the hardware can carry. The result
 * (LocalAiReport, spec: local-ai-report-spec.md) goes to the hub in the hello and on its own, and the router (PB4) reads the same.
 *
 * Rules: every probe has a short deadline and a failed one means "not there", never an error; only this computer's own loopback
 * address is ever asked; a sign-in is recognised by its file or environment key being present, and nothing about it (no name,
 * email, key) is kept or sent.
 */
import { existsSync, readdirSync, readFileSync, statSync, statfsSync } from 'node:fs';
import { arch, cpus, freemem, homedir, platform, totalmem } from 'node:os';
import { delimiter, join } from 'node:path';
import type { LocalAiReport, LocalCli, LocalCliId, LocalHardware, LocalRuntime, LocalRuntimeId } from '@remote-harness/shared';
import { childEnv } from '../childEnv.js';
import { COPILOT_MODELS, copilotSignedIn, findCliOnPath, findOnPath, pathOf, realRun, type RunFn } from '../cliTools.js';

export const HTTP_DEADLINE_MS = 1500;
export const COMMAND_DEADLINE_MS = 4000;
const MAX_MODELS = 50;
const MAX_BODY_BYTES = 2_000_000;

/** The body of an answer, read only up to [max] bytes (a bigger one is not a model list: it throws). */
async function readCapped(res: Response, max: number): Promise<string> {
  const reader = res.body?.getReader();
  if (!reader) {
    const t = await res.text();
    if (t.length > max) throw new Error('too big');
    return t;
  }
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > max) {
      void reader.cancel().catch(() => undefined);
      throw new Error('too big');
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks).toString('utf8');
}

export const DEFAULT_PORTS: Record<LocalRuntimeId, number> = { ollama: 11434, lmstudio: 1234, llamacpp: 8080 };

type Env = Record<string, string | undefined>;

export type DiscoverOptions = {
  env?: Env;
  home?: string;
  platform?: NodeJS.Platform;
  arch?: string;
  /** Agent's own accounts folder (PROFILES_DIR): ChatGPT / Gemini / Copilot / Claude sign-ins kept there count too. */
  profilesDir?: string;
  ports?: Partial<Record<LocalRuntimeId, number>>;
  run?: RunFn;
  fetchFn?: typeof fetch;
  /** Test hooks for the hardware. */
  hardware?: Partial<{ totalmem: number; freemem: number; cpuModel: string; cpuCores: number }>;
  now?: () => number;
};

type CliSpec = {
  id: LocalCliId;
  name: string;
  bin: string;
  /** Files (relative to home / given dirs) that hold a sign-in. */
  files: (c: Ctx) => string[];
  /** Environment keys that stand for a sign-in. */
  envKeys: string[];
  /** On macOS the sign-in lives in the keychain, which is not read here. */
  keychainOnMac?: boolean;
  /** How one of [files] shows a sign-in, when being there and not empty is not enough. */
  holdsLogin?: (file: string) => boolean;
};

type Ctx = { env: Env; home: string; platform: NodeJS.Platform; profilesDir?: string };

const PROVIDER_KEYS = ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY', 'DEEPSEEK_API_KEY', 'OPENROUTER_API_KEY', 'GROQ_API_KEY', 'MISTRAL_API_KEY', 'XAI_API_KEY'];

const xdgData = (c: Ctx): string => c.env.XDG_DATA_HOME?.trim() || join(c.home, '.local', 'share');

/** Folders inside the agent's accounts folder (one per account), for sign-in files kept there. */
function profileDirs(c: Ctx): string[] {
  if (!c.profilesDir) return [];
  try {
    return readdirSync(c.profilesDir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && !d.name.startsWith('.tools'))
      .map((d) => join(c.profilesDir!, d.name))
      .slice(0, 50);
  } catch {
    return [];
  }
}

export const CLI_SPECS: CliSpec[] = [
  {
    id: 'claude',
    name: 'Claude Code',
    bin: 'claude',
    files: (c) => [
      join(c.env.CLAUDE_CONFIG_DIR?.trim() || join(c.home, '.claude'), '.credentials.json'),
      ...profileDirs(c).map((d) => join(d, '.credentials.json')),
    ],
    envKeys: ['ANTHROPIC_API_KEY', 'CLAUDE_CODE_OAUTH_TOKEN', 'ANTHROPIC_AUTH_TOKEN'],
    keychainOnMac: true,
  },
  {
    id: 'codex',
    name: 'Codex (ChatGPT)',
    bin: 'codex',
    files: (c) => [join(c.env.CODEX_HOME?.trim() || join(c.home, '.codex'), 'auth.json'), ...profileDirs(c).map((d) => join(d, 'auth.json'))],
    envKeys: ['OPENAI_API_KEY', 'CODEX_API_KEY'],
  },
  {
    id: 'gemini',
    name: 'Gemini CLI',
    bin: 'gemini',
    files: (c) => [join(c.home, '.gemini', 'oauth_creds.json'), ...profileDirs(c).map((d) => join(d, '.gemini', 'oauth_creds.json'))],
    envKeys: ['GEMINI_API_KEY', 'GOOGLE_API_KEY'],
  },
  {
    id: 'copilot',
    name: 'GitHub Copilot CLI',
    bin: 'copilot',
    // Copilot keeps the token in the system's credential store (else its config.json); config.json names the signed-in account.
    // An Escanor account added with a token keeps that in its own folder.
    files: (c) => [
      join(c.env.COPILOT_HOME?.trim() || join(c.home, '.copilot'), 'config.json'),
      ...profileDirs(c).filter((d) => /[\\/]copilot-[^\\/]*$/.test(d)).flatMap((d) => [join(d, 'config.json'), join(d, '.escanor-api-key')]),
    ],
    envKeys: ['COPILOT_GITHUB_TOKEN'],
    holdsLogin: (f) => (f.endsWith('config.json') ? copilotSignedIn(f) : fileHoldsLogin(f)),
  },
  {
    id: 'opencode',
    name: 'opencode',
    bin: 'opencode',
    files: (c) => [join(xdgData(c), 'opencode', 'auth.json')],
    envKeys: PROVIDER_KEYS,
  },
  {
    id: 'aider',
    name: 'Aider',
    bin: 'aider',
    files: () => [],
    envKeys: PROVIDER_KEYS,
  },
  {
    id: 'qwen',
    name: 'Qwen Code',
    bin: 'qwen',
    files: (c) => [join(c.home, '.qwen', 'oauth_creds.json')],
    envKeys: ['DASHSCOPE_API_KEY', 'OPENAI_API_KEY', 'QWEN_API_KEY'],
  },
];

/** A sign-in file counts when it exists and is not empty (`{}` and blanks do not count). Content is never kept. */
export function fileHoldsLogin(file: string): boolean {
  try {
    const st = statSync(file);
    if (!st.isFile() || st.size < 3) return false;
    const text = readFileSync(file, 'utf8').trim();
    if (text === '' || text === '{}' || text === 'null' || text === '[]') return false;
    return true;
  } catch {
    return false;
  }
}

export function detectLogin(spec: CliSpec, c: Ctx): { login: LocalCli['login']; loginVia?: LocalCli['loginVia'] } {
  for (const f of spec.files(c)) if ((spec.holdsLogin ?? fileHoldsLogin)(f)) return { login: 'yes', loginVia: 'file' };
  for (const k of spec.envKeys) if ((c.env[k] ?? '').trim().length > 8) return { login: 'yes', loginVia: 'env' };
  // Claude Code on a Mac keeps the sign-in in the keychain: it cannot be told without asking the keychain (a prompt), so unknown.
  if (spec.keychainOnMac && c.platform === 'darwin') return { login: 'unknown', loginVia: 'keychain' };
  // A tool whose own config might hold a key (aider's .aider.conf.yml) is not looked into: no key found = no.
  return { login: 'no' };
}

/** Where tools usually install themselves, added to the search (an app started from a launcher has a short PATH). */
export function extraBinDirs(c: Ctx): string[] {
  const h = c.home;
  const out = [join(h, '.local', 'bin'), join(h, '.claude', 'local'), join(h, '.npm-global', 'bin'), join(h, '.bun', 'bin'), join(h, '.cargo', 'bin'), join(h, '.volta', 'bin')];
  // The tools the agent installed for itself when an account for that AI was added (cliTools.ts ensureCli).
  if (c.profilesDir) out.push(join(c.profilesDir, '.tools', 'node_modules', '.bin'));
  if (c.platform === 'darwin') out.push('/opt/homebrew/bin', '/usr/local/bin');
  if (c.platform === 'win32') {
    const appData = c.env.APPDATA || join(h, 'AppData', 'Roaming');
    const local = c.env.LOCALAPPDATA || join(h, 'AppData', 'Local');
    out.push(join(appData, 'npm'), join(local, 'Programs', 'Ollama'), join(h, '.local', 'bin'));
  }
  return out;
}

export function searchEnv(c: Ctx): Env {
  const key = c.platform === 'win32' ? Object.keys(c.env).find((k) => k.toUpperCase() === 'PATH') ?? 'Path' : 'PATH';
  const dirs = [...pathOf(c.env).split(delimiter).filter(Boolean), ...extraBinDirs(c)];
  return { ...c.env, [key]: [...new Set(dirs)].join(delimiter) };
}

function versionOf(text: string): string | undefined {
  return /\bv?(\d+\.\d+(?:\.\d+)?(?:[-+][0-9A-Za-z.]+)?)/.exec(text)?.[1];
}

async function probeCli(spec: CliSpec, c: Ctx, run: RunFn): Promise<LocalCli> {
  const env = searchEnv(c);
  // VS Code's stand-in `copilot` command (it only says the real one is missing) does not count (findCliOnPath).
  const bin = findCliOnPath(spec.bin, env, c.platform);
  const base: LocalCli = { id: spec.id, name: spec.name, installed: false, login: 'no', usable: false };
  if (!bin) return base;
  const login = detectLogin(spec, c);
  const cli: LocalCli = { ...base, installed: true, ...login, usable: login.login !== 'no' };
  // Copilot's models, for the apps' model menus (Claude Code's are read from Claude Code itself, claudeModels.ts).
  if (spec.id === 'copilot') cli.models = COPILOT_MODELS.map((m) => ({ ...m }));
  try {
    // childEnv: never the hub's credentials. Only --version is run, so nothing is started, signed in or changed.
    const r = await run(bin, ['--version'], { env: childEnv(env as NodeJS.ProcessEnv) as Env, timeoutMs: COMMAND_DEADLINE_MS });
    if (r.code === 0) {
      const v = versionOf(r.out || r.err);
      if (v) cli.version = v;
    }
  } catch {
    // version unknown is fine
  }
  return cli;
}

// ---------------------------------------------------------------------------- local runtimes

const isLoopback = (h: string): boolean => ['127.0.0.1', 'localhost', '::1', '[::1]', '0.0.0.0'].includes(h);

/** The port Ollama is told to listen on (OLLAMA_HOST), when it is this computer's own address; else the default. */
export function ollamaPort(env: Env, fallback = DEFAULT_PORTS.ollama): number {
  const raw = (env.OLLAMA_HOST ?? '').trim().replace(/^https?:\/\//, '');
  if (!raw) return fallback;
  const m = /^(\[[^\]]+\]|[^:]*)(?::(\d{1,5}))?/.exec(raw);
  if (!m) return fallback;
  const host = m[1] || '127.0.0.1';
  if (!isLoopback(host)) return fallback;
  const p = Number(m[2]);
  return Number.isInteger(p) && p > 0 && p < 65536 ? p : fallback;
}

async function getJson(f: typeof fetch, port: number, path: string): Promise<unknown | null> {
  try {
    // Never follow a redirect: another program on the port could send this computer to a host that is not its own.
    const res = await f(`http://127.0.0.1:${port}${path}`, { signal: AbortSignal.timeout(HTTP_DEADLINE_MS), headers: { accept: 'application/json' }, redirect: 'manual' });
    if (!res.ok || res.status < 200 || res.status > 299) return null;
    return JSON.parse(await readCapped(res, MAX_BODY_BYTES));
  } catch {
    return null;
  }
}

const rec = (v: unknown): Record<string, unknown> | null => (v && typeof v === 'object' && !Array.isArray(v) ? (v as Record<string, unknown>) : null);
const arr = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const num = (v: unknown): number | undefined => (typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : undefined);
const str = (v: unknown, max = 200): string | undefined => (typeof v === 'string' && v.length > 0 ? v.slice(0, max) : undefined);

async function probeOllama(f: typeof fetch, port: number, installed: boolean): Promise<LocalRuntime> {
  const out: LocalRuntime = { id: 'ollama', name: 'Ollama', port, installed, running: false, models: [] };
  const [verRaw, tagsRaw, psRaw] = await Promise.all([getJson(f, port, '/api/version'), getJson(f, port, '/api/tags'), getJson(f, port, '/api/ps')]);
  const ver = rec(verRaw);
  const tags = rec(tagsRaw);
  // Both must look like Ollama's: some other program on the port is not Ollama.
  if (!str(ver?.version) && !Array.isArray(tags?.models)) return out;
  out.running = true;
  out.installed = true;
  const v = str(ver?.version, 40);
  if (v) out.version = v;
  const loaded = new Set<string>();
  for (const m of arr(rec(psRaw)?.models)) {
    const n = str(rec(m)?.name);
    if (n) loaded.add(n);
  }
  for (const m of arr(tags?.models).slice(0, MAX_MODELS)) {
    const r = rec(m);
    const name = str(r?.name) ?? str(r?.model);
    if (!name) continue;
    out.models.push({ name, ...(num(r?.size) !== undefined ? { sizeBytes: num(r?.size) } : {}), loaded: loaded.has(name) });
  }
  return out;
}

async function probeLmStudio(f: typeof fetch, port: number): Promise<LocalRuntime> {
  const out: LocalRuntime = { id: 'lmstudio', name: 'LM Studio', port, running: false, models: [] };
  // LM Studio's own listing says which models are loaded; the common /v1/models listing is the fallback.
  const rich = rec(await getJson(f, port, '/api/v0/models'));
  const list = Array.isArray(rich?.data) ? rich : rec(await getJson(f, port, '/v1/models'));
  if (!Array.isArray(list?.data)) return out;
  out.running = true;
  for (const m of arr(list?.data)) {
    const r = rec(m);
    const name = str(r?.id);
    if (!name) continue;
    if (r?.type === 'embeddings' || r?.type === 'embedding') continue; // not for chat
    out.models.push({ name, ...(r?.state !== undefined ? { loaded: r.state === 'loaded' } : {}) });
    if (out.models.length >= MAX_MODELS) break;
  }
  return out;
}

async function probeLlamaCpp(f: typeof fetch, port: number): Promise<LocalRuntime> {
  const out: LocalRuntime = { id: 'llamacpp', name: 'llama.cpp server', port, running: false, models: [] };
  // Port 8080 is used by many programs: only llama-server's own /health ({"status":"ok"}) counts.
  const health = rec(await getJson(f, port, '/health'));
  if (typeof health?.status !== 'string') return out;
  out.running = true;
  for (const m of arr(rec(await getJson(f, port, '/v1/models'))?.data).slice(0, MAX_MODELS)) {
    const r = rec(m);
    const name = str(r?.id);
    if (name) out.models.push({ name: name.replace(/^.*[\\/]/, ''), loaded: health.status === 'ok', ...(num(rec(r?.meta)?.size) !== undefined ? { sizeBytes: num(rec(r?.meta)?.size) } : {}) });
  }
  return out;
}

export async function probeRuntimes(o: DiscoverOptions = {}): Promise<LocalRuntime[]> {
  const env = o.env ?? process.env;
  const f = o.fetchFn ?? fetch;
  const pf = o.platform ?? platform();
  const home = o.home ?? homedir();
  const c: Ctx = { env, home, platform: pf, profilesDir: o.profilesDir };
  const ports = { ...DEFAULT_PORTS, ollama: ollamaPort(env), ...o.ports };
  const ollamaInstalled = findOnPath('ollama', searchEnv(c), pf) !== null || (pf === 'darwin' && existsSync('/Applications/Ollama.app'));
  return Promise.all([probeOllama(f, ports.ollama, ollamaInstalled), probeLmStudio(f, ports.lmstudio), probeLlamaCpp(f, ports.llamacpp)]);
}

// ---------------------------------------------------------------------------- hardware

/** `nvidia-smi` output (csv, no header, MiB) -> graphics cards. */
export function parseNvidiaSmi(out: string): { name: string; vramBytes?: number }[] {
  const gpus: { name: string; vramBytes?: number }[] = [];
  for (const line of out.split(/\r?\n/)) {
    const m = /^\s*(.+?)\s*,\s*(\d+(?:\.\d+)?)\s*$/.exec(line);
    if (m) gpus.push({ name: m[1]!, vramBytes: Math.round(Number(m[2]) * 1024 * 1024) });
  }
  return gpus.slice(0, 16);
}

/** `rocm-smi --showproductname --showmeminfo vram --json` -> cards (AMD). */
export function parseRocmSmi(out: string): { name: string; vramBytes?: number }[] {
  try {
    const j = rec(JSON.parse(out));
    if (!j) return [];
    const gpus: { name: string; vramBytes?: number }[] = [];
    for (const [k, v] of Object.entries(j)) {
      const r = rec(v);
      if (!/^card\d+$/.test(k) || !r) continue;
      const total = Number(r['VRAM Total Memory (B)']);
      gpus.push({ name: str(r['Card Series']) ?? str(r['Card series']) ?? str(r['Card model']) ?? 'AMD GPU', ...(Number.isFinite(total) && total > 0 ? { vramBytes: total } : {}) });
    }
    return gpus.slice(0, 16);
  } catch {
    return [];
  }
}

async function probeGpus(c: Ctx, run: RunFn, archName: string, cpuModel: string, ramTotal: number): Promise<LocalHardware['gpus']> {
  if (c.platform === 'darwin' && archName === 'arm64') return [{ name: cpuModel || 'Apple silicon', vramBytes: ramTotal, unified: true }];
  const env = childEnv(searchEnv(c) as NodeJS.ProcessEnv) as Env;
  const nv = await run('nvidia-smi', ['--query-gpu=name,memory.total', '--format=csv,noheader,nounits'], { env, timeoutMs: COMMAND_DEADLINE_MS }).catch(() => null);
  if (nv && nv.code === 0) {
    const g = parseNvidiaSmi(nv.out);
    if (g.length) return g;
  }
  if (c.platform === 'linux') {
    const amd = await run('rocm-smi', ['--showproductname', '--showmeminfo', 'vram', '--json'], { env, timeoutMs: COMMAND_DEADLINE_MS }).catch(() => null);
    if (amd && amd.code === 0) {
      const g = parseRocmSmi(amd.out);
      if (g.length) return g;
    }
  }
  return [];
}

export function modelBudget(ramTotal: number, gpus: LocalHardware['gpus']): number {
  const unified = gpus.some((g) => g.unified);
  const vram = unified ? 0 : gpus.reduce((s, g) => s + (g.vramBytes ?? 0), 0);
  if (vram > 0) return vram;
  return Math.floor(ramTotal * (unified ? 0.7 : 0.6));
}

function diskFree(dir: string): number | undefined {
  try {
    const s = statfsSync(dir);
    return Number(s.bavail) * Number(s.bsize);
  } catch {
    return undefined;
  }
}

export async function probeHardware(o: DiscoverOptions = {}): Promise<LocalHardware> {
  const env = o.env ?? process.env;
  const pf = o.platform ?? platform();
  const home = o.home ?? homedir();
  const run = o.run ?? realRun;
  const c: Ctx = { env, home, platform: pf, profilesDir: o.profilesDir };
  const cpu = cpus();
  const cpuModel = o.hardware?.cpuModel ?? (cpu[0]?.model ?? 'unknown').replace(/\s+/g, ' ').trim();
  const ramTotal = o.hardware?.totalmem ?? totalmem();
  const ramFree = o.hardware?.freemem ?? freemem();
  const archName = o.arch ?? arch();
  const gpus = await probeGpus(c, run, archName, cpuModel, ramTotal);
  const vramTotal = gpus.filter((g) => !g.unified).reduce((s, g) => s + (g.vramBytes ?? 0), 0);
  const modelDir = env.OLLAMA_MODELS?.trim() || join(home, '.ollama');
  const disk = diskFree(existsSync(modelDir) ? modelDir : home);
  return {
    os: pf,
    arch: archName,
    cpuModel,
    cpuCores: o.hardware?.cpuCores ?? cpu.length,
    ramTotalBytes: ramTotal,
    ramFreeBytes: ramFree,
    gpus,
    vramTotalBytes: vramTotal,
    modelBudgetBytes: modelBudget(ramTotal, gpus),
    ...(disk !== undefined ? { diskFreeBytes: disk } : {}),
  };
}

// ---------------------------------------------------------------------------- the whole report

export function summarize(clis: LocalCli[], runtimes: LocalRuntime[]): LocalAiReport['summary'] {
  const usableClis = clis.filter((x) => x.usable).length;
  const running = runtimes.filter((r) => r.running);
  const localModels = running.reduce((s, r) => s + r.models.length, 0);
  return { usableClis, runningRuntimes: running.length, localModels, best: usableClis > 0 ? 'cli' : localModels > 0 ? 'runtime' : 'none' };
}

/** Look at this computer. Never throws; the whole scan is a few seconds at most (probes run side by side). */
export async function discoverLocalAi(o: DiscoverOptions = {}): Promise<LocalAiReport> {
  const now = o.now ?? Date.now;
  const t0 = now();
  const env = o.env ?? process.env;
  const c: Ctx = { env, home: o.home ?? homedir(), platform: o.platform ?? platform(), profilesDir: o.profilesDir };
  const run = o.run ?? realRun;
  const [clis, runtimes, hardware] = await Promise.all([
    Promise.all(CLI_SPECS.map((s) => probeCli(s, c, run).catch((): LocalCli => ({ id: s.id, name: s.name, installed: false, login: 'no', usable: false })))),
    probeRuntimes(o).catch((): LocalRuntime[] => []),
    probeHardware(o).catch(
      (): LocalHardware => ({ os: c.platform, arch: o.arch ?? arch(), cpuModel: 'unknown', cpuCores: 0, ramTotalBytes: 0, ramFreeBytes: 0, gpus: [], vramTotalBytes: 0, modelBudgetBytes: 0 }),
    ),
  ]);
  return { v: 1, scannedAt: new Date(t0).toISOString(), tookMs: now() - t0, clis, runtimes, hardware, summary: summarize(clis, runtimes) };
}

/** The sign-in state of the tools already found, read again (files only: cheap), so a new sign-in shows within a minute. */
export function refreshLogins(clis: LocalCli[], o: DiscoverOptions = {}): LocalCli[] {
  const c: Ctx = { env: o.env ?? process.env, home: o.home ?? homedir(), platform: o.platform ?? platform(), profilesDir: o.profilesDir };
  return clis.map((x) => {
    const spec = CLI_SPECS.find((s) => s.id === x.id);
    if (!spec || !x.installed) return x;
    const login = detectLogin(spec, c);
    const { loginVia: _v, ...rest } = x;
    return { ...rest, ...login, usable: login.login !== 'no' };
  });
}

/** What counts as "something changed": everything except the time of the scan and the free RAM. */
export function reportFingerprint(r: LocalAiReport): string {
  const { scannedAt: _s, tookMs: _t, hardware, machine, health, ...rest } = r;
  const { ramFreeBytes: _f, diskFreeBytes: _d, ...hw } = hardware;
  const { checkedAt: _m, ...mach } = machine ?? ({} as NonNullable<LocalAiReport['machine']>);
  const { checkedAt: _h, ...hl } = health ?? ({} as NonNullable<LocalAiReport['health']>);
  return JSON.stringify({ ...rest, hardware: hw, machine: mach, health: hl });
}
