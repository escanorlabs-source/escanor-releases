/**
 * Answers a `local_ask` from the hub (PB4): walks the engines the router picked, one at a time, and moves to the next ONLY when one
 * fails (not signed in, usage limit, model missing, error, empty answer). A slow engine is never given up on; a quiet stretch is
 * only reported (`silence`). Every request ends with exactly one `done` or `failed` event, whatever happens.
 */
import { existsSync, realpathSync, statSync } from 'node:fs';
import { relative, resolve, isAbsolute } from 'node:path';
import type { AgentLocalAskEvent, HubLocalAsk, LocalAiReport, LocalAskEvent, OwnFailureCode } from '@remote-harness/shared';
import { askCli, type CliAsk } from './cliAnswer.js';
import { EngineFailure, type FailureReason } from './engineError.js';
import { resourceOfEngine, type OwnComputer } from './ownAi.js';
import { askRuntime, type ChatMessage, type RuntimeAsk } from './localEngine.js';
import { pullModel } from './ollamaPull.js';
import { exactCandidate, planEngines, type Candidate } from './router.js';

export type CloudAsk = { messages: ChatMessage[]; task: HubLocalAsk['task']; signal: AbortSignal; onText: (delta: string) => void; /** What failed before the cloud was asked. */ tried: { engine: string; why: string }[] };

export type AskerDeps = {
  /** The latest AI report of this computer (null before the first scan finished). */
  report: () => LocalAiReport | null;
  /** Look again (after a download). Optional. */
  rescan?: () => Promise<void>;
  send: (m: AgentLocalAskEvent) => void;
  /** The cloud step. Absent = this agent has none (the router then never offers it). */
  cloud?: (a: CloudAsk) => Promise<string>;
  /** Injectable for tests. */
  cli?: (a: CliAsk) => Promise<string>;
  runtime?: (a: RuntimeAsk) => Promise<string>;
  pull?: typeof pullModel;
  silenceMs?: number;
  now?: () => number;
  maxActive?: number;
  /** How long a download question waits for a person (default 30 minutes). */
  askWaitMs?: number;
  /** Extra CliAsk fields (tests: env, home, platform). */
  cliExtra?: Partial<CliAsk>;
  /** The rules for work from the router (switches, busy, locked). Absent = this agent takes no jobs from outside. */
  own?: OwnComputer;
  /** Tasks may only work inside this folder (the agent's projects folder). */
  projectsRoot?: string;
};

const CODE_OF: Record<FailureReason, OwnFailureCode> = { unavailable: 'not_installed', auth: 'signed_out', limit: 'limited', model_missing: 'model_missing', error: 'error', empty: 'error', cancelled: 'cancelled', declined: 'error' };

/** The folder a task may work in: it must exist and be inside the root. Null (with the reason) when not. */
export function taskFolder(cwd: string | undefined, root: string | undefined): { ok: true; dir: string } | { ok: false; message: string } {
  if (!cwd?.trim()) return { ok: false, message: 'A task needs a folder to work in.' };
  if (!root) return { ok: false, message: 'This computer has no projects folder set up for tasks.' };
  try {
    const dir = realpathSync(resolve(cwd));
    const base = realpathSync(resolve(root));
    const rel = relative(base, dir);
    if (rel.startsWith('..') || isAbsolute(rel)) return { ok: false, message: 'That folder is outside this computer\'s projects folder, so it is not used for tasks.' };
    if (!existsSync(dir) || !statSync(dir).isDirectory()) return { ok: false, message: 'That folder does not exist on this computer.' };
    return { ok: true, dir };
  } catch {
    return { ok: false, message: 'That folder does not exist on this computer.' };
  }
}

type Active = {
  ctl: AbortController;
  seq: number;
  /** Waiting for the person's yes/no to a download. */
  pullWait: ((approve: boolean) => void) | null;
  /** The link dropped while it waited for the yes/no. */
  pullLost?: boolean;
  /** The final event went out. */
  ended: boolean;
};

const MAX_ACTIVE = 6;

type Answer = { text: string; /** The engine that really answered, when it is not the candidate (a download, then the model). */ engine?: string; label?: string };

export class LocalAsker {
  private readonly active = new Map<string, Active>();
  constructor(private readonly d: AskerDeps) {}

  get activeCount(): number {
    return this.active.size;
  }

  /** Starts answering; never throws. */
  start(msg: HubLocalAsk): void {
    if (this.active.has(msg.requestId)) return; // the hub sent it twice
    const a: Active = { ctl: new AbortController(), seq: 0, pullWait: null, ended: false };
    if (this.active.size >= (this.d.maxActive ?? MAX_ACTIVE)) {
      this.emit(msg.requestId, a, { kind: 'failed', message: 'This computer is already answering several questions. Try again in a moment.', tried: [] });
      return;
    }
    this.active.set(msg.requestId, a);
    void this.run(msg, a)
      .catch((err) => {
        // Unreachable by design (run() ends every path itself); this is the net under it.
        this.finish(msg.requestId, a, { kind: 'failed', message: `Something went wrong while answering: ${err instanceof Error ? err.message : String(err)}`, tried: [] });
      })
      .finally(() => this.active.delete(msg.requestId));
  }

  cancel(requestId: string): void {
    const a = this.active.get(requestId);
    if (!a) return;
    a.ctl.abort();
    a.pullWait?.(false);
  }

  /** The person's yes or no to a download. */
  answerPull(requestId: string, approve: boolean): void {
    const a = this.active.get(requestId);
    const w = a?.pullWait;
    if (!a || !w) return;
    a.pullWait = null;
    w(approve);
  }

  /** The hub link dropped: nobody is left to answer a download question, so those requests end (the answer would never arrive). */
  dropWaiting(): void {
    for (const a of this.active.values()) {
      const w = a.pullWait;
      if (!w) continue;
      a.pullWait = null;
      a.pullLost = true;
      w(false);
    }
  }

  cancelAll(): void {
    for (const id of [...this.active.keys()]) this.cancel(id);
  }

  // ------------------------------------------------------------------------------------------------------------------

  private emit(requestId: string, a: Active, event: LocalAskEvent): void {
    try {
      this.d.send({ type: 'local_ask_event', requestId, seq: ++a.seq, event });
    } catch {
      // the link is down: the hub asks again or the person does; the answer is not lost to a throw here
    }
  }

  /** The one and only final event of a request. */
  private finish(requestId: string, a: Active, event: Extract<LocalAskEvent, { kind: 'done' | 'failed' }>): void {
    if (a.ended) return;
    a.ended = true;
    this.emit(requestId, a, event);
  }

  private messages(msg: HubLocalAsk): ChatMessage[] {
    const m: ChatMessage[] = [];
    if (msg.system?.trim()) m.push({ role: 'system', content: msg.system });
    for (const h of msg.history ?? []) if (h && (h.role === 'user' || h.role === 'assistant') && typeof h.content === 'string' && h.content) m.push({ role: h.role, content: h.content });
    m.push({ role: 'user', content: msg.prompt });
    return m;
  }

  private async run(msg: HubLocalAsk, a: Active): Promise<void> {
    const id = msg.requestId;
    const now = this.d.now ?? Date.now;
    const t0 = now();
    const tried: { engine: string; label: string; why: string }[] = [];
    if (typeof msg.prompt !== 'string' || !msg.prompt.trim()) {
      this.finish(id, a, { kind: 'failed', message: 'There was nothing to answer: the question was empty.', tried });
      return;
    }
    const messages = this.messages(msg);
    const report = this.d.report();
    const router = msg.fromRouter === true;
    const mode = msg.mode === 'task' ? 'task' : 'answer';
    let cwd: string | undefined;
    if (router) {
      // Work from outside: the machine says no up front (one line, nothing started) when the tool is off, signed out, at its limit, the screen is locked or the computer is busy.
      const refuse = (code: OwnFailureCode, message: string): void => this.finish(id, a, { kind: 'failed', message, tried, code, refused: true, ...(msg.jobId ? { jobId: msg.jobId } : {}) });
      if (!this.d.own) return refuse('off', 'This computer does not take AI jobs from Escanor.');
      if (msg.resource && !exactCandidate(msg.resource, report) && resourceOfEngine(msg.resource)) return refuse('not_supported', `${msg.resource} cannot run jobs yet.`);
      const g = await this.d.own.gate(msg.resource, mode, report);
      if (!g.ok) return refuse(g.code, g.message);
      if (mode === 'task') {
        const f = taskFolder(msg.cwd, this.d.projectsRoot);
        if (!f.ok) return refuse('bad_folder', f.message);
        cwd = f.dir;
      }
    }
    let plan = planEngines(report, msg.task, { prefer: msg.prefer, allowCloud: !router && msg.allowCloud === true, allowPull: router ? false : msg.allowPull, cloudAvailable: Boolean(this.d.cloud) });
    if (router && msg.resource) {
      const c = exactCandidate(msg.resource, report);
      plan = { candidates: c ? [c] : [], notes: [] };
    } else if (router && mode === 'task') {
      plan = { ...plan, candidates: plan.candidates.filter((c) => c.kind === 'cli') };
    }
    for (const n of plan.notes) this.emit(id, a, { kind: 'skipped', engine: n.engine, label: n.label, why: n.why });
    if (plan.candidates.length === 0) {
      this.finish(id, a, { kind: 'failed', message: noEngineMessage(report, plan.notes.map((n) => n.why)), tried, code: 'not_installed', ...(msg.jobId ? { jobId: msg.jobId } : {}), ...(router ? { refused: true } : {}) });
      return;
    }

    let declined = '';
    let firstTextAt: number | null = null;
    let lastCode: OwnFailureCode = 'error';
    const jobId = msg.jobId ? { jobId: msg.jobId } : {};
    const onText = (delta: string): void => {
      firstTextAt ??= now();
      this.emit(id, a, { kind: 'text', text: delta });
    };
    for (const cand of plan.candidates) {
      if (a.ctl.signal.aborted) break;
      const rid = resourceOfEngine(cand.engine);
      // A job from the router holds its tool while it runs: a second job for the same tool, or a third in all, is told "busy".
      const release = router && rid && this.d.own ? this.d.own.begin(rid) : null;
      if (router && rid && this.d.own && !release) {
        const why = 'This computer is already running as many jobs for Escanor as it takes.';
        tried.push({ engine: cand.engine, label: cand.label, why });
        lastCode = 'busy';
        this.emit(id, a, { kind: 'skipped', engine: cand.engine, label: cand.label, why });
        continue;
      }
      try {
        firstTextAt = null;
        const r = await this.tryOne(cand, msg, a, messages, onText, tried, mode, cwd);
        this.finish(id, a, { kind: 'done', engine: r.engine ?? cand.engine, label: r.label ?? cand.label, text: r.text, ms: now() - t0, ...(firstTextAt !== null ? { startMs: firstTextAt - t0 } : {}), ...jobId });
        return;
      } catch (err) {
        const f = err instanceof EngineFailure ? err : new EngineFailure('error', err instanceof Error ? err.message : String(err));
        if (f.reason === 'cancelled') break;
        lastCode = CODE_OF[f.reason];
        if (f.reason === 'limit' && rid) this.d.own?.markLimited(rid, f.message);
        tried.push({ engine: cand.engine, label: cand.label, why: f.message });
        this.emit(id, a, { kind: 'skipped', engine: cand.engine, label: cand.label, why: f.message });
        if (f.reason === 'declined') {
          declined = f.message; // still tries what comes next (the cloud, when allowed): only the download was refused
        }
      } finally {
        release?.();
      }
    }
    if (a.ctl.signal.aborted) {
      this.finish(id, a, { kind: 'failed', message: 'Cancelled.', tried, cancelled: true, code: 'cancelled', ...jobId });
      return;
    }
    this.finish(id, a, {
      kind: 'failed',
      message: declined && tried.length === 1 ? declined : `No AI on this computer could answer. ${tried.map((t) => `${t.label}: ${t.why}`).join(' ')}`.trim(),
      tried,
      code: tried.length ? lastCode : 'not_installed',
      ...jobId,
    });
  }

  private async tryOne(c: Candidate, msg: HubLocalAsk, a: Active, messages: ChatMessage[], onText: (d: string) => void, tried: { engine: string; why: string }[], mode: 'answer' | 'task' = 'answer', cwd?: string): Promise<Answer> {
    const id = msg.requestId;
    const signal = a.ctl.signal;
    const silenceMs = this.d.silenceMs;
    const onSilence = (engine: string) => (seconds: number) => this.emit(id, a, { kind: 'silence', engine, seconds });
    switch (c.kind) {
      case 'cli': {
        this.emit(id, a, { kind: 'engine', engine: c.engine, label: c.label });
        return { text: await (this.d.cli ?? askCli)({ cli: c.cli, messages, signal, onText, onSilence: onSilence(c.engine), silenceMs, mode, ...(cwd ? { cwd } : {}), ...this.d.cliExtra }) };
      }
      case 'runtime': {
        this.emit(id, a, { kind: 'engine', engine: c.engine, label: c.label });
        return { text: await (this.d.runtime ?? askRuntime)({ port: c.port, model: c.model, messages, signal, onText, onSilence: onSilence(c.engine), silenceMs }) };
      }
      case 'pull': {
        const approved = await new Promise<boolean>((resolve) => {
          if (signal.aborted) return resolve(false);
          a.pullWait = resolve;
          // Waiting for a person is not a run, but a question nobody answers for hours must not hold a slot for ever.
          const t = setTimeout(() => {
            if (a.pullWait === resolve) {
              a.pullWait = null;
              a.pullLost = true;
              resolve(false);
            }
          }, this.d.askWaitMs ?? 30 * 60_000);
          t.unref?.();
          this.emit(id, a, { kind: 'pull_needed', model: c.model, sizeBytes: c.sizeBytes, diskFreeBytes: this.d.report()?.hardware.diskFreeBytes });
        });
        a.pullWait = null;
        if (signal.aborted) throw new EngineFailure('cancelled', 'Cancelled.');
        if (!approved && a.pullLost) throw new EngineFailure('declined', 'Nobody answered the question about downloading a model, so there is nothing on this computer to answer with.');
        if (!approved) throw new EngineFailure('declined', 'You chose not to download a model, so there is nothing on this computer to answer with.');
        await (this.d.pull ?? pullModel)({ port: c.port, model: c.model, signal, onProgress: (p) => this.emit(id, a, { kind: 'pull_progress', model: p.model, completedBytes: p.completedBytes, totalBytes: p.totalBytes, status: p.status }) });
        await this.d.rescan?.().catch(() => undefined);
        const label = `Ollama (${c.model})`;
        const engine = `runtime:ollama:${c.model}`;
        this.emit(id, a, { kind: 'engine', engine, label });
        return { text: await (this.d.runtime ?? askRuntime)({ port: c.port, model: c.model, messages, signal, onText, onSilence: onSilence(engine), silenceMs }), engine, label };
      }
      case 'cloud': {
        this.emit(id, a, { kind: 'engine', engine: c.engine, label: c.label });
        if (!this.d.cloud) throw new EngineFailure('unavailable', 'The cloud model is not available on this computer.');
        let out: string;
        try {
          out = await this.d.cloud({ messages, task: msg.task, signal, onText, tried: tried.map((t) => ({ engine: t.engine, why: t.why })) });
        } catch (err) {
          if (err instanceof EngineFailure) throw err;
          throw new EngineFailure(signal.aborted ? 'cancelled' : 'error', err instanceof Error ? err.message : String(err));
        }
        if (!out.trim()) throw new EngineFailure('empty', 'The cloud model sent an empty answer.');
        return { text: out };
      }
    }
  }
}

/** Why nothing could even be tried, in words for the person. */
export function noEngineMessage(report: LocalAiReport | null, reasons: string[]): string {
  if (!report) return 'This computer has not finished looking at which AI it has. Try again in a minute.';
  const why = reasons.length ? ` ${reasons.join(' ')}` : '';
  return `No AI is ready on this computer.${why} Sign in to Claude Code, Codex, Gemini CLI or GitHub Copilot CLI here, or start a local model program such as Ollama.`.trim();
}
