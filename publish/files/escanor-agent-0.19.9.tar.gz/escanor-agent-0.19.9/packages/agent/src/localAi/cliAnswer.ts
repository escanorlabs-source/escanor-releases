/**
 * An engine that gets an ANSWER from a signed-in AI tool (Claude Code, Codex, Gemini CLI, GitHub Copilot CLI) run once in its print mode with no way to
 * touch files: Claude with no tools at all, Codex in its read-only sandbox, Gemini in plan mode, Copilot with
 * every change, command and read refused, all in an empty scratch folder.
 * No time limit; a quiet stretch is only reported. The tool uses the computer's own sign-in.
 */
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { Readable, Writable } from 'node:stream';
import type { LocalCliId } from '@remote-harness/shared';
import { AGENT_CHAT_ENV, childEnv } from '../childEnv.js';
import { isLimitText, killTree, type CliChild } from '../cliEngine.js';
import { findCliOnPath, launchSpec, stripAnsi, withNodeOnPath } from '../cliTools.js';
import { MIN_NODE, withNewNode } from '../nodeRuntime.js';
import { searchEnv } from './discover.js';
import { EngineFailure } from './engineError.js';
import { DEFAULT_SILENCE_MS, type ChatMessage } from './localEngine.js';

export type CliAsk = {
  cli: LocalCliId;
  messages: ChatMessage[];
  signal?: AbortSignal;
  onText: (delta: string) => void;
  onSilence?: (seconds: number) => void;
  silenceMs?: number;
  /** Injectable for tests. */
  env?: NodeJS.ProcessEnv;
  home?: string;
  platform?: NodeJS.Platform;
  bin?: string;
  /** `task`: the tool may read and search files in [cwd] (never edit, never run commands). Default `answer`: no tools at all. */
  mode?: 'answer' | 'task';
  /** The folder a task works in (must exist). */
  cwd?: string;
  spawnFn?: (bin: string, args: string[], opts: { cwd: string; env: Record<string, string | undefined> }) => CliChild;
  killGraceMs?: number;
};

/** The arguments of an answer-only run. The prompt goes on stdin (never on the command line). */
export function answerArgs(cli: LocalCliId, scratch: string, mode: 'answer' | 'task' = 'answer'): string[] {
  switch (cli) {
    case 'claude':
      // task: only the reading tools (the names Claude Code has for them); answer: no tools at all.
      return ['-p', '--output-format', 'text', '--tools', mode === 'task' ? 'Read,Grep,Glob' : '', '--strict-mcp-config', '--no-session-persistence', ...(mode === 'task' ? ['--permission-mode', 'dontAsk', '--allowedTools', 'Read,Grep,Glob'] : [])];
    case 'codex':
      return ['exec', '--skip-git-repo-check', '-s', 'read-only', '-C', scratch, '-'];
    case 'gemini':
      return ['-p', '', '--output-format', 'text', '--approval-mode', 'plan', '--skip-trust'];
    case 'copilot':
      // -p cannot ask, so nothing runs that is not allowed: no changes, no commands; an answer may not even read files.
      return ['-p', '', '--output-format', 'text', '-s', '--no-auto-update', '--no-ask-user', '--deny-tool=write', '--deny-tool=shell', ...(mode === 'task' ? [] : ['--deny-tool=read', '--deny-tool=url'])];
    default:
      throw new EngineFailure('unavailable', `${cli} cannot be used for answers yet.`);
  }
}

/** The whole conversation as one text for a tool that takes a single prompt. */
export function flatten(messages: ChatMessage[]): string {
  const system = messages.filter((m) => m.role === 'system').map((m) => m.content);
  const rest = messages.filter((m) => m.role !== 'system');
  if (rest.length === 1) return [...system, rest[0]!.content].join('\n\n');
  const talk = rest.map((m) => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n\n');
  return [...system, 'Conversation so far:', talk, 'Reply to the last User message.'].join('\n\n');
}

const NAMES: Record<string, string> = { claude: 'Claude Code', codex: 'Codex', gemini: 'Gemini CLI', copilot: 'GitHub Copilot CLI' };

/** What a tool's failure means for the router: a limit or a missing sign-in moves on to the next engine, with a readable reason. */
export function classify(cli: LocalCliId, text: string, code: number | null): EngineFailure {
  const name = NAMES[cli] ?? cli;
  const raw = stripAnsi(text).trim().slice(-600);
  if (isLimitText(raw)) return new EngineFailure('limit', `${name} has reached its usage limit. ${raw.slice(0, 300)}`.trim());
  if (/not logged in|please (log ?in|sign in)|login required|not signed in|unauthori[sz]ed|\b401\b|invalid api key|api key not valid|authenticat|credentials/i.test(raw)) {
    return new EngineFailure('auth', `${name} is not signed in on this computer. ${raw.slice(0, 200)}`.trim());
  }
  return new EngineFailure('error', raw ? `${name} stopped with an error: ${raw}` : `${name} stopped with an error (exit code ${code ?? 'unknown'}).`);
}

export async function askCli(a: CliAsk): Promise<string> {
  const env0 = a.env ?? process.env;
  const platform = a.platform ?? process.platform;
  const bin = a.bin ?? findCliOnPath(a.cli, searchEnv({ env: env0, home: a.home ?? env0.HOME ?? env0.USERPROFILE ?? '', platform }), platform);
  if (!bin) throw new EngineFailure('unavailable', `${NAMES[a.cli] ?? a.cli} is not installed on this computer.`);
  if (a.signal?.aborted) throw new EngineFailure('cancelled', 'Cancelled.');
  const scratch = mkdtempSync(join(tmpdir(), 'escanor-ask-'));
  // A task works in the folder it was given; an answer works in an empty scratch folder.
  const work = a.mode === 'task' && a.cwd ? a.cwd : scratch;
  try {
    const args = answerArgs(a.cli, work, a.mode ?? 'answer');
    const env0b = withNodeOnPath(childEnv(searchEnv({ env: env0, home: a.home ?? '', platform }) as NodeJS.ProcessEnv, { [AGENT_CHAT_ENV]: '1' }));
    // Gemini CLI needs a newer Node than a computer's first one may be.
    const env = a.cli === 'gemini' && !a.spawnFn ? withNewNode(env0b, MIN_NODE.gemini) : env0b;
    const child = (a.spawnFn ?? realSpawn)(bin, args, { cwd: work, env });
    return await collect(child, a, flatten(a.messages));
  } catch (err) {
    if (err instanceof EngineFailure) throw err;
    throw new EngineFailure('unavailable', `${NAMES[a.cli] ?? a.cli} could not be started: ${err instanceof Error ? err.message : String(err)}`);
  } finally {
    try {
      rmSync(scratch, { recursive: true, force: true, maxRetries: 3, retryDelay: 100 });
    } catch {
      // a folder Windows still holds: a left-over empty folder must never cost the answer
    }
  }
}

const realSpawn: NonNullable<CliAsk['spawnFn']> = (bin, args, opts) => {
  const l = launchSpec(bin);
  return spawn(l.command, [...l.args, ...args], { cwd: opts.cwd, env: opts.env, stdio: ['pipe', 'pipe', 'pipe'], detached: process.platform !== 'win32', windowsHide: true });
};

function collect(child: CliChild, a: CliAsk, prompt: string): Promise<string> {
  return new Promise((resolve, reject) => {
    let out = '';
    let err = '';
    let last = Date.now();
    let reported = 0;
    let done = false;
    const every = a.silenceMs ?? DEFAULT_SILENCE_MS;
    const timer = a.onSilence
      ? setInterval(() => {
          const quiet = Date.now() - last;
          const step = Math.floor(quiet / every);
          if (step > reported) {
            reported = step;
            a.onSilence?.(Math.round(quiet / 1000));
          }
        }, Math.max(5, Math.min(every / 2, 5_000)))
      : null;
    timer?.unref?.();
    const finish = (fn: () => void) => {
      if (done) return;
      done = true;
      if (timer) clearInterval(timer);
      a.signal?.removeEventListener('abort', onAbort);
      fn();
    };
    const onAbort = () => {
      try {
        killTree(child, 'SIGINT');
      } catch {
        // gone
      }
      const k = setTimeout(() => {
        try {
          killTree(child, 'SIGKILL');
        } catch {
          // gone
        }
      }, a.killGraceMs ?? 3000);
      k.unref?.();
      child.once('exit', () => clearTimeout(k));
      finish(() => reject(new EngineFailure('cancelled', 'Cancelled.')));
    };
    a.signal?.addEventListener('abort', onAbort, { once: true });
    (child.stdout as Readable | null)?.on('data', (b: Buffer) => {
      last = Date.now();
      reported = 0;
      const t = stripAnsi(b.toString('utf8'));
      if (out.length < 2_000_000) out += t;
      if (!done) a.onText(t);
    });
    (child.stderr as Readable | null)?.on('data', (b: Buffer) => {
      last = Date.now();
      reported = 0;
      err = (err + b.toString('utf8')).slice(-65_536);
    });
    child.once('error', (e: Error) =>
      finish(() => reject(new EngineFailure('unavailable', `${NAMES[a.cli] ?? a.cli} could not be started: ${(e as NodeJS.ErrnoException).code === 'ENOENT' ? 'it is not installed' : e.message}`))),
    );
    child.once('exit', (code: number | null) => {
      // The output may still be flowing in for a moment after the exit (a helper the tool left can hold it open).
      setTimeout(
        () =>
          finish(() => {
            const text = stripAnsi(out).trim();
            if (code === 0 && text) resolve(text);
            else if (code === 0) reject(new EngineFailure('empty', `${NAMES[a.cli] ?? a.cli} sent an empty answer.`));
            else reject(classify(a.cli, err || out, code));
          }),
        50,
      );
    });
    const stdin = child.stdin as Writable | null;
    stdin?.on('error', () => undefined);
    stdin?.end(prompt);
  });
}
