import { mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
// The agent loads HUB_TOKEN/HUB_URL from .env into process.env. Claude child
// processes run model-chosen shell commands, so anything they inherit can be
// read with `env`. HUB_TOKEN is shared by the whole tenant and lets its holder
// impersonate any VM, so it must never reach them. ANTHROPIC_API_KEY stays: it
// is the child's own credential when the VM isn't logged in via `claude`.
// ESCANOR_OUTBOX_KEY signs the agent's outbox (outboxKey.ts): a chat holding it could forge lines there.
/**
 * Set in the environment of every Claude chat the agent itself starts (SDK, `--input-format stream-json`). The phone-inbox hook
 * (terminalInbox.ts HOOK_SCRIPT) is for chats open in a terminal only: it exits at once when it sees this, because in an SDK
 * chat its SessionStart waiter holds the session up until a phone message arrives, so the chat never starts.
 */
export const AGENT_CHAT_ENV = 'ESCANOR_AGENT_CHAT';

const HUB_ONLY = ['HUB_TOKEN', 'HUB_URL', 'ESCANOR_OUTBOX_KEY'];

/**
 * The disk folder Claude children use for temporary files. /tmp can be a small RAM disk (and a private one per service), and a chat's
 * leftovers (virtual environments, clones, caches) filled it and the machine's memory. ESCANOR_CHILD_TMPDIR picks the folder, else it
 * is `tmp` inside the agent's data folder (DATA_DIR, as config.ts reads it).
 */
export function childTmpDir(base: NodeJS.ProcessEnv): string {
  return resolve(base.ESCANOR_CHILD_TMPDIR?.trim() || resolve(base.DATA_DIR || './data', 'tmp'));
}

export function childEnv(base: NodeJS.ProcessEnv, overrides: Record<string, string> = {}): Record<string, string | undefined> {
  const env: Record<string, string | undefined> = { ...base, ...overrides };
  for (const key of HUB_ONLY) delete env[key];
  // An explicit TMPDIR (a chat user's own, set by the caller) stays; unset or the plain /tmp gets the agent's disk folder.
  const explicit = (overrides.TMPDIR ?? base.TMPDIR)?.trim();
  if (process.platform !== 'win32' && (!explicit || explicit === '/tmp' || explicit === '/tmp/') ) {
    try {
      const dir = childTmpDir(base);
      mkdirSync(dir, { recursive: true, mode: 0o700 });
      env.TMPDIR = dir;
    } catch {
      // keep the old behaviour
    }
  }
  return env;
}
