import { mkdirSync, readFileSync, readdirSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import { desktopEnv, realRunner, type Runner } from './computerControl.js';

/**
 * Two small things the goal agent asks of a computer before a meeting (direct commands `av_check` and `quiet_notifications`):
 *
 *  - av_check: is there a camera, a microphone that is not muted, and sound that is neither muted nor nearly off? With `fix` it
 *    unmutes and lifts a very low volume, and says what it changed. It only reads device state and flips mute / volume, the same
 *    things the volume keys do; it never records, never opens the camera or the microphone.
 *  - quiet_notifications: pop-up banners off for N minutes (GNOME, dunst, mako), put back by itself when the time is up, even if
 *    this agent restarts (the earlier setting is kept in a small file). Turning it off by hand puts them back at once.
 *
 * Plain words come back in `say` (the hub passes only numbers and yes/no values in `data`).
 */

export type PrepDeps = {
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
  run?: Runner;
  /** Names of the camera devices (sysfs on Linux); tests hand in their own. */
  cameras?: () => string[] | null;
  now?: () => number;
};

export type AvReport = {
  /** null: could not tell on this computer. */
  camera: boolean | null;
  micFound: boolean | null;
  micMuted: boolean | null;
  /** 0 to 100, null when unknown. */
  volume: number | null;
  speakersMuted: boolean | null;
  fixed: string[];
};

const LOW_VOLUME = 25;
const RAISED_TO = 50;

export function linuxCameras(sys = '/sys/class/video4linux', read: (p: string) => string = (p) => readFileSync(p, 'utf8'), list: (p: string) => string[] = (p) => readdirSync(p)): string[] | null {
  try {
    return list(sys)
      .filter((d) => /^video\d+$/.test(d))
      .filter((d) => {
        try {
          return !/metadata/i.test(read(`${sys}/${d}/name`));
        } catch {
          return true;
        }
      });
  } catch {
    return null;
  }
}

/** "Volume: front-left: 22937 /  35% / -27.00 dB, front-right: ..." -> 35 */
export function pactlPercent(out: string): number | null {
  const m = /(\d{1,3})%/.exec(out);
  return m ? Math.min(100, Number(m[1])) : null;
}

/** "Mute: yes" / "Mute: no" */
export function pactlMuted(out: string): boolean | null {
  const m = /Mute:\s*(yes|no)/i.exec(out);
  return m ? m[1]!.toLowerCase() === 'yes' : null;
}

/** "Volume: 0.35" / "Volume: 0.35 [MUTED]" -> {percent, muted} */
export function wpctlVolume(out: string): { percent: number; muted: boolean } | null {
  const m = /Volume:\s*([0-9.]+)(\s*\[MUTED\])?/i.exec(out);
  return m ? { percent: Math.round(Number(m[1]) * 100), muted: Boolean(m[2]) } : null;
}

async function out(run: Runner, env: NodeJS.ProcessEnv, cmd: string, args: string[]): Promise<{ ok: boolean; missing: boolean; stdout: string }> {
  const r = await run({ cmd, args }, env);
  return { ok: r.code === 0, missing: r.missing, stdout: r.stdout };
}

async function linuxAv(fix: boolean, run: Runner, env: NodeJS.ProcessEnv, r: AvReport): Promise<void> {
  const pa = await out(run, env, 'pactl', ['get-default-sink']);
  if (pa.ok) {
    const sinkMute = pactlMuted((await out(run, env, 'pactl', ['get-sink-mute', '@DEFAULT_SINK@'])).stdout);
    const vol = pactlPercent((await out(run, env, 'pactl', ['get-sink-volume', '@DEFAULT_SINK@'])).stdout);
    r.speakersMuted = sinkMute;
    r.volume = vol;
    const sources = (await out(run, env, 'pactl', ['list', 'short', 'sources'])).stdout.split('\n').filter((l) => l.trim() && !/\.monitor\b/.test(l));
    r.micFound = sources.length > 0;
    r.micMuted = r.micFound ? pactlMuted((await out(run, env, 'pactl', ['get-source-mute', '@DEFAULT_SOURCE@'])).stdout) : null;
    if (fix) {
      if (r.micMuted === true && (await out(run, env, 'pactl', ['set-source-mute', '@DEFAULT_SOURCE@', '0'])).ok) {
        r.micMuted = false;
        r.fixed.push('unmuted the microphone');
      }
      if (r.speakersMuted === true && (await out(run, env, 'pactl', ['set-sink-mute', '@DEFAULT_SINK@', '0'])).ok) {
        r.speakersMuted = false;
        r.fixed.push('unmuted the speakers');
      }
      if (r.volume !== null && r.volume < LOW_VOLUME && (await out(run, env, 'pactl', ['set-sink-volume', '@DEFAULT_SINK@', `${RAISED_TO}%`])).ok) {
        r.fixed.push(`raised the volume from ${r.volume}% to ${RAISED_TO}%`);
        r.volume = RAISED_TO;
      }
    }
    return;
  }
  // PipeWire without the pulse tools
  const sink = wpctlVolume((await out(run, env, 'wpctl', ['get-volume', '@DEFAULT_AUDIO_SINK@'])).stdout);
  const src = wpctlVolume((await out(run, env, 'wpctl', ['get-volume', '@DEFAULT_AUDIO_SOURCE@'])).stdout);
  if (sink) {
    r.volume = sink.percent;
    r.speakersMuted = sink.muted;
  }
  r.micFound = src ? true : sink ? false : null;
  r.micMuted = src ? src.muted : null;
  if (fix) {
    if (src?.muted && (await out(run, env, 'wpctl', ['set-mute', '@DEFAULT_AUDIO_SOURCE@', '0'])).ok) {
      r.micMuted = false;
      r.fixed.push('unmuted the microphone');
    }
    if (sink?.muted && (await out(run, env, 'wpctl', ['set-mute', '@DEFAULT_AUDIO_SINK@', '0'])).ok) {
      r.speakersMuted = false;
      r.fixed.push('unmuted the speakers');
    }
    if (sink && sink.percent < LOW_VOLUME && (await out(run, env, 'wpctl', ['set-volume', '@DEFAULT_AUDIO_SINK@', `${RAISED_TO}%`])).ok) {
      r.fixed.push(`raised the volume from ${sink.percent}% to ${RAISED_TO}%`);
      r.volume = RAISED_TO;
    }
  }
}

async function macAv(fix: boolean, run: Runner, env: NodeJS.ProcessEnv, r: AvReport): Promise<void> {
  const osa = async (script: string) => (await out(run, env, 'osascript', ['-e', script])).stdout.trim();
  const outVol = Number(await osa('output volume of (get volume settings)'));
  const inVol = Number(await osa('input volume of (get volume settings)'));
  const muted = (await osa('output muted of (get volume settings)')) === 'true';
  if (Number.isFinite(outVol)) r.volume = outVol;
  r.speakersMuted = muted;
  if (Number.isFinite(inVol)) {
    r.micFound = true;
    r.micMuted = inVol === 0;
  }
  const cam = await out(run, env, 'system_profiler', ['SPCameraDataType']);
  if (cam.ok) r.camera = /Model ID/i.test(cam.stdout);
  if (fix) {
    if (r.micMuted && (await out(run, env, 'osascript', ['-e', 'set volume input volume 75'])).ok) {
      r.micMuted = false;
      r.fixed.push('turned the microphone up');
    }
    if (muted && (await out(run, env, 'osascript', ['-e', 'set volume without output muted'])).ok) {
      r.speakersMuted = false;
      r.fixed.push('unmuted the speakers');
    }
    if (r.volume !== null && r.volume < LOW_VOLUME && (await out(run, env, 'osascript', ['-e', `set volume output volume ${RAISED_TO}`])).ok) {
      r.fixed.push(`raised the volume from ${r.volume}% to ${RAISED_TO}%`);
      r.volume = RAISED_TO;
    }
  }
}

export async function checkAv(fix: boolean, d: PrepDeps = {}): Promise<AvReport> {
  const platform = d.platform ?? process.platform;
  const env = desktopEnv(d.env ?? process.env, platform);
  const run = d.run ?? realRunner;
  const r: AvReport = { camera: null, micFound: null, micMuted: null, volume: null, speakersMuted: null, fixed: [] };
  if (platform === 'linux') {
    const cams = (d.cameras ?? (() => linuxCameras()))();
    r.camera = cams === null ? null : cams.length > 0;
    await linuxAv(fix, run, env, r);
  } else if (platform === 'darwin') {
    await macAv(fix, run, env, r);
  }
  return r;
}

/** The plain sentence for an AvReport: what was found, what was changed. */
export function avSay(r: AvReport): string {
  const parts: string[] = [];
  parts.push(r.camera === true ? 'Camera found' : r.camera === false ? 'No camera found' : 'Camera not checked');
  parts.push(r.micFound === false ? 'no microphone found' : r.micMuted === true ? 'microphone is muted' : r.micFound === true ? 'microphone ready' : 'microphone not checked');
  if (r.volume !== null) parts.push(`volume ${r.volume}%${r.speakersMuted ? ' (muted)' : ''}`);
  else if (r.speakersMuted !== null) parts.push(r.speakersMuted ? 'speakers muted' : 'speakers on');
  let text = parts.join(', ') + '.';
  if (r.fixed.length) text += ` I ${r.fixed.join(' and ')}.`;
  return text;
}

export const avData = (r: AvReport): Record<string, unknown> => ({
  ...(r.camera !== null ? { camera: r.camera } : {}),
  ...(r.micFound !== null ? { micFound: r.micFound } : {}),
  ...(r.micMuted !== null ? { micMuted: r.micMuted } : {}),
  ...(r.volume !== null ? { volume: r.volume } : {}),
  ...(r.speakersMuted !== null ? { speakersMuted: r.speakersMuted } : {}),
  fixedCount: r.fixed.length,
});

// ------------------------------------------------------------------------------------------------ quiet notifications

type Saved = { kind: 'gnome' | 'dunst' | 'mako'; previous: string; until: number };

export const MAX_QUIET_MINUTES = 240;

const GNOME_KEY = ['org.gnome.desktop.notifications', 'show-banners'] as const;

export class QuietNotifications {
  private saved: Saved | null = null;

  constructor(private d: PrepDeps = {}, private file?: string) {
    if (file) {
      try {
        const s = JSON.parse(readFileSync(file, 'utf8')) as Saved;
        if (s && (s.kind === 'gnome' || s.kind === 'dunst' || s.kind === 'mako') && typeof s.until === 'number') this.saved = s;
      } catch {
        // nothing saved
      }
    }
  }

  private now = () => (this.d.now ?? Date.now)();
  private get platform() {
    return this.d.platform ?? process.platform;
  }
  private get env() {
    return desktopEnv(this.d.env ?? process.env, this.platform);
  }
  private get run() {
    return this.d.run ?? realRunner;
  }

  get until(): number | null {
    return this.saved ? this.saved.until : null;
  }

  private persist(): void {
    if (!this.file) return;
    try {
      mkdirSync(dirname(this.file), { recursive: true });
      const tmp = `${this.file}.tmp`;
      writeFileSync(tmp, JSON.stringify(this.saved ?? {}), { mode: 0o600 });
      renameSync(tmp, this.file);
    } catch {
      // the setting is also restored by the timer in this process
    }
  }

  private async detect(): Promise<Saved['kind'] | null> {
    if (this.platform !== 'linux') return null;
    const g = await this.run({ cmd: 'gsettings', args: ['get', ...GNOME_KEY] }, this.env);
    if (g.code === 0 && /(true|false)/.test(g.stdout)) return 'gnome';
    if ((await this.run({ cmd: 'dunstctl', args: ['is-paused'] }, this.env)).code === 0) return 'dunst';
    if ((await this.run({ cmd: 'makoctl', args: ['mode'] }, this.env)).code === 0) return 'mako';
    return null;
  }

  async start(minutes: number): Promise<{ ok: boolean; say: string; until?: number }> {
    const mins = Math.max(1, Math.min(MAX_QUIET_MINUTES, Math.floor(minutes) || 60));
    const until = this.now() + mins * 60_000;
    if (this.saved) {
      // already quiet: only the time is extended, the earlier setting stays the one to put back
      this.saved.until = Math.max(this.saved.until, until);
      this.persist();
      return { ok: true, say: `Notifications stay silenced for ${mins} minutes.`, until: this.saved.until };
    }
    const kind = await this.detect();
    if (!kind) return { ok: false, say: 'Silencing notifications is not set up for this kind of computer yet. They were left as they were.' };
    let previous = 'false';
    let ok = false;
    if (kind === 'gnome') {
      previous = /true/.test((await this.run({ cmd: 'gsettings', args: ['get', ...GNOME_KEY] }, this.env)).stdout) ? 'true' : 'false';
      ok = (await this.run({ cmd: 'gsettings', args: ['set', ...GNOME_KEY, 'false'] }, this.env)).code === 0;
    } else if (kind === 'dunst') {
      previous = /true/.test((await this.run({ cmd: 'dunstctl', args: ['is-paused'] }, this.env)).stdout) ? 'true' : 'false';
      ok = (await this.run({ cmd: 'dunstctl', args: ['set-paused', 'true'] }, this.env)).code === 0;
    } else {
      previous = ((await this.run({ cmd: 'makoctl', args: ['mode'] }, this.env)).stdout.trim().split(/\s+/).pop() || 'default').replace(/[^\w-]/g, '') || 'default';
      ok = (await this.run({ cmd: 'makoctl', args: ['mode', '-s', 'do-not-disturb'] }, this.env)).code === 0;
    }
    if (!ok) return { ok: false, say: 'Could not silence notifications on this computer. They were left as they were.' };
    this.saved = { kind, previous, until };
    this.persist();
    return { ok: true, say: `Notifications are silenced for ${mins} minutes.`, until };
  }

  /** Put the setting back (now, or when due). Returns true when something was restored. */
  async stop(): Promise<boolean> {
    const s = this.saved;
    if (!s) return false;
    this.saved = null;
    this.persist();
    if (s.kind === 'gnome') await this.run({ cmd: 'gsettings', args: ['set', ...GNOME_KEY, s.previous === 'true' ? 'true' : 'false'] }, this.env);
    else if (s.kind === 'dunst') await this.run({ cmd: 'dunstctl', args: ['set-paused', s.previous === 'true' ? 'true' : 'false'] }, this.env);
    else await this.run({ cmd: 'makoctl', args: ['mode', '-s', s.previous || 'default'] }, this.env);
    return true;
  }

  /** Called now and then (and at start-up): puts the setting back once its time is up. */
  async sweep(): Promise<void> {
    if (this.saved && this.saved.until <= this.now()) await this.stop();
  }
}

