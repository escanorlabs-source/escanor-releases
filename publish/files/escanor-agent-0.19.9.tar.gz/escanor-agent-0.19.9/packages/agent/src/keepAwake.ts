import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, readdirSync, readFileSync } from 'node:fs';

// Keep this machine from sleeping while the assistant is working for someone (a chat running, a message waiting, a prompt
// waiting for an answer), and let go the moment nothing runs. Built for a laptop: a cloud machine that is meant to sleep when
// idle (the hub's power control) is not affected, because nothing is held while idle.
//
// Limit: a user-level inhibitor stops the laptop sleeping on its own (idle timeout, the power button menu), not necessarily
// when the lid is closed on battery; many systems sleep on lid close whatever an app asks (logind's handle-lid-switch, and the
// firmware on some machines). That is deliberate: a closed laptop in a bag must not run hot.

/** 'on' = whenever working; 'ac' = only while plugged in; 'off' = never. */
export type KeepAwakeMode = 'on' | 'ac' | 'off';

export function keepAwakeModeFrom(raw: string | undefined): KeepAwakeMode {
  const v = raw?.trim().toLowerCase();
  if (!v) return 'on';
  if (v === '0' || v === 'off' || v === 'false' || v === 'no') return 'off';
  if (v === 'ac' || v === 'ac-only' || v === 'ac_only' || v === 'plugged') return 'ac';
  return 'on';
}

export interface Inhibitor {
  release(): void;
}

export interface AwakePlatform {
  /** Take a sleep lock; null if it could not be taken (tried again later). */
  acquire(why: string): Inhibitor | null;
  /** On mains power (true when it cannot tell, e.g. a desktop). */
  onAcPower(): boolean;
}

export class KeepAwake {
  private busy = false;
  private lock: Inhibitor | null = null;
  private stopped = false;

  constructor(private platform: AwakePlatform, private mode: KeepAwakeMode, private why = 'Escanor is working for you') {}

  get held(): boolean {
    return this.lock !== null;
  }

  setBusy(busy: boolean): void {
    this.busy = busy;
    this.refresh();
  }

  setMode(mode: KeepAwakeMode): void {
    this.mode = mode;
    this.refresh();
  }

  /** Re-decide: called when work starts or ends, the mode changes, and now and then (the plug may have changed). */
  refresh(): void {
    const want = !this.stopped && this.busy && this.mode !== 'off' && (this.mode === 'on' || this.platform.onAcPower());
    if (want && !this.lock) {
      try {
        this.lock = this.platform.acquire(this.why);
      } catch {
        this.lock = null;
      }
    } else if (!want && this.lock) {
      const l = this.lock;
      this.lock = null;
      try {
        l.release();
      } catch {
        // already gone
      }
    }
  }

  stop(): void {
    this.busy = false;
    this.refresh();
    this.stopped = true;
  }
}

// ---------- the real platforms ----------

export type InhibitCommand = { cmd: string; args: string[]; detached: boolean };

/**
 * The helper process that holds the lock for as long as it lives. Each also ends on its own if the agent dies, so a crash
 * can never leave the machine unable to sleep.
 */
export function inhibitCommand(platform: string, agentPid: number, why = 'Escanor is working for you'): InhibitCommand | null {
  if (platform === 'linux') {
    return {
      cmd: 'systemd-inhibit',
      args: [
        '--what=sleep:idle',
        '--mode=block',
        '--who=Escanor agent',
        `--why=${why}`,
        'sh',
        '-c',
        'while kill -0 "$1" 2>/dev/null; do sleep 5; done',
        'escanor-inhibit',
        String(agentPid),
      ],
      // Its own process group, so releasing ends the helper and the shell loop with it.
      detached: true,
    };
  }
  if (platform === 'darwin') return { cmd: 'caffeinate', args: ['-i', '-w', String(agentPid)], detached: false };
  if (platform === 'win32') {
    const script =
      'Add-Type -Namespace W -Name P -MemberDefinition \'[System.Runtime.InteropServices.DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);\'; ' +
      '[void][W.P]::SetThreadExecutionState(0x80000001); ' + // ES_CONTINUOUS | ES_SYSTEM_REQUIRED, held by this thread
      `while (Get-Process -Id ${agentPid} -ErrorAction SilentlyContinue) { Start-Sleep -Seconds 5 }`;
    return { cmd: 'powershell.exe', args: ['-NoProfile', '-NonInteractive', '-Command', script], detached: false };
  }
  return null;
}

/** From /sys/class/power_supply entries: true when a mains supply is online, or when there is no battery to run on. */
export function acFromSysfs(supplies: { type?: string; online?: string }[]): boolean {
  const mains = supplies.filter((s) => s.type === 'Mains' || s.type === 'USB' || s.type === 'USB_PD');
  if (mains.some((s) => s.online?.trim() === '1')) return true;
  return !supplies.some((s) => s.type === 'Battery');
}

function readSysfsSupplies(): { type?: string; online?: string }[] {
  const dir = '/sys/class/power_supply';
  if (!existsSync(dir)) return [];
  const read = (p: string): string | undefined => {
    try {
      return readFileSync(p, 'utf8').trim();
    } catch {
      return undefined;
    }
  };
  return readdirSync(dir).map((n) => ({ type: read(`${dir}/${n}/type`), online: read(`${dir}/${n}/online`) }));
}

class ProcessInhibitor implements Inhibitor {
  constructor(private child: ChildProcess, private groupLeader: boolean) {}
  release(): void {
    const pid = this.child.pid;
    try {
      if (this.groupLeader && pid) process.kill(-pid, 'SIGTERM');
      else this.child.kill('SIGTERM');
    } catch {
      // already gone
    }
  }
}

export function systemPlatform(os: string = process.platform): AwakePlatform {
  let warned = false;
  return {
    acquire(why) {
      const c = inhibitCommand(os, process.pid, why);
      if (!c) return null;
      try {
        const child = spawn(c.cmd, c.args, { stdio: 'ignore', detached: c.detached, windowsHide: true });
        let failed = false;
        child.on('error', (err) => {
          failed = true;
          if (!warned) {
            warned = true;
            console.warn(`Keep-awake is unavailable (${c.cmd}: ${err.message}); this machine may sleep while working.`);
          }
        });
        child.unref();
        return failed ? null : new ProcessInhibitor(child, c.detached);
      } catch {
        return null;
      }
    },
    onAcPower() {
      if (os === 'linux') return acFromSysfs(readSysfsSupplies());
      return true; // macOS and Windows: not told apart here, so "only on AC" holds like "on"
    },
  };
}
