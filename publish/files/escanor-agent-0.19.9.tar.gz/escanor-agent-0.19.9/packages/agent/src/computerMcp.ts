import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { COMPUTER_TOOLS, parseAction, runComputerAction, type Deps } from './computerControl.js';
import { ScreenLease, TypeGuard, readFocus, settle, type Frame } from './screenSafety.js';
import { raiseOpened, snapshotWindows } from './windowFocus.js';
import { RemoteSwitch } from './jarvis.js';
import type { Shot } from './screenControl.js';
import { LiveScreen, describeEvents, parseEvents, type LiveEvent } from './liveControl.js';
import { logSafety, type SafetyEvent } from './safetyLog.js';
import { defaultUndoRoot } from './undo.js';
import { CONSENT_NAME, NOTES_NAME, HIGHLIGHT_NAME, NoteLog, ScreenConsent, writeHighlight, SCREEN_HELP_DIR_ENV, SOCKET_NAME, askAgent, realHighlight } from './screenHelp.js';
import { SCREEN_DO_TOOL, SCREEN_HELP_TOOL, SCREEN_HELP_TOOLS, SCREEN_HELP_TOOL_NAMES, screenDoTool, screenHelpTool, type HelpDeps } from './screenHelpTools.js';
import { screenLocked } from './liveControl.js';
import { takeScreenshot } from './screenControl.js';
import { join } from 'node:path';
import { MESH_COMPUTER_ACTIONS, MESH_ACTIONS, MESH_PHONE_ACTIONS, MESH_WATCH_ACTIONS, MESH_KINDS, MESH_OPS, MESH_SOCKET_NAME, askMeshAgent, parseMeshRequest } from './meshAsk.js';
import { PHONE_ACTIONS, PHONE_SOCKET_NAME, askPhoneAgent, parsePhoneAsk } from './phoneAsk.js';

/**
 * The computer-control tools (computerControl.ts) as a small MCP server over stdio, so a chat on this computer can use them:
 * "on my laptop, play lo-fi on YouTube" becomes the tool call play_youtube {query: "lo-fi"}. The session manager adds it to every
 * chat's servers as `escanor_computer` (sessionManager.ts) and lets its tools run without a card: they only open pages and apps
 * and press media keys, like the person at the keyboard. Each answer is one plain sentence the AI can repeat.
 *
 * Only what the protocol needs (initialize, tools/list, tools/call, ping), one JSON-RPC message per line.
 */

export const COMPUTER_MCP_NAME = 'escanor_computer';
const PROTOCOL = '2025-06-18';

type Rpc = { jsonrpc?: string; id?: string | number | null; method?: string; params?: Record<string, unknown> };

/** The guide the AI reads when it connects: how to do any everyday thing on this computer, not one app. */
export const GUIDE = [
  'Do everyday things on this computer for the person: open pages and apps, YouTube, media, volume, lock, a new email, and anything else on the screen.',
  'How to work: (1) Understand what the person actually needs and what a good result looks like; if it is unclear, pick the most likely meaning and say which. (2) Plan the few steps first, and use the quick tools (open_url, open_app, play_youtube, media, volume, compose_mail) when they fit. (3) Act one step at a time with screen_look / screen_click / screen_type / screen_keys / screen_scroll / screen_drag; each answers with a new picture. (4) After every step read the picture: did the right window, page or field change? If not, fix it before going on, and never click or type on a guess.',
  'Questions about their screen (what is on it, where to click, filling a form): use screen_help, then screen_do to click or type where it pointed (the person is asked first).',
  'Going to a page: use open_url, or press ctrl+l and type the address. Pages load slowly: the picture is returned once the screen stops changing; if it says the screen was still changing, screen_look again before trusting it.',
  'Typing: click the text field first and check in the picture that the cursor is in it. Typing onto a page (not a text field) triggers its single-key shortcuts and can delete, archive or send things, so screen_type refuses until a field has the keyboard; single letters pressed alone via screen_keys are refused the same way.',
  'One driver at a time: if the answer says the screen is busy with another task, stop, wait a minute, try again, and never act blind. Do not close, move or reuse windows or tabs you did not open.',
  'Never delete, send, pay, post or change settings unless the person asked for exactly that. If an action had an effect nobody asked for (a mail archived or deleted, a tab closed, a setting changed), undo it at once (ctrl+z, the page\u2019s Undo link, the Trash or reopen the tab with ctrl+shift+t), check the picture, and tell the person plainly what happened and that it is undone.',
  'Passwords: you never get one and nothing is typed for you. To unlock the keyring, sign GitHub in again or run a sudo command the person listed, run `escanor-agent signin keyring|github|check --from-ai --why "the reason"` or `escanor-agent sudo --from-ai --why "the reason" -- <command>` in a terminal: the person is asked on their phone (which computer, what will happen, your reason) and it goes ahead only after their fingerprint. If they say no or do not answer, nothing happens; tell them plainly and do not try another way.',
  'Finish with the answer the person asked for, in plain words (the list, the number, the confirmation), not a description of the clicks. Keep it short, and say if something could not be done and why.',
].join('\n\n');

/** What a server with no screen is told: its one tool is `devices`, and device names must come from the list, not from guessing. */
export const MESH_GUIDE = [
  'This computer has no screen. You can reach the person\u2019s other devices with the devices tool, and nothing else on this computer\u2019s screen.',
  'Device names: the person says "my server", "my desktop", "my laptop". Call devices with op "list" first and use the name exactly as listed (match "server" to the device whose kind or name is a server). If two devices fit, say which two and ask; never guess a name.',
  'For "ask my server ..." style tasks use op "ask" with that device and the short task, then answer with what it replied. "Continue this chat on my laptop" is op "handoff" kind "chat" with no ids (this chat is used).',
  'If the task came from a spoken request, reply in one or two short sentences that sound natural read aloud. A change that waits for the person\u2019s yes on their phone has not happened yet: say so.',
].join('\n\n');

/** The tools that open or switch windows: they take the screen (one chat at a time) and make an older click stale. */
const WINDOW_TOOLS = new Set(['open_url', 'open_app', 'play_youtube', 'compose_mail']);

let sharedLease: ScreenLease | null = null;
/** The one screen lease of this server (its own file location is the machine-wide one, shared by every chat's server). */
export const screenLease = (): ScreenLease => (sharedLease ??= new ScreenLease());
const realFocus = { snapshot: () => snapshotWindows(), raise: (b: Parameters<typeof raiseOpened>[0], host: string) => raiseOpened(b, host) };

export async function answer(msg: Rpc, deps: Deps & { lease?: ScreenLease | null } = {}): Promise<Record<string, unknown> | null> {
  if (msg.id === undefined || msg.id === null) return null; // a notification: nothing to say
  const reply = (result: unknown) => ({ jsonrpc: '2.0', id: msg.id, result });
  switch (msg.method) {
    case 'initialize':
      return reply({
        protocolVersion: typeof msg.params?.protocolVersion === 'string' ? msg.params.protocolVersion : PROTOCOL,
        capabilities: { tools: {} },
        serverInfo: { name: 'escanor-computer', version: '1.0.0' },
        instructions: process.env[MESH_ONLY_ENV] === '1' ? MESH_GUIDE : GUIDE,
      });
    case 'ping':
      return reply({});
    case 'tools/list':
      return reply({ tools: process.env[MESH_ONLY_ENV] === '1' ? [DEVICES_TOOL] : [...COMPUTER_TOOLS, ...SCREEN_TOOLS, ...SCREEN_HELP_TOOLS, PHONE_TOOL, DEVICES_TOOL] });
    case 'tools/call': {
      const name = String(msg.params?.name ?? '');
      const args = (msg.params?.arguments && typeof msg.params.arguments === 'object' ? msg.params.arguments : {}) as Record<string, unknown>;
      if (name === DEVICES_TOOL.name) return reply(await devicesTool(args));
      if (process.env[MESH_ONLY_ENV] === '1') return reply({ content: [{ type: 'text', text: 'This server has no screen: it can only list and reach your other devices (the devices tool).' }], isError: true });
      if (name === PHONE_TOOL.name) return reply(await phoneTool(args));
      if (SCREEN_TOOL_NAMES.has(name)) return reply(await screenTool(name, args, screenDeps));
      if (SCREEN_HELP_TOOL_NAMES.has(name)) return reply(name === SCREEN_HELP_TOOL ? await screenHelpTool(args, helpDeps()) : await screenDoTool(args, helpDeps()));
      const a = parseAction(name, args);
      if ('error' in a) return reply({ content: [{ type: 'text', text: a.error }], isError: true });
      const live = !deps.run; // the real programs (not a test's stand-ins)
      const lease = deps.lease === undefined ? (live ? screenLease() : null) : deps.lease;
      if (WINDOW_TOOLS.has(a.kind)) {
        const got = await lease?.acquire();
        if (got && !got.ok) return reply({ content: [{ type: 'text', text: got.say }], isError: true });
        screenDeps.guard?.reset();
      }
      const out = await runComputerAction(a, { ...deps, focus: deps.focus ?? (live ? realFocus : undefined) });
      return reply({ content: [{ type: 'text', text: out.say }], isError: !out.ok });
    }
    default:
      return { jsonrpc: '2.0', id: msg.id, error: { code: -32601, message: `Unknown method ${msg.method}` } };
  }
}

export function serve(input: NodeJS.ReadableStream = process.stdin, output: NodeJS.WritableStream = process.stdout): Promise<void> {
  process.once('exit', () => sharedLease?.release());
  const rl = createInterface({ input });
  const pending = new Set<Promise<void>>();
  rl.on('line', (line) => {
    if (!line.trim()) return;
    let msg: Rpc;
    try {
      msg = JSON.parse(line) as Rpc;
    } catch {
      output.write(`${JSON.stringify({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } })}\n`);
      return;
    }
    const p = answer(msg).then((r) => {
      if (r) output.write(`${JSON.stringify(r)}\n`);
    });
    pending.add(p);
    void p.finally(() => pending.delete(p));
  });
  // Calls still running when the chat hangs up are finished first (their answers may still be read).
  return new Promise((resolve) => rl.once('close', () => void Promise.allSettled([...pending]).then(() => {
    sharedLease?.release();
    resolve();
  })));
}

/** How a chat starts this server: the agent's own Node (or Electron run as Node) and bin/computer-mcp.mjs, which loads tsx first. */
export function computerMcpConfig(remoteFile?: string, helpDir?: string, meshOnly = false, callerKey = ''): { type: 'stdio'; command: string; args: string[]; env?: Record<string, string> } {
  const bin = fileURLToPath(new URL('../bin/computer-mcp.mjs', import.meta.url));
  const env: Record<string, string> = { ...(process.versions.electron ? { ELECTRON_RUN_AS_NODE: '1' } : {}), ...(remoteFile ? { [REMOTE_FILE_ENV]: remoteFile } : {}), ...(helpDir ? { [SCREEN_HELP_DIR_ENV]: helpDir } : {}), ...(meshOnly ? { [MESH_ONLY_ENV]: '1' } : {}), ...(callerKey ? { [CALLER_KEY_ENV]: callerKey } : {}) };
  return { type: 'stdio', command: process.execPath, args: [bin], ...(Object.keys(env).length ? { env } : {}) };
}

// ------------------------------------------------------------------------------------------------- the screen, for the AI

/** Where the Remote control switch is kept (the agent's data folder), handed to this server by the session manager. */
export const REMOTE_FILE_ENV = 'ESCANOR_REMOTE_FILE';

const xy = { x: { type: 'integer', description: 'Pixels from the left of the last screen_look picture' }, y: { type: 'integer', description: 'Pixels from the top of the last screen_look picture' } };

/** Tools that see and use the whole screen, like a person at the keyboard. Each action answers with a new picture. */
export const SCREEN_TOOLS: Array<{ name: string; description: string; inputSchema: Record<string, unknown> }> = [
  { name: 'screen_look', description: 'See the screen of this computer now (a picture). Use it first, and after acting to check. Coordinates for the other screen tools are pixels in this picture.', inputSchema: { type: 'object', properties: {} } },
  {
    name: 'screen_click',
    description: 'Click on the screen at x,y (pixels in the last screen_look picture). button: left (default), right, double, middle.',
    inputSchema: { type: 'object', properties: { ...xy, button: { type: 'string', enum: ['left', 'right', 'double', 'middle'] } }, required: ['x', 'y'] },
  },
  { name: 'screen_type', description: 'Type text into the text field that has the keyboard (click the field first and check the cursor is in it; refused otherwise, so shortcuts never fire). Use screen_keys "enter" to submit.', inputSchema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] } },
  {
    name: 'screen_keys',
    description: 'Press keys together, e.g. "enter", "ctrl+l", "alt+tab", "ctrl+shift+t", "super", "esc", "f11", "pagedown". Names: ctrl alt shift super enter esc tab backspace delete up down left right home end pageup pagedown space f1-f12 and single characters.',
    inputSchema: { type: 'object', properties: { keys: { type: 'string' } }, required: ['keys'] },
  },
  {
    name: 'screen_scroll',
    description: 'Scroll at x,y (or where the pointer is). direction up/down/left/right, amount 1-15 steps (default 3).',
    inputSchema: { type: 'object', properties: { ...xy, direction: { type: 'string', enum: ['up', 'down', 'left', 'right'] }, amount: { type: 'integer', minimum: 1, maximum: 15 } }, required: ['direction'] },
  },
  {
    name: 'screen_drag',
    description: 'Drag with the left button from x,y to x2,y2 (pixels in the last picture).',
    inputSchema: { type: 'object', properties: { ...xy, x2: { type: 'integer' }, y2: { type: 'integer' } }, required: ['x', 'y', 'x2', 'y2'] },
  },
];
const SCREEN_TOOL_NAMES = new Set(SCREEN_TOOLS.map((t) => t.name));

export type ScreenToolDeps = {
  live: () => LiveScreen;
  remoteOn: () => boolean;
  log: (e: SafetyEvent) => void;
  /** The size of the last picture the AI saw (its coordinates). */
  last: { w: number; h: number } | null;
  /** Wait before the after-picture (tests: none). */
  settle?: number;
  /** One chat at a time on the screen (screenSafety.ts). Off when absent. */
  lease?: ScreenLease | null;
  /** Typing only into text fields. Off when absent. */
  guard?: TypeGuard | null;
  /** The longest to wait for the picture to stop changing (ms); 0 = take the first picture. Default: 6 seconds (none when `settle` is 0). */
  settleMax?: number;
  sleep?: (ms: number) => Promise<void>;
};

type ToolResult = { content: Array<Record<string, unknown>>; isError?: boolean };
const text = (t: string, isError = false): ToolResult => ({ content: [{ type: 'text', text: t }], ...(isError ? { isError: true } : {}) });

let idle: NodeJS.Timeout | null = null;
let liveScreen: LiveScreen | null = null;
const screenGuard = new TypeGuard(() => readFocus());
const screenDeps: ScreenToolDeps = {
  get lease() {
    return screenLease();
  },
  guard: screenGuard,
  live: () => (liveScreen ??= new LiveScreen({ unlock: true, width: 1280, gap: 0.25 })),
  remoteOn: () => new RemoteSwitch(process.env[REMOTE_FILE_ENV] ?? '', process.env, true).enabled(),
  log: (e) => logSafety(defaultUndoRoot(), e),
  last: null,
};

/** One screen tool call. The session stays open between calls and closes after two quiet minutes (GNOME shows its sharing icon meanwhile). */
export async function screenTool(name: string, args: Record<string, unknown>, d: ScreenToolDeps): Promise<ToolResult> {
  if (!d.remoteOn()) return text('Remote control is off on this computer, so the screen cannot be used. The owner can turn it on in the Escanor app (Machines, this computer, Remote control).', true);
  const got = await d.lease?.acquire();
  if (got && !got.ok) return text(got.say, true);
  const live = d.live();
  if (idle) clearTimeout(idle);
  idle = setTimeout(() => {
    live.stop();
    d.lease?.release();
  }, 120_000);
  idle.unref();
  const started = await live.start();
  if (!started.ok) return text(started.say, true);
  if (started.unlocked) d.log({ at: Date.now(), action: 'remote', source: 'agent', command: 'unlock_screen', why: 'the AI unlocked the screen to work on it (Remote control is on)' });
  const look = async (say: string, since?: number): Promise<ToolResult> => {
    const first = since === undefined ? await live.frame() : await live.frameAfter(since, d.settle ?? 300);
    const cap = d.settleMax ?? (d.settle === 0 ? 0 : 6000);
    const s = await settle<Shot & Frame>(() => live.frame() as Promise<(Shot & Frame) | null>, { capMs: cap, first: first as (Shot & Frame) | null, sleep: d.sleep });
    const shot = s.shot;
    if (!shot) return text(`${say} (No picture of the screen came back.)`, !say);
    d.last = { w: shot.width, h: shot.height };
    const moving = cap > 0 && !s.settled ? ' The screen was still changing when this picture was taken (a page may still be loading): take another screen_look before trusting it.' : '';
    return { content: [{ type: 'image', data: shot.b64, mimeType: shot.mime }, { type: 'text', text: `${say ? `${say} ` : ''}Screen picture ${shot.width}x${shot.height} pixels${started.unlocked ? ' (the screen was locked; it is unlocked now)' : ''}.${moving}` }] };
  };
  if (name === 'screen_look') return look('');
  const last = d.last ?? (await live.frame().then((s) => (s ? { w: s.width, h: s.height } : null)));
  if (!last) return text('Take a screen_look first.', true);
  const fx = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(0, Math.min(1, v / Math.max(1, last.w - 1))) : NaN);
  const fy = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(0, Math.min(1, v / Math.max(1, last.h - 1))) : NaN);
  let raw: unknown[];
  switch (name) {
    case 'screen_click': {
      const b = args.button === 'right' ? 'right' : args.button === 'double' ? 'double' : args.button === 'middle' ? 'middle' : 'tap';
      raw = [{ t: b, x: fx(args.x), y: fy(args.y) }];
      break;
    }
    case 'screen_type':
      raw = [{ t: 'text', text: args.text }];
      break;
    case 'screen_keys':
      raw = [{ t: 'keys', keys: args.keys }];
      break;
    case 'screen_scroll': {
      const n = typeof args.amount === 'number' ? Math.max(1, Math.min(15, Math.trunc(args.amount))) : 3;
      const dir = String(args.direction);
      const at = typeof args.x === 'number' && typeof args.y === 'number' ? { x: fx(args.x), y: fy(args.y) } : {};
      raw = [{ t: 'scroll', ...at, ...(dir === 'up' ? { dy: -n } : dir === 'down' ? { dy: n } : dir === 'left' ? { dx: -n } : { dx: n }) }];
      break;
    }
    default:
      raw = [{ t: 'drag', x: fx(args.x), y: fy(args.y), x2: fx(args.x2), y2: fy(args.y2) }];
  }
  const parsed = parseEvents(raw);
  if (!parsed.ok) return text(parsed.error, true);
  if (d.guard && name === 'screen_type') {
    const ok = await d.guard.checkType();
    if (!ok.ok) return text(ok.say, true);
  }
  if (d.guard && name === 'screen_keys') {
    const ok = await d.guard.checkKeys(String(args.keys));
    if (!ok.ok) return text(ok.say, true);
  }
  const r = await live.send(parsed.events as LiveEvent[]);
  const sent = Date.now();
  d.log({ at: Date.now(), action: 'remote', source: 'agent', command: name, why: r.ok ? `the AI ${describeEvents(parsed.events)} on the screen` : `could not: ${r.say}` });
  if (!r.ok) return text(r.say, true);
  if (name === 'screen_click') d.guard?.noteClick(args.button);
  if (name === 'screen_keys') d.guard?.noteKeys(String(args.keys));
  return look(`Done: ${describeEvents(parsed.events)}.`, sent);
}

// ------------------------------------------------------------------------------------------------- the owner's other devices (meshAsk.ts)

/** A headless server's chats get only the devices tool (no screen to drive): the session manager sets this. */
export const MESH_ONLY_ENV = 'ESCANOR_MESH_ONLY';
/** This chat's random key (sessionManager.callerSessionId): sent with a devices request so "continue this chat" needs no chat id from the model. */
export const CALLER_KEY_ENV = 'ESCANOR_CALLER_KEY';

export const DEVICES_TOOL = {
  name: 'devices',
  description:
    'The person\'s other devices, through Escanor (their own only; never this computer). op "list": which devices they have and which are online. op "command" {device, action, args}: one fixed thing on another device. A computer: ' +
    MESH_COMPUTER_ACTIONS.join(', ') +
    ' (open_url {url}, open_app {app}, media {op}, volume {op, level}). A phone: ' +
    MESH_PHONE_ACTIONS.join(', ') +
    ' (open_link {url}, receive_link {url}, open_app {app}, ring {seconds}, torch {on}, notify {text, title?} = a short notice that only shows words); every action except notify answers only if its owner switched on "Let my other devices ask this phone". A watch: ' +
    MESH_WATCH_ACTIONS.join(', ') +
    ' (notify {text}, ring {seconds}). op "handoff" {to, kind, payload}: hand something to a device: link {url}, text {text}, chat {} ("continue this chat on my laptop", to a computer: this chat is used; give no ids), reading (what they were reading). op "ask" {device, task}: give a short job to another computer or a server and get its answer. Name the device as the person did ("desktop", "server", "laptop"); never guess. Each change is checked by the safety check first: if the answer says it is waiting for the person\'s yes, tell them to answer in the Escanor app; nothing has been done yet. A watch or the status wall can only be shown things, spoken to or rung, never made to run actions.',
  inputSchema: {
    type: 'object',
    properties: {
      op: { type: 'string', enum: [...MESH_OPS] },
      device: { type: 'string', description: 'command and ask: which device' },
      to: { type: 'string', description: 'handoff: which device' },
      action: { type: 'string', enum: [...MESH_ACTIONS] },
      args: { type: 'object' },
      kind: { type: 'string', enum: [...MESH_KINDS] },
      payload: { type: 'object' },
      task: { type: 'string', description: 'ask: the short job' },
    },
    required: ['op'],
  },
};

async function devicesTool(args: Record<string, unknown>): Promise<{ content: Array<Record<string, unknown>>; isError?: boolean }> {
  const p = parseMeshRequest(args);
  if (!p.ok) return { content: [{ type: 'text', text: p.error }], isError: true };
  const dir = process.env[SCREEN_HELP_DIR_ENV] ?? '';
  const r = await askMeshAgent(dir ? join(dir, MESH_SOCKET_NAME) : '', p.req, undefined, process.env[CALLER_KEY_ENV] ?? '');
  const rows = r.devices?.map((d) => `${d.name} (${d.kind}, ${d.online ? 'online' : 'offline'}${d.is_this_device ? ', this computer' : ''}${d.state && d.state !== 'unknown' ? `, ${d.state}` : ''})`).join('; ');
  return { content: [{ type: 'text', text: rows ? `${r.say}\n${rows}` : r.say }], ...(r.ok ? {} : { isError: true }) };
}

// ------------------------------------------------------------------------------------------------- the owner's phone (phoneAsk.ts)

export const PHONE_TOOL = {
  name: 'phone',
  description:
    'Ask the person\'s own phone to do ONE thing, through Escanor: ring (so they can find it; seconds 5-60), stop_ring, battery (how much battery), status, torch (on true/false), media (op: play, pause, play_pause, next, previous, stop), receive_link (url: a web link that appears on the phone as a notification to tap), open_link (url: opens the link on the phone, or shows a notice to tap when Android does not let it open by itself), open_app (app: the name of the app, for example YouTube). It cannot place calls, read notifications or send messages. The phone answers only if its owner switched on "Let my other devices ask this phone" in the Escanor app, and only while the app is running; if it does not answer, say so and say where to turn it on.',
  inputSchema: {
    type: 'object',
    properties: {
      action: { type: 'string', enum: [...PHONE_ACTIONS] },
      seconds: { type: 'integer', minimum: 5, maximum: 60, description: 'ring: how long' },
      on: { type: 'boolean', description: 'torch: on or off' },
      op: { type: 'string', enum: ['play', 'pause', 'play_pause', 'next', 'previous', 'stop'], description: 'media: which button' },
      url: { type: 'string', description: 'receive_link or open_link: the web link' },
      app: { type: 'string', description: 'open_app: the app\'s name' },
    },
    required: ['action'],
  },
};

async function phoneTool(args: Record<string, unknown>): Promise<{ content: Array<Record<string, unknown>>; isError?: boolean }> {
  const p = parsePhoneAsk(args);
  if (!p.ok) return { content: [{ type: 'text', text: p.error }], isError: true };
  const dir = process.env[SCREEN_HELP_DIR_ENV] ?? '';
  const r = await askPhoneAgent(dir ? join(dir, PHONE_SOCKET_NAME) : '', p.ask);
  const extra = r.data && Object.keys(r.data).length ? ` ${JSON.stringify(r.data)}` : '';
  return { content: [{ type: 'text', text: `${r.say}${r.ok ? extra : ''}` }], ...(r.ok ? {} : { isError: true }) };
}

// ------------------------------------------------------------------------------------------------- screen help (screenHelp.ts)

/** The real dependencies of screen_help and screen_do, built per call from this server's environment. */
function helpDeps(): HelpDeps {
  const dir = process.env[SCREEN_HELP_DIR_ENV] ?? '';
  return {
    remoteOn: () => screenDeps.remoteOn(),
    consent: new ScreenConsent(join(dir, CONSENT_NAME)),
    notes: new NoteLog(join(dir, NOTES_NAME)),
    shoot: () => takeScreenshot(),
    locked: () => screenLocked(),
    ask: (a) => askAgent(dir ? join(dir, SOCKET_NAME) : '', a),
    highlight: realHighlight,
    mark: (b) => {
      try {
        if (dir) writeHighlight(join(dir, HIGHLIGHT_NAME), b);
      } catch {
        /* the phone just shows no ring */
      }
    },
    act: async (name, args, size) => {
      screenDeps.last = size;
      const r = await screenTool(name, args, screenDeps);
      return { ...r, content: r.content.filter((b) => b.type === 'text') }; // the new picture is dropped: nothing of the screen is kept
    },
  };
}

export { SCREEN_DO_TOOL, SCREEN_HELP_TOOL };
