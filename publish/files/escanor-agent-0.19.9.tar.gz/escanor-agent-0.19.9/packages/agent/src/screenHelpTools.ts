import {
  SECRET_LABEL,
  LOOK_FRESH_MS,
  MODES,
  boxAt,
  centre,
  whereWords,
  type Answer,
  type Ask,
  type Box,
  type Highlighter,
  type Mode,
  type NoteLog,
  type ScreenConsent,
} from './screenHelp.js';
import type { Shot } from './screenControl.js';

/**
 * The two chat tools of screen-aware help (the escanor_computer MCP server, computerMcp.ts):
 *  - screen_help {question, mode}: one picture of the screen, answered by a vision model on Escanor's server, the target
 *    highlighted on the real screen first. The picture never reaches the chat's own model or its history.
 *  - screen_do {kind: click | fill, x, y, label, text?, app?}: click or type, only where the last look pointed. The chat's
 *    PreToolUse hook holds every call for the person's yes (Autonomous: only with the app named, checked here).
 */

type ToolResult = { content: Array<Record<string, unknown>>; isError?: boolean };
const text = (t: string, isError = false): ToolResult => ({ content: [{ type: 'text', text: t }], ...(isError ? { isError: true } : {}) });

export const SCREEN_HELP_TOOL = 'screen_help';
export const SCREEN_DO_TOOL = 'screen_do';
export const SCREEN_HELP_TOOL_NAMES: ReadonlySet<string> = new Set([SCREEN_HELP_TOOL, SCREEN_DO_TOOL]);

export const SCREEN_HELP_TOOLS: Array<{ name: string; description: string; inputSchema: Record<string, unknown> }> = [
  {
    name: SCREEN_HELP_TOOL,
    description:
      'Answer a question about what is on the person\'s screen ("what is on my screen", "where do I click to ...", "help me fill this form"). Takes ONE picture only because they asked, sends it to a vision model, highlights the target on their screen and answers in plain words. The picture is never kept. Use mode "where" to point at one thing to click, "form" for a form, "look" otherwise. Use this instead of screen_look for the person\'s questions.',
    inputSchema: { type: 'object', properties: { question: { type: 'string', description: 'What the person asked, in their words' }, mode: { type: 'string', enum: [...MODES] } }, required: ['question'] },
  },
  {
    name: SCREEN_DO_TOOL,
    description:
      'Click, or click and type, exactly where the last screen_help highlighted (x and y are fractions 0 to 1 of the screen, from the box screen_help gave; label is that box\'s label). The person is asked for a yes first. kind "click" clicks; "fill" clicks the field and types `text`. Never for passwords, card numbers or codes. In an Autonomous chat pass `app`, the app the person named.',
    inputSchema: {
      type: 'object',
      properties: { kind: { type: 'string', enum: ['click', 'fill'] }, x: { type: 'number' }, y: { type: 'number' }, label: { type: 'string' }, text: { type: 'string' }, app: { type: 'string' } },
      required: ['kind', 'x', 'y', 'label'],
    },
  },
];

export type Look = { at: number; w: number; h: number; target: Box | null; fields: Box[]; app: string };
let lastLook: Look | null = null;
export const forgetLook = (): void => {
  lastLook = null;
};

export type HelpDeps = {
  remoteOn: () => boolean;
  consent: ScreenConsent;
  notes: NoteLog;
  shoot: () => Promise<{ ok: true; shot: Shot } | { ok: false; say: string }>;
  locked: () => Promise<boolean>;
  ask: (a: Ask) => Promise<Answer>;
  highlight: Highlighter;
  /** The click and typing, as the existing screen tools (pixels of the last picture; their answers carry a new picture, dropped here). */
  act: (name: 'screen_click' | 'screen_type', args: Record<string, unknown>, size: { w: number; h: number }) => Promise<ToolResult>;
  now?: () => number;
  /** Tells the phone's live view where the last look pointed. */
  mark?: (b: Box) => void;
  /** Wait after the highlight before acting (tests: none). */
  settle?: number;
};

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function screenHelpTool(args: Record<string, unknown>, d: HelpDeps): Promise<ToolResult> {
  if (!d.remoteOn()) return text('Remote control is off on this computer, so the screen cannot be looked at. The owner can turn it on in the Escanor app (Machines, this computer, Remote control).', true);
  if (!d.consent.granted()) return text('Screen help has not been allowed on this computer yet. It is asked for the first time the person uses it.', true);
  const mode: Mode = MODES.includes(args.mode as Mode) ? (args.mode as Mode) : 'look';
  const question = typeof args.question === 'string' ? args.question.slice(0, 600) : '';
  if (await d.locked()) return text('The screen is locked, so there is nothing to look at yet. Ask the person to unlock it.', true);
  const shot = await d.shoot();
  if (!shot.ok) return text(shot.say, true);
  const answer = await d.ask({ image: shot.shot.b64, mime: 'image/jpeg', question, mode });
  if (!answer.ok) return text(answer.say, true);
  lastLook = { at: (d.now ?? Date.now)(), w: shot.shot.width, h: shot.shot.height, target: answer.target, fields: answer.fields, app: answer.app };
  if (answer.note) d.notes.add(answer.note, d.now?.());
  if (answer.target) d.mark?.(answer.target);
  if (answer.target) void d.highlight(answer.target, 4); // points first: the person sees where while the words are read
  const lines = [answer.say];
  if (answer.target) lines.push(`Highlighted on the screen: "${answer.target.label || 'the spot'}" (${whereWords(answer.target)}). x=${(centre(answer.target).x).toFixed(3)}, y=${(centre(answer.target).y).toFixed(3)}.`);
  if (answer.fields.length) lines.push(`Fields in order: ${answer.fields.map((f, i) => `${i + 1}. "${f.label || 'field'}" (x=${centre(f).x.toFixed(3)}, y=${centre(f).y.toFixed(3)})`).join('; ')}.`);
  if (answer.app) lines.push(`App in front: ${answer.app}.`);
  if (answer.cap) lines.push(`Screen help used ${answer.used} of ${answer.cap} this month.`);
  lines.push('Nothing was saved: the picture is gone. To click or type there, use screen_do (the person is asked first).');
  return text(lines.join('\n'));
}

const sameApp = (a: string, b: string): boolean => {
  const x = a.toLowerCase().trim();
  const y = b.toLowerCase().trim();
  return x.length > 0 && y.length > 0 && (x.includes(y) || y.includes(x));
};

export async function screenDoTool(args: Record<string, unknown>, d: HelpDeps): Promise<ToolResult> {
  if (!d.remoteOn()) return text('Remote control is off on this computer, so the screen cannot be used.', true);
  const now = (d.now ?? Date.now)();
  if (!lastLook || now - lastLook.at > LOOK_FRESH_MS) return text('Look first: ask screen_help so the spot is pointed at, then use screen_do on it.', true);
  const x = Number(args.x);
  const y = Number(args.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return text('x and y must be the numbers screen_help gave.', true);
  const hit = boxAt([...(lastLook.target ? [lastLook.target] : []), ...lastLook.fields], x, y);
  if (!hit) return text('That is not where screen_help pointed, so nothing was done. Ask screen_help again for the place you mean.', true);
  const kind = args.kind === 'fill' ? 'fill' : 'click';
  const label = `${hit.label} ${typeof args.label === 'string' ? args.label : ''}`;
  if (kind === 'fill') {
    if (SECRET_LABEL.test(label)) return text('That field holds a password, code or card number. Escanor never types those; the person types it themselves.', true);
    if (typeof args.text !== 'string' || !args.text || args.text.length > 500) return text('fill needs the text to type (up to 500 characters).', true);
  }
  if (typeof args.app === 'string' && args.app.trim() && lastLook.app && !sameApp(lastLook.app, args.app)) {
    return text(`The screen shows "${lastLook.app}", not "${args.app}", so nothing was done.`, true);
  }
  await Promise.race([d.highlight(hit, 1), sleep(1500)]); // pointed at once more, right before the action
  if (d.settle) await sleep(d.settle);
  const c = centre(hit);
  const px = { x: Math.round(c.x * (lastLook.w - 1)), y: Math.round(c.y * (lastLook.h - 1)) };
  const size = { w: lastLook.w, h: lastLook.h };
  const clicked = await d.act('screen_click', { ...px, button: 'left' }, size);
  if (clicked.isError) return text(String(clicked.content.find((b) => b.type === 'text')?.text ?? 'The click did not work.'), true);
  if (kind === 'fill') {
    await sleep(d.settle ?? 150);
    const typed = await d.act('screen_type', { text: args.text }, size);
    if (typed.isError) return text(`Clicked "${hit.label}" but typing failed: ${String(typed.content.find((b) => b.type === 'text')?.text ?? '')}`, true);
    return text(`Clicked "${hit.label}" and typed ${String(args.text).length} characters. Ask screen_help to see the result.`);
  }
  return text(`Clicked "${hit.label}". Ask screen_help to see what changed.`);
}
