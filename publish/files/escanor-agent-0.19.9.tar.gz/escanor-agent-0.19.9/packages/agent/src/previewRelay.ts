import { request as httpRequest, type ClientRequest, type IncomingMessage } from 'node:http';
import { createBrotliDecompress, createGunzip, createInflate } from 'node:zlib';
import type { Readable } from 'node:stream';
import type { AgentToHubMessage, HubPreviewHttp } from '@remote-harness/shared';
import type { LinkTarget } from './previewOpen.js';

/**
 * SITEPREV3, the computer's side of a private preview link: the hub relays a browser's request (`preview_http`) and this answers it
 * from the preview this agent runs for that link's fix, and from nothing else.
 *
 *  - Where it goes is decided here, never by the request: 127.0.0.1 and the port of this run's own preview (PreviewOpener.target).
 *    The request only names a path. No preview for the link (yet) = a `preview_http_wait` the hub turns into a plain page.
 *  - Limits: 1 MB in, 16 MB out, 30 s to start answering and under 2 minutes in all, eight requests at a time (the rest wait their
 *    turn, up to 30 s: a page asks for all its scripts and styles at once).
 *  - Nothing is logged: no path, header, cookie or body.
 */

export const MAX_BODY_IN = 1_000_000;
export const MAX_BODY_OUT = 16_000_000;
export const CHUNK = 192 * 1024;
export const MAX_IN_FLIGHT = 8;
/** Requests past the eight wait in line; only past this many waiting does one get "busy". The hub keeps at most 8 + 64 per link. */
export const MAX_QUEUED = 128;
const HEAD_TIMEOUT_MS = 30_000;
const TOTAL_TIMEOUT_MS = 115_000;
const METHODS = new Set(['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']);
const TOKEN = /^[!#$%&'*+.^_`|~0-9A-Za-z-]{1,100}$/;
const PATH = /^\/[^\s\x00-\x1f\x7f]{0,7999}$/;
const DROP_IN = /^(host|connection|keep-alive|transfer-encoding|upgrade|te|trailer|proxy-.*|accept-encoding|content-length|forwarded|via|x-forwarded-.*|x-real-ip|x-hub-.*|cf-.*)$/i;
const DROP_OUT = /^(connection|keep-alive|transfer-encoding|upgrade|te|trailer|proxy-.*|content-length|content-encoding)$/i;

export type RelayOptions = {
  target: (linkId: string) => LinkTarget;
  send: (msg: AgentToHubMessage) => void;
  request?: typeof httpRequest;
};

/** The request headers the preview gets: the browser's own, cleaned, with this computer's address as the host and no compression. */
export function headersIn(pairs: unknown, port: number): Record<string, string | string[]> {
  const out: Record<string, string | string[]> = {};
  if (Array.isArray(pairs)) {
    for (const p of pairs.slice(0, 64)) {
      if (!Array.isArray(p) || typeof p[0] !== 'string' || typeof p[1] !== 'string') continue;
      const k = p[0].toLowerCase();
      const v = p[1];
      if (!TOKEN.test(k) || DROP_IN.test(k) || /[\r\n\0]/.test(v) || v.length > 8_000) continue;
      const had = out[k];
      out[k] = had === undefined ? v : Array.isArray(had) ? [...had, v] : [had, v];
    }
  }
  out.host = `127.0.0.1:${port}`;
  out['accept-encoding'] = 'identity';
  return out;
}

/** The preview's answer headers for the hub: cleaned, and a redirect to its own local address made a path. */
export function headersOut(raw: string[], port: number): [string, string][] {
  const out: [string, string][] = [];
  const local = new RegExp(`^https?://(?:127\\.0\\.0\\.1|localhost|0\\.0\\.0\\.0|\\[::1\\]):${port}(/[^\\s]*)?$`, 'i');
  for (let i = 0; i + 1 < raw.length && out.length < 100; i += 2) {
    const k = raw[i].toLowerCase();
    let v = raw[i + 1];
    if (DROP_OUT.test(k) || !TOKEN.test(k) || /[\r\n]/.test(v)) continue;
    if (k === 'location') {
      const m = local.exec(v);
      if (m) v = m[1] || '/';
    }
    out.push([k, v]);
  }
  return out;
}

function decoded(res: IncomingMessage): Readable {
  const enc = String(res.headers['content-encoding'] ?? '').trim().toLowerCase();
  if (enc === 'gzip' || enc === 'x-gzip') return res.pipe(createGunzip());
  if (enc === 'deflate') return res.pipe(createInflate());
  if (enc === 'br') return res.pipe(createBrotliDecompress());
  return res;
}

export class PreviewRelay {
  private inFlight = new Map<string, { req: ClientRequest; timers: ReturnType<typeof setTimeout>[]; done: boolean; headed: boolean }>();
  /** Requests waiting for one of the eight places, oldest first. */
  private queue = new Map<string, { msg: HubPreviewHttp; timer: ReturnType<typeof setTimeout> }>();

  constructor(private o: RelayOptions) {}

  /** Never throws: every request gets a head and an end, or a wait. */
  handle(msg: HubPreviewHttp): void {
    const id = typeof msg?.id === 'string' && msg.id.length <= 64 ? msg.id : '';
    if (!id || this.inFlight.has(id) || this.queue.has(id)) return;
    const t = this.o.target(typeof msg.linkId === 'string' ? msg.linkId : '');
    if ('wait' in t) {
      this.o.send({ type: 'preview_http_wait', id, state: t.wait, message: t.message });
      return;
    }
    const method = typeof msg.method === 'string' ? msg.method.toUpperCase() : '';
    if (!METHODS.has(method) || typeof msg.path !== 'string' || !PATH.test(msg.path)) return this.fail(id, 400, 'This request cannot be passed to the preview.');
    if (this.inFlight.size >= MAX_IN_FLIGHT) {
      if (this.queue.size >= MAX_QUEUED) return this.fail(id, 503, 'The preview is busy with other requests. Try again in a moment.');
      const timer = setTimeout(() => {
        if (this.queue.delete(id)) this.fail(id, 504, 'The preview did not answer in time.');
      }, HEAD_TIMEOUT_MS);
      this.queue.set(id, { msg, timer });
      return;
    }
    let body: Buffer | undefined;
    if (typeof msg.body === 'string' && msg.body) {
      body = Buffer.from(msg.body, 'base64');
      if (body.length > MAX_BODY_IN) return this.fail(id, 413, 'Requests through a preview link can be at most 1 MB.');
    }
    const headers = headersIn(msg.headers, t.port);
    if (body) headers['content-length'] = String(body.length);
    let req: ClientRequest;
    try {
      req = (this.o.request ?? httpRequest)({ host: '127.0.0.1', port: t.port, method, path: msg.path, headers });
    } catch {
      return this.fail(id, 400, 'This request cannot be passed to the preview.');
    }
    const entry = { req, timers: [] as ReturnType<typeof setTimeout>[], done: false, headed: false };
    this.inFlight.set(id, entry);
    entry.timers.push(setTimeout(() => !entry.headed && this.end(id, 'timeout', 504), HEAD_TIMEOUT_MS));
    entry.timers.push(setTimeout(() => this.end(id, 'timeout', 504), TOTAL_TIMEOUT_MS));
    req.on('error', () => this.end(id, 'failed', 502));
    req.on('response', (res) => {
      if (entry.done) return res.resume();
      entry.headed = true;
      this.o.send({ type: 'preview_http_head', id, status: res.statusCode ?? 502, headers: headersOut(res.rawHeaders, t.port) });
      let sent = 0;
      const stream = decoded(res);
      stream.on('data', (chunk: Buffer) => {
        if (entry.done) return;
        sent += chunk.length;
        if (sent > MAX_BODY_OUT) return this.end(id, 'too_big');
        for (let i = 0; i < chunk.length; i += CHUNK) this.o.send({ type: 'preview_http_body', id, data: chunk.subarray(i, i + CHUNK).toString('base64') });
      });
      stream.on('end', () => this.end(id));
      stream.on('error', () => this.end(id, 'failed'));
    });
    req.end(body);
  }

  /** The browser went away, or the hub gave up: stop asking the preview. */
  cancel(id: string): void {
    const q = this.queue.get(id);
    if (q) {
      clearTimeout(q.timer);
      this.queue.delete(id);
      return;
    }
    const e = this.inFlight.get(id);
    if (!e) return;
    e.done = true;
    this.inFlight.delete(id);
    for (const t of e.timers) clearTimeout(t);
    e.req.destroy();
    this.next();
  }

  stopAll(): void {
    for (const q of this.queue.values()) clearTimeout(q.timer);
    this.queue.clear();
    for (const id of [...this.inFlight.keys()]) this.cancel(id);
  }

  /** A place came free: the oldest waiting request goes (checked again, its link may have ended meanwhile). */
  private next(): void {
    while (this.inFlight.size < MAX_IN_FLIGHT && this.queue.size) {
      const [id, q] = this.queue.entries().next().value!;
      clearTimeout(q.timer);
      this.queue.delete(id);
      this.handle(q.msg);
    }
  }

  private fail(id: string, status: number, text: string): void {
    this.o.send({ type: 'preview_http_head', id, status, headers: [['content-type', 'text/plain; charset=utf-8']] });
    this.o.send({ type: 'preview_http_body', id, data: Buffer.from(text).toString('base64') });
    this.o.send({ type: 'preview_http_end', id });
  }

  /** Finish once: before the head the hub gets a plain error answer; after it, the end (with an error the stream breaks). */
  private end(id: string, error?: string, statusIfNoHead = 502): void {
    const e = this.inFlight.get(id);
    if (!e || e.done) return;
    e.done = true;
    this.inFlight.delete(id);
    for (const t of e.timers) clearTimeout(t);
    if (error) e.req.destroy();
    if (error && !e.headed) this.fail(id, statusIfNoHead, error === 'timeout' ? 'The preview did not answer in time.' : 'The preview did not answer.');
    else this.o.send({ type: 'preview_http_end', id, ...(error ? { error } : {}) });
    this.next();
  }
}
