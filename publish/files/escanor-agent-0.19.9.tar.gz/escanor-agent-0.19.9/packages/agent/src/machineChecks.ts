import { execFile } from 'node:child_process';
import os from 'node:os';

/**
 * Read-only checks of this computer for the website's Machines page (Disks, Processes, Memory, Load). A fixed allow-list: the page names
 * a check, never a command, so nothing typed anywhere can reach a shell here. Each check runs one fixed program (or reads the
 * operating system through Node), and the answer is structured rows, not text. Process rows carry the program's short name only, never
 * its arguments (they can hold secrets).
 */

export type CheckKind = 'disks' | 'processes' | 'memory' | 'load';
export const CHECK_KINDS: readonly CheckKind[] = ['disks', 'processes', 'memory', 'load'];
export const isCheckKind = (v: unknown): v is CheckKind => typeof v === 'string' && (CHECK_KINDS as readonly string[]).includes(v);

export type CheckRow = Record<string, string | number>;
export type CheckResult = { ok: true; kind: CheckKind; rows: CheckRow[]; say: string } | { ok: false; say: string };

export type CheckExec = (file: string, args: string[]) => Promise<string>;

/** Rows the page shows at most. */
export const MAX_TOP = 25;
const DEFAULT_TOP = 15;

const realExec: CheckExec = (file, args) =>
  new Promise((resolve, reject) => {
    execFile(file, args, { timeout: 8000, maxBuffer: 2_000_000, windowsHide: true }, (err, stdout) => (err ? reject(err) : resolve(String(stdout))));
  });

/** The one fixed program for a check on a platform, or null when the check is done through Node (memory, load). */
export function checkProgram(kind: CheckKind, platform: NodeJS.Platform, top = DEFAULT_TOP): { file: string; args: string[] } | null {
  const n = Math.max(1, Math.min(MAX_TOP, Math.floor(top)));
  if (platform === 'win32') {
    if (kind === 'disks') {
      return { file: 'powershell', args: ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', 'Get-PSDrive -PSProvider FileSystem | Select-Object Name,Used,Free | ConvertTo-Csv -NoTypeInformation'] };
    }
    if (kind === 'processes') {
      return { file: 'powershell', args: ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', `Get-Process | Sort-Object CPU -Descending | Select-Object -First ${n} Id,CPU,WorkingSet,ProcessName | ConvertTo-Csv -NoTypeInformation`] };
    }
    return null;
  }
  if (kind === 'disks') return { file: 'df', args: platform === 'darwin' ? ['-kP'] : ['-kP', '-x', 'tmpfs', '-x', 'devtmpfs', '-x', 'squashfs', '-x', 'overlay'] };
  if (kind === 'processes') return { file: 'ps', args: platform === 'darwin' ? ['-Aro', 'pid,pcpu,pmem,comm'] : ['-eo', 'pid,pcpu,pmem,comm', '--sort=-pcpu'] };
  return null;
}

const gb = (kb: number): number => Math.round((kb / 1024 / 1024) * 10) / 10;
const base = (p: string): string => p.split(/[\\/]/).filter(Boolean).pop() ?? p;

/** `df -kP` into rows: mount point, size and used in GB, percent full. Fullest first. */
export function parseDf(text: string): CheckRow[] {
  const rows: CheckRow[] = [];
  for (const line of text.split('\n')) {
    const p = line.trim().split(/\s+/);
    if (p.length < 6 || !/^\d+%$/.test(p[4]!) || !p[5]!.startsWith('/')) continue;
    const total = Number(p[1]);
    const used = Number(p[2]);
    if (!Number.isFinite(total) || !Number.isFinite(used) || total <= 0) continue;
    rows.push({ mount: p.slice(5).join(' '), sizeGb: gb(total), usedGb: gb(used), percent: parseInt(p[4]!, 10) });
  }
  return rows.sort((a, b) => Number(b.percent) - Number(a.percent));
}

/** `ps -eo pid,pcpu,pmem,comm` into rows (header skipped), the first `top`. */
export function parsePs(text: string, top = DEFAULT_TOP): CheckRow[] {
  const rows: CheckRow[] = [];
  for (const line of text.split('\n')) {
    const p = line.trim().split(/\s+/);
    if (p.length < 4 || !/^\d+$/.test(p[0]!) || !/^[\d.]+$/.test(p[1]!) || !/^[\d.]+$/.test(p[2]!)) continue;
    rows.push({ pid: Number(p[0]), cpu: Number(p[1]), mem: Number(p[2]), name: base(p.slice(3).join(' ')).slice(0, 60) });
  }
  return rows.sort((a, b) => Number(b.cpu) - Number(a.cpu) || Number(b.mem) - Number(a.mem)).slice(0, Math.max(1, Math.min(MAX_TOP, top)));
}

const csv = (text: string): string[][] =>
  text
    .split(/\r?\n/)
    .filter((l) => l.trim())
    .map((l) => [...l.matchAll(/"((?:[^"]|"")*)"|([^,]+)/g)].map((m) => (m[1] ?? m[2] ?? '').replace(/""/g, '"')));

/** The PowerShell disk listing (Name, Used, Free in bytes) into rows. */
export function parseWinDisks(text: string): CheckRow[] {
  return csv(text)
    .slice(1)
    .flatMap((r) => {
      const used = Number(r[1]);
      const free = Number(r[2]);
      if (!Number.isFinite(used) || !Number.isFinite(free) || used + free <= 0) return [];
      const total = used + free;
      return [{ mount: `${r[0]}:`, sizeGb: gb(total / 1024), usedGb: gb(used / 1024), percent: Math.round((used / total) * 100) }];
    })
    .sort((a, b) => Number(b.percent) - Number(a.percent));
}

/** The PowerShell process listing (Id, CPU seconds, WorkingSet bytes, name) into rows. CPU is seconds used so far, the best Windows gives cheaply. */
export function parseWinPs(text: string, top = DEFAULT_TOP): CheckRow[] {
  const total = os.totalmem();
  return csv(text)
    .slice(1)
    .flatMap((r) => {
      const pid = Number(r[0]);
      if (!Number.isFinite(pid)) return [];
      const cpu = Number(r[1]);
      const ws = Number(r[2]);
      return [{ pid, cpu: Number.isFinite(cpu) ? Math.round(cpu * 10) / 10 : 0, mem: Number.isFinite(ws) && total ? Math.round((ws / total) * 1000) / 10 : 0, name: (r[3] ?? '').slice(0, 60) }];
    })
    .slice(0, Math.max(1, Math.min(MAX_TOP, top)));
}

export type CheckDeps = { platform?: NodeJS.Platform; exec?: CheckExec; top?: number; memory?: () => { total: number; free: number }; load?: () => { load: number[]; uptime: number; cpus: number } };

/** Runs one named check. Anything not on the list is refused without running anything. */
export async function runCheck(kind: unknown, d: CheckDeps = {}): Promise<CheckResult> {
  if (!isCheckKind(kind)) return { ok: false, say: 'That is not one of the checks this computer offers (disks, processes, memory, load).' };
  const platform = d.platform ?? process.platform;
  const top = d.top ?? DEFAULT_TOP;
  try {
    if (kind === 'memory') {
      const m = d.memory?.() ?? { total: os.totalmem(), free: os.freemem() };
      const used = m.total - m.free;
      return { ok: true, kind, rows: [{ name: 'Memory', totalGb: Math.round((m.total / 2 ** 30) * 10) / 10, usedGb: Math.round((used / 2 ** 30) * 10) / 10, freeGb: Math.round((m.free / 2 ** 30) * 10) / 10, percent: m.total ? Math.round((used / m.total) * 100) : 0 }], say: 'Memory in use now.' };
    }
    if (kind === 'load') {
      const l = d.load?.() ?? { load: os.loadavg(), uptime: os.uptime(), cpus: os.cpus().length };
      return { ok: true, kind, rows: [{ load1: Math.round(l.load[0]! * 100) / 100, load5: Math.round(l.load[1]! * 100) / 100, load15: Math.round(l.load[2]! * 100) / 100, cpus: l.cpus, uptimeHours: Math.round((l.uptime / 3600) * 10) / 10 }], say: 'Load and uptime.' };
    }
    const prog = checkProgram(kind, platform, top);
    if (!prog) return { ok: false, say: 'This check is not available on this kind of computer.' };
    const text = await (d.exec ?? realExec)(prog.file, prog.args);
    const rows = kind === 'disks' ? (platform === 'win32' ? parseWinDisks(text) : parseDf(text)) : platform === 'win32' ? parseWinPs(text, top) : parsePs(text, top);
    if (!rows.length) return { ok: false, say: 'The computer answered, but nothing in it could be read.' };
    return { ok: true, kind, rows, say: kind === 'disks' ? 'Disks, fullest first.' : `The ${rows.length} busiest programs.` };
  } catch {
    return { ok: false, say: 'The check could not run on this computer.' };
  }
}
