import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { HubUserInput } from '@remote-harness/shared';

/**
 * QUEUEUI: the messages waiting on this machine (SessionManager.waiting), kept in data/queue.json so a restart of the agent loses
 * none of them. The hub sends a waiting message again after a restart too; the agent then only confirms it (same inputId).
 */
export type Waiting = {
  /** The agent's id for it (what the apps' queue commands name). */
  id: string;
  input: HubUserInput;
  /** Why it waits, and what the person was told: for a free slot, or for Claude's usage limit. */
  told: 'cap' | 'limit';
  /** When it started waiting (ms). */
  queuedAt: number;
  /** The Claude account it runs on (usage limits are per account). */
  accountId?: string;
};

/**
 * Only what came from the apps is saved. The agent's own messages (`agent:` inputIds: a fix picked up after a restart) are decided
 * again on the next start (fixTests.ts resumeAfterRestart asks Escanor first), so a saved copy would send a second "continue".
 */
export const savable = (w: Waiting): boolean => !w.input.inputId?.startsWith('agent:');

/** At most this many are kept on disk (the oldest first); more than that is not a queue any person manages. */
export const MAX_SAVED_WAITING = 200;

const isObject = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);

function readWaiting(r: unknown): Waiting | null {
  if (!isObject(r) || typeof r.id !== 'string' || !r.id || r.id.length > 200) return null;
  if (r.told !== 'cap' && r.told !== 'limit') return null;
  if (typeof r.queuedAt !== 'number' || !Number.isFinite(r.queuedAt)) return null;
  if (r.accountId !== undefined && typeof r.accountId !== 'string') return null;
  const i = r.input;
  if (!isObject(i) || i.type !== 'user_input' || typeof i.sessionId !== 'string' || !i.sessionId || typeof i.text !== 'string') return null;
  if (i.tempId !== undefined && typeof i.tempId !== 'string') return null;
  if (i.images !== undefined && !Array.isArray(i.images)) return null;
  return { id: r.id, input: i as unknown as HubUserInput, told: r.told, queuedAt: r.queuedAt, ...(r.accountId ? { accountId: r.accountId as string } : {}) };
}

/** What waited when the agent last stopped; nothing when there is no file or it cannot be read. */
export function loadWaiting(file: string): Waiting[] {
  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    return [];
  }
  if (!Array.isArray(raw)) return [];
  const out: Waiting[] = [];
  const ids = new Set<string>();
  for (const r of raw.slice(0, MAX_SAVED_WAITING)) {
    const w = readWaiting(r);
    if (!w || ids.has(w.id) || !savable(w)) continue;
    ids.add(w.id);
    out.push(w);
  }
  return out;
}

/** Written whole each time (a temp file renamed over it), readable only by this user: it holds what the person wrote. */
export function saveWaiting(file: string, waiting: Waiting[]): void {
  try {
    mkdirSync(dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    writeFileSync(tmp, JSON.stringify(waiting.filter(savable).slice(0, MAX_SAVED_WAITING)), { mode: 0o600 });
    renameSync(tmp, file);
  } catch (err) {
    console.error(`Could not write the queue (${err instanceof Error ? err.message : err}).`);
  }
}
