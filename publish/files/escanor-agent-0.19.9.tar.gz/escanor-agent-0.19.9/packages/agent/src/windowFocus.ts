import { realRunner, type Runner } from './computerControl.js';

/**
 * After a page is opened, bring the window it opened in to the front. `xdg-open` hands the address to the browser, which may open it
 * in a window on another workspace, a minimised one or one behind the rest, so the next screen picture would show something else.
 *
 * On X11 and XWayland windows wmctrl can list and raise them: we note every window before opening, then raise the one that appeared
 * or whose title changed (the page's own title), else the browser window that names the site. Where wmctrl cannot see the browser
 * (a native Wayland window) or is not installed, nothing is raised and the answer says to check the picture.
 */

export type Win = { id: string; cls: string; title: string };
export type WinSnap = { ok: boolean; wins: Win[] };

const BROWSER = /(chrom|firefox|brave|vivaldi|opera|edge|epiphany|librewolf|zen|waterfox)/i;

export function parseWmctrl(out: string): Win[] {
  const wins: Win[] = [];
  for (const line of out.split('\n')) {
    // 0x04200003  0 google-chrome.Google-chrome  host Page title
    const m = /^(0x[0-9a-f]+)\s+(-?\d+)\s+(\S+)\s+(\S+)\s?(.*)$/i.exec(line.trim());
    if (m) wins.push({ id: m[1], cls: m[3], title: m[5] });
  }
  return wins;
}

export type FocusDeps = { run?: Runner; env?: NodeJS.ProcessEnv; sleep?: (ms: number) => Promise<void>; platform?: NodeJS.Platform; waitMs?: number };
const nap = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export async function snapshotWindows(d: FocusDeps = {}): Promise<WinSnap> {
  if ((d.platform ?? process.platform) !== 'linux') return { ok: false, wins: [] };
  const r = await (d.run ?? realRunner)({ cmd: 'wmctrl', args: ['-lx'] }, d.env ?? process.env);
  if (r.missing || r.code !== 0) return { ok: false, wins: [] };
  return { ok: true, wins: parseWmctrl(r.stdout) };
}

/** Which window to raise: a new one, else one whose title changed, else the only browser window that names the site. */
export function pickWindow(before: Win[], after: Win[], host: string, guess = true): Win | null {
  const old = new Map(before.map((w) => [w.id, w]));
  const fresh = after.filter((w) => BROWSER.test(w.cls) && !old.has(w.id));
  if (fresh.length) return fresh[fresh.length - 1];
  const changed = after.filter((w) => BROWSER.test(w.cls) && old.has(w.id) && old.get(w.id)!.title !== w.title);
  if (changed.length) return changed[changed.length - 1];
  if (!guess) return null;
  const bare = host.replace(/^www\./, '').split('.')[0].toLowerCase();
  const named = bare.length >= 3 ? after.filter((w) => BROWSER.test(w.cls) && w.title.toLowerCase().includes(bare)) : [];
  if (named.length === 1) return named[0];
  const browsers = after.filter((w) => BROWSER.test(w.cls));
  return browsers.length === 1 ? browsers[0] : null;
}

/** Wait for the browser to react, then raise its window. Resolves true when a window was brought to the front. Never throws. */
export async function raiseOpened(before: WinSnap, host: string, d: FocusDeps = {}): Promise<boolean> {
  if (!before.ok) return false;
  const run = d.run ?? realRunner;
  const env = d.env ?? process.env;
  const sleep = d.sleep ?? nap;
  const end = (d.waitMs ?? 3000) / 400;
  try {
    for (let i = 0; i <= end; i++) {
      await sleep(400);
      const now = await snapshotWindows(d);
      if (!now.ok) return false;
      const w = pickWindow(before.wins, now.wins, host, i >= end); // the site name and the lone browser window are the last resort: wait first for a new window or title
      if (w) {
        const r = await run({ cmd: 'wmctrl', args: ['-i', '-a', w.id] }, env);
        return r.code === 0;
      }
    }
  } catch {
    /* the page is open either way */
  }
  return false;
}
