/**
 * Entry point of the agent when Escanor Desktop starts it (bin/embed.mjs imports this). See embedHost.ts and agent-embed-spec.md.
 * Reads the settings (a JSON line on stdin, or the environment), takes the data folder's lock, loads the normal agent (index.ts)
 * and then only reports health and obeys the few commands the desktop can send.
 */
import { readFileSync, mkdirSync } from 'node:fs';
import { homedir } from 'node:os';
import {
  CONFIG_WAIT_MS, EXIT, EmbedControl, LineReader, MAX_LINE, acquireLock, applyConfigToEnv, configFromEnv, parseEmbedConfig, scrub,
  type AgentLock, type ControlRuntime,
} from './embedHost.js';

const version = (): string => {
  try {
    return JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version as string;
  } catch {
    return 'unknown';
  }
};

// Whatever the agent prints is for the log, never for the event stream.
for (const m of ['log', 'info', 'debug'] as const) console[m] = (...a: unknown[]) => console.error(...a);

const secrets: string[] = [];
let lock: AgentLock | null = null;
let runtime: ControlRuntime | null = null;
let finished = false;

const control = new EmbedControl(
  { write: (line) => void process.stdout.write(line) },
  (reason) => stop(reason),
  () => {
    if (!lock) return;
    if (!lock.owned()) return stop('lock-lost'); // another agent took this data folder (a long sleep made ours look stale): give way
    lock.touch();
  },
);

function finish(code: number): void {
  if (finished) return;
  finished = true;
  control.stopHeartbeat();
  lock?.release();
  const exit = () => process.exit(code);
  setTimeout(exit, 2000).unref(); // a stdout nobody reads must not keep us alive
  process.stdout.write('', exit);
}

function stop(reason: string): void {
  if (finished) return;
  control.setState('stopping');
  try {
    runtime?.stop();
  } catch (err) {
    console.error('Stopping the agent failed:', err instanceof Error ? err.message : err);
  }
  control.emit('stopped', { reason });
  finish(EXIT.ok);
}

function fatal(code: string, message: string, exit: number): void {
  control.error(code, message, true);
  finish(exit);
}

async function start(raw: unknown): Promise<void> {
  const parsed = parseEmbedConfig(raw, homedir());
  if (!parsed.ok) return fatal('bad_config', `${parsed.field}: ${parsed.message}`, EXIT.badConfig);
  const cfg = parsed.config;
  secrets.push(cfg.token);
  control.hide(cfg.token);
  for (const k of cfg.ignoredEnv) control.warning('env_ignored', `The setting ${k} is not one the desktop may set; it was ignored.`);

  try {
    mkdirSync(cfg.workspaceRoot, { recursive: true });
    lock = acquireLock(cfg.dataDir);
  } catch (err) {
    const e = err as Error & { code?: string };
    return fatal(e.code === 'already_running' ? 'already_running' : 'data_dir', e.message, e.code === 'already_running' ? EXIT.alreadyRunning : EXIT.dataDir);
  }

  applyConfigToEnv(cfg, process.env);
  control.identify(cfg.machineId, cfg.kind);

  const { onLinkStatus, currentLinkStatus, getRuntime, setUpdateRequester } = await import('./embedRuntime.js');
  onLinkStatus((s) => control.link(s));
  setUpdateRequester(() => (control.emit('update_request'), true));
  try {
    await import('./index.js');
  } catch (err) {
    return fatal('crash', `The agent could not start: ${err instanceof Error ? err.message : String(err)}`, EXIT.crash);
  }
  delete process.env.HUB_TOKEN; // the agent has its copy; nothing it starts needs this one
  const rt = getRuntime();
  if (finished) {
    // A stop arrived while the agent was loading: stop what just came up, say nothing more.
    try {
      rt?.stop();
    } catch {
      // best effort
    }
    return;
  }
  if (!rt) return fatal('crash', 'The agent started but did not register itself.', EXIT.crash);
  runtime = rt;
  control.setRuntime(rt);
  const current = currentLinkStatus();
  if (current) control.link(current);
  control.emit('ready', { machineId: cfg.machineId, kind: cfg.kind, name: cfg.name ?? null, dataDir: cfg.dataDir, workspaceRoot: cfg.workspaceRoot });
  control.startHeartbeat();
  control.health(true);
}

function crash(err: unknown): void {
  const text = scrub(err instanceof Error ? (err.stack ?? err.message) : String(err), secrets).slice(0, 2000);
  console.error('Agent crashed:', text);
  control.error('crash', text, true);
  try {
    runtime?.stop(); // chats and test runs live in their own process groups: they must not outlive the agent
  } catch {
    // best effort
  }
  finish(EXIT.crash);
}
process.on('uncaughtException', crash);
process.on('unhandledRejection', crash);
for (const signal of ['SIGINT', 'SIGTERM', 'SIGBREAK'] as const) {
  try {
    process.on(signal, () => stop(signal.toLowerCase()));
  } catch {
    // not a signal on this system
  }
}

control.emit('starting', { pid: process.pid, agentVersion: version(), platform: process.platform, arch: process.arch, node: process.version });

let phase: 'waiting' | 'running' = 'waiting';
let configTimer: NodeJS.Timeout | null = null;
const begin = (raw: unknown) => {
  phase = 'running';
  if (configTimer) clearTimeout(configTimer);
  start(raw).catch((err) => fatal('crash', `The agent could not start: ${err instanceof Error ? err.message : String(err)}`, EXIT.crash));
};

const lines = new LineReader(
  (line) => {
    if (phase === 'waiting') {
      try {
        const j = JSON.parse(line) as Record<string, unknown>;
        if (j && j.type === 'config') return begin(j);
      } catch {
        // falls through to the complaint
      }
      control.error('protocol', 'The first line must be the config.', false);
      return;
    }
    try {
      const j = JSON.parse(line) as Record<string, unknown>;
      if (j && j.type === 'config') return control.warning('config_ignored', 'The agent is already configured; restart it to change the settings.');
    } catch {
      // control.command reports it
    }
    control.command(line);
  },
  () => control.error('protocol', `A line was longer than ${MAX_LINE} bytes and was dropped.`, false),
);
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk: string) => lines.push(chunk));
// The desktop closed our stdin: it is gone. Do not stay behind.
process.stdin.on('end', () => (phase === 'waiting' && !finished ? (control.error('config_timeout', 'The desktop closed the channel before sending settings.', true), finish(EXIT.configTimeout)) : stop('host-gone')));
process.stdin.on('error', () => stop('host-gone'));

// The environment form is used only when asked for (ESCANOR_EMBED_CONFIG=env): a shell that happens to hold an agent's HUB_URL and
// HUB_TOKEN must never beat the settings the desktop sends. The token is then readable from /proc/<pid>/environ, so the desktop uses stdin.
let envConfig: Record<string, unknown> | null = null;
try {
  envConfig = process.env.ESCANOR_EMBED_CONFIG === 'env' ? configFromEnv(process.env) : null;
} catch (err) {
  fatal('bad_config', `The token file could not be read: ${err instanceof Error ? err.message : String(err)}`, EXIT.badConfig);
}
if (envConfig) begin(envConfig);
else if (!finished) {
  configTimer = setTimeout(() => fatal('config_timeout', 'No settings arrived within 30 seconds.', EXIT.configTimeout), Number(process.env.ESCANOR_EMBED_CONFIG_WAIT_MS) || CONFIG_WAIT_MS);
  configTimer.unref?.();
}
