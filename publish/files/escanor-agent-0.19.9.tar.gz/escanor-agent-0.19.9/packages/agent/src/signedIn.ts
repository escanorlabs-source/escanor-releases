import { cpSync, existsSync, mkdirSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { hasClaudeSignIn, providerOf, readAccountKey, type ClaudeProfile } from './profiles.js';

/**
 * Which Claude accounts on this computer are signed in, so a chat never stops at Claude Code's "Not logged in · Please run /login".
 * It is Escanor's agent, not a terminal: with another account signed in, a new chat starts on that one, and a chat whose account
 * turns out to be signed out goes on, with its history, on a signed-in one (sessionManager.ts).
 *
 * Two signals, neither reads a secret:
 *  - on Linux, Claude Code keeps its sign-in in <config dir>/.credentials.json, so a missing file means signed out (on macOS and
 *    Windows it sits in the system keychain, so only the second signal counts there);
 *  - Claude Code itself saying so in a chat (signedOutText). That mark holds until the account's sign-in file changes (it was
 *    signed in again from the phone or a terminal).
 */

/** Claude Code's words when the account in use has no working sign-in (current and older wording; an API key that is refused). */
export function signedOutText(text: unknown): boolean {
  return typeof text === 'string' && /not logged in|please run \/login|invalid api key|oauth token (?:has )?(?:expired|been revoked)|authentication_failed/i.test(text);
}

/** The words of an assistant message as Claude Code sends it (its text parts). */
export function assistantText(message: unknown): string {
  const content = (message as { message?: { content?: unknown } })?.message?.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  return content
    .map((part) => (part && typeof part === 'object' && (part as { type?: unknown }).type === 'text' && typeof (part as { text?: unknown }).text === 'string' ? (part as { text: string }).text : ''))
    .join('\n');
}

/** An assistant message that is Claude Code's "not signed in" stop (its error code, or its words in a short reply). */
export function signedOutReply(message: unknown): boolean {
  if ((message as { error?: unknown })?.error === 'authentication_failed') return true;
  const text = assistantText(message);
  return text.length < 300 && signedOutText(text);
}

export type SignInDeps = {
  /** Where an account keeps its sign-in (profileConfigDir). */
  dirOf: (p: ClaudeProfile) => string;
  platform?: NodeJS.Platform;
  env?: NodeJS.ProcessEnv;
};

const mtime = (file: string): number | null => {
  try {
    return statSync(file).mtimeMs;
  } catch {
    return null;
  }
};

export class SignInState {
  /** Accounts Claude Code said were signed out, with their sign-in file's time then (null: no file). */
  private marks = new Map<string, number | null>();

  constructor(private d: SignInDeps) {}

  private credentials(p: ClaudeProfile): string {
    return join(this.d.dirOf(p), '.credentials.json');
  }

  /** Claude Code said this account is not signed in. */
  mark(p: ClaudeProfile): void {
    if (providerOf(p) !== 'claude') return;
    this.marks.set(p.id, mtime(this.credentials(p)));
  }

  /** Whether a chat on this account can start without a sign-in prompt. Accounts of other AIs are never judged here. */
  signedIn(p: ClaudeProfile): boolean {
    if (providerOf(p) !== 'claude') return true;
    if (this.marks.has(p.id)) {
      if (mtime(this.credentials(p)) === this.marks.get(p.id)) return false;
      this.marks.delete(p.id); // signed in again since
    }
    const dir = this.d.dirOf(p);
    if (p.method === 'key') return readAccountKey(dir) !== null;
    if ((this.d.platform ?? process.platform) !== 'linux') return true;
    const env = this.d.env ?? process.env;
    // The machine's own login may be a key or token in the agent's environment instead of a file.
    if (!p.configDir && (env.ANTHROPIC_API_KEY?.trim() || env.CLAUDE_CODE_OAUTH_TOKEN?.trim())) return true;
    return hasClaudeSignIn(dir);
  }
}

const ID_RE = /^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$/;

/**
 * Gives the chat's history (<dir>/projects/<project>/<id>.jsonl, and its helpers' folder) to another account's folder, so the chat
 * can go on there. The original stays where it was. True when the other folder now has it.
 */
export function copyTranscript(sessionId: string, fromDir: string, toDir: string): boolean {
  if (fromDir === toDir) return true;
  if (!ID_RE.test(sessionId)) return false;
  const projects = join(fromDir, 'projects');
  let subs: string[];
  try {
    subs = readdirSync(projects);
  } catch {
    return false;
  }
  for (const sub of subs) {
    const file = join(projects, sub, `${sessionId}.jsonl`);
    if (!existsSync(file)) continue;
    try {
      const target = join(toDir, 'projects', sub);
      mkdirSync(target, { recursive: true, mode: 0o700 });
      cpSync(file, join(target, `${sessionId}.jsonl`), { force: true });
      const helpers = join(projects, sub, sessionId);
      if (existsSync(helpers)) cpSync(helpers, join(target, sessionId), { recursive: true, force: true });
      return true;
    } catch {
      return false;
    }
  }
  return false;
}
