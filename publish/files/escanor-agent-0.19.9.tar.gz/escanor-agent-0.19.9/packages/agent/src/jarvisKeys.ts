import { createHash, createPublicKey, randomBytes, randomInt, randomUUID, timingSafeEqual, verify } from 'node:crypto';
import { chmodSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { DeviceAsk, DeviceAskPurpose } from '@remote-harness/shared';

/**
 * The fingerprint yes, as this computer checks it (Jarvis phase 2). The phone keeps a signing key of its own (ECDSA P-256, the same
 * key the app uses for its secret approvals) and signs only after the phone's own fingerprint, face or PIN check:
 *   escanor-jarvis-v1|<purpose>|<subject>|<nonce>|<machine>
 * This computer trusts a phone's public key only after the person paired it WITH THE COMPUTER IN FRONT OF THEM: the computer shows a
 * six-digit code on its own screen and the phone types it back. A stolen sign-in token cannot pair a key (it cannot see the screen)
 * and cannot sign (it does not hold the key), so it cannot unlock, sign in, look at the screen or turn Remote control on.
 * An ask can be answered once, and only before it runs out.
 */

export const YES_PREFIX = 'escanor-jarvis-v1';
export const ASK_TTL_MS = 2 * 60_000;
export const PAIR_CODE_TTL_MS = 10 * 60_000;
const MAX_KEYS = 10;
const MAX_OPEN_ASKS = 20;
const MAX_PAIR_TRIES = 5;

export const yesMessage = (purpose: DeviceAskPurpose, subject: string, nonce: string, machine: string): string => `${YES_PREFIX}|${purpose}|${subject}|${nonce}|${machine}`;

const unb64u = (s: string): Buffer | null => (/^[A-Za-z0-9_-]+$/.test(s) ? Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64') : null);

/** What the phone calls this key: the first 8 bytes of the SHA-256 of its 65-byte point, in hex (the app's PhoneKey.keyId). */
export function keyIdOf(publicKey: string): string | null {
  const raw = unb64u(publicKey);
  return raw && raw.length === 65 && raw[0] === 4 ? createHash('sha256').update(raw).digest('hex').slice(0, 16) : null;
}

/** Is this the signature of `message` by that public key (65-byte point, url-safe base64; the signature is r || s, 64 bytes)? */
export function verifySignature(publicKey: string, message: string, signature: string): boolean {
  try {
    const raw = unb64u(publicKey);
    const sig = unb64u(signature);
    if (!raw || !sig || raw.length !== 65 || raw[0] !== 4 || sig.length !== 64) return false;
    const key = createPublicKey({ key: { kty: 'EC', crv: 'P-256', x: raw.subarray(1, 33).toString('base64url'), y: raw.subarray(33).toString('base64url') }, format: 'jwk' });
    return verify('sha256', Buffer.from(message), { key, dsaEncoding: 'ieee-p1363' }, sig);
  } catch {
    return false;
  }
}

export type TrustedKey = { keyId: string; publicKey: string; name: string; addedAt: number };

/** The phones this computer trusts for fingerprint yeses. Owner-only file next to the agent's other settings. */
export class KeyStore {
  constructor(private file: string) {}

  list(): TrustedKey[] {
    try {
      const j = JSON.parse(readFileSync(this.file, 'utf8')) as unknown;
      if (!Array.isArray(j)) return [];
      return j.filter((k): k is TrustedKey => !!k && typeof k.keyId === 'string' && typeof k.publicKey === 'string' && keyIdOf(k.publicKey) === k.keyId).slice(0, MAX_KEYS);
    } catch {
      return [];
    }
  }

  get(keyId: string): TrustedKey | undefined {
    return this.list().find((k) => k.keyId === keyId);
  }

  /** Adds (or renames) a phone's key. A bad key, or an eleventh phone, is refused. */
  add(publicKey: string, name: string, now = Date.now()): TrustedKey | null {
    const keyId = keyIdOf(publicKey);
    if (!keyId) return null;
    const cleanName = name.replace(/[^\p{L}\p{N} ._'-]/gu, '').trim().slice(0, 40) || 'Phone';
    // Pairing the same phone again (a reinstall makes a new key) replaces its earlier entry: one row per phone, and the old key stops
    // being trusted. The plain fallback name is shared by every phone that sent none, so it never replaces anything.
    const sameName = (k: TrustedKey) => cleanName !== 'Phone' && k.name.toLowerCase() === cleanName.toLowerCase();
    const rest = this.list().filter((k) => k.keyId !== keyId && !sameName(k));
    if (rest.length >= MAX_KEYS) return null;
    const row: TrustedKey = { keyId, publicKey, name: cleanName, addedAt: now };
    this.write([...rest, row]);
    return row;
  }

  private write(rows: TrustedKey[]): void {
    mkdirSync(dirname(this.file), { recursive: true, mode: 0o700 });
    const tmp = `${this.file}.tmp`;
    writeFileSync(tmp, JSON.stringify(rows), { mode: 0o600 });
    renameSync(tmp, this.file);
    try {
      chmodSync(this.file, 0o600);
    } catch {
      /* best effort */
    }
  }

  exists(): boolean {
    return existsSync(this.file);
  }
}

/** The code shown on the computer's own screen when a phone asks to pair. One at a time, a few tries, ten minutes. */
export class PairingCode {
  private cur: { code: string; at: number; tries: number } | null = null;

  /**
   * The code to show for a phone that asks to pair. A second ask while a code is still good (a double tap, a retry after a slow
   * answer) gets the SAME code: a new one would make the one already on the screen wrong, and the person would type the old one.
   * A code that is used up, locked after wrong tries, or older than its time gets a new one.
   */
  begin(now = Date.now()): string {
    const c = this.cur;
    if (c && now - c.at <= PAIR_CODE_TTL_MS && c.tries < MAX_PAIR_TRIES) return c.code;
    const code = String(randomInt(0, 1_000_000)).padStart(6, '0');
    this.cur = { code, at: now, tries: 0 };
    return code;
  }

  /** True once, for the right code in time. Wrong tries are counted; after five the code is gone. */
  check(given: unknown, now = Date.now()): boolean {
    const c = this.cur;
    if (!c || now - c.at > PAIR_CODE_TTL_MS || typeof given !== 'string') return false;
    if (++c.tries > MAX_PAIR_TRIES) {
      this.cur = null;
      return false;
    }
    const a = Buffer.from(given.trim());
    const b = Buffer.from(c.code);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return false;
    this.cur = null;
    return true;
  }
}

export type PendingAsk<T> = { ask: DeviceAsk; what: T };

/** Asks put to the phone and not yet answered. Each can be taken once; an old one is gone. */
export class AskBook<T> {
  private open = new Map<string, PendingAsk<T>>();

  create(purpose: DeviceAskPurpose, subject: string, machine: string, what: T, now = Date.now()): DeviceAsk {
    this.sweep(now);
    if (this.open.size >= MAX_OPEN_ASKS) {
      const oldest = [...this.open.values()].sort((a, b) => a.ask.expiresAt - b.ask.expiresAt)[0];
      if (oldest) this.open.delete(oldest.ask.askId);
    }
    const ask: DeviceAsk = { askId: randomUUID(), purpose, subject, nonce: randomBytes(16).toString('base64url'), machine, expiresAt: now + ASK_TTL_MS };
    this.open.set(ask.askId, { ask, what });
    return ask;
  }

  /** The ask, once. Null when it is unknown, taken already, or has run out. */
  take(askId: string, now = Date.now()): PendingAsk<T> | null {
    const p = this.open.get(askId);
    if (!p) return null;
    this.open.delete(askId);
    return p.ask.expiresAt > now ? p : null;
  }

  /** Cancels without answering (the phone said no). */
  drop(askId: string): boolean {
    return this.open.delete(askId);
  }

  /** Ids of asks that ran out (removed here, so the phone can be told). */
  sweep(now = Date.now()): string[] {
    const gone: string[] = [];
    for (const [id, p] of this.open) {
      if (p.ask.expiresAt <= now) {
        this.open.delete(id);
        gone.push(id);
      }
    }
    return gone;
  }

  size(): number {
    return this.open.size;
  }
}

/** Does this signed answer belong to the ask, by a phone this computer trusts? */
export function checkYes(keys: KeyStore, ask: DeviceAsk, given: { keyId?: unknown; signature?: unknown }): { ok: true; key: TrustedKey } | { ok: false; why: 'not_paired' | 'unknown_key' | 'bad_signature' } {
  const list = keys.list();
  if (list.length === 0) return { ok: false, why: 'not_paired' };
  const key = typeof given.keyId === 'string' ? list.find((k) => k.keyId === given.keyId) : undefined;
  if (!key) return { ok: false, why: 'unknown_key' };
  if (typeof given.signature !== 'string') return { ok: false, why: 'bad_signature' };
  const msg = yesMessage(ask.purpose, ask.subject, ask.nonce, ask.machine);
  return verifySignature(key.publicKey, msg, given.signature) ? { ok: true, key } : { ok: false, why: 'bad_signature' };
}
