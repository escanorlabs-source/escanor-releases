# Agent helper scripts

`claude-sessions` lists and searches the Claude Code sessions on this machine, from any terminal or any chat the app
started. Copy or link it into `~/.local/bin` (Python 3, no dependencies).

- `claude-sessions`: every live session (terminals, including resumed ones; chats the agent runs) with folder, status, last
  prompt and last reply
- `claude-sessions search WORDS`: every saved session whose prompts or replies mention all the words
- `claude-sessions show ID [N]`: the last N messages of one session (an id prefix is enough)

Keys and tokens are masked in the output. claude.ai chats (the Claude app's chat tab) are stored on Anthropic's servers,
not on this machine, so they never appear.
