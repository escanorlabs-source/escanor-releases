#!/usr/bin/env bash
# Escanor: unlock this computer from your phone, only after your fingerprint.
#
# The Escanor installer already does this, so you normally never run it. It is here to repair or remove the setup:
#
#   remote-unlock-setup.sh          install it (the same step the installer runs; safe to run again)
#   remote-unlock-setup.sh --undo   remove it, and put back what the first version of this script changed:
#                                   automatic sign-in is turned off again and the lock-at-login item is deleted
#
# Nothing here ever turns automatic sign-in on. After a restart you sign in by hand, or approve with your fingerprint in the app.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL="$HERE/unlock/install-root.sh"
ME="$(id -un)"
AUTOSTART="${XDG_CONFIG_HOME:-$HOME/.config}/autostart/escanor-lock-at-login.desktop"

[ -f "$INSTALL" ] || { echo "install-root.sh is missing next to this script ($INSTALL): update Escanor first." >&2; exit 1; }
[ "$(uname -s)" = Linux ] || { echo "This is for Linux computers. Nothing was changed." >&2; exit 1; }

case "${1:-}" in
  --undo)
    sudo bash "$INSTALL" --uninstall
    sudo bash "$INSTALL" --undo-old-autologin --user "$ME"
    rm -f "$AUTOSTART"
    echo "Done: phone sign-in is removed, automatic sign-in is off, and the lock-at-login item is gone."
    ;;
  ""|--install)
    sudo bash "$INSTALL" --user "$ME"
    ;;
  *)
    echo "usage: $0 [--undo]" >&2
    exit 2
    ;;
esac
