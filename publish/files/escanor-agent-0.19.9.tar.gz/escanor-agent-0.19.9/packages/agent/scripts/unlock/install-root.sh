#!/usr/bin/env bash
# Escanor: the privileged part of "unlock only after a fingerprint". Run as root (the agent installer calls it inside its sudo step).
#
#   install-root.sh --user NAME            install (safe to run again; keeps phone keys and the install date)
#   install-root.sh --uninstall            remove everything this script installed (puts back any one-shot login setting first)
#   install-root.sh --undo-old-autologin --user NAME
#                                          undo the OLD remote-unlock-setup.sh: automatic sign-in back off
#   options: --root DIR   work inside DIR instead of / (tests; no systemctl, no ownership changes)
#            --dry-run    say what would change, change nothing
#            --dm gdm|lightdm|sddm|none, --kind laptop|desktop|server|vm   (override detection)
#
# What it installs (ability only; nothing is trusted until the person approves in the Escanor app):
#   /usr/libexec/escanor/session-helper, escanor-wol, install-root.sh   the helper (signs in once, only for a phone-signed approval), the Wake-on-LAN
#                                                               setter, and a copy of this installer (so removing Escanor can undo it)
#   /etc/systemd/system/escanor-session-helper.socket, escanor-session-helper@.service   the helper, started by systemd on demand
#   /etc/systemd/system/escanor-session-cleanup.service        at boot: puts back any one-shot login setting a crash left behind
#   /etc/systemd/system/escanor-wol.service                    Wake-on-LAN on wired network cards, every boot
#   /etc/escanor/unlock.json                                    what this computer is (user, login manager, kind)
#   /var/lib/escanor/unlock/                                    trusted phone keys and used approvals (root only)
# It never turns automatic sign-in on, never writes a password, and changes no login setting by itself.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT=""
USER_NAME=""
MODE=install
DRY=0
DM_OVERRIDE="${ESCANOR_DM:-}"
KIND_OVERRIDE="${ESCANOR_KIND:-}"
SYSTEMCTL="${ESCANOR_INSTALL_SYSTEMCTL:-}"

while [ $# -gt 0 ]; do
  case "$1" in
    --user) USER_NAME="${2:?--user needs a name}"; shift 2 ;;
    --root) ROOT="${2:?--root needs a folder}"; ROOT="${ROOT%/}"; shift 2 ;;
    --uninstall) MODE=uninstall; shift ;;
    --undo-old-autologin) MODE=undo-old; shift ;;
    --dry-run) DRY=1; shift ;;
    --dm) DM_OVERRIDE="${2:?}"; shift 2 ;;
    --kind) KIND_OVERRIDE="${2:?}"; shift 2 ;;
    -h|--help) sed -n '2,19p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
done

say() { printf '    %s\n' "$*"; }
# Everything that changes the computer goes through do_*, so --dry-run changes nothing.
do_() { if [ "$DRY" = 1 ]; then say "would: $*"; else "$@"; fi; }
R() { printf '%s%s' "$ROOT" "$1"; }

if [ -z "$ROOT" ] && [ "$DRY" = 0 ] && [ "$(id -u)" != 0 ]; then
  echo "install-root.sh must run as root (the Escanor installer runs it inside its sudo step)." >&2
  exit 2
fi

HELPER_DIR="$(R /usr/libexec/escanor)"
UNIT_DIR="$(R /etc/systemd/system)"
CONF_DIR="$(R /etc/escanor)"
STATE_DIR="$(R /var/lib/escanor/unlock)"
UNITS=(escanor-session-helper.socket escanor-session-helper@.service escanor-session-cleanup.service escanor-wol.service)
NM_CONF="$(R /etc/NetworkManager/conf.d/escanor-wol.conf)"

# Is the real systemd running here (so enabling units means something)?
use_systemctl() {
  if [ -n "$SYSTEMCTL" ]; then return 0; fi
  [ -z "$ROOT" ] && [ -d /run/systemd/system ] && command -v systemctl >/dev/null 2>&1
}
sctl() { local bin="${SYSTEMCTL:-systemctl}"; if [ "$DRY" = 1 ]; then say "would: $bin $*"; else "$bin" "$@" || true; fi; }

detect_dm() {
  [ -n "$DM_OVERRIDE" ] && { echo "$DM_OVERRIDE"; return; }
  local t="" b
  if [ -L "$(R /etc/systemd/system/display-manager.service)" ]; then
    t="$(basename "$(readlink "$(R /etc/systemd/system/display-manager.service)")")"
  elif [ -f "$(R /etc/X11/default-display-manager)" ]; then
    t="$(basename "$(head -n1 "$(R /etc/X11/default-display-manager)")")"
  fi
  case "$t" in
    gdm*) echo gdm; return ;;
    lightdm*) echo lightdm; return ;;
    sddm*) echo sddm; return ;;
  esac
  for b in gdm3 gdm lightdm sddm; do
    if [ -f "$(R /usr/lib/systemd/system/$b.service)" ] || [ -f "$(R /lib/systemd/system/$b.service)" ]; then
      case "$b" in gdm*) echo gdm ;; *) echo "$b" ;; esac
      return
    fi
  done
  echo none
}

detect_kind() {
  local dm="$1"
  [ -n "$KIND_OVERRIDE" ] && { echo "$KIND_OVERRIDE"; return; }
  if [ -z "$ROOT" ] && command -v systemd-detect-virt >/dev/null 2>&1 && systemd-detect-virt --vm --quiet 2>/dev/null; then echo vm; return; fi
  if compgen -G "$(R /sys/class/power_supply/BAT*)" >/dev/null 2>&1; then echo laptop; return; fi
  if [ "$dm" = none ]; then echo server; else echo desktop; fi
}

write_if_changed() { # $1 path, $2 mode; content on stdin. Prints "changed" or nothing.
  local dest="$1" mode="$2" tmp
  tmp="$(mktemp "${dest}.XXXXXX" 2>/dev/null || mktemp)"
  cat >"$tmp"
  if [ -f "$dest" ] && cmp -s "$tmp" "$dest" && [ "$(stat -c %a "$dest")" = "$mode" ]; then rm -f "$tmp"; return 1; fi
  chmod "$mode" "$tmp"
  mv "$tmp" "$dest"
  return 0
}

# ---------------------------------------------------------------------------------------------------------------------------
undo_old() {
  # What remote-unlock-setup.sh (the first version) did: GDM automatic sign-in on, and a lock-at-login item. Put the sign-in back off.
  echo "==> Turning the old automatic sign-in back off"
  python3 - "$ROOT" "${USER_NAME:-}" "$DRY" <<'PY'
import os, re, sys
root, user, dry = sys.argv[1], sys.argv[2], sys.argv[3] == '1'
conf = None
for d in ('/etc/gdm3', '/etc/gdm'):
    if os.path.isfile(root + d + '/custom.conf'):
        conf = root + d + '/custom.conf'
        break
if not conf:
    print('    no GDM settings file here: nothing to undo')
    sys.exit(0)

def old_script_wrote(text, on, who):
    """Exactly the file the old script's set_autologin produced from `text`."""
    if '[daemon]' not in text:
        text = '[daemon]\n' + text
    head, rest = text.split('[daemon]', 1)
    nxt = re.search(r'^\[', rest, re.M)
    body, tail = (rest[:nxt.start()], rest[nxt.start():]) if nxt else (rest, '')
    body = re.sub(r'^\s*#?\s*AutomaticLoginEnable\s*=.*\n?', '', body, flags=re.M)
    body = re.sub(r'^\s*#?\s*AutomaticLogin\s*=.*\n?', '', body, flags=re.M)
    body = 'AutomaticLoginEnable=%s\nAutomaticLogin=%s\n' % (on, who) + body.lstrip('\n')
    return head + '[daemon]\n' + body + tail

def autologin_on(text):
    return re.search(r'^\s*AutomaticLoginEnable\s*=\s*(true|1|yes|on)\s*$', text, re.M | re.I) is not None

def set_false(text):
    if re.search(r'^\s*AutomaticLoginEnable\s*=', text, re.M):
        return re.sub(r'^(\s*)AutomaticLoginEnable\s*=.*$', r'\1AutomaticLoginEnable=False', text, flags=re.M)
    return text

cur = open(conf, encoding='utf-8').read()
if not autologin_on(cur):
    print('    automatic sign-in is already off in ' + conf)
    sys.exit(0)
bak = conf + '.escanor-backup'
new = None
if os.path.isfile(bak):
    orig = open(bak, 'rb').read()
    text = orig.decode('utf-8', 'replace')
    who = user
    m = re.search(r'^\s*AutomaticLogin\s*=\s*(\S+)', cur, re.M)
    if m:
        who = m.group(1)
    # Old script wrote either layout (the first version put a blank line before the settings); accept both.
    wrote = [old_script_wrote(text, 'True', who)]
    wrote.append(wrote[0].replace('[daemon]\nAutomaticLoginEnable', '[daemon]\n\nAutomaticLoginEnable', 1))
    if cur in wrote and not autologin_on(text):
        new = orig
        print('    restoring ' + conf + ' from the copy the old setup kept')
if new is None:
    new = set_false(cur).encode('utf-8')
    print('    setting AutomaticLoginEnable=False in ' + conf + ' (the file was changed since, so it is edited, not replaced)')
if dry:
    print('    would write ' + conf)
    sys.exit(0)
st = os.stat(conf)
tmp = conf + '.escanor-tmp'
with open(tmp, 'wb') as f:
    f.write(new)
os.chmod(tmp, st.st_mode & 0o7777)
try:
    os.chown(tmp, st.st_uid, st.st_gid)
except PermissionError:
    pass
os.rename(tmp, conf)
PY
}

# ---------------------------------------------------------------------------------------------------------------------------
uninstall() {
  echo "==> Removing phone sign-in from this computer"
  if [ -x "$HELPER_DIR/session-helper" ] && [ "$DRY" = 0 ]; then ESCANOR_HELPER_ROOT="$ROOT" "$HELPER_DIR/session-helper" cleanup >/dev/null 2>&1 || true; fi
  if use_systemctl; then
    for u in escanor-session-helper.socket escanor-session-cleanup.service escanor-wol.service; do sctl disable --now "$u"; done
  fi
  for u in "${UNITS[@]}"; do do_ rm -f "$UNIT_DIR/$u"; done
  do_ rm -f "$HELPER_DIR/session-helper" "$HELPER_DIR/escanor-wol" "$NM_CONF" "$HELPER_DIR/install-root.sh"
  do_ rm -f "$CONF_DIR/unlock.json" "$STATE_DIR/phone-keys.json" "$STATE_DIR/used-nonces" "$STATE_DIR/lock" "$STATE_DIR/oneshot/meta.json" "$STATE_DIR/oneshot/original"
  for d in "$STATE_DIR/oneshot" "$STATE_DIR" "$(R /var/lib/escanor)" "$CONF_DIR" "$HELPER_DIR"; do
    [ "$DRY" = 1 ] && continue
    rmdir "$d" 2>/dev/null || true
  done
  if use_systemctl; then sctl daemon-reload; fi
  say "removed"
}

# ---------------------------------------------------------------------------------------------------------------------------
install_all() {
  [ -n "$USER_NAME" ] || { echo "--user NAME is required" >&2; exit 2; }
  case "$USER_NAME" in *[!a-zA-Z0-9._-]*|-*|"") echo "not a valid login name: $USER_NAME" >&2; exit 2 ;; esac
  if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 is missing, so phone sign-in cannot be installed here. Everything else works." >&2
    exit 3
  fi
  local dm kind grp
  dm="$(detect_dm)"; kind="$(detect_kind "$dm")"
  case "$dm" in gdm|lightdm|sddm|none) ;; *) echo "unknown login manager: $dm" >&2; exit 2 ;; esac
  if [ -z "$ROOT" ]; then grp="$(id -gn "$USER_NAME" 2>/dev/null || true)"; [ -n "$grp" ] || { echo "no such user: $USER_NAME" >&2; exit 2; }
  else grp="$(id -gn "$USER_NAME" 2>/dev/null || echo "$USER_NAME")"; fi
  echo "==> Setting up phone sign-in (ability only; off until you approve it in the Escanor app)"
  say "user: $USER_NAME   login manager: $dm   kind: $kind"

  do_ mkdir -p "$HELPER_DIR" "$UNIT_DIR" "$CONF_DIR" "$STATE_DIR/oneshot"
  do_ chmod 0755 "$HELPER_DIR" "$CONF_DIR"
  do_ chmod 0700 "$(R /var/lib/escanor)" "$STATE_DIR" "$STATE_DIR/oneshot" 2>/dev/null || true
  if [ "$DRY" = 1 ]; then
    say "would: install the helper, the Wake-on-LAN script, 4 systemd units, $CONF_DIR/unlock.json"
    for u in escanor-session-helper.socket escanor-session-cleanup.service escanor-wol.service; do sctl enable "$u"; done
    return
  fi

  # The helper and the Wake-on-LAN setter (root-owned, not writable by anyone else).
  # (a copy of this installer stays next to the helper, so removing Escanor can take the helper out again without the app's files)
  [ "$SRC/session-helper" -ef "$HELPER_DIR/session-helper" ] || install -m 0755 "$SRC/session-helper" "$HELPER_DIR/session-helper"
  [ "${BASH_SOURCE[0]}" -ef "$HELPER_DIR/install-root.sh" ] || install -m 0755 "${BASH_SOURCE[0]}" "$HELPER_DIR/install-root.sh"
  cat >"$HELPER_DIR/escanor-wol.tmp" <<'WOL'
#!/bin/sh
# Wake-on-LAN (magic packet) on every wired network card, so a suspended or powered-off computer can be woken from the Escanor app.
for n in /sys/class/net/*; do
  name=$(basename "$n")
  [ -e "$n/device" ] || continue          # real hardware only (no docker, bridges, tunnels)
  [ -d "$n/wireless" ] && continue        # wired only
  [ "$(cat "$n/type" 2>/dev/null)" = 1 ] || continue
  if command -v ethtool >/dev/null 2>&1; then ethtool -s "$name" wol g >/dev/null 2>&1 || true; fi
done
exit 0
WOL
  chmod 0755 "$HELPER_DIR/escanor-wol.tmp"; mv "$HELPER_DIR/escanor-wol.tmp" "$HELPER_DIR/escanor-wol"
  if [ -z "$ROOT" ]; then chown root:root "$HELPER_DIR/session-helper" "$HELPER_DIR/escanor-wol" "$HELPER_DIR/install-root.sh"; fi

  local changed=0
  write_if_changed "$UNIT_DIR/escanor-session-helper.socket" 644 <<EOF && changed=1
[Unit]
Description=Escanor phone sign-in helper (started only when the Escanor service asks)

[Socket]
ListenStream=/run/escanor/session-helper.sock
SocketMode=0660
SocketUser=root
SocketGroup=$grp
DirectoryMode=0755
Accept=yes
MaxConnections=4

[Install]
WantedBy=sockets.target
EOF
  write_if_changed "$UNIT_DIR/escanor-session-helper@.service" 644 <<'EOF' && changed=1
[Unit]
Description=Escanor phone sign-in helper (one request)

[Service]
Type=simple
StandardInput=socket
StandardOutput=socket
StandardError=journal
ExecStart=/usr/libexec/escanor/session-helper serve
RuntimeMaxSec=150
PrivateTmp=true
ProtectHome=true
NoNewPrivileges=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictRealtime=true
LockPersonality=true
EOF
  write_if_changed "$UNIT_DIR/escanor-session-cleanup.service" 644 <<'EOF' && changed=1
[Unit]
Description=Escanor: put back any one-shot login setting a crash left behind
DefaultDependencies=no
After=local-fs.target
Before=display-manager.service gdm.service gdm3.service lightdm.service sddm.service

[Service]
Type=oneshot
ExecStart=/usr/libexec/escanor/session-helper cleanup

[Install]
WantedBy=multi-user.target
EOF
  write_if_changed "$UNIT_DIR/escanor-wol.service" 644 <<'EOF' && changed=1
[Unit]
Description=Escanor: Wake-on-LAN on wired network cards
After=network-pre.target
Wants=network-pre.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/libexec/escanor/escanor-wol

[Install]
WantedBy=multi-user.target
EOF
  if [ -d "$(R /etc/NetworkManager)" ]; then
    mkdir -p "$(dirname "$NM_CONF")"
    write_if_changed "$NM_CONF" 644 <<'EOF' && changed=1
# Escanor: let a wired connection be woken by a magic packet (new connections; the Escanor service also sets it each boot).
[connection]
ethernet.wake-on-lan=magic
EOF
  fi

  # The record of what this computer is. Keeps the install date and a machine id already written.
  python3 - "$CONF_DIR/unlock.json" "$USER_NAME" "$dm" "$kind" <<'PY'
import json, os, sys, time
path, user, dm, kind = sys.argv[1:5]
old = {}
try:
    old = json.load(open(path))
except Exception:
    pass
rec = {'version': 1, 'user': user, 'dm': dm, 'kind': kind, 'installed_at': old.get('installed_at') or int(time.time() * 1000)}
if isinstance(old.get('machine'), str) and old['machine']:
    rec['machine'] = old['machine']
new = json.dumps(rec) + '\n'
if not os.path.exists(path) or open(path).read() != new:
    tmp = path + '.tmp'
    with open(tmp, 'w') as f:
        f.write(new)
    os.chmod(tmp, 0o644)
    os.rename(tmp, path)
PY
  chmod 0644 "$CONF_DIR/unlock.json"
  # Phone keys and used approvals (root only). Never replaced when they exist.
  [ -f "$STATE_DIR/phone-keys.json" ] || (umask 077; printf '[]' >"$STATE_DIR/phone-keys.json")
  [ -f "$STATE_DIR/used-nonces" ] || (umask 077; : >"$STATE_DIR/used-nonces")

  if use_systemctl; then
    [ "$changed" = 1 ] && sctl daemon-reload
    sctl enable --now escanor-session-helper.socket
    sctl enable --now escanor-session-cleanup.service
    sctl enable --now escanor-wol.service
  else
    say "systemd is not running here (container or test folder): units written, not started"
  fi
  say "done. Nothing signs in until you approve it on your phone with your fingerprint."
}

case "$MODE" in
  install) install_all ;;
  uninstall) uninstall ;;
  undo-old) undo_old ;;
esac
