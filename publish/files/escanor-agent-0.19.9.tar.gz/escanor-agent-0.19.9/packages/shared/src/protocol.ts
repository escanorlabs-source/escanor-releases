// Wire protocol shared by the agent (runs on each VM), the hub (the server
// you run once), and the web/PWA client. Kept as plain data types so all
// three sides can import it without pulling in the Claude Agent SDK.

export type ImageAttachment = {
  mediaType: string;
  dataBase64: string;
};

export type PermissionDecision = 'allow' | 'deny';

/** Which AI an account on a machine is: absent means 'claude' (older agents only had Claude accounts). */
export type AccountProvider = 'claude' | 'chatgpt' | 'gemini' | 'copilot';
export const ACCOUNT_PROVIDERS: readonly AccountProvider[] = ['claude', 'chatgpt', 'gemini', 'copilot'];

/**
 * One AI account on a machine. The type keeps its old name for compatibility; `MachineAccount` is the same thing.
 * `provider` absent = 'claude'. Ids of ChatGPT / Gemini / GitHub Copilot accounts start with `chatgpt-` / `gemini-` / `copilot-`.
 */
export type ClaudeAccount = {
  id: string;
  label: string;
  provider?: AccountProvider;
  email?: string;
};
export type MachineAccount = ClaudeAccount;

// ---------- Agent -> Hub ----------

export type AgentHello = {
  type: 'hello';
  agentVersion: string;
  /** What this agent does: `isolated` (isolated chats), `chat_user` (chats run as their own OS users, not the agent's), `preview_open` (can open a fix on this computer), `preview_link` (can serve that through a private hub link). */
  capabilities?: string[];
  /** The machine's boot (ESCANOR_BOOT_ID): Escanor delivers waiting messages only to the agent of the current boot. */
  bootId?: string;
  vmName: string;
  hostname: string;
  accounts: ClaudeAccount[];
  sessions: AgentSessionSummary[];
  /**
   * Permission prompts and questions (AskUserQuestion) still waiting for an answer on this machine (agents from 0.9.0). The hub
   * keeps them pending and expires any other prompt of this machine it still shows as pending: the machine no longer waits for it.
   * Each one is also sent again as a `permission_request` with `resent: true` right after the hello.
   */
  pending?: AgentPendingRequest[];
  /** What kind of machine this is, found by looking (agents from 0.9.14): the app builds its screens for it. */
  machine?: MachineSummary;
  /** The stable id of the computer when the agent runs inside Escanor Desktop (its install id): lets the apps tell this machine and the desktop's own pairing are one. */
  machineId?: string;
  /** Older ids of this same computer (the Desktop install id): the hub merges a duplicate row into this machine (agents from 0.19.6). */
  legacyMachineIds?: string[];
  /** This computer was set up again on purpose: a removed machine joins again (agents from 0.19.6). */
  repaired?: boolean;
  /** What AI this machine can use (agents from 0.11.0); see LocalAiReport. */
  localAi?: LocalAiReport;
};

/** laptop, desktop, server, device (a Raspberry Pi and the like), vm; for a VM in a cloud, which cloud and its own names for it. `personal` = the owner's own computer running the agent inside Escanor Desktop. */
export type MachineSummary = {
  kind: 'laptop' | 'desktop' | 'server' | 'device' | 'vm' | 'personal' | 'unknown';
  os: string;
  cloud?: 'gcp' | 'aws' | 'azure' | 'oci';
  cloudInfo?: Record<string, string>;
  macs: string[];
};

/** The hub asks this machine to do something about its own power: sleep now, or send a wake-up to another machine on its network. */
export type HubPowerCommand = {
  type: 'power_command';
  action: 'suspend' | 'wol';
  /** For wol: the hardware address to wake. */
  mac?: string;
  /** For wol: the machine (its id on the hub) being woken, the one the fingerprint yes names. */
  target?: string;
  /** For wol: the owner's fingerprint yes, signed `escanor-jarvis-v1|wake|<target>:<expiresAt>|<nonce>|<target>` by a phone. Without a good one nothing is sent. */
  approval?: { keyId: string; signature: string; nonce: string; expiresAt: number };
};

/** A prompt waiting on this machine (hello.pending). */
export type AgentPendingRequest = {
  requestId: string;
  sessionId: string;
  toolName: string;
  input: Record<string, unknown>;
  blockedPath?: string;
  /** What it will do in everyday words (shared/describe.ts); absent from older agents. */
  summary?: string;
  /** When the machine asked, ISO. */
  askedAt: string;
};

export type AgentSessionSummary = {
  sessionId: string;
  cwd: string;
  title: string;
  createdAt: string;
  status: 'active' | 'idle';
  accountId: string;
  /** Put away by the agent to stay under its open-chat cap (agents from 0.8.0): still resumable by a message. */
  archived?: boolean;
  /** How the chat was found (agents from 0.9.5): a terminal or Desktop Code session, or one the agent started. Older agents omit it. */
  source?: 'terminal' | 'desktop' | 'agent';
  /** The last prompt or reply, one line, at most 160 characters, secrets hidden. Empty when unknown. */
  preview?: { role: 'prompt' | 'reply'; text: string };
  /** The person marked this chat Priority (agents from 0.12.4): its work goes first on this machine. */
  priority?: true;
};

/** A chat's Priority mark changed (agents from 0.12.4), after a set_priority: the hub and the apps show the new mark. */
export type AgentSessionPriority = {
  type: 'session_priority';
  sessionId: string;
  priority: boolean;
};

export type AgentSdkMessage = {
  type: 'sdk_message';
  sessionId: string;
  tempId?: string;
  message: unknown; // raw SDKMessage from @anthropic-ai/claude-agent-sdk
};

// The reply as it is being written (the full text so far, not a delta), so a phone shows it without waiting for the whole
// message. Not stored by the hub; the finished message arrives as an sdk_message like any other.
export type AgentSdkPartial = {
  type: 'sdk_partial';
  sessionId: string;
  tempId?: string;
  text: string;
};

export type AgentSessionCreated = {
  type: 'session_created';
  tempId: string;
  sessionId: string;
  cwd: string;
  title: string;
  accountId: string;
  /** A chat found in a terminal / Desktop Code (agents from 0.9.5); absent for one the agent started. */
  source?: 'terminal' | 'desktop';
};

export type AgentSessionEnded = {
  type: 'session_ended';
  sessionId: string;
  reason?: string;
};

/**
 * A small chat this machine opened for itself is used up and deleted here (smallSessions.ts): an automation run nobody typed
 * in, or a terminal session that never got a reply (only /model, /clear...). The hub forgets it and the apps drop it.
 */
export type AgentSessionDeleted = {
  type: 'session_deleted';
  sessionId: string;
};

export type AgentPermissionRequest = {
  type: 'permission_request';
  sessionId: string;
  requestId: string;
  toolName: string;
  input: Record<string, unknown>;
  blockedPath?: string;
  /**
   * What it will do in everyday words ("Delete the folder build and everything in it", shared/describe.ts), for the phone's
   * approval bar. Optional: older agents leave it out and the apps describe the call themselves.
   */
  summary?: string;
  /** The same prompt announced again (after a reconnect): already stored and pushed once, so neither again. */
  resent?: true;
};

export type AgentError = {
  type: 'error';
  sessionId?: string;
  tempId?: string;
  message: string;
  // 'notice' = a status line, not a failure ("Queued: ...", "usage limit reached; will resume at ..."). Absent = an error.
  // Older hubs and apps drop it and show the line as an error, which is the old behaviour.
  kind?: 'notice';
};

export type AgentProjectsList = {
  type: 'projects_list';
  requestId: string;
  projects: string[]; // relative paths under the agent's workspace root
};

export type AgentMcpServerStatus = {
  name: string;
  // 'configured' = accepted and will be used by the next session; the others are what a
  // live session's own MCP client reported when it dialled the server.
  status: 'configured' | 'connected' | 'pending' | 'needs-auth' | 'failed' | 'disabled';
  error?: string;
};

export type AgentMcpStatus = {
  type: 'mcp_status';
  servers: AgentMcpServerStatus[];
  liveSessions: number; // sessions the change was applied to without a restart
};

/** A running subagent or background task of a chat (the Task/Agent tool). */
export type AgentTaskInfo = { id: string; description: string };

/**
 * What a chat is doing right now, in the machine's own words (DEV5). Sent on change, at most about one every 2 s per chat (the
 * last state always goes out). `step` is one short line ("Running: npm test", "Editing: src/x.ts", "Waiting for your OK: Bash"),
 * null when idle. A chat waiting for an answer counts as running (`waiting: true`).
 */
export type AgentSessionActivity = {
  type: 'session_activity';
  sessionId: string;
  activity: 'running' | 'idle';
  waiting: boolean;
  tasks: AgentTaskInfo[];
  step: string | null;
  /**
   * Optional (agent 0.11.1+): work the chat left running after its turn ended (background helpers and commands, a scheduled
   * wake-up). Claude Code wakes the chat by itself when one finishes, so the chat is working in the background, not idle, and a
   * message sent to it is taken in without stopping anything. Then `step` starts with BACKGROUND_STEP. Absent: none.
   */
  background?: AgentBackgroundWork;
};

/** Work a chat left running after its turn: how many helpers and commands still run, and when it wakes itself (ISO), if it will. */
export type AgentBackgroundWork = { helpers: number; commands: number; wakeAt?: string };

/** How a chat's step starts while it works in the background ("Working in the background · 3 helpers running · wakes up at 14:05"). */
export const BACKGROUND_STEP = 'Working in the background';

/**
 * A phone/app message reached this machine (DEV6): `delivered` = accepted by the SDK (taken to be written to Claude Code), `queued` = held on this machine for a free
 * slot or for Claude's usage limit (delivered later, with a second ack), `refused` = it will not run (`reason` says why).
 * `inputId` echoes HubUserInput.inputId when the hub gave one; `sessionId` is the chat it went to (the real id once known), and
 * `tempId` the new chat's temp id it was sent to.
 */
export type AgentInputAck = {
  type: 'input_ack';
  sessionId: string;
  tempId?: string;
  inputId?: string;
  status: 'delivered' | 'queued' | 'refused';
  reason?: string;
};

/**
 * The answer to a prompt reached the waiting chat (`delivered: true`), or there was nothing waiting for it any more
 * (`delivered: false`: the chat ended, the machine restarted, or it was answered already). An approval is done only once delivered.
 */
export type AgentPermissionAck = {
  type: 'permission_ack';
  requestId: string;
  sessionId?: string;
  delivered: boolean;
};

/** What runs on this machine now (DEV7): sent every 60 s and on change. No secrets: no env values, no full command lines. */
export type AgentMachineState = {
  type: 'machine_state';
  state: MachineState;
};

/** How much of one Claude account's usage window is used (VAULT6; agents report it unless ESCANOR_ACCOUNT_USAGE=0). */
export type AccountUsage = {
  /** Percent of the five-hour window used (0-100). */
  five_hour_pct: number;
  /** When that window resets, ISO; null when Claude gave none. */
  resets_at: string | null;
  seven_day_pct?: number;
  /** When the weekly window resets, ISO (agents from 0.12.9). */
  seven_day_resets_at?: string | null;
  /** When the agent last read it, ISO. */
  checked_at: string;
  /** A chat is running on this computer with this account right now (agents from 0.19.5). */
  in_use?: boolean;
  /**
   * The account's usage kept climbing with none of Escanor's chats using it: something else (another computer or app) is using it
   * (agents from 0.19.5). Cleared by the next reading that shows no such rise.
   */
  outside_use?: boolean;
  /** The last reading failed (rate limit or a network error); the figures are the last good ones, `checked_at` says how old (agents from 0.19.5). */
  stale?: boolean;
};

export type MachineState = {
  /** When it was taken, ISO. */
  at: string;
  /** Usage per Claude account id (VAULT6); absent when the agent does not report it. */
  usage?: Record<string, AccountUsage>;
  /**
   * "Give way to me" (agents from 0.12.9): the setting, and what the computer is doing for the person now: `level` normal / yield
   * (lowest priority, new work waits) / pause (our chat processes stopped), with the words to show ("Paused: you're using this
   * computer", "Waiting: computer busy"). Absent on older agents.
   */
  giveWay?: { mode: 'on' | 'gentle' | 'off'; level: 'normal' | 'yield' | 'pause'; why?: 'using' | 'busy' | 'memory'; text?: string; stopped?: number };
  /**
   * AI accounts that reached their limit (agents from 0.12.9): all their work waits and starts by itself at `resetsAt` (ISO).
   * `text` is ready to show ("AI limit reached on Work: starts again at 3:40 pm"). Empty/absent = none.
   */
  aiLimits?: Array<{ accountId: string; label: string; resetsAt: string; source: 'message' | 'usage' | 'plan'; text: string }>;
  /** Device mesh (agents from 0.15.0): is the person at this computer now (input idle time, lock). Absent where it cannot tell. */
  presence?: { at: string; idleSeconds?: number; active?: boolean; locked?: boolean };
  /** What this computer can do for the device mesh: computer_control, screen, notifications. */
  deviceCaps?: string[];
  health: {
    cpuPct: number | null;
    load1: number;
    cores: number;
    memUsedPct: number;
    memTotalMb: number;
    diskUsedPct: number | null;
    diskFreeGb: number | null;
    uptimeS: number;
    battery?: { pct: number; charging: boolean } | null;
  };
  /** Listening TCP ports (the process only when this user owns it). */
  ports: Array<{ port: number; addr: string; process?: string; pid?: number }>;
  /** Listening ports that look like a dev server, with a short label ("next dev", "vite", "uvicorn") and its folder. */
  devServers: Array<{ port: number; url: string; label: string; pid: number; cwd?: string }>;
  /** null = Docker is not installed or not reachable here. */
  docker: Array<{ id: string; name: string; image: string; state: string; status: string; ports: string }> | null;
  /** Git repositories under the workspace (relative path; '.' = the workspace itself). */
  repos: Array<{ path: string; branch: string | null; head: string | null; dirty: boolean; changes: number; ahead: number | null; behind: number | null }>;
  /** Test and build runs going on right now (by process). */
  running: Array<{ kind: 'test' | 'build'; label: string; pid: number; cwd?: string }>;
  /** Coding agents on this machine: Claude chats (by session) and other agents (Codex, Aider, ...) by process. */
  agents: Array<{ kind: string; state: string; pid?: number; sessionId?: string; cwd?: string; source: 'escanor' | 'terminal' | 'process' }>;
  /** The last test / build run this machine saw finish (a chat's command, or a fix's own test run), if any. */
  lastTest: MachineRunResult | null;
  lastBuild: MachineRunResult | null;
};

export type MachineRunResult = { cmd: string; ok: boolean; exit?: number; at: string; sessionId?: string; by: 'chat' | 'agent' };

/**
 * The agent's own test run for a fix done on this machine (FLOW3, backend FX9): sent as an `sdk_message` whose `message` is this
 * row. Only the agent process makes one: a model-produced message of this type is never forwarded (wsClient.ts).
 */
export type EscanorTestsRow = {
  type: 'escanor_tests';
  repo: string;
  branch: string;
  base: string;
  head: string;
  tests_before: { cmd: string; exit: number; tail: string };
  tests_after: { cmd: string; exit: number; tail: string };
};

/** sdk_message `message.type`s only the agent itself may produce: a copy coming from Claude is dropped, never forwarded. */
export const AGENT_ONLY_ROW_TYPES: ReadonlySet<string> = new Set(['escanor_tests']);

/**
 * One message waiting on this machine (agents from 0.9.7, QUEUEUI): for a free chat slot ('cap') or for Claude's usage limit to
 * reset ('limit'). Never the whole message: `preview` is its first words (at most QUEUE_PREVIEW_CHARS).
 */
export type QueueItem = {
  /** The agent's id for this waiting message (what the queue commands name). */
  id: string;
  /** The hub's id for the message (HubUserInput.inputId), when it had one. */
  inputId?: string;
  /** The chat it is for: a real chat id, or the new chat's temp id (then `newChat` is true). */
  sessionId: string;
  tempId?: string;
  /** It starts a new chat (true), or it is for a chat that exists (false). */
  newChat: boolean;
  /** The existing chat's title, when it is for one this machine knows. */
  chatTitle?: string;
  /** The first words of the message, on one line. */
  preview: string;
  /** It also has pictures. */
  images?: number;
  reason: 'cap' | 'limit';
  /** Sent as priority: it waits ahead of the others (agents from 0.12.9). */
  priority?: true;
  /**
   * Set while the computer's own limits hold new work (agents from 0.12.5): 'memory' = short of memory, 'load' = busy. The reason is
   * still 'cap' (older apps show "waiting for a slot"); apps that know this show "Waiting: this computer is busy, it starts when it
   * has room" (or "short of memory"). 'user' (agents from 0.12.9) = the person is using this computer ("you're using this computer").
   */
  busy?: 'memory' | 'load' | 'user';
  /** 0 = next to start. */
  position: number;
  /** When it started waiting, ISO. */
  queuedAt: string;
  /** For 'limit': when Claude's usage limit resets, ISO, when Claude said. */
  resetsAt?: string;
};

/** Every message waiting on this machine, in the order they start (agents from 0.9.7). Sent on every change and on (re)connect. */
export type AgentQueueState = {
  type: 'queue_state';
  items: QueueItem[];
  /** How many chats this machine keeps open, and runs at once (its caps). */
  maxOpen?: number;
  maxLive?: number;
  at: string;
};

/** The answer to a queue command (requestId echoes the command's). `error` says in plain words why it was not done. */
export type AgentQueueResult = {
  type: 'queue_result';
  requestId: string;
  ok: boolean;
  error?: string;
  /** queue_get: the message's whole current text (an edit included). */
  text?: string;
};

/**
 * The answer to an account command (requestId echoes the command's). `start` returns the sign-in page to open (`url`) and the
 * `flowId` the code is sent with; a finished sign-in, a rename or a removal returns the account and the machine's whole account
 * list (`accounts`), which the hub keeps and shows like a hello's. `error` says in plain words why it was not done.
 */
export type AgentAccountResult = {
  type: 'account_result';
  requestId: string;
  ok: boolean;
  error?: string;
  flowId?: string;
  url?: string;
  /** ChatGPT / GitHub Copilot device sign-in: the one-time code the person types on the sign-in page (`url`). None for ChatGPT's browser sign-in. */
  userCode?: string;
  /** How the started sign-in finishes: 'signin' (sign-in page) or 'key' (paste an API key). */
  method?: 'signin' | 'key';
  account?: ClaudeAccount;
  accounts?: ClaudeAccount[];
};

/** The limits validate.ts repeats (it imports nothing at run time from here). */
export const MAX_SUBAGENT_ITEMS = 50;
export const MAX_SUBAGENT_STEPS = 50;

/**
 * One background helper of a chat (a Claude Code subagent), as this machine sees it. Plain words only: `description` is what the
 * helper was asked to do, `lastStep` its newest step ("Running: npm test"), `summary` how it ended (finished helpers only).
 */
export type SubagentItem = {
  id: string;
  description: string;
  model?: string;
  /** The helper that started this one (nested helpers). */
  parentId?: string;
  state: 'running' | 'finished';
  startedAt: string;
  finishedAt?: string;
  lastStep?: string;
  summary?: string;
  /** Finished without a word from the helper: its process is gone (shown as Stopped). */
  stopped?: boolean;
};

/**
 * The background helpers of one chat (agents from 0.9.8). Sent on change, at most once a second per chat, the latest list last;
 * an empty list clears. Old hubs and apps ignore the kind.
 */
export type AgentSubagents = {
  type: 'subagents';
  sessionId: string;
  items: SubagentItem[];
};

/** One recent step of a helper, read-only: role is who spoke (assistant text, a tool call, a tool result, the first prompt). */
export type SubagentStep = {
  index: number;
  role: 'assistant' | 'tool' | 'result' | 'user';
  text: string;
  at?: string;
};

/** The answer to subagent_steps (requestId echoes the command's): the newest steps before `before`, oldest first. */
export type AgentSubagentStepsResult = {
  type: 'subagent_steps_result';
  requestId: string;
  ok: boolean;
  error?: string;
  steps?: SubagentStep[];
  /** Pass as `before` for the next older page; absent when there is nothing older. */
  nextBefore?: number;
};


// ---------- Safety layer (agent 0.10.0+, packages/agent/src/safetyAgent.ts, undo.ts, tripwire.ts) ----------

/** One copy Escanor kept before an AI deleted or threw something away (put back with safety_action restore). */
export type SafetyUndo = {
  id: string;
  at: number;
  /** agent: an Escanor chat; machine: any other Claude on the computer; snapshot: the daily copy of the person's own folders. */
  source: 'agent' | 'machine' | 'snapshot';
  command: string;
  cwd: string;
  paths: string[];
  files: number;
  bytes: number;
  git: string[];
  partial?: boolean;
  restoredAt?: number;
};
export type SafetyEventRow = {
  at: number;
  action: 'backup' | 'block' | 'hold' | 'trip' | 'restore' | 'resume' | 'stop' | 'guard' | 'remote';
  source: 'agent' | 'machine' | 'tripwire' | 'app';
  command?: string;
  why?: string;
  cwd?: string;
  undoId?: string;
  paths?: string[];
};
export type SafetyTrip = { at: number; reason: string; deleted: string[]; paused: number };
export type SafetyState = {
  /** The safety layer is on (ESCANOR_SAFETY not 0). */
  enabled: boolean;
  /** What no copy can undo waits for the person's Approve (ESCANOR_RISK_HOLDS not 0). */
  holds: boolean;
  /** Claude settings files on the computer that carry the machine-wide guard / all found. */
  guard: { set: number; files: number };
  /** The tripwire paused the AIs here and waits for Resume or Stop. */
  tripped: SafetyTrip | null;
  /** Can this computer pause programs (not on Windows: Stop only). */
  canPause: boolean;
  undo: SafetyUndo[];
  events: SafetyEventRow[];
};

export type AgentSafetyState = { type: 'safety_state'; requestId: string; state: SafetyState };
export type AgentSafetyResult = { type: 'safety_result'; requestId: string; ok: boolean; message: string; state?: SafetyState };
/** Sent once per incident: the tripwire paused every AI on this computer. */
export type AgentSafetyAlert = { type: 'safety_alert'; trip: SafetyTrip };

export type HubSafetyGet = { type: 'safety_get'; requestId: string };
export type HubSafetyAction = { type: 'safety_action'; requestId: string; action: 'restore' | 'resume' | 'stop'; undoId?: string };

// ---------- What AI a machine can use (agents from 0.11.0) ----------

export type LocalCliId = 'claude' | 'codex' | 'gemini' | 'copilot' | 'opencode' | 'aider' | 'qwen';
export type LocalRuntimeId = 'ollama' | 'lmstudio' | 'llamacpp';

/** One AI command-line tool: there or not, and whether a sign-in (or a key) for it is present. Never a name, email or key. */
/** One model in Claude Code's own menu (supportedModels): `value` is what a chat is started with (an alias like `fable` follows the newest). */
export type ClaudeModelOption = { value: string; label: string; description?: string; resolved?: string };

export type LocalCli = {
  id: LocalCliId;
  name: string;
  installed: boolean;
  version?: string;
  /** 'yes' = a sign-in or key is present; 'no' = none found; 'unknown' = cannot be told from here (a keychain). */
  login: 'yes' | 'no' | 'unknown';
  loginVia?: 'file' | 'env' | 'keychain';
  usable: boolean;
  /** The person's switch for this tool (agents from 0.17.0). false = never used, not by a job and not by /ask. */
  allowed?: boolean;
  /** The subscription visible on this computer, from the tool's own sign-in file: `max`, `pro`, `plus`, `team`, `free`, `google-account`, `api-key`. Never a name, email or key. */
  plan?: string;
  /** Usage room: Claude's five-hour figure when it can be read; `limited` while a limit it hit has not reset. */
  limit?: { usedPct?: number; resetsAt?: string; limited: boolean };
  /** One word for the router. */
  state?: 'ready' | 'busy' | 'limited' | 'signed_out' | 'off' | 'not_installed';
  /** Claude Code (agents from 0.18) and GitHub Copilot CLI (agents from 0.18.0): the models it offers, for the apps' model menus. */
  models?: ClaudeModelOption[];
};

/** An AI program that runs models on this computer itself. */
export type LocalRuntime = {
  id: LocalRuntimeId;
  name: string;
  port: number;
  /** Ollama: the program is installed even if its server is not running. */
  installed?: boolean;
  running: boolean;
  version?: string;
  models: { name: string; sizeBytes?: number; loaded?: boolean }[];
  allowed?: boolean;
  state?: 'ready' | 'busy' | 'off' | 'not_running';
};

/** How the computer is right now (agents from 0.17.0). busy = our own jobs at the limit, our work held for the person, or short of memory; locked = screen locked. */
export type OwnMachineState = { state: 'idle' | 'busy' | 'locked'; activeJobs: number; activeChats: number; locked: boolean; checkedAt: string; why?: string };

export type LocalHardware = {
  os: string;
  arch: string;
  cpuModel: string;
  cpuCores: number;
  ramTotalBytes: number;
  ramFreeBytes: number;
  gpus: { name: string; vramBytes?: number; unified?: boolean }[];
  vramTotalBytes: number;
  /** What a local model may use: the graphics memory if there is some, else most of the RAM. */
  modelBudgetBytes: number;
  diskFreeBytes?: number;
};

export type LocalAiReport = {
  v: 1;
  scannedAt: string;
  tookMs: number;
  clis: LocalCli[];
  runtimes: LocalRuntime[];
  hardware: LocalHardware;
  summary: { usableClis: number; runningRuntimes: number; localModels: number; best: 'cli' | 'runtime' | 'none' };
  machine?: OwnMachineState;
  health?: { ok: boolean; agentVersion: string; checkedAt: string };
};

/** The machine's AI inventory: sent after connecting, every 10 minutes and when something changed. */
export type AgentLocalAi = { type: 'local_ai'; report: LocalAiReport };

// ---------- Asking the machine's own AI (agents from 0.12.0) ----------

/** What the question is, which decides the engine: `quick` = a short job (a title, a one-line answer), `summarize`, `explain` (about code, read-only), `chat`. */
export type LocalAskTask = 'chat' | 'quick' | 'summarize' | 'explain';

/**
 * Ask this machine's own AI one question and get an answer (never edits files): the machine tries its signed-in AI tools, then
 * models running on it, then (only if allowed) a cloud model, and moves on to the next only when one FAILS, never because it is slow.
 * Every request ends with exactly one `done` or `failed` event.
 */
export type HubLocalAsk = {
  type: 'local_ask';
  requestId: string;
  task: LocalAskTask;
  prompt: string;
  system?: string;
  history?: { role: 'user' | 'assistant'; content: string }[];
  /** Try this engine first (an `engine` id from an earlier event or from the machine's AI report: `cli:claude`, `runtime:ollama`). */
  prefer?: string;
  /** The cloud may answer when nothing here can. Default no. */
  allowCloud?: boolean;
  /** A model may be downloaded when nothing here can answer, after the person says yes. Default yes (it still asks). */
  allowPull?: boolean;
  /** From the router (hub own-job, agents from 0.17.0): the machine's rules for work from outside apply (busy, locked, switches). */
  fromRouter?: boolean;
  /** The router's own id for the job, echoed in the events. */
  jobId?: string;
  /** Run on exactly this resource (`cli:claude`, `runtime:ollama:<model>`); no other is tried. */
  resource?: string;
  /** `answer` = one-shot prompt; `task` = the tool may read and search in `cwd`, never edit or run commands. */
  mode?: 'answer' | 'task';
  cwd?: string;
};
export type HubLocalAskCancel = { type: 'local_ask_cancel'; requestId: string };
/** The person's answer to a `pull_needed` event. */
export type HubLocalPullAnswer = { type: 'local_pull_answer'; requestId: string; approve: boolean };

/** Events of one request. An `engine` event starts an engine: text shown so far from an earlier engine that failed is replaced by what follows. */
export type LocalAskEvent =
  | { kind: 'engine'; engine: string; label: string }
  | { kind: 'text'; text: string }
  | { kind: 'silence'; engine: string; seconds: number }
  | { kind: 'skipped'; engine: string; label: string; why: string }
  | { kind: 'pull_needed'; model: string; sizeBytes: number; diskFreeBytes?: number }
  | { kind: 'pull_progress'; model: string; completedBytes: number; totalBytes: number; status: string }
  | { kind: 'done'; engine: string; label: string; text: string; ms: number; /** Time to the first character. */ startMs?: number; jobId?: string }
  | { kind: 'failed'; message: string; tried: { engine: string; label: string; why: string }[]; cancelled?: boolean; code?: OwnFailureCode; /** Nothing was run: the machine said no up front. */ refused?: boolean; jobId?: string };

export type OwnFailureCode = 'busy' | 'locked' | 'not_allowed' | 'limited' | 'signed_out' | 'not_installed' | 'not_running' | 'model_missing' | 'bad_folder' | 'too_many' | 'not_supported' | 'off' | 'cancelled' | 'error';
/** Hello capability: this agent takes jobs from the router (`local_ask` with fromRouter) and reports plan, limits and busy state. */
export const OWN_JOB_CAPABILITY = 'own_job';
export type AgentLocalAskEvent = { type: 'local_ask_event'; requestId: string; seq: number; event: LocalAskEvent };

/** Asking the cloud as a last resort: the hub uses the owner's own cloud AI key (never one on the computer) and the smallest adequate model. */
export type AgentCloudAsk = { type: 'cloud_ask'; requestId: string; task: LocalAskTask; messages: { role: 'system' | 'user' | 'assistant'; content: string }[]; tried?: { engine: string; why: string }[] };
export type HubCloudAnswer = { type: 'cloud_answer'; requestId: string; ok: boolean; text?: string; error?: string; provider?: string; model?: string };

// ---------- Jarvis: direct commands to a computer (no model turn) ----------

/** Hello capability: this agent takes `device_command` (open, show, wake, unlock, see the screen...) straight from the phone. */
export const DEVICE_COMMAND_CAPABILITY = 'device_command';
/** Hello capability: this agent answers the website's read-only checks (disks, processes, memory, load) and opens its terminal after the owner's yes: device actions `check`, `term_open`, `term_send`, `term_read`, `term_close`. */
export const MACHINE_CHECKS_CAPABILITY = 'machine_checks';

/**
 * Hello capability: this agent may ask the owner's phone to do one thing (ring, battery, flashlight, media button, a link as a
 * notification) with `phone_command`; the hub answers with one `phone_result`. The hub checks the action against a fixed list.
 */
export const PHONE_COMMAND_CAPABILITY = 'phone_command';
export type AgentPhoneCommand = { type: 'phone_command'; requestId: string; target?: string; action: string; args?: Record<string, unknown> };
export type HubPhoneResult = { type: 'phone_result'; requestId: string; ok: boolean; say: string; data?: Record<string, unknown>; code?: string };

/** What a fingerprint yes is for. The phone signs `escanor-jarvis-v1|purpose|subject|nonce|machine` (agent/src/jarvisKeys.ts). */
export type DeviceAskPurpose = 'unlock' | 'signin' | 'view' | 'enable' | 'type_login' | 'enable_typing' | 'enable_signin' | 'signin_use' | 'signin_window' | 'wake' | 'deps';

/** Who asked for something that needs a fingerprint: the owner on the phone, the AI in a chat, or an automation on the computer. */
export type DeviceAskSource = 'phone' | 'ai' | 'automation';

/** A question the computer put to the phone: the person answers with a fingerprint. Expires on its own (`expiresAt`, ms). */
export type DeviceAsk = {
  askId: string;
  purpose: DeviceAskPurpose;
  subject: string;
  nonce: string;
  machine: string;
  expiresAt: number;
  /** What the person's access policy wants shown with the yes, besides the signed fingerprint: 'password' and/or 'totp' (typed on the phone). Absent = the fingerprint alone. */
  also?: ('password' | 'totp')[];
  /** What will happen if the person says yes, in plain words the computer wrote from fixed sentences (never a secret's value). */
  what?: string;
  /** Why it is asked, in the words of whoever asked (shown labelled with `source`). */
  why?: string;
  source?: DeviceAskSource;
};

/** The phone (through the hub) tells a computer to do one thing now. `action` and `args` are checked again by the agent. */
export type HubDeviceCommand = { type: 'device_command'; requestId: string; action: string; args?: Record<string, unknown> };

/** The phone's answer to a DeviceAsk: a signed yes, or `approve: false` to cancel. */
export type HubDeviceApproval = { type: 'device_approval'; requestId: string; askId: string; approve: boolean; keyId?: string; signature?: string; /** Typed just now on the phone, when the ask's `also` says so. Passed on to the account to check; never kept or logged. */ recheck?: { password?: string; code?: string } };

/** The answer to a device command or approval (requestId echoes it). Live only: never kept for a reconnect. */
export type AgentDeviceResult = {
  type: 'device_result';
  requestId: string;
  ok: boolean;
  /** Plain words for the person. */
  say: string;
  state?: 'done' | 'needs_approval' | 'code_needed';
  ask?: DeviceAsk;
  data?: Record<string, unknown>;
  code?: 'remote_off' | 'not_paired' | 'refused' | 'failed' | 'expired' | 'blocked';
};

/** The computer asks the phone for a fingerprint (the hub tells every app and sends a push), and later says it is settled. */
export type AgentDeviceAsk = { type: 'device_ask'; ask: DeviceAsk };
export type AgentDeviceAskDone = { type: 'device_ask_done'; askId: string };

// ---------- Remote desktop: the live screen of a computer, streamed to the phone and the web (docs/REMOTE_DESKTOP.md) ----------

/** Hello capability: this agent streams its screen to viewers the hub connects (`screen_open`) and takes their input. */
export const SCREEN_STREAM_CAPABILITY = 'screen_stream';

/** A viewer connected to the hub's /screen socket for a view the owner approved: start (or keep) streaming. */
export type HubScreenOpen = { type: 'screen_open'; viewId: string; viewer: string; client: string };
/** That viewer's socket closed. */
export type HubScreenClose = { type: 'screen_close'; viewId: string; viewer: string };
/** One message from a viewer (hello, ack, quality, monitor, in, clip_set, clip_get, ping, end); checked again by the agent. */
export type HubScreenIn = { type: 'screen_in'; viewId: string; viewer: string; msg: Record<string, unknown> };
/** Text for one viewer (or, without `viewer`, for every viewer of the view). Pictures go as binary frames instead (docs/REMOTE_DESKTOP.md). */
export type AgentScreenOut = { type: 'screen_out'; viewId: string; viewer?: string; msg: Record<string, unknown> };
/** A view was granted (after the fingerprint yes): the hub tells every app so a web page that asked can open the stream. */
export type AgentScreenView = { type: 'screen_view'; viewId: string; expiresAt: number };
/** A view ended, and why in plain words. */
export type AgentScreenViewEnd = { type: 'screen_view_end'; viewId: string; why: string };

export type AgentToHubMessage = (
  | AgentHello
  | AgentSdkMessage
  | AgentSdkPartial
  | AgentSessionCreated
  | AgentSessionEnded
  | AgentSessionDeleted
  | AgentSessionPriority
  | AgentPermissionRequest
  | AgentError
  | AgentProjectsList
  | AgentMcpStatus
  | AgentSessionActivity
  | AgentInputAck
  | AgentPermissionAck
  | AgentMachineState
  | AgentQueueState
  | AgentQueueResult
  | AgentAccountResult
  | AgentDeviceResult
  | AgentPhoneCommand
  | AgentDeviceAsk
  | AgentDeviceAskDone
  | AgentScreenOut
  | AgentScreenView
  | AgentScreenViewEnd
  | AgentSubagents
  | AgentSubagentStepsResult
  | AgentPreviewHttpHead
  | AgentPreviewHttpBody
  | AgentPreviewHttpEnd
  | AgentPreviewHttpWait
  | AgentSafetyState
  | AgentSafetyResult
  | AgentSafetyAlert
  | AgentLocalAi
  | AgentLocalAskEvent
  | AgentCloudAsk
) & {
  /**
   * Outbox id (agents from 0.9.0): set on every message the agent keeps until the hub has it, the same on each copy sent again
   * (after a reconnect or a restart). A hub ignores a second copy with the same id. Not on hello, sdk_partial, session_activity
   * or machine_state (those are state, re-sent as their latest value).
   */
  mid?: string;
};

// ---------- Hub -> Agent ----------

export type HubUserInput = {
  type: 'user_input';
  sessionId: string; // real session id, or the tempId for a brand-new chat
  tempId?: string; // set only when sessionId is a not-yet-created chat
  cwd?: string; // used only when starting/resuming a session
  accountId?: string; // used only when starting a brand-new session
  text: string;
  images?: ImageAttachment[];
  // What the chat runs with, sent with every message so a chat that has to be started or resumed for it keeps what was
  // chosen (a set_* sent while the chat was not running used to be lost). Absent: what the agent last knew for it.
  permissionMode?: PermissionMode;
  model?: string; // '' = the default model
  effort?: EffortLevel | null; // null = the default effort
  // A chat that reaches nothing outside its own folder: it gets none of the hub's MCP servers, now or later, and cannot call
  // an MCP tool. Once a chat is isolated it stays so (a later message without the flag does not undo it). Used for an app
  // builder's chats, which may run in bypass on the company's machine and must not reach the workspace's integrations.
  isolated?: boolean;
  // A new chat (tempId) that must not continue an open one. Agents from 0.8.0 continue the recent idle chat in the same folder
  // when asked for a new one (the hub is told with session_created naming that chat); this, or a first message starting with
  // "/new", always starts a separate one.
  fresh?: boolean;
  /** "Send as priority": if the message has to wait for a free chat slot it waits at the front of the queue, ahead of the other waiting messages (agents from 0.12.9). */
  priority?: boolean;
  /** A chat Escanor itself starts for a goal: when the computer's normal chat slots are all busy it may use the one reserved slot above the cap (never more than one, nobody is stopped for it). Newer agents only; older ones ignore it. */
  jobSlot?: boolean;
  /** The hub's id for this message (agents from 0.9.0 echo it in input_ack, so the app shows "waiting for PC" until delivered). */
  inputId?: string;
  /**
   * This message starts or continues a fix done on this computer (FLOW3): the branch it is delivered on (`escanor/fix-...`). The
   * agent recognises the backend's own delivery words ("create a new branch named escanor/fix-...") without it. Only with
   * `verify: true` (or the text marker `[escanor:verify-tests]`: control level Fix & verify and up) does the agent run the base
   * commit's own test command on the base and the pushed head and send the result (EscanorTestsRow).
   */
  fix?: { branch: string; verify?: boolean };
  /**
   * WATCHLIST: the only repositories (owner/name) this chat may change on a remote: an auto-fix run's `extra.write_repos`
   * (mongo-backend autopilot/supervisor.py). The agent then refuses git push, gh pr create/merge, gh api writes and the like to
   * any other repository, and a write whose repository it cannot tell. Sticky: a later message can only narrow it. The agent
   * also reads the backend's own words for it ("Change only these repositories, the ones the person chose for fixes: ..."),
   * so it holds with a backend or hub that does not pass this on. Absent (and no such words): no limit, as before.
   */
  writeRepos?: string[];
};

export type HubInterrupt = {
  type: 'interrupt';
  sessionId: string;
};

export type PermissionMode = 'default' | 'acceptEdits' | 'bypassPermissions' | 'plan' | 'dontAsk' | 'auto';

export type EffortLevel = 'low' | 'medium' | 'high' | 'xhigh' | 'max';

export type HubSetPermissionMode = {
  type: 'set_permission_mode';
  sessionId: string;
  mode: PermissionMode;
};

export type HubSetModel = {
  type: 'set_model';
  sessionId: string;
  model?: string;
};

/**
 * Mark a chat Priority, or take the mark off (agents from 0.12.4; older agents ignore it). A Priority chat's waiting messages go
 * first, and when every slot for a running chat is taken it starts next; if every slot is held by chats that are not Priority it
 * gets one slot above the cap. No other chat is ever stopped for it.
 */
export type HubSetPriority = {
  type: 'set_priority';
  sessionId: string;
  priority: boolean;
};

export type HubSetEffort = {
  type: 'set_effort';
  sessionId: string;
  effort: EffortLevel | null;
};

export type HubPermissionResponse = {
  type: 'permission_response';
  requestId: string;
  behavior: PermissionDecision;
  message?: string;
};

export type HubListProjects = {
  type: 'list_projects';
  requestId: string;
};

/**
 * "Open on my computer" (PREVIEW1 fallback): fetch a fix's pull request (or branch) from a repository this computer already has,
 * into a throwaway worktree, start the project (after asking the person) and open it in the browser. Only for an agent whose hello
 * lists the `preview_open` capability; answered to Escanor's API (not the hub), see packages/agent/src/previewOpen.ts.
 */
export type HubPreviewOpen = {
  type: 'preview_open';
  requestId: string;
  runId: string;
  repo: string; // owner/name
  prNumber?: number;
  branch?: string;
};

/**
 * SITEPREV3, a private link to the preview this computer runs (agents whose hello lists `preview_link`). Escanor's backend mints it
 * on the hosted hub for a workspace owner or admin; the agent starts the fix like preview_open (asking first) but opens no browser,
 * and serves `preview_http` from that preview's own 127.0.0.1 port only until the link ends (expiresAt, ms) or preview_unshare.
 * See packages/agent/src/previewRelay.ts.
 */
export type HubPreviewShare = Omit<HubPreviewOpen, 'type'> & { type: 'preview_share'; linkId: string; expiresAt: number };
export type HubPreviewUnshare = { type: 'preview_unshare'; linkId: string };
/** One browser request through a link: a path (with its query) on the link's preview, never a host or port. body is base64. */
export type HubPreviewHttp = { type: 'preview_http'; id: string; linkId: string; method: string; path: string; headers: [string, string][]; body?: string };
export type HubPreviewHttpCancel = { type: 'preview_http_cancel'; id: string };
/** The answer to preview_http: head, base64 body pieces, end. Or wait, when no preview runs for the link (yet). Never kept in the outbox. */
export type AgentPreviewHttpHead = { type: 'preview_http_head'; id: string; status: number; headers: [string, string][] };
export type AgentPreviewHttpBody = { type: 'preview_http_body'; id: string; data: string };
export type AgentPreviewHttpEnd = { type: 'preview_http_end'; id: string; error?: string };
export type AgentPreviewHttpWait = { type: 'preview_http_wait'; id: string; state: 'starting' | 'stopped' | 'failed'; message?: string };

// An MCP server the hub keeps installed on every VM. `name` becomes the server's namespace
// in Claude Code (`mcp__<name>__<tool>`), so it is restricted to characters that survive that.
export type ManagedMcpServer = {
  name: string;
  url: string; // streamable-HTTP endpoint
  headers?: Record<string, string>; // e.g. { Authorization: 'Bearer ...' }
  autoAllow?: boolean; // pre-approve ALL of this server's tools so chats never stall on a permission card
  // When autoAllow is off: still pre-approve the calls that only *read* (see isReadOnlyMcpCall), so a
  // chat can look things up freely and asks only before it changes something.
  autoAllowReads?: boolean;
  // When autoAllow is off: also pre-approve `escanor_invoke` calls whose tool_id is one of these (exact, or a
  // trailing `*` prefix). This is how an operator's playbook lets a machine post in a channel or open a ticket
  // without a card, while everything else that changes something still waits for a person.
  autoAllowTools?: string[];
  alwaysLoad?: boolean; // load its tools into every prompt instead of deferring them behind tool search
  managedBy?: string; // who installed it ('escanor'); informational
  updatedAt: string;
};

// Declarative: always the complete set. The agent makes its sessions match it, so a server
// missing from the list is removed and a VM that was offline converges as soon as it is back.
export type HubSetMcpServers = {
  type: 'set_mcp_servers';
  servers: ManagedMcpServer[];
};

// The machine's queue (agents from 0.9.7): each names a waiting message by QueueItem.id; the agent answers with queue_result.
/** Drop it: the message is answered as refused ("Cancelled from the queue"), with the ones waiting behind it in the same chat. */
export type HubQueueCancel = { type: 'queue_cancel'; requestId: string; id: string };
/** New text for it, only while it still waits. */
export type HubQueueEdit = { type: 'queue_edit'; requestId: string; id: string; text: string };
/** Move it (with the other messages for the same chat) to index `to` (0 = next), to the top, or one place up. */
export type HubQueueMove = { type: 'queue_move'; requestId: string; id: string; to: number | 'top' | 'up' };
/**
 * Start it now, if a slot can be made by putting the least recently active idle chat away (never a running one). Otherwise it
 * stays where it is and the result says why.
 */
export type HubQueueStartNow = { type: 'queue_start_now'; requestId: string; id: string };
/** The whole current text of a waiting message (for Edit: queue_state only carries its first words). */
export type HubQueueGet = { type: 'queue_get'; requestId: string; id: string };
export type HubQueueCommand = HubQueueCancel | HubQueueEdit | HubQueueMove | HubQueueStartNow | HubQueueGet;

/**
 * Claude accounts on the machine, added from the phone (agents with the `account_login` capability: on unless ESCANOR_ACCOUNT_LOGIN=0).
 * The machine runs Claude's own sign-in (`claude auth login`) for a new account folder: `start` answers with the sign-in page,
 * the person signs in there with the account's own email or Google and sends back the code the page shows (`code`). `cancel`
 * stops a sign-in, `rename` changes the name shown, `remove` signs that account out on this machine. Answered with account_result.
 */
export type HubAccountCommand =
  | {
      type: 'account_command';
      requestId: string;
      action: 'start';
      label?: string;
      email?: string;
      /** Which AI to add (default 'claude'). */
      provider?: AccountProvider;
      /** 'signin' (default) or 'key' (the person pastes an API key as the `code`). */
      method?: 'signin' | 'key';
    }
  | { type: 'account_command'; requestId: string; action: 'code'; flowId: string; code: string }
  | { type: 'account_command'; requestId: string; action: 'cancel'; flowId: string }
  | { type: 'account_command'; requestId: string; action: 'rename'; accountId: string; label: string }
  | { type: 'account_command'; requestId: string; action: 'remove'; accountId: string }
  /** Make this machine's sign-in of a Claude account available on every machine of the workspace (agents from 0.19.0, capability `account_workspace`). */
  | { type: 'account_command'; requestId: string; action: 'share'; accountId: string };

/** In the hello when the agent shares accounts with the workspace and uses the workspace's shared accounts (workspaceAccounts.ts). */
export const ACCOUNT_WORKSPACE_CAPABILITY = 'account_workspace';

/** What an agent says in its hello capabilities when it can add Claude accounts from the phone. */
export const ACCOUNT_LOGIN_CAPABILITY = 'account_login';
/** In the hello when the agent can add and run ChatGPT (Codex CLI) accounts. */
export const ACCOUNT_PROVIDER_CHATGPT_CAPABILITY = 'account_provider_chatgpt';
/** In the hello when the agent can add and run Gemini (Gemini CLI) accounts. */
export const ACCOUNT_PROVIDER_GEMINI_CAPABILITY = 'account_provider_gemini';
/**
 * In the hello when the agent can add and run GitHub Copilot (Copilot CLI) accounts. Sign-in is GitHub's device sign-in: `start`
 * answers with `url` (https://github.com/login/device) and `userCode`; once the person has entered the code and approved, the phone
 * sends `code` = 'device-approved' (as for ChatGPT's device sign-in). method 'key' takes a GitHub token with Copilot access instead.
 */
export const ACCOUNT_PROVIDER_COPILOT_CAPABILITY = 'account_provider_copilot';
/**
 * In the hello when a ChatGPT sign-in can switch to Codex's normal browser sign-in (no ChatGPT setting needed): right after
 * `start`, the phone sends `code` = 'browser-signin' and gets ChatGPT's page as `url` (no `userCode`); it then sends the address
 * that page went back to (http://127.0.0.1:1455/auth/callback?code=...&state=...) as the `code`.
 */
export const ACCOUNT_CHATGPT_BROWSER_CAPABILITY = 'account_chatgpt_browser';

/** Read-only drill-down into one helper of a chat: its newest steps (`limit` up to 50), older ones with `before` (a step index). Answered with subagent_steps_result. */
export type HubSubagentSteps = { type: 'subagent_steps'; requestId: string; sessionId: string; id: string; limit?: number; before?: number };

/**
 * Per-machine settings from the phone (agents from 0.12.9; older agents ignore it). `giveWay`: "Give way to me when I'm using this
 * computer": 'on' (default: our work lowers its priority and waits, and is paused when other programs need the computer), 'gentle'
 * (lower priority and wait, never pause) or 'off'. The agent keeps it and reports it back in machine_state.
 */
export type HubSetMachineSettings = { type: 'set_machine_settings'; giveWay?: 'on' | 'gentle' | 'off'; /** The permissions page changed this computer's set: the agent asks the backend for it now. */ permissionsChanged?: boolean };

/**
 * The Escanor plan's AI limit was reached (the hub knows; agents from 0.12.9): all work on `accountId` (every account when absent)
 * waits until `resetsAt` (ISO) and starts again by itself then.
 */
export type HubAiLimit = { type: 'ai_limit'; accountId?: string; resetsAt: string; source?: 'plan' };

/** The workspace's AI accounts changed (one was added, signed in again or removed): the agent pulls them at once (workspaceAccounts.syncNow). */
export type HubWorkspaceAccountsChanged = { type: 'workspace_accounts_changed' };
/** This computer, removed from the workspace, was restored: the agent connects again at once instead of waiting for its next recheck. */
export type HubRestored = { type: 'restored' };

export type HubToAgentMessage =
  | HubWorkspaceAccountsChanged
  | HubRestored
  | HubScreenOpen
  | HubScreenClose
  | HubScreenIn
  | HubDeviceCommand
  | HubPhoneResult
  | HubDeviceApproval
  | HubSetMachineSettings
  | HubAiLimit
  | HubSetPriority
  | HubPowerCommand
  | HubUserInput
  | HubInterrupt
  | HubSetPermissionMode
  | HubSetModel
  | HubSetEffort
  | HubPermissionResponse
  | HubListProjects
  | HubPreviewOpen
  | HubPreviewShare
  | HubPreviewUnshare
  | HubPreviewHttp
  | HubPreviewHttpCancel
  | HubSetMcpServers
  | HubQueueCommand
  | HubAccountCommand
  | HubSubagentSteps
  | HubSafetyGet
  | HubSafetyAction
  | HubLocalAsk
  | HubLocalAskCancel
  | HubLocalPullAnswer
  | HubCloudAnswer;

// ---------- Hub -> Browser (push channel) ----------

export type BrowserVmStatus = {
  type: 'vm_status';
  vmId: string;
  name: string;
  connected: boolean;
  accounts: ClaudeAccount[];
};

export type BrowserSdkMessage = {
  type: 'sdk_message';
  vmId: string;
  sessionId: string;
  tempId?: string;
  message: unknown;
  createdAt: string;
};

export type BrowserSdkPartial = {
  type: 'sdk_partial';
  vmId: string;
  sessionId: string;
  text: string;
};

export type BrowserSessionCreated = {
  type: 'session_created';
  vmId: string;
  tempId: string;
  sessionId: string;
  cwd: string;
  title: string;
  accountId: string;
};

export type BrowserSessionEnded = {
  type: 'session_ended';
  vmId: string;
  sessionId: string;
};

export type BrowserSessionDeleted = {
  type: 'session_deleted';
  vmId: string;
  sessionId: string;
};

export type BrowserSessionPriority = {
  type: 'session_priority';
  vmId: string;
  sessionId: string;
  priority: boolean;
};

export type BrowserPermissionRequest = {
  type: 'permission_request';
  vmId: string;
  sessionId: string;
  requestId: string;
  toolName: string;
  input: Record<string, unknown>;
  blockedPath?: string;
  /** What it will do in everyday words (AgentPermissionRequest.summary). */
  summary?: string;
};

export type BrowserPermissionResolved = {
  type: 'permission_resolved';
  vmId: string;
  sessionId: string;
  requestId: string;
};

export type HubToBrowserMessage =
  | BrowserSessionPriority
  | BrowserVmStatus
  | BrowserSdkMessage
  | BrowserSdkPartial
  | BrowserSessionCreated
  | BrowserSessionEnded
  | BrowserSessionDeleted
  | BrowserPermissionRequest
  | BrowserPermissionResolved;

// ---------- REST DTOs ----------

export type VmDto = {
  id: string;
  name: string;
  connected: boolean;
  lastSeenAt: string | null;
  accounts: ClaudeAccount[];
  /** Power control (sleep when idle, wake when work arrives), when the hub has it set up for this machine. */
  power?: VmPowerDto | null;
  /** What kind of machine it is, as its agent found out (agents from 0.9.14); absent for older agents. */
  machine?: MachineSummary;
};

export type PowerStateDto = 'running' | 'stopped' | 'starting' | 'stopping' | 'unknown';

/** What the app may know about a machine's power control. The cloud credential itself never comes back. */
export type VmPowerDto = {
  autoStart: boolean;
  autoStop: boolean;
  idleMinutes: number;
  state: PowerStateDto;
  waking: boolean;
  lastError: string | null;
  /** Where the machine is: provider, project/zone/instance or region/instance, and which account can start it. */
  target: Record<string, string>;
};

export type PowerSetupDto =
  | { provider: 'gcp'; gcp: { project: string; zone: string; instance: string; serviceAccountJson: string } }
  | { provider: 'oci'; oci: { tenancy: string; user: string; fingerprint: string; privateKey: string; region: string; instanceId: string } }
  /** A laptop, desktop or server on a network: it sleeps by itself on the hub's word, and another of your machines on the same network wakes it. */
  | { provider: 'lan'; lan: { mac: string; relayVmId: string } }
  | { provider: 'aws'; aws: { accessKeyId: string; secretAccessKey: string; region: string; instanceId: string } }
  | { provider: 'azure'; azure: { tenantId: string; clientId: string; clientSecret: string; subscriptionId: string; resourceGroup: string; vmName: string } }
  /** A laptop, home server or anything else: addresses the hub calls to wake it and to put it to sleep. */
  | { provider: 'webhook'; webhook: { wakeUrl: string; sleepUrl: string; statusUrl?: string; authorization?: string } };

export type SessionDto = {
  id: string;
  vmId: string;
  cwd: string;
  title: string;
  createdAt: string;
  lastMessageAt: string;
  // 'waiting': Claude asked for permission and nobody has answered yet.
  status: 'active' | 'idle' | 'ended' | 'waiting';
  accountId: string;
  tempId?: string; // the temporary id the chat was started under, when the hub knows it
  archived?: true; // put away by the machine to stay under its open-chat cap; still resumable by a message (absent: not)
};

export type MessageDto = {
  id: number;
  sessionId: string;
  vmId: string;
  message: unknown;
  createdAt: string;
};

export type McpServerDto = Omit<ManagedMcpServer, 'headers'> & {
  // Header *names* only. Values are credentials and never leave the hub once stored.
  headerNames: string[];
};

export type McpServerInput = {
  url: string;
  headers?: Record<string, string>;
  autoAllow?: boolean;
  alwaysLoad?: boolean;
  managedBy?: string;
};

// The first agent release that understands `set_mcp_servers`. An older agent ignores the message
// without saying so, so the hub reports it as needing an update instead of "installing" forever.
export const MIN_MCP_AGENT_VERSION = '0.3.0';

// The first agent release that honours the `isolated` run choice (HubUserInput.isolated) AND runs chats as their own OS users with
// nothing shared between them, no filesystem settings, the MCP configuration on a pipe and no_new_privs, and sends the heartbeat
// the hosted hub uses to tell a live connection from a dead one (0.6.2; it says `chat_user` in its hello when it really does): a chat with no MCP servers that cannot call an MCP tool, and
// that cannot read the agent's hub token or the other chats' MCP credentials. Escanor's backend lets an app chat run without approval prompts only on an agent at least this new (it reads
// the version the hosted hub reports in GET /vms), so a stale agent fails closed instead of giving a no-prompts chat the
// workspace's MCP servers.
export const MIN_ISOLATED_AGENT_VERSION = '0.6.2';

// The first agent release that reports its queue (queue_state) and takes queue_cancel / queue_edit / queue_move / queue_start_now
// (QUEUEUI). An older one ignores the commands without answering, so the apps say "Update the Escanor agent on this computer".
export const MIN_QUEUE_AGENT_VERSION = '0.9.7';
/** QueueItem.preview is at most this many characters. */
export const QUEUE_PREVIEW_CHARS = 80;
/** A queue_state lists at most this many messages. */
export const MAX_QUEUE_ITEMS = 100;

function versionAtLeast(version: string | null | undefined, minimum: string): boolean {
  if (!version) return false;
  const parse = (v: string) => v.split('.').map((n) => parseInt(n, 10) || 0);
  const have = parse(version);
  const need = parse(minimum);
  for (let i = 0; i < Math.max(have.length, need.length); i++) {
    const d = (have[i] ?? 0) - (need[i] ?? 0);
    if (d !== 0) return d > 0;
  }
  return true;
}

export function agentSupportsMcp(version: string | null | undefined): boolean {
  return versionAtLeast(version, MIN_MCP_AGENT_VERSION);
}

export function agentSupportsIsolation(version: string | null | undefined): boolean {
  return versionAtLeast(version, MIN_ISOLATED_AGENT_VERSION);
}

export type VmMcpStatusDto = {
  vmId: string;
  name: string;
  connected: boolean;
  agentVersion: string | null;
  mcpSupported: boolean;
  reportedAt: string | null;
  servers: AgentMcpServerStatus[];
  liveSessions: number;
};

export type McpOverviewDto = {
  servers: McpServerDto[];
  vms: VmMcpStatusDto[];
};

export type McpPutResultDto = {
  server: McpServerDto;
  vmsConnected: number;
  vmsTotal: number;
};

export const MCP_SERVER_NAME_RE = /^[a-z0-9][a-z0-9_-]{0,31}$/;

// Claude Code names a server's tools `mcp__<server>__<tool>`. A server called "a__b" would be indistinguishable from
// tool "b__..." of server "a", so a name with "__" could inherit another server's approvals: refuse it.
export const isValidMcpServerName = (name: string): boolean => MCP_SERVER_NAME_RE.test(name) && !name.includes('__') && !name.endsWith('_');

// ---------- outbound MCP URL (SSRF guard) ----------

function ipv4(host: string): number[] | null {
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return null;
  const p = m.slice(1).map(Number);
  return p.every((n) => n <= 255) ? p : null;
}

// Expands ::ffff:7f00:1 style IPv4-mapped addresses (what URL parsing produces) to dotted quads.
function mappedIpv4(host: string): number[] | null {
  const m = host.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (!m) return null;
  const hi = parseInt(m[1], 16);
  const lo = parseInt(m[2], 16);
  return [hi >> 8, hi & 255, lo >> 8, lo & 255];
}

function classifyHost(rawHost: string): 'metadata' | 'private' | 'public' {
  const host = rawHost.toLowerCase().replace(/^\[|\]$/g, '').replace(/\.$/, '');
  if (host === 'metadata.google.internal' || host === 'metadata' || host.endsWith('.metadata.google.internal')) return 'metadata';
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.internal') || host.endsWith('.local')) return 'private';

  const v4 = ipv4(host) ?? mappedIpv4(host);
  if (v4) {
    const [a, b] = v4;
    if (a === 169 && b === 254) return 'metadata';
    if (a === 0 || a === 10 || a === 127 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127)) return 'private';
    return 'public';
  }
  if (host.includes(':')) {
    if (host === '::1' || host === '::') return 'private';
    if (/^fe[89ab]/.test(host) || host.startsWith('fd00:ec2:')) return 'metadata'; // link-local, AWS IPv6 IMDS
    if (/^f[cd]/.test(host)) return 'private'; // unique-local
  }
  return 'public';
}

// The hub pushes this URL (plus a bearer token) to every VM, so it must not be pointable
// at cloud metadata endpoints or, by default, anything on a private network.
export function validateMcpUrl(url: unknown, opts: { allowPrivate?: boolean } = {}): { ok: true; value: string } | { ok: false; error: string } {
  if (typeof url !== 'string' || url.length > 2048) return { ok: false, error: 'url required' };
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return { ok: false, error: 'invalid url' };
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return { ok: false, error: 'url must be http(s)' };
  if (u.username || u.password) return { ok: false, error: 'url must not embed credentials' };
  const kind = classifyHost(u.hostname);
  if (kind === 'metadata') return { ok: false, error: 'url points at a link-local / metadata address' };
  if (kind === 'private' && !opts.allowPrivate) return { ok: false, error: 'url points at a private or loopback address' };
  return { ok: true, value: u.toString() };
}


// ---------- MCP server helpers (pure; used by the Node hub and the Worker hub alike) ----------

const HEADER_NAME_RE = /^[A-Za-z0-9!#$%&'*+.^_`|~-]{1,64}$/;
const MAX_HEADERS = 16;
const MAX_HEADER_VALUE = 4096;

export type ParsedMcpServerInput = { ok: true; server: Omit<ManagedMcpServer, 'updatedAt'> } | { ok: false; error: string };

export type ParseMcpOptions = {
  /** The entry being updated. Fields the request leaves out keep its values, so a partial update cannot reset them. */
  existing?: ManagedMcpServer;
  /** Accept loopback / private-network URLs (a hub that runs beside its MCP server). Metadata addresses never pass. */
  allowPrivate?: boolean;
};

export function parseMcpServerInput(name: string, body: unknown, opts: ParseMcpOptions = {}): ParsedMcpServerInput {
  if (!isValidMcpServerName(name)) {
    return { ok: false, error: 'Server name must be 1-32 chars of a-z, 0-9, "_" or "-", starting with a letter or digit, and must not contain "__"' };
  }
  const b = (body && typeof body === 'object' ? body : {}) as Record<string, unknown>;
  const existing = opts.existing;

  if (typeof b.url !== 'string') return { ok: false, error: 'url is required' };
  const checked = validateMcpUrl(b.url.trim(), { allowPrivate: opts.allowPrivate });
  if (!checked.ok) return { ok: false, error: checked.error };

  let headers: Record<string, string> | undefined = existing?.headers;
  if (b.headers !== undefined) {
    headers = undefined;
    if (b.headers !== null) {
      if (typeof b.headers !== 'object' || Array.isArray(b.headers)) return { ok: false, error: 'headers must be an object' };
      const entries = Object.entries(b.headers as Record<string, unknown>);
      if (entries.length > MAX_HEADERS) return { ok: false, error: `at most ${MAX_HEADERS} headers` };
      headers = {};
      for (const [k, v] of entries) {
        if (!HEADER_NAME_RE.test(k)) return { ok: false, error: `invalid header name "${k}"` };
        // A CR/LF in a value would let a caller smuggle extra headers into every MCP request.
        if (typeof v !== 'string' || v.length > MAX_HEADER_VALUE || /[\r\n]/.test(v)) {
          return { ok: false, error: `invalid value for header "${k}"` };
        }
        headers[k] = v;
      }
    }
  }

  // A flag is a boolean or absent. Coercing (Boolean("false") === true) turned a string into blanket approval.
  const flag = (key: 'autoAllow' | 'autoAllowReads' | 'alwaysLoad', fallback: boolean): boolean | null => {
    const v = b[key];
    if (v === undefined) return existing?.[key] ?? fallback;
    return typeof v === 'boolean' ? v : null;
  };
  // Approving every tool of a server is something an operator asks for; a new server starts out asking.
  const autoAllow = flag('autoAllow', false);
  const autoAllowReads = flag('autoAllowReads', false);
  const alwaysLoad = flag('alwaysLoad', true);
  for (const [key, val] of [['autoAllow', autoAllow], ['autoAllowReads', autoAllowReads], ['alwaysLoad', alwaysLoad]] as const) {
    if (val === null) return { ok: false, error: `${key} must be true or false` };
  }

  return {
    ok: true,
    server: {
      name,
      url: checked.value,
      headers,
      autoAllow: autoAllow as boolean,
      autoAllowReads: autoAllowReads as boolean,
      ...(existing?.autoAllowTools ? { autoAllowTools: existing.autoAllowTools } : {}),
      alwaysLoad: alwaysLoad as boolean,
      managedBy: typeof b.managedBy === 'string' ? b.managedBy.slice(0, 32) : existing?.managedBy,
    },
  };
}

export function toMcpServerDto(s: ManagedMcpServer): McpServerDto {
  const { headers, ...rest } = s;
  return { ...rest, headerNames: Object.keys(headers ?? {}) };
}

// A token issued for one purpose (Escanor's integration), separate from a browser login so that
// signing out never breaks it and it can be revoked on its own. The value is shown once, on creation.
// 'mcp' tokens may only manage the MCP-server registry (what Escanor needs); 'full' is everything a login can do except mint tokens.
export type ApiTokenScope = 'full' | 'mcp';
export type ApiTokenDto = { id: string; label: string; createdAt: string; scope?: ApiTokenScope; expiresAt?: string | null };
export type ApiTokenCreatedDto = ApiTokenDto & { token: string };

// ---------- Is this MCP call read-only? ----------
//
// Used to let a chat look things up without asking while still asking before it changes anything.
// The rule is deliberately one-sided: a call is "read" only if it positively looks like one, and
// anything unrecognised, mixed ("get_or_create"), or touching secrets is *not* -- it asks. A wrong
// "no" costs one click; a wrong "yes" changes someone's cloud account without asking.

const READ_VERBS = new Set([
  'list', 'get', 'describe', 'read', 'search', 'query', 'status', 'show', 'find', 'count', 'fetch',
  'view', 'head', 'check', 'lookup', 'inspect', 'retrieve', 'summary', 'overview', 'stats', 'usage',
  'providers', 'tools', 'whoami', 'me',
]);

const CHANGE_WORDS = new Set([
  'create', 'delete', 'remove', 'update', 'put', 'post', 'patch', 'set', 'add', 'start', 'stop', 'restart',
  'reboot', 'terminate', 'destroy', 'deploy', 'apply', 'run', 'exec', 'execute', 'invoke', 'send', 'write',
  'upload', 'attach', 'detach', 'revoke', 'rotate', 'reset', 'cancel', 'scale', 'resize', 'merge', 'close',
  'open', 'push', 'publish', 'import', 'restore', 'enable', 'disable', 'grant', 'invite', 'transfer',
  'drain', 'kill', 'purge', 'clear', 'flush', 'trigger', 'rollback', 'promote', 'assign', 'unassign',
  'register', 'deregister', 'subscribe', 'unsubscribe', 'approve', 'reject', 'commit', 'fork', 'clone',
  'archive', 'unarchive', 'lock', 'unlock', 'move', 'rename', 'copy', 'sync', 'schedule', 'submit',
  'suspend', 'resume', 'pause', 'replace', 'modify', 'edit', 'change', 'confirm', 'pay', 'refund', 'charge',
  // A read verb in front of one of these still ends in a change: list_and_drop_tables, get_and_notify, fetch_and_install.
  // Only unambiguous verbs: words that are also common nouns in read operations (issue, page, message, alert, email, comment,
  // star, pin...) are left out on purpose -- the leading-read-verb rule below already refuses ids that merely mention them.
  'drop', 'wipe', 'erase', 'truncate', 'shred', 'notify', 'install', 'uninstall', 'mount', 'unmount', 'shutdown', 'poweroff',
  'evict', 'expire', 'invalidate', 'renew', 'reissue', 'regenerate', 'mint', 'ban', 'kick', 'mute', 'unmute', 'unblock', 'unstar',
  'unpin', 'unfollow', 'insert', 'upsert', 'alter', 'grant', 'dispatch', 'broadcast', 'tweet', 'increment', 'decrement', 'emit',
]);

// Words that join two operations ("list and drop"). A call that does more than one thing is not a plain read.
const CONNECTOR_WORDS = new Set(['and', 'then', 'or', 'also', 'after', 'before', 'plus', 'with', 'via', 'else', 'while', 'until']);

// A SQL statement or GraphQL operation that changes data, found anywhere in the arguments.
const WRITE_IN_ARGS = /\b(?:insert|update|delete|drop|alter|truncate|create|grant|revoke|merge|replace|upsert|rename|vacuum|reindex|copy|call|exec|execute|attach|detach|pragma|mutation)\b/i;

function argsContainWrite(value: unknown, depth = 0, budget = { left: 200_000 }): boolean {
  if (depth > 12 || budget.left <= 0) return true; // too deep / too big to vet: ask
  if (typeof value === 'string') {
    budget.left -= value.length;
    return WRITE_IN_ARGS.test(value);
  }
  if (Array.isArray(value)) return value.some((v) => argsContainWrite(v, depth + 1, budget));
  if (value && typeof value === 'object') return Object.values(value as Record<string, unknown>).some((v) => argsContainWrite(v, depth + 1, budget));
  return false;
}

// Reading these is itself sensitive; a person should see the request first.
const SENSITIVE_WORDS = new Set(['secret', 'secrets', 'password', 'passwords', 'credential', 'credentials', 'token', 'tokens', 'key', 'keys', 'apikey', 'apikeys', 'private', 'ssh', 'cert', 'certificate', 'certificates', 'env', 'vault']);

// The tools Escanor's MCP server exposes for discovery. They never change anything.
const ESCANOR_READ_ONLY_TOOLS = new Set(['escanor_list_providers', 'escanor_connection_status', 'escanor_list_tools', 'escanor_usage_stats']);

// Exact id, or a prefix when the pattern ends in `*` (and has something before it). Anything else does not match.
export function mcpToolIdMatches(patterns: readonly string[] | undefined, toolId: string): boolean {
  if (!toolId || !patterns) return false;
  return patterns.some((p) => (p.length > 1 && p.endsWith('*') ? toolId.startsWith(p.slice(0, -1)) : p === toolId));
}

export function isReadOnlyMcpCall(tool: string, input: Record<string, unknown> | undefined): boolean {
  if (ESCANOR_READ_ONLY_TOOLS.has(tool)) return true;
  if (tool !== 'escanor_invoke') return false;

  const toolId = typeof input?.tool_id === 'string' ? input.tool_id : '';
  if (!toolId) return false;
  const args = input?.arguments;
  // An explicit confirm flag is how Escanor marks a destructive call; its presence means the caller
  // knew it was one.
  if (args && typeof args === 'object' && (args as Record<string, unknown>).confirm) return false;

  const words = toolId.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  if (words.length === 0) return false;
  if (words.some((w) => CHANGE_WORDS.has(w) || SENSITIVE_WORDS.has(w) || CONNECTOR_WORDS.has(w))) return false;
  // The operation has to be *led* by a read verb: the first verb in the id (ids start with a provider / resource, so look a few
  // words in) must be one that only reads. An id with no recognisable verb is not vouched for.
  const verb = words.slice(0, 4).find((w) => READ_VERBS.has(w));
  if (!verb) return false;
  // What is passed matters as much as what the tool is called: database_query with `DELETE FROM ...` is not a read.
  return !argsContainWrite(args);
}
