/**
 * Risky commands: what an AI must not run on a computer without a person's OK, in any chat mode (bypass included).
 *
 * The Autonomous blocklist (autonomy.ts) refuses a short list of things outright in chats that answer themselves. This is the
 * wider safety net under every chat: a command that cannot be undone, or that reaches far beyond the work at hand, waits for an
 * Approve on the phone. Only commands that are about to run count -- `echo "rm -rf src"`, a commit message or a file that merely
 * mentions a command are text, not commands (shellParse.ts reads the line as bash would).
 *
 * Each finding says, in plain words, what will happen and why it is risky.
 */

import { parseShell, programName, type Command, type Word } from './shellParse.ts';

export type RiskKind =
  | 'delete-folder'
  | 'force-push'
  | 'remote-delete'
  | 'discard-work'
  | 'database'
  | 'cluster'
  | 'infra-destroy'
  | 'container-prune'
  | 'cloud-delete'
  | 'disk'
  | 'permissions'
  | 'download-run'
  | 'credentials'
  | 'outside-home'
  | 'system-change'
  | 'send-message'
  | 'screen-act'
  | 'unreadable';

export type Risk = { kind: RiskKind; why: string };

/** Longer commands are held unchecked rather than checked slowly. */
export const MAX_RISK_CHARS = 100_000;

export const RISK_WHY: Record<RiskKind, string> = {
  'delete-folder': 'It deletes a folder and everything in it, and that folder is not one of the project\'s build or temporary folders. Deleted files cannot be brought back.',
  'force-push': 'It force-pushes over a main or protected branch (or does not say which branch), which can wipe out other people\'s work on the server.',
  'remote-delete': 'It deletes branches or tags on the server (GitHub, GitLab...), not just on this computer.',
  'discard-work': 'It throws away changes that are not saved in git yet. They cannot be brought back.',
  database: 'It drops or empties a database table, or deletes rows without saying which ones.',
  cluster: 'It deletes things running in a Kubernetes cluster.',
  'infra-destroy': 'It tears down cloud infrastructure (servers, databases, networks) managed by this project.',
  'container-prune': 'It removes all stopped containers, unused images or volumes. Data kept in volumes is lost.',
  'cloud-delete': 'It deletes something in a cloud account (a server, bucket, database, app or repository).',
  disk: 'It formats a disk or writes straight onto one. Everything on it can be lost.',
  permissions: 'It changes who may read or change files across the whole machine, not just this project.',
  'download-run': 'It downloads a script from the internet and runs it straight away, without anyone reading it first.',
  credentials: 'It reaches where this computer keeps passwords, keys or sign-ins (the keychain, saved browser logins, SSH or cloud keys).',
  'outside-home': 'It changes files outside your own folders, in a place that belongs to the whole computer.',
  'system-change': 'It changes the computer itself (its settings, services, users, startup or power) or runs with administrator rights.',
  'send-message': 'It sends an email or message in your name (a new one, a reply or a forward). Once sent it cannot be taken back.',
  'screen-act': 'It uses your screen for you: Escanor looks at it, or clicks or types on it, as if it were you.',
  unreadable: 'It is too long, or runs commands inside commands too deeply, for Escanor to check, so a person should look at it first.',
};

const risk = (kind: RiskKind): Risk => ({ kind, why: RISK_WHY[kind] });

// ------------------------------------------------------------------------------------------------- what a command deletes (safety.ts)

/**
 * While riskAndPlan reads a line, what it would delete or discard is collected here instead of being called risky, so the agent can
 * keep a copy first and let it run without asking anyone (safety.ts). Only what is fully known is collected: a target made by a
 * substitution, a delete fed by xargs or a program held in an unknown variable stays a risk, as before.
 */
export type PlannedDelete = {
  /** The target as the program receives it (quotes removed; `$VAR`, `~` and globs left for safety.ts to resolve). */
  path: string;
  /** The target exactly as typed (to tell a pattern from a quoted `*`, and for Windows paths, whose backslashes are not escapes). */
  raw: string;
  /** Some of it was quoted. */
  quoted: boolean;
  /** Where a relative path starts: undefined = the command's own folder, a path (maybe `~...` or `$VAR...`) after a cd, null = not known. */
  base: string | null | undefined;
  recursive: boolean;
  /** What deletes it: rm, find, remove-item, code... */
  via: string;
  /** A build or temp folder: deleting it is routine, no copy is kept (it is still checked against what is never deleted). */
  routine?: boolean;
  /** Not deleted but emptied or written over in place (`> f`, truncate, dd of=, shred): kept as a real copy, not a link. */
  overwrite?: boolean;
  /** Only checked against what is never deleted (a move: nothing is lost). */
  checkOnly?: boolean;
};
export type GitUndoOp = 'discard' | 'clean' | 'stash' | 'branch-delete' | 'push-delete';
export type PlannedGit = { op: GitUndoOp; args: string[]; base: string | null | undefined };
export type Plan = { deletes: PlannedDelete[]; git: PlannedGit[] };

type Frame = { base: string | null | undefined };
let collecting: { plan: Plan; frames: Frame[]; suspended: number } | null = null;
const planOn = () => collecting !== null && collecting.suspended === 0;
const frameBase = (): string | null | undefined => (collecting ? collecting.frames[collecting.frames.length - 1]?.base : undefined);

/** Where `cd` (or pushd) goes for the plan: a path still holding `~`/`$VAR`, undefined = unchanged, null = not known. */
function planCd(words: Word[], prev: string | null | undefined): string | null | undefined {
  if (words.length === 1) return '~';
  if (words.length !== 2) return null;
  const w = words[1];
  if (w.hasSubst) return null;
  const t = w.text;
  if (t === '-' || /^~[^/]/.test(t)) return null;
  if (t.startsWith('~') || t.startsWith('/') || t.startsWith('$') || /^[A-Za-z]:[\\/]/.test(t)) return t;
  if (prev === null) return null;
  return prev === undefined ? t : `${prev}/${t}`;
}

/** Collects an rm-like delete when every target is known. false: something is not known (the delete stays a risk). */
function captureDeletes(via: string, targets: Word[], recursive: boolean, more: boolean, base: string, extra: { overwrite?: boolean; checkOnly?: boolean } = {}): boolean {
  if (!planOn() || more) return false;
  // `{}` (find -exec), a substitution, `~user`: what it names is not known here.
  if (targets.some((w) => w.text.includes('{}'))) return false;
  if (targets.some((w) => w.text.startsWith('/dev/'))) return false; // a device: the disk check decides
  if (targets.some((w) => !safeDeleteTarget(w, base) && (w.hasSubst || /^~[^/]/.test(w.text)))) return false;
  const b = frameBase();
  // Build and temp folders are collected too (marked routine: no copy), so safety.ts still sees one that is Escanor's own store.
  for (const w of targets) {
    if (w.hasSubst) continue;
    const routine = !extra.overwrite && safeDeleteTarget(w, base);
    collecting!.plan.deletes.push({ path: w.text, raw: w.raw, quoted: w.quoted, base: b, recursive, via, ...(routine ? { routine: true } : {}), ...(extra.overwrite ? { overwrite: true } : {}), ...(extra.checkOnly ? { checkOnly: true } : {}) });
  }
  return true;
}

const TEMP_DEST = /^(?:\/tmp\/|\/var\/tmp\/|\/private\/tmp\/|\/dev\/shm\/|\$\{?(?:TMPDIR|TMP|TEMP)\}?\/?|\/dev\/null$)/;
const DELETERS = new Set(['rm', 'unlink', 'shred', 'srm', 'rimraf', 'truncate', 'rmdir', 'mv']);

function rmTargets(a: Word[]): { recursive: boolean; targets: Word[] } {
  let recursive = false;
  let ended = false;
  const targets: Word[] = [];
  for (const w of a) {
    const t = w.text;
    if (!ended && t === '--') {
      ended = true;
      continue;
    }
    if (!ended && t.startsWith('-') && t.length > 1) {
      if (t === '--recursive' || (!t.startsWith('--') && /[rR]/.test(t))) recursive = true;
      continue;
    }
    targets.push(w);
  }
  return { recursive, targets };
}

/** Collects a git command that discards work or deletes a branch, so it can be kept first. false: not one that can be kept. */
function captureGit(a: Word[], g: Risk | null, more: boolean): boolean {
  if (!planOn() || more) return false;
  let i = 0;
  let dir: string | null | undefined = frameBase();
  while (i < a.length && a[i].text.startsWith('-')) {
    if (a[i].text === '-C') {
      const to = a[i + 1];
      if (!to || to.hasSubst) return false;
      dir = planCd([lit('cd'), to], dir);
    } else if (a[i].text === '--git-dir' || a[i].text === '--work-tree' || a[i].text.startsWith('--git-dir=') || a[i].text.startsWith('--work-tree=')) return false;
    i += GIT_GLOBAL_VALUED.includes(a[i].text) ? 2 : 1;
  }
  if (a.slice(i).some((w) => w.hasSubst)) return false;
  const sub = a[i]?.text;
  const args = a.slice(i + 1).map((w) => w.text);
  const flags = args.filter((x) => x.startsWith('-'));
  const add = (op: GitUndoOp) => {
    collecting!.plan.git.push({ op, args: [sub ?? '', ...args], base: dir });
    return true;
  };
  if (g?.kind === 'force-push') return false;
  if (sub === 'push') {
    if (g && flags.some((x) => x === '--mirror' || x === '--prune')) return false;
    return g ? add('push-delete') : false;
  }
  if (sub === 'reset' || sub === 'checkout' || sub === 'switch' || sub === 'restore') {
    if (g) return add('discard');
    // Not risky, but still throws away changes to the files it names (git checkout -- a.ts): kept too, it costs nothing.
    if ((sub === 'checkout' && args.includes('--')) || (sub === 'restore' && !flags.some((x) => x === '--staged' || x === '-S'))) add('discard');
    return false;
  }
  if (sub === 'clean') return g ? add('clean') : false;
  // git rm: files in the last commit come back from git; changes not committed yet are kept here first.
  if (sub === 'rm') {
    add('discard');
    return false;
  }
  if (sub === 'worktree' && args[0] === 'remove' && flags.some((x) => x === '--force' || x === '-f')) {
    const path = a.slice(i + 1).filter((w) => !w.text.startsWith('-'))[1];
    if (path) captureDeletes('git worktree', [path], true, false, '');
    return false;
  }
  if (sub === 'stash') return g ? add('stash') : false;
  if (sub === 'branch' && flags.some((x) => x === '-D' || x === '--delete' || x === '-d' || /^-[A-Za-z]*D/.test(x))) {
    add('branch-delete');
    return false;
  }
  return false;
}

/**
 * The risk of a command line, and what it would delete or discard that a copy can be kept of first. A delete that is collected is
 * not a risk here: the caller keeps the copy (or, if it cannot, treats it as the risk it would have been).
 */
export function riskAndPlan(command: string): { risk: Risk | null; plan: Plan } {
  const plan: Plan = { deletes: [], git: [] };
  const prev = collecting;
  collecting = { plan, frames: [{ base: undefined }], suspended: 0 };
  try {
    return { risk: riskyCommand(command), plan };
  } finally {
    collecting = prev;
  }
}

// ------------------------------------------------------------------------------------------------- programs and wrappers

const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh', 'fish', 'ash', 'mksh', 'busybox', 'csh', 'tcsh']);
const INTERPRETERS = new Set(['python', 'python2', 'python3', 'node', 'nodejs', 'deno', 'bun', 'perl', 'ruby', 'php', 'lua', 'pwsh', 'powershell', 'iex', 'invoke-expression']);
const DB_CLIENTS = new Set(['psql', 'mysql', 'mariadb', 'sqlite3', 'sqlite', 'mongosh', 'mongo', 'redis-cli', 'sqlcmd', 'cqlsh', 'clickhouse-client', 'clickhouse', 'duckdb', 'cockroach', 'pgcli', 'mycli', 'litecli', 'usql', 'bq', 'turso', 'snowsql', 'trino', 'presto', 'spanner-cli']);
const DOWNLOADERS = new Set(['curl', 'wget', 'fetch', 'http', 'https', 'httpie', 'xh', 'aria2c', 'invoke-webrequest', 'iwr', 'invoke-restmethod', 'irm']);
/**
 * Is this command only text? A text program, unless it is told to run another program on what it reads (`rg --pre`, `man -P`).
 * `words`: the program's arguments as written.
 */
export function onlyText(p: string, words: string[]): boolean {
  if (!TEXT_PROGRAMS.has(p)) return false;
  if ((p === 'rg' || p === 'ag') && words.some((w) => w === '--pre' || w.startsWith('--pre=') || w === '--pager' || w.startsWith('--pager='))) return false;
  if (p === 'man' && words.some((w) => /^-[A-Za-z]*P/.test(w) || w === '--pager' || w.startsWith('--pager=') || w.startsWith('-H') || w.startsWith('--html'))) return false;
  return true;
}

/** Programs whose arguments are only text: what they are given never runs. */
export const TEXT_PROGRAMS = new Set(['echo', 'printf', 'grep', 'egrep', 'fgrep', 'rg', 'ag', 'ack', 'man', 'which', 'whereis', 'whatis', 'apropos', 'type', 'tldr', 'info', 'wc', 'cowsay', 'logger', 'notify-send', 'say', 'true', 'false', ':', 'test', '[', '[[', 'help', 'jq', 'yq']);
const KEYWORDS = new Set(['if', 'then', 'else', 'elif', 'do', 'while', 'until', '!', '{', '}', 'time', 'coproc']);
/** Where a pipe into one of these could run what flows in. */
const RUNS_INPUT = new Set([...SHELLS, ...INTERPRETERS, ...DB_CLIENTS, 'sudo', 'doas', 'su', 'env', 'ssh', 'xargs', 'parallel', 'eval', 'source', '.', 'at', 'batch', 'crontab', 'awk', 'gawk', 'sed', 'docker', 'kubectl', 'podman']);

/** The program a word runs, lower-cased, with a leading backslash dropped (`\rm`). */
function prog(w: string): string {
  const p = programName(w);
  return (p.startsWith('\\') ? p.slice(1) : p).toLowerCase();
}

type Argv = {
  words: Word[];
  /** It is also given arguments not seen here (xargs, find -exec {} ...). */
  more: boolean;
  /** A command line a wrapper runs from a string (`bash -c "..."`, `ssh host "..."`, `eval`): read whole, pipes and all. */
  script?: string;
};

const flagTakesValue = (set: string[], w: string) => set.includes(w);

/**
 * The commands an argv really runs, wrappers taken off: `sudo -u x env A=1 nice -n 5 rm ...` is rm. Commands a wrapper runs from
 * a string (`bash -c "..."`, `ssh host "..."`, `su -c`, `eval`, `watch`) are read with the shell reader and returned too.
 */
function unwrap(words: Word[], depth: number, more = false): Argv[] {
  let i = 0;
  const out: Argv[] = [];
  const fromString = (text: string) => {
    out.push({ words: [], more: false, script: text });
  };
  while (i < words.length) {
    const w = words[i].text;
    if (/^[A-Za-z_][A-Za-z0-9_]*\+?=/.test(w) && !words[i].quoted) {
      i++;
      continue;
    }
    if (KEYWORDS.has(w)) {
      i++;
      continue;
    }
    const p = prog(w);
    const rest = words.slice(i + 1);
    const skipFlags = (valued: string[], j = 0): number => {
      while (j < rest.length) {
        const a = rest[j].text;
        if (a === '--') return j + 1;
        if (!a.startsWith('-') || a === '-') break;
        j += flagTakesValue(valued, a) ? 2 : 1;
      }
      return j;
    };
    if (p === 'sudo' || p === 'doas' || p === 'run0' || p === 'pkexec') {
      const j = skipFlags(['-u', '-g', '-h', '-p', '-C', '-D', '-r', '-t', '-U', '-T', '--user', '--group', '--host', '--prompt', '--chdir']);
      i += 1 + j;
      continue;
    }
    if (p === 'env') {
      let j = 0;
      while (j < rest.length) {
        const a = rest[j].text;
        if (a === '-S' || a === '--split-string') {
          fromString(rest.slice(j + 1).map((x) => x.text).join(' '));
          return out;
        }
        if (a.startsWith('--split-string=') || (a.startsWith('-S') && a.length > 2)) {
          // env -S'rm -rf ~' / --split-string='...': the string, then any words after it.
          fromString([a.startsWith('-S') ? a.slice(2) : a.slice('--split-string='.length), ...rest.slice(j + 1).map((x) => x.text)].join(' '));
          return out;
        }
        if (a === '-u' || a === '--unset' || a === '-C' || a === '--chdir') j += 2;
        else if (a.startsWith('-') || /^[A-Za-z_][A-Za-z0-9_]*=/.test(a)) j++;
        else break;
      }
      i += 1 + j;
      continue;
    }
    if (p === 'busybox' && rest[0] && !SHELLS.has(prog(rest[0].text))) {
      i++; // busybox rm -rf x: the applet is the program
      continue;
    }
    if (p === 'command' || p === 'builtin') {
      if (rest[0] && /^-[vV]$/.test(rest[0].text)) return out; // command -v x: only looks it up
      i += 1 + skipFlags([]);
      continue;
    }
    if (['nohup', 'time', 'exec', 'unbuffer', 'chronic', 'setsid', 'caffeinate', 'catchsegv', 'stdbuf', 'nice', 'ionice', 'timeout', 'gtimeout', 'chrt', 'taskset', 'flock', 'proxychains', 'proxychains4', 'tsocks', 'torsocks', 'firejail', 'strace', 'ltrace', 'npx', 'pnpx', 'bunx'].includes(p)) {
      let j = skipFlags(['-n', '-c', '-p', '-a', '-o', '-s', '-k', '--signal', '--kill-after', '-i', '-e', '-E', '--adjustment', '--class', '--classdata']);
      if (['timeout', 'gtimeout'].includes(p) && rest[j] && /^\d/.test(rest[j].text)) j++;
      if (p === 'taskset' && rest[j]) j++;
      if (p === 'flock' && rest[j]) j++;
      if ((p === 'npx' || p === 'pnpx' || p === 'bunx') && rest[j]?.text === '--yes') j++;
      i += 1 + j;
      continue;
    }
    if (p === 'unshare' || p === 'systemd-run' || p === 'chroot') {
      let j = skipFlags(['-u', '--unit', '-p', '--property', '-E', '--setenv', '-M', '--machine', '--uid', '--gid', '--slice', '--description', '--working-directory', '--userspec', '--groups']);
      if (p === 'chroot' && rest[j]) j++; // chroot NEWROOT command...
      i += 1 + j;
      continue;
    }
    if (p === 'script') {
      // script -c "command" [file]: that string is the command.
      const k = rest.findIndex((x) => x.text === '-c' || x.text === '--command');
      const eq = rest.find((x) => x.text.startsWith('--command='));
      if (k >= 0 && rest[k + 1]) fromString(rest[k + 1].text);
      if (eq) fromString(eq.text.slice('--command='.length));
      out.push({ words: words.slice(i), more });
      return out;
    }
    if ((p === 'npm' || p === 'pnpm' || p === 'yarn') && ['exec', 'dlx', 'x'].includes(rest[0]?.text ?? '')) {
      // npm exec rimraf /, pnpm dlx rimraf /: the package's command is the program.
      let j = 1;
      while (j < rest.length && rest[j].text.startsWith('-') && rest[j].text !== '--') j += ['-p', '--package', '-c', '--call', '-w', '--workspace'].includes(rest[j].text) ? 2 : 1;
      if (rest[j]?.text === '--') j++;
      const call = rest.findIndex((x) => x.text === '-c' || x.text === '--call');
      if (call >= 0 && rest[call + 1]) fromString(rest[call + 1].text);
      i += 1 + j;
      continue;
    }
    if (p === 'xargs' || p === 'parallel') {
      const j = skipFlags(['-I', '-i', '-n', '-P', '-L', '-l', '-s', '-d', '-E', '-e', '-a', '--arg-file', '--delimiter', '--max-args', '--max-procs', '-j', '--jobs']);
      i += 1 + j;
      more = true;
      continue;
    }
    if (p === 'cmd' || p === 'cmd.exe') {
      // cmd /c "..." / cmd /k ...: the rest of the line is the command.
      const k = rest.findIndex((x) => /^\/[ckCK]$/.test(x.text));
      if (k >= 0) fromString(rest.slice(k + 1).map((x) => x.raw.replace(/^"(.*)"$/s, '$1')).join(' '));
      out.push({ words: words.slice(i), more });
      return out;
    }
    if (p === 'pwsh' || p === 'powershell' || p === 'pwsh.exe' || p === 'powershell.exe') {
      // pwsh -Command "...", pwsh -c ..., pwsh -EncodedCommand <base64 UTF-16>: that is the command.
      const k = rest.findIndex((x) => /^-(?:c|command|e|ec|encodedcommand)$/i.test(x.text));
      if (k >= 0 && rest[k + 1]) {
        if (/^-(?:e|ec|encodedcommand)$/i.test(rest[k].text)) {
          try {
            fromString(Buffer.from(rest[k + 1].text, 'base64').toString('utf16le'));
          } catch {
            fromString('eval "$UNREADABLE"');
          }
        } else fromString(rest.slice(k + 1).map((x) => x.raw.replace(/^(["'])(.*)\1$/s, '$2')).join(' '));
      }
      out.push({ words: words.slice(i), more });
      return out;
    }
    if (SHELLS.has(p) || p === 'su') {
      // bash -c "...": that string is the command. Flags like -lc / -ec carry the c. It is looked for among all the words, so an
      // option with a value before it (`bash -o pipefail -c`, `bash -O extglob -c`, `su admin -c`) does not hide it; a word that
      // only looks like -c after a script file is read too (a hold too many, never one too few).
      for (let j = 0; j < rest.length; j++) {
        const a = rest[j].text;
        if (a.startsWith('--command=')) fromString(a.slice('--command='.length));
        else if (/^-[A-Za-z]*c[A-Za-z]*$/.test(a) || a === '--command') {
          if (rest[j + 1]) fromString(rest[j + 1].text);
          j++;
        }
      }
      out.push({ words: words.slice(i), more });
      return out;
    }
    if (p === 'eval') {
      fromString(rest.map((x) => x.text).join(' '));
      // eval itself too: what it runs may come from a download (`eval "$(curl ...)"`).
      out.push({ words: words.slice(i), more });
      return out;
    }
    if (p === 'watch') {
      const j = skipFlags(['-n', '--interval', '-d', '--differences']);
      fromString(rest.slice(j).map((x) => x.text).join(' '));
      return out;
    }
    if (p === 'ssh') {
      const j = skipFlags(['-p', '-i', '-l', '-o', '-F', '-J', '-L', '-R', '-D', '-E', '-b', '-c', '-e', '-m', '-O', '-Q', '-S', '-W', '-w', '-B', '-I']);
      // The host, then the remote command (joined, as ssh joins it).
      const remote = rest.slice(j + 1).map((x) => x.text);
      if (remote[0] === '--') remote.shift(); // ssh host -- cmd
      if (remote.length) fromString(remote.join(' '));
      return out;
    }
    if ((p === 'docker' || p === 'podman' || p === 'nerdctl') && rest[0]?.text === 'exec') {
      let j = 1;
      while (j < rest.length && rest[j].text.startsWith('-')) j += ['-e', '--env', '-u', '--user', '-w', '--workdir', '--env-file'].includes(rest[j].text) ? 2 : 1;
      out.push(...unwrap(rest.slice(j + 1), depth + 1));
      out.push({ words: words.slice(i), more });
      return out;
    }
    if ((p === 'kubectl' || p === 'oc') && rest[0]?.text === 'exec') {
      const dash = rest.findIndex((x) => x.text === '--');
      if (dash >= 0) out.push(...unwrap(rest.slice(dash + 1), depth + 1));
      return out;
    }
    if (p === 'find') {
      // -exec / -execdir / -ok run a command for each file found: `{}` is a path under find's starting folders.
      const roots: Word[] = [];
      let j = 0;
      while (j < rest.length && !rest[j].text.startsWith('-') && rest[j].text !== '(' && rest[j].text !== '!') roots.push(rest[j++]);
      for (; j < rest.length; j++) {
        if (['-exec', '-execdir', '-ok', '-okdir'].includes(rest[j].text)) {
          const end = rest.findIndex((x, k) => k > j && (x.text === ';' || x.text === '+'));
          const inner = rest.slice(j + 1, end < 0 ? rest.length : end);
          const rootsSafe = findTargetsSafe(roots, rest);
          // A delete of each file found is as safe as the folders it searches.
          const resolved = inner.map((x) => (x.text.includes('{}') ? (rootsSafe ? lit('./build/x') : lit('{}')) : x));
          // What find visits is what an inner delete takes: its starting folders are checked (and kept) as a delete.
          const innerProg = unwrap(inner, depth + 1).map((x) => prog(x.words[0]?.text ?? ''));
          if (innerProg.some((q) => DELETERS.has(q))) captureDeletes('find', roots.length ? roots : [lit('.')], true, more, '');
          out.push(...unwrap(resolved, depth + 1));
          if (end > 0) j = end;
        }
      }
      out.push({ words: words.slice(i), more });
      return out;
    }
    out.push({ words: words.slice(i), more });
    return out;
  }
  return out;
}

const lit = (text: string): Word => ({ text, raw: text, quoted: false, hasVar: false, hasSubst: false, subst: [] });

// ------------------------------------------------------------------------------------------------- deleting folders

/** A project's own build output, caches and temporary folders: deleting one of these is routine. */
export const BUILD_DIRS: ReadonlySet<string> = new Set([
  'node_modules', 'dist', 'build', 'out', 'target', '.next', '.nuxt', '.svelte-kit', '.turbo', '.cache', '.parcel-cache', '.vite', '.angular',
  '.expo', '.dart_tool', '.gradle', 'coverage', '.nyc_output', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache', '.tox', '.venv',
  'venv', 'tmp', 'temp', '.tmp', '.temp', 'obj', 'storybook-static', '.docusaurus', '.vercel', '.netlify', '.wrangler', '.serverless',
  '.terraform', 'cdk.out', '.eggs', 'htmlcov', '.hypothesis', '.sass-cache', '.output', 'lib-cov', '.pnpm-store', '.yarn-cache', 'bower_components',
  '.build', 'DerivedData', '.dart-tool', 'Pods', '.cxx', '.externalNativeBuild', 'cmake-build-debug', 'cmake-build-release', '.stack-work',
  'elm-stuff', '_build', 'deps', '.elixir_ls', '.mix', 'zig-cache', 'zig-out', '.zig-cache', '.ipynb_checkpoints',
  '.webpack', '.esbuild', '.rollup.cache', '.swc', '.vitest', '.jest-cache', 'jest_cache', 'playwright-report', 'test-results', '.astro',
]);
const TEMP_ROOTS = ['/tmp/', '/var/tmp/', '/private/tmp/', '/private/var/folders/', '/dev/shm/'];
const TEMP_VARS = /^(?:\$\{?(?:TMPDIR|TMP|TEMP|TEMPDIR|RUNNER_TEMP)\}?|\$\(mktemp(?: [^)]*)?\)|`mktemp(?: [^`]*)?`)(?=\/|$)/;
const PWD_VARS = /^(?:\$\{?PWD\}?|\$\(pwd\)|`pwd`)(?=\/|$)/;

/** Lexically resolved path segments ('..' popped). null when '..' climbs above where a relative path starts. */
function segments(path: string): string[] | null {
  const out: string[] = [];
  for (const s of path.split('/')) {
    if (s === '' || s === '.') continue;
    if (s === '..') {
      if (!out.length || out[out.length - 1] === '..') return null;
      out.pop();
    } else out.push(s);
  }
  return out;
}

/**
 * Is a recursive delete of this word routine (a build, cache or temp folder of the project)? Unknown values ($X, $(...)) are
 * not. `base`: the folder an earlier `cd` on the same line moved to, for a relative path.
 */
export function safeDeleteTarget(w: Word, base = ''): boolean {
  let t = w.raw.replace(/["'\\]/g, '');
  let temp = false;
  const tv = TEMP_VARS.exec(t);
  if (tv) {
    temp = true;
    t = `/tmp/x${t.slice(tv[0].length)}`;
  }
  const pv = PWD_VARS.exec(t);
  if (pv) t = `.${t.slice(pv[0].length)}`;
  if (t.includes('$') || t.includes('`') || t.includes('{}')) return false;
  if (/^~(?=\/|$)/.test(t)) t = `/home/u${t.slice(1)}`;
  if (!t.startsWith('/') && base) t = `${base}/${t}`;
  if (t.startsWith('/')) {
    const segs = segments(t);
    if (!segs) return false;
    const abs = `/${segs.join('/')}/`;
    // Something inside a temp folder (not the temp folder itself).
    if (TEMP_ROOTS.some((r) => abs.startsWith(r) && abs.length > r.length)) return true;
    if (temp) return false;
    // A build folder at least two levels down (/home/u/app/dist, never /dist or /home/build).
    return segs.some((s, k) => k >= 2 && (BUILD_DIRS.has(s) || /\.egg-info$/.test(s)));
  }
  const segs = segments(t);
  if (!segs || !segs.length) return false; // `.`, `./`, `*`... the whole project, or above it
  return segs.some((s) => BUILD_DIRS.has(s) || /\.egg-info$/.test(s));
}

function rmRisk(a: Word[], more: boolean, base: string): boolean {
  let recursive = false;
  const targets: Word[] = [];
  let ended = false;
  for (const w of a) {
    const t = w.text;
    if (!ended && t === '--') {
      ended = true;
      continue;
    }
    if (!ended && t.startsWith('-') && t.length > 1) {
      if (t === '--recursive' || (!t.startsWith('--') && /[rR]/.test(t))) recursive = true;
      continue;
    }
    targets.push(w);
  }
  if (!recursive) return false;
  // xargs rm -r: what it deletes comes from elsewhere, so it is not known to be safe.
  if (more) return true;
  return targets.some((w) => !safeDeleteTarget(w, base));
}

/** A relative path that stays inside the project folder (no `..` above it, no variable). */
function inProject(w: Word, base = ''): boolean {
  if (base) return false;
  const t = w.raw.replace(/["']/g, '');
  if (!t || t.startsWith('/') || t.startsWith('~') || t.includes('$') || t.includes('`')) return false;
  return segments(t) !== null;
}

/**
 * A find expression that negates its tests or offers another branch (`! -name dist`, `-not`, `-o`, `-prune -o`, `,`): its names then
 * say what it skips, not what it takes. (`-prune` alone only stops find going deeper; `-a` only joins.)
 */
const FIND_NEGATES = new Set(['!', '-not', '-o', '-or', ',']);
const findNegates = (args: Word[]) => args.some((w) => FIND_NEGATES.has(w.text));

/** What find visits is safe to delete: its folders are build or temp folders, or it looks only for build folders inside the project. */
function findTargetsSafe(roots: Word[], args: Word[], base = ''): boolean {
  const from = roots.length ? roots : [lit('.')];
  if (from.every((r) => safeDeleteTarget(r, base))) return true;
  if (findNegates(args)) return false;
  const names = args.flatMap((w, k) => (['-name', '-iname'].includes(w.text) && args[k + 1] ? [args[k + 1].text] : []));
  return names.length > 0 && names.every((n) => BUILD_DIRS.has(n) || /\.egg-info$/.test(n)) && from.every((r) => inProject(r, base));
}

function findDeleteRisk(a: Word[], base: string): boolean {
  if (!a.some((w) => w.text === '-delete')) return false;
  const roots: Word[] = [];
  let j = 0;
  while (j < a.length && !a[j].text.startsWith('-') && a[j].text !== '(' && a[j].text !== '!') roots.push(a[j++]);
  if (findTargetsSafe(roots, a, base)) return false;
  // Inside the project, a search narrowed by name (`-name "*.pyc"`) deletes those files, not the project. Age or size alone is
  // not narrow: `find . -mtime +1 -delete` takes most of the project.
  const filtered = !findNegates(a) && a.some((w, k) => ['-name', '-iname', '-path', '-ipath', '-regex', '-iregex'].includes(w.text) && a[k + 1] && !/^\*+$/.test(a[k + 1].text));
  return !(filtered && (roots.length ? roots : [lit('.')]).every((r) => inProject(r, base)));
}

// ------------------------------------------------------------------------------------------------- git

/** Branches a force push must never go over: the usual default and release branches. */
export const PROTECTED_BRANCH_NAMES: ReadonlySet<string> = new Set(['main', 'master', 'trunk', 'develop', 'development', 'dev', 'production', 'prod', 'release', 'releases', 'staging', 'stable', 'live', 'default', 'gh-pages']);

function protectedRef(ref: string): boolean {
  const dst = ref.includes(':') ? ref.slice(ref.lastIndexOf(':') + 1) : ref;
  const name = dst.replace(/^\+/, '').replace(/^refs\/heads\//, '');
  if (name === 'HEAD' || name === '@' || name === '') return true;
  if (/[$`]/.test(name)) return true; // a branch given by a variable or $(...): not known, so taken as protected
  return PROTECTED_BRANCH_NAMES.has(name.toLowerCase()) || PROTECTED_BRANCH_NAMES.has(name.split('/')[0].toLowerCase());
}

const GIT_GLOBAL_VALUED = ['-C', '-c', '--git-dir', '--work-tree', '--namespace', '--exec-path', '--config-env'];

function gitRisk(a: Word[]): Risk | null {
  let i = 0;
  while (i < a.length && a[i].text.startsWith('-')) {
    // git -c alias.x='!rm -rf ~' x: an alias that runs a shell command, not read here.
    if (a[i].text === '-c' && /^alias\.[^=]*=\s*!/i.test(a[i + 1]?.text ?? '')) return risk('unreadable');
    i += GIT_GLOBAL_VALUED.includes(a[i].text) ? 2 : 1;
  }
  const sub = a[i]?.text;
  const args = a.slice(i + 1).map((w) => w.text);
  const flags = args.filter((x) => x.startsWith('-'));
  const has = (...f: string[]) => flags.some((x) => f.includes(x) || f.some((g) => g.startsWith('--') && x.startsWith(`${g}=`)));
  const short = (ch: string) => flags.some((x) => /^-[A-Za-z]+$/.test(x) && x.includes(ch));
  if (sub === 'push') {
    const pos: string[] = [];
    for (let k = 0; k < args.length; k++) {
      const x = args[k];
      if (['-o', '--push-option', '--repo', '--receive-pack', '--exec'].includes(x)) {
        k++;
        continue;
      }
      if (!x.startsWith('-')) pos.push(x);
    }
    const refs = pos.slice(1);
    if (has('--delete') || short('d') || refs.some((r) => r.startsWith(':'))) return risk('remote-delete');
    if (has('--mirror', '--prune')) return risk('remote-delete');
    const force = has('--force', '--force-with-lease') || short('f') || refs.some((r) => r.startsWith('+'));
    if (force && (refs.length === 0 || has('--all', '--branches', '--tags') || refs.some(protectedRef))) return risk('force-push');
    return null;
  }
  if (sub === 'reset' && has('--hard')) return risk('discard-work');
  if (sub === 'clean' && !has('--dry-run') && !short('n') && (has('--force') || short('f'))) return risk('discard-work');
  if (sub === 'checkout' || sub === 'switch') {
    if (has('--force', '--discard-changes') || short('f')) return risk('discard-work');
    if (sub === 'checkout') {
      const dd = args.indexOf('--');
      const paths = dd >= 0 ? args.slice(dd + 1) : args.filter((x) => !x.startsWith('-'));
      if (paths.some((p) => p === '.' || p === ':/' || p === '*' || p === './' || p === ':(top)')) return risk('discard-work');
    }
  }
  if (sub === 'restore') {
    const staged = has('--staged') || short('S');
    const worktree = has('--worktree') || short('W');
    const paths = args.filter((x) => !x.startsWith('-'));
    if ((!staged || worktree) && paths.some((p) => p === '.' || p === ':/' || p === '*' || p === './')) return risk('discard-work');
  }
  if (sub === 'stash' && (args[0] === 'clear' || args[0] === 'drop')) return risk('discard-work');
  return null;
}

function ghRisk(a: Word[]): Risk | null {
  const t = a.map((w) => w.text);
  if ((t[0] === 'repo' || t[0] === 'release') && t[1] === 'delete') return risk('cloud-delete');
  if (t[0] === 'api') {
    const m = t.findIndex((x) => x === '-X' || x === '--method');
    const method = m >= 0 ? t[m + 1] : t.find((x) => x.startsWith('--method='))?.slice(9) ?? t.find((x) => /^-X[A-Za-z]+$/.test(x))?.slice(2);
    if (method?.toUpperCase() === 'DELETE') return t.some((x) => /\/git\/refs\//.test(x)) ? risk('remote-delete') : risk('cloud-delete');
  }
  return null;
}

// ------------------------------------------------------------------------------------------------- databases

const SQL_DROP = /\bdrop\s+(?:table|database|schema|keyspace|collection)\b/i;
const SQL_TRUNCATE = /\btruncate\s+(?:table\s+)?(?:only\s+)?[`"[\w]/i;
const MONGO_WIPE = /\.(?:drop|dropDatabase)\s*\(\s*\)|\.(?:deleteMany|remove)\s*\(\s*(?:\{\s*\})?\s*[,)]/;
const REDIS_WIPE = /\bflush(?:all|db)\b/i;

/** Code that talks to a database: a driver, a connection, or a statement run. */
const DB_CALL = /\b(?:execute(?:script|many)?|executeRaw\w*|queryRaw\w*|raw|query|exec|run|sql)\s*\(|\bcursor\b|\bconnect\s*\(|\b(?:sqlite3|psycopg2?|pymysql|MySQLdb|sqlalchemy|asyncpg|aiosqlite|duckdb|pymongo|motor|redis|mysql2?|pg|better-sqlite3|knex|sequelize|typeorm|prisma|drizzle|mongoose|mongodb)\b|\b(?:create_engine|MongoClient|Pool|Client|Database)\s*\(|\bsubprocess\b[\s\S]*\b(?:psql|mysql|sqlite3|mongosh)\b/;

/** Statements that drop or empty a table, or delete rows with no WHERE. Statements are split on ';'. */
export function sqlRisk(text: string): boolean {
  if (!text) return false;
  if (SQL_DROP.test(text) || SQL_TRUNCATE.test(text) || MONGO_WIPE.test(text)) return true;
  for (const stmt of text.split(';')) {
    const m = /\bdelete\s+from\s+\S+/i.exec(stmt);
    if (m && !/\bwhere\b/i.test(stmt.slice(m.index))) return true;
  }
  return false;
}

const ORM_WIPES: Array<[string, RegExp]> = [
  ['prisma', /\bmigrate reset\b|\bdb push\b.*--(?:force-reset|accept-data-loss)/],
  ['rails', /\bdb:(?:drop|reset|purge|schema:load)\b/],
  ['rake', /\bdb:(?:drop|reset|purge|schema:load)\b/],
  ['sequelize', /\bdb:drop\b/],
  ['typeorm', /\bschema:drop\b/],
  ['knex', /\bmigrate:rollback\b.*--all/],
  ['supabase', /\bdb reset\b.*--linked|\bdb reset\b.*--db-url/],
  ['mongorestore', /--drop\b/],
];

function databaseRisk(p: string, a: Word[], c: Command): boolean {
  const joined = a.map((w) => w.text).join(' ');
  if (p === 'redis-cli' && a.some((w) => /^flush(?:all|db)$/i.test(w.text))) return true;
  for (const [name, re] of ORM_WIPES) if (p === name && re.test(joined)) return true;
  if ((p === 'python' || p === 'python3') && /\bmanage\.py\s+(?:flush|reset_db)\b/.test(joined)) return true;
  if (DB_CLIENTS.has(p) || INTERPRETERS.has(p) || p === 'wrangler' || p === 'gcloud' || p === 'atlas' || p === 'mongocli') {
    // A program (python, node...) is only held when its code also talks to a database: a test or a checker that merely holds the
    // words "DROP TABLE" in a string is not a wipe. A database client runs whatever SQL it is given.
    const code = INTERPRETERS.has(p);
    const wipes = (text: string) => (code ? MONGO_WIPE.test(text) || (sqlRisk(text) && DB_CALL.test(text)) : sqlRisk(text));
    if (wipes(joined) || (p === 'redis-cli' && REDIS_WIPE.test(joined))) return true;
    for (const h of c.heredocs) if (wipes(h.body) || (p === 'redis-cli' && REDIS_WIPE.test(h.body))) return true;
    for (const h of c.herestrings) if (wipes(h.text)) return true;
    // What is piped in from echo / printf / cat <<EOF.
    const from = c.pipeFrom;
    if (from && TEXT_PROGRAMS.has(prog(from.words[0]?.text ?? '')) && wipes(from.words.slice(1).map((w) => w.text).join(' '))) return true;
    if (from && prog(from.words[0]?.text ?? '') === 'cat' && from.heredocs.some((h) => wipes(h.body))) return true;
  }
  return false;
}

// ------------------------------------------------------------------------------------------------- clusters, infra, containers, clouds

function clusterRisk(p: string, a: string[]): boolean {
  // The subcommand is looked for among all the words that are not options, so an option with a value before it
  // (`kubectl -v 6 delete`, `helm -n prod uninstall`) does not hide it. A name that happens to be such a word is held too.
  const pos = a.filter((x) => !x.startsWith('-'));
  if (['kubectl', 'oc', 'k', 'kubecolor', 'microk8s.kubectl'].includes(p)) {
    // Only these are a dry run; kubectl reads --dry-run=false (or none) as no dry run at all.
    const dry = a.some((x) => ['--dry-run', '--dry-run=client', '--dry-run=server', '--dry-run=true'].includes(x));
    if (dry) return false;
    if (pos.includes('delete') || pos.includes('drain')) return true;
    if (pos.includes('replace') && a.some((x) => x === '--force' || x === '--force=true')) return true;
    if (pos.includes('apply') && a.some((x) => x === '--prune' || x.startsWith('--prune='))) return true;
    return false;
  }
  if (p === 'helm') return pos.some((x) => ['uninstall', 'delete', 'del', 'un'].includes(x));
  if (p === 'eksctl') return pos.includes('delete');
  return false;
}

function infraRisk(p: string, a: string[]): boolean {
  const pos = a.filter((x) => !x.startsWith('-'));
  if (['terraform', 'tofu', 'terragrunt', 'cdktf'].includes(p)) {
    const sub = pos[0] === 'run-all' ? pos[1] : pos[0];
    if (sub === 'destroy' || pos.includes('destroy')) return true;
    if (sub === 'apply' && a.some((x) => x === '-destroy' || x === '--destroy')) return true;
    if (sub === 'state' && (pos[1] === 'rm' || pos[1] === 'replace-provider')) return true;
    if (sub === 'workspace' && pos[1] === 'delete') return true;
    return false;
  }
  // Options with a value may come first (`pulumi -s prod destroy`, `cdk --profile p destroy`): any word that is not an option counts.
  if (p === 'pulumi') return pos.includes('destroy') || pos.includes('down') || pos.some((x, k) => x === 'stack' && pos[k + 1] === 'rm');
  if (p === 'cdk') return pos.includes('destroy');
  if (p === 'sst') return pos.includes('remove');
  if (p === 'serverless' || p === 'sls') return pos.includes('remove');
  if (p === 'copilot') return pos.includes('delete');
  return false;
}

function containerRisk(p: string, a: Word[]): boolean {
  if (!['docker', 'podman', 'nerdctl'].includes(p) && !(p === 'docker-compose')) return false;
  const t = a.map((w) => w.text);
  const pos = t.filter((x) => !x.startsWith('-'));
  if (p === 'docker-compose' || pos[0] === 'compose') {
    const sub = p === 'docker-compose' ? pos[0] : pos[1];
    return sub === 'down' && t.some((x) => x === '-v' || x === '--volumes' || x === '--rmi');
  }
  if (pos.includes('prune')) return true;
  if (pos[0] === 'volume' && (pos[1] === 'rm' || pos[1] === 'remove')) return true;
  // docker rm -f $(docker ps -aq), docker rmi $(docker images -q): everything at once.
  const rmLike = ['rm', 'rmi'].includes(pos[0]) || (['container', 'image'].includes(pos[0]) && ['rm', 'remove'].includes(pos[1]));
  return rmLike && a.some((w) => w.hasSubst);
}

const CLOUD_CLIS = new Set(['aws', 'gcloud', 'gsutil', 'az', 'doctl', 'heroku', 'vercel', 'netlify', 'fly', 'flyctl', 'railway', 'firebase', 'supabase', 'wrangler', 'glab', 'oci', 'linode-cli', 'hcloud', 'vultr-cli', 'ibmcloud', 'scw', 'exo', 's3cmd', 'rclone', 'stripe', 'render', 'aliyun', 'cf', 'atlas', 'mongocli', 'neonctl', 'neon', 'pscale', 'turso', 'upctl', 'civo', 'exoscale', 'b2', 'mc', 'azcopy', 'bq', 'cloudflared', 'gh', 'tsh', 'doppler', 'vault', 'consul', 'nomad', 'okteto', 'koyeb', 'northflank', 'appwrite', 'convex', 'planetscale']);
const CLOUD_DELETE_WORD = /^(?:delete|destroy|remove|rm|rb|purge|terminate|deregister|del|drop|wipe|nuke|erase)$|^(?:delete|terminate|remove|destroy|deregister|purge)-|-(?:delete|destroy|remove)$|:(?:delete|destroy|remove|rm)$|^(?:apps|projects|sites|databases?|buckets?):(?:destroy|delete)$/i;

function cloudRisk(p: string, a: string[]): boolean {
  if (!CLOUD_CLIS.has(p)) return false;
  if (a.some((x) => x === '--dry-run' || x === '--dryrun')) return false;
  if (p === 'gh') return false; // ghRisk decides
  if (p === 'rclone') return a.some((x) => ['purge', 'delete', 'deletefile', 'rmdir', 'rmdirs', 'sync'].includes(x)) && !a.includes('--dry-run');
  if (p === 'mc') return a.some((x) => ['rm', 'rb'].includes(x));
  return a.some((x) => !x.startsWith('-') && CLOUD_DELETE_WORD.test(x));
}

// ------------------------------------------------------------------------------------------------- disks and permissions

const DISK_TOOLS = new Set(['mkfs', 'mke2fs', 'mkswap', 'sfdisk', 'cfdisk', 'wipefs', 'blkdiscard', 'mkntfs', 'mkdosfs', 'newfs', 'badblocks']);
const RAW_DEVICE = /^\/dev\/(?:sd|nvme|hd|vd|xvd|mmcblk|disk|rdisk|md|dm-|mapper\/|loop|sr|nbd)/;

function diskRisk(p: string, a: string[], c: Command): boolean {
  if (p === 'format') return a.some((x) => /^[A-Za-z]:$/.test(x)); // Windows: format D:
  if (DISK_TOOLS.has(p) || p.startsWith('mk' + 'fs')) {
    if (p === 'badblocks') return a.includes('-w');
    if (p === 'wipefs') return !a.includes('-n') && !a.includes('--no-act') && a.some((x) => x.startsWith('-a') || x === '--all' || x.startsWith('-o') || x === '--offset');
    return true;
  }
  if (p === 'fdisk' || p === 'gdisk') return !a.some((x) => x === '-l' || x === '--list');
  if (p === 'sgdisk') return a.some((x) => /^(?:-Z|--zap-all|-z|--zap|-o|--clear|-d|--delete|-n|--new|-g|--mbrtogpt)/.test(x));
  if (p === 'parted') return a.some((x) => ['mklabel', 'mkpart', 'rm', 'resizepart', 'mkfs'].includes(x));
  if (p === 'dd') return a.some((x) => x.startsWith('of=/dev/') && x !== 'of=/dev/null' && x !== 'of=/dev/stdout' && x !== 'of=/dev/stderr');
  // Copied or written straight onto a disk (`cp img /dev/sda`, `tee /dev/sdb`, `pv img > ...`).
  if (['cp', 'tee', 'pv', 'cat', 'install', 'rsync', 'ddrescue', 'balena', 'etcher'].includes(p)) return a.some((x) => RAW_DEVICE.test(x) && !(p === 'cat' || p === 'pv'));
  if (p === 'shred') return a.some((x) => RAW_DEVICE.test(x));
  if (p === 'diskutil') return /^(?:eraseDisk|eraseVolume|zeroDisk|randomDisk|secureErase|partitionDisk|reformat)$/i.test(a[0] ?? '') || (a[0] === 'apfs' && /^delete/i.test(a[1] ?? ''));
  if (p === 'cryptsetup') return a.some((x) => ['luksFormat', 'erase', 'luksErase', 'reencrypt'].includes(x));
  if (p === 'zpool') return a[0] === 'destroy' || a[0] === 'labelclear';
  if (p === 'zfs') return a[0] === 'destroy';
  if (['lvremove', 'vgremove', 'pvremove'].includes(p)) return true;
  if (p === 'mdadm') return a.includes('--zero-superblock');
  if (p === 'hdparm') return a.some((x) => x.startsWith('--security-erase') || x === '--trim-sector-ranges');
  if (p === 'nvme') return a[0] === 'format' || a[0] === 'sanitize';
  // Anything written with > onto a raw disk.
  return c.redirects.some((r) => (r.op.endsWith('>') || r.op.endsWith('>>') || r.op.endsWith('>|')) && r.target && RAW_DEVICE.test(r.target.text));
}

/** The whole machine, or a folder holding all of it (system folders, every home). */
function wholeMachine(path: string): boolean {
  let t = path.replace(/["']/g, '');
  if (/^(?:~|\$HOME|\$\{HOME\})(?:\/?\*?)$/.test(t)) return true;
  if (!t.startsWith('/')) return false;
  const segs = segments(t);
  if (!segs) return true;
  while (segs.length && /^\*+$/.test(segs[segs.length - 1])) segs.pop();
  if (!segs.length) return true;
  return segs.length === 1 && ['home', 'etc', 'usr', 'var', 'bin', 'sbin', 'lib', 'lib64', 'opt', 'boot', 'root', 'srv', 'Users', 'System', 'Library', 'Applications', 'private'].includes(segs[0]);
}

function permissionsRisk(p: string, a: string[]): boolean {
  if (!['chmod', 'chown', 'chgrp', 'setfacl', 'chattr'].includes(p)) return false;
  const recursive = a.some((x) => x === '-R' || x === '--recursive' || /^-[A-Za-z]*R[A-Za-z]*$/.test(x));
  const targets = a.filter((x) => !x.startsWith('-'));
  const mode = p === 'chmod' ? targets[0] ?? '' : '';
  const paths = p === 'chmod' || p === 'chown' || p === 'chgrp' ? targets.slice(1) : targets;
  if (!paths.some(wholeMachine)) return false;
  // Anyone may write: a numeric mode whose last digit has the write bit, or a+w / o+w / +w.
  const opens = /^[0-7]*[2367]$/.test(mode) || /(?:^|,)[ugoa]*\+[rwxXst]*w/.test(mode);
  return recursive || opens;
}

// ------------------------------------------------------------------------------------------------- downloads run at once

/** Does this program take the code it runs from its input (`sh`, `python3 -`, `node`, `iex`) rather than from a file or -c? */
function readsCodeFromInput(p: string, a: string[]): boolean {
  if (p === 'iex' || p === 'invoke-expression') return true;
  if (SHELLS.has(p)) {
    if (a.some((x) => /^-[A-Za-z]*c[A-Za-z]*$/.test(x) || x === '--command')) return false;
    const pos = a.filter((x) => !x.startsWith('-') && !x.startsWith('+'));
    return a.includes('-s') || !pos.length || pos[0] === '-';
  }
  if (INTERPRETERS.has(p)) {
    if (a.some((x) => ['-c', '-m', '-e', '-E', '-r', '-p', '--eval', '--print', '-File', '-file'].includes(x))) return false;
    if (a.some((x, k) => /^-command$/i.test(x))) return a.some((x, k) => /^-command$/i.test(x) && a[k + 1] === '-');
    const pos = a.filter((x) => !x.startsWith('-'));
    return !pos.length || a.includes('-');
  }
  return false;
}

/** The words where a shell or interpreter takes the code it runs: `bash <(curl ..)`, `sh -c "$(curl ..)"`, `eval "$(curl ..)"`. */
function codeWords(p: string, words: Word[]): Word[] {
  const rest = words.slice(1);
  if (p === 'eval') return rest;
  if (p === 'source' || p === '.') return rest.slice(0, 1);
  const c = rest.findIndex((w) => /^-[A-Za-z]*[ce][A-Za-z]*$/.test(w.text) || w.text === '--command' || w.text === '--eval' || /^-command$/i.test(w.text));
  if (c >= 0) return rest.slice(c + 1, c + 2);
  const first = rest.find((w) => !w.text.startsWith('-'));
  return first ? [first] : [];
}

/** Does any of these commands download (`curl`, `sudo wget`, `bash -c "curl ..."`)? */
function downloads(cmds: Command[], depth = 0): boolean {
  if (depth > 4) return true; // too deep to follow: taken as a download
  return cmds.some((s) =>
    unwrap(s.words, 0).some((a) => (a.script !== undefined ? downloads(parseShell(a.script, 1).commands, depth + 1) : DOWNLOADERS.has(prog(a.words[0]?.text ?? '')))),
  );
}

function downloadRunRisk(p: string, words: Word[], c: Command): boolean {
  const runsCode = SHELLS.has(p) || INTERPRETERS.has(p) || p === 'source' || p === '.' || p === 'eval';
  if (!runsCode) return false;
  const a = words.slice(1).map((w) => w.text);
  // curl ... | sh (any stage before it downloads), when sh takes its code from that pipe.
  if (readsCodeFromInput(p, a)) {
    for (let from = c.pipeFrom; from; from = from.pipeFrom) if (downloads([from])) return true;
  }
  return codeWords(p, words).some((w) => downloads(w.subst));
}

// ------------------------------------------------------------------------------------------------- the check

/** Programs a word could name when it is a variable whose value is not known here (`$X -rf src`). */
const VAR_PROGRAM_GUESSES = ['rm', 'bash', 'git', 'kubectl', 'helm', 'terraform', 'pulumi', 'docker', 'aws', 'gcloud', 'az', 'psql', 'mysql', 'mongosh', 'redis-cli', 'dd', 'chmod', 'chown', 'find'];
const VAR_WORD = /^\$\{?([A-Za-z_][A-Za-z0-9_]*)\}?$/;

/** Calls in interpreter code (`python3 -c`, `node -e`...) that run a shell command or delete a folder tree. */
const RUNS_SHELL_CODE = /\b(?:subprocess|child_process|commands\.getoutput)\b|\b(?:os\.system|os\.popen|execSync|spawnSync|execFileSync|exec|spawn|system|popen|Popen|shell_exec|passthru|IO\.popen)\s*\(|`/;
const DELETES_TREE_CODE = /\b(?:rmtree|rmSync|rmdirSync|rm_rf|rm_r|remove_dir_all|rimraf|removedirs|remove_entry_secure)\s*\(\s*/g;
/** Single-file deletes in code: kept when the file is named by a literal (os.remove('a.ts'), fs.unlinkSync("x")). */
const DELETES_FILE_CODE = /\b(?:os\.remove|os\.unlink|unlinkSync|unlink|File\.delete|FileUtils\.rm|remove_file)\s*\(\s*/g;
const PATH_UNLINK_CODE = /\bPath\(\s*('(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*")\s*\)\s*\.unlink\s*\(/g;
const STRING_LITERAL = /'((?:[^'\\\n]|\\.)*)'|"((?:[^"\\\n]|\\.)*)"/g;

function codeRisk(code: string, base: string, depth: number): Risk | null {
  if (RUNS_SHELL_CODE.test(code)) {
    const literals = [...code.matchAll(STRING_LITERAL)].map((m) => (m[1] ?? m[2] ?? '').replace(/\\(.)/g, '$1'));
    // Each string, and all of them together (subprocess.run(["rm", "-rf", "src"])).
    for (const text of [...literals, literals.join(' ')]) {
      const r = commandRiskOf(text, depth + 1);
      if (r) return r;
    }
  }
  if (planOn()) {
    for (const m of code.matchAll(DELETES_FILE_CODE)) {
      const first = /^(?:'((?:[^'\\\n]|\\.)*)'|"((?:[^"\\\n]|\\.)*)")/.exec(code.slice((m.index ?? 0) + m[0].length));
      const literal = (first?.[1] ?? first?.[2] ?? '').replace(/\\(.)/g, '$1');
      if (literal && !literal.includes('{')) captureDeletes('code', [lit(literal)], false, false, base);
    }
    for (const m of code.matchAll(PATH_UNLINK_CODE)) {
      const literal = m[1].slice(1, -1);
      if (literal && !literal.includes('{')) captureDeletes('code', [lit(literal)], false, false, base);
    }
  }
  for (const m of code.matchAll(DELETES_TREE_CODE)) {
    const after = code.slice((m.index ?? 0) + m[0].length);
    const first = /^(?:'((?:[^'\\\n]|\\.)*)'|"((?:[^"\\\n]|\\.)*)")/.exec(after);
    // A folder named by a variable is not known to be safe.
    if (first && safeDeleteTarget(lit(first[1] ?? first[2] ?? ''), base)) continue;
    const literal = (first?.[1] ?? first?.[2] ?? '').replace(/\\(.)/g, '$1');
    if (first && literal && !literal.includes('{') && captureDeletes('code', [lit(literal)], true, false, base)) continue;
    return risk('delete-folder');
  }
  return null;
}


// ------------------------------------------------------------------------------------------------- broader cases (glob deletes, make clean, delete scripts)

/** A line that splits words with the shell's own separator (`r${IFS}m`, `rm$IFS-rf`, `$IFS$9`). */
const IFS_REF = /\$\{IFS[^}]*\}(?:\$\{?[0-9@*]\}?)?|\$IFS(?![A-Za-z0-9_])(?:\$[0-9@*])?/g;
const mentionsIfs = (text: string) => /\$\{?IFS(?![A-Za-z0-9_])/.test(text);

/** Is the folder a relative path starts in (after a `cd` to `base`) the whole machine or above the project (`cd ..` makes it '/..')? */
const badBase = (base: string): boolean => !!base && wholeMachine(base);

/**
 * `rm -f ~/*`, `rm -f /etc/*`, `rm -f ../*`: a glob that takes every file in a broad place (home, a system folder, above the project).
 * Globs inside the project (`*.log`, `dist/*`) and inside temp or build folders are routine.
 */
function broadGlobDelete(targets: Word[], base: string): boolean {
  for (const w of targets) {
    if (w.quoted || w.hasSubst) continue;
    let t = w.raw.replace(/["'\\]/g, '');
    if (!/[*?[]/.test(t)) continue;
    const pv = PWD_VARS.exec(t);
    if (pv) t = `.${t.slice(pv[0].length)}`;
    const slash = t.lastIndexOf('/');
    const whole = /^\.?\*+$/.test(t.slice(slash + 1));
    let dir = slash < 0 ? '' : t.slice(0, slash) || '/';
    if (!dir.startsWith('/') && !dir.startsWith('~') && !dir.startsWith('$')) {
      if (!base) {
        if (dir && segments(dir) === null) return true; // ../*
        continue;
      }
      dir = dir ? `${base}/${dir}` : base;
    }
    if (safeDeleteTarget(lit(dir))) continue;
    if (dir.includes('$') && !/^(?:\$HOME|\$\{HOME\})(?:\/|$)/.test(dir)) {
      if (whole) return true; // `$DIR/*`: where it is is not known
      continue;
    }
    if (whole || wholeMachine(dir)) return true;
  }
  return false;
}

const CLEAN_TARGETS = /^(?:clean|distclean|dist-clean|mrproper|maintainer-clean|realclean|veryclean|clobber|purge|wipe|nuke|clean-all|cleanall|fullclean)$/;

/** Is a folder named in `make -C dir` the whole machine, above the project, or not known? */
function dirOutside(d: string, base: string): boolean {
  const t = d.replace(/["'\\]/g, '');
  if (t.includes('$') || t.includes('`')) return true;
  if (t.startsWith('/') || t.startsWith('~')) return wholeMachine(t);
  if (base) return wholeMachine(`${base}/${t}`);
  return segments(t) === null;
}

/** `make clean` (and kin) somewhere other than the project: in another folder (`-C ..`, `-C ~`, `-C $DIR`) or after a `cd ..`. */
function makeCleanRisk(p: string, rest: Word[], base: string): boolean {
  if (!['make', 'gmake', 'gnumake', 'bmake'].includes(p)) return false;
  let dir: string | null = null;
  const goals: string[] = [];
  for (let k = 0; k < rest.length; k++) {
    const t = rest[k].raw;
    if (t === '-C' || t === '--directory' || t === '--dir') dir = rest[++k]?.raw ?? '';
    else if (/^--directory=/.test(t)) dir = t.slice(12);
    else if (/^-C./.test(t)) dir = t.slice(2);
    else if (t === '-f' || t === '--file' || t === '--makefile' || t === '-j' || t === '-I' || t === '-o' || t === '-W') k++;
    else if (!t.startsWith('-') && !t.includes('=')) goals.push(rest[k].text);
  }
  if (!goals.some((g) => CLEAN_TARGETS.test(g))) return false;
  return dir !== null ? dirOutside(dir, base) : badBase(base);
}

const DELETE_SCRIPT_NAME = /(?:^|[^a-z])(?:clean|cleanup|wipe|purge|nuke|delete|remove|destroy|prune|uninstall|reset|rm)(?:[^a-z]|$)/i;
const SCRIPT_RUNNERS = new Set([...SHELLS, 'python', 'python3', 'node', 'perl', 'ruby']);

/**
 * A script on disk whose name says it deletes (`./cleanup.sh`, `bash ~/wipe.sh`), run from outside the project or from somewhere not
 * known. A script inside the project (`./scripts/clean.sh`) is routine.
 */
function deleteScriptRisk(p: string, words: Word[], base: string): boolean {
  let script: Word | undefined;
  if (words[0].text.includes('/') && !SCRIPT_RUNNERS.has(p)) script = words[0];
  else if (SCRIPT_RUNNERS.has(p)) script = words.slice(1).find((w) => !w.text.startsWith('-') && w.text.includes('.'));
  if (!script) return false;
  const t = script.raw.replace(/["'\\]/g, '');
  if (!DELETE_SCRIPT_NAME.test(t.slice(t.lastIndexOf('/') + 1))) return false;
  if (TEMP_VARS.test(t)) return false;
  if (t.startsWith('/')) {
    const segs = segments(t);
    return !segs || !TEMP_ROOTS.some((r) => `/${segs.join('/')}/`.startsWith(r));
  }
  if (t.startsWith('~') || t.includes('$') || t.includes('`')) return true;
  return segments(t) === null || badBase(base);
}

function argvRisk(words: Word[], more: boolean, c: Command, base: string, vars: Map<string, string>, depth: number): Risk | null {
  const p = prog(words[0].text);
  const rest = words.slice(1);
  const a = rest.map((w) => w.text);
  const v = VAR_WORD.exec(words[0].text);
  // A program not written out: held in a variable, made by a substitution (`"$(echo rm)"`, backticks) or an escaped quote (`$'\x72m'`).
  if (words[0].hasVar || words[0].hasSubst || /\$['"]/.test(words[0].raw)) {
    // `$(curl https://x)`: what a download prints, run as a command.
    if (words[0].hasSubst && downloads(words[0].subst)) return risk('download-run');
    if (deleteScriptRisk(p, words, base)) return risk('delete-folder');
    // Its value when the same line set it, else every program it could plausibly be.
    const known = v ? vars.get(v[1]) : undefined;
    if (known !== undefined) return commandRiskOf([known, ...rest.map((w) => w.raw)].join(' '), depth + 1);
    // Guesses are never collected: what really runs is not known, so a copy of what a guess would delete proves nothing.
    if (collecting) collecting.suspended++;
    try {
      for (const guess of VAR_PROGRAM_GUESSES) {
        if (!rest.length) break;
        const r = wordsRisk([lit(guess), ...rest], more, c, base, vars, depth);
        if (r) return r;
      }
    } finally {
      if (collecting) collecting.suspended--;
    }
    // A program name spliced with $IFS (`rm$IFS-rf`) is a way round the check: never run unseen.
    return mentionsIfs(words[0].raw) ? risk('unreadable') : null;
  }
  if (onlyText(p, a)) return null;
  if (TEXT_PROGRAMS.has(p)) return risk('unreadable'); // rg --pre, man -P: runs a program this does not read
  // eval "$X": what a variable holds is only known when it runs (`eval "$(tool init)"` is read: its commands are checked).
  if (p === 'eval' && rest.some((w) => w.hasVar && !w.hasSubst)) return risk('unreadable');
  if (p === 'rm' && !rmTargets(rest).recursive && broadGlobDelete(rmTargets(rest).targets, base)) return risk('delete-folder');
  if (makeCleanRisk(p, rest, base) || deleteScriptRisk(p, words, base)) return risk('delete-folder');
  if (p === 'rm' || p === 'unlink' || p === 'rimraf' || p === 'del-cli') {
    const { recursive, targets } = p === 'rm' ? rmTargets(rest) : { recursive: p !== 'unlink', targets: rest.filter((w) => !w.text.startsWith('-')) };
    const captured = captureDeletes(p, targets, recursive, more, base);
    if (!captured && (p === 'rm' ? rmRisk(rest, more, base) : p !== 'unlink' && targets.some((w) => !safeDeleteTarget(w, base)))) return risk('delete-folder');
  }
  if (p === 'trash-empty') return risk('delete-folder');
  // mv: never kept a copy of (nothing is lost), but moving a whole home or system folder away is checked like deleting it, so it
  // cannot be moved somewhere a later delete counts as routine (`mv ~/Documents /tmp/x && rm -rf /tmp/x`).
  if ((p === 'mv' || p === 'move-item' || p === 'move' || p === 'mi') && planOn() && !more) {
    const srcs = rest.filter((w) => !w.text.startsWith('-'));
    const t = a.findIndex((x) => x === '-t' || x === '--target-directory' || x.startsWith('--target-directory='));
    const from = t >= 0 ? srcs.filter((w) => w !== rest[t + 1]) : srcs.slice(0, -1);
    const dest = t >= 0 ? (rest[t + 1]?.text ?? a[t].replace(/^--target-directory=/, '')) : srcs[srcs.length - 1]?.text ?? '';
    // Moved into a temp folder (or /dev/null): as good as deleted, so a copy is kept; elsewhere only checked.
    const toTemp = TEMP_DEST.test(dest);
    const b = frameBase();
    for (const w of from) if (!w.hasSubst) collecting!.plan.deletes.push({ path: w.text, raw: w.raw, quoted: w.quoted, base: b, recursive: true, via: 'mv', ...(toTemp ? {} : { checkOnly: true }) });
  }
  if (p === 'find' && a.includes('-delete')) {
    const roots: Word[] = [];
    for (let j = 0; j < rest.length && !rest[j].text.startsWith('-') && rest[j].text !== '(' && rest[j].text !== '!'; j++) roots.push(rest[j]);
    // Even a narrow one (-name '*.ts') is kept: what it takes is still gone otherwise.
    if (!captureDeletes('find', roots.length ? roots : [lit('.')], true, more, base) && findDeleteRisk(rest, base)) return risk('delete-folder');
  }
  // Other deletes and overwrites that leave nothing behind.
  if ((p === 'shred' || p === 'srm') && !rest.some((w) => w.text.startsWith('/dev/'))) {
    const targets = rest.filter((w) => !w.text.startsWith('-'));
    if (!captureDeletes(p, targets, p === 'srm' || a.some((x) => /^-[a-z]*r/i.test(x)), more, base, { overwrite: true })) return risk('delete-folder');
  }
  if (p === 'truncate' || p === 'clear-content' || p === 'clc' || p === 'set-content' || p === 'sc') {
    const valued = new Set(['-s', '--size', '-r', '--reference', '-value', '-encoding', '-filter', '-include', '-exclude']);
    const targets = rest.filter((w, k) => !w.text.startsWith('-') && !valued.has(rest[k - 1]?.text.toLowerCase() ?? ''));
    captureDeletes(p, p === 'set-content' || p === 'sc' ? targets.slice(0, 1) : targets, false, more, base, { overwrite: true });
  }
  if (p === 'cp' && rest.some((w) => w.text === '/dev/null')) {
    const targets = rest.filter((w) => !w.text.startsWith('-') && w.text !== '/dev/null');
    captureDeletes('cp', targets.slice(-1), false, more, base, { overwrite: true });
  }
  if (p === 'dd') {
    const of = rest.find((w) => w.text.startsWith('of='));
    if (of && !RAW_DEVICE.test(of.text.slice(3))) captureDeletes('dd', [{ ...of, text: of.text.slice(3), raw: of.raw.replace(/^of=/, '') }], false, more, base, { overwrite: true });
  }
  if (p === 'rsync' && a.some((x) => /^--(?:delete|del|remove-source-files)/.test(x))) {
    const pos = rest.filter((w) => !w.text.startsWith('-') && !/^[^/]*:/.test(w.text));
    const target = a.some((x) => x.startsWith('--remove-source-files')) ? pos.slice(0, -1) : pos.slice(-1);
    if (!captureDeletes('rsync', target, true, more, base)) return risk('delete-folder');
  }
  if (p === 'robocopy' && a.some((x) => /^\/(?:mir|purge|move)$/i.test(x))) {
    const pos = rest.filter((w) => !w.text.startsWith('/'));
    if (!captureDeletes('robocopy', a.some((x) => /^\/move$/i.test(x)) ? pos.slice(0, 1) : pos.slice(1, 2), true, more, base)) return risk('delete-folder');
  }
  if ((p === 'tar' || p === 'bsdtar') && a.some((x) => x === '--remove-files')) {
    if (!captureDeletes('tar', rest.filter((w) => !w.text.startsWith('-') && !/\.(?:tar|tgz|gz|bz2|xz|zst)$/.test(w.text)), true, more, base)) return risk('delete-folder');
  }
  if (p === 'zip' && a.some((x) => /^-[A-Za-z]*m/.test(x) || x === '--move')) {
    if (!captureDeletes('zip', rest.filter((w) => !w.text.startsWith('-')).slice(1), true, more, base)) return risk('delete-folder');
  }
  // at / batch run later what they are fed, with no check when it runs.
  if ((p === 'at' || p === 'batch') && !a.some((x) => x === '-l' || x === '-r' || x === '-d' || x === '-c')) return risk('unreadable');
  if (p === 'remove-item' || p === 'rd' || p === 'rmdir' || p === 'del' || p === 'erase' || p === 'ri') {
    const recursive = a.some((x) => /^[-/](?:r(?:ecurse)?|s)$/i.test(x));
    const targets = rest.filter((w) => !w.text.startsWith('-') && !/^\/[a-z]$/i.test(w.text));
    const shell = p === 'remove-item' || p === 'ri' || p === 'del' || p === 'erase' || ((p === 'rd' || p === 'rmdir') && recursive);
    // Remove-Item fed by a pipe (Get-ChildItem x | Remove-Item): what it deletes is not on its line.
    if ((p === 'remove-item' || p === 'ri') && !targets.length && c.pipeFrom) return risk('delete-folder');
    const captured = shell && captureDeletes(p, targets, recursive, more, base);
    if (!captured && (p === 'remove-item' || p === 'ri' || p === 'rd' || p === 'rmdir') && recursive && targets.some((w) => !safeDeleteTarget(w, base))) return risk('delete-folder');
  }
  if (p === 'git') {
    const g = gitRisk(rest);
    const captured = captureGit(rest, g, more);
    if (g && !captured) return g;
  }
  if (p === 'gh') {
    const g = ghRisk(rest);
    if (g) return g;
  }
  if (databaseRisk(p, rest, c)) return risk('database');
  if (clusterRisk(p, a)) return risk('cluster');
  if (infraRisk(p, a)) return risk('infra-destroy');
  if (containerRisk(p, rest)) return risk('container-prune');
  if (cloudRisk(p, a)) return risk('cloud-delete');
  if (diskRisk(p, a, c)) return risk('disk');
  if (permissionsRisk(p, a)) return risk('permissions');
  if (downloadRunRisk(p, words, c)) return risk('download-run');
  if (INTERPRETERS.has(p)) {
    for (const w of codeWords(p, words)) {
      const r = codeRisk(w.text, base, depth);
      if (r) return r;
    }
    // `python3 - <<'EOF'`, `node <<<'...'`, `echo '...' | python3`: the code it is fed.
    if (readsCodeFromInput(p, a)) {
      const fed = fedText(c);
      if (fed === null) return risk('unreadable');
      for (const text of fed) {
        const r = codeRisk(text, base, depth);
        if (r) return r;
      }
    }
  }
  // A shell fed by echo / printf / a here-document runs that text: read it as commands. Fed from anything else (a file, a decoder,
  // another program), what it runs is not known here, so it waits for a person.
  if (SHELLS.has(p) && !a.some((x) => /^-[A-Za-z]*c/.test(x))) {
    const fed = fedText(c);
    if (fed === null && readsCodeFromInput(p, a)) return risk('unreadable');
    for (const text of fed ?? []) {
      const inner = commandRiskOf(text, depth + 1);
      if (inner) return inner;
    }
  }
  return null;
}

/**
 * The text a command is fed: its here-documents and here-strings, and what is piped in from echo / printf / cat <<EOF. null when
 * something else is piped in (a file, a decoder, another program): what flows in is not known here.
 */
function fedText(c: Command): string[] | null {
  const fed: string[] = c.heredocs.map((h) => h.body);
  for (const h of c.herestrings) fed.push(h.text);
  const from = c.pipeFrom;
  if (from) {
    const fp = prog(from.words[0]?.text ?? '');
    if (fp === 'echo' || fp === 'printf') fed.push(from.words.slice(1).map((w) => w.text).filter((x) => !/^-[neE]+$/.test(x)).join(' '));
    else if (fp === 'cat' && from.words.length === 1 && from.heredocs.length) for (const h of from.heredocs) fed.push(h.body);
    else return null;
    if (from.words.some((w) => w.hasSubst || w.hasVar)) return null; // echo "$(...)" | sh: not plain text
  }
  return fed;
}

/** The risk of the commands these words run, wrappers taken off (`sudo bash -c "..."`). */
function wordsRisk(all: Word[], outerMore: boolean, c: Command, base: string, vars: Map<string, string>, depth: number): Risk | null {
  for (const { words, more, script } of unwrap(all, 0, outerMore)) {
    if (script !== undefined) {
      const r = commandRiskOf(script, depth + 1);
      if (r) return r;
      continue;
    }
    if (!words.length) continue;
    const r = argvRisk(words, more, c, base, vars, depth);
    if (r) return r;
  }
  return null;
}

function commandRisk(c: Command, base: string, vars: Map<string, string>, depth: number): Risk | null {
  const r = wordsRisk(c.words, false, c, base, vars, depth);
  if (r) return r;
  // `> file`, `>| file`, `&> file`: what was in it is gone. A copy is kept when it exists (not /dev/..., not appends, not 2>).
  if (planOn()) {
    for (const rd of c.redirects) {
      if (!rd.target || !/^(?:>|>\||&>|1>)$/.test(rd.op) || /^\/dev\//.test(rd.target.text) || rd.target.hasSubst || /^&/.test(rd.target.text)) continue;
      captureDeletes('>', [rd.target], false, false, base, { overwrite: true });
    }
  }
  // A redirect onto a raw disk from any program (echo x > /dev/sda).
  if (c.redirects.some((r) => (r.op.endsWith('>') || r.op.endsWith('>>') || r.op.endsWith('>|')) && r.target && RAW_DEVICE.test(r.target.text))) return risk('disk');
  return null;
}

/** Commands inside commands deeper than this are not followed: such a line waits for a person. */
const MAX_NESTING = 6;

function commandRiskOf(command: string, depth: number): Risk | null {
  if (depth > MAX_NESTING) return risk('unreadable');
  const parsed = parseShell(command, depth);
  if (parsed.tooDeep) return risk('unreadable');
  // `cd /tmp/x && rm -rf y`: a relative path after a cd to a known folder is read from there.
  let base = '';
  const destroyPlans = new Set<string>();
  // `X="rm -rf"; $X src`: what a variable was set to earlier on the line (unknown once set from something not plain).
  const vars = new Map<string, string>();
  const frame: Frame = { base: frameBase() };
  collecting?.frames.push(frame);
  try {
    for (const c of parsed.commands) {
      const r = commandRisk(c, base, vars, depth) ?? destroyPlanApplied(c, destroyPlans);
      if (r) return r;
      rememberAssignments(c, vars);
      if (!c.nested && c.words.length === 2 && prog(c.words[0].text) === 'cd') base = cdTarget(c.words[1], base);
      const cp = prog(c.words[0]?.text ?? '');
      if (cp === 'cd' || cp === 'pushd' || cp === 'popd' || cp === 'set-location' || cp === 'sl' || cp === 'chdir') {
        // In a subshell, group or substitution a cd may or may not last: what comes after it starts somewhere not known.
        frame.base = !parsed.top.includes(c) || !parsed.simple || cp === 'popd' ? null : planCd(c.words, frame.base);
      }
    }
    return null;
  } finally {
    if (collecting) collecting.frames.pop();
  }
}

/**
 * `terraform plan -destroy -out=p && terraform apply p`: a plan file made to destroy, then applied on the same line. The plan alone
 * changes nothing; applying it tears everything down.
 */
function destroyPlanApplied(c: Command, plans: Set<string>): Risk | null {
  for (const { words } of unwrap(c.words, 0)) {
    const p = prog(words[0]?.text ?? '');
    if (!['terraform', 'tofu', 'terragrunt'].includes(p)) continue;
    const a = words.slice(1).map((w) => w.text);
    const pos = a.filter((x) => !x.startsWith('-'));
    if (pos[0] === 'plan' && a.some((x) => x === '-destroy' || x === '--destroy')) {
      const k = a.findIndex((x) => x === '-out' || x === '--out');
      const out = k >= 0 ? a[k + 1] : a.find((x) => /^--?out=/.test(x))?.replace(/^--?out=/, '');
      if (out) plans.add(out);
    }
    if (pos[0] === 'apply' && pos.slice(1).some((x) => plans.has(x))) return risk('infra-destroy');
  }
  return null;
}

/** `X=value` / `export X=value` alone on a command: remembered for a later `$X` on the same line. */
function rememberAssignments(c: Command, vars: Map<string, string>): void {
  const words = c.words[0]?.text === 'export' || c.words[0]?.text === 'declare' || c.words[0]?.text === 'local' ? c.words.slice(1) : c.words;
  if (!words.length || !words.every((w) => /^[A-Za-z_][A-Za-z0-9_]*=/.test(w.text))) return;
  for (const w of words) {
    const k = w.text.indexOf('=');
    const name = w.text.slice(0, k);
    if (w.hasVar || w.hasSubst) vars.delete(name);
    else vars.set(name, w.text.slice(k + 1));
  }
}

/** Where `cd <word>` goes, as far as it is known ('' when not: a relative path is then read as inside the project). */
function cdTarget(to: Word, base: string): string {
  const t = to.raw.replace(/["']/g, '');
  const tv = TEMP_VARS.exec(t);
  if (tv) return `/tmp/x${t.slice(tv[0].length)}`;
  if (t.includes('$') || t.includes('`') || t.startsWith('~')) return '';
  if (t.startsWith('/')) return t;
  // `cd ..` leaves the project: what follows works on some other folder ('/..' is never routine).
  if (!base) return segments(t) === null ? '/..' : '';
  return `${base}/${t}`;
}

/** Why this shell command line needs a person's OK before it runs, or null when it may run. */
export function riskyCommand(command: string): Risk | null {
  if (typeof command !== 'string' || !command.trim()) return null;
  if (command.length > MAX_RISK_CHARS) return risk('unreadable');
  // A line continuation is joined first, as bash does.
  const text = command.replace(/\\\r?\n/g, '');
  const r = commandRiskOf(text, 0);
  if (r || !mentionsIfs(text)) return r;
  // `rm${IFS}-rf${IFS}src`: read again with each $IFS as the space it stands for.
  return commandRiskOf(text.replace(IFS_REF, ' '), 0);
}

/** One word for the shell, exactly as given. */
export function shellQuote(word: string): string {
  return /^[A-Za-z0-9_@%+=:,./-]+$/.test(word) ? word : `'${word.replace(/'/g, `'\\''`)}'`;
}

/** The fields of a tool call that hold a command it runs (Bash, Monitor, PowerShell, an MCP shell tool...). */
const COMMAND_FIELDS = ['command', 'cmd', 'script'] as const;

/** Why this tool call needs a person's OK, or null. Only commands count: a file being written is not a command being run. */
export function riskyToolCall(toolName: string, input: unknown): (Risk & { command: string }) | null {
  const fields = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  for (const key of COMMAND_FIELDS) {
    const value = fields[key];
    // An argv list (Codex's exec) is one command whose words are exactly these: quoted so the reader keeps them whole.
    const command = Array.isArray(value) ? value.map((x) => shellQuote(String(x))).join(' ') : value;
    if (typeof command !== 'string') continue;
    const r = riskyCommand(command);
    if (r) return { ...r, command };
  }
  return null;
}

/**
 * What an app sends with its Approve of a risky-command hold (permission_response.message). The agent runs a held command only on an
 * allow that carries it: an answer from something that cannot show the hold (an older phone's Autonomous auto-answer, the hub's
 * own low-risk auto-allow) never carries it, so it is taken as a no.
 */
export const HOLD_APPROVED_NOTE = 'escanor:risky-command-approved';

/** The words a person reads on the phone: what will run, why it is risky, and that it waits for them. */
export function holdDescription(r: Risk): string {
  return `Escanor paused this command until you say yes. ${r.why} Approve to run it, or Refuse to stop it.`;
}
