import data from './jarvisBrain.data.json' with { type: 'json' };

/**
 * The Jarvis brain: ONE intent router for the phone, the desktop app and the laptop agent. A sentence in (typed, or heard and
 * transcribed), an intent out. Pure text in, a decision out: no network, no model, no clock, so every phrasing is a test case
 * (test/jarvis-brain-cases.json) that the phone's Dart port runs too.
 *
 *  - `device`: one thing a computer can do with no model turn (open a page or an app, YouTube, media keys, volume, lock, wake, keep
 *    awake, show a page, look at the screen, unlock). It goes through the command bus (`POST /vms/:id/device`) or, on the computer
 *    itself, straight to the same checked programs (computerControl.ts).
 *  - `send_mail`: an email in the person's name. Never a direct command: it is a short chat turn on the computer, and the mail rules
 *    hold it for a yes.
 *  - `sdlc`: the software work Escanor already does: run the tests, open the preview of a fix, show the failing check, approve (or
 *    refuse) the deploy plan, say what Escanor is doing. They route to the existing runs, previews and Guardian plans.
 *  - `chat`: everything else. A short chat turn on the right machine (or the Assistant).
 *  - `custom`: what a rule another part of Jarvis registered answers (see registerJarvisRule).
 *
 * It understands polite English ("could you please ... for me"), Hinglish ("laptop pe tests chalao", "awaaz badhao") and the
 * common Hindi words in Devanagari. The words live in jarvisBrain.data.json; the phone's copy is generated from it
 * (scripts/gen-jarvis-brain.mjs) and a test fails when the two drift apart.
 *
 * Extension points: other Jarvis areas (wake and fingerprint, mail and messages, screen help, the device mesh, the phone as a
 * node) add a rule with registerJarvisRule({id, owner, priority, match}). Higher priority is asked first; the built-in rules are
 * stop 1000, sdlc 300, screen 250, device 200. A rule returns an intent or null (not mine). Nothing else in this file needs to change.
 */

export type DeviceAction =
  | 'open_url'
  | 'open_app'
  | 'play_youtube'
  | 'media'
  | 'volume'
  | 'lock_screen'
  | 'compose_mail'
  | 'show'
  | 'wake_screen'
  | 'keep_awake'
  | 'unlock_screen'
  | 'screenshot';

export type SdlcOp = 'run_tests' | 'open_preview' | 'show_failing_check' | 'approve_plan' | 'reject_plan' | 'status';

export type JarvisLang = 'en' | 'hi';

type Common = {
  /** 'computer' when the person named one ("on my laptop", "laptop pe"); null otherwise. */
  target: 'computer' | null;
  /** 'hi' for Hinglish or Devanagari. Replies stay in plain English. */
  lang: JarvisLang;
};

export type JarvisIntent =
  | { kind: 'empty' }
  | { kind: 'stop' }
  | ({ kind: 'device'; action: DeviceAction; args: Record<string, unknown>; say: string; fingerprint?: boolean } & Common)
  | ({ kind: 'send_mail'; args: Record<string, unknown>; say: string } & Common)
  | ({ kind: 'sdlc'; op: SdlcOp; say: string; args: { of?: 'fix' | 'latest'; implicit?: boolean }; fingerprint: boolean } & Common)
  | ({ kind: 'screen'; screen: string; say: string } & Common)
  | ({ kind: 'chat'; text: string } & Common)
  | ({ kind: 'custom'; owner: string; op: string; args: Record<string, unknown>; say: string; fingerprint?: boolean } & Common);

/** What a rule returns: an intent without the two fields the router fills in. */
export type RuleResult =
  | { kind: 'device'; action: DeviceAction; args: Record<string, unknown>; say: string; fingerprint?: boolean }
  | { kind: 'send_mail'; args: Record<string, unknown>; say: string }
  | { kind: 'screen'; screen: string; say: string }
  | { kind: 'sdlc'; op: SdlcOp; say: string; args: { of?: 'fix' | 'latest'; implicit?: boolean }; fingerprint: boolean }
  | { kind: 'custom'; owner: string; op: string; args: Record<string, unknown>; say: string; fingerprint?: boolean };

/** What the app knows when the person speaks. Free-form for the rules that need more (pending approvals, which devices exist). */
export type JarvisContext = { hasComputer?: boolean; [key: string]: unknown };

export type RuleInput = {
  /** The words as said (wake phrase removed, case kept). */
  heard: string;
  /** The part for the computer: the words without "on my laptop" (Hinglish already put into English). */
  said: string;
  /** The whole sentence, lowercase, without punctuation (Devanagari put into Latin Hinglish): for matching words. */
  plain: string;
  target: 'computer' | null;
  lang: JarvisLang;
  ctx: JarvisContext;
};

export type JarvisRule = {
  /** Unique: registering the same id again replaces the rule. */
  id: string;
  /** Which part of Jarvis it belongs to ("mail", "screen", "mesh", ...). */
  owner: string;
  /** Higher is asked first. Built-in: stop 1000, sdlc 300, device 200. */
  priority: number;
  match: (input: RuleInput) => RuleResult | null;
};

// ------------------------------------------------------------------------------------------------ the words

type Phrases = { op: SdlcOp; all?: string[][]; any?: string[]; none?: string[]; maxWords?: number; args?: { implicit?: boolean } };
type Data = {
  computerNouns: string[];
  stopSentences: string[];
  devanagari: Record<string, string>;
  screens: Record<string, string[]>;
  hinglish: { markers: string[]; address: string; addressOf: string; rules: { re: string; to: string }[] };
  sdlc: Phrases[];
};
const words = data as unknown as Data;

const DEVANAGARI = /[ऀ-ॿ]/;

/** "what's" -> "what is", apostrophes gone, punctuation gone, one space between words. Latin and Devanagari letters and digits stay. */
export function plain(text: string): string {
  return text
    .toLowerCase()
    .replace(/[‘’`]/g, "'")
    .replace(/\b(what|how|where|who|that|it|there|here)'s\b/g, '$1 is')
    .replace(/'/g, '')
    .replace(/[^a-z0-9ऀ-ॿ%]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Speech recognisers have never heard "Escanor" and spell it as they like ("escaner", "es canor", "ex canor"). */
const NAME_HEARD_AS = /\be[sx]\s?c?\s?a\s?n{1,2}\s?[eo]r?\b/gi;
export const canonicalizeName = (t: string): string => t.replace(NAME_HEARD_AS, 'escanor');

const WAKE = /^\s*(?:hey|ok|okay|hi|yo|hello)\s+escanor\b[\s,.:;!?-]*/i;
/** Drop a leading "hey escanor" (or ok/hi/yo/hello), whatever punctuation follows. */
export const stripWake = (raw: string): string => canonicalizeName(raw).replace(WAKE, '').trim();

const padded = (s: string): string => ` ${s} `;
const has = (text: string, phrase: string): boolean => text.includes(padded(plain(phrase)));

/** Devanagari words put into Latin Hinglish so one set of rules reads both ("टेस्ट चलाओ" -> "test chalao"). */
function mapDevanagari(text: string): string {
  if (!DEVANAGARI.test(text)) return text;
  return text
    .split(/\s+/)
    .map((tok) => {
      const bare = tok.replace(/[।,.!?]+$/g, '');
      const tail = tok.slice(bare.length);
      return (words.devanagari[bare] ?? bare) + tail;
    })
    .join(' ');
}

/** Hinglish: a distinctive Hinglish word is in the sentence (or it was written in Devanagari). */
function isHinglish(original: string, mapped: string): boolean {
  if (DEVANAGARI.test(original)) return true;
  const p = padded(plain(mapped));
  return words.hinglish.markers.some((m) => p.includes(padded(plain(m))));
}

const COMPUTER_NOUN = `(?:${words.computerNouns.join('|')})`;

/** Hinglish sentence -> the English sentence the device grammar reads, and the computer if one was named ("laptop pe"). */
export function hinglishToEnglish(text: string): { text: string; computer: string | null } {
  // Lowercase, no punctuation except what a web address or a name needs (a dot, a hyphen, a slash).
  let t = mapDevanagari(text)
    .toLowerCase()
    .replace(/[\u2018\u2019`']/g, '')
    .replace(/[^a-z0-9\u0900-\u097f%.\-/:@_]+/g, ' ')
    .replace(/(?<=\s)[.\-]+(?=\s|$)|^[.\-]+(?=\s)|(?<=\S)[.]+(?=\s|$)/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  t = t.replace(/\b(?:meri|mera|mere|apni|apna|apne) /g, '');
  let computer: string | null = null;
  const of = new RegExp(words.hinglish.addressOf).exec(t);
  if (of) {
    t = t.replace(new RegExp(words.hinglish.addressOf), `my ${of[1]} ${of[2]}`).trim();
  }
  const at = new RegExp(words.hinglish.address).exec(t);
  if (at) {
    computer = at[1]!;
    t = t.replace(new RegExp(words.hinglish.address), ' ').replace(/\s+/g, ' ').trim();
  }
  // "laptop lock karo": a computer named first.
  const lead = new RegExp(`^(${COMPUTER_NOUN})(?: ko)? (?=\\S)`).exec(t);
  if (lead && !computer) {
    computer = lead[1]!;
    t = t.slice(lead[0].length);
  }
  // "arijit singh ke gaane chalao": the "ke gaane" is only a pointer to the music.
  t = t.replace(/\b(?:ke|ka|ki) (?:gaane|gaana|gana|songs?|music)\b/g, ' ').replace(/\s+/g, ' ').trim();
  for (const r of words.hinglish.rules) {
    if (!new RegExp(r.re).test(t)) continue;
    t = t.replace(new RegExp(r.re, 'g'), (...m: unknown[]) => r.to.replace(/\$(\d)/g, (_x, n: string) => (typeof m[Number(n)] === 'string' ? (m[Number(n)] as string) : ''))).replace(/\s+/g, ' ').trim();
    // A rule written as a whole sentence (^...$) is the one that read the verb: it ends the reading. The others only tidy words.
    if (r.re.startsWith('^')) break;
  }
  t = t.replace(/\b(?:gaana|gaane|gana)\b/g, 'music');
  return { text: t, computer };
}

// ------------------------------------------------------------------------------------------------ the computer named

const noun = COMPUTER_NOUN;

/** Sentences that are about the computer as a whole, with no "on my laptop" in front. */
const WHOLE = new RegExp(
  `^(?:(?:show me|show|let me see|see|take a look at) (?:my|the) ${noun}(?: screen)?|(?:show me|let me see|see) (?:my|the) screen` +
    `|what(?:'s| is) on (?:my|the) ${noun}(?: screen)?|(?:unlock|wake(?: up)?) (?:my|the) ${noun}` +
    `|(?:put|show|display|cast|throw) .+ on (?:the|my) (?:big screen|tv))$`,
  'i',
);

const TAIL = '(?: (?:please|now|right now|for me|thanks|thank you))*';

/** The words with "on my laptop" taken out, and whether a computer was named. */
export function splitComputer(said: string): { target: 'computer' | null; rest: string } {
  const s = said.trim().replace(/[.!?]+$/, '').replace(/\s+/g, ' ');
  if (WHOLE.test(s)) return { target: 'computer', rest: s };
  const a =
    new RegExp(`^(?:on|in|at|from|over on) (?:my|the|this) ${noun}[, ]+(.+)$`, 'i').exec(s) ??
    new RegExp(`^(?:tell|ask|have|get|make) (?:my|the) ${noun}(?: to)? (.+)$`, 'i').exec(s) ??
    new RegExp(`^(.+?),? (?:on|in|at|from) (?:my|the|this) ${noun}${TAIL}$`, 'i').exec(s) ??
    new RegExp(`^(?:my |the )?${noun}[,:] (.+)$`, 'i').exec(s);
  return a ? { target: 'computer', rest: a[1]!.trim() } : { target: null, rest: s };
}

// ------------------------------------------------------------------------------------------------ what a computer can do

export type DeviceIntent = { action: DeviceAction | 'send_mail'; args: Record<string, unknown>; say: string; fingerprint?: boolean };

const clean = (t: string): string => t.toLowerCase().replace(/[.!?]+$/, '').replace(/\s+/g, ' ').trim();

const EMAIL = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
/** "ana at example dot com" -> "ana@example.com": a speech recogniser writes the words. */
export const spokenEmail = (t: string): string => t.trim().replace(/\s+at\s+/g, '@').replace(/\s+dot\s+/g, '.').replace(/ /g, '');

const MAIL_WORDS = '(?:my )?(?:mail|email|e-mail|gmail|inbox)';
const GMAIL_INBOX = 'https://mail.google.com/mail/';
const POLITE = /^(?:(?:please|kindly|just|hey|so|okay|ok|can you|could you|would you|will you|can u|go ahead and|i want you to|i need you to|i would like you to|i want to|i would like to|i'd like to|i wanna|let's|lets) )+/;
const POLITE_END = /(?: (?:please|now|right now|for me|thanks|thank you|quickly|real quick))+$/;

const orig = (heard: string, lowered: string): string => {
  const i = heard.toLowerCase().indexOf(lowered);
  return i < 0 ? lowered : heard.slice(i, i + lowered.length);
};

/** What the computer is asked to do, or null when the sentence is not one of the everyday actions. */
export function parseDevice(raw: string): DeviceIntent | null {
  const heard = raw.trim().replace(/[.!?]+$/, '');
  let t = clean(heard);
  for (let again = true; again; ) {
    const before = t;
    t = t.replace(POLITE, '').replace(POLITE_END, '').trim();
    again = t !== before;
  }
  if (!t) return null;

  const media: [RegExp, [string, string]][] = [
    [/^(?:pause|pause (?:it|the music|music|the video|the song|playback|this))$/, ['pause', 'Pausing what is playing.']],
    [/^(?:stop|stop (?:it|the music|music|the video|the song|playback|this))$/, ['stop', 'Stopping what is playing.']],
    [/^(?:play|play it|resume|continue|unpause|resume (?:it|the music|music|playback|the song|the video)|play (?:it|the music|music) again)$/, ['play', 'Playing.']],
    [/^(?:next|skip|skip (?:it|this|this song|this one|the song)|(?:play |go to )?(?:the )?next (?:song|track|video|one))$/, ['next', 'Skipping to the next one.']],
    [/^(?:previous|back|go back|(?:play |go to )?(?:the )?(?:previous|last) (?:song|track|video|one))$/, ['previous', 'Going back to the previous one.']],
  ];
  for (const [re, [op, say]] of media) if (re.test(t)) return { action: 'media', args: { op }, say };
  // "play music" is the play key, not a search for the word music.
  if (/^(?:play|put on|start|resume)(?: (?:some|the|my|a))? (?:music|songs?|song|tunes|something|anything)$/.test(t)) return { action: 'media', args: { op: 'play' }, say: 'Playing.' };

  const volume =
    /^(?:turn |make )?(?:the )?(?:volume|sound) (up|down|higher|lower)$|^(?:turn|make) (?:it )?(up|down)$|^(?:make it )?(louder|quieter|softer)$|^(raise|lower|increase|decrease|reduce) the (?:volume|sound)$/.exec(t);
  if (volume) {
    const w = volume[1] ?? volume[2] ?? volume[3] ?? volume[4]!;
    const up = ['up', 'higher', 'louder', 'raise', 'increase'].includes(w);
    return { action: 'volume', args: { op: up ? 'up' : 'down' }, say: up ? 'Turning the volume up.' : 'Turning the volume down.' };
  }
  const level = /^(?:set |turn |put )?(?:the )?(?:volume|sound) (?:to |at )?(\d{1,3})(?: ?%| percent)?$/.exec(t);
  if (level && Number(level[1]) <= 100) return { action: 'volume', args: { op: 'set', level: Number(level[1]) }, say: `Setting the volume to ${level[1]}%.` };
  if (/^(?:mute|mute (?:it|the sound|sound|the volume))$/.test(t)) return { action: 'volume', args: { op: 'mute' }, say: 'Muting the sound.' };
  if (/^(?:unmute|unmute (?:it|the sound|sound))$/.test(t)) return { action: 'volume', args: { op: 'unmute' }, say: 'Turning the sound back on.' };

  if (new RegExp(`^lock(?: it| the screen| the computer| the laptop| my (?:screen|computer|laptop|pc|mac))?$`).test(t)) {
    return { action: 'lock_screen', args: {}, say: 'Locking the screen.' };
  }

  // Look at the screen, unlock it, wake it, keep it awake, put a page on it.
  if (new RegExp(`^(?:show me|show|let me see|see|take a look at) (?:my |the )(?:${noun} )?screen$|^(?:show me|show|let me see|see|take a look at) (?:my|the) ${noun}$|^what(?:'s| is) on (?:my |the )?(?:${noun} )?screen$|^what(?:'s| is) on (?:my|the) ${noun}$`).test(t)) {
    return { action: 'screenshot', args: {}, say: 'Asking to see the screen. Your fingerprint is needed first.', fingerprint: true };
  }
  if (new RegExp(`^unlock(?: it| the screen| the ${noun}| my (?:screen|${noun}))?$`).test(t)) {
    return { action: 'unlock_screen', args: {}, say: 'Unlocking the screen. Your fingerprint is needed first.', fingerprint: true };
  }
  if (new RegExp(`^wake(?: up)?(?: the| my)?(?: screen| display| ${noun})?$|^turn on the screen$`).test(t)) {
    return { action: 'wake_screen', args: {}, say: 'Waking the screen.' };
  }
  const awake = new RegExp(`^keep (?:the |my |it )?(?:(?:screen|display|${noun}) )?(?:on|awake)(?: for (?:(\\d{1,4})|an?|one) ?(minutes?|mins?|hours?))?$`).exec(t);
  if (awake) {
    const unit = awake[2];
    const n = awake[1] == null ? 1 : Number(awake[1]);
    const minutes = unit == null ? 30 : Math.min(240, Math.max(1, unit.startsWith('h') ? n * 60 : n));
    return { action: 'keep_awake', args: { minutes }, say: `Keeping the screen awake for ${minutes} minutes.` };
  }
  const shown = new RegExp(`^(?:show|put|display|bring up|throw|cast)(?: me)? (.+?)(?: (?:on|onto|to) (?:the |my )?(?:big screen|screen|tv|${noun}))?(?: for (\\d{1,4}) (minutes?|mins?|hours?))?$`).exec(t);
  if (shown) {
    const target = shown[1]!.trim();
    let url: string | null = null;
    const given = /https?:\/\/\S+/i.exec(heard)?.[0];
    if (given && target.startsWith('http')) url = given;
    else if (/^(?:[a-z0-9-]+\.)+[a-z]{2,}(?:\/\S*)?$/.test(target.replace(/\s+dot\s+/g, '.'))) url = `https://${target.replace(/\s+dot\s+/g, '.')}`;
    else if (/^[a-z0-9-]{2,30}$/.test(target) && !['it', 'me', 'this', 'that', 'time', 'mail', 'email', 'screen'].includes(target)) {
      url = target === 'youtube' ? 'https://www.youtube.com/' : `https://${target}.com`;
    }
    if (url) {
      const unit = shown[3];
      const minutes = unit == null ? null : Math.min(240, Math.max(1, unit.startsWith('h') ? Number(shown[2]) * 60 : Number(shown[2])));
      let host = '';
      try {
        host = new URL(url).hostname;
      } catch {
        host = '';
      }
      return { action: 'show', args: { url, ...(minutes != null ? { minutes } : {}) }, say: host ? `Putting ${host} on the screen.` : 'Putting that page on the screen.' };
    }
  }

  // YouTube: "play lo-fi on youtube", "play lo-fi", "youtube lo-fi", "search youtube for lo-fi", or a link.
  const link = /(https?:\/\/(?:www\.|m\.)?(?:youtube\.com|youtu\.be)\/\S+)/i.exec(heard);
  if (link && /^(?:play|open|put on|watch)\b/.test(t)) return { action: 'play_youtube', args: { url: link[1] }, say: 'Playing that video on YouTube.' };
  const yt =
    /^(?:play|put on|watch|listen to) (.+?) (?:on|in|from) (?:youtube|you tube)$/.exec(t) ??
    /^(?:search )?(?:youtube|you tube)(?: for)? (.+)$/.exec(t) ??
    /^(?:play|put on|listen to) (?:some )?(.+)$/.exec(t);
  if (yt) {
    const q = yt[1]!.trim();
    if (q && q !== 'youtube') return { action: 'play_youtube', args: { query: q }, say: `Opening YouTube for ${q}.` };
  }

  // Mail: open the inbox, write a new one (opened for the person to send), or send one (through their connected mail, held).
  if (new RegExp(`^(?:open|check|show|go to) ${MAIL_WORDS}$`).test(t)) return { action: 'open_url', args: { url: GMAIL_INBOX }, say: 'Opening your mail.' };
  const send = /^(?:send|reply with)(?: an?)? (?:email|mail|e-mail|message) to (.+?)(?: (?:about|with subject|subject) (.+?))?(?: (?:saying|that says|to say|telling (?:them|him|her)) (.+))?$/.exec(t);
  if (send) {
    const to = spokenEmail(send[1]!);
    const args: Record<string, unknown> = { to, ...(send[2] ? { subject: orig(heard, send[2]) } : {}), ...(send[3] ? { body: orig(heard, send[3]) } : {}) };
    return { action: 'send_mail', args, say: `I will write it to ${to}. Before it is sent, your phone asks you to approve it.` };
  }
  const compose = /^(?:write|compose|draft|start|open)(?: an?| a new)? (?:new )?(?:email|mail|e-mail)(?: to (.+?))?(?: (?:about|with subject|subject) (.+?))?(?: (?:saying|that says) (.+))?$/.exec(t);
  if (compose) {
    const to = compose[1] ? spokenEmail(compose[1]) : null;
    const args: Record<string, unknown> = {
      ...(to && EMAIL.test(to) ? { to } : {}),
      ...(compose[2] ? { subject: orig(heard, compose[2]) } : {}),
      ...(compose[3] ? { body: orig(heard, compose[3]) } : {}),
    };
    return { action: 'compose_mail', args, say: `Opening a new email${args.to ? ` to ${args.to}` : ''}. You press Send.` };
  }

  // A web page or an app.
  const site = new RegExp(`^(?:open|go to|visit)(?: the)? ((?:[a-z0-9-]+\\.)+[a-z]{2,}(?:\\/\\S*)?)$`).exec(t.replace(/\s+dot\s+/g, '.'));
  if (site) return { action: 'open_url', args: { url: `https://${site[1]}` }, say: `Opening ${site[1]}.` };
  if (/^(?:open|go to) (?:the )?(?:youtube|you tube)$/.test(t)) return { action: 'open_url', args: { url: 'https://www.youtube.com/' }, say: 'Opening YouTube.' };
  const app = /^(?:open|launch|start)(?: the| my)? ([a-z0-9][a-z0-9 ._+-]{0,40}?)(?: app)?$/.exec(t);
  if (app && !/\b(?:file|folder|project|repo|terminal session|preview|tests?|dashboard)s?\b/.test(app[1]!)) {
    const name = app[1]!.trim();
    return { action: 'open_app', args: { app: name }, say: `Opening ${name}.` };
  }
  return null;
}

// ------------------------------------------------------------------------------------------------ the app's own screens

const SCREEN_WORDS = Object.entries(words.screens).flatMap(([screen, names]) => names.map((n) => [n, screen] as const));

/** "open settings", "go to the editor": a screen of the Escanor app, not an app on the computer. */
export function parseScreen(raw: string): { screen: string; say: string } | null {
  let t = clean(raw.trim());
  for (let again = true; again; ) {
    const before = t;
    t = t.replace(POLITE, '').replace(POLITE_END, '').trim();
    again = t !== before;
  }
  const m = /^(?:open|go to|show|take me to|switch to|bring up)(?: me)?(?: the| my)? (.+?)(?: page| screen| tab| section)?$/.exec(t);
  if (!m) return null;
  const hit = SCREEN_WORDS.find(([n]) => n === m[1]);
  return hit ? { screen: hit[1], say: `Opening ${hit[1]}.` } : null;
}

// ------------------------------------------------------------------------------------------------ the software work

const SDLC_SAY: Record<SdlcOp, string> = {
  run_tests: 'Running the tests.',
  open_preview: 'Opening the preview of the fix.',
  show_failing_check: 'Looking for the failing check.',
  approve_plan: 'Looking at the plan that waits for you. Your fingerprint is needed to approve it.',
  reject_plan: 'Looking at the plan that waits for you.',
  status: 'Checking what Escanor is doing.',
};

const PHRASES = words.sdlc.map((r) => ({
  ...r,
  allN: r.all?.map((g) => g.map(plain)),
  anyN: r.any?.map(plain),
  noneN: r.none?.map(plain),
}));

/** Which software-work request a sentence is, or null. `text` is the lowercase, punctuation-free sentence. */
export function matchSdlc(text: string): { op: SdlcOp; args: { of?: 'fix' | 'latest'; implicit?: boolean } } | null {
  const p = padded(text);
  const n = text.split(' ').filter(Boolean).length;
  for (const r of PHRASES) {
    if (r.maxWords && n > r.maxWords) continue;
    if (r.anyN && !r.anyN.some((w) => p.includes(padded(w)))) continue;
    if (r.allN && !r.allN.every((g) => g.some((w) => p.includes(padded(w))))) continue;
    if (!r.anyN && !r.allN) continue;
    if (r.noneN?.some((w) => p.includes(padded(w)))) continue;
    const args: { of?: 'fix' | 'latest'; implicit?: boolean } = { ...(r.args ?? {}) };
    if (r.op === 'open_preview') args.of = /\b(?:fix|fixes|fixed|theek|patch)\b/.test(text) ? 'fix' : 'latest';
    return { op: r.op, args };
  }
  return null;
}

// ------------------------------------------------------------------------------------------------ the router

const builtIn: JarvisRule[] = [
  {
    id: 'sdlc',
    owner: 'sdlc',
    priority: 300,
    match: (i) => {
      const m = matchSdlc(i.plain);
      return m ? { kind: 'sdlc', op: m.op, say: SDLC_SAY[m.op], args: m.args, fingerprint: m.op === 'approve_plan' } : null;
    },
  },
  {
    id: 'screen',
    owner: 'screen',
    priority: 250,
    match: (i) => {
      const sc = parseScreen(i.said);
      return sc ? { kind: 'screen', screen: sc.screen, say: sc.say } : null;
    },
  },
  {
    id: 'device',
    owner: 'device',
    priority: 200,
    match: (i) => {
      const d = parseDevice(i.said);
      if (!d) return null;
      if (d.action === 'send_mail') return { kind: 'send_mail', args: d.args, say: d.say };
      return { kind: 'device', action: d.action, args: d.args, say: d.say, ...(d.fingerprint ? { fingerprint: true } : {}) };
    },
  },
];

const extra = new Map<string, JarvisRule>();

/** Add (or replace, by id) a rule. Higher priority is asked first. */
export function registerJarvisRule(rule: JarvisRule): void {
  if (!rule.id || typeof rule.match !== 'function') throw new Error('A Jarvis rule needs an id and a match function.');
  if (builtIn.some((b) => b.id === rule.id)) throw new Error(`"${rule.id}" is a built-in rule.`);
  extra.set(rule.id, rule);
}

export function unregisterJarvisRule(id: string): void {
  extra.delete(id);
}

/** The rules in the order they are asked (for tests and for the docs). */
export function jarvisRules(): { id: string; owner: string; priority: number }[] {
  return [...builtIn, ...extra.values()].sort((a, b) => b.priority - a.priority).map(({ id, owner, priority }) => ({ id, owner, priority }));
}

const STOP = new Set(words.stopSentences.map(plain));

/** What a sentence means. Never throws: a rule that fails is skipped. */
export function routeJarvis(raw: string, ctx: JarvisContext = {}): JarvisIntent {
  const heard = stripWake(typeof raw === 'string' ? raw : '');
  if (!heard) return { kind: 'empty' };
  if (STOP.has(plain(heard))) return { kind: 'stop' };

  const mapped = mapDevanagari(heard);
  const lang: JarvisLang = isHinglish(heard, mapped) ? 'hi' : 'en';
  let target: 'computer' | null;
  let said: string;
  let plainText: string;
  if (lang === 'hi') {
    const h = hinglishToEnglish(mapped);
    plainText = plain(mapped);
    const s = splitComputer(h.computer ? `on my ${h.computer} ${h.text}` : h.text);
    target = s.target ?? (new RegExp(words.hinglish.address).test(plainText) ? 'computer' : null);
    said = s.rest;
  } else {
    const s = splitComputer(heard);
    target = s.target;
    said = s.rest;
    plainText = plain(heard);
  }

  const input: RuleInput = { heard, said, plain: plainText, target, lang, ctx };
  const rules = [...builtIn, ...extra.values()].sort((a, b) => b.priority - a.priority);
  for (const rule of rules) {
    let out: RuleResult | null = null;
    try {
      out = rule.match(input);
    } catch {
      out = null;
    }
    if (out) return { ...out, target, lang } as JarvisIntent;
  }
  return { kind: 'chat', text: lang === 'hi' ? heard : said, target, lang };
}
