/**
 * Escanor's safety layer for AI work on a computer: what to do with one tool call, balancing three things (the product's promise):
 * the AI keeps doing its work, the person is not asked to approve things, and nothing important is ever lost.
 *
 *   allow   most calls: reading, building, editing, deleting build/temp folders.
 *   backup  a delete or a git command that throws work away: Escanor keeps a copy first (agent undo.ts), then lets it run. No one is
 *           asked; the copy can be put back from the phone, the desktop app or the website for a week.
 *   hold    what no local copy can undo (cloud deletes, dropping a database, force-pushing main, formatting a disk, running a
 *           downloaded script...): waits for the person's Approve (riskHold.ts).
 *   block   what an AI never does on a computer, approved or not: deleting the whole home folder, a system folder, a whole drive, the
 *           Desktop/Documents/Downloads... folders themselves, the keys folder (~/.ssh), or Escanor's own undo copies. The person can
 *           still do it themselves.
 *
 * Pure (no files read here): paths are resolved from the call's folder, home and environment, so the same answer is given by the
 * agent's in-chat hook and by the machine-wide hook that guards every Claude on the computer.
 */

import { posix } from 'node:path';
import { scriptHold } from './scriptRisk.ts';
import { riskAndPlan, RISK_WHY, shellQuote, type GitUndoOp, type Plan, type Risk } from './risk.ts';

export type SafetyCtx = {
  /** The folder the call runs in. */
  cwd: string;
  home: string;
  env: Record<string, string | undefined>;
  platform: string;
  /** More folders no AI may delete (Escanor's undo store, the agent's own folder). */
  protect?: string[];
  /** What a pattern matches on disk now (the agent gives it; without it a pattern is only checked as written). */
  expand?: (pattern: string) => string[];
  /** The real path (links followed), or null when nothing is there. */
  realpath?: (path: string) => string | null;
  /** The folder of the project the person works in (the nearest folder with .git or a package file above `cwd`); default `cwd`. */
  projectRoot?: string;
  /** The text of a file (for scripts a command runs), or null. Without it scripts are not read. */
  readFile?: (path: string) => string | null;
};

export type BackupDelete = { path: string; glob: boolean; recursive: boolean; via: string; overwrite?: boolean };
export type BackupGit = { op: GitUndoOp; args: string[]; cwd: string };
export type BackupPlan = { deletes: BackupDelete[]; git: BackupGit[] };

export type Verdict =
  | { action: 'allow' }
  | { action: 'backup'; plan: BackupPlan; command: string }
  | { action: 'hold'; risk: Risk; command: string }
  | { action: 'block'; why: string; path: string; command: string };

const COMMAND_FIELDS = ['command', 'cmd', 'script'] as const;

/** The command line a tool call runs (Bash, PowerShell, an MCP shell tool, Codex's argv), or null. */
export function commandOf(input: unknown): string | null {
  const fields = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
  for (const key of COMMAND_FIELDS) {
    const value = fields[key];
    const command = Array.isArray(value) ? value.map((x) => shellQuote(String(x))).join(' ') : value;
    if (typeof command === 'string' && command.trim()) return command;
  }
  return null;
}

// ------------------------------------------------------------------------------------------------- paths

const isWin = (ctx: SafetyCtx) => ctx.platform === 'win32';
/** A path in one spelling: forward slashes, no trailing slash, `..` resolved; on Windows lower-case (its paths ignore case). */
export function normPath(p: string, win = false): string {
  let t = p.replace(/\\/g, '/');
  // Git Bash / MSYS spell C:\x as /c/x.
  if (win && /^\/[a-zA-Z](?:\/|$)/.test(t)) t = `${t[1]}:${t.slice(2) || '/'}`;
  if (win) t = t.toLowerCase();
  const drive = /^[a-zA-Z]:/.exec(t)?.[0] ?? '';
  let rest = t.slice(drive.length);
  if (drive && !rest.startsWith('/')) rest = `/${rest}`;
  rest = posix.normalize(rest || '/');
  if (rest.length > 1 && rest.endsWith('/')) rest = rest.slice(0, -1);
  return drive + rest;
}
const isAbs = (t: string) => t.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(t) || /^[a-zA-Z]:$/.test(t);
/** Positional parameters ($0, $1, "$@", ${2}...): their values come from how the line is run, not known here. */
const POSITIONAL = /\$(?:[0-9@*#?!$-]|\{[0-9@*#]+\})/g;

type Resolved = { path: string; unknown: false } | { unknown: true; ifEmpty: string | null };

const VAR = /\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$env:([A-Za-z_][A-Za-z0-9_]*)|\$([A-Za-z_][A-Za-z0-9_]*)|%([A-Za-z_][A-Za-z0-9_]*)%/g;

function envOf(ctx: SafetyCtx, name: string): string | undefined {
  if (name === 'HOME' || (isWin(ctx) && name.toUpperCase() === 'USERPROFILE')) return ctx.env[name] ?? ctx.home;
  if (name === 'PWD') return ctx.cwd;
  if (!isWin(ctx)) return ctx.env[name];
  const key = Object.keys(ctx.env).find((k) => k.toUpperCase() === name.toUpperCase());
  return key ? ctx.env[key] : undefined;
}

/** `~`, `$VAR`, `${VAR}`, `$env:VAR`, `%VAR%` filled in. unknown: a variable with no value here (bash would make it empty). */
function expand(t: string, ctx: SafetyCtx): { text: string; unknown: boolean; ifEmpty: string } {
  let unknown = false;
  if (/\$\{[^}]*[:#%/^,][^}]*\}/.test(t)) unknown = true; // ${X:-y}, ${X#y}...: not followed here
  if (new RegExp(POSITIONAL.source).test(t)) unknown = true;
  let s = t.replace(/^~(?=\/|\\|$)/, ctx.home);
  let empty = s.replace(/\$\{[^}]*\}/g, (m) => (/^\$\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(m) ? m : ''));
  const fill = (blankUnknown: boolean) => (m: string, a?: string, b?: string, c?: string, d?: string) => {
    const name = a ?? b ?? c ?? d ?? '';
    const v = envOf(ctx, name);
    if (v === undefined) {
      if (!blankUnknown) unknown = true;
      return blankUnknown ? '' : m;
    }
    return v;
  };
  s = s.replace(VAR, fill(false));
  empty = empty.replace(POSITIONAL, '').replace(VAR, fill(true));
  return { text: s, unknown: unknown || /\$/.test(s.replace(/\$\{[^}]*\}/g, '$')) && unknown, ifEmpty: empty };
}

function resolveIn(raw: string, base: string | null | undefined, ctx: SafetyCtx): Resolved {
  const e = expand(raw, ctx);
  let from: string | null;
  if (base === undefined) from = ctx.cwd;
  else if (base === null) from = null;
  else {
    const b = resolveIn(base, undefined, ctx);
    from = b.unknown ? null : b.path;
  }
  // Case is kept (a copy is put back under the same name); neverDelete compares Windows paths without case.
  const join = (t: string, dir: string | null) => (isAbs(t) ? normPath(t) : dir === null ? null : normPath(`${dir}/${t}`));
  if (e.unknown) {
    const ifEmpty = join(e.ifEmpty, from);
    return { unknown: true, ifEmpty };
  }
  const path = join(e.text, from);
  return path === null ? { unknown: true, ifEmpty: null } : { path, unknown: false };
}

const GLOB = /[*?[]/;

/** Does a word, as typed, hold a pattern character outside quotes (`"$HOME"/*` does, `'*.log'` does not)? */
export function unquotedGlob(raw: string): boolean {
  let q: string | null = null;
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (q) {
      if (c === q) q = null;
      else if (c === '\\' && q === '"') i++;
      continue;
    }
    if (c === '\\') {
      i++;
      continue;
    }
    if (c === '"' || c === "'") q = c;
    else if (c === '*' || c === '?' || c === '[') return true;
  }
  return false;
}
const BROAD_GLOB = /^(?:\*+|\.\*|\*\.\*|\.\[!.\]\*|\{,\.\}\*|\.\?\*|\[!.\]\*)$/;

// ------------------------------------------------------------------------------------------------- never

/** Folders in a home that hold a person's life, not a project: never deleted or moved away whole by an AI. */
const PRECIOUS_HOME = [
  'Desktop', 'Documents', 'Downloads', 'Pictures', 'Music', 'Videos', 'Movies', 'Public', 'Templates', 'OneDrive', 'Dropbox', 'Google Drive',
  'iCloud Drive', 'Library', 'AppData', '.ssh', '.gnupg', '.config', '.local', '.local/share', '.claude', '.claude-profiles', '.escanor',
  '.aws', '.kube', '.docker', '.gcloud', '.azure', 'snap', 'Applications',
];
/** Where whole drives are mounted: /mnt/x, /media/u/x, /run/media/u/x, /Volumes/x. */
const MOUNT = /^(?:\/mnt\/[^/]+|\/media\/[^/]+(?:\/[^/]+)?|\/run\/media\/[^/]+\/[^/]+|\/volumes\/[^/]+)$/i;

/** Why deleting (or moving away) this whole path is never done by an AI here, or null. `path`: resolved, normPath'd. */
export function neverDelete(path: string, ctx: SafetyCtx): string | null {
  const win = isWin(ctx);
  const home = normPath(ctx.home, win);
  const p = normPath(path, win);
  const under = (a: string, b: string) => a === b || a.startsWith(b.endsWith('/') ? b : `${b}/`);
  const ci = win || ctx.platform === 'darwin';
  const eq = (a: string, b: string) => (ci ? a.toLowerCase() === b.toLowerCase() : a === b);
  const drive = /^[a-z]:/i.exec(p)?.[0] ?? '';
  const rest = p.slice(drive.length);
  if (rest === '/' || rest === '') return 'the whole drive';
  if (under(home, p)) return p === home ? 'your whole home folder' : 'a folder that holds your whole home folder';
  const segs = rest.split('/').filter(Boolean);
  if (segs.length === 1) return 'a system folder';
  // A system folder's own folders (/usr/lib, /boot/efi, /etc/ssh, /var/lib): the computer stops working without them.
  if (!win && segs.length === 2 && (['usr', 'boot', 'bin', 'sbin', 'lib', 'lib64', 'etc', 'System', 'Library', 'Applications', 'opt'].includes(segs[0]) || (segs[0] === 'var' && ['lib', 'log', 'cache', 'spool', 'mail', 'db', 'backups'].includes(segs[1])))) return 'a system folder';
  if (MOUNT.test(p)) return 'a whole drive';
  if (win && /^[a-z]:\/(?:windows|program files(?: \(x86\))?|programdata|users\/[^/]+)$/.test(p)) return 'a system folder';
  for (const name of PRECIOUS_HOME) if (eq(p, `${home}/${name}`)) return `your ${name} folder`;
  for (const extra of ctx.protect ?? []) {
    const x = normPath(extra, win);
    if (under(p, x) || under(x, p)) return "Escanor's own safety copies";
  }
  return null;
}

// ------------------------------------------------------------------------------------------------- the decision

export const BLOCK_WHY = (what: string, path: string) =>
  `It would delete or move away ${what} (${path}). No AI may do that on this computer, in any mode, and it cannot be approved from the phone; only the person can do it themselves.`;

/**
 * What to do with one tool call. `plan` may be given when the caller already read the command (tests); otherwise it is read here.
 */
export function decide(toolName: string, input: unknown, ctx: SafetyCtx): Verdict {
  const command = commandOf(input);
  if (!command) return { action: 'allow' };
  const { risk, plan } = riskAndPlan(command);
  const v = decidePlan(command, risk, plan, ctx);
  // A script a command runs (`make clean`, `npm run clean`, `./clean.sh`, `python3 wipe.py`) that deletes outside the project or somewhere unclear.
  if ((v.action === 'allow' || v.action === 'backup') && ctx.readFile) {
    const hold = scriptHold(command, { cwd: ctx.cwd, projectRoot: ctx.projectRoot, home: ctx.home, platform: ctx.platform, env: ctx.env, readFile: ctx.readFile });
    if (hold) return { action: 'hold', risk: { kind: 'delete-folder', why: hold.why }, command };
  }
  return v;
}



export function decidePlan(command: string, risk: Risk | null, plan: Plan, ctx: SafetyCtx): Verdict {
  const win = isWin(ctx);
  const deletes: BackupDelete[] = [];
  let unclear = false;
  let linkTrick = false;
  const tamper = tamperReason(command, ctx);
  if (tamper) return { action: 'block', why: tamper, path: '', command };
  const held = tamperHold(command);
  // `rm -rf $HOME/{Desktop,Documents}`: a brace list is several targets; each is checked (and kept) on its own.
  const targets: typeof plan.deletes = [];
  for (const d of plan.deletes) {
    if (!unquotedBrace(win ? d.raw.replace(/\\/g, '/') : d.raw)) {
      targets.push(d);
      continue;
    }
    const raws = braceExpand(d.raw);
    const paths = braceExpand(d.path);
    if (!raws || !paths || raws.length !== paths.length) {
      unclear = true;
      continue;
    }
    for (let k = 0; k < raws.length; k++) targets.push({ ...d, raw: raws[k], path: paths[k] });
  }
  for (const d of targets) {
    const glob = unquotedGlob(win ? d.raw.replace(/\\/g, '/') : d.raw);
    // One file written over or removed (no -r, no pattern) cannot take a folder with it: `> $d/notes.md` with $d unknown is not `rm -rf /`.
    const oneFile = !d.recursive && !glob;
    // PowerShell and cmd do not treat a backslash as an escape: on Windows the path is read as typed.
    const r = resolveIn(win ? d.raw.replace(/["']/g, '') : d.path, d.base, ctx);
    const trailing = /[\\/]\.?["']?$/.test(d.raw);
    /** The paths a delete of p really reaches: p, its folder's links followed, and with a trailing slash what the link points to. */
    const reach = (p: string): string[] => {
      const out = [p];
      if (!ctx.realpath) return out;
      const cut = p.lastIndexOf('/');
      const dir = cut > 0 ? ctx.realpath(p.slice(0, cut)) : null;
      if (dir) out.push(`${dir.replace(/\\/g, '/')}/${p.slice(cut + 1)}`);
      if (trailing || d.recursive) {
        const real = ctx.realpath(p);
        if (real && trailing) out.push(real.replace(/\\/g, '/'));
      }
      return out;
    };
    const check = (p: string): string | null => {
      if (glob && ctx.expand) {
        for (const m of ctx.expand(p)) for (const q of reach(normPath(m))) {
          const what = neverDelete(q, ctx);
          if (what) return what;
        }
      }
      for (const q of reach(p)) {
        if (q === p) continue;
        const what = neverDelete(q, ctx);
        if (what) return what;
      }
      if (glob) {
        // `~/*`, `/*`, `"$X"/*`: everything in a folder is that folder.
        const segs = p.split('/');
        const k = segs.findIndex((s) => GLOB.test(s));
        const prefix = segs.slice(0, k).join('/') || '/';
        const broad = segs.slice(k).every((s) => BROAD_GLOB.test(s) || s === '');
        return broad ? neverDelete(prefix, ctx) : null;
      }
      return neverDelete(p, ctx);
    };
    if (r.unknown) {
      const what = r.ifEmpty !== null && !oneFile ? check(r.ifEmpty) : null;
      if (what) return { action: 'block', why: `${BLOCK_WHY(what, r.ifEmpty!)} (A variable in it has no value here, and empty it means exactly that.)`, path: r.ifEmpty!, command };
      if (d.recursive && !d.checkOnly && !d.routine) unclear = true;
      continue;
    }
    const what = oneFile ? storeOnly(r.path, ctx) : check(r.path);
    if (what) return { action: 'block', why: BLOCK_WHY(what, r.path), path: r.path, command };
    if (guardedSettings(r.path, ctx)) return { action: 'block', why: SETTINGS_WHY, path: r.path, command };
    if (!d.checkOnly && !d.routine) {
      // With a trailing slash a link's target is emptied: that is what is kept.
      const real = trailing && ctx.realpath ? ctx.realpath(r.path) : null;
      deletes.push({ path: real ? normPath(real) : r.path, glob, recursive: d.recursive, via: d.via, ...(d.overwrite ? { overwrite: true } : {}) });
      // `ln -s ~ x; rm -rf x/`: the link is made on the same line, after this check could look at it.
      if (trailing && /\bln\s+(?:-\w*s|--symbolic)/.test(command)) linkTrick = true;
    }
  }
  if (risk) return { action: 'hold', risk, command };
  if (held) return { action: 'hold', risk: { kind: 'unreadable', why: held }, command };
  if (unclear || linkTrick) return { action: 'hold', risk: { kind: 'delete-folder', why: RISK_WHY['delete-folder'] }, command };
  const git: BackupGit[] = [];
  for (const g of plan.git) {
    const r = g.base === undefined ? { unknown: false as const, path: normPath(ctx.cwd) } : g.base === null ? { unknown: true as const, ifEmpty: null } : resolveIn(g.base, undefined, ctx);
    if (r.unknown) {
      if (g.op !== 'discard' || plan.git.length > 1) return { action: 'hold', risk: { kind: 'discard-work', why: RISK_WHY['discard-work'] }, command };
      continue;
    }
    git.push({ op: g.op, args: g.args, cwd: r.path });
  }
  if (!deletes.length && !git.length) return { action: 'allow' };
  return { action: 'backup', plan: { deletes, git }, command };
}

/**
 * A command that would switch Escanor's safety off: take the guard out of a Claude settings file, turn all hooks off, start a Claude
 * that skips the settings carrying it, stop or kill the Escanor agent, or reach into Escanor's own safety copies. Never run by an AI.
 */
export function tamperReason(command: string, ctx: SafetyCtx): string | null {
  const c = command.replace(/\\\r?\n/g, ' ');
  if (/disableAllHooks/.test(c)) return "It would turn every hook off, and with them Escanor's safety check.";
  // Only the settings files that carry the guard (a Claude config folder's own, managed settings), never a project's .claude/.
  if (GUARDED_TEXT.test(c)) {
    const S = String.raw`['"]?(?:${GUARDED_TEXT.source})['"]?`;
    const writes = [
      new RegExp(String.raw`(?:^|[\s;&|(])(?:sed|perl)\s+(?:-\S+\s+)*-\w*i\b[^;&|]*${S}`), // an in-place edit of it
      new RegExp(String.raw`>>?\|?\s*${S}`), // a redirect into it
      new RegExp(String.raw`(?:^|[\s;&|(])(?:tee|rm|truncate|shred|unlink|sponge|Set-Content|Out-File|Clear-Content|Remove-Item)\b[^;&|]*${S}`),
      new RegExp(String.raw`(?:^|[\s;&|(])(?:mv|cp|ln|install|rsync)\b[^;&|]*\s${S}\s*(?:$|[;&|)])`), // as the destination
      new RegExp(String.raw`(?:^|[\s;&|(])dd\b[^;&|]*of=${S}`),
    ];
    if (writes.some((re) => re.test(c))) return SETTINGS_WHY;
  }
  // A Claude started so that it skips the settings carrying the guard.
  if (/(?:^|[\s;&|(/])claude(?:\s|$)/.test(c) && /--settings\b|--setting-sources\b|--bare\b|CLAUDE_CONFIG_DIR=/.test(c)) {
    return "It would start a Claude that skips the settings carrying Escanor's safety check.";
  }
  const AGENT_UNIT = String.raw`(?:escanor-agent|remote-harness-agent|harness-agent)(?:\.service)?(?![\w-])`;
  if (new RegExp(String.raw`\b(?:systemctl|service)\b[^;&|]*\b(?:stop|disable|mask|kill)\b[^;&|]*${AGENT_UNIT}`, 'i').test(c) || /\b(?:pkill|killall)\b[^;&|]*(?:escanor|remote-harness|harness-agent)/i.test(c)) {
    return 'It would stop the Escanor agent (or every AI program), which keeps this computer safe.';
  }
  const stores = [...(ctx.protect ?? []), '/var/tmp/escanor-safety', '/private/var/tmp/escanor-safety', 'escanor/undo', 'escanor\\undo'];
  if (stores.some((p) => p && c.includes(p.replace(/\\/g, '/')) || c.includes(p))) return "It reaches into Escanor's own safety copies, which no AI may touch.";
  return null;
}

const SETTINGS_WHY = "It would change a Claude settings file in a way that can take Escanor's safety check out.";
/** A Claude config folder's own settings file, as written in a command (~/.claude/settings.json, a profile's, managed settings). */
const GUARDED_TEXT = /(?:~|\$HOME|\$\{HOME\}|\/home\/[^\/\s'";&|]+|\/Users\/[^\/\s'";&|]+|\/root|[A-Za-z]:[\\/]+Users[\\/]+[^\\/\s'";&|]+)[\\/]+\.claude(?:-profiles[\\/]+[^\\/\s'";&|]+)?[\\/]+settings(?:\.local)?\.json|managed-settings\.json/;

/** Is this resolved path a settings file that carries the guard? */
export function guardedSettings(path: string, ctx: SafetyCtx): boolean {
  const win = isWin(ctx);
  const p = normPath(path, win);
  const home = normPath(ctx.home, win);
  if (/[\/]managed-settings\.json$/i.test(p)) return true;
  const config = ctx.env.CLAUDE_CONFIG_DIR?.trim();
  if (config && (p === normPath(`${config}/settings.json`, win) || p === normPath(`${config}/settings.local.json`, win))) return true;
  return p.startsWith(`${home}/`) && /^\/\.claude(?:-profiles\/[^/]+)?\/settings(?:\.local)?\.json$/.test(p.slice(home.length));
}

/**
 * Code on the line that writes files, next to a guarded settings file: maybe harmless (it writes something else), maybe not; a person
 * looks first. Only when the settings file is named on the line.
 */
export function tamperHold(command: string): string | null {
  if (!GUARDED_TEXT.test(command)) return null;
  if (/open\([^)]*['"][wa]\+?['"]|write_text|writeFileSync|writeFile|json\.dump\(|File\.write|\.write\(/.test(command)) {
    return "It runs code that writes files on the same line that names a Claude settings file, which could take Escanor's safety check out.";
  }
  return null;
}

/** Does a word, as typed, hold a brace list outside quotes (`{a,b}`, `{,.}*`)? */
export function unquotedBrace(raw: string): boolean {
  let q: string | null = null;
  for (let i = 0; i < raw.length; i++) {
    const c = raw[i];
    if (q) {
      if (c === q) q = null;
      else if (c === '\\' && q === '"') i++;
      continue;
    }
    if (c === '\\') {
      i++;
      continue;
    }
    if (c === '"' || c === "'") q = c;
    else if (c === '{') {
      const end = raw.indexOf('}', i);
      if (end > i && /,|\.\./.test(raw.slice(i, end))) return true;
    }
  }
  return false;
}

/** `a{b,c}d{e,f}` → abde, abdf, acde, acdf. null when it cannot be read simply (nested, a range, too many). */
export function braceExpand(text: string): string[] | null {
  const open = text.search(/\{[^{}]*[,][^{}]*\}/);
  if (open < 0) return /\{[^{}]*\.\.[^{}]*\}/.test(text) ? null : [text];
  const close = text.indexOf('}', open);
  const inner = text.slice(open + 1, close);
  if (inner.includes('{')) return null;
  const out: string[] = [];
  for (const alt of inner.split(',')) {
    const rest = braceExpand(text.slice(0, open) + alt + text.slice(close + 1));
    if (!rest) return null;
    out.push(...rest);
    if (out.length > 256) return null;
  }
  return out;
}

/** For a single file: only Escanor's own safety copies are off-limits (folders are checked for recursive deletes). */
function storeOnly(path: string, ctx: SafetyCtx): string | null {
  const win = isWin(ctx);
  const p = normPath(path, win);
  for (const extra of ctx.protect ?? []) {
    const x = normPath(extra, win);
    if (p === x || p.startsWith(`${x}/`)) return "Escanor's own safety copies";
  }
  return null;
}

/** What the AI is told when a call is blocked for good. */
export function blockedForGoodMessage(why: string): string {
  return `Escanor stopped this command. ${why} Do not try another way to do the same thing. Say what you needed it for; the person can do it themselves if they really want to.`;
}
