/**
 * Commands that delete by running something else: `make clean`, `npm run clean`, `./clean.sh`, `python3 wipe.py`, `node scripts/reset.js`.
 * The command line itself holds no delete, so the line check (risk.ts) and the copies (safety.ts) never see one. Here the file that
 * would run is read (the caller gives `readFile`), and what it deletes is checked the same way a typed delete is: a target inside the
 * project that is plainly named is ordinary work (a script that removes `dist` runs at once); a target outside the project, in the home
 * folder, made from a variable this reader cannot fill in, or fed by another program is held for the person.
 *
 * It reads text, it does not run anything: a program that builds a path in code is "unclear" (held) only when the delete itself is
 * visible in the file. A script that never mentions deleting is not held. Known limits: a link inside the project that points
 * elsewhere is not followed; code that builds the name of the delete call itself is not seen.
 */
import { parseShell, programName } from './shellParse.ts';

export type ScriptCtx = {
  cwd: string;
  /** The folder of the project the person works in (default: the folder the command runs in). */
  projectRoot?: string;
  home: string;
  platform: string;
  env: Record<string, string | undefined>;
  /** The text of a file, or null when it cannot be read (missing, not text). A file too big to read returns SCRIPT_TOO_BIG. */
  readFile?: (path: string) => string | null;
};

export type ScriptHold = { why: string; file: string };

/** What `readFile` returns for a file too big to check: the script is then held when it is a clean-up, never waved through. */
export const SCRIPT_TOO_BIG = '\u0000TOO_BIG';
export const MAX_SCRIPT_BYTES = 200_000;

const CLEANISH = /^(clean|distclean|realclean|mrproper|purge|wipe|reset|nuke|fresh|clear|cleanup|clean-all|clean_all|veryclean|uninstall|prune|scrub|reinstall)([-_:.].*)?$/i;
const DELETERS = new Set(['rm', 'rmdir', 'unlink', 'shred', 'srm', 'rimraf', 'del', 'erase', 'rd', 'remove-item', 'ri']);
/** Programs that only run what follows them: looked through. */
const WRAPPERS = new Set(['env', 'time', 'nice', 'nohup', 'exec', 'command', 'sudo', 'doas', 'timeout', 'stdbuf', 'ionice', 'npx', 'pnpx', 'bunx', 'builtin']);
const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh', 'source', '.']);
const INTERP: Record<string, 'python' | 'node' | 'ruby' | 'perl' | 'ps'> = { python: 'python', python3: 'python', python2: 'python', py: 'python', node: 'node', nodejs: 'node', deno: 'node', ruby: 'ruby', perl: 'perl', powershell: 'ps', pwsh: 'ps' };
const MAX_EXPANDED = 100_000;

const posixJoin = (a: string, b: string): string => {
  const out: string[] = [];
  for (const seg of `${a}/${b}`.replace(/\\/g, '/').split('/')) {
    if (seg === '' || seg === '.') continue;
    if (seg === '..') out.pop();
    else out.push(seg);
  }
  return `/${out.join('/')}`;
};
const norm = (p: string, win: boolean): string => {
  let t = p.replace(/\\/g, '/');
  if (win) t = t.toLowerCase();
  const drive = /^[a-zA-Z]:/.exec(t)?.[0] ?? '';
  return drive + posixJoin('/', t.slice(drive.length));
};
const under = (p: string, dir: string): boolean => p === dir || p.startsWith(dir.endsWith('/') ? dir : `${dir}/`);
const brief = (t: string): string => (t.length > 60 ? `${t.slice(0, 57)}...` : t).replace(/[\r\n]+/g, ' ');

type Where = 'inside' | 'outside' | 'unclear';
type Kind = 'shell' | 'python' | 'node' | 'ruby' | 'perl' | 'ps';

/** One command with the wrappers and `NAME=value` in front of it taken off. `raw` keeps the program as typed (its folder and case). */
type Step = { prog: string; raw: string; args: string[]; inline?: string };

class Checker {
  private seen = new Set<string>();
  private win: boolean;
  private project: string;
  private c: ScriptCtx;
  constructor(c: ScriptCtx) {
    this.c = c;
    this.win = c.platform === 'win32';
    this.project = norm(c.projectRoot ?? c.cwd, this.win);
  }

  /** A Windows line keeps its backslashes as path separators (bash would read them as escapes). */
  private parse(text: string) {
    return parseShell(this.win ? text.replace(/\\/g, '/') : text);
  }

  /** Where one delete target lands, from the folder `base`, with the script's own plain variables filled in. */
  where(raw: string, base: string, vars: Record<string, string>): Where {
    let t = raw;
    for (let i = 0; i < 4 && /\$/.test(t); i++) {
      t = t.replace(/\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)|\$\(([A-Za-z_][A-Za-z0-9_]*)\)/g, (m, a, b, d) => {
        const name = String(a ?? b ?? d);
        if (name === 'HOME' && vars.HOME === undefined) return this.c.home;
        return vars[name] ?? m;
      });
      if (t.length > MAX_EXPANDED) return 'unclear';
    }
    if (/[$`]|%\w+%/.test(t)) return 'unclear';
    if (t === '') return 'unclear';
    if (t === '~' || /^~[^/]/.test(t)) return 'outside';
    if (t.startsWith('~')) t = this.c.home + t.slice(1);
    const abs = t.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(t);
    const p = norm(abs ? t : `${base}/${t}`, this.win);
    return under(p, this.project) && p !== norm(this.c.home, this.win) ? 'inside' : 'outside';
  }

  /** The command a word list really runs: assignments and wrapper programs off, `sh -c "..."` opened. */
  private step(words: string[], vars: Record<string, string>): Step | null {
    let w = [...words];
    for (let guard = 0; guard < 8 && w.length; guard++) {
      while (w.length && /^[A-Za-z_][A-Za-z0-9_]*=/.test(w[0]!)) {
        const m = /^([A-Za-z_][A-Za-z0-9_]*)=(.*)$/.exec(w[0]!)!;
        vars[m[1]!] = m[2]!;
        w = w.slice(1);
      }
      if (!w.length) return null;
      const raw = w[0]!;
      const prog = programName(raw.replace(/\\/g, '/')).toLowerCase().replace(/\.(exe|com)$/, '');
      if (WRAPPERS.has(prog)) {
        // skip the wrapper's own flags (and `timeout 30`, `nice -n 5` values)
        let i = 1;
        while (i < w.length && (w[i]!.startsWith('-') || /^[A-Za-z_][A-Za-z0-9_]*=/.test(w[i]!) || (prog === 'timeout' && /^\d/.test(w[i]!)))) i++;
        w = w.slice(i);
        continue;
      }
      if (SHELLS.has(prog) && prog !== 'source' && prog !== '.') {
        const i = w.findIndex((a, k) => k > 0 && /^-[a-z]*c[a-z]*$/.test(a));
        if (i > 0 && w[i + 1] !== undefined) return { prog, raw, args: w.slice(1), inline: w[i + 1] };
      }
      if (prog === 'eval') return { prog, raw, args: w.slice(1), inline: w.slice(1).join(' ') };
      return { prog, raw, args: w.slice(1) };
    }
    return null;
  }

  /** The first delete in a shell text (a Makefile recipe, a package script, a shell file) that is not plainly inside the project. */
  shellText(text: string, base: string, vars: Record<string, string>, depth: number, label: string): ScriptHold | null {
    let parsed;
    try {
      parsed = this.parse(text);
    } catch {
      return { why: `A script this command runs could not be read (${brief(label)}), and it may delete files.`, file: label };
    }
    const v = { ...vars };
    let dir = base;
    for (const cmd of parsed.commands) {
      const st = this.step(cmd.words.map((w) => w.text), v);
      if (!st) continue;
      if (st.inline !== undefined && depth < 4) {
        const inner = this.shellText(st.inline, dir, v, depth + 1, label);
        if (inner) return inner;
        continue;
      }
      const { prog, args } = st;
      if (prog === 'cd' || prog === 'pushd') {
        const t = args.find((a) => !a.startsWith('-'));
        const w = t === undefined ? 'outside' : this.where(t, dir, v);
        if (w === 'inside') dir = t!.startsWith('/') ? t! : `${dir}/${t}`;
        else return { why: `A script this command runs changes to a folder outside the project or one it cannot work out (${brief(label)}), and it deletes files.`, file: label };
        continue;
      }
      const targets = this.deleteTargets(prog, args);
      if (targets) {
        if (targets.unknown) return { why: `A script this command runs deletes files in a way that cannot be checked (${brief(label)}).`, file: label };
        for (const t of targets.paths) {
          const w = this.where(t, dir, v);
          if (w !== 'inside') return { why: `A script this command runs (${brief(label)}) deletes ${w === 'outside' ? 'something outside the project' : `"${brief(t)}", which cannot be worked out here`}. Check it before it runs.`, file: label };
        }
        continue;
      }
      // another script or program started from here: followed (a few levels)
      if (depth < 3) {
        const inner = this.invocation(st, dir, depth + 1);
        if (inner) return inner;
      }
    }
    return null;
  }

  /** The things a delete-like command removes, or null when the command is not one. unknown: it deletes but not what. */
  private deleteTargets(prog: string, args: string[]): { paths: string[]; unknown?: boolean } | null {
    const plain = args.filter((a) => !a.startsWith('-') && !(this.win && /^\/[a-z?]{1,3}$/i.test(a)));
    if (DELETERS.has(prog)) return { paths: plain };
    if (prog === 'find') {
      const del = args.includes('-delete') || args.some((a, i) => /^-exec(dir)?$/.test(a) && DELETERS.has(programName(args[i + 1] ?? '').toLowerCase()));
      if (!del) return null;
      const roots: string[] = [];
      for (const a of args) {
        if (a.startsWith('-') || a === '(' || a === '!') break;
        roots.push(a);
      }
      return { paths: roots.length ? roots : ['.'] };
    }
    if (prog === 'git' && plain[0] === 'clean') return { paths: ['.'] };
    if (prog === 'rsync' && args.some((a) => /^--(delete|del|remove-source-files)/.test(a))) return { paths: plain.slice(-1) };
    if (prog === 'xargs' && args.some((a) => DELETERS.has(programName(a).toLowerCase()))) return { paths: [], unknown: true };
    return null;
  }

  /** `make`, `npm run`, a script given by path, an interpreter and its file. */
  invocation(st: Step, dir: string, depth: number): ScriptHold | null {
    const { prog, raw, args } = st;
    const key = `${raw} ${args.join(' ')}@${dir}`;
    if (this.seen.has(key) || this.seen.size > 40) return null;
    this.seen.add(key);
    const read = this.c.readFile;
    if (!read) return null;
    const abs = (p: string) => (p.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(p) ? p : `${dir}/${p}`);
    if (prog === 'make' || prog === 'gmake') return this.make(args, dir, depth);
    if (['npm', 'yarn', 'pnpm', 'bun'].includes(prog)) {
      const i = args[0] === 'run' || args[0] === 'run-script' ? 1 : 0;
      const name = args[i];
      if (!name || name.startsWith('-')) return null;
      const pkg = read(norm(`${dir}/package.json`, this.win));
      if (!pkg || pkg === SCRIPT_TOO_BIG) return null;
      let scripts: Record<string, unknown> = {};
      try {
        scripts = (JSON.parse(pkg) as { scripts?: Record<string, unknown> }).scripts ?? {};
      } catch {
        return null;
      }
      // npm runs `pre<name>` and `post<name>` around the script itself
      for (const n of [`pre${name}`, name, `post${name}`]) {
        const text = scripts[n];
        if (typeof text !== 'string') continue;
        const r = this.shellText(text, dir, {}, depth, `package.json "${n}"`);
        if (r) return r;
      }
      return null;
    }
    let file: string | null = null;
    let kind: Kind | null = null;
    if (SHELLS.has(prog)) {
      file = args.find((a) => !a.startsWith('-')) ?? null;
      kind = 'shell';
    } else if (INTERP[prog]) {
      const flagFile = prog === 'powershell' || prog === 'pwsh' ? args[args.findIndex((a) => /^-file$/i.test(a)) + 1] : undefined;
      file = flagFile ?? args.find((a) => !a.startsWith('-')) ?? null;
      kind = INTERP[prog]!;
    } else if (/^(\.\.?[\\/]|\/|[A-Za-z]:[\\/]|~\/)|\.(sh|bash|bat|cmd|py|js|mjs|cjs|rb|pl|ps1)$/i.test(raw) && !/^(git|npm|npx)$/.test(prog)) {
      // the program as typed: its folder and its capitals matter (`./scripts/Reset.sh`)
      file = raw;
      kind = /\.py$/i.test(raw) ? 'python' : /\.(m?c?js)$/i.test(raw) ? 'node' : /\.rb$/i.test(raw) ? 'ruby' : /\.pl$/i.test(raw) ? 'perl' : /\.ps1$/i.test(raw) ? 'ps' : 'shell';
    }
    if (!file || !kind) return null;
    const full = norm(file.startsWith('~') ? this.c.home + file.slice(1) : abs(file), this.win);
    const text = read(full);
    if (text === null) return null;
    const label = file;
    if (text === SCRIPT_TOO_BIG) return { why: `A script this command runs (${brief(label)}) is too big for Escanor to check, so a person should look at it first.`, file: label };
    if (kind === 'shell') return this.shellText(text, dir, {}, depth, label);
    return this.codeText(text, kind, dir, label);
  }

  private make(args: string[], dir: string, depth: number): ScriptHold | null {
    const read = this.c.readFile!;
    let base = dir;
    const files: string[] = [];
    const targets: string[] = [];
    for (let i = 0; i < args.length; i++) {
      const a = args[i]!;
      if (a === '-C' || a === '--directory') base = this.cd(base, args[++i] ?? '');
      else if (/^-C./.test(a)) base = this.cd(base, a.slice(2));
      else if (a.startsWith('--directory=')) base = this.cd(base, a.slice(12));
      else if (a === '-f' || a === '--file' || a === '--makefile') files.push(args[++i] ?? '');
      else if (a.startsWith('--file=') || a.startsWith('--makefile=')) files.push(a.slice(a.indexOf('=') + 1));
      else if (!a.startsWith('-') && !a.includes('=')) targets.push(a);
    }
    const wanted = targets.length ? targets : [''];
    const cleanish = wanted.filter((t) => CLEANISH.test(t));
    if (!cleanish.length) return null;
    if (this.where('.', base, {}) !== 'inside') return { why: `This runs "make ${brief(cleanish.join(' '))}" in a folder outside the project (${brief(base)}), where it deletes files. Check it before it runs.`, file: 'Makefile' };
    let text: string | null = null;
    for (const f of files.length ? files : ['GNUmakefile', 'makefile', 'Makefile']) {
      text = read(norm(f.startsWith('/') ? f : `${base}/${f}`, this.win));
      if (text !== null) break;
    }
    if (text === null) return null;
    if (text === SCRIPT_TOO_BIG) return { why: `The Makefile this command runs is too big for Escanor to check, and "make ${brief(cleanish.join(' '))}" deletes files. A person should look at it first.`, file: 'Makefile' };
    const vars: Record<string, string> = {};
    for (const m of text.matchAll(/^([A-Za-z_][A-Za-z0-9_]*)[ \t]*[:?+]?=[ \t]*(.*?)[ \t]*$/gm)) vars[m[1]!] = m[2]!;
    for (const t of cleanish) {
      const r = this.makeTarget(text, t, vars, base, depth, new Set());
      if (r) return r;
    }
    return null;
  }

  /** The recipe of one make target and of what it depends on (a few levels), read as shell. */
  private makeTarget(text: string, target: string, vars: Record<string, string>, base: string, depth: number, seen: Set<string>): ScriptHold | null {
    if (seen.has(target) || seen.size > 12) return null;
    seen.add(target);
    const rule = this.rule(text, target);
    if (!rule) return null;
    const lines = rule.recipe.map((l) => l.replace(/^[@+\-\s]+/, ''));
    if (lines.length) {
      const r = this.shellText(this.fill(lines.join('\n'), vars), base, {}, depth, `Makefile "${target}"`);
      if (r) return r;
    }
    for (const dep of rule.deps) {
      if (!dep || /[$%]/.test(dep) || dep.startsWith('.')) continue;
      const r = this.makeTarget(text, dep, vars, base, depth, seen);
      if (r) return r;
    }
    return null;
  }

  private cd(base: string, t: string): string {
    return t.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(t) ? t : `${base}/${t}`;
  }

  /** Make's own `$(NAME)` / `${NAME}` filled from the Makefile's plain assignments (a few levels), and its handful of well-known ones. */
  private fill(text: string, vars: Record<string, string>): string {
    const all: Record<string, string> = { ...vars, RM: 'rm -f', MAKE: 'make', CURDIR: '.', PWD: '.' };
    const simple = (x: string): string =>
      x
        .replace(/\$[({]shell\s+pwd[)}]/g, '.')
        .replace(/\$[({](?:abspath|realpath|wildcard|strip|dir)\s+([^)}$]*)[)}]/g, '$1')
        .replace(/\$[({]([A-Za-z_][A-Za-z0-9_]*):[^)}]*[)}]/g, '$$($1)'); // $(SRC:.c=.o): the same names, other endings
    let t = simple(text);
    for (let i = 0; i < 6; i++) {
      const next = simple(t.replace(/\$\(([A-Za-z_][A-Za-z0-9_]*)\)|\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g, (m, a, b) => all[String(a ?? b)] ?? m));
      if (next === t) break;
      t = next;
      if (t.length > MAX_EXPANDED) return '$UNKNOWN_TOO_LARGE'; // a blown-up expansion is not read: its delete is unclear
    }
    return t.replace(/\$\$/g, '$');
  }

  /** A make rule: every target on its head line counts (`clean clean-all:`); the recipe lines under it (and after a `;`), and what it depends on. */
  private rule(text: string, target: string): { recipe: string[]; deps: string[] } | null {
    const lines = text.split(/\r?\n/);
    const isHead = (l: string): RegExpExecArray | null => /^([^\s#:=][^:=]*?)\s*:(?![:=])\s*([^;]*)(?:;\s*(.*))?$/.exec(l);
    let i = -1;
    let head: RegExpExecArray | null = null;
    for (let k = 0; k < lines.length; k++) {
      const m = isHead(lines[k]!);
      if (m && m[1]!.split(/\s+/).includes(target)) {
        i = k;
        head = m;
        break;
      }
    }
    if (i < 0 || !head) return null;
    const recipe: string[] = [];
    if (head[3]) recipe.push(head[3]);
    let carry = '';
    for (let j = i + 1; j < lines.length; j++) {
      const l = lines[j]!;
      if (!/^\t/.test(l) && l.trim() !== '' && !/^\s*#/.test(l)) break;
      if (/^\s*#/.test(l) || l.trim() === '') continue;
      const body = l.replace(/^\t/, '');
      if (body.endsWith('\\')) carry += `${body.slice(0, -1)} `;
      else {
        recipe.push(carry + body);
        carry = '';
      }
    }
    return { recipe, deps: head[2]!.split(/\s+/).filter(Boolean) };
  }

  /** Python, Node, Ruby, Perl, PowerShell, a Windows batch file: a delete call that is visible in the text, and what it is given. */
  private codeText(text: string, kind: Exclude<Kind, 'shell'>, dir: string, label: string): ScriptHold | null {
    // Bounded groups only: an adversarial file must not make the check slow.
    const calls: Record<Exclude<Kind, 'shell'>, RegExp> = {
      python: /\b(?:shutil\.rmtree|os\.(?:remove|unlink|rmdir|removedirs)|rmtree|Path\([^)\n]{0,200}\)\.(?:unlink|rmdir))\s*\(?\s*([^,)\n]{0,300})/g,
      node: /\b(?:fs(?:\.promises)?\.(?:rmSync|rmdirSync|unlinkSync|rm|rmdir|unlink)|rimraf(?:\.sync)?|fse?\.(?:remove|emptyDir)(?:Sync)?)\s*\(\s*([^,)\n]{0,300})/g,
      ruby: /\b(?:FileUtils\.(?:rm_rf|rm_r|rm_f|rm|remove_dir|remove_entry)|File\.delete|Dir\.rmdir)\s*\(?\s*([^,)\n]{0,300})/g,
      perl: /\b(?:unlink|rmdir|rmtree|remove_tree)\s*\(?\s*([^,)\n;]{0,300})/g,
      ps: /\b(?:Remove-Item|ri|del|rd|rm)\b[ \t]+([^\n|;]{0,300})/gi,
    };
    for (const m of text.slice(0, MAX_SCRIPT_BYTES).matchAll(calls[kind])) {
      let arg = (m[1] ?? '').trim();
      if (kind === 'ps') arg = arg.split(/\s+/).find((a) => !a.startsWith('-')) ?? '';
      const lit = /^([rRbuUfF]*)(["'`])(.*?)\2\s*$/.exec(arg);
      // an f-string, a template with `${...}` or a name with braces is built at run time: not a plain place
      if (!lit || /f/i.test(lit[1]!) || /[{}$]/.test(lit[3]!)) return { why: `A script this command runs (${brief(label)}) deletes files, and where cannot be worked out. Check it before it runs.`, file: label };
      const w = this.where(lit[3]!, dir, {});
      if (w !== 'inside') return { why: `A script this command runs (${brief(label)}) deletes ${w === 'outside' ? 'something outside the project' : `"${brief(lit[3]!)}", which cannot be worked out here`}. Check it before it runs.`, file: label };
    }
    return null;
  }

  /** The command line as typed: every command in it that runs a file. */
  line(command: string): ScriptHold | null {
    let parsed;
    try {
      parsed = this.parse(command);
    } catch {
      return null;
    }
    let dir = this.c.cwd;
    const vars: Record<string, string> = {};
    for (const cmd of parsed.top.length ? parsed.top : parsed.commands) {
      const st = this.step(cmd.words.map((w) => w.text), vars);
      if (!st) continue;
      if (st.inline !== undefined) {
        // `sh -c "make clean"`: the text it is given is a command line of its own
        const r = new Checker({ ...this.c, cwd: dir }).line(st.inline);
        if (r) return r;
        continue;
      }
      if (st.prog === 'cd' || st.prog === 'pushd') {
        const t = st.args.find((a) => !a.startsWith('-'));
        if (t !== undefined && !/[$`]/.test(t)) dir = t.startsWith('/') || /^[a-zA-Z]:[\\/]/.test(t) ? t : t.startsWith('~') ? this.c.home + t.slice(1) : `${dir}/${t}`;
        continue;
      }
      const r = this.invocation(st, dir, 0);
      if (r) return r;
    }
    return null;
  }
}

/** Why running this command line would delete something outside the project (or something unclear) through a script, or null. */
export function scriptHold(command: string, ctx: ScriptCtx): ScriptHold | null {
  if (!ctx.readFile || command.length > 20_000) return null;
  try {
    const read = ctx.readFile;
    return new Checker({
      ...ctx,
      readFile: (p) => {
        const t = read(p);
        if (t === null) return null;
        return t === SCRIPT_TOO_BIG || t.length > MAX_SCRIPT_BYTES ? SCRIPT_TOO_BIG : t;
      },
    }).line(command);
  } catch {
    return null; // a check that cannot read does not stop ordinary work; the other checks still apply
  }
}

