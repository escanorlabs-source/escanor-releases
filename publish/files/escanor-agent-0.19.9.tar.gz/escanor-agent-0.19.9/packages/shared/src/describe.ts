import { parseShell, programName, type Command } from './shellParse.ts';
import { riskyToolCall, shellQuote as shellQuoteWord, type RiskKind } from './risk.ts';

/**
 * What a tool call will do, in everyday words, for the phone's approval bar ("Delete the folder build and everything in it").
 * Never the raw command: the person sees that only when they ask (See details). `undoable` is false when what it does cannot be
 * taken back (a delete, a force push, a wiped database...). The phone has the same rules in Dart (describe_action.dart) for
 * agents older than this file.
 */
export type ActionDescription = { summary: string; undoable: boolean };

/** Longest summary sent: one line on a phone, two at most. */
export const MAX_SUMMARY_CHARS = 140;

const PATH_CHARS = 48;

/** A path or name, short enough for one line ("…/src/app.ts"). */
function short(p: string): string {
  const t = p.trim();
  if (t.length <= PATH_CHARS) return t;
  const tail = t.slice(-(PATH_CHARS - 1));
  const cut = tail.indexOf('/');
  return `…${cut > 0 && cut < 20 ? tail.slice(cut) : tail}`;
}

/** "a", "a and b", "a, b and 3 more". */
function list(items: string[], noun?: string): string {
  const xs = items.map(short);
  if (xs.length === 0) return noun ?? '';
  if (xs.length === 1) return xs[0];
  if (xs.length === 2) return `${xs[0]} and ${xs[1]}`;
  return `${xs[0]}, ${xs[1]} and ${xs.length - 2} more`;
}

function cap(s: string): string {
  const t = s.replace(/\s+/g, ' ').trim();
  const one = t.charAt(0).toUpperCase() + t.slice(1);
  return one.length > MAX_SUMMARY_CHARS ? `${one.slice(0, MAX_SUMMARY_CHARS - 1).trimEnd()}…` : one;
}

const safe = (summary: string): ActionDescription => ({ summary, undoable: true });
const final = (summary: string): ActionDescription => ({ summary, undoable: false });

/** Programs that only set the scene (where to run, a note on screen): skipped when saying what a line does. */
const SCENERY = new Set(['cd', 'pushd', 'popd', 'echo', 'printf', 'true', ':', 'set', 'export', 'source', '.', 'sleep', 'clear', 'pwd']);

const SHELLS = new Set(['sh', 'bash', 'zsh', 'dash', 'ksh', 'fish', 'python', 'python3', 'node', 'perl', 'ruby']);

const DB_TOOLS: Record<string, string> = {
  psql: 'PostgreSQL',
  pg_restore: 'PostgreSQL',
  mysql: 'MySQL',
  mariadb: 'MySQL',
  mongo: 'MongoDB',
  mongosh: 'MongoDB',
  sqlite3: 'SQLite',
  'redis-cli': 'Redis',
  dropdb: 'PostgreSQL',
  createdb: 'PostgreSQL',
};

const PACKAGE_MANAGERS = new Set(['npm', 'pnpm', 'yarn', 'bun']);

function positional(args: string[]): string[] {
  return args.filter((a) => !a.startsWith('-'));
}

function hostOf(url: string): string {
  const m = /^[a-z]+:\/\/([^/:?#]+)/i.exec(url);
  return m ? m[1] : short(url);
}

function hasShort(args: string[], ch: string): boolean {
  return args.some((a) => /^-[A-Za-z]+$/.test(a) && a.includes(ch));
}

function describeGit(args: string[]): ActionDescription {
  // Options before the subcommand (`git -C dir push`) are skipped.
  let i = 0;
  while (i < args.length && args[i].startsWith('-')) i += args[i] === '-C' || args[i] === '-c' ? 2 : 1;
  const sub = args[i] ?? '';
  const rest = args.slice(i + 1);
  const pos = positional(rest);
  const has = (...f: string[]) => rest.some((a) => f.includes(a) || f.some((g) => g.startsWith('--') && a.startsWith(`${g}=`)));
  switch (sub) {
    case 'push': {
      const branch = pos[1] ? ` (branch ${short(pos[1].replace(/^\+/, ''))})` : '';
      if (has('--delete', '-d') || pos[1]?.startsWith(':')) return final(`Delete a branch from the online copy of this project${branch}`);
      if (has('--force', '-f', '--force-with-lease') || pos[1]?.startsWith('+')) return final(`Overwrite the online copy of this project with yours${branch}`);
      return safe(`Send your saved changes to the online copy of this project${branch}`);
    }
    case 'commit': {
      const mi = rest.findIndex((a) => a === '-m' || a === '--message');
      const msg = mi >= 0 && rest[mi + 1] ? `: "${short(rest[mi + 1].split('\n')[0])}"` : '';
      return safe(`Save a checkpoint of your changes${msg}`);
    }
    case 'reset':
      if (has('--hard')) return final('Throw away all changes that are not saved in a checkpoint');
      return safe('Step back to an earlier checkpoint, keeping your changes in the files');
    case 'clean':
      return final('Delete the files this project does not keep track of (new, unsaved files)');
    case 'checkout':
    case 'switch': {
      if (rest.includes('--') || (sub === 'checkout' && has('.'))) {
        const files = rest.slice(rest.indexOf('--') + 1).filter((a) => !a.startsWith('-'));
        return final(`Throw away unsaved changes to ${list(files.length ? files : ['these files'])}`);
      }
      if (has('-b', '-B', '-c', '-C')) return safe(`Make a new branch ${short(pos[0] ?? '')} and switch to it`);
      if (has('--force', '-f')) return final(`Switch to ${short(pos[0] ?? 'another branch')}, throwing away unsaved changes`);
      return safe(`Switch to ${pos[0] ? `the branch ${short(pos[0])}` : 'another branch'}`);
    }
    case 'restore':
      if (has('--staged', '-S') && !has('--worktree', '-W')) return safe(`Take ${list(pos, 'files')} out of the next checkpoint`);
      return final(`Throw away unsaved changes to ${list(pos, 'these files')}`);
    case 'branch':
      if (has('-D', '-d', '--delete') || hasShort(rest, 'D')) return final(`Delete the branch ${list(pos, 'named here')}`);
      return safe(pos.length ? `Make a new branch ${short(pos[0])}` : 'List the branches');
    case 'stash':
      if (pos[0] === 'drop' || pos[0] === 'clear') return final('Delete changes you put aside earlier');
      if (pos[0] === 'pop' || pos[0] === 'apply') return safe('Bring back changes you put aside earlier');
      return safe('Put your unsaved changes aside for later');
    case 'pull':
      return safe('Download the latest changes and add them to yours');
    case 'fetch':
      return safe('Check the online copy of this project for new changes');
    case 'merge':
      return safe(`Combine ${pos[0] ? `the branch ${short(pos[0])}` : 'another branch'} into this one`);
    case 'rebase':
      return safe(`Replay your changes on top of ${pos[0] ? short(pos[0]) : 'another branch'}`);
    case 'clone':
      return safe(`Download a copy of the project from ${pos[0] ? hostOf(pos[0]) : 'online'}`);
    case 'add':
      return safe(`Mark ${list(pos, 'changes')} for the next checkpoint`);
    case 'rm':
      return final(`Delete ${list(pos, 'files')} from the project`);
    case 'tag':
      if (has('-d', '--delete')) return final(`Delete the tag ${list(pos)}`);
      return safe(pos.length ? `Label this checkpoint ${short(pos[0])}` : 'List the labels');
    case 'status':
    case 'diff':
    case 'log':
    case 'show':
      return safe('Look at what changed in this project');
    default:
      return safe(sub ? `Run git ${sub} on this project` : 'Run a git command');
  }
}

function describePackages(pm: string, args: string[]): ActionDescription {
  const sub = args[0] ?? 'install';
  const pos = positional(args.slice(1));
  const global = args.includes('-g') || args.includes('--global') || args[0] === 'global';
  const where = global ? ' for the whole computer' : '';
  switch (sub) {
    case 'i':
    case 'install':
    case 'add':
    case 'ci':
      return safe(pos.length ? `Install the package${pos.length > 1 ? 's' : ''} ${list(pos)}${where}` : "Install this project's packages");
    case 'uninstall':
    case 'remove':
    case 'rm':
    case 'un':
      return safe(`Remove the package${pos.length > 1 ? 's' : ''} ${list(pos)}${where}`);
    case 'update':
    case 'upgrade':
    case 'up':
      return safe(pos.length ? `Update ${list(pos)}` : "Update this project's packages");
    case 'test':
    case 't':
      return safe("Run this project's tests");
    case 'run':
    case 'run-script':
      return safe(pos[0] ? `Run this project's "${short(pos[0])}" script` : "List this project's scripts");
    case 'start':
      return safe('Start this project');
    case 'publish':
      return final('Publish this package for everyone to download');
    case 'exec':
    case 'dlx':
    case 'x':
      return safe(pos[0] ? `Download and run the tool ${short(pos[0])}` : 'Run a tool');
    default:
      if (pm !== 'npm' && !sub.startsWith('-')) return safe(`Run this project's "${short(sub)}" script`);
      return safe(`Run ${pm} ${short(sub)}`);
  }
}

function describePip(args: string[]): ActionDescription {
  // `python -m pip install x`
  const sub = args[0] ?? '';
  const pos = positional(args.slice(1));
  const ri = args.findIndex((a) => a === '-r' || a === '--requirement');
  if (sub === 'install') {
    if (ri >= 0 && args[ri + 1]) return safe(`Install the Python packages listed in ${short(args[ri + 1])}`);
    return safe(pos.length ? `Install the Python package${pos.length > 1 ? 's' : ''} ${list(pos)}` : 'Install Python packages');
  }
  if (sub === 'uninstall') return safe(`Remove the Python package${pos.length > 1 ? 's' : ''} ${list(pos)}`);
  return safe(`Run pip ${short(sub)}`);
}

function describeDocker(args: string[]): ActionDescription {
  let a = args;
  if (a[0] === 'compose') a = a.slice(1);
  const sub = a[0] ?? '';
  const rest = a.slice(1);
  const pos = positional(rest);
  const compose = args[0] === 'compose';
  if (compose) {
    if (sub === 'up') return safe("Start this project's services");
    if (sub === 'down') return rest.includes('-v') || rest.includes('--volumes') ? final("Stop this project's services and delete their stored data") : safe("Stop and remove this project's services");
    if (sub === 'build') return safe("Build this project's services");
    return safe(`Run docker compose ${short(sub)}`);
  }
  if (sub === 'container' || sub === 'image' || sub === 'volume' || sub === 'network' || sub === 'system' || sub === 'builder') {
    const what = { container: 'containers', image: 'images', volume: 'stored data (volumes)', network: 'networks', system: 'containers, images and data', builder: 'build cache' }[sub];
    const op = rest[0] ?? '';
    const names = positional(rest.slice(1));
    if (op === 'prune') return final(`Delete unused ${what}`);
    if (op === 'rm' || op === 'remove') return final(`Delete the ${sub} ${list(names)}`);
    return safe(`Look at Docker ${what}`);
  }
  switch (sub) {
    case 'run':
      return safe(`Start a new container from ${pos[0] ? short(pos[0]) : 'an image'}`);
    case 'rm':
      return final(`Delete the container${pos.length > 1 ? 's' : ''} ${list(pos)}`);
    case 'rmi':
      return final(`Delete the image${pos.length > 1 ? 's' : ''} ${list(pos)}`);
    case 'stop':
    case 'kill':
      return safe(`Stop the container${pos.length > 1 ? 's' : ''} ${list(pos)}`);
    case 'start':
    case 'restart':
      return safe(`${sub === 'start' ? 'Start' : 'Restart'} the container${pos.length > 1 ? 's' : ''} ${list(pos)}`);
    case 'build':
      return safe('Build a container image from this folder');
    case 'push':
      return safe(`Upload the image ${list(pos)} to its registry`);
    case 'pull':
      return safe(`Download the image ${list(pos)}`);
    case 'exec':
      return safe(`Run a command inside the container ${pos[0] ? short(pos[0]) : ''}`);
    case 'ps':
    case 'images':
    case 'logs':
    case 'inspect':
      return safe('Look at Docker containers');
    default:
      return safe(`Run docker ${short(sub)}`);
  }
}

function describeSystemctl(args: string[]): ActionDescription {
  const pos = positional(args);
  const op = pos[0] ?? '';
  const units = pos.slice(1).map((u) => u.replace(/\.service$/, ''));
  const svc = units.length ? `the system service ${list(units)}` : 'a system service';
  switch (op) {
    case 'start':
      return safe(`Start ${svc}`);
    case 'stop':
      return safe(`Stop ${svc}`);
    case 'restart':
    case 'reload':
    case 'try-restart':
      return safe(`Restart ${svc}`);
    case 'enable':
      return safe(`Make ${svc} start with the computer`);
    case 'disable':
      return safe(`Stop ${svc} from starting with the computer`);
    case 'mask':
      return safe(`Block ${svc} from running`);
    case 'poweroff':
    case 'reboot':
    case 'halt':
      return final(op === 'reboot' ? 'Restart the computer' : 'Turn the computer off');
    case 'status':
    case 'is-active':
    case 'list-units':
      return safe('Check the system services');
    default:
      return safe(`Change ${svc}`);
  }
}

function describeDb(prog: string, args: string[], text: string): ActionDescription {
  const name = DB_TOOLS[prog];
  if (prog === 'dropdb') return final(`Delete the ${name} database ${list(positional(args))}`);
  if (prog === 'createdb') return safe(`Make a new ${name} database ${list(positional(args))}`);
  if (prog === 'redis-cli') {
    if (/\bflush(all|db)\b/i.test(text)) return final('Wipe all the data in Redis');
    if (/\b(del|unlink)\b/i.test(text)) return final('Delete data in Redis');
    return safe('Run a command on Redis');
  }
  if (/\bdrop\s+(database|schema|table|collection)\b|\.drop(Database)?\s*\(/i.test(text)) return final(`Delete a whole ${name} table or database`);
  if (/\b(truncate)\b|\bdelete\s+from\b|\.(deleteMany|remove)\s*\(/i.test(text)) return final(`Delete data in the ${name} database`);
  if (/\b(update|insert|alter|create)\b|\.(updateMany|updateOne|insertOne|insertMany)\s*\(/i.test(text)) return safe(`Change data in the ${name} database`);
  return safe(`Run a query on the ${name} database`);
}

/** Words that only shape the line (`if`, `then`, `do`, a group's brace...): what follows them is the command. */
const SHELL_KEYWORDS = new Set(['if', 'then', 'else', 'elif', 'do', 'while', 'until', '!', '{', '(', 'time']);

/** Programs that run the command after their own options (`nohup cmd`, `timeout 5 cmd`, `xargs cmd`): it is that command that counts. Value: options that take a value. */
const WRAPPERS: Record<string, Set<string>> = {
  env: new Set(['-u', '--unset', '-C', '--chdir', '-S', '--split-string']),
  exec: new Set(['-a']),
  command: new Set(),
  builtin: new Set(),
  nohup: new Set(),
  time: new Set(['-f', '--format', '-o', '--output']),
  nice: new Set(['-n', '--adjustment']),
  ionice: new Set(['-c', '-n', '-p', '-t']),
  chrt: new Set(),
  setsid: new Set(),
  stdbuf: new Set(['-i', '-o', '-e']),
  unbuffer: new Set(),
  timeout: new Set(['-s', '--signal', '-k', '--kill-after']),
  watch: new Set(['-n', '--interval', '-d']),
  xargs: new Set(['-I', '-i', '-n', '-P', '-d', '-L', '-l', '-s', '-E', '-e', '-a', '--arg-file', '--delimiter', '--max-args', '--max-procs', '--replace']),
};

/** Words a program that is not known here uses for deleting or tearing down (`aws s3 rm`, `gcloud projects delete`). */
const DELETE_WORDS = new Set(['delete', 'destroy', 'rm', 'rb', 'rmdir', 'remove', 'purge', 'drop', 'terminate', 'wipe', 'prune', 'truncate', 'uninstall', 'erase', 'nuke']);

/** A whole line given as text to another shell (`bash -c "..."`, `eval "..."`): what that line does, without Claude's own words. */
function describeInner(line: string, depth: number): ActionDescription | null {
  if (depth > 3 || !line.trim()) return null;
  const d = describeShell(line, '', depth + 1);
  return d.known ? d : null;
}

function describeOne(c: Command, piped: Command | null, depth = 0): ActionDescription | null {
  let words = c.words.map((w) => w.text);
  // `FOO=1 cmd`, `then cmd`, `nohup cmd`, `env FOO=1 cmd`, `timeout 5 cmd`, `xargs -0 cmd`: the command is what follows.
  for (let guard = 0; guard < 20 && words.length; guard++) {
    if (/^[A-Za-z_][A-Za-z0-9_]*=/.test(words[0]) || SHELL_KEYWORDS.has(words[0])) {
      words = words.slice(1);
      continue;
    }
    const w = programName(words[0]);
    const takesValue = WRAPPERS[w];
    if (!takesValue) break;
    let i = 1;
    while (i < words.length && (words[i].startsWith('-') || (w === 'env' && /^[A-Za-z_][A-Za-z0-9_]*=/.test(words[i])))) {
      i += takesValue.has(words[i]) ? 2 : 1;
    }
    // `timeout 5 cmd`, `chrt 10 cmd`: a number before the command.
    if ((w === 'timeout' || w === 'chrt') && i < words.length && /^[0-9.]+[smhd]?$/.test(words[i])) i++;
    words = words.slice(i);
  }
  if (!words.length) return null;
  let prog = programName(words[0]);
  let args = words.slice(1);
  if (prog === 'sudo' || prog === 'doas') {
    // Options of sudo (`-u user`, `-E`) come before the command.
    let i = 0;
    while (i < args.length && args[i].startsWith('-')) i += args[i] === '-u' || args[i] === '-g' ? 2 : 1;
    const inner = args.slice(i);
    if (!inner.length) return safe('Get administrator rights');
    const d = describeOne({ ...c, words: c.words.slice(c.words.length - inner.length) }, piped, depth);
    return d ? { summary: `As administrator: ${d.summary.charAt(0).toLowerCase()}${d.summary.slice(1)}`, undoable: d.undoable } : null;
  }
  if (prog === 'npx' || prog === 'bunx') {
    const tool = positional(args)[0];
    return safe(tool ? `Download and run the tool ${short(tool)}` : 'Run a tool');
  }
  // `bash -c "..."` and `eval "..."`: the line inside is what runs.
  if (prog === 'eval' || (SHELLS.has(prog) && (args.includes('-c') || args.some((a) => /^-[a-z]*c[a-z]*$/.test(a))) && ['sh', 'bash', 'zsh', 'dash', 'ksh', 'fish'].includes(prog))) {
    const at = prog === 'eval' ? 0 : args.findIndex((a) => /^-[a-z]*c[a-z]*$/.test(a)) + 1;
    const line = prog === 'eval' ? args.join(' ') : (args[at] ?? '');
    return describeInner(line, depth) ?? safe('Run a few commands');
  }
  // `find ... -exec rm -rf {} +`: what it does to each file found.
  if (prog === 'find') {
    const ex = args.findIndex((a) => a === '-exec' || a === '-execdir' || a === '-ok' || a === '-okdir');
    if (ex >= 0) {
      const tail = args.slice(ex + 1);
      const stop = tail.findIndex((a) => a === ';' || a === '+' || a === '\\;');
      const inner = describeInner((stop >= 0 ? tail.slice(0, stop) : tail).map((a) => (a === '{}' ? 'FILE' : shellQuoteWord(a))).join(' '), depth);
      if (args.includes('-delete')) return final('Find files and delete them');
      const each = stop >= 0 ? tail.slice(0, stop) : tail;
      if (inner && ['rm', 'rmdir', 'unlink', 'shred'].includes(programName(each[0] ?? ''))) return final('Find files and delete them');
      if (inner) return { summary: `Find files and, for each one: ${inner.summary.charAt(0).toLowerCase()}${inner.summary.slice(1)}`, undoable: inner.undoable };
    }
  }
  if (/^mkfs(\.|$)/.test(prog) || prog === 'wipefs' || prog === 'sgdisk') return final('Write straight to a disk (this can erase it)');
  if (prog === 'truncate') {
    const files = positional(args).filter((a) => !/^[0-9]+[KMG]?$/.test(a));
    return final(`Empty the file${files.length > 1 ? 's' : ''} ${list(files, 'named here')}`);
  }
  const pos = positional(args);
  const text = words.join(' ');
  // A download handed straight to a shell runs code nobody has read.
  if ((prog === 'curl' || prog === 'wget') && c.pipesTo) {
    const next = c.pipesTo.words.map((w) => programName(w.text)).find((w) => w !== 'sudo' && !w.startsWith('-'));
    if (next && SHELLS.has(next)) {
      const url = args.find((a) => /^[a-z]+:\/\//i.test(a)) ?? pos[0] ?? '';
      return final(`Download a script from ${hostOf(url)} and run it straight away`);
    }
  }
  if (piped && SHELLS.has(prog) && piped.words.some((w) => programName(w.text) === 'curl' || programName(w.text) === 'wget')) return null;
  switch (prog) {
    case 'rm':
    case 'rmdir':
    case 'unlink':
    case 'shred': {
      const folder = prog === 'rmdir' || hasShort(args, 'r') || hasShort(args, 'R') || args.includes('--recursive');
      if (!pos.length) return final('Delete files');
      if (folder) return final(`Delete ${pos.length > 1 ? 'the folders' : 'the folder'} ${list(pos)} and everything in ${pos.length > 1 ? 'them' : 'it'}`);
      return final(`Delete ${pos.length > 1 ? 'the files' : 'the file'} ${list(pos)}`);
    }
    case 'mv':
      if (pos.length >= 2) return safe(`Move or rename ${list(pos.slice(0, -1))} to ${short(pos[pos.length - 1])}`);
      return safe('Move or rename files');
    case 'cp':
    case 'rsync':
    case 'scp':
      if (pos.length >= 2) return safe(`Copy ${list(pos.slice(0, -1))} to ${short(pos[pos.length - 1])}`);
      return safe('Copy files');
    case 'mkdir':
      return safe(`Make the folder ${list(pos)}`);
    case 'touch':
      return safe(`Make the file ${list(pos)}`);
    case 'git':
      return describeGit(args);
    case 'gh':
      if (pos[0] === 'pr' && pos[1] === 'merge') return final('Merge the pull request on GitHub');
      if (pos[0] === 'pr' && pos[1] === 'create') return safe('Open a pull request on GitHub');
      if (pos[0] === 'repo' && pos[1] === 'delete') return final('Delete the GitHub repository');
      if (pos[0] === 'release' && pos[1] === 'create') return safe('Publish a release on GitHub');
      return safe('Use GitHub');
    case 'pip':
    case 'pip3':
    case 'uv':
      return describePip(prog === 'uv' && args[0] === 'pip' ? args.slice(1) : args);
    case 'python':
    case 'python3':
      if (args[0] === '-m' && (args[1] === 'pip' || args[1] === 'pip3')) return describePip(args.slice(2));
      if (pos[0]) return safe(`Run the Python program ${short(pos[0])}`);
      return safe('Run Python code');
    case 'node':
    case 'deno':
    case 'ruby':
    case 'perl':
      return safe(pos[0] ? `Run the program ${short(pos[0])}` : `Run ${prog} code`);
    case 'bash':
    case 'sh':
    case 'zsh':
      return safe(args[0] === '-c' ? 'Run a few commands' : pos[0] ? `Run the script ${short(pos[0])}` : 'Run a script');
    case 'docker':
    case 'podman':
      return describeDocker(args);
    case 'docker-compose':
      return describeDocker(['compose', ...args]);
    case 'systemctl':
      return describeSystemctl(args);
    case 'service':
      return describeSystemctl([pos[1] ?? '', pos[0] ?? '']);
    case 'reboot':
      return final('Restart the computer');
    case 'shutdown':
    case 'poweroff':
    case 'halt':
      return final('Turn the computer off');
    case 'curl':
    case 'wget': {
      const url = args.find((a) => /^[a-z]+:\/\//i.test(a)) ?? pos[0] ?? '';
      const sends = args.some((a) => ['-X', '--request', '-d', '--data', '--data-raw', '-F', '--form', '-T', '--upload-file'].includes(a));
      return safe(sends ? `Send data to ${hostOf(url)}` : `Download from ${hostOf(url)}`);
    }
    case 'chmod': {
      const deep = hasShort(args, 'R') || args.includes('--recursive');
      const files = pos.slice(1);
      return safe(`Change who can read, change or run ${list(files, 'files')}${deep ? ' and everything inside' : ''}`);
    }
    case 'chown':
    case 'chgrp': {
      const deep = hasShort(args, 'R') || args.includes('--recursive');
      const files = pos.slice(1);
      return safe(`Change the owner of ${list(files, 'files')}${deep ? ' and everything inside' : ''}${pos[0] ? ` to ${short(pos[0])}` : ''}`);
    }
    case 'kill':
      return final(`Stop the running program${pos.length > 1 ? 's' : ''} (number ${list(pos)})`);
    case 'pkill':
    case 'killall':
      return final(`Stop every running program called ${list(pos)}`);
    case 'dd':
    case 'mkfs':
    case 'fdisk':
    case 'parted':
      return final('Write straight to a disk (this can erase it)');
    case 'apt':
    case 'apt-get':
    case 'dnf':
    case 'yum':
    case 'brew':
    case 'pacman':
    case 'snap': {
      const op = pos[0] ?? '';
      const names = pos.slice(1);
      if (op === 'install' || op === '-S') return safe(`Install ${list(names, 'programs')} on the computer`);
      if (op === 'remove' || op === 'purge' || op === 'uninstall' || op === 'autoremove') return safe(`Remove ${list(names, 'programs')} from the computer`);
      if (op === 'update' || op === 'upgrade') return safe('Update the programs on the computer');
      return safe(`Run ${prog} ${short(op)}`);
    }
    case 'make':
      if (pos.includes('clean') || pos.includes('distclean')) return safe('Delete what this project built, so it can be built again');
      return safe(pos[0] ? `Run the "${short(pos[0])}" step of this project` : 'Build this project');
    case 'cargo':
    case 'go':
    case 'dotnet':
    case 'mvn':
    case 'gradle':
    case './gradlew':
    case 'gradlew':
    case 'flutter':
    case 'dart':
      if (pos[0] === 'test') return safe("Run this project's tests");
      if (pos[0] === 'build') return safe('Build this project');
      if (pos[0] === 'run') return safe('Start this project');
      return safe(`Run ${prog} ${short(pos[0] ?? '')}`);
    case 'ssh':
      return safe(`Connect to the computer ${pos[0] ? short(pos[0].replace(/^.*@/, '')) : 'online'} and run commands there`);
    case 'tee':
      return safe(`Write to the file ${list(pos)}`);
    case 'sed':
      if (args.some((a) => a === '-i' || a.startsWith('-i') || a === '--in-place')) return safe(`Change the text in ${list(pos.slice(1), 'files')}`);
      return safe('Read files');
    case 'cat':
    case 'less':
    case 'head':
    case 'tail':
    case 'ls':
    case 'find':
    case 'grep':
    case 'rg':
    case 'wc':
    case 'tree':
    case 'du':
    case 'df':
    case 'stat':
    case 'file':
      if (prog === 'find' && args.includes('-delete')) return final('Find files and delete them');
      return safe('Look at files');
    case 'tar':
    case 'zip':
    case 'unzip':
    case 'gzip':
    case 'gunzip':
      return safe(args.some((a) => /^-?[a-z]*x/.test(a)) || prog === 'unzip' || prog === 'gunzip' ? 'Unpack an archive' : 'Pack files into an archive');
    case 'crontab':
      return args.includes('-r') ? final('Delete all scheduled jobs') : safe('Change the scheduled jobs');
    case 'vercel':
    case 'netlify':
    case 'firebase':
    case 'wrangler':
    case 'fly':
    case 'flyctl':
    case 'heroku':
      return safe(pos.includes('deploy') || pos.includes('--prod') || args.includes('--prod') ? 'Put a new version of the site live' : `Use ${prog}`);
    case 'kubectl':
      if (pos[0] === 'delete') return final(`Delete ${list(pos.slice(1), 'things')} from the cluster`);
      if (pos[0] === 'apply') return safe('Change what runs on the cluster');
      return safe('Use the cluster');
    case 'terraform':
      if (pos[0] === 'destroy') return final('Delete the cloud setup this project made');
      if (pos[0] === 'apply') return safe('Change the cloud setup');
      return safe('Check the cloud setup');
  }
  if (PACKAGE_MANAGERS.has(prog)) return describePackages(prog, args);
  if (DB_TOOLS[prog]) return describeDb(prog, args, text);
  // A program not known here that says it deletes (`aws s3 rm`, `gcloud projects delete`): never called harmless.
  const del = positional(args).find((a) => DELETE_WORDS.has(a.toLowerCase()));
  if (del) return final(`Use ${short(prog)} to ${del.toLowerCase() === 'destroy' ? 'tear something down' : 'delete something'}`);
  return null;
}

function describeShell(command: string, description: string, depth = 0): ActionDescription & { known: boolean } {
  const parsed = parseShell(command.replace(/\\\r?\n/g, ' '));
  const parts: ActionDescription[] = [];
  let unknown = 0;
  // Every command, those inside `$(...)`, backticks and `<(...)` too: a delete hidden in a substitution is still a delete.
  for (const c of parsed.commands) {
    const first = c.words[0] ? programName(c.words[0].text) : '';
    if (!first || SCENERY.has(first) || first === 'fi' || first === 'done' || first === 'esac' || first === '}' || first === ')') continue;
    const d = describeOne(c, c.pipeFrom, depth);
    if (d) parts.push(d);
    else if (!(c.pipeFrom && SHELLS.has(first)) && !c.nested) unknown++;
  }
  const undoable = parts.every((p) => p.undoable);
  if (parts.length === 0) {
    if (description) return { summary: cap(description), undoable: true, known: false };
    const prog = parsed.top.map((c) => (c.words[0] ? programName(c.words[0].text) : '')).find((p) => p && !SCENERY.has(p));
    return { summary: prog ? `Run the program ${short(prog)}` : 'Run a command on your computer', undoable: true, known: false };
  }
  // What cannot be undone is said first.
  const ordered = [...parts.filter((p) => !p.undoable), ...parts.filter((p) => p.undoable)];
  const said = ordered.slice(0, 2).map((p, i) => (i === 0 ? p.summary : p.summary.charAt(0).toLowerCase() + p.summary.slice(1)));
  const more = parts.length - said.length + unknown;
  const summary = `${said.join(', then ')}${more > 0 ? ` (+${more} more step${more > 1 ? 's' : ''})` : ''}`;
  return { summary: cap(summary), undoable, known: true };
}

/** What the safety check (risk.ts) found, in the bar's words: said first when the reading above missed it. */
const RISK_WORDS: Record<RiskKind, string> = {
  'delete-folder': 'Delete a folder and everything in it',
  'force-push': 'Overwrite the online copy of this project',
  'remote-delete': 'Delete branches or tags online',
  'discard-work': 'Throw away changes that are not saved',
  database: 'Delete or empty database data',
  cluster: 'Delete things running in a Kubernetes cluster',
  'infra-destroy': 'Tear down cloud servers or databases',
  'container-prune': 'Delete Docker containers, images or stored data',
  'cloud-delete': 'Delete something in a cloud account',
  disk: 'Write straight to a disk (this can erase it)',
  permissions: 'Change who can read or change files across the computer',
  'download-run': 'Download a script and run it straight away',
  credentials: 'Reach your saved passwords or keys',
  'outside-home': 'Change files that belong to the whole computer',
  'system-change': 'Change the computer itself, or run as administrator',
  'send-message': 'Send an email or message in your name',
  'screen-act': 'Use your screen for you',
  unreadable: 'Run a command too long or tangled to check',
};

/** Risk kinds whose work cannot be taken back (the phone's _undoneHolds, message_format.dart). */
const UNDONE_RISKS: ReadonlySet<RiskKind> = new Set(['delete-folder', 'force-push', 'remote-delete', 'discard-work', 'database', 'cluster', 'infra-destroy', 'container-prune', 'cloud-delete', 'disk', 'download-run', 'send-message']);

function str(v: unknown): string {
  return typeof v === 'string' ? v : '';
}

function mcpWords(name: string): string {
  return name.replace(/[_-]+/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().trim();
}

/** What this tool call will do, in everyday words. Never throws; something it does not know gets a safe generic line. */
export function describeCommand(tool: string, input: unknown): ActionDescription {
  try {
    const i = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>;
    const file = short(str(i.file_path) || str(i.notebook_path) || str(i.path));
    switch (tool) {
      case 'Bash':
      case 'BashOutput':
      case 'Monitor':
      case 'PowerShell':
      case 'shell':
      case 'exec': {
        const raw = i.command ?? i.cmd ?? i.script;
        const command = Array.isArray(raw) ? raw.map((x) => String(x)).join(' ') : str(raw);
        if (!command.trim()) return safe('Run a command on your computer');
        const { summary, undoable } = describeShell(command, str(i.description));
        // The safety check reads the line more deeply: what it calls risky is never left out of the words or called undoable.
        const risk = riskyToolCall(tool, input);
        if (!risk || !undoable) return { summary, undoable };
        const final = UNDONE_RISKS.has(risk.kind);
        // Something only to be careful with (administrator rights, a system file) keeps its words unless it reaches your keys.
        if (!final && risk.kind !== 'credentials') return { summary, undoable };
        const lead = RISK_WORDS[risk.kind];
        return { summary: summary.toLowerCase().startsWith(lead.toLowerCase()) ? summary : cap(`${lead}. ${summary}`), undoable: !final };
      }
      case 'Edit':
      case 'MultiEdit':
        return safe(file ? `Change the file ${file}` : 'Change a file');
      case 'Write':
        return safe(file ? `Write the file ${file}` : 'Write a file');
      case 'NotebookEdit':
        return safe(file ? `Change the notebook ${file}` : 'Change a notebook');
      case 'Read':
        return safe(file ? `Read the file ${file}` : 'Read a file');
      case 'Glob':
      case 'Grep':
      case 'LS':
        return safe('Search the files in this project');
      case 'WebFetch':
        return safe(`Open the web page ${hostOf(str(i.url))}`);
      case 'WebSearch':
        return safe(str(i.query) ? `Search the web for "${short(str(i.query))}"` : 'Search the web');
      case 'Task':
      case 'Agent':
        return safe(str(i.description) ? `Start a helper to ${str(i.description).charAt(0).toLowerCase()}${str(i.description).slice(1)}` : 'Start a helper for part of the work');
      case 'AskUserQuestion':
        return safe('Ask you a question');
      case 'ExitPlanMode':
        return safe('Start working on the plan');
      case 'TodoWrite':
        return safe('Update its to-do list');
    }
    // JARVIS1: this computer's own everyday actions (agent computerControl.ts), in the words the person would use.
    if (tool.startsWith('mcp__escanor_computer__')) {
      const what = tool.slice('mcp__escanor_computer__'.length);
      const q = str(i.query) || str(i.url);
      const words: Record<string, string> = {
        open_url: `Open ${str(i.url) || 'a web page'} in your browser`,
        open_app: `Open ${str(i.app) || 'an app'}`,
        play_youtube: q ? `Play “${q}” on YouTube in your browser` : 'Open YouTube in your browser',
        media: `Press ${(str(i.op) || 'play/pause').replace('_', '/')} on what is playing`,
        volume: str(i.op) === 'set' ? `Set the volume to ${String(i.level)}%` : `Volume ${str(i.op) || 'change'}`,
        lock_screen: 'Lock your screen',
        compose_mail: `Open a new email${str(i.to) ? ` to ${str(i.to)}` : ''} for you to send`,
        screen_help: 'Look at your screen once to answer your question (the picture is not kept)',
        screen_do: str(i.kind) === 'fill' ? `Type “${short(str(i.text))}” into “${short(str(i.label))}” on your screen` : `Click “${short(str(i.label))}” on your screen`,
      };
      if (words[what]) return safe(cap(words[what]));
    }
    const mcp = /^mcp__([^_]+(?:_[^_]+)*?)__(.+)$/.exec(tool);
    if (mcp) return safe(cap(`Use ${mcpWords(mcp[1])}: ${mcpWords(mcp[2])}`));
    return safe(cap(`Use the tool ${tool || 'asked for'}`));
  } catch {
    return safe('Do something on your computer');
  }
}
