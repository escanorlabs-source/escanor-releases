/**
 * A small, linear shell reader: what a command line will actually run, as bash would split it.
 *
 * Not a full shell. It reads words (quotes, backslashes, `$var`), the operators that separate commands (`;` `&&` `||` `|` `&`
 * newline), redirections, here-documents and comments, and it opens up what runs inside a word: `$(...)`, backticks and
 * `<(...)` are read as commands of their own. Simple brace lists in a word (`{rm,-rf,/}`) are expanded as bash expands them.
 *
 * Two users:
 *  - risk.ts asks which programs run with which arguments (`commands`), so `echo "rm -rf /"` is an echo, not a delete.
 *  - autonomy.ts asks, for a plain command line it can vouch for (`simple`), whether a word it flagged is only text (a commit
 *    message, a here-document written to a file, an echo) rather than something that runs.
 */

export type Word = {
  /** The word as the program receives it: quotes and backslashes removed. Substitutions are left as written (`$(pwd)`). */
  text: string;
  /** The word exactly as typed. */
  raw: string;
  /** Some of it was quoted. */
  quoted: boolean;
  /** An unquoted or double-quoted `$name` / `${name}` the shell fills in (its value is not known here). */
  hasVar: boolean;
  /** A `$(...)`, backtick or `<(...)` inside it (its commands are read separately, see Command.nested). */
  hasSubst: boolean;
  /** The commands of its substitutions, outermost first. */
  subst: Command[];
};

export type Redirect = { op: string; target: Word | null };

export type HereDoc = { delimiter: string; body: string; quoted: boolean; strip: boolean; closed: boolean };

export type Command = {
  words: Word[];
  redirects: Redirect[];
  heredocs: HereDoc[];
  /** `<<< word`: a here-string fed to it. */
  herestrings: Word[];
  /** The command whose output this one reads (`a | b`: b.pipeFrom is a). */
  pipeFrom: Command | null;
  /** Its own output goes into the next command of a pipeline. */
  pipesTo: Command | null;
  /** Read from inside a substitution, a `bash -c` string, a here-document fed to a shell... */
  nested: boolean;
};

export type Parsed = {
  /** Every command of the line, including those inside substitutions (flat, in reading order). */
  commands: Command[];
  /** The top-level commands only (what autonomy.ts can vouch for). */
  top: Command[];
  /**
   * Nothing here that this reader does not fully follow: no substitution, subshell, group, brace list, `eval`, unbalanced
   * quote, or a here-document whose end was never found. Only then may a caller say a word is "only text".
   */
  simple: boolean;
  /** A quote was never closed (bash would refuse the line). */
  unterminated: boolean;
  /** Substitutions nest deeper than this reader follows: what runs inside them was not read. */
  tooDeep: boolean;
};

const MAX_DEPTH = 8;

const isSpace = (c: string) => c === ' ' || c === '\t' || c === '\r';
const isNameStart = (c: string) => /[A-Za-z_]/.test(c);
const isNameChar = (c: string) => /[A-Za-z0-9_]/.test(c);

function emptyCommand(nested: boolean): Command {
  return { words: [], redirects: [], heredocs: [], herestrings: [], pipeFrom: null, pipesTo: null, nested };
}

/** The index just after the `)` that closes the `(` at src[open], with quotes and nested parentheses skipped; -1 if none. */
function closeParen(src: string, open: number): number {
  let depth = 0;
  for (let i = open; i < src.length; i++) {
    const c = src[i];
    if (c === '\\') {
      i++;
      continue;
    }
    if (c === "'") {
      const end = src.indexOf("'", i + 1);
      if (end < 0) return -1;
      i = end;
      continue;
    }
    if (c === '"') {
      // A double-quoted string may itself hold $( ... ): walk it.
      let j = i + 1;
      while (j < src.length && src[j] !== '"') {
        if (src[j] === '\\') j++;
        j++;
      }
      if (j >= src.length) return -1;
      i = j;
      continue;
    }
    if (c === '`') {
      const end = closeBacktick(src, i);
      if (end < 0) return -1;
      i = end - 1;
      continue;
    }
    if (c === '(') depth++;
    else if (c === ')') {
      depth--;
      if (depth === 0) return i + 1;
    }
  }
  return -1;
}

/** The index just after the backtick that closes the one at src[open]; -1 if none. */
function closeBacktick(src: string, open: number): number {
  for (let i = open + 1; i < src.length; i++) {
    if (src[i] === '\\') {
      i++;
      continue;
    }
    if (src[i] === '`') return i + 1;
  }
  return -1;
}

/** `{a,b,c}` (one unquoted brace list, with an optional prefix and suffix) as bash expands it; null when it is not one. */
function braceExpand(raw: string): string[] | null {
  const m = /^([^{}'"\\$]*)\{([^{}'"\\$]*,[^{}'"\\$]*)\}([^{}'"\\$]*)$/.exec(raw);
  if (!m) return null;
  return m[2].split(',').map((part) => `${m[1]}${part}${m[3]}`);
}

type State = { src: string; i: number; depth: number; parsed: Parsed };

function parseInto(src: string, depth: number, nested: boolean, parsed: Parsed): Command[] {
  const st: State = { src, i: 0, depth, parsed };
  const top: Command[] = [];
  let cmd = emptyCommand(nested);
  const pendingHeredocs: HereDoc[] = [];
  const finish = () => {
    if (cmd.words.length || cmd.redirects.length || cmd.heredocs.length || cmd.herestrings.length) {
      top.push(cmd);
      parsed.commands.push(cmd);
    }
  };
  const next = (pipe: boolean) => {
    finish();
    const prev = cmd;
    cmd = emptyCommand(nested);
    if (pipe && (prev.words.length || prev.redirects.length || prev.heredocs.length)) {
      cmd.pipeFrom = prev;
      prev.pipesTo = cmd;
    }
  };

  while (st.i < src.length) {
    const c = src[st.i];
    if (isSpace(c)) {
      st.i++;
      continue;
    }
    if (c === '\n') {
      st.i++;
      next(false);
      // Here-document bodies start on the line after their `<<`.
      for (const h of pendingHeredocs.splice(0)) readHeredocBody(st, h);
      continue;
    }
    if (c === '#') {
      // A comment runs to the end of the line.
      const end = src.indexOf('\n', st.i);
      st.i = end < 0 ? src.length : end;
      continue;
    }
    if (c === ';' || c === '&' || c === '|') {
      const two = src.slice(st.i, st.i + 2);
      if (c === '|' && two !== '||') {
        st.i += two === '|&' ? 2 : 1;
        next(true);
        continue;
      }
      if (c === '&' && (two === '&>' || src.slice(st.i, st.i + 3) === '&>>')) {
        // &> file: a redirection, not a separator.
        const op = src.slice(st.i, st.i + 3) === '&>>' ? '&>>' : '&>';
        st.i += op.length;
        cmd.redirects.push({ op, target: readWord(st) });
        continue;
      }
      st.i += two === '&&' || two === '||' || two === ';;' ? 2 : 1;
      next(false);
      continue;
    }
    if (c === '(' || c === ')') {
      // A subshell or group: its commands are read as commands; a caller vouching for plain text does not vouch for these.
      parsed.simple = false;
      st.i++;
      next(false);
      continue;
    }
    // Redirections: [n]> >> < <> >| <&n >&n, here-documents << <<-, here-strings <<<, process substitution <( >(.
    const redir = /^(\d*)(<<<|<<-|<<|>>|>\||>&|<&|<>|>|<)/.exec(src.slice(st.i, st.i + 6));
    if (redir) {
      if ((redir[2] === '<' || redir[2] === '>') && src[st.i + redir[0].length] === '(') {
        // <(cmd) / >(cmd): read as a word (its commands are nested).
        const w = readWord(st);
        if (w) cmd.words.push(w);
        else st.i++; // never stuck on a character readWord does not take
        continue;
      }
      st.i += redir[0].length;
      const op = redir[2];
      if (op === '<<' || op === '<<-') {
        while (st.i < src.length && isSpace(src[st.i])) st.i++;
        const w = readWord(st);
        if (!w) continue;
        const h: HereDoc = { delimiter: w.text, body: '', quoted: w.quoted, strip: op === '<<-', closed: false };
        cmd.heredocs.push(h);
        pendingHeredocs.push(h);
        continue;
      }
      if (op === '<<<') {
        const w = readWord(st);
        if (w) cmd.herestrings.push(w);
        continue;
      }
      cmd.redirects.push({ op: redir[1] + op, target: readWord(st) });
      continue;
    }
    const w = readWord(st);
    if (!w) {
      st.i++;
      continue;
    }
    if (!w.quoted && (w.raw === '{' || w.raw === '}')) {
      parsed.simple = false;
      continue;
    }
    const expanded = !w.quoted && w.raw.includes('{') && w.raw.includes(',') ? braceExpand(w.raw) : null;
    if (expanded) {
      parsed.simple = false;
      for (const text of expanded) cmd.words.push({ ...w, text, raw: text });
      continue;
    }
    if (w.raw.includes('{') || w.raw.includes('}')) {
      if (!w.quoted || /(?:^|[^$])\{/.test(w.raw)) parsed.simple = false;
    }
    cmd.words.push(w);
  }
  finish();
  for (const h of pendingHeredocs) if (!h.closed) parsed.simple = false; // no end line: bash would read to the end
  return top;
}

function readHeredocBody(st: State, h: HereDoc): void {
  const lines: string[] = [];
  while (st.i < st.src.length) {
    const end = st.src.indexOf('\n', st.i);
    const line = st.src.slice(st.i, end < 0 ? st.src.length : end);
    st.i = end < 0 ? st.src.length : end + 1;
    const cmp = h.strip ? line.replace(/^\t+/, '') : line;
    if (cmp === h.delimiter) {
      h.body = lines.length ? `${lines.join('\n')}\n` : '';
      h.closed = true;
      return;
    }
    lines.push(cmp);
  }
  // Never closed: the rest of the input is its body.
  h.body = lines.join('\n');
  st.parsed.simple = false;
}

/** Reads one word at st.i (which is not a space or an operator). Null at the end. */
function readWord(st: State): Word | null {
  const { src } = st;
  while (st.i < src.length && isSpace(src[st.i])) st.i++;
  if (st.i >= src.length) return null;
  const start = st.i;
  let text = '';
  let quoted = false;
  let hasVar = false;
  let hasSubst = false;
  const subst: Command[] = [];
  const nest = (inner: string) => {
    hasSubst = true;
    st.parsed.simple = false;
    if (st.depth >= MAX_DEPTH) {
      st.parsed.tooDeep = true;
      return;
    }
    subst.push(...parseInto(inner, st.depth + 1, true, st.parsed));
  };
  /** `$...` at st.i (inside double quotes or not): appends it and reads what runs inside. */
  const dollar = () => {
    const n = src[st.i + 1];
    if (n === '(') {
      const end = closeParen(src, st.i + 1);
      if (end < 0) {
        st.parsed.unterminated = true;
        text += src.slice(st.i);
        st.i = src.length;
        return;
      }
      // $(( arithmetic )) runs nothing.
      if (src[st.i + 2] !== '(') nest(src.slice(st.i + 2, end - 1));
      else st.parsed.simple = false;
      text += src.slice(st.i, end);
      st.i = end;
      return;
    }
    if (n === '{') {
      const end = src.indexOf('}', st.i + 2);
      const stop = end < 0 ? src.length : end + 1;
      text += src.slice(st.i, stop);
      hasVar = true;
      st.i = stop;
      return;
    }
    if (n !== undefined && (isNameStart(n) || /[0-9@*#?$!-]/.test(n))) {
      let j = st.i + 2;
      if (isNameStart(n)) while (j < src.length && isNameChar(src[j])) j++;
      text += src.slice(st.i, j);
      hasVar = true;
      st.i = j;
      return;
    }
    if (n === "'") {
      // $'...': ANSI-C quoting.
      quoted = true;
      const end = src.indexOf("'", st.i + 2);
      const stop = end < 0 ? src.length : end;
      if (end < 0) st.parsed.unterminated = true;
      text += src.slice(st.i + 2, stop).replace(/\\(.)/g, '$1');
      st.i = stop + 1;
      return;
    }
    text += '$';
    st.i++;
  };

  while (st.i < src.length) {
    const c = src[st.i];
    if (isSpace(c) || c === '\n' || c === ';' || c === '&' || c === '|' || c === ')') break;
    if (c === '(' ) {
      if (st.i === start) break; // a subshell opens here, not a word
      // `<(`/`>(` inside a word is handled below; any other ( makes this line one we do not vouch for.
      st.parsed.simple = false;
      text += c;
      st.i++;
      continue;
    }
    if ((c === '<' || c === '>') && src[st.i + 1] === '(') {
      const end = closeParen(src, st.i + 1);
      if (end < 0) {
        st.parsed.unterminated = true;
        st.i = src.length;
        break;
      }
      nest(src.slice(st.i + 2, end - 1));
      text += src.slice(st.i, end);
      st.i = end;
      continue;
    }
    if ((c === '<' || c === '>') && st.i > start) break; // a redirection right after the word (`a>b`)
    if ((c === '<' || c === '>') && st.i === start) break;
    if (c === '\\') {
      if (st.i + 1 < src.length && src[st.i + 1] !== '\n') {
        text += src[st.i + 1];
        quoted = true;
      }
      st.i += 2;
      continue;
    }
    if (c === "'") {
      quoted = true;
      const end = src.indexOf("'", st.i + 1);
      if (end < 0) {
        st.parsed.unterminated = true;
        text += src.slice(st.i + 1);
        st.i = src.length;
        break;
      }
      text += src.slice(st.i + 1, end);
      st.i = end + 1;
      continue;
    }
    if (c === '"') {
      quoted = true;
      st.i++;
      let closed = false;
      while (st.i < src.length) {
        const d = src[st.i];
        if (d === '"') {
          st.i++;
          closed = true;
          break;
        }
        if (d === '\\' && st.i + 1 < src.length && '"\\$`\n'.includes(src[st.i + 1])) {
          if (src[st.i + 1] !== '\n') text += src[st.i + 1];
          st.i += 2;
          continue;
        }
        if (d === '$') {
          dollar();
          continue;
        }
        if (d === '`') {
          const end = closeBacktick(src, st.i);
          if (end < 0) {
            st.parsed.unterminated = true;
            st.i = src.length;
            break;
          }
          nest(src.slice(st.i + 1, end - 1));
          text += src.slice(st.i, end);
          st.i = end;
          continue;
        }
        text += d;
        st.i++;
      }
      if (!closed) st.parsed.unterminated = true;
      continue;
    }
    if (c === '`') {
      const end = closeBacktick(src, st.i);
      if (end < 0) {
        st.parsed.unterminated = true;
        st.i = src.length;
        break;
      }
      nest(src.slice(st.i + 1, end - 1));
      text += src.slice(st.i, end);
      st.i = end;
      continue;
    }
    if (c === '$') {
      dollar();
      continue;
    }
    text += c;
    st.i++;
  }
  if (st.i === start) return null;
  return { text, raw: src.slice(start, st.i), quoted, hasVar, hasSubst, subst };
}

/** Reads a command line. Linear in its length (bounded nesting). */
export function parseShell(src: string, depth = 0): Parsed {
  const parsed: Parsed = { commands: [], top: [], simple: true, unterminated: false, tooDeep: false };
  parsed.top = parseInto(src, depth, depth > 0, parsed);
  if (parsed.unterminated) parsed.simple = false;
  return parsed;
}

/** The program a word names: `/bin/rm`, `\rm`, `"rm"` and `rm` are all rm. */
export function programName(word: string): string {
  return word.slice(word.lastIndexOf('/') + 1);
}
